print ' '
print 'Updating database version info ...'
go

if exists ( select 1 from dbo.database_info where owner_code = 'TC' )
begin
	update database_info
        set last_touch_date = getdate(),
            note='SPK67 #ADSO-9862'
	where owner_code='TC'
end
go