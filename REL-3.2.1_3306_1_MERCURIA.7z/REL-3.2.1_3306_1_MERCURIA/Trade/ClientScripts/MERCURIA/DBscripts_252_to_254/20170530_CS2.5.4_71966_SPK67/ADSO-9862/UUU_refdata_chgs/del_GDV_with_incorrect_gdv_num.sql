print ' '
print 'Removing GDV records with incorrect fdv_nums for the data set ''PASS_CONTROL_INFO'' if EXIST ...'
go

declare @gdd_num1        int,
        @gdd_num2        int,
        @gdd_num3        int,
        @gdv_num1        int,
        @gdv_num2        int,
        @gdn_num         int,
        @rows_deleted    int,
        @errcode         int
        
select @gdd_num1 = null,
       @gdd_num2 = null,
       @gdd_num3 = null,
       @gdv_num1 = null,
       @gdv_num2 = null,
       @gdn_num = null,
       @rows_deleted = 0,
       @errcode = 0


select @gdn_num = gdn_num 
from dbo.generic_data_name
where data_name = 'PASS_CONTROL_INFO'

if @gdn_num is null
   goto endofscript

select @gdd_num1 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'pass_task_code'

select @gdd_num2 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'column_number'

select @gdd_num3 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'column_value'

if @gdd_num1 is null or
   @gdd_num2 is null or
   @gdd_num3 is null
   goto endofscript

select @gdv_num1 = gdv_num
from dbo.generic_data_values
where string_value = 'FUTURE_BROKER_FIFO' and
      gdd_num = @gdd_num1

select @gdv_num2 = gdv_num
from dbo.generic_data_values
where int_value = 3 and
      gdd_num = @gdd_num2
      
if @gdv_num1 = @gdv_num2
   goto endofscript

-- At this point, the GDV table had the records with incorrect gdv_num(s).
-- We need to remove these records
begin tran
exec gen_new_transaction
delete dbo.generic_data_values
where string_value = 'FUTURE_BROKER_FIFO' and
      gdd_num = @gdd_num1
select @rows_deleted = @@rowcount,
       @errcode = @@error
if @errcode > 0
   goto errexit
if @rows_deleted > 0
   print '=> The existing GDV record for the string value ''FUTURE_BROKER_FIFO'' was deleted!'
   
delete dbo.generic_data_values
where int_value = 3 and
      gdd_num = @gdd_num2
select @rows_deleted = @@rowcount,
       @errcode = @@error
if @errcode > 0
   goto errexit
if @rows_deleted > 0
   print '=> The existing GDV record for the int value ''3'' was deleted!'

delete dbo.generic_data_values
where string_value = 'Tag values to group Futures BROKER FIFO' and
      gdd_num = @gdd_num3
select @rows_deleted = @@rowcount,
       @errcode = @@error
if @errcode > 0
   goto errexit
if @rows_deleted > 0
   print '=> The existing GDV record for the string value ''Tag values to group Futures BROKER FIFO'' was deleted!'

delete dbo.generic_data_values
where string_value = 'OPTION_BROKER_FIFO' and
      gdd_num = @gdd_num1
select @rows_deleted = @@rowcount,
       @errcode = @@error
if @errcode > 0
   goto errexit
if @rows_deleted > 0
   print '=> The existing GDV record for the string value ''OPTION_BROKER_FIFO'' was deleted!'
      
delete dbo.generic_data_values
where int_value = 4 and
      gdd_num = @gdd_num2
select @rows_deleted = @@rowcount,
       @errcode = @@error
if @errcode > 0
   goto errexit
if @rows_deleted > 0
   print '=> The existing GDV record for the int value ''4'' was deleted!'

delete dbo.generic_data_values
where string_value = 'Tag values to group Options BROKER FIFO' and
      gdd_num = @gdd_num3
select @rows_deleted = @@rowcount,
       @errcode = @@error
if @errcode > 0
   goto errexit
if @rows_deleted > 0
   print '=> The existing GDV record for the string value ''Tag values to group Options BROKER FIFO'' was deleted!'
commit tran
goto endofscript

errexit:
if @@trancount > 0
   rollback tran
   
endofscript:
go
      

