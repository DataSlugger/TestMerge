/* ********************************************************
    data name 'PASS_CONTROL_INFO'
   ******************************************************** */
set nocount on

print ' '
print 'Adding a GDN record for the data_name "PASS_CONTROL_INFO" ...'
go

declare @gdn_num         int,
        @smsg            varchar(255),
        @rows_affected   int,
        @errcode         int
        
select @gdn_num = null,
       @errcode = 0

if exists (select 1 
           from dbo.generic_data_name
           where data_name = 'PASS_CONTROL_INFO')
begin
   print '=> generic_data_name: The data set name "PASS_CONTROL_INFO" has been added already!'
   goto endofscript
end

select @gdn_num = isnull(max(gdn_num), 0)
from dbo.generic_data_name

select @gdn_num = @gdn_num + 1 
begin tran
insert into dbo.generic_data_name 
   values(@gdn_num, 'PASS_CONTROL_INFO', 1)
select @rows_affected = @@rowcount,
       @errcode = @@error
if @errcode > 0
begin
   if @@trancount > 0
      rollback tran
   select @smsg = '=> Failed to add a GDN record for the data set "PASS_CONTROL_INFO"!'
   print @smsg
   goto endofscript 
end
commit tran
if @rows_affected > 0
begin
   select @smsg = '=> generic_data_name: Added a GDN record (' + cast(@gdn_num as varchar) + ') for the data set "PASS_CONTROL_INFO"' 
   print @smsg
end
endofscript:
go
