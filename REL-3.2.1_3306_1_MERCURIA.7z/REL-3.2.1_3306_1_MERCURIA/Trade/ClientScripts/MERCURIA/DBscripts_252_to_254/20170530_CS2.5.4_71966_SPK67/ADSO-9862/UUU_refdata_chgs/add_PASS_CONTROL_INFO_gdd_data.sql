set nocount on

/* =================================================================
    Adding the following 3 generic_data_definition records for the
    data set "PASS_CONTROL_INFO":

        attr_name             data_type_ind
        --------------------- -------------
        pass_task_code        4
        column_number         1
        column_value          4
   =================================================================
*/

print ' '
print 'Adding 3 GDD records for the data set "PASS_CONTROL_INFO" ...'
go

declare @gdn_num         int,
        @gdd_num         int,
        @smsg            varchar(255),
        @rows_affected   int,
        @errcode         int
        
select @gdn_num = null,
       @gdd_num = null,
       @errcode = 0

select @gdn_num = gdn_num 
from dbo.generic_data_name
where data_name = 'PASS_CONTROL_INFO'

if @gdn_num is null
begin
   print '=> The GDN record for the data set "PASS_CONTROL_INFO" does not exist!'
   goto endofscript
end

/* ***** ATTRIBUTE #1: pass_task_code ***** */

if not exists (select 1 
               from dbo.generic_data_definition
               where gdn_num = @gdn_num and
                     attr_name = 'pass_task_code')
begin
   select @gdd_num = isnull(max(gdd_num), 0)
   from dbo.generic_data_definition

   select @gdd_num = @gdd_num + 1
   begin tran
   insert into dbo.generic_data_definition
      values(@gdd_num, @gdn_num, 'PASS_CONTROL_INFO', 'pass_task_code', 4, 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDD record for the attribute "pass_task_code"!'
      print @smsg
      goto endofscript 
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_definition: Added a GDD record (' + cast(@gdd_num as varchar) + ') for the attribute "pass_task_code"'
      print @smsg
   end
end
else
begin
   select @smsg = '=> generic_data_definition: The attribute "pass_task_code" exists in table already' 
   print @smsg
end

/* ***** ATTRIBUTE #2: column_number ***** */

if not exists (select 1 
               from dbo.generic_data_definition
               where gdn_num = @gdn_num and
                     attr_name = 'column_number')
begin
   select @gdd_num = isnull(max(gdd_num), 0)
   from dbo.generic_data_definition

   select @gdd_num = @gdd_num + 1
   begin tran
   insert into dbo.generic_data_definition
      values(@gdd_num, @gdn_num, 'PASS_CONTROL_INFO', 'column_number', 1, 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDD record for the attribute "column_number"!'
      print @smsg
      goto endofscript 
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_definition: Added a GDD record (' + cast(@gdd_num as varchar) + ') for the attribute "column_number"' 
      print @smsg
   end
end
else
begin
   select @smsg = '=> generic_data_definition: The attribute "column_number" exists in table already' 
   print @smsg
end

/* ***** ATTRIBUTE #3: column_value ***** */

if not exists (select 1 
               from dbo.generic_data_definition
               where gdn_num = @gdn_num and
                     attr_name = 'column_value')
begin
   select @gdd_num = isnull(max(gdd_num), 0)
   from dbo.generic_data_definition

   select @gdd_num = @gdd_num + 1
   begin tran
   insert into dbo.generic_data_definition
      values(@gdd_num, @gdn_num, 'PASS_CONTROL_INFO', 'column_value', 4, 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDD record for the attribute "column_value"!'
      print @smsg
      goto endofscript 
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_definition: Added a GDD record (' + cast(@gdd_num as varchar) + ') for the attribute "column_value"' 
      print @smsg
   end
end
else
begin
   select @smsg = '=> generic_data_definition: The attribute "column_value" exists in table already' 
   print @smsg
end
endofscript:
go
