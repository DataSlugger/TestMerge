print ' '
print 'Adding new attribute ''PORTFOLIO_TAG_FOR_FIFO'' ...'
go

IF NOT EXISTS (select * from dbo.constants
               where attribute_name = 'PORTFOLIO_TAG_FOR_FIFO')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('PORTFOLIO_TAG_FOR_FIFO', 'BOOKCOMP', 'Y', 'A', 'This is the entity_tag which if defined will be used to restrict the real portfolios to consider for FIFO in FIFO application.')
go
