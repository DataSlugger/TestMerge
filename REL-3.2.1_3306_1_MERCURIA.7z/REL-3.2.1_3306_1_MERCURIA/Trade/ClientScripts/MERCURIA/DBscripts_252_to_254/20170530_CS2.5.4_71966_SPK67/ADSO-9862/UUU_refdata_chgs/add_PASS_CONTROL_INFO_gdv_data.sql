set nocount on

print ' '
print 'Adding GDV records for the data set ''PASS_CONTROL_INFO'' ...'
go

declare @gdd_num1        int,
        @gdd_num2        int,
        @gdd_num3        int,
        @gdv_num         int,
        @gdn_num         int,
        @smsg            varchar(255),
        @rows_affected   int,
        @errcode         int
        
select @gdd_num1 = null,
       @gdd_num2 = null,
       @gdd_num3 = null,
       @gdv_num = null,
       @gdn_num = null,
       @errcode = 0


select @gdn_num = gdn_num 
from dbo.generic_data_name
where data_name = 'PASS_CONTROL_INFO'

if @gdn_num is null
begin
   print '=> The GDN record for the data set "PASS_CONTROL_INFO" does not exist!'
   goto endofscript
end

select @gdd_num1 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'pass_task_code'

select @gdd_num2 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'column_number'

select @gdd_num3 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'column_value'

if @gdd_num1 is null or
   @gdd_num2 is null or
   @gdd_num3 is null
begin
   print 'One or some of attributes for data name ''PASS_CONTROL_INFO'' are missing!'
   goto endofscript
end 

/* ----------------------------------------------- 
   GDV row set #1 

      pass_task_code       : FUTURE_BROKER_FIFO
      column_number        : 1
      column_value         : Brokers To Future FIFO
   ----------------------------------------------- */

if not exists (select 1
               from dbo.generic_data_values
               where int_value = 1 and
                     gdd_num = @gdd_num2)   
begin
   -- GDV for the attribute "pass_task_code"
   select @gdv_num = isnull(max(gdv_num), 0)
   from dbo.generic_data_values

   select @gdv_num = @gdv_num + 1
   begin tran
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num1, null, null, null, 'FUTURE_BROKER_FIFO', 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDV record with the string value ''FUTURE_BROKER_FIFO'' for the attribute "pass_task_code"!'
      goto endofscript
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_values: A record with the string value ''FUTURE_BROKER_FIFO'' was added for the attribute "pass_task_code"'
      print @smsg
   end
 
    -- GDV for the attribute "column_number"
   select @gdv_num = isnull(max(gdv_num), 0)
   from dbo.generic_data_values

   select @gdv_num = @gdv_num + 1
   begin tran
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num2, 1, null, null, null, 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDV record with the int value 1 for the attribute "column_number"!'
      goto endofscript
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_values: A record with the int value 1 was added for the attribute "column_number"'
      print @smsg
   end
  
   -- GDV for the attribute "column_value"
   select @gdv_num = isnull(max(gdv_num), 0)
   from dbo.generic_data_values

   select @gdv_num = @gdv_num + 1
   begin tran
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num3, null, null, null, 'Brokers To Future FIFO', 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDV record with the string value ''Brokers To Future FIFO'' for the attribute "column_value"!'
      goto endofscript
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_values: A record with the string value ''Brokers To Future FIFO'' was added for the attribute "column_value"'
      print @smsg
   end
end
else
   print '=> The GDV records for ''FUTURE_BROKER_FIFO/1/Brokers To Future FIFO'' have existed already!'
   

/* ----------------------------------------------- 
   GDV row set #2 

      pass_task_code       : OPTION_BROKER_FIFO
      column_number        : 2
      column_value         : Brokers To Options FIFO
   ----------------------------------------------- */

if not exists (select 1
               from dbo.generic_data_values
               where int_value = 2 and
                     gdd_num = @gdd_num2)   
begin
   -- GDV for the attribute "pass_task_code"
   select @gdv_num = isnull(max(gdv_num), 0)
   from dbo.generic_data_values

   select @gdv_num = @gdv_num + 1
   begin tran
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num1, null, null, null, 'OPTION_BROKER_FIFO', 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDV record with the string value ''OPTION_BROKER_FIFO'' for the attribute "pass_task_code"!'
      goto endofscript
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_values: A record with the string value ''OPTION_BROKER_FIFO'' was added for the attribute "pass_task_code"'
      print @smsg
   end
 
   -- GDV for the attribute "column_number"
   select @gdv_num = isnull(max(gdv_num), 0)
   from dbo.generic_data_values

   select @gdv_num = @gdv_num + 1
   begin tran
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num2, 2, null, null, null, 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDV record with the int value 2 for the attribute "column_number"!'
      goto endofscript
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_values: A record with the int value 2 was added for the attribute "column_number"'
      print @smsg
   end
  
   -- GDV for the attribute "column_value"
   select @gdv_num = isnull(max(gdv_num), 0)
   from dbo.generic_data_values

   select @gdv_num = @gdv_num + 1
   begin tran
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num3, null, null, null, 'Brokers To Options FIFO', 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDV record with the string value ''Brokers To Options FIFO'' for the attribute "column_value"!'
      goto endofscript
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_values: A record with the string value ''Brokers To Options FIFO'' was added for the attribute "column_value"'
      print @smsg
   end
end
else
   print '=> The GDV records for ''OPTION_BROKER_FIFO/2/Brokers To Options FIFO'' have existed already!'

/* ----------------------------------------------- 
   GDV row set #3 

      pass_task_code       : FUTURE_BROKER_FIFO 
      column_number        : 3
      column_value         : Tag values to group Futures BROKER FIFO
   ----------------------------------------------- */

if not exists (select 1
               from dbo.generic_data_values
               where int_value = 3 and
                     gdd_num = @gdd_num2)   
begin
   -- GDV for the attribute "pass_task_code"
   select @gdv_num = isnull(max(gdv_num), 0)
   from dbo.generic_data_values

   select @gdv_num = @gdv_num + 1
   begin tran
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num1, null, null, null, 'FUTURE_BROKER_FIFO', 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDV record with the string value ''FUTURE_BROKER_FIFO'' for the attribute "pass_task_code"!'
      goto endofscript
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_values: A record with the string value ''FUTURE_BROKER_FIFO'' was added for the attribute "pass_task_code"'
      print @smsg
   end
 
    -- GDV for the attribute "column_number"
   begin tran
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num2, 3, null, null, null, 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDV record with the int value 3 for the attribute "column_number"!'
      goto endofscript
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_values: A record with the int value 3 was added for the attribute "column_number"'
      print @smsg
   end
  
   -- GDV for the attribute "column_value"
   begin tran
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num3, null, null, null, 'Tag values to group Futures BROKER FIFO', 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDV record with the string value ''Tag values to group Futures BROKER FIFO'' for the attribute "column_value"!'
      goto endofscript
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_values: A record with the string value ''Tag values to group Futures BROKER FIFO'' was added for the attribute "column_value"'
      print @smsg
   end
end
else
   print '=> The GDV records for ''FUTURE_BROKER_FIFO/3/Tag values to group Futures BROKER FIFO'' have existed already!'

/* ----------------------------------------------- 
   GDV row set #4 
      
      pass_task_code       : OPTION_BROKER_FIFO 
      column_number        : 4
      column_value         : Tag values to group Options BROKER FIFO
   ----------------------------------------------- */

if not exists (select 1
               from dbo.generic_data_values
               where int_value = 4 and
                     gdd_num = @gdd_num2)   
begin
   -- GDV for the attribute "pass_task_code"
   select @gdv_num = isnull(max(gdv_num), 0)
   from dbo.generic_data_values

   select @gdv_num = @gdv_num + 1
   begin tran
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num1, null, null, null, 'OPTION_BROKER_FIFO', 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDV record with the string value ''OPTION_BROKER_FIFO'' for the attribute "pass_task_code"!'
      goto endofscript
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_values: A record with the string value ''OPTION_BROKER_FIFO'' was added for the attribute "pass_task_code"'
      print @smsg
   end
 
   -- GDV for the attribute "column_number"
   begin tran
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num2, 4, null, null, null, 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDV record with the int value 4 for the attribute "column_number"!'
      goto endofscript
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_values: A record with the int value 4 was added for the attribute "column_number"'
      print @smsg
   end
  
   -- GDV for the attribute "column_value"
   begin tran
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num3, null, null, null, 'Tag values to group Options BROKER FIFO', 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
      select @smsg = '=> Failed to add a GDV record with the string value ''Tag values to group Options BROKER FIFO'' for the attribute "column_value"!'
      goto endofscript
   end
   commit tran
   if @rows_affected > 0
   begin
      select @smsg = '=> generic_data_values: A record the string value ''Tag values to group Options BROKER FIFO'' was added for the attribute "column_value"'
      print @smsg
   end
end
else
   print '=> The GDV records for ''OPTION_BROKER_FIFO/4/Tag values to group Options BROKER FIFO'' have existed already!'

endofscript:
go
