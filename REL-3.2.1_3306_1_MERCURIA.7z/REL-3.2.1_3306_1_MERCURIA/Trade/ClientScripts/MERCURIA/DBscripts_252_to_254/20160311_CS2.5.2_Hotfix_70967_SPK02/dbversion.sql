print ' '
print 'Updating database version info ...'
go

if exists ( select 1 from dbo.database_info where owner_code = 'TC' )
begin
	update database_info
        set last_touch_date = getdate(),minor_revnum='70967',
            note='SPK02 #ADSO-4866'
	where owner_code='TC'
end
go