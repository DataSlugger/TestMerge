set nocount on

print ' '
print 'Altering the column ''item_num'' in the ''aud_rc_assign_trade'' table to be a NON-NULLable column ...'
go

declare @columns      table
(
    column_id        smallint primary key,
	column_name      sysname not null,
	data_type        sysname not null,
	null_flag        bit default 1
)

insert into @columns
  select * from [dbo].[udf_table_colinfo]('dbo', 'aud_rc_assign_trade')
  
IF EXISTS (SELECT 1 
           FROM @columns
           WHERE column_name = 'item_num' and
		         null_flag = 1)
BEGIN
   ALTER TABLE dbo.aud_rc_assign_trade
	  ALTER COLUMN item_num smallint NOT NULL
   PRINT '--> COLUMN item_num ON dbo.aud_rc_assign_trade CHANGED TO NOT NULL ...OK '
END

print 'Altering the column ''trade_num'' in the ''aud_rc_assign_trade'' table to be a NON-NULLable column ...'

IF EXISTS (SELECT 1 
           FROM @columns
           WHERE column_name = 'trade_num' and
		         null_flag = 1)
BEGIN
	ALTER TABLE dbo.aud_rc_assign_trade
	   ALTER COLUMN trade_num int NOT NULL
	PRINT '--> COLUMN trade_num ON dbo.aud_rc_assign_trade CHANGED TO NOT NULL ...OK '
END
GO
