ALTER TABLE dbo.mot_location_tariff
DROP COLUMN ppl_tariff_type
GO

ALTER TABLE dbo.mot_location_tariff
DROP COLUMN pto_tariff_amt
GO

ALTER TABLE dbo.mot_location_tariff
DROP COLUMN pla_tariff_amt
GO