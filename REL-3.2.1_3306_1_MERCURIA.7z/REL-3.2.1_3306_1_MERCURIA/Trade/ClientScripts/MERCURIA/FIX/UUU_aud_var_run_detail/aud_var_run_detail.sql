set nocount on

print ' '
print 'Altering the column ''detail_value3'' in the ''aud_var_run_detail'' table to be a NON-NULLable column ...'
go

declare @columns      table
(
    column_id        smallint primary key,
	column_name      sysname not null,
	data_type        sysname not null,
	null_flag        bit default 1
)

insert into @columns
  select * from [dbo].[udf_table_colinfo]('dbo', 'aud_var_run_detail')
  
IF EXISTS (SELECT 1 
           FROM @columns
           WHERE column_name = 'detail_value3' and
		         null_flag = 1)
BEGIN
   ALTER TABLE dbo.aud_var_run_detail
	  ALTER COLUMN detail_value3 datetime NOT NULL
   PRINT '--> COLUMN detail_value3 ON dbo.aud_var_run_detail CHANGED TO NOT NULL ...OK '
END

print 'Altering the column size of the column ''userid'' in the ''aud_var_run_detail'' table to varchar(256) ...'
  
IF EXISTS (SELECT 1
           FROM @columns
           WHERE column_name = 'userid' and
		         data_type <> 'varchar(256)')
BEGIN
   ALTER TABLE dbo.aud_var_run_detail
      ALTER COLUMN userid varchar(256) NOT NULL;
   PRINT 'COLUMN userid ALTERED'
END
GO