print ''
print 'Dropping triggers for the tid_mark_to_market table ...'
go

IF OBJECT_ID('dbo.tid_mark_to_market_deltrg', 'TR') is not null
begin
   exec('drop trigger dbo.tid_mark_to_market_deltrg')
   IF OBJECT_ID('dbo.tid_mark_to_market_deltrg', 'TR') is null
      PRINT '--> Trigger tid_mark_to_market_deltrg on Table tid_mark_to_market removed ...OK'
end
go

IF OBJECT_ID('dbo.tid_mark_to_market_updtrg', 'TR') is not null
begin
   exec('drop trigger dbo.tid_mark_to_market_updtrg')
   IF OBJECT_ID('dbo.tid_mark_to_market_updtrg', 'TR') is null
      PRINT '--> Trigger tid_mark_to_market_updtrg on Table tid_mark_to_market removed ...OK'
end
go
