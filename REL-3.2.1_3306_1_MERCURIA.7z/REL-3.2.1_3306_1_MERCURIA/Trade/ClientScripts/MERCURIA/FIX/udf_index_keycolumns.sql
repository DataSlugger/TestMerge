SET ANSI_NULLS ON
go
SET QUOTED_IDENTIFIER ON
go

IF object_id('dbo.udf_index_keycolumns', 'FN') is not null
   DROP FUNCTION [dbo].[udf_index_keycolumns]
go

CREATE FUNCTION [dbo].[udf_index_keycolumns]
(
   @schema_name    sysname = 'dbo',
   @table_name     sysname,
   @index_name     sysname
)
RETURNS varchar(2000) 
AS
begin
declare @index_id            int,
        @i                   smallint,
        @keys                varchar(800),       /* string to build up index key in */
        @index_type_desc     varchar(60),        /* string to build up index desc in */
        @thiskey             varchar(30),
		@is_descending_key   bit
		
   set @keys = null
   select @index_id = index_id,
          @index_type_desc = type_desc
   from sys.indexes
   where object_id = object_id('dbo.' + @table_name) and
         name = @index_name

   if @index_id is null
      return null
   
   select @i = 1,
          @keys = ''

   while @i <= 31
   begin
      set @thiskey = index_col(@table_name, @index_id, @i)

      if @thiskey is NULL 
         break

      if @i > 1
         set @keys = @keys + ', ' 

      set @keys = @keys + @thiskey
	  
      set @is_descending_key = (select is_descending_key
	                            from sys.index_columns 
					            where object_id = object_id('dbo.' + @table_name) and
					                  index_id = @index_id and
									  index_column_id = @i)
      if (@is_descending_key = 1)
         set @keys = @keys + ' DESC'

      set @i = @i + 1
   end  /* while */

   return @keys
end
go




   


   