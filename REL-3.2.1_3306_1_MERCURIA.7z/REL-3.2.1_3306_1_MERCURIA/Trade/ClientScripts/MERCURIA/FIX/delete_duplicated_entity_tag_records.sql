set nocount on

RAISERROR('Removing duplicated entity_tag records if EXIST ...', 0, 1) with nowait

if object_id('tempdb..#porttags', 'U') is not null
   exec('drop table #porttags')
go

create table #porttags
(
   entity_tag_key      int primary key not null,
   entity_tag_name     varchar(16) not null,
   key1                varchar(16) not null
)
go

insert into #porttags
   (entity_tag_key, entity_tag_name, key1)
select et.entity_tag_key, etd.entity_tag_name, et.key1
from dbo.entity_tag et
        join dbo.entity_tag_definition etd
		   on et.entity_tag_id = etd.oid
		join dbo.icts_entity_name en
		  on etd.entity_id = en.oid
        join (select entity_tag_id, key1
              from dbo.entity_tag
              where entity_tag_id in (select oid
                                      from dbo.entity_tag_definition
                                      where entity_id = (select oid 
                                                         from icts_entity_name 
                                                         where entity_name = 'Portfolio'))
              group by entity_tag_id, key1
              having count(*) > 1) t
			on et.entity_tag_id = t.entity_tag_id and
			   et.key1 = t.key1
order by etd.entity_tag_name, et.key1
go

/*
select * from #porttags
==>
entity_tag_name	 key1	    entity_tag_key	
---------------  ---------  ---------------------
DESK    	     1725634	3625882	
DESK    	     1725634	3625896	
DESK    	     1725636	3625883	
DESK    	     1725636	3625895	
DESK    	     1741564	3625884	
DESK    	     1741564	3625897	
DESK    	     1787171	3555839	
DESK    	     1787171	3625173	
DESK    	     1811749	3625885	
DESK    	     1811749	3625898	
*/

RAISERROR('=> The following query shows the duplicated entity_tag records which can be removed', 0, 1) with nowait

select entity_tag_name,
       key1 as real_port_num,
	   entity_tag_key
from (select entity_tag_name,
             key1,
             entity_tag_key,
             ROW_NUMBER() over (partition by entity_tag_name, key1 order by entity_tag_name, key1, entity_tag_key asc) as row_no
      from #porttags) t
where t.row_no = 1
order by entity_tag_name, key1, entity_tag_key
go

RAISERROR('=> Removing duplicated entity_tag records now ...', 0, 1) with nowait

if object_id('dbo.entity_tag_deltrg', 'TR') is not null
begin
   if OBJECTPROPERTY(object_id('dbo.entity_tag_deltrg'), 'ExecIsTriggerDisabled') = 0
      exec('disable trigger dbo.entity_tag_deltrg on dbo.entity_tag')
end
go

declare @rows_affected    int,
        @smsg             varchar(max),
		@errcode          int
		
begin tran
begin try
  delete dbo.entity_tag 
  where entity_tag_key in (select entity_tag_key
                           from (select entity_tag_name,
                                        key1,
                                        entity_tag_key,
                                        ROW_NUMBER() over (partition by entity_tag_name, key1 order by entity_tag_name, key1, entity_tag_key asc) as row_no
                                 from #porttags) t
                           where t.row_no = 1)
  set @rows_affected = @@rowcount
end try
begin catch
  set @errcode = ERROR_NUMBER()
  set @smsg = ERROR_MESSAGE()
  if @@trancount > 0
     rollback tran
  RAISERROR('=> Failed to delete duplicated entity_tag records due to the error below:', 0, 1) with nowait
  RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
  goto errexit
end catch
commit tran
RAISERROR('=> %d duplicated entity_tag records were removed!', 0, 1, @rows_affected) with nowait

errexit:
RAISERROR(' ', 0, 1) with nowait
if object_id('dbo.entity_tag_deltrg', 'TR') is not null
begin
   if OBJECTPROPERTY(object_id('dbo.entity_tag_deltrg'), 'ExecIsTriggerDisabled') = 1
      exec('enable trigger dbo.entity_tag_deltrg on dbo.entity_tag')
end
go

if object_id('tempdb..#porttags', 'U') is not null
   exec('drop table #porttags')
go
