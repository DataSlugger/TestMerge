set nocount on

print ''
print 'Dropping index aud_allocation_transfer_idx1 if exists and it is not on ''trans_id'' column ...'
go

declare @index_cols    varchar(800)

if exists (select 1
           from sys.indexes
		   where object_id = object_id('dbo.aud_allocation_transfer') and
		         name = 'aud_allocation_transfer_idx1')
begin
   set @index_cols = (select [dbo].[udf_index_keycolumns]('dbo', 'aud_allocation_transfer', 'aud_allocation_transfer_idx1'))
   if @index_cols is null
   begin
      RAISERROR('=> Failed to obtain column list for index ''aud_allocation_transfer_idx1''???', 0, 1) with nowait
      goto endofscript
   end

   if @index_cols like '%source_inv_num%'
      exec('DROP INDEX aud_allocation_transfer_idx1 ON dbo.aud_allocation_transfer')
end

endofscript:
GO