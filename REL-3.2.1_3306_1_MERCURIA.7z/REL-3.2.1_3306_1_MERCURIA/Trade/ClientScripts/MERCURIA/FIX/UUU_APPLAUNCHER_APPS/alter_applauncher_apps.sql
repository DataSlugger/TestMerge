set nocount on

SET ANSI_WARNINGS OFF;
go

print ' '
print 'Altering the column size of the column ''link_invoke'' in the ''APPLAUNCHER_APPS'' table to nvarchar(50) ...'
go

declare @columns      table
(
    column_id        smallint primary key,
	column_name      sysname not null,
	data_type        sysname not null,
	null_flag        bit default 1
)

insert into @columns
  select * from [dbo].[udf_table_colinfo]('dbo', 'APPLAUNCHER_APPS')
  

IF EXISTS (SELECT 1
           FROM @columns
           WHERE column_name = 'link_invoke' and
		         data_type <> 'nvarchar(50)')
    BEGIN
      ALTER TABLE dbo.APPLAUNCHER_APPS
        ALTER COLUMN link_invoke nvarchar(50) NULL;
      PRINT 'COLUMN link_invoke ALTERED'
    END
GO

SET ANSI_WARNINGS ON;
go