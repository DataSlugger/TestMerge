print ''
print 'Dropping triggers which do not follow the standard naming convention ...'
go

if object_id('dbo.var_component_del', 'TR') is not null
   exec('drop trigger dbo.var_component_del')
go

if object_id('dbo.var_ext_position_del', 'TR') is not null
   exec('drop trigger dbo.var_ext_position_del')
go

if object_id('dbo.var_limit_del', 'TR') is not null
   exec('drop trigger dbo.var_limit_del')
go

if object_id('dbo.var_run_detail_del', 'TR') is not null
   exec('drop trigger dbo.var_run_detail_del')
go

/* ********************************************************************** */

if object_id('dbo.var_component_ins', 'TR') is not null
   exec('drop trigger dbo.var_component_ins')
go

if object_id('dbo.var_ext_position_ins', 'TR') is not null
   exec('drop trigger dbo.var_ext_position_ins')
go

if object_id('dbo.var_limit_ins', 'TR') is not null
   exec('drop trigger dbo.var_limit_ins')
go

if object_id('dbo.var_run_detail_ins', 'TR') is not null
   exec('drop trigger dbo.var_run_detail_ins')
go

/* ********************************************************************** */
 
if object_id('dbo.var_component_upd', 'TR') is not null
   exec('drop trigger dbo.var_component_upd')
go

if object_id('dbo.var_ext_position_upd', 'TR') is not null
   exec('drop trigger dbo.var_ext_position_upd')
go

if object_id('dbo.var_limit_upd', 'TR') is not null
   exec('drop trigger dbo.var_limit_upd')
go

if object_id('dbo.var_run_detail_upd', 'TR') is not null
   exec('drop trigger dbo.var_run_detail_upd')
go
