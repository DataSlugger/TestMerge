print ' '
print 'Creating a new index to speed up queries using portfolio_tag indexed view (MERCO-8310) ...'
go

IF NOT EXISTS (SELECT 1 
               FROM sys.indexes
               WHERE object_id = OBJECT_ID('dbo.portfolio') AND
                     name = 'portfolio_idx2' and
                     index_id > 0 and index_id < 255)			
   CREATE NONCLUSTERED INDEX [portfolio_idx2] 
      ON [dbo].[portfolio]([port_num],[port_type])
         INCLUDE ([trading_entity_num])
go