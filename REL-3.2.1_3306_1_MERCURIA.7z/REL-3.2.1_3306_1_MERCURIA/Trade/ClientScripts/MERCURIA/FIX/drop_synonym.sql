print ''
print 'Dropping ''dbo.lc_ext_info'' SYNONYM if exists ...'
go

IF OBJECT_ID('dbo.lc_ext_info', 'SN') IS NOT NULL
BEGIN
	DROP SYNONYM dbo.lc_ext_info
	PRINT 'SYNONYM dbo.lc_ext_info DROPPED';
END
GO
