/* ------------------------------------------------------------------
   The following USA cost codes are added for FuelQuest integration
   ------------------------------------------------------------------ */

set nocount on

print ' '
print 'Loading cost codes (USA) for FuelQuest integration into the commodity table ...'
go

create table #cost_codes
(
   cmdty_code         char(8),
   cmdty_short_desc   char(15),
   cmdty_long_desc    varchar(40)
)

insert into #cost_codes values('A2',       'STSALESTAXDISCX', 'ST TAX DISCOUNT - CONSUMER SALES TAX')
insert into #cost_codes values('A2D',      'DFUELTAXDISCLCL', 'ST TAX DISCOUNT - DIESEL FUEL LCL OPT')
insert into #cost_codes values('A2G',      'GASTAXDISCLCLXX', 'ST TAX DISCOUNT - GASOLINE LCL OPT')
insert into #cost_codes values('AD',       'DIESELSTTAXDISC', 'ST TAX DISCOUNT - DIESEL')
insert into #cost_codes values('ADR',      'DFUELRETAILDISC', 'ST TAX DISCOUNT - DIESEL FUEL RETAIL')
insert into #cost_codes values('ADW',      'DFUELWHOLESALER', 'ST TAX DISCOUNT - DIESEL FUEL WHOLESALER')
insert into #cost_codes values('AE',       'ETHANOLTAXDISCX', 'ST TAX DISCOUNT - ETHANOL')
insert into #cost_codes values('AEP',      'ENVFEESTTAXDISC', 'ST TAX DISCOUNT - ENVIRONMENTAL FEE')
insert into #cost_codes values('AEXG1',    'GAS1/3TAXDISCAE', 'ST TAX DISCOUNT - GASOLINE ONE-THIRD')
insert into #cost_codes values('AEXG2',    'GAS2/3TAXDISCAE', 'ST TAX DISCOUNT - GASOLINE TWO-THIRDS')
insert into #cost_codes values('AEXG3',    'GAS1/2TAXDISCAE', 'ST TAX DISCOUNT - GASOLINE ONE-HALF')
insert into #cost_codes values('AEXGX',    'GASSTTAXDISCAEX', 'ST TAX DISCOUNT - GASOLINE')
insert into #cost_codes values('AG',       'GASSTTAXDISCAGX', 'ST TAX DISCOUNT - GASOLINE')
insert into #cost_codes values('AG1',      'GAS1/3TAXDISCAG', 'ST TAX DISCOUNT - GASOLINE ONE-THIRD')
insert into #cost_codes values('AG2',      'GAS2/3TAXDISCAG', 'ST TAX DISCOUNT - GASOLINE TWO-THIRDS')
insert into #cost_codes values('AG3',      'GAS1/2TAXDISCAE', 'ST TAX DISCOUNT - GASOLINE ONE-HALF')
insert into #cost_codes values('AGR',      'GASRETTAXDISCAE', 'ST TAX DISCOUNT - GASOLINE RETAIL')
insert into #cost_codes values('AGW',      'GASWHOTAXDISCAE', 'ST TAX DISCOUNT - GASOLINE WHOLESALER')
insert into #cost_codes values('AGX',      'GASSTTAXDISCAGX', 'ST TAX DISCOUNT - GASOLINE')
insert into #cost_codes values('AH2',      'GASOHTAXDISCAGH', 'ST TAX DISCOUNT - GASOHOL')
insert into #cost_codes values('AH1',      'GAS10PCTTAXDISC', 'ST TAX DISCOUNT - GASOHOL 10 PCT')
insert into #cost_codes values('AH5',      'GAS5-7TAXDISCAH', 'ST TAX DISCOUNT - GASOHOL 5.7 PCT')
insert into #cost_codes values('AH7',      'GAS7-7TAXDISCAH', 'ST TAX DISCOUNT - GASOHOL 7.7 PCT')
insert into #cost_codes values('AJ',       'JFUELTAXDISCAJX', 'ST TAX DISCOUNT - JET FUEL')
insert into #cost_codes values('AMF',      'STTAXDISCAMFXXX', 'ST TAX DISCOUNT')
insert into #cost_codes values('AMFSL',    'SHIPTRAINDISCXX', 'ST TAX DISCOUNT - SHIP/TRAIN')
insert into #cost_codes values('ARG',      'GASRETTAXDISCAR', 'ST TAX DISCOUNT - GASOLINE RETAIL')
insert into #cost_codes values('AUST',     'USTFEETAXDISCAU', 'ST TAX DISCOUNT -  UST FEE')
insert into #cost_codes values('BS2G',     'GASMTRFUELEXTAX', 'MTR FUEL EXC TAX - GASOLINE')
insert into #cost_codes values('BSAJ',     'JETMTRFUELEXTAX', 'MTR FUEL EXC TAX - JET')
insert into #cost_codes values('BSD',      'DIEMTRFUELEXTAX', 'MTR FUEL EXC TAX - DIESEL')
insert into #cost_codes values('BSEP',     'MDOILXFERFEEBSE', 'MD OIL TRANSFER FEE')
insert into #cost_codes values('BSEPCISO', 'SURFACEOILFEEBS', 'ST COASTAL/INLAND SURFACE OIL FEE')
insert into #cost_codes values('BSEPCP',   'STENVCOASTALPRO', 'ST ENVIRONMENTAL - COASTAL PROTECTION')
insert into #cost_codes values('BSEPGW6',  'GRDWATEROILFEE6', 'ST GROUND WATER OIL FEE - #6')
insert into #cost_codes values('BSEPGWG',  'GRDWATEROILFEEG', 'ST GROUND WATER OIL FEE - GASOLINE')
insert into #cost_codes values('BSEPGWS',  'GRDWATEROILFEES', 'ST GROUND WATER OIL FEE - DSL,KER')
insert into #cost_codes values('BSEPOD',   'OILDISPOSEFEEOD', 'ST OIL DISCHARGE/DISPOSAL FEE')
insert into #cost_codes values('BSEPOD1',  'OILDISPOSEFEED1', 'ST OIL DISCHARGE/DISPOSAL FEE')
insert into #cost_codes values('BSEPOPC',  'OILPOLLUCTLFEEC', 'ST OIL POLLUTION CONTROL FEE')
insert into #cost_codes values('BSEPWQ',   'ENVWATERQUALITY', 'ST ENVIRONMENTAL - WATER QUALITY')
insert into #cost_codes values('BSG',      'GASMTRFUELEXBSG', 'MTR FUEL EXC TAX - GASOLINE')
insert into #cost_codes values('BSGR',     'GROSSRECTAXBSGR', 'ST GROSS RECEIPTS TAX')
insert into #cost_codes values('BSIF',     'STINSPFEEBSIFXX', 'ST INSPECTION FEE')
insert into #cost_codes values('BSPBD',    'STPETRBUSTAXDIE', 'ST PETR BUS TAX - DIESEL')
insert into #cost_codes values('BSPBG',    'STPETROBUSTAX',   'STATE PETROLEUM BUSINESS TAX')
insert into #cost_codes values('BSPSTD1',  'D1PREPAIDSALTAX', 'PREPAID SALES TAX - DIESEL REG 1')
insert into #cost_codes values('BSPSTD2',  'D2PREPAIDSALTAX', 'PREPAID SALES TAX - DIESEL REG 2')
insert into #cost_codes values('BSPSTG1',  'G1PREPAIDSALTAX', 'PREPAID SALES TAX-GASOLINE REG 1')
insert into #cost_codes values('BSPSTG2',  'G2PREPAIDSALTAX', 'PREPAID SALES TAX-GASOLINE REG 2')
insert into #cost_codes values('BSRPT',    'RESIPETROLTAXPT', 'ST RESIDUAL PETROLEUM TAX')
insert into #cost_codes values('BSRPT2',   'RESIPETROLTAX2T', 'ST RESIDUAL PETROLEUM TAX- NO 2 OIL')
insert into #cost_codes values('BSUST',    'STUSTFEEXXXXXXX', 'ST UST FEE')
insert into #cost_codes values('CIMF',     'CMOTORFUELTAXMF', 'CITY MOTOR FUEL TAX')
insert into #cost_codes values('CIMFD',    'CMOTORFUELTAXDI', 'CITY MOTOR FUEL TAX - DIESEL')
insert into #cost_codes values('CIMFG',    'CMOTORFUELTAXGA', 'CITY MOTOR FUEL TAX - GASOLINE')
insert into #cost_codes values('CIPJD',    'PLCEJURIMFTAXDI', 'POLICE JURISDICTION MF TAX - DIESEL')
insert into #cost_codes values('CIPJG',    'PLCEJURIMFTAXGA', 'POLICE JURISDICTION MF TAX - GASOLINE')
insert into #cost_codes values('CIS',      'CITYSALESTAXCIS', 'CITY SALES TAX')
insert into #cost_codes values('COA',      'CNTYAVIATGASTAX', 'COUNTY AVIATION GASOLINE TAX')
insert into #cost_codes values('COJ',      'CNTYJETFUELTAXJ', 'COUNTY JET FUEL TAX')
insert into #cost_codes values('COMF',     'CNTYMTRFUELTAXF', 'COUNTY MOTOR FUEL TAX')
insert into #cost_codes values('COMFD',    'CNTYMTRFUELTAXD', 'COUNTY MOTOR FUEL TAX - DIESEL FUEL')
insert into #cost_codes values('COMFG',    'CNTYMTRFUELTAXG', 'COUNTY MOTOR FUEL TAX - GASOLINE')
insert into #cost_codes values('COMFI',    'CNTMTRFUELIXTAX', 'COUNTY MOTOR FUEL INDEXED TAX')
insert into #cost_codes values('COS',      'COUNTYSALESTAXS', 'COUNTY SALES TAX')
insert into #cost_codes values('EXC',      'EXCISEDUTYEXCXX', 'EXCISE DUTY')
insert into #cost_codes values('FA',       'FEDEXCTAXAVGAS',  'FED EXC TAX - AVGAS')
insert into #cost_codes values('FBE1',     'GAS10PCTETHGHL',  'FED EXC TAX - GASOLINE 10 PCT ETH GHL BLD')
insert into #cost_codes values('FBE5',     'GAS5/7PCTETHGHL', 'FED EXC TAX - GASOLINE 5.7 PCT ETH GHL BLD')
insert into #cost_codes values('FBE7',     'GAS7/7PCTETHGHL', 'FED EXC TAX - GASOLINE 7.7 PCT ETH GHL BLD')
insert into #cost_codes values('FBM1',     'GAS10PCTMTHGHL',  'FED EXC TAX - GASOLINE 10 PCT MTH GHL BLD')
insert into #cost_codes values('FBM5',     'GAS5/7PCTMTHGHL', 'FED EXC TAX - GASOLINE 5.7 PCT MTH GHL BLD')
insert into #cost_codes values('FBM7',     'GAS7/7PCTMTHGHL', 'FED EXC TAX - GASOLINE 7.7 PCT MTH GHL BLD')
insert into #cost_codes values('FBUT',     'FEDEXCTAXBUTANE', 'FED EXC TAX - BUTANE')
insert into #cost_codes values('FD',       'FEDEXCTAXDIESEL', 'FED EXC TAX - DIESEL FUEL')
insert into #cost_codes values('FDDB',     'FEXCTAXDYEDDIBU', 'FED EXC TAX - DYED DIESEL BUS')
insert into #cost_codes values('FDDT',     'FEXCTAXDYEDDITR', 'FED EXC TAX - DYED DIESEL TRAIN')
insert into #cost_codes values('FE',       'FEDEXCTAXETHANO', 'FED EXC TAX - ETHANOL')
insert into #cost_codes values('FE1',      'GASOHOL10PCTETH', 'FED EXC TAX - GASOHOL 10 PCT ETH')
insert into #cost_codes values('FE5',      'GASOHO5/7PCTETH', 'FED EXC TAX - GASOHOL 5.7 PCT ETH')
insert into #cost_codes values('FE7',      'GASOHO7/7PCTETH', 'FED EXC TAX - GASOHOL 7.7 PCT ETH')
insert into #cost_codes values('FE85',     'FEDEXCTAXE85XXX', 'FED EXC TAX - E85')
insert into #cost_codes values('FEBC1',    'FETHABLDCR10PCT', 'FED ETHANOL BLEND CREDIT - 10 PCT')
insert into #cost_codes values('FEBC5',    'FETHABLDCR5/7PC', 'FED ETHANOL BLEND CREDIT - 5.7 PCT')
insert into #cost_codes values('FEBC7',    'FETHABLDCR7/7PC', 'FED ETHANOL BLEND CREDIT - 7.7 PCT')
insert into #cost_codes values('FG',       'FEDEXCTAXGASOLI', 'FED EXC TAX - GASOLINE')
insert into #cost_codes values('FJC',      'FEXCTAXJETFUECM', 'FED EXC TAX - JET FUEL COMMERCIAL')
insert into #cost_codes values('FJN',      'FEXCTAXJETFUENC', 'FED EXC TAX - JET FUEL NON-COMMERCIAL')
insert into #cost_codes values('FK',       'FEDEXCTAXKEROSE', 'FED EXC TAX - KEROSENE')
insert into #cost_codes values('FM1',      'FEXTAXGASO10PCM', 'FED EXC TAX - GASOHOL 10 PCT MTH')
insert into #cost_codes values('FM5',      'FEXTAXGASO5/7PM', 'FED EXC TAX - GASOHOL 5.7 PCT MTH')
insert into #cost_codes values('FM7',      'FEXTAXGASO7/7PM', 'FED EXC TAX - GASOHOL 7.7 PCT MTH')
insert into #cost_codes values('FM85',     'FEXTAXGASO7/7PM', 'FED EXC TAX - M85')
insert into #cost_codes values('GST',      'GOODSSERVICETAX', 'GOODS - SERVICES TAX')
insert into #cost_codes values('S2AF',     'STAVIATIFUEL2AF', 'ST AVIATION FUEL TAX')
insert into #cost_codes values('S2D',      'STDIESELFUELTAX', 'ST DIESEL FUEL TAX')
insert into #cost_codes values('S2EF',     'STEXPORTTAXNJOI', 'ST EXPORT TAX - NJ OIL SPILL FEE')
insert into #cost_codes values('S2EP',     'STOILSPILLFEEEP', 'ST OIL SPILL FEE')
insert into #cost_codes values('S2G',      'STGASOLINETAX2G', 'ST GASOLINE TAX')
insert into #cost_codes values('S2RST',    'STSALESTAX2RST',  'ST SALES TAX')
insert into #cost_codes values('SAF',      'STAVIATIFUELSAF', 'ST AVIATION FUEL TAX')
insert into #cost_codes values('SAFF',     'STAVFUELTAXFEDC', 'ST AVIATION FUEL TAX - FED CERT')
insert into #cost_codes values('SAFN',     'STAVFUELTAXNONF', 'ST AVIATION FUEL TAX - NON-FED CERT')
insert into #cost_codes values('SAG',      'STAVGASOLTAXSAG', 'ST AVIATION GASOLINE TAX')
insert into #cost_codes values('SAG85',    'STAVGASOLISAG85', 'ST AVIATION GASOLINE TAX - 85 PCT ALC')
insert into #cost_codes values('SAJ',      'STJETFUELTAXSAJ', 'ST JET FUEL TAX')
insert into #cost_codes values('SAJPC',    'STJETFUELTAXJPC', 'ST JET FUEL TAX - PRIVATE/COMMERCIAL')
insert into #cost_codes values('SBZLA',    'LABORDERZONETAX', 'LA BORDER ZONE TAX')
insert into #cost_codes values('SBZMO',    'MOBORDERZONETAX', 'MO BORDER ZONE TAX')
insert into #cost_codes values('SBZMS',    'MSBORDERZONETAX', 'MS BORDER ZONE TAX')
insert into #cost_codes values('SBZOK',    'OKBORDERZONETAX', 'OK BORDER ZONE TAX')
insert into #cost_codes values('SBZTN',    'TNBORDERZONETAX', 'TN BORDER ZONE TAX')
insert into #cost_codes values('SBZTX',    'TXBORDERZONETAX', 'TX BORDER ZONE TAX')
insert into #cost_codes values('SCLPP01',  'STLEADPOISONSCF', 'ST LEAD POISON - SC FUELS')
insert into #cost_codes values('SCLPP02',  'STLEADPOISONPET', 'ST LEAD POISON - PETRO DIAMOND')
insert into #cost_codes values('SCLPP03',  'STLEADPOISONSHE', 'ST LEAD POISON - SHELL')
insert into #cost_codes values('SCLPP04',  'STLEADPOISONCHE', 'ST LEAD POISON - CHEVRON')
insert into #cost_codes values('SD',       'STDIESELFUELSDX', 'ST DIESEL FUEL TAX')
insert into #cost_codes values('SDD',      'STSPFUELEXCITAX', 'ST SPECIAL FUEL EXCISE TAX')
insert into #cost_codes values('SDDSL',    'STDYEDDIESELDSL', 'ST DYED DIESEL TAX - ST AND LCL GOVT')
insert into #cost_codes values('SDGVT',    'STDIESELFUELGVT', 'ST DIESEL FUEL TAX - GOVT RATE')
insert into #cost_codes values('SDM',      'STDIESELFUELSDM', 'ST DIESEL FUEL TAX - MARINE')
insert into #cost_codes values('SE',       'STGASOHOLTAXETH', 'ST GASOHOL TAX - ETHANOL')
insert into #cost_codes values('SEF',      'STEXPORTTAXTNSP', 'ST EXPORT TAX - TN SPECIAL TAX')
insert into #cost_codes values('SEFAF',    'STEXPORTTAXMDAV', 'ST EXPORT TAX - MD AVIATION FUEL TAX')
insert into #cost_codes values('SEFAG',    'STEXPORTTAXAZAV', 'ST EXPORT TAX - AZ AVGAS TAX')
insert into #cost_codes values('SEFAJ',    'STEXPORTTAXAZJE', 'ST EXPORT TAX - AZ JET FUEL TAX')
insert into #cost_codes values('SEFD',     'STEXPORTTAXAZDI', 'ST EXPORT TAX - AZ DIESEL FUEL TAX')
insert into #cost_codes values('SEFENV',   'STEXPORTTAXNVEN', 'ST EXPORT TAX - NV ENV FEE')
insert into #cost_codes values('SEFEP',    'STEXPORTTAXMDEN', 'ST EXPORT TAX - MD ENVIRONMENTAL FEE')
insert into #cost_codes values('SEFG',     'STEXPORTTAXAZGA', 'ST EXPORT TAX - AZ GASOLINE TAX')
insert into #cost_codes values('SEFINS',   'STEXPORTTAXNVIN', 'ST EXPORT TAX - NV INS FEE')
insert into #cost_codes values('SENVE',    'STENVIRFEEETHAN', 'ST ENVIRONMENTAL FEE - ETHANOL')
insert into #cost_codes values('SEP',      'STENVIRFEEXXSEP', 'ST ENVIRONMENTAL FEE')
insert into #cost_codes values('SEP2D',    'STENVIRFEEDIESE', 'ST ENVIRONMENTAL FEE - DIESEL FUEL')
insert into #cost_codes values('SEP2G',    'STENVIRFEEGASOL', 'ST ENVIRONMENTAL FEE - GASOLINE')
insert into #cost_codes values('SEPCISO',  'STCOASTALINLAND', 'ST COASTAL/INLAND SURFACE OIL FEE')
insert into #cost_codes values('SEPCP',    'STENVIRCOASTALP', 'ST ENVIRONMENTAL - COASTAL PROTECTION')
insert into #cost_codes values('SEPD',     'STENVIRFEEDFUEL', 'ST ENVIRONMENTAL FEE - DIESEL FUEL')
insert into #cost_codes values('SEPG',     'STENVIRFEEGASPG', 'ST ENVIRONMENTAL FEE - GASOLINE')
insert into #cost_codes values('SEPGWD',   'GWATEROILFEEDIE', 'ST GROUND WATER OIL FEE - DIESEL FUEL')
insert into #cost_codes values('SEPGWDD',  'GWATEROILFEEDYE', 'ST GROUND WATER OIL FEE - DYED DIESEL')
insert into #cost_codes values('SEPGWG',   'GWATEROILFEEGAS', 'ST GROUND WATER OIL FEE - GASOLINE')
insert into #cost_codes values('SEPHO',    'HEATINGOILINSFE', 'ST HEATING OIL INSURANCE FEE')
insert into #cost_codes values('SEPIP',    'STENVIRINLANDPR', 'ST ENVIRONMENTAL - INLAND PROTECTION')
insert into #cost_codes values('SEPOD',    'OILDISPOSALFEEO', 'ST OIL DISCHARGE/DISPOSAL FEE')
insert into #cost_codes values('SEPODF',   'OILDISPOSALFEEF', 'ST OIL DISCHARGE/DISPOSAL FEE - FUEL OIL')
insert into #cost_codes values('SEPOPC',   'OILPOLLUCTRLFEE', 'ST OIL POLLUTION CONTROL FEE')
insert into #cost_codes values('SEPWQ',    'STENVIRONMENTWQ', 'ST ENVIRONMENTAL - WATER QUALITY')
insert into #cost_codes values('SEPWQL',   'STENVIRONMENWQL', 'ST ENVIRONMENTAL - WATER QUALITY LUBES')
insert into #cost_codes values('SG',       'STGASOLINETAXSG', 'ST GASOLINE TAX')
insert into #cost_codes values('SGGVT',    'STGASTAXGOVTRAT', 'ST GASOLINE TAX - GOVT RATE')
insert into #cost_codes values('SGM',      'STGASTAXMARINEX', 'ST GASOLINE TAX - MARINE')
insert into #cost_codes values('SGML',     'STGASMINLOCALOP', 'ST GASOLINE MIN LOCAL OPTION TAX')
insert into #cost_codes values('SGR',      'GROSRECEIPTSTAX', 'ST GROSS RECEIPTS TAX')
insert into #cost_codes values('SGRR',     'GENEXCISETAXRET', 'ST GENERAL EXCISE TAX - RETAIL')
insert into #cost_codes values('SGRW',     'GENEXCISETAXWHL', 'ST GENERAL EXCISE TAX - WHOLESALE')
insert into #cost_codes values('SH',       'STGASOHOLTAXXSH', 'ST GASOHOL TAX')
insert into #cost_codes values('SH1',      'STGASOTAX10PCTA', 'ST GASOHOL TAX - 10 PCT ALC')
insert into #cost_codes values('SH5',      'STGASOTAX5/7PCT', 'ST GASOHOL TAX - 5.7 PCT ALC')
insert into #cost_codes values('SH7',      'STGASOTAX7/7PCT', 'ST GASOHOL TAX - 7.7 PCT ALC')
insert into #cost_codes values('SH85',     'STGASOTAX85PCTA', 'ST GASOHOL TAX - 85 PCT ALC')
insert into #cost_codes values('SHAW',     'STGASOTAXANCHOR', 'ST GASOHOL TAX - ANCHORAGE WINTER')
insert into #cost_codes values('SHST',     'STHAZSUBTAXSHST', 'ST HAZARDOUS SUBSTANCE TAX')
insert into #cost_codes values('SIF',      'STINSPFEEXXXSIF', 'ST INSPECTION FEE')
insert into #cost_codes values('SIFD',     'STINSPFEEXXSIFD', 'ST INSPECTION FEE - DIESEL FUEL')
insert into #cost_codes values('SIFG',     'STINSPFEEXXSIFG', 'ST INSPECTION FEE - GASOLINE')
insert into #cost_codes values('SIFL',     'STINSPFEEXXSIFL', 'ST INSPECTION FEE - LUBES')
insert into #cost_codes values('SIFSRB',   'STINSPFEESIFSRB', 'ST INSPECTION FEE - SHIP/RAILROAD/BOAT')
insert into #cost_codes values('SIK',      'STINSPFEEXXXSIK', 'ST INSPECTION FEE - KEROSENE')
insert into #cost_codes values('SINS2',    'STINSPFEEXSINS2', 'ST INSPECTION FEE')
insert into #cost_codes values('SINSE',    'STINSPFEEXSINSE', 'ST INSPECTION FEE - ETHANOL')
insert into #cost_codes values('SK',       'SPFUELEXCITAXKE', 'ST SPECIAL FUEL EXCISE TAX - KEROSENE')
insert into #cost_codes values('SL',       'STLUBEOILTAXXSL', 'ST LUBE OIL TAX')
insert into #cost_codes values('SMF2',     'STADDILICTAXMF2', 'ST ADDITIONAL LICENSE TAX')
insert into #cost_codes values('SMF2F',    'STADDILICTAMF2F', 'ST ADDITIONAL LICENSE TAX - FARMING')
insert into #cost_codes values('SMFF',     'STFUELTAXXXFARM', 'ST FUEL TAX - FARMING')
insert into #cost_codes values('SOFD',     'OILFRANCTAXDIEF', 'ST OIL FRANCHISE TAX - DIESEL FUEL')
insert into #cost_codes values('SOFG',     'OILFRANCTAXGASO', 'ST OIL FRANCHISE TAX - GASOLINE')
insert into #cost_codes values('SPB',      'STPOOLBONDFEEXX', 'ST POOL BOND FEE')
insert into #cost_codes values('SPBAR',    'STPETRBUSTAXAVG', 'ST PETR BUS TAX - AVGAS RETAIL')
insert into #cost_codes values('SPBD',     'STPETRBUSTAXDIE', 'ST PETR BUS TAX - DIESEL')
insert into #cost_codes values('SPBDCU',   'STPETRBUSTAXDCO', 'ST PETR BUS TAX - DIESEL COMMERCIAL USE')
insert into #cost_codes values('SPBDEC',   'STPETRBUSTAXDEC', 'ST PETR BUS TAX - DIESEL ELECTRIC CORP')
insert into #cost_codes values('SPBDHC',   'STPETRBUSTAXDNR', 'ST PETR BUS TAX - DIESEL NON-RES HEAT/COOL')
insert into #cost_codes values('SPBDRR',   'STPETRBUSTAXDRA', 'ST PETR BUS TAX - DIESEL RAILROAD')
insert into #cost_codes values('SPBG',     'STPETRBUSTAXGAS', 'ST PETR BUS TAX - GASOLINE')
insert into #cost_codes values('SPPDF1',   'STDELIVFEEXPDF1', 'ST DELIVERY FEE 1')
insert into #cost_codes values('SPPDF2',   'STDELIVFEEXPDF2', 'ST DELIVERY FEE 2')
insert into #cost_codes values('SPPDF3',   'STDELIVFEEXPDF3', 'ST DELIVERY FEE 3')
insert into #cost_codes values('SPPDF4',   'STDELIVFEEXPDF4', 'ST DELIVERY FEE 4')
insert into #cost_codes values('SPPDFA',   'STDELIVFEEXPDFA', 'ST DELIVERY FEE A')
insert into #cost_codes values('SPST',     'PREPAIDSALETAXT', 'ST PREPAID SALES TAX')
insert into #cost_codes values('SPSTD',    'PREPAIDSALTAXDF', 'ST PREPAID SALES TAX - DIESEL FUEL')
insert into #cost_codes values('SPSTD1',   'PREPAIDSALTAXD1', 'ST PREPAID SALES TAX - DIESEL FUEL REG 1')
insert into #cost_codes values('SPSTD2',   'PREPAIDSALTAXD2', 'ST PREPAID SALES TAX - DIESEL FUEL REG 2')
insert into #cost_codes values('SPSTG',    'PREPAIDSALETAXG', 'ST PREPAID SALES TAX - GASOLINE')
insert into #cost_codes values('SPSTG1',   'PREPAIDSATAXDG1', 'ST PREPAID SALES TAX - GASOLINE REG 1')
insert into #cost_codes values('SPSTG2',   'PREPAIDSATAXDG2', 'ST PREPAID SALES TAX - GASOLINE REG 2')
insert into #cost_codes values('SPSTH',    'PREPAIDSTAXGASX', 'ST PREPAID SALES TAX - GASOHOL')
insert into #cost_codes values('SPSTJ',    'PREPAIDSTAXJETF', 'ST PREPAID SALES TAX - JET FUEL')
insert into #cost_codes values('SRST',     'STSALESTAXXSRST', 'ST SALES TAX')
insert into #cost_codes values('SRSTH',    'STSALESTAXGASOH', 'ST SALES TAX - GASOHOL')
insert into #cost_codes values('SST',      'CONSUMERSALETAX', 'ST CONSUMER SALES TAX')
insert into #cost_codes values('SUST',     'STUSTFEEXXXSUST', 'ST UST FEE')
insert into #cost_codes values('SUSTE',    'STUSTFEEETHANOL', 'ST UST FEE - ETHANOL')

declare @cmdty_code        char(8),
        @cmdty_short_desc  char(15),
        @cmdty_long_desc   varchar(40),
        @smsg              varchar(255),
        @errcode           int,
        @pl_implication    varchar(20)
        
select @errcode = 0,
       @pl_implication = 'NO_EFFECT'   /* for Sempra only, for others, use 'OPEN' */
        
select @cmdty_code = min(cmdty_code)
from #cost_codes

while @cmdty_code is not null
begin
   select @cmdty_short_desc = cmdty_short_desc,
          @cmdty_long_desc = cmdty_long_desc
   from #cost_codes
   where cmdty_code = @cmdty_code
   
   if exists (select 1
              from dbo.commodity 
              where cmdty_code = @cmdty_code)
   begin          
      if not exists (select 1
                     from dbo.commodity 
                     where cmdty_code = @cmdty_code and
                           cmdty_short_name = @cmdty_short_desc)
      begin
         select @smsg = 'The cmdty_code ''' + @cmdty_code + ''' (''' + @cmdty_short_desc + ''') exists, but with different cmdty_short_name!'
         print @smsg
         select cmdty_short_name from dbo.commodity where cmdty_code = @cmdty_code
      end
   end
   else
   begin   
      begin tran       
      insert into commodity  
         (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
          cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
          prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, 
          cmdty_category_code, trans_id)
       values(@cmdty_code, 'N', 'O', 'A', @cmdty_short_desc, @cmdty_long_desc, 
               NULL, NULL, NULL, NULL, 'UNIT', NULL, NULL, 1)
      select @errcode = @@error
      if @errcode > 0
      begin
         rollback tran
         select @smsg = 'Failed to add the cmdty_code ''' + @cmdty_code + ''' into the commodity table!'
         print @smsg
         goto endofscript
      end
      else
      begin
         if NOT exists (select 1
                        from dbo.cost_code 
                        where cost_code = @cmdty_code)
         begin
            insert into cost_code 
               (cost_code, cost_code_desc, cost_code_type_ind, 
                cost_code_order_num, pl_implication, trans_id)
             values(@cmdty_code, @cmdty_long_desc, 'M', NULL, @pl_implication, 1)
            select @errcode = @@error
            if @errcode > 0
            begin
               rollback tran
               select @smsg = 'Failed to add the cost_code ''' + @cmdty_code + ''' into the cost_code table!'
               print @smsg
               goto endofscript
            end
            else
            begin               
               commit tran
               select @smsg = 'The cost_code ''' + @cmdty_code + ''' was added into the commodity table and the cost_code table!'
               print @smsg
            end
         end
         else
         begin
            commit tran
            select @smsg = 'The cost_code ''' + @cmdty_code + ''' was added into the commodity table!'
            print @smsg
         end
      end
   end
   
   select @cmdty_code = min(cmdty_code)
   from #cost_codes
   where cmdty_code > @cmdty_code
end
endofscript:
drop table #cost_codes
go


