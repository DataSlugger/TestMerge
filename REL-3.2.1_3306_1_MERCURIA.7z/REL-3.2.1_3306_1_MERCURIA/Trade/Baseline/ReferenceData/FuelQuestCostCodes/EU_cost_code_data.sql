/* ---------------------------------------------------------------------
   The following EUROPEAN cost codes are added for FuelQuest integration
   --------------------------------------------------------------------- */

set nocount on

print ' '
print 'Loading cost codes (EU) for FuelQuest integration into the commodity table ...'
go

create table #cost_codes
(
   cmdty_code         char(8),
   cmdty_short_desc   char(15),
   cmdty_long_desc    varchar(40)
)

insert into #cost_codes values('EBV',      'EBVTAXEUXXXXXXX', 'EBV TAX')
insert into #cost_codes values('EBV-FO',   'EBVTAXFOXXXXXXX', 'EBV TAX')
insert into #cost_codes values('EXC',      'EXCISEDUTYEXCXX', 'EXCISE DUTY')
insert into #cost_codes values('EXC1',     'EXCISEDUTYLSFOX', 'EXCISE DUTY-LSFO')
insert into #cost_codes values('EXC-SUPP', 'SUPPOEXCISEDUTY', 'SUPPOSED EXCISE DUTY')
insert into #cost_codes values('MOT',      'MINERALOILTAXEU', 'MINERAL OIL TAX')
insert into #cost_codes values('SAF',      'STAVIATIFUELSAF', 'ST AVIATION FUEL TAX')
insert into #cost_codes values('SD',       'STDIESELFUELSDX', 'ST DIESEL FUEL TAX')
insert into #cost_codes values('SHST',     'STHAZSUBTAXSHST', 'ST HAZARDOUS SUBSTANCE TAX')
insert into #cost_codes values('SG',       'STGASOLINETAXSG', 'ST GASOLINE TAX')
insert into #cost_codes values('VATEXC',   'VATONEXCISEXXEU', 'VAT ON EXCISE')
insert into #cost_codes values('VATGOODS', 'VATONGOODSXXXEU', 'VAT ON GOODS')

declare @cmdty_code        char(8),
        @cmdty_short_desc  char(15),
        @cmdty_long_desc   varchar(40),
        @smsg              varchar(255),
        @errcode           int,
        @pl_implication    varchar(20)
        
select @errcode = 0,
       @pl_implication = 'NO_EFFECT'   /* for Sempra only, for others, use 'OPEN' */
       
select @cmdty_code = min(cmdty_code)
from #cost_codes

while @cmdty_code is not null
begin
   select @cmdty_short_desc = cmdty_short_desc,
          @cmdty_long_desc = cmdty_long_desc
   from #cost_codes
   where cmdty_code = @cmdty_code
   
   if exists (select 1
              from dbo.commodity 
              where cmdty_code = @cmdty_code)
   begin          
      if not exists (select 1
                     from dbo.commodity 
                     where cmdty_code = @cmdty_code and
                           cmdty_short_name = @cmdty_short_desc)
      begin
         select @smsg = 'The cmdty_code ''' + @cmdty_code + ''' exists, but with different cmdty_short_name!'
         print @smsg
      end
   end
   else
   begin   
      begin tran       
      insert into commodity  
         (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
          cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
          prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, 
          cmdty_category_code, trans_id)
       values(@cmdty_code, 'N', 'O', 'A', @cmdty_short_desc, @cmdty_long_desc, 
               NULL, NULL, NULL, NULL, 'UNIT', NULL, NULL, 1)
      select @errcode = @@error
      if @errcode > 0
      begin
         rollback tran
         select @smsg = 'Failed to add the cmdty_code ''' + @cmdty_code + ''' into the commodity table!'
         print @smsg
         goto endofscript
      end
      else
      begin
         if NOT exists (select 1
                        from dbo.cost_code 
                        where cost_code = @cmdty_code)
         begin
            insert into cost_code 
               (cost_code, cost_code_desc, cost_code_type_ind, 
                cost_code_order_num, pl_implication, trans_id)
             values(@cmdty_code, @cmdty_long_desc, 'M', NULL, @pl_implication, 1)
            select @errcode = @@error
            if @errcode > 0
            begin
               rollback tran
               select @smsg = 'Failed to add the cost_code ''' + @cmdty_code + ''' into the cost_code table!'
               print @smsg
               goto endofscript
            end
            else
            begin               
               commit tran
               select @smsg = 'The cost_code ''' + @cmdty_code + ''' was added into the commodity table and the cost_code table!'
               print @smsg
            end
         end
         else
         begin
            commit tran
            select @smsg = 'The cost_code ''' + @cmdty_code + ''' was added into the commodity table!'
            print @smsg
         end
      end
   end
   
   select @cmdty_code = min(cmdty_code)
   from #cost_codes
   where cmdty_code > @cmdty_code
end
endofscript:
drop table #cost_codes
go




