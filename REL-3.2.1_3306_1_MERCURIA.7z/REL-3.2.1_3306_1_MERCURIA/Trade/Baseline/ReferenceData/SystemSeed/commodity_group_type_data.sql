set nocount on

set QUOTED_IDENTIFIER ON
go

print ' '
print 'Loading seed reference data into the commodity_group_type table ...'
go

insert into dbo.commodity_group_type 
      (cmdty_group_type_code, cmdty_group_type_desc, trans_id)
    values('CRUDE', 'P', 1)
go

insert into dbo.commodity_group_type 
      (cmdty_group_type_code, cmdty_group_type_desc, trans_id)
    values('POSITION', 'POSITION GROUP', 1)
go

insert into dbo.commodity_group_type 
      (cmdty_group_type_code, cmdty_group_type_desc, trans_id)
    values('PRODUCTS', 'P', 1)
go

insert into dbo.commodity_group_type 
      (cmdty_group_type_code, cmdty_group_type_desc, trans_id)
    values('TAX', 'T', 1)
go

insert into dbo.commodity_group_type 
      (cmdty_group_type_code, cmdty_group_type_desc, trans_id)
    values ('VESSEL', 'GROUP FOR VOYAGES', 1)
go

insert into dbo.commodity_group_type 
      (cmdty_group_type_code, cmdty_group_type_desc, trans_id)
    values ('PRICERPT', 'GROUP FOR PRICE REPORT', 1)
go

if exists (select 1 
           from dbo.commodity_group_type 
           where cmdty_group_type_code = 'FOREX' and 
                 cmdty_group_type_desc = 'FOREX')
begin
   exec('alter table dbo.commodity_group_type disable trigger commodity_group_type_updtrg')
   
   update dbo.commodity_group_type
   set cmdty_group_type_desc = 'FOREX GROUP'
   where cmdty_group_type_code = 'FOREX' and 
         cmdty_group_type_desc = 'FOREX'

   exec('alter table dbo.commodity_group_type enable trigger commodity_group_type_updtrg')
end
go

if not exists (select 1 
               from dbo.commodity_group_type 
               where cmdty_group_type_code = 'FOREX' and 
                     cmdty_group_type_desc = 'FOREX GROUP')
   insert into dbo.commodity_group_type
        (cmdty_group_type_code, cmdty_group_type_desc, trans_id)
            values('FOREX', 'FOREX GROUP', 1)
go

if not exists (select 1 
               from dbo.commodity_group_type 
               where cmdty_group_type_code = 'EIPP' and 
                     cmdty_group_type_desc = 'EIPP CMDTYS')
   insert into dbo.commodity_group_type
        (cmdty_group_type_code, cmdty_group_type_desc, trans_id)
            values('EIPP', 'EIPP CMDTYS', 1)
go