set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system config. attributes into the constants table ...'
go


IF NOT EXISTS (select * from constants
                   where attribute_name = 'DBVersion')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DBVersion','20010706.2.2', 'N', 'I', 'This attribute was to used to record the version of \
database script used to create or upgrade database. This information has been moved to the \
database_info table.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'HideTermEvergreen')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('HideTermEvergreen','YES', 'N', 'A', 'If its value sets to ''Y'', Term and Evergreen will not be available in TradeCapture.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'MaturityDateFieldName')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('MaturityDateFieldName','last_trade_date', 'N', 'I', 'Not Available')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'PassUser')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('PassUser','ICT', 'N', 'A', 'This attribute stores an ICTS user_init which is used to run PASS.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'TradeTrackingEmail')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('TradeTrackingEmail','','Y','A', 'see explanation for the attribute ''DaysBeforeTradeTracking''.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'UseALS')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UseALS','Y', 'N', 'A', 'If the value is set to ''Y'', ICTS will use ALS to generate derived data.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'requireVoyageInformation')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('requireVoyageInformation','N','Y','A','It is used to determine if user needs to enter voyage information for allocations')
go


IF NOT EXISTS (select * from constants
                   where attribute_name = 'DaysBeforeFinalPricing')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DaysBeforeFinalPricing','2', 'Y', 'A', 'Used by PASS to determine how many days before a cost \
record is set from price estimate to price final after the last day of pricing.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DaysBeforeTradeTracking')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DaysBeforeTradeTracking','0','Y','A', 'TradeCapture will send a mail to address which can be \
obtained from the attribute ''TradeTrackingEmail'' after update a trade which had not been updated \
for ''DaysBeforeTradeTracking'' days or longer.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DefaultInterestRate')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DefaultInterestRate','.06', 'Y', 'A', 'The default rate used in options calculations. This rate should be entered in decimal form, not percentage form.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DefaultToNonHedgePos')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DefaultToNonHedgePos','?', 'Y', 'A', 'It defines whether futures/physicals and some other types \
of order types default as Hedge or Physical type of positions. For derivatives, Y=default to ''NonHedge'', \
N= default to ''Hedge''.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DefaultTradingPeriod')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DefaultTradingPeriod','SPOT', 'Y', 'A', 'It is used by passpricetrades to figure out \
the trading period to use if price for the specified trading period does not exist in the price table.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DefaultVolatility')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DefaultVolatility','.3', 'Y', 'A', 'Default volatility used in options calculations.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NTPassMaxWaitHours')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NTPassMaxWaitHours','7', 'Y', 'A', 'This is used to the passscript as the number of hours AFTER \
NTPass starts that the Script will wait before assuming that NTPass has ''crashed'' if there is no ''COMPLETE'' \
entry found for NTPASS.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NTPassNotifyWait')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NTPassNotifyWait','5', 'Y', 'A', 'How long the pass notification script will wait on a pass \
process before it concludes that it may have failed (in hours).')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NeedToLookUpDeltaForOtc')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NeedToLookUpDeltaForOtc','Y', 'Y', 'A', 'It is used to determine if the delta of an option will \
be always calculated. set value to ''Y'' if delta will also be provided along with the market value of the option.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'PR_RealizedUnrealized')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('PR_RealizedUnrealized', 'Y', 'Y', 'A', 'It is used by the PortfolioReport to enable or disable some \
realized/unrealized popup menu item in the PortfolioReport.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'AllowEstimatePrice')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowEstimatePrice', 'Y', 'Y', 'A', 'It is used to enable/disable ''Estimated Price'' button in \ 
openstep-version of apps; However, it is not used by Windows version of apps because the ''Estimated Price'' \
button is always enabled.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NumberOfMonthsBack')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NumberOfMonthsBack', '24', 'Y', 'A', 'The number of months that PASS pre-loads trading period \
information. For now, since we are constantly marking futures and synthetics (instead of FIFOing them), \
this number MUST be as large as the number of months in ICTS.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DefaultPriceTermForIPESwap')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DefaultPriceTermForIPESwap', 'Y', 'Y', 'A', 'This is a flag controlling whether auto sets price \
term for the IPE and ICE quotes to be ''Roll on One Day before Roll Date'' for swap trade.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DisallowForwardContrDate')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DisallowForwardContrDate','Y', 'Y', 'A', 'This is a flag indicating whether trades with forward \
Contract Date can be entered. It should be ''Y'' or ''N''.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'BrokerRestriction')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('BrokerRestriction', 'Y', 'Y', 'A', 'It is used to determine if Futures and Listed options \
should be closed out among the same broker.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'OtherSystemAliasFields')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('OtherSystemAliasFields', 'Y', 'Y', 'I', 'Not Available')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'UsePriceUom')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UsePriceUom', 'N', 'Y', 'I', 'Not Available')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'CompanyName')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CompanyName','<UNKNOWN>', 'Y', 'A', 'In OpenStep, the company name is one of properties stored in \
NetInfo. In Windows, this information is stored here. DealView app uses this information.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'SequenceWaterMark')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('SequenceWaterMark', '18446744073709551616', 'N', 'A', 'This is attribute used in icts_transaction \
and transaction_touch triggers to detect corrupted IDENTITY GAP problem.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'ActualHighTolerancePercent')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ActualHighTolerancePercent', '10', 'Y', 'A', 'It stores a value which is used for balancing \ 
actual quantity when all allocation items in an allocation is NOT fully actualized.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'ActualLowTolerancePercent')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ActualLowTolerancePercent', '1', 'Y', 'A', 'It stores a value which is used for balancing \ 
actual quantity when all allocation items in an allocation is fully actualized.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NominateHighTolerancePercent')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NominateHighTolerancePercent', '15', 'Y', 'A', 'It stores a value which is used for balancing \
nominated quantity when the user attempt to save an unconfirmed allocation.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NominateLowTolerancePercent')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NominateLowTolerancePercent', '5', 'Y', 'A', 'It stores a value which is used for balancing \
nominated quantity when the user attempt to confirm an allocation or save an confirmed allocation.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'RequireCommentForUpdating')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('RequireCommentForUpdating', 'N', 'Y', 'A', 'If the value is set to ''Y'', users are required to \
update the long comment when they update a trade in TradeCapture.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'SAPOK')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('SAPOK', 'Y', 'N', 'A', 'If this attribute is ''Y'', then the interface application generates flat \
files and reads flat file in the format that users required for their SAP.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'MultiCompanyDB')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('MultiCompanyDB', 'N', 'Y', 'A', 'It indicates Whether or not the system is configured to host \
multiple companies at the same time (and therefore, block access of company A''s data from company B -- \
affects security and what you can view in PortfolioManager and stuff like that).')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'ImbalanceCorrectionRequired')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ImbalanceCorrectionRequired', 'Y', 'Y', 'A', 'When ImbalanceCorrectionRequired = ''N'', it means \
that no option for the user to override quantity imbalance. When ImbalanceCorrectionRequired = ''Y'', \
it means that the Allocation apps will show as imbalance alter message asking the user whether to continue.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'WTPFormat')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('WTPFormat', '1', 'Y', 'A', 'This is a format code indicating which format string should be used \
to generate weekly trading period description for a new trading period record thru TPAUTOGEN process.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'ShouldRepriceRolledInventories')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ShouldRepriceRolledInventories', 'Y', 'Y', 'A', 'It is used by passpriceinventories to determine \
if it needs to reprice inventories which have been closed and rolled. If it is set to ''Y'', \
passpriceinventories reprices all inventories (open, closed, rolled). If it is set to ''N'', \
passpriceinventories only prices Open inventories.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'AllowAutoAllocation')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowAutoAllocation', 'N', 'Y', 'A', 'Turns on/off ICTS behaviour to automatically create \
allocations for specific types of trades on trade creation (based on cmdty/location etc).')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NWAInterface')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NWAInterface', 'N', 'N', 'A', 'If this attribute is ''Y'', then the interface application \
generates flat files and reads flat file in the format that NWA required for their external systems. \
This is for NWA. Only NWA should have this entry with a ''Y''. Everone else should only have a ''N'' or \
it should not be there.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'SendRNInd')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('SendRNInd', 'N', 'Y', 'A', 'Indicates if R&N files are needed to be generated. (This entry \
was added for ALS to generate R&N files for Futures and Listed Option.)')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'RNGatewayPath')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('RNGatewayPath', 'c:\RNFiles', 'Y', 'A', 'The folder path for R&N files to be saved. (This entry \
was added for ALS to generate R&N files for Futures and Listed Option.)')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'RNCostBookCompNum')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('RNCostBookCompNum', '0', 'Y', 'A', 'It stores a default booking company # for R&N interface')
go

/*
IF NOT EXISTS (select * from constants
                   where attribute_name = 'DefaultExceptionAddition')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DefaultExceptionAddition', 'ENGLAW', 'N', 'A', 'It stores a Default for display in Exceptions & \
Additions ''Excp./Addns:'' field on the  miscellaneous screen for Physical Trades in TradeCapture.')
*/

IF NOT EXISTS (select * from constants
                   where attribute_name = 'LocationInspectorTyp')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('LocationInspectorTyp', 'Flat', 'Y', 'A', 'Flat = Flat list of Locations; Heirarchical = Hierarchical \
representation of Locations. Hierarchy displays in TradeCapture for Load Port, Discharge Port and Title \
Transfer fields.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'AllowCrossPortfolioScheduling')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowCrossPortfolioScheduling', 'N', 'Y', 'A', 'This will control if an Allocation can have \
multiple portfolios - however, note that even if this constant is ''on'', the portfolios themselves should \
be ''balanced''.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'AllowIntendedStatus')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowIntendedStatus', 'N', 'Y', 'A', 'It indicates whether allocation will have ''intended'' \
allocation item status available for the user to select. By default, please set it to ''N'' means user can \
not select an intented status.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'WarningStartDateEMailAddress')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('WarningStartDateEMailAddress', '', 'Y', 'A', 'It is an email address used by ALS to send warning \
message when the warningStartDate in tradeTermInfo of a trade is today date. By default the value is a \
empty string.')
go

If NOT EXISTS (select * from constants
                   where attribute_name = 'UnvouchedFinalCosts')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UnvouchedFinalCosts', 'RN', 'N', 'A', 'It stores a list of cost type codes. When a new cost \
record was added or a cost record was being updated, If the cost status of this cost record is either \
''VOUCHED'' or ''PAID'', and its cost type code does not exist in the list stored here, then cost''s insertion \
trigger and update trigger would check if the associated voucher record was added as well.')
go

If NOT EXISTS (select * from constants
                   where attribute_name = 'AllowNominatedStatus')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowNominatedStatus', 'Y', 'Y', 'A', 'Y= displays ''Nominated'' in the list of ''Item Status'' on \
the Scheduling Tab with Confirmed and Allocated (Allocation Application), The default is ''N''.')
go


If NOT EXISTS (select * from constants
                   where attribute_name = 'AutoVouchFate')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AutoVouchFate', '7', 'Y', 'A', 'When the auto voucher indicator in a Trade is set to ''YES'',  \
the fates of all costs associated with this trade are set to the attribute value. For example, in this \
case, the attribute value is 7.')
go

If NOT EXISTS (select * from constants
                   where attribute_name = 'ReversalVoucherOK')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ReversalVoucherOK', 'N', 'Y', 'A', '''Y'' means that NT CommAccount allows user to its user to create\   
 reversal voucher. ''N'' (default) means that user cannot create reversal voucher.')
go

If NOT EXISTS (select * from constants
                   where attribute_name = 'MTMExposureDisplayEndOffset')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('MTMExposureDisplayEndOffset', '30', 'Y', 'A', 'It determines the number of days before certain dates \
to end the display of mtm exposure and begin display of cash exposure.')  
go

If NOT EXISTS (select * from constants
                   where attribute_name = 'WriteOffToleranceAllowed')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('WriteOffToleranceAllowed', 'Y', 'Y', 'A', 'If it is set to Y, then any cost less than $0.01 will not \
create create a WO record.')
go

If NOT EXISTS (select * from constants
                   where attribute_name = 'FuturesFeedDefaultPortNum')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('FuturesFeedDefaultPortNum', '-1', 'Y', 'A', 'It serves as a default portfolio number for those \
futures loaded from fill file in FuturesFeed app.')
go

If NOT EXISTS (select * from constants
                   where attribute_name = '10TagsCanBeNull')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('10TagsCanBeNull', 'Y', 'Y', 'A', 'It serves as a flag telling whether a record added into jms_reports table \
can have null value(s).')
go

If NOT EXISTS (select * from constants
                   where attribute_name = 'SempraLiveAccountAlias')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('SempraLiveAccountAlias', '', 'Y', 'A', 'It stores an alias source code used to identify the counterparties \
in the account_alias table that will participate in the SempraLive interface.')
go

If NOT EXISTS (select * from constants
                   where attribute_name = 'TCMandatoryContact')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('TCMandatoryContact', 'N', 'N', 'A', 'It signifys whether the contact filed in TradeCapture is mandatory or not.')
go


If NOT EXISTS (select * from constants
                   where attribute_name = 'MktFormulaRelativePrecedent')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('MktFormulaRelativePrecedent', 'NO', 'Y', 'A', 'is used by passpricemarkets in the event that a user has a \
formula for a relative (nearby, e.g. SPOT01) period as well as a formula for the REAL (e.g. 200202) \
period to which this relative period maps. The value NO implies that the formula for the REAL period \
takes precedence over the relative formula. YES implies vice versa.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'CreditBookCompList1')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CreditBookCompList1','', 'Y', 'A', 'booking company number list #1 used by credit interface (separated ids in list with a comma).')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'CreditBookCompList2')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CreditBookCompList2','', 'Y', 'A', 'booking company number list #2 used by credit interface (separated ids in list with a comma).')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'CreditBookCompList3')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CreditBookCompList3','', 'Y', 'A', 'booking company number list #3 used by credit interface (separated ids in list with a comma).')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'BunkerTraderInit')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('BunkerTraderInit','', 'Y', 'A', 'trader init used by credit interface and 4GenInterface.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'UpdateExposure')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UpdateExposure','Y', 'Y', 'A', 'It is used by passpl task in PASS to decide if the exposure_detail \
entries for the costs should be updated or not. If this value is missing, or does not start with N or n, \
the queries are created.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'SAP_INTERCP_ACCT_NUM_THRES')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('SAP_INTERCP_ACCT_NUM_THRES','10000', 'Y', 'A', 'It contains a threshold acct_num for determining if an account \
is a SAP intercompany account.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DefaultGSTTaxRate')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DefaultGSTTaxRate','3', 'Y', 'A', 'It is used in the CommAccount to set the default GST (value added tax) \
 rate for costs. The rate is then ued in CAInterface (sending to SAP) to increase the amount \
of the cost by the rate and create an offset cost of the original amount.')
go


IF NOT EXISTS (select * from constants
                   where attribute_name = 'RootActivePortfolioNumber')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('RootActivePortfolioNumber','', 'Y', 'A', 'It stores the portfolio number of the ultimate parent of all active portfolios.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'RestrictUpdatesToJMSReports')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('RestrictUpdatesToJMSReports','N', 'Y', 'A', 'It is used to control whether users needs entries in the \
user_permission table to update the fields in the jms_reports table.')
go


IF NOT EXISTS (select * from constants
                   where attribute_name = 'BunkerSpotPurchCPAcctNum')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('BunkerSpotPurchCPAcctNum','', 'Y', 'A', 'It is used for setting the counterparty of the bunker spot \
purchase trade which is created by auto allocation.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'CashMods')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CashMods','N', 'Y', 'A', 'It is used to determine the behaviour of costs in ICTS to a great extent.  In a broad sense, \
having a value of Y for this constant enables ICTS to interface with accounting modules \
of clients who use a cash-based accounting system.  The behaviour of several modules in ICTS related \
to costs are treated is governed by this constant.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'allowWorldScaleCosts')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('allowWorldScaleCosts','N', 'N', 'A', 'It is used to determine if user is allowed to create world scale cost.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'CostBookPrdDate')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CostBookPrdDate','CostDueDate', 'Y', 'A', 'It is used to indicate how to set cost_book_prd_date, \
possible values are either CostEffDate or CostDueDate.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NTPassPredecessor')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NTPassPredecessor','PriceLoad', 'N', 'A', 'It stores a filter value for matching event_owner column of event records whose event_code is ''Complete''.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'FammFourGenBTBWhse1')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('FammFourGenBTBWhse1','NETHLU,SINGFU,CSLBTB,CSLINV', 'Y', 'A', 'It stores a list of warehouse codes for Famm 4Gen Back to Back Sales.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'PriceExpiredMarketFormulas')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('PriceExpiredMarketFormulas','N', 'Y', 'A', 'It is used to instruct ICTS to either price ALL market formulas (Y) or price only current and forward formulas (N).')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'CINFieldLength')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CINFieldLength','8', 'Y', 'A', 'It stores the max number of characters a CIN (Cargo ID Number) field in trade table can have.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'requireVoyageInformation')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('requireVoyageInformation','N','Y','A','It is used to determine if user needs to enter voyage information for allocations')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'secCPInvTotalAmtCurr')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('secCPInvTotalAmtCurr','EURO','Y','A','It is used to determine the currency for the second totalAmt of CPInvoice in voucher editor.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'JVPaymentMethod')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('JVPaymentMethod', 'WIR', 'N', 'A', 'It tells which payment method code is used for Joint venture.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'JVPaymentMethod')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('JVPaymentTerm', 'NCROI', 'N', 'A', 'It tells which payment term code is used for Joint venture.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'AllowMultiRebookVouchers')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowMultiRebookVouchers', 'YES', 'Y', 'A', 'When it is YES, rebook costs from a voucher reversal can go on differen final vouchers. \
If it is NO, rebook costs from a reversed voucher should go on the same final voucher.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'ShouldAutoExerciseListedOption')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ShouldAutoExerciseListedOption', 'YES', 'Y', 'A', 'When it is YES, It allows processlistedoptions to automatically exercise and \
expire listed options. If it is NO, it does not allow processlistedoptions to automatically exercise and expire listed options.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'AICostEffDateBehavior')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AICostEffDateBehavior', 'AI', 'Y', 'A', 'The value AI set the AI costEffDate to be mid of nomin period, the value \
AA sets it to be earliest ai_est_actual_date.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'RepriceProcessChunkSize')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('RepriceProcessChunkSize', '50', 'Y', 'A', 'This constant will determine how many trade_items Repricing app will process before saving changes.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'TCShortCmntLength')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('TCShortCmntLength', '15', 'Y', 'A', 'Controls the default comment string length allowable in the TC short comment fields.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'UseSubAllocForInventoryPricing')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UseSubAllocForInventoryPricing', 'YES', 'Y', 'A', 'Use sub allocation to pick the allocation items for pricing, as opposed to all items')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DiscountPL')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DiscountPL', 'N', 'Y', 'A', 'Turns on or off NPV discounting option of profit/loss in passpl')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NON_PL_COST_CODE')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NON_PL_COST_CODE', 'VAT', 'Y', 'A', 'It is used to determine if a cost will be picked up by PASS')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NTPassServerUBS')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NTPassServerUBS', 'N', 'Y', 'A', 'It is used to determine whether NTPassServer will be run or not')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'EarliestFIFODate')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('EarliestFIFODate', convert(varchar, getdate(), 110), 'Y', 'A', 'Earliest fill date to be considered for FIFO.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DaysBeforeFIFO')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('DaysBeforeFIFO', '0', 'Y', 'A', 
            'Number of days between asof_date and fill_date for it to be considered for FIFO.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DefaultCorrelation')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('DefaultCorrelation', '0.65', 'Y', 'A', 
            'The default correlation used in multi-component options calculations.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'ShouldCheckGLCode')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('ShouldCheckGLCode', 'Y', 'Y', 'A', 
            'It is used to tell whether to do calculation automatically for the cost if a GL code exists.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DepartmentsEligibleToConfirm')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('DepartmentsEligibleToConfirm', '', 'Y', 'A', 
            'It contains a list of departments. If a user belongs to one of these \
departments, he/she can create voucher document only if trade is confirmed or cost \
are approved.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'PassTransactionLimit')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('PassTransactionLimit', '50', 'Y', 'A', 
            'Controls batch save size (# of rows) in pass server processing. Larger \
numbers should increase efficiency but also increase potential deadlock situations. \
Smaller numbers should do the opposite. Deadlock situations are typically more \
likely when multiple pass servers are used simultaneously.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'ManualInputSecQtyPreference')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('ManualInputSecQtyPreference', 'N', 'Y', 'A',
            'If ''Y'', then the Allocation app will automatically \
select manual input for secondary quantity for new allocation items. If ''N'', \
the app will automatically convert the primary quantities to secondary quantities.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DelayBusDaysBeforeFIFO')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('DelayBusDaysBeforeFIFO', '3', 'Y', 'A', 'Number of business days after last \
trade date before an exchange trade will be FIFOd.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'FIFOExchOptBeforeExerExpire')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('FIFOExchOptBeforeExerExpire', 'NO','N','A','If yes, we FIFO Listed Options \
automatically before running exercise/expire task')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'MTMFIFOdExchTrades')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('MTMFIFOdExchTrades', 'NO','Y','A','If yes, the closed PL is not extended value, \
instead it is MTM of tid.alloc_qty')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'UseLastTrdDateToMTMExchTrds')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('UseLastTrdDateToMTMExchTrds', 'NO','Y','A','If yes, we use market price and \
currency conversion rate on the last_trade_date for MTM on dates past last_trade_date; \
otherwise it is the market price and currency conversion rate on the asof_date of PASS run')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'ReverseUnpostedVouchers')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('ReverseUnpostedVouchers','NO','Y','A','If set to yes, the vouchers with null \
voucher_book_date can also be reversed. Otherwise, the vouchers must be posted in order to \
be reversed.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'PriceMktsUptoLastTradeDate')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('PriceMktsUptoLastTradeDate','N','Y','A','This is used to determine if we should \
stop pricing a market formula after the last trade date (default is after the last del date)')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'TCCounterpartyOnExchangeTrade')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('TCCounterpartyOnExchangeTrade','DISALLOW','Y','A','Indicate if counterparty is \
MANDATORY, OPTIONAL, or DISALLOW for Futures and Exchange Options trade')
go

-- When the attribute below is set to some positive number, then the pricing of the market 
-- formula is carried out for that many number of days in future after the trading period 
-- for the market formula has expired.  For instance, a formula for 200411 may have the 
-- lastTradeDate of 11/30/2004, but if the above constant is set to 60, then the formula 
-- with trading period 200411 will be evaluated for upto 60days after 11/30/2004.

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DaysPriceAfterEndPeriod')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('DaysPriceAfterEndPeriod','0','Y','A','Days to continue pricing market formulas \
after the trading period lastTradeDate is over')
go

-- Added the following 2 attributes For Mercuria
IF NOT EXISTS (select * from constants
                   where attribute_name = 'DefaultInhouseTradeToConfirmed')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('DefaultInhouseTradeToConfirmed','N','Y','A', 'Indicate if inhouse trades are \
defaulted to confirmed')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DisallowUnconcludedTrade')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('DisallowUnconcludedTrade','N','Y','A', 'To disallow user entering unconcluded trades')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'BrokerFifoEarliestFillsFirst')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('BrokerFifoEarliestFillsFirst','N','Y','A', 'It indicates if the broker fifo starts from the \
earliest fill date or the intraday fills on the as-of-date first.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DeclarationDateCalendar')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('DeclarationDateCalendar', 'USA', 'Y', 'A', 'The cal_code for the calendar used in computing \
the relative declaration date based on business days')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'UseOptionSkewTable')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('UseOptionSkewTable', 'N', 'Y', 'A', 'Used to determine whether the option_skew table is used \
for volatility lookup (If ''N'', option_price table is used for volatilities).')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'UseExchangeOptionPrices')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('UseExchangeOptionPrices', 'Y', 'Y', 'A', 'Used to determine whether exchange option prices \
entered into option_price table are used (If ''N'', exchange option prices are computed with the underlying volatility).')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'FlatFileGen.DailyInterface')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('FlatFileGen.DailyInterface', 'TC', 'Y', 'A', 'Tells which client specific classes needed to be loaded for flat file generation.')
go


IF NOT EXISTS (select * from constants
                   where attribute_name = 'LastPricingAsOfToday')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('LastPricingAsOfToday','Y','Y','A','Indicate if the pricedQty in distribution is defaulted to as the trade is priced as of today')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'AutopoolBookCompRequired')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     VALUES('AutopoolBookCompRequired','N','Y','A','If set to Y, then booking company is required for autopool_criteria')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'SeparateThetaModel')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('SeparateThetaModel','N', 'Y', 'A','Option model in NTPass which calculates theta separate from drift. \
Usual model include drift in theta.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NTPassServerSelectTimeOut')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NTPassServerSelectTimeOut','900', 'Y', 'A','NT pass server, DB select statement query time out in seconds.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NTPassServerUpdateTimeOut')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NTPassServerUpdateTimeOut','900', 'Y', 'A','NT pass server, DB update statement query time out in seconds.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'IsCostCenterDefault')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('IsCostCenterDefault','N', 'Y', 'A','It is used to determine how the cost center info is defaulted in cost editor.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'ShouldUpdateCostBookPrdDate')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ShouldUpdateCostBookPrdDate','Y', 'Y', 'A','It is used by CommAccount application to determine if it \
needs to update costs book_prd_date to that of vouchers voucher_book_prd_date, when it is updated via CA app')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'isBookCompDefForPortOwnedCost')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('isBookCompDefForPortOwnedCost','N', 'Y', 'A','It is used to determine if Booking Company is \
defaulted for Portfolio cost.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'hasWriteOffLimit')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('hasWriteOffLimit','N', 'Y', 'A','It is used to determine if users has an amount limit for the write \
off cost he created.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'defaultFirstGLCode')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('defaultFirstGLCode','Y', 'Y', 'A','It is used to determine if costGLCode is defaulted to the first \
record in Database.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DefaultComprPricePrecision')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DefaultComprPricePrecision','3', 'Y', 'A','It is used to tell what is the default price precision\
for compromise of claims')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'setMatCodeInVoyageField')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('setMatCodeInVoyageField','N', 'Y', 'A','It indicates whether the voyage_code column in the cost_ext_info \
table is used to store a material code for the cost_code (in FR7).')
go

-- NOTE: The attribute_name in constants table must be expanded to 50 characters
IF NOT EXISTS (select * from constants
                   where attribute_name = 'ShouldNotDiscountIfPriceAndQtyActual')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ShouldNotDiscountIfPriceAndQtyActual','Y', 'Y', 'A','It drives the behavior of the discountFactor being \
set to 1 (no discounting - default) if the cost is price and qty actualized.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'UseAltSourceIndForAllTPs')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UseAltSourceIndForAllTPs','N', 'Y', 'A','It will control if the UseAltSourceInd field will be used \
only for SPOT/SPOT0X trading periods (which is the current default implementation) or if it will be for ALL \
trading periods (which is a new enhancement).')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'AlternatePriceSource')                
   INSERT INTO dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
      VALUES('AlternatePriceSource','','Y','A','Alternate price source used for alternate mtm value in futures P/L calculation.')
go
                        
IF NOT EXISTS (select * from constants
                   where attribute_name = 'ShouldFixCostCurrencyConvRateBasedOn')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ShouldFixCostCurrencyConvRateBasedOn','', 'Y', 'I','It stores a cost attribute date column (i.e. \
cost_effective_date, cost_due_date, or cost_book_date, etc) which the module''s logic \
will be based on.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'UomCodeForLiter')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UomCodeForLiter','', 'Y', 'I', 'Uom code for liter unit of measure')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'UomCodeForKilogram')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UomCodeForKilogram','', 'Y', 'I', 'Uom code for kilogram unit of measure')
go

/* PHIS-33  04/17/2017 */
IF NOT EXISTS (select * from constants
                   where attribute_name = 'CurrConvAverageBeforeReciprocal')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CurrConvAverageBeforeReciprocal','YES', 'Y', 'A', 'If YES, reciprocal of average; else average of reciprocals.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'ActivePositionPLCalcMonthLimit')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ActivePositionPLCalcMonthLimit','6', 'Y', 'I', 'Limit for how many months after trading period ends will P/L be calculated on positions.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'EnableRealTimePL')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('EnableRealTimePL','N','Y','A','If yes, extra processing will be enabled which is needed for the functioning of real-time P/L.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'NumOfSPOTMonthsAllowed')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NumOfSPOTMonthsAllowed','18','Y','A','Max. number of months a SPOT trading period can be created')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'UseYearInCustomVoucherString')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UseYearInCustomVoucherString','Y','Y','A','It is used to control whether ''year'' in the custom_voucher_range table \ 
shall be used to construct a custom voucher string.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'EnablePLHistoryAudit')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('EnablePLHistoryAudit','Y','N','A','If yes then audit pl_history records will be generated. The attribute_value is \
maintianed by PASS, which disables the generation while it is running and sets it back to enabled when finished.') 
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'UseVATQualification')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UseVATQualification','N','Y','A','It is used to determine whether EU tax qualication is used.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'EnableRealTimePricing')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('EnableRealTimePricing','N','Y','A','If yes, extra processing will be enabled which is needed for the functioning \
of real-time pricing.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'VatTypesForInventoryQualification')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('VatTypesForInventoryQualification', ' ', 'Y', 'A', 'A list of vat types for inventory qualification. Use column as separator.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'VatTypesForEUQualification')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('VatTypesForEUQualification', ' ', 'Y', 'A', 'A list of vat types for EU Qualification. Use column as separator.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'EnableMtmNetLossCreditLimit')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('EnableMtmNetLossCreditLimit', 'N', 'Y', 'A', 'If set to ''Y'', Account Reference CreditLimit will enable Method Type: Mtm Net Loss.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'IsToleranceRequired')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('IsToleranceRequired', 'N', 'Y', 'A', 'It is used to determine if tolerance is a required value for a trade item.')
go

/* This attribute was deleted from Mercuria db, we do not want to enter this again
   during a db upgrade -- Peter Lo  11/19/2008
*/

/* enabled - PHIS-23 by Peter Lo  04/17/2017 */  
IF NOT EXISTS (select * from constants
                   where attribute_name = 'DefaultFXConvPrecision')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DefaultFXConvPrecision', '15', 'Y', 'A', 'It stores a default precision value for FX Conversions.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'SwapUseOneUomConvForAllQuotes')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('SwapUseOneUomConvForAllQuotes', 'Y', 'Y', 'A', 'If set to Y, only one UOM conversion rate is used for the positions and quote \
prices of all the market quotes in a swap.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'TCInactivateExtMappingFields')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('TCInactivateExtMappingFields', 'N', 'Y', 'A', 'If YES, the External Source Popup and External Commodity Name field in TC will \
be disabled for existing template trades.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'AutoDeleteEmptyAlloc')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AutoDeleteEmptyAlloc', 'N', 'Y', 'A', 'Delete allocation automatically if all items are removed and no allocation owned costs exist.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'DisplayCustomerInvoiceInfo')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DisplayCustomerInvoiceInfo', 'N', 'Y', 'A', 'It is used to determine invoice received date and invoice type on voucher editor.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'AllowVoucherTISecCost')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowVoucherTISecCost', 'N', 'Y', 'A', 'It is used to decide whether to allow vouchering Secondary cost before Trade is actualised.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'WriteMTMVolatility')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('WriteMTMVolatility', 'N', 'Y', 'A', 'If it is set to Y, then NTPASS will write records to tid_mtm_volatility table.')
go

IF NOT EXISTS (select * from constants
                   where attribute_name = 'FuturesFeedOfficeDescriptor')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('FuturesFeedOfficeDescriptor', '', 'Y', 'A', 'This is used to store an OFFICE location code such as LON, etc for FuturesFeed app.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'FilterTradingPeriodsFromQuoteInspector')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('FilterTradingPeriodsFromQuoteInspector', 'Y', 'Y', 'I', 'If active and set to Y, trading periods as viewed in the quote reference \
inspector where there is no reference trade will be filtered out based the trading period''s last trade date \
if that is older than a year from the present.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ManualSecQtyTolerancePercent')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ManualSecQtyTolerancePercent', '100', 'Y', 'A', '2nd actual quantity tolerance percent for manual input 2nd quantity (valid range 0-100).')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowCrackEFPTolerance')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowCrackEFPTolerance', 'N', 'Y', 'A', 'Turns on functionality to enable tolerance and estimated \
quantity to crack EFP type trades if set to Y.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'InvoiceCustomerGroupType')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('InvoiceCustomerGroupType', '', 'Y', 'A', 'It is used to decide if two costs with different \
 counterparties can be vouched into one voucher.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ShouldSaveEachTradeInPricing')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ShouldSaveEachTradeInPricing', 'N', 'Y', 'A', 'It is used for making the logic to save changes in \
passpricetrades after each trade to reduce changes of deadlock a configurable option. It saves at the trade level \
instead of several trades at a time.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ShouldSaveHistoricalPlData')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ShouldSaveHistoricalPlData', '0', 'Y', 'A', 'It is used to see if the ''historical'' pl data \
(such as qppMTM etc) should be saved.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'TruckCaptureActualTolerancePercent')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('TruckCaptureActualTolerancePercent', '0', 'Y', 'A', 'This value determines the percentage tolerance for \
actuals entered in TruckCapture. Exceeding this tolerance results in a user warning.')
go

/* PHIS-22   04/17/2017 */
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AltFXConvPrecision')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
       VALUES('AltFXConvPrecision', '15', 'Y', 'A', 'An alternative FX Rate Conversion Precision. \
The value 0 means no rounding required; the value 4 means round to 4.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'JSVATFunctionality')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
      VALUES('JSVATFunctionality', 'N', 'N', 'A', 'It is used to turn on/off FuelQuest Functionality.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'UseVAT')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UseVAT', 'N', 'Y', 'A', 'It is use to determine if VAT is needed.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'UseVATForActual')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UseVATForActual', 'N', 'N', 'A', 'It allows user to enter VAT information at actual level.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'SkipPositionPPLWrite')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
      VALUES('SkipPositionPPLWrite', 'N', 'Y', 'A', 'When turned on with an affirmative value, the writing of \
portfolio_profit_loss records for position and position group portfolios will be stopped.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowNetQtyHigherThanGrossQty')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
      VALUES('AllowNetQtyHigherThanGrossQty', 'N', 'Y', 'A', 'Allow whether the net qty can be larger than gross qty of an actual.')
go

/* -------------------------------------------------------
    CVX TI
   ------------------------------------------------------- */

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'DefaultCreditTermOnCreditLimit')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DefaultCreditTermOnCreditLimit','N','Y','A','It indicates if credit term default is based on \
whether credit limit is exceeded.') 
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'NumberOfClosedMonthsToViewForPhyExch')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NumberOfClosedMonthsToViewForPhyExch','2','Y','A','Number of past months available for viewing in Exchange Physical.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'PhysExchNewLegCreatedWithZeroQty')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('PhysExchNewLegCreatedWithZeroQty','NO','Y','A','If set to YES, the new legs in a physical exchange will be created with zero qty.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'PhysExchOpenMonths')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('PhysExchOpenMonths','3','Y','A','Number of forward months for Physical Exchange Trade.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowNoiseBandsTask')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowNoiseBandsTask','N','N','A','Whether noise bands and RNSV can be a PASS task option.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ShouldComputeMTMForPhysExchanges')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ShouldComputeMTMForPhysExchanges','N','Y','A','To turn on/off the functionality to compute the MTM p/l for Physical exchanges.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'confirmAiWhenActualize')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('confirmAiWhenActualize','Y','N','A','Use it to enable confirmation of AI when actuals are added.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'TCAllowToAddMultiplePhysExch')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('TCAllowToAddMultiplePhysExch','N','Y','A','If NO, the Add Order button in TradeWindow will be disabled if there is \
any physical exchange order exists in a trade. Default is NO.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowNetQtyHigherThanGrossQty')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
      VALUES('AllowNetQtyHigherThanGrossQty', 'N', 'Y', 'A', 'Allow whether the net qty can be larger than gross qty of an actual.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'PickupProcessTicketPendingRows')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('PickupProcessTicketPendingRows', 'N', 'N', 'A', 'If it is set to Y, ProcessTicket app will process \
when the PT thread wakes up, this gets updated via the windows scheduler to Y during the window \
when the rows are to be Processed.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'RunInvRptForOPL')                
   INSERT INTO dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
      VALUES('RunInvRptForOPL', 'N', 'Y', 'A', 'If yes the Inventory report will be run for \
criteria specified in config.plist after Official Pass run.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'UseAccountDfltCreditTermOnly')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
      VALUES('UseAccountDfltCreditTermOnly','Y', 'Y', 'A', 'If Y, the credit term field in TC will be disabled, \
and the credit term will be tied to the dflt_credit_term_code of the counterparty account.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'BrokerFeeBasedOnActualVolumes')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
      VALUES('BrokerFeeBasedOnActualVolumes', '', 'Y', 'A', 'It is used to hold a list of acct_nums which require \
broker fee to be calculated based on actual volume.')
go

IF EXISTS (select 1 from dbo.constants
               where attribute_name = 'NewAsACopyOf_EnableAutoPortfolioCreation')   
   update dbo.constants
   set attribute_name = 'NewAsACopyOf_Create_Portfolio'
   where attribute_name = 'NewAsACopyOf_EnableAutoPortfolioCreation'
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'NewAsACopyOf_Create_Portfolio')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NewAsACopyOf_Create_Portfolio', 'Y', 'Y', 'A', 'Enables or Disables auto portfolio creation while \
creating instances from NewAsACopy of Scenario.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'NewAsACopyOf_PreOrAppend_YYMM_ToPortfolio')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NewAsACopyOf_PreOrAppend_YYMM_ToPortfolio', 'Y', 'Y', 'A', 'Valid values are PREAPPEND or APPEND. Based on this \
value the risk period in YYMM format will be either appened to portfolio short/long name or preappend.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'DefaultGSTRate')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('DefaultGSTRate','5', 'Y', 'A', 'This rate will be applicable if AUTOGST_CREATION is turned on TI and \
no rate is specified for the location. Value is in % ')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'GST_CostCode')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('GST_CostCode','GST', 'Y', 'A', 'Represents cost_code for GST costs, this CostCode Should exists in \
both cost_code and commodity table.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ShouldDefaultBuySellFld')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ShouldDefaultBuySellFld', 'Y', 'Y', 'A', 'Will select Buy/Sell or Rec/Del/Both radio matrixes in TradeData panel \
if the value is YES, use will be forced to select these fields it the value is NO.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'FX_Exposure_ON')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values ('FX_Exposure_ON', 'Y', 'Y', 'A', 'If Y, the functionality to calculate exposure and PL fox FX costs \
(where price currency and portfolio PL currency differ). Default is N')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'FX_Primary_CostTypes')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values ('FX_Primary_CostTypes', 'WPP, OPP, SWAP, NO', 'Y', 'A', 'List of cost_type_codes which are to be considered as \
principle costs in separating the FX exposure between principle and others. Currency trade costs are the third category.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'BankInfoIsMandatory')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('BankInfoIsMandatory', 'Y', 'Y', 'A', 'When this constant is YES, then Bank Information related data is to be entered in \
ICTSAdmin, if constant value is NO, then Bank Information is optional.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'UseTheSafe')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values ('UseTheSafe', 'Y', 'Y', 'A', 'When Yes, SAFE button enabled across all apps, or else it is disabled')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'CustomVoucherImpementation')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values ('CustomVoucherImpementation','VATIDBASED', 'Y', 'A', 'Determines the logic used for custom voucher string generation, current options are GENERAL, VATIDBASED')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'LCBankFeeMinPcntWarningLimit')                
   insert into dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     values ('LCBankFeeMinPcntWarningLimit', '3', 'Y', 'A', 'Minimum percentage limit after \
which a soft warning will be thrown to the user. Valid value 0-99')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'LCBankFeeMaxPcntLimit')                
   insert into dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
     values ('LCBankFeeMaxPcntLimit', '9', 'Y', 'A', 'Maximum percent value that can be allowed \
when entering the LC Bank fee percent value')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ThresholdForZeroPositions')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values ('ThresholdForZeroPositions', '0.01', 'Y', 'A', 'Parameter used in PortfolioManager to determine what will be considered a zero quantity for display')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'MAC_ActualDateBased')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('MAC_ActualDateBased', 'Y', 'Y', 'A', 'If Y, aiEstActualDate on the actual is used for sequencing in moving average inventory pricing; if N, it is based on data entry into system')   
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'InventoryPriceForPL')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('InventoryPriceForPL', 'WACOG', 'Y', 'A', 'WACOG: weighted avg cost of goods; MAC: moving average cost; FIFO: FIFO pricing')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowValueAdjForInventory')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('AllowValueAdjForInventory', 'Y', 'Y', 'A', 'If Y, a user can create a pay/rec cost to modify inventory value')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'CreditLimitRoundingPrecedence')                
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CreditLimitRoundingPrecedence', 'X', 'Y', 'I', 'Location of rounding in the exposure credit limit calculation. \
''Before'' = before aggregation and calculation, ''After'' = after aggregation and calculation, \
inactive status = no rounding')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'CreditLimitRoundingScale')                
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CreditLimitRoundingScale', '-3', 'Y', 'A', 'Scale for rounding, positive values denote the number of digits \
to the right of the decimal point, negative values denote the number of digits to the left of the decimal point')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'MAC_ActualDateBased')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('MAC_ActualDateBased', 'Y', 'Y', 'A', 'If Y, aiEstActualDate on the actual is used for sequencing in moving average inventory pricing; if N, it is based on data entry into system')   
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'InventoryPriceForPL')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('InventoryPriceForPL', 'WACOG', 'Y', 'A', 'WACOG: weighted avg cost of goods; MAC: moving average cost; FIFO: FIFO pricing')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowValueAdjForInventory')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('AllowValueAdjForInventory', 'Y', 'Y', 'A', 'If Y, a user can create a pay/rec cost to modify inventory value')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ApplyExchRateBasedOnVoucherRule')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('ApplyExchRateBasedOnVoucherRule', 'N', 'Y', 'A', 'If the value is set to Y, then different rules will be used while retreving the FX P/L exchange rate based on voucher status')   
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'Require_Cleared_Attributes')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('Require_Cleared_Attributes', '1', 'Y', 'A', 'Require_Cleared_Attributes')   
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'LM_AUTO_PAYMENT')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('LM_AUTO_PAYMENT', '1', 'N', 'A', 'It is used to calculate the payment if the attribute_value is non-zero')   
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'LockPLInSalePortfolio')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('LockPLInSalePortfolio', 'NO', 'Y', 'A', 'Indicates if the Purchase P/L is locked in the portfolio of the Sale once allocated.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'EnforceSameCreditTermRuleForTerms')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('EnforceSameCreditTermRuleForTerms', '', 'Y', 'A', 'This containt list of credit term codes, if a credit term code is in this list, then all costs that are put on a voucher should have same credit term codes')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'PartialsPricingCounterpartyList')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('PartialsPricingCounterpartyList', 'ALL', 'Y', 'A', 'It contains a list of account numbers, separated by commas, for the counterparties that do not want to use weighted average spec value in formula calculation')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'CheckAllocForMatchingProfitCenter')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('CheckAllocForMatchingProfitCenter', 'Y', 'Y', 'A', 'Check to see profit centers match on both sides of an allocation')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'CheckAllocForMatchingBookingCompany')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('CheckAllocForMatchingBookingCompany', 'Y', 'Y', 'A', 'Check to see booking companies match on both sides of an allocation')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ExecutorIdForJavaPass')
   INSERT INTO dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('ExecutorIdForJavaPass', '3', 'Y', 'A', 'Denotes the value that will be used as executor_id for Hibernate Java Pass server. The attribute_value here should also be set on pass_task.executor_id for the tasks to be executed using this server.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'SPC_Co_Reg_No')
   INSERT INTO dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('SPC_Co_Reg_No', '', 'Y', 'A', 'SPC - GST template field.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'FlatFileGen.DailyInterface.FilePrefix')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('FlatFileGen.DailyInterface.FilePrefix', 'Symphony', 'Y', 'A', 'File Name Prefix for flat files.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'StatusForExpiredLC')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('StatusForExpiredLC', 'EXPIRED', 'N', 'A', 'Status code for expired LCs')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowAutoOkToLoadInterCompanyTrades')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('AllowAutoOkToLoadInterCompanyTrades', 'Y', 'Y', 'A', 'This flag is to allow auto setting of okToLoad on sched_status of trade for inter company trades.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'MaxFavoriteAttrDisplayed')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('MaxFavoriteAttrDisplayed', '15', 'Y', 'A', 'It tells how many favorite attributes to be displayed in Layout Options')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'MaxRecentSearchesDisplayed')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('MaxRecentSearchesDisplayed', '5', 'Y', 'A', 'It tells how many recent searches to be displayed in drop down in Trade Search Panel')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'XeedGridFetchLimit')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('XeedGridFetchLimit', '100', 'Y', 'A', 'It tells how many rows to be fetched for one time when a query is fired in Trade Search Panel ')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ZytaxTDSVersion')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('ZytaxTDSVersion', '50', 'Y', 'A', 'Determines the Zytax Tax Determination version')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'EnableWacogsFunctionality')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('EnableWacogsFunctionality', 'NO', 'Y', 'A', 'If set YES, the WACOGS Inventory Pricing functionality is enabled')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'NorthSeaMktCodeForBrentReports')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('NorthSeaMktCodeForBrentReports', 'NSEA', 'Y', 'A', 'The mkt_code to be used to identify the market for North Sea; it is used for Brent reports; if not set, the mkt_code is assumed to be: NSEA, N.SEA or NORTHSEA')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowInternalTradeAllocSplit')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('AllowInternalTradeAllocSplit', 'Y', 'N', 'A', 'When YES,internal trade will be allocated like regular trades.When NO, internal trades has to be allocated in one allocation')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'WritePLForInvRolledAtMktPrice')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('WritePLForInvRolledAtMktPrice', 'Y', 'Y', 'A', 'If yes, we write two pl_history rows for mkt and inv value for inventories rolled at market price')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowRollProjectedQuantity')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('AllowRollProjectedQuantity', 'N', 'Y', 'A', 'Enables funtionality which allows rolling of projected quantity by \
automatically actualizing that quantity when rolling and applying subsequent actual information as open period adjustments')
go

-- Added by issue #1338312
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowPortChangeForCompletedSchedulingTrade')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowPortChangeForCompletedSchedulingTrade', 'N', 'Y', 'A', 'If Y, portfolio of completed scheduling or zero open qty trades can be changed')
go

-- Added by issue #1338298
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowMultipleTransportsInShipment')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowMultipleTransportsInShipment','Y', 'N', 'A', 'Allow scheduling a shipment with parcels having different transport types (MOTType)')
go

-- Added by issue #1335576
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowCostAdjForInventories')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('AllowCostAdjForInventories', 'N', 'Y', 'A', 'Cost adjustment is valid only for MAC algorithm at present. Cost adjustment panel in allocation app is enabled/disabled depending on this constant')
go

-- Added by issue #1335187
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ShouldUpdateSynthPositionsWithScheduleQty')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('ShouldUpdateSynthPositionsWithScheduleQty', 'Y', 'N', 'A', 'It is used for the quantity of a scheduled autopooled physical position to be updated to the Synthetic positions')
go

-- Added by issue #1332561
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'PopulateBankAcctNumFromPEBank')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('PopulateBankAcctNumFromPEBank', 'NO', 'Y', 'A', 'If the value is set to YES then the bank account number field is auto populated from the PE Bank info. If NO then the bank account number field need to be populated by the user manually.')
go

-- Added by issue #1338298
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowMultipleTransportsInShipment')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('AllowMultipleTransportsInShipment','Y', 'N', 'A', 'Allow scheduling a shipment with parcels having different transport types (MOTType)')
go

-- Added by issue #1331671
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'WritePLForInvRolledAtMktPrice')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('WritePLForInvRolledAtMktPrice', 'Y', 'Y', 'A', 'If yes, we write two pl_history rows for mkt and inv value for inventories rolled at market price')
go

-- Added by issue #1335576
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowCostAdjForInventories')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('AllowCostAdjForInventories', 'N', 'Y', 'A', 'Cost adjustment is valid only for MAC algorithm at present. Cost adjustment panel in allocation app is enabled/disabled depending on this constant')
go

-- Added by issue #1340577
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'EnableEmailFaxForSharepoint')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('EnableEmailFaxForSharepoint', 'N', 'Y', 'A', 'Indicates to turn ON/OFF the RightFax functionality, \
a feature to send email/fax using the RightFax API integrated with symphony')
go

-- Added by issue #1338312
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowPortChangeForCompletedSchedulingTrade')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowPortChangeForCompletedSchedulingTrade', 'N', 'Y', 'A', 'If Y, portfolio of completed scheduling or zero open qty trades can be changed')
go

-- Added by issue #1341218
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'SymphonyShouldUseLogistics')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('SymphonyShouldUseLogistics', 'N', 'Y', 'I', 'This is used to indicate if a client is using Logistics or Allocation.\
This flag drives mainly how the IneosSAPinterface maps SAP date to Symphony movements, \
but in the future can be used for other tasks also')
go

-- Added by issue #1344338
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'CheckForSwiftAndRoutingFields')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CheckForSwiftAndRoutingFields', 'N', 'Y', 'A', 'If Y it checks for non null values in Swift Code and Routing related fields')
go

-- Added by issue #1344750
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'CanOverrideCostRate')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CanOverrideCostRate', 'Y', 'Y', 'A', 'Rate field is enabled when it is Y in the Template costs section of Symphony')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowAnyCrTermToLC')                
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowAnyCrTermToLC', '1', 'Y', 'A', 'Default 1 � Hard Warning  2 - Soft Warning  3 � Disable feature')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowDraftVoucherCreation')                
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowDraftVoucherCreation', 'N', 'Y', 'A', 'This constant indicates whether the draft voucher functionality is allowed or not')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'CreateInstantPrPo')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('CreateInstantPrPo', 'N', 'Y', 'A', 'For creating Preliminary Formula based on actual quantity should create PR/POs \
immediately instead of waiting for Scheduling')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ConsiderFASDifferential')
   INSERT INTO dbo.constants
       (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('ConsiderFASDifferential', 'Y', 'Y', 'A', 'Determines whether a differential amount entered in the trade_order_on_exch.order_price \
should be added to final fill price of the trade item fills of a TAS/FAS future trades. The order price can be Positive/Negative')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'CreateInstantPrPo')
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES ('CreateInstantPrPo', 'N', 'Y', 'A', 'For creating Preliminary Formula based on actual quantity should create PR/POs \
immediately instead of waiting for Scheduling')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'EnableDoddFrankTimestampValidation')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('EnableDoddFrankTimestampValidation', 'N', 'Y', 'A', 'If set to YES, timestamp entry validation will be \
performed on order types configured. Otherwise, existing validation will remain in effect.')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ICEEconfirmIntegration')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ICEEconfirmIntegration', 'N', 'Y', 'A', 'Turning ON this feature will enable the integration of ICE eConfirm service with symphony')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'UsePEBanksForAccountBankInfo')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UsePEBanksForAccountBankInfo', 'N', 'N', 'A', 'Y - will turn enable Bank Selection from PEBank Account, \
N - will have Bank short name as freeform text field')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowVoucherPartialReversal')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowVoucherPartialReversal', 'N', 'Y', 'A', 'It indicates whether few costs on a posted voucher can be reversed')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'CreateReversalVoucher')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('CreateReversalVoucher', 'Y', 'Y', 'A', 'It indicates whether a reversal voucher is needed to be created')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'EnableCopyingOfTradeTermInfoAttributes')                
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('EnableCopyingOfTradeTermInfoAttributes','N', 'Y', 'A', 'While deep copying a trade, if Attribute_value=Y, \
copying of tradeterminfo attributes is allowed, else disallowed')
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowBothPrepaidProvisionalCostsOnSameVoucher') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowBothPrepaidProvisionalCostsOnSameVoucher', 'Y', 'Y', 'A', 'If Y, then both prepayment \
and provisional costs are allowed on voucher')
end
go

-- Added by issue #1350585
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ReadICTSPortfolioFromExternalTrade') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ReadICTSPortfolioFromExternalTrade', 'Y', 'Y', 'A', 'Turning ON this feature enables the \
External Trade Server to read the portfolio num from the external trades and account it directly to the specified port in symphony')
end
go

-- Added by issue #1354085
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowBothPrepaidProvisionalCostsOnSameVoucher') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowBothPrepaidProvisionalCostsOnSameVoucher','Y', 'Y', 'A', 'If Y- then both prepayment and \
provisional costs are allowed on voucher')
end
go

-- Added by issue #1357987
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowDraftVoucherCreation') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowDraftVoucherCreation', 'N', 'Y', 'A', 'This constant indicates whether the draft voucher functionality is allowed or not')
end
go

-- Added by issue #1359674
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'SwapUseSameUomConvForPriceAndQty') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('SwapUseSameUomConvForPriceAndQty','N', 'Y', 'A', 'If set to ''Y'', the UOM conversion rate for pricing is derived from the UOM Conversion Factor field for swaps')
end
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'SwapAllowOverideUomConvFactor') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('SwapAllowOverideUomConvFactor','Y', 'Y', 'A', 'If set to ''Y'', user is allowed to modify the value of the UOM Conversion Factor for swaps in TC')
end
go

-- Added by issue #1358910
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'FEA_APO_MODEL_PARAMETER') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('FEA_APO_MODEL_PARAMETER', '2', 'Y', 'A', 'FEA library APO options model parameter')
end
go

-- Added by issue #1353451
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowDifferentUOMInSwap') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowDifferentUOMInSwap', 'Y', 'Y', 'A', 'If Yes, allow to enter a price UOM in a different type from \
the contract quantity on swaps')
end
go

-- Added by issue #1353842, updated by issue #1363647
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'IncludeCostCodeInTotalPLNoSecCost') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('IncludeCostCodeInTotalPLNoSecCost','', 'N', 'A', 'List of secondary cost codes to be \
included in Total Pl No Secondary cost bucket')
end
go

-- Added by issue #1342966
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'FutRealizedOnLastTradeDate') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('FutRealizedOnLastTradeDate', 'Y', 'N', 'I', 'Cash-settled Futures set PL Realization Date to last trade date')
end
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'SwapRealizedOnLastAccumDate') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('SwapRealizedOnLastAccumDate', 'Y', 'N', 'I', 'Paper Swaps set PL Realization Date to last accumulation date')
end
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'OtcOptRealizedOnExpiryOrExerciseDate') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('OtcOptRealizedOnExpiryOrExerciseDate', 'Y', 'N', 'I', 'Cash-settled OTC Options set PL Realization Date to expiry date or exercise date')
end
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'ExchOptRealizedOnExpiryOrExerciseDate') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('ExchOptRealizedOnExpiryOrExerciseDate', 'Y', 'N', 'I', 'Exchange Listed Options set PL Realization Date to expiry date or exercise date')
end
go


-- Added by issue #1352869
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'AllowZeroQtyPhysicalItems') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AllowZeroQtyPhysicalItems','N', 'Y', 'A', 'If set to YES, zero quantity physical trade items \
will be allowed along with zero quantity parcels. Otherwise, existing validation will remain in effect')
end
go

-- Added by issue #1363449
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'UsePaperConvBBLtoMTForPosConv') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('UsePaperConvBBLtoMTForPosConv', 'N', 'Y', 'A', 'If set to Y, the \
PaperConvBBLtoMT port tag value will be used for position UOM conversion')
end
go

-- Added by issue #1364243
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'IsCostOwnerCodeRequired') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('IsCostOwnerCodeRequired','Y', 'Y', 'A', 'Cost Uploader interface treats the xml \
field cost_owner_code mandatory if this is set to Y else N')
end
go

-- Issue #1364883
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'NumPastDaysToShowPipelineCycles') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('NumPastDaysToShowPipelineCycles', 30, 'Y', 'A', 'Defines how may days earlier cycles has to display')
end
go

-- Issue #1365125
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'PopulateExchangeBrokerOnICETrades') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('PopulateExchangeBrokerOnICETrades','N', 'Y', 'A', 'If Y it populates exchange broker details on outgoing ICE trades else no')
end
go

-- Issue #1365326
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'FallBackForMktLibraries') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('FallBackForMktLibraries', 'N', 'Y', 'A', 'This attribute is to avoid the applying of Fall Back \
For Market Libraries by default')
end
go

-- Issue #1366380
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'SynthRealizationDaysToAdd') 
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('SynthRealizationDaysToAdd', '15', 'Y', 'A', 'Used to set PLRealization date for Future/Inhouse trades')
end
go

-- Issue #1369331
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'LQSCatchUpTimeLimit')
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('LQSCatchUpTimeLimit','30', 'Y', 'A', 'This will define the Max Duration Limit in minutes for \
CatchUpScanner in LQS to process pending sequences')
end
go

-- Issue #1375091
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'EnableCleanZeroCosts')
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values('EnableCleanZeroCosts','N', 'Y', 'A', 'If Y-Allows to clean zero costs through cost panel in Logistics app')
end
go

-- Issue #1364243
IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'IsCostOwnerCodeRequired')
begin
   INSERT INTO dbo.constants(attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values('IsCostOwnerCodeRequired','Y', 'Y', 'A', 'Cost Uploader interface treats the xml \
field cost_owner_code mandatory if this is set to Y else no')
end

if not exists (select 1
               from dbo.constants
                   where attribute_name = 'NumPastDaysToShowPipelineCycles')
begin
   insert into dbo.constants
   (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values('NumPastDaysToShowPipelineCycles',30, 'Y', 'A', 'Defines how may days earlier cycles has to display')
end

if not exists (select 1
               from dbo.constants
                   where attribute_name = 'PopulateExchangeBrokerOnICETrades')
begin
    insert into dbo.constants
    (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
    values('PopulateExchangeBrokerOnICETrades','N', 'Y', 'A', 'If Y it populates exchange broker details on outgoing ICE trades else no')
end


if not exists (select 1
               from dbo.constants
                   where attribute_name = 'AllowEventDateModAfterAlloc')
begin
    insert into dbo.constants
    (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
    values('AllowEventDateModAfterAlloc','N', 'Y', 'A', 'Controls whether the event formula estimate \
date can be modified after trade has been allocated, otherwise it is locked down')
end


if not exists (select 1
               from dbo.constants
                   where attribute_name = 'FallBackForMktLibraries')
begin
    insert into dbo.constants
    (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
    values('FallBackForMktLibraries','N', 'Y', 'A', 'This attribute is to avoid the applying of Fall Back \
For Market Libraries by default')
end

if not exists (select 1
               from dbo.constants
                   where attribute_name = 'LQSCatchUpTimeLimit')
begin
    insert into dbo.constants
    (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
    values('LQSCatchUpTimeLimit','30', 'Y', 'A', 'This will define the Max Duration Limit in minutes for \
CatchUpScanner in LQS to process pending sequences')
end
go

if not exists (select 1
               from dbo.constants
               where attribute_name = 'PetromanCounterpartyAcctNum')
begin
    insert into dbo.constants
          (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
    values('PetromanCounterpartyAcctNum','0', 'Y', 'A', 'Counterparty account number for Petroman Truck Sales')
end
go

if not exists (select 1
               from dbo.constants
               where attribute_name = 'DisallowDiffFixVsFloatQtySwaps')
begin
   insert into dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values('DisallowDiffFixVsFloatQtySwaps','N', 'Y', 'A', 'Y-ERROR out N-Soft waring if \
quantities different for fixed and float legs on swap trades')
end
go

if not exists (select 1
               from dbo.constants
                   where attribute_name = 'DoNotCopyEstEventDateToTitleTranDate')
begin
        insert into dbo.constants
                (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
           values('DoNotCopyEstEventDateToTitleTranDate','N', 'N', 'A', 'This helps to avoid copying of Est \
Event Date in the place of Title Trans Date')
end
go

if not exists (select 1
               from dbo.constants
                   where attribute_name = 'K3eConfirmIntegration')
begin
	insert into dbo.constants
                (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
           values('K3eConfirmIntegration','Y', 'Y', 'A', 'Turning ON this feature will enable the integration \
of K3 ICE eConfirm service with symphony')
end
go

if not exists (select 1
               from dbo.constants
                   where attribute_name = 'EnableCleanZeroCosts')
begin
        insert into dbo.constants
                (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
           values('EnableCleanZeroCosts','N', 'Y', 'A', 'If Y-Allows to clean zero costs through cost panel in Logistics app')
end
go

if not exists (select 1
               from dbo.constants
               where attribute_name = 'EnableBlockTradeCostAutoGen')
begin
   insert into dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values ('EnableBlockTradeCostAutoGen', 'Y', 'Y', 'A', 'Enable the feature to generate brokerage costs for \
the external trades through broker cost autogen process')
end
go

if not exists (select 1
               from dbo.constants
               where attribute_name = 'AllowActualDischargeDatePriorToActualLoadDate')
begin
   insert into dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values('AllowActualDischargeDatePriorToActualLoadDate','N', 'Y', 'A', 'If Y-Allows to have ActualDischargeDate prior to ActualLoadDate \
and shows soft warning error instead of hard stop while saving')
end
go

/* PHIS-81   4/19/2017 */
if not exists (select 1
               from dbo.constants
                   where attribute_name = 'CloseSPPTPPINVROLLCosts')
begin
   insert into dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values('CloseSPPTPPINVROLLCosts','Y', 'Y', 'A', 'This flag is to Close the Costs whose CostTypeCode is \
SPP, TPP, INVROLL. If Y then it sets Cost Status to CLOSED')
end
go

if not exists (select 1
               from dbo.constants
                   where attribute_name = 'AutoGenBrokerCostAtCommodityMarketLevel')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('AutoGenBrokerCostAtCommodityMarketLevel','Y','Y','A','Set to Y if External Trade Server should auto generate the broker costs as per cost codes defined at commodity market level otherwise set to N if it should generate costs as per cost codes defined at commodity level.')
end
go

if not exists (select 1
               from dbo.constants
                   where attribute_name = 'LastEODRunDate')
begin
        insert into dbo.constants
                (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
           values('LastEODRunDate','', 'N', 'I', 'It stores the last EOD pass run date, \
which is used by EDPL to update the latest PL')
end
go

if not exists (select 1
               from dbo.constants
               where attribute_name = 'NextPLDate')
begin
   insert into dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values('NextPLDate','', 'N', 'I', 'It stores the last EOD pass run date, \
which is used by EDPL to update the latest PL')
end
go

if not exists (select 1
               from dbo.constants
               where attribute_name = 'DisallowMultipleTaxAuthoriesOnLocation')
begin
   insert into dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values('DisallowMultipleTaxAuthoriesOnLocation','N', 'Y', 'A', 'ICTSAdmin app don''t allow the user to select more than \
one Tax Authority to an account If this sets to Y')
end
go

if not exists (select 1
               from dbo.constants
               where attribute_name = 'AllowEFPFillModAfterTradeConfirm')
begin
   insert into dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values('AllowEFPFillModAfterTradeConfirm','N', 'Y', 'A', 'Controls whether the EFP trade fills can be \
modified after trade has been confirmed, otherwise it is locked down')
end
go

if not exists (select 1
               from dbo.constants
               where attribute_name = 'PLasExpiredFutureAfterNumDays')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('PLasExpiredFutureAfterNumDays', '90', 'Y', 'A', 'PLasExpiredFutureAfterNumDays')
end
go

if not exists (select 1
               from dbo.constants
                   where attribute_name = 'NonCopyPriceLineItemsToInv')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('NonCopyPriceLineItemsToInv','','Y','A','List of price line item commodity codes, which should not be copied over from physical trade formula to inventory MTM formula.')
end
go

if not exists (select 1
               from dbo.constants
               where attribute_name = 'ExchangeTradeBrokerCostEffDate')
begin
   insert into dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values('ExchangeTradeBrokerCostEffDate','Y', 'Y', 'A', 'If the constant value is Y the cost effective date is same as trades contract date if N then default behavior')
end
go

if not exists (select 1
               from dbo.constants
               where attribute_name = 'ExchangeTradeBrokerCostPayTerm')
begin
   insert into dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values('ExchangeTradeBrokerCostPayTerm','Y', 'Y', 'A', 'If this constant available the payment term on the cost is updated with the constant value otherwise default behavior')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'AccountZeroInventoryWriteOff')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('AccountZeroInventoryWriteOff','N','Y','A','Determines whether inventories with zero position qty, no builds/draws and had adjustments should contribute PL or not')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'PLasSummarySwapAfterNumDays')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('PLasSummarySwapAfterNumDays','90','Y','A','Number of days past the last trade after which PL for swaps will be summarized at position level')
end
go

if NOT EXISTS (select 1
               from dbo.constants
               where attribute_name = 'IgnorePortAndTradeBCompMismatch')
begin
   insert into dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   values('IgnorePortAndTradeBCompMismatch','Y', 'Y', 'A', 'IgnorePortAndTradeBCompMismatch')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'AccountZeroInventoryWriteOff')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('AccountZeroInventoryWriteOff','N','Y','A','Determines whether inventories with zero position qty, no builds/draws and had adjustments should contribute PL or not')
end
go


IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'MsiSkipRefineryInternalTrade')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('MsiSkipRefineryInternalTrade','Y','Y','A','To skip the Internal trade leg which has the counterparty with account name MOH Refinery to be sent through interface')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'RepriceModularFormula')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('RepriceModularFormula','Y','N','A','To enable/disable auto repricing of trades by ALS')
end
go


IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'CostNumbersToSkipNewProration')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('CostNumbersToSkipNewProration',' ','Y','A','Comma separated list of PR cost numbers for which the new PR/PO proration logic will not be applicable')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'allowVoucherZytaxWithWPPCost')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('allowVoucherZytaxWithWPPCost','N','Y','A', 'It is used to decide whether to allow user voucher the WPP cost together with Zytax or Tax costs')
end
go

IF NOT EXISTS (select 1 from dbo.constants
                   where attribute_name = 'JSVATFunctionality')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('JSVATFunctionality','N','N','A', 'It is used to turn on/off FuelQuest or Tax Functionality')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'AllowInternalTradeVouchSeparately')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('AllowInternalTradeVouchSeparately','N','Y','A','When N, payable internal trade cost will be auto vouched while vouching receivable cost. When Y, payable cost needs to be vouched manually')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'InternalTradeTypesAllowVouchSeparately')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('InternalTradeTypesAllowVouchSeparately','PHYSICAL,PARTIAL,EFPEXCH','N','A','List of internal trade types, allowed to vouch the payable and receivable costs separately when BookingCompany and Counterparty are different')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'NoDelivryDrawPickPrevInvPrice')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('NoDelivryDrawPickPrevInvPrice','N','Y','A', 'When enabled, If there are no delivery draws, Prev Inv Avg Price is picked up by Pass')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'SnapshotIgnoreNewTrades')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value,client_edit_ind,attribute_status,attribute_note)
   VALUES('SnapshotIgnoreNewTrades','Y','Y','A','If not available or value=N: update position history with latest position; if value=Y: ignore new trades by computing position for the as of date')
end
go

IF NOT EXISTS (select * from dbo.constants
               where attribute_name = 'AllowedInvPricingTypes')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value ,client_edit_ind,attribute_status,attribute_note)
   VALUES('AllowedInvPricingTypes', 'WACOG,Modified WACOG,MAC,FIFO', 'Y', 'A', 'It stores a list of inventory pricing methods that are allowed to choose by user for each trade order')
end
go

IF NOT EXISTS (select * from dbo.constants
               where attribute_name = 'FIFOMTMOption')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value ,client_edit_ind,attribute_status,attribute_note)
   VALUES('FIFOMTMOption','NOMTM','Y','A','It can have values MTM,NOMTM, BOTH. This controls the available options on UI for storage, transport trade')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'DisplayVoucherExtendedFields')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value ,client_edit_ind,attribute_status,attribute_note)
   VALUES('DisplayVoucherExtendedFields','N','N','A','It indicates whether or not the system should display some extra fields in voucher editor screen')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'DisplayReverseRebookCostEditor')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value ,client_edit_ind,attribute_status,attribute_note)
   VALUES('DisplayReverseRebookCostEditor','N','N','A','It indicates whether or not the system should display the reverse rebook cost editor before reversing a voucher')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'CPInvoiceRefMaxLength')
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value ,client_edit_ind,attribute_status,attribute_note)
   VALUES('CPInvoiceRefMaxLength','16','Y','A','Restriction to Configurable amount of chars for voucher counterparty inv ref')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'PORTFOLIO_TAG_FOR_FIFO')                
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value ,client_edit_ind,attribute_status,attribute_note)
   VALUES('PORTFOLIO_TAG_FOR_FIFO', 'BOOKCOMP', 'Y', 'A', 'This is the entity_tag which if defined will be used to restrict the real portfolios to consider for FIFO in FIFO application.')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'UseMemoForRCCode')                
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value ,client_edit_ind,attribute_status,attribute_note)
   VALUES('UseMemoForRCCode', 'Y', 'Y', 'A', 'It serves as a flag telling whether "RC Memo Code" field in .Net TC is visible or not.')
end
go

IF NOT EXISTS (select 1 from dbo.constants
               where attribute_name = 'AutoAssignLCFromTradeToAllocation')                
begin
   INSERT INTO dbo.constants
         (attribute_name, attribute_value, client_edit_ind, attribute_status, attribute_note)
   VALUES('AutoAssignLCFromTradeToAllocation', 'Y', 'Y', 'A', 'value Y assigns LC on trade to Allocation Automatically')
end
go


