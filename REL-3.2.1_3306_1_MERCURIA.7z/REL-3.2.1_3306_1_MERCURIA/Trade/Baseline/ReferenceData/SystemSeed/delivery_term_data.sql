set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table delivery_term
go

print 'Loading seed reference data into the delivery_term table ...'
go

insert into dbo.delivery_term 
   values('CANDFFO', 'COST AND FREIGHT FREEOUT', 1)
go

insert into dbo.delivery_term 
   values('CANDFLT', 'COST AND FREIGHT LINER TERMS', 1)
go

insert into dbo.delivery_term 
   values('CFR', 'COST AND FREIGHT', 1)
go

insert into dbo.delivery_term 
   values('CIF', 'COST INSURANCE & FREIGHT', 1)
go

insert into dbo.delivery_term 
   values('CIFFO', 'COST INSURANCE FREIGHT FREEOUT', 1)
go

insert into dbo.delivery_term 
   values('CIFLT', 'COST INSURANCE FREIGHT LINER TERMS', 
1)
go

insert into dbo.delivery_term 
   values('CIP', 'CARRIAGE AND INSURANCE PAID TO', 1)
go

insert into dbo.delivery_term 
   values('CPT', 'CARRIAGE PAID TO', 1)
go

insert into dbo.delivery_term 
   values('DAF', 'DELIVERED AT FRONTIER', 1)
go

insert into dbo.delivery_term 
   values('DDP', 'DELIVERED DUTY PAID', 1)
go

insert into dbo.delivery_term 
   values('DDU', 'DELIVERED DUTY UNPAID', 1)
go

insert into dbo.delivery_term 
   values('DEQ', 'DELIVERED EX QUAY (DUTY PAID)', 1)
go

insert into dbo.delivery_term 
   values('DES', 'DELIVERED EX SHIP', 1)
go

insert into dbo.delivery_term 
   values('DLVD', 'DELIVERED', 1)
go

insert into dbo.delivery_term 
   values('EXD/EXWH', 'EX DOCK / EX WAREHOUSE', 1)
go

insert into dbo.delivery_term 
   values('EXDOCK', 'EX DOCK', 1)
go

insert into dbo.delivery_term 
   values('EXPIPE', 'EX PIPE', 1)
go

insert into dbo.delivery_term 
   values('EXSHIP', 'DELIVERED EX SHIP', 1)
go

insert into dbo.delivery_term 
   values('EXSILO', 'EX SILO', 1)
go

insert into dbo.delivery_term 
   values('EXSTOCK', 'EX STOCK', 1)
go

insert into dbo.delivery_term 
   values('EXTANK', 'EX TANK', 1)
go

insert into dbo.delivery_term 
   values('EXWH', 'EX WAREHOUSE', 1)
go

insert into dbo.delivery_term 
   values('EXWORKS', 'EX WORKS', 1)
go

insert into dbo.delivery_term 
   values('FAS', 'FREE ALONG SIDE', 1)
go

insert into dbo.delivery_term 
   values('FCA', 'FREE CARRIAGE', 1)
go

insert into dbo.delivery_term 
   values('FIP', 'FREE IN PIPE', 1)
go

insert into dbo.delivery_term 
   values('FNDTRNSF', 'FUNDS TRANSFER', 1)
go

insert into dbo.delivery_term 
   values('FOB', 'FREE ON BOARD', 1)
go

insert into dbo.delivery_term 
   values('FOBLT', 'FREE ON BOARD LINER TERMS', 1)
go

insert into dbo.delivery_term 
   values('FOBORCIF', 'FOB OR CIF', 1)
go

insert into dbo.delivery_term 
   values('FOBORDVD', 'FOB OR DELIVERED', 1)
go

insert into dbo.delivery_term 
   values('FOBS', 'FREE ON BOARD STOWED', 1)
go

insert into dbo.delivery_term 
   values('FOBST', 'FREE ON BOARD STOWED AND TRIMMED', 1)
go

insert into dbo.delivery_term 
   values('FOBTP', 'FREE ON BOARD TAXES PAID', 1)
go

insert into dbo.delivery_term 
   values('FOR', 'FREE ON RAIL', 1)
go

insert into dbo.delivery_term 
   values('FOT', 'FREE ON TRUCK', 1)
go

insert into dbo.delivery_term 
   values('INSILO', 'IN SILO', 1)
go

insert into dbo.delivery_term 
   values('INSTORE', 'IN STORE', 1)
go

insert into dbo.delivery_term 
   values('INTANK', 'IN TANK', 1)
go

insert into dbo.delivery_term 
   values('INWHSEDU', 'IN WAREHOUSE, DUTY UNPAID', 1)
go

insert into dbo.delivery_term 
   values('NETNOM', 'NET NOMINATION', 1)
go

insert into dbo.delivery_term 
   values('OUTTURN', 'OUTTURN EX DUTY', 1)
go

insert into dbo.delivery_term 
   values('TANKTRAN', 'TANK TRANSFER', 1)
go

