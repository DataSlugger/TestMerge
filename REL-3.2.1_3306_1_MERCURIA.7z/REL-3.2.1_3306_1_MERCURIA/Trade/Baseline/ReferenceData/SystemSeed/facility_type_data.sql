set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the facility_type table ...'
go

IF NOT EXISTS (select 1 from dbo.facility_type
               where facility_type_code = 'STORAGE' )
   INSERT INTO dbo.facility_type(facility_type_code, facility_type_long_name, trans_id)
   VALUES ('STORAGE', 'STORAGE', 1)   
go
