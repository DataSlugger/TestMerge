set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the uic_report_type table ...'
go

if not exists (select 1
               from dbo.uic_report_type
               where oid = 1 and
                     report_type = 'Trade Entry')
   insert into dbo.uic_report_type values(1, 'Trade Entry', 1)
go

if not exists (select 1
               from dbo.uic_report_type
               where oid = 2 and
                     report_type = 'Non-trade costs')
   insert into dbo.uic_report_type values(2, 'Non-trade costs', 1)
go

if not exists (select 1
               from dbo.uic_report_type
               where oid = 3 and
                     report_type = 'Allocation')
   insert into dbo.uic_report_type values(3, 'Allocation', 1)
go

if not exists (select 1
               from dbo.uic_report_type
               where oid = 4 and
                     report_type = 'Vouchers')
   insert into dbo.uic_report_type values(4, 'Vouchers', 1)
go

if not exists (select 1
               from dbo.uic_report_type
               where oid = 5 and
                     report_type = 'All Entities')
   insert into dbo.uic_report_type values(5, 'All Entities', 1)
go

exec refresh_a_last_num 'uic_report_type', 'oid'
go
