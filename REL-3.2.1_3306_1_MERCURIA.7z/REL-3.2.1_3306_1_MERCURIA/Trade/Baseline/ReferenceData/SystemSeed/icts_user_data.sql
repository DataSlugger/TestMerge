set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table icts_user
go

print 'Loading seed reference data into the icts_user table ...'
go

insert into icts_user 
    (user_init, user_last_name, user_first_name, desk_code, loc_code,
     user_logon_id, us_citizen_ind, user_job_title, user_status,
     user_employee_num, email_address, trans_id)
  values('ADM', 'Admin', 'ICTS', 'TC', 'TC', 'icts_admin', 
             'Y', 'NONE', 'A', NULL, NULL, 1)
go

insert into icts_user 
    (user_init, user_last_name, user_first_name, desk_code, loc_code,
     user_logon_id, us_citizen_ind, user_job_title, user_status,
     user_employee_num, email_address, trans_id)
  values('ICA', 'Analyst', 'ICTS', 'TC', 'TC', 'ictsanalyst', 
             'Y', 'ANALYST', 'A', NULL, NULL, 1)
go

insert into icts_user 
    (user_init, user_last_name, user_first_name, desk_code, loc_code,
     user_logon_id, us_citizen_ind, user_job_title, user_status,
     user_employee_num, email_address, trans_id)
  values('ICT', 'Pass', 'Icts', 'TC', 'TC', 'ictspass', 
             'Y', 'TRADER', 'A', NULL, NULL, 1)
go

insert into icts_user 
    (user_init, user_last_name, user_first_name, desk_code, loc_code,
     user_logon_id, us_citizen_ind, user_job_title, user_status,
     user_employee_num, email_address, trans_id)
  values('SVR', 'Server', 'Application', 'TC', 'TC', 'ictssrvr', 
             'Y', 'NONE', 'A', NULL, NULL, 1)
go

insert into icts_user 
    (user_init, user_last_name, user_first_name, desk_code, loc_code,
     user_logon_id, us_citizen_ind, user_job_title, user_status,
     user_employee_num, email_address, trans_id)
  values('ICU', 'Analyst', 'ICTS', 'TC', 'TC', 'icts_user', 
             'Y', 'ANALYST', 'A', NULL, NULL, 1)
go

/* Paul Summermatter   05/24/2005
       The live prices server looks for the following user and uses it for 
       transactions where it (the server) is editing live price information. 
       A db login for this user account does not need to exist (and probably 
       should not exist, because no one should ever actually log in as this 
       user).
*/
insert into icts_user 
    (user_init, user_last_name, user_first_name, desk_code, loc_code,
     user_logon_id, us_citizen_ind, user_job_title, user_status,
     user_employee_num, email_address, trans_id)
  values('LPU', 'Server User', 'Live Prices', 'TC', 'TC', 'liveprices_svr_user', 
             'Y', 'NONE', 'A', NULL, NULL, 1)
go
