set nocount on
set xact_abort on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the function_action table ...'
go

create table #function_action
(   
   oid			        int	identity(1,1) NOT NULL,
   function_num			int	NOT NULL,
   action_name			varchar(255) NOT NULL,
   action_type			varchar(40)	NULL,
)
go

insert into #function_action
   (function_num, action_name, action_type)
   values(255, 'ApproveCost', NULL),
         (606, 'ApproveCost', NULL),
         (269, 'ApproveVoucher', NULL),
         (254, 'CanDoEverything', NULL),
         (113, 'CanDoEverything', NULL),
         (613, 'CanDoEverything', NULL),
         (618, 'CanEditInternalCosts', NULL),
         (166, 'CanEditInternalCosts', NULL),
         (270, 'CanEditInternalCosts', NULL),
         (271, 'HoldVoucher', NULL),
         (215, 'OverridePrice', NULL),
         (243, 'ReverseInvoice', NULL),
         (244, 'ReversePayment', NULL),
         (211, 'ReverseVoucher', NULL),
         (306, 'ReverseVoucher', NULL),
         (272, 'UnholdVoucher', NULL),
         (257, 'UpdateAddlaxCost', NULL),
         (251, 'UpdateCost', NULL),
         (608, 'UpdateCost', NULL),
         (253, 'UpdateVoucher', NULL),
         (273, 'UnapproveVoucher', NULL)
go

/* ********************************************************************* */
/* The code body for adding records into the function_action table       */
/* ********************************************************************* */
print '=> Moving records from the temp table to function_action table...'
go

if exists (select 1 
           from #function_action f 
           where not exists (select 1 
                             from dbo.function_action fa with (nolock)
                             where fa.function_num = f.function_num and 
                                   fa.action_name = f.action_name))
begin
declare	@max_oid			    int,
	      @rows_affected	  int,
	      @trans_id			    int,
        @errcode          int,
        @smsg             varchar(2000)
        
   exec dbo.gen_new_transaction_NOI @app_name = 'DBScript_ADSO-2860'
   select @trans_id = last_num 
   from dbo.icts_trans_sequence
   where oid = 1

   select @max_oid = isnull(max(oid),0) from function_action
   set @rows_affected = 0	
   begin tran
	 begin try	
		 insert into dbo.function_action
		      (oid, function_num, action_name, action_type, trans_id)
		 select @max_oid + oid,
		        function_num,
		        action_name,
		        action_type,
		        @trans_id 
		 from #function_action f
		 where not exists (select 1 
		                   from dbo.function_action fa
		                   where fa.function_num = f.function_num and 
		                         fa.action_name = f.action_name)
		 set @rows_affected = @@rowcount
	 end try
	 begin catch
		 if @@trancount > 0 
			  rollback tran
		 set @errcode = ERROR_NUMBER()
		 set @smsg = ERROR_MESSAGE()
		 RAISERROR('=> Failed to add function_action records due to below error:', 0, 1) with nowait
		 RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
     goto endofscript
	 end catch			
   commit tran
	 if @rows_affected > 0
		  RAISERROR('=> %d function_action records were added successfully!', 0, 1, @rows_affected) with nowait
end
else
	print '=> No rows found to be added into the function_action table'

endofscript:
drop table #function_action
go

exec dbo.refresh_a_last_num 'function_action', 'oid'
go