set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table exceptions_additions
go

print 'Loading seed reference data into the exceptions_additions table ...'
go

insert into dbo.exceptions_additions
     (excp_addns_code, excp_addns_desc, trans_id)
values('ENGLAW', 'English Law', 1)
go
