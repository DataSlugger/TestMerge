set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the icts_product table ...'
go

if object_id('tempdb..#products', 'U') is not null
   exec('drop table #products')
go

create table #products
(
   oid                  int primary key,
   product_id           int not null,
   product_name         varchar(200) not null,
   order_type           varchar(200) not null
)
go

print '=> Load records (1-10) into the temp table ...'
go
insert into #products (oid, order_type, product_id, product_name)
select 1, 'SWAP', 100, '0.5% Sing swap'
union all
select 2, 'SWAP', 101, '0.5% Sing/Dubai'
union all
select 3, 'SWAP', 102, '0.5% Sing/GO 1st'
union all
select 4, 'SWAP', 103, '1% NWE FOB Cargo'
union all
select 5, 'SWAP', 104, '1% NWE FOB'
union all
select 6, 'SWAP', 105, '1% NYH Cargo swap'
union all
select 7, 'SWAP', 106, '1% NYH Cargo'
union all
select 8, 'SWAP', 107, '180cst Sing swap'
union all
select 9, 'SWAP', 108, '180cst Sing/Dubai'
union all
select 10, 'SWAP', 109, '3% USGCW swap'
go

print '=> Load records (11-20) into the temp table ...'
go
insert into #products (oid, order_type, product_id, product_name)
select 11, 'SWAP', 110, '3.5% MED FOB'
union all
select 12, 'SWAP', 111, '3.5% Rdam Barges'
union all
select 13, 'SWAP', 112, '3.5% Rdam'
union all
select 14, 'SWAP', 113, 'Brent 1st line'
union all
select 15, 'SWAP', 114, 'Dated/Brent 1st'
union all
select 16, 'SWAP', 115, 'Dubai 1st line'
union all
select 17, 'SWAP', 118, 'GO 1st line swap'
union all
select 18, 'SWAP', 119, 'GO 1st line/Brent'
union all
select 19, 'SWAP', 120, 'GO MED FOB/GO 1st'
union all
select 20, 'SWAP', 121, 'GO NWE CIF/GO 1st'
go

insert into #products (oid, order_type, product_id, product_name)
select 21, 'SWAP', 122, 'GO Rdam Barges/GO'
union all
select 22, 'SWAP', 123, 'HO 1st line swap'
union all
select 23, 'SWAP', 124, 'HO 1st line/WTI'
union all
select 24, 'SWAP', 128, 'Naphtha NWE CIF'
union all
select 25, 'SWAP', 129, 'Naphtha NWE CIF'
union all
select 26, 'SWAP', 130, 'Naphtha Sing FOB'
union all
select 27, 'SWAP', 131, 'Naphtha Sing FOB'
union all
select 28, 'SWAP', 132, 'NWE CIF Cargo/GO'
union all
select 29, 'SWAP', 134, 'Rdam Barges'
union all
select 30, 'SWAP', 136, 'Rdam Barges'
go

insert into #products (oid, order_type, product_id, product_name)
select 31, 'SWAP', 137, 'Rdam Barges'
union all
select 32, 'SWAP', 138, 'Sing Kero swap'
union all
select 33, 'SWAP', 139, 'Sing Kero/NWE CIF'
union all
select 34, 'SWAP', 140, 'Sing Regrade swap'
union all
select 35, 'SWAP', 141, 'Tapis swap'
union all
select 36, 'SWAP', 142, 'USGC 54 Jet/HO 1st'
union all
select 37, 'SWAP', 143, 'USGC 54 Jet/WTI'
union all
select 38, 'SWAP', 145, 'USGC Conv Unl'
union all
select 39, 'SWAP', 146, 'USGC Conv Unl'
union all
select 40, 'SWAP', 147, 'USGC No. 2/HO 1st'
go

insert into #products (oid, order_type, product_id, product_name)
select 41, 'SWAP', 148, 'USGC No. 2/WTI 1st'
union all
select 42, 'SWAP', 149, 'WTI 1st line swap'
union all
select 43, 'SWAP', 150, 'WTI 1st line'
union all
select 44, 'SWAP', 151, 'WTI BAS'
union all
select 45, 'SWAP', 152, 'Dated Brent'
union all
select 46, 'SWAP', 153, 'USGC 54 Jet'
union all
select 47, 'SWAP', 154, 'USGC No. 2 HO Swap'
union all
select 48, 'SWAP', 155, 'USGC Conv Unl 87'
union all
select 49, 'SWAP', 156, 'NWE CIF Cargo'
union all
select 50, 'SWAP', 157, 'MED Cargo FOB swap'
go

insert into #products (oid, order_type, product_id, product_name)
select 51, 'SWAP', 158, 'Brent/Dubai 1st'
union all
select 52, 'SWAP', 159, 'Tapis/Brent 1st'
union all
select 53, 'SWAP', 160, '3% USGCW swap/WTI'
union all
select 54, 'SWAP', 161, 'Sing Kero/Dubai'
union all
select 55, 'SWAP', 162, 'NWE CIF'
union all
select 56, 'SWAP', 163, '1% NYH Cargo'
union all
select 57, 'SWAP', 164, '180cst Sing'
union all
select 58, 'SWAP', 165, '1% Rdam Barges/1%'
union all
select 59, 'SWAP', 166, 'Rdam Barges'
union all
select 60, 'SWAP', 167, 'MED Cargo FOB/GO '
go

insert into #products (oid, order_type, product_id, product_name)
select 61, 'SWAP', 168, '1% Rdam Barges'
union all
select 62, 'SWAP', 169, 'NWE CIF Premium'
union all
select 63, 'SWAP', 171, 'Oman MOG OSP'
union all
select 64, 'SWAP', 174, 'OMAN MOG OSP/Dubai'
union all
select 65, 'SWAP', 175, '10ppm Rdam'
union all
select 66, 'SWAP', 176, 'ULSD NWE CIF/GO'
union all
select 67, 'SWAP', 177, 'NYH Barges No.'
union all
select 68, 'SWAP', 178, 'NYH Barges LS No.'
union all
select 69, 'SWAP', 180, 'NYH Barges Unl 87/'
union all
select 70, 'SWAP', 182, 'Sing Kero/Brent'
go

insert into #products (oid, order_type, product_id, product_name)
select 71, 'SWAP', 183, '180cst Sing/380cst'
union all
select 72, 'SWAP', 184, '380cst Sing swap'
union all
select 73, 'SWAP', 185, 'Tapis/Dubai swap'
union all
select 74, 'SWAP', 186, 'ULSD NWE CIF'
union all
select 75, 'SWAP', 187, '1% NWE FOB'
union all
select 76, 'SWAP', 188, '1% NWE FOB'
union all
select 77, 'SWAP', 189, 'WTI 1st Line Fin'
union all
select 78, 'SWAP', 190, 'Brent 1st Line Fin'
union all
select 79, 'SWAP', 191, 'GO 1st Line Fin'
union all
select 80, 'SWAP', 192, 'HO 1st Line Fin'
go

insert into #products (oid, order_type, product_id, product_name)
select 81, 'SWAP', 193, '1% NYH Cargo Fin'
union all
select 82, 'SWAP', 194, '180cst Sing Fin'
union all
select 83, 'SWAP', 195, '3.5% Rdam Barges'
union all
select 84, 'SWAP', 196, 'Sing Kero Fin'
union all
select 85, 'SWAP', 197, 'Mogas 95R UL 10ppm'
union all
select 86, 'SWAP', 198, 'Mogas 95R UL 10ppm'
union all
select 87, 'SWAP', 199, 'Oman 1st line swap'
union all
select 88, 'SWAP', 200, 'Mogas 95R UL 50ppm'
union all
select 89, 'SWAP', 201, 'Mogas 95R UL NWE'
union all
select 90, 'SWAP', 202, 'Mogas 95R UL NWE'
go

insert into #products (oid, order_type, product_id, product_name)
select 91, 'SWAP', 203, '3% NYH Cargo swap'
union all
select 92, 'SWAP', 204, '3.5% MED FOB Cargo'
union all
select 93, 'SWAP', 205, 'GO MED FOB swap'
union all
select 94, 'SWAP', 206, 'GO MED CIF swap'
union all
select 95, 'SWAP', 207, 'Mogas 95R UL10ppm'
union all
select 96, 'SWAP', 210, 'Dated Brent/Dubai'
union all
select 97, 'SWAP', 212, '1% NWE CIF Cargo'
union all
select 98, 'SWAP', 213, '3.5% NWE CIF Cargo'
union all
select 99, 'SWAP', 214, '1% MED CIF Cargo'
union all
select 100, 'SWAP', 215, 'USGC LS No. 2 HO'
go

insert into #products (oid, order_type, product_id, product_name)
select 101, 'SWAP', 216, 'USGC 54 Jet (WB)'
union all
select 102, 'SWAP', 217, '2.2% NYH Cargo'
union all
select 103, 'SWAP', 220, '0.5% Sing Fin'
union all
select 104, 'SWAP', 222, 'NWE CIF Cargo Fin'
union all
select 105, 'SWAP', 223, 'Dated Brent Fin'
union all
select 106, 'SWAP', 224, 'GO 1st line/Brent'
union all
select 107, 'SWAP', 226, 'GO MED CIF/GO MED'
union all
select 108, 'SWAP', 227, '.3% HP NYH Cargo'
union all
select 109, 'SWAP', 228, '.7% NYH Cargo swap'
union all
select 110, 'SWAP', 229, '.3% HP NYH'
go

insert into #products (oid, order_type, product_id, product_name)
select 111, 'SWAP', 230, 'GO MED CIF/GO MED'
union all
select 112, 'SWAP', 231, '50ppm ULSD MED'
union all
select 113, 'SWAP', 232, '50ppm ULSD MED'
union all
select 114, 'SWAP', 233, '50ppm ULSD NWE'
union all
select 115, 'SWAP', 234, '1% MED CIF'
union all
select 116, 'SWAP', 235, '1% MED CIF'
union all
select 117, 'SWAP', 236, '50ppm ULSD MED'
union all
select 118, 'SWAP', 237, '50ppm ULSD MED'
union all
select 119, 'SWAP', 238, 'Carbob-R swap'
union all
select 120, 'SWAP', 239, 'Carb No. 2 HO swap'
go

insert into #products (oid, order_type, product_id, product_name)
select 121, 'SWAP', 240, 'Carbob-R/HU 1st'
union all
select 122, 'SWAP', 241, 'Carb No. 2/HO 1st'
union all
select 123, 'SWAP', 242, 'USWC LA Jet'
union all
select 124, 'SWAP', 243, 'USGC LS No. 2 HO'
union all
select 125, 'SWAP', 244, 'USWC LA Jet/HO 1st'
union all
select 126, 'SWAP', 245, 'Urals (RCMB)/Dated'
union all
select 127, 'SWAP', 247, 'GO MED CIF/GO 1st'
union all
select 128, 'SWAP', 248, '1% Rdam'
union all
select 129, 'SWAP', 249, '1% NYH Cargo/1%'
union all
select 130, 'SWAP', 250, 'Chicago LS Diesel'
go

insert into #products (oid, order_type, product_id, product_name)
select 131, 'SWAP', 251, 'WTI 1st line'
union all
select 132, 'SWAP', 252, 'RB 1st line swap'
union all
select 133, 'SWAP', 253, 'Naphtha Sing FOB'
union all
select 134, 'SWAP', 254, 'USGC Conv Unl'
union all
select 135, 'SWAP', 255, 'Mogas 92 UL Sing'
union all
select 136, 'SWAP', 256, 'USGC Conv Unl'
union all
select 137, 'SWAP', 257, 'Carbob-R/RB 1st'
union all
select 138, 'SWAP', 258, 'RB 1st line/HO 1st'
union all
select 139, 'SWAP', 259, 'RB 1st line/WTI'
union all
select 140, 'SWAP', 260, 'USGC Conv Unl'
go

insert into #products (oid, order_type, product_id, product_name)
select 141, 'SWAP', 262, 'NYH Barges Unl   '
union all
select 142, 'SWAP', 263, 'RB 1st Line Fin'
union all
select 143, 'SWAP', 264, 'Oman 1st'
union all
select 144, 'SWAP', 265, 'Rdam Barges FOB'
union all
select 145, 'SWAP', 266, '3% USGCW/3.5% Rdam'
union all
select 146, 'SWAP', 268, 'GO Rdam Barges'
union all
select 147, 'SWAP', 269, 'NYH Cargo No. 2/HO'
union all
select 148, 'SWAP', 270, '50ppm ULSD NWE CIF'
union all
select 149, 'SWAP', 271, '10ppm ULSD Rdam'
union all
select 150, 'SWAP', 272, 'ULSD USGC (PL)/HO'
go

insert into #products (oid, order_type, product_id, product_name)
select 151, 'SWAP', 273, 'Dated Brent/Platts'
union all
select 152, 'SWAP', 274, 'Dated Brent/Platts'
union all
select 153, 'SWAP', 275, 'Dated Brent/Platts'
union all
select 154, 'SWAP', 276, 'Dated Brent/Platts'
union all
select 155, 'SWAP', 277, 'Dated Brent/Platts'
union all
select 156, 'SWAP', 278, 'Dated Brent/Platts'
union all
select 157, 'SWAP', 279, 'Dated Brent/Platts'
union all
select 158, 'SWAP', 280, 'Dated Brent/Platts'
union all
select 159, 'SWAP', 281, 'Dated Brent/Platts'
union all
select 160, 'SWAP', 282, 'Dated Brent/Platts'
go

insert into #products (oid, order_type, product_id, product_name)
select 161, 'SWAP', 283, 'Dated Brent/Platts'
union all
select 162, 'SWAP', 284, 'Dated Brent/Platts'
union all
select 163, 'SWAP', 285, '10ppm ULSD NWE'
union all
select 164, 'SWAP', 286, 'Mogas 97 UL Sing'
union all
select 165, 'SWAP', 287, 'Sing Kero/GO 1st'
union all
select 166, 'SWAP', 288, 'RBOB 1st'
union all
select 167, 'SWAP', 289, '50ppm ULSD MED CIF'
union all
select 168, 'SWAP', 290, 'LA Jet Pipe'
union all
select 169, 'SWAP', 291, 'ULSD USGC (PL)'
union all
select 170, 'SWAP', 292, 'Naphtha Japan swap'
go

insert into #products (oid, order_type, product_id, product_name)
select 171, 'SWAP', 293, '.7% NYH Cargo/1%'
union all
select 172, 'SWAP', 294, 'MED FOB Prem UL'
union all
select 173, 'SWAP', 295, 'Urals (RCMB) swap'
union all
select 174, 'SWAP', 296, 'NYH Barges 54'
union all
select 175, 'SWAP', 297, '1% MED FOB Cargo'
union all
select 176, 'SWAP', 298, 'Dubai 1st line Fin'
union all
select 177, 'SWAP', 299, '380cst Sing Fin'
union all
select 178, 'SWAP', 1500, 'GO 0.1 Rdam'
union all
select 179, 'SWAP', 1501, 'MED CIF Premium'
union all
select 180, 'SWAP', 1502, 'GO 0.1 NWE CIF/GO'
go

insert into #products (oid, order_type, product_id, product_name)
select 181, 'SWAP', 1503, '2.2% NYH Cargo/3%'
union all
select 182, 'SWAP', 1504, '1% MED FOB'
union all
select 183, 'SWAP', 1505, '1% NWE CIF'
union all
select 184, 'SWAP', 1506, '3.5% MED CIF/3.5%'
union all
select 185, 'SWAP', 1507, 'Naphtha'
union all
select 186, 'SWAP', 1508, 'GO 0.1 MED FOB/GO'
union all
select 187, 'SWAP', 1509, 'GO 0.1 MED FOB'
union all
select 188, 'SWAP', 1510, 'GO 0.1 MED CIF'
union all
select 189, 'SWAP', 1511, 'GO 0.1 MED CIF/GO'
union all
select 190, 'SWAP', 1512, 'GO 0.1 MED CIF/GO'
go

insert into #products (oid, order_type, product_id, product_name)
select 191, 'SWAP', 1513, 'GO 0.1 MED CIF/GO'
union all
select 192, 'SWAP', 1514, 'GO 0.1 Rdam Barges'
union all
select 193, 'SWAP', 1515, 'Rdam Barges FOB/GO'
union all
select 194, 'SWAP', 1516, 'Rdam Barges FOB'
union all
select 195, 'SWAP', 1517, '180cst Sing/3%'
union all
select 196, 'SWAP', 1518, 'USGC 54 Jet Option'
union all
select 197, 'SWAP', 1519, '1% MED CIF'
union all
select 198, 'SWAP', 1520, '3.5% MED CIF swap'
union all
select 199, 'SWAP', 1521, 'GO 0.1 NWE CIF'
union all
select 200, 'SWAP', 1522, '10ppm ULSD NWE CIF'
go

insert into #products (oid, order_type, product_id, product_name)
select 201, 'SWAP', 1523, 'Urals Rdam Dated'
union all
select 202, 'SWAP', 1524, 'WTS swap'
union all
select 203, 'SWAP', 1525, '50ppm ULSD MED FOB'
union all
select 204, 'SWAP', 1526, 'GO 0.1 Rdam'
union all
select 205, 'SWAP', 1527, '10ppm ULSD MED'
union all
select 206, 'SWAP', 1528, 'NW Shelf swap'
union all
select 207, 'SWAP', 1529, '380cst Sing/3.5%'
union all
select 208, 'SWAP', 1530, 'MED FOB Prem UL'
union all
select 209, 'SWAP', 1531, 'MED FOB Prem UL'
union all
select 210, 'SWAP', 1532, '3% NYH Cargo/3%'
go

insert into #products (oid, order_type, product_id, product_name)
select 211, 'SWAP', 1533, 'Naphtha'
union all
select 212, 'SWAP', 1534, 'Euro-Bob Oxy swap'
union all
select 213, 'SWAP', 1535, 'Euro-Bob Oxy/Brent'
union all
select 214, 'SWAP', 1536, 'Euro-Bob'
union all
select 215, 'SWAP', 1537, 'RBOB 1st'
union all
select 216, 'SWAP', 1538, 'MED FOB Prem UL'
union all
select 217, 'SWAP', 1539, 'COL ULSD/HO 1st'
union all
select 218, 'SWAP', 1540, 'COL ULSD swap'
union all
select 219, 'SWAP', 1541, 'COL JET 54/HO 1st'
union all
select 220, 'SWAP', 1543, 'EIA REG swap'
go

insert into #products (oid, order_type, product_id, product_name)
select 221, 'SWAP', 1544, 'EIA DIESEL swap'
union all
select 222, 'SWAP', 1545, 'HO 1st line/GO 1st'
union all
select 223, 'SWAP', 1546, 'RME Rdam Barges'
union all
select 224, 'SWAP', 1547, 'FAME 0 Rdam Barges'
union all
select 225, 'SWAP', 1548, 'RB Futures'
union all
select 226, 'SWAP', 1549, 'WTI Futures'
union all
select 227, 'SWAP', 1550, 'WTI Futures Option'
union all
select 228, 'SWAP', 1552, 'COL HO'
union all
select 229, 'SWAP', 1553, 'COL HO/HO 1st line'
union all
select 230, 'SWAP', 1554, 'NY ULSD/HO 1st'
go

insert into #products (oid, order_type, product_id, product_name)
select 231, 'SWAP', 1555, 'COL JET54'
union all
select 232, 'SWAP', 1556, 'COL UNL87'
union all
select 233, 'SWAP', 1557, 'COL UNL87/WTI 1st'
union all
select 234, 'SWAP', 1558, 'COL UNL87/RB 1st '
union all
select 235, 'SWAP', 1559, 'Dated Brent/Brent'
union all
select 236, 'SWAP', 1560, 'HO Futures Option'
union all
select 237, 'SWAP', 1561, '3% USGCW Fin'
union all
select 238, 'SWAP', 1562, 'Brent Futures'
union all
select 239, 'SWAP', 1563, 'Mogas 95 UL Sing'
union all
select 240, 'SWAP', 1564, '.3% LP NYH Cargo'
go

insert into #products (oid, order_type, product_id, product_name)
select 241, 'SWAP', 1565, 'Naphtha NWE CIF'
union all
select 242, 'SWAP', 1566, 'Naphtha Japan Fin'
union all
select 243, 'SWAP', 1567, 'NYH Barges HO/HO'
union all
select 244, 'SWAP', 1569, 'WTI swap'
union all
select 245, 'SWAP', 1570, 'Mogas 92 UL'
union all
select 246, 'SWAP', 1571, 'USGC 54 Jet'
union all
select 247, 'SWAP', 1572, 'GO Futures'
union all
select 248, 'SWAP', 1573, 'HO Futures'
union all
select 249, 'SWAP', 1574, 'USGC No. 2(WB)/WTI'
union all
select 250, 'SWAP', 1575, '10 ppm UK ULSD NWE'
go

insert into #products (oid, order_type, product_id, product_name)
select 251, 'SWAP', 1576, 'FOB NWE Cargo'
union all
select 252, 'SWAP', 1577, 'GO Arab Gulf FOB '
union all
select 253, 'SWAP', 1578, 'GO .05 Arab Gulf'
union all
select 254, 'SWAP', 1579, 'GO .25 Arab Gulf'
union all
select 255, 'SWAP', 1580, 'GO Futures Option'
union all
select 256, 'SWAP', 1581, 'DME Oman 1st line'
union all
select 257, 'SWAP', 1582, 'DME Oman 1st'
union all
select 258, 'SWAP', 1583, 'Indo swap'
union all
select 259, 'SWAP', 1584, 'Naphtha'
union all
select 260, 'SWAP', 1585, 'LLS DIFF swap'
go

insert into #products (oid, order_type, product_id, product_name)
select 261, 'SWAP', 1586, 'Mars DIFF swap'
union all
select 262, 'SWAP', 1587, 'WTI 1st Line Fin'
union all
select 263, 'SWAP', 1588, 'WTI ICE Futures'
union all
select 264, 'SWAP', 1589, 'WTI ICE 1st line'
union all
select 265, 'SWAP', 1591, 'Upper Zakum 1st'
union all
select 266, 'SWAP', 1592, 'Tokyo Bay swap'
union all
select 267, 'SWAP', 1593, 'Tokyo Bay Kero'
union all
select 268, 'SWAP', 1594, '0.001% GO Tokyo'
union all
select 269, 'SWAP', 1595, '0.1% AFO Toyko Bay'
union all
select 270, 'SWAP', 1596, '1% AFO Toyko Bay'
go

insert into #products (oid, order_type, product_id, product_name)
select 271, 'SWAP', 1597, '0.3% LSCFO Toyko'
union all
select 272, 'SWAP', 1598, '3% HSCFO Toyko Bay'
union all
select 273, 'SWAP', 1599, '380cst Sing/Dubai'
union all
select 274, 'SWAP', 1600, '0.5% Sing/HO 1st'
union all
select 275, 'SWAP', 1601, 'FAME 0 Rdam'
union all
select 276, 'SWAP', 1602, 'RME Rdam Barges'
union all
select 277, 'SWAP', 1603, 'ULSD USGC (PL)/WTI'
union all
select 278, 'SWAP', 1604, 'Mogas 92 UL'
union all
select 279, 'SWAP', 1605, 'Urals (RDAM)/Dated'
union all
select 280, 'SWAP', 1606, 'RB 1st line/Brent'
go

insert into #products (oid, order_type, product_id, product_name)
select 281, 'SWAP', 1607, '10ppm ULSD MED CIF'
union all
select 282, 'SWAP', 1608, 'JCC Provisional'
union all
select 283, 'SWAP', 1609, 'JCC 9 Digit'
union all
select 284, 'SWAP', 1610, 'JCC Detailed swap'
union all
select 285, 'SWAP', 1611, 'JCC Fixed swap'
union all
select 286, 'SWAP', 1612, 'JCC 9 Digit'
union all
select 287, 'SWAP', 1613, 'JCC Detailed USD'
union all
select 288, 'SWAP', 1614, 'JCC Fixed USD swap'
union all
select 289, 'SWAP', 1615, '3.5% MED FOB'
union all
select 290, 'SWAP', 1616, 'GO 0.1 NWE'
go

insert into #products (oid, order_type, product_id, product_name)
select 291, 'SWAP', 1617, 'USGC Conv Unl 87'
union all
select 292, 'SWAP', 1618, 'Mogas 92 UL'
union all
select 293, 'SWAP', 1619, 'GO 50ppm Rdam'
union all
select 294, 'SWAP', 1620, 'ULSD USGC (WB)'
union all
select 295, 'SWAP', 1621, 'ULSD USGC'
union all
select 296, 'SWAP', 1622, 'Minas/Brent 1st'
union all
select 297, 'SWAP', 1623, 'USGC Conv Unl 87'
union all
select 298, 'SWAP', 1624, 'WTI 1st Line vs'
union all
select 299, 'SWAP', 1625, 'WTI 1st Line vs'
union all
select 300, 'SWAP', 1626, 'WTI 1st Line vs'
go

insert into #products (oid, order_type, product_id, product_name)
select 301, 'SWAP', 1627, 'WTI 1st Line vs'
union all
select 302, 'SWAP', 1628, 'WTI 1st Line vs'
union all
select 303, 'SWAP', 1629, 'WTI 1st Line vs'
union all
select 304, 'SWAP', 1630, 'Group 3 Unl/RB 1st'
union all
select 305, 'SWAP', 1631, 'GO 1st Line Fin'
union all
select 306, 'SWAP', 1632, 'Rdam Barges'
union all
select 307, 'SWAP', 1633, '10ppm ULSD MED CIF'
union all
select 308, 'SWAP', 1634, '10ppm ULSD MED FOB'
union all
select 309, 'SWAP', 1635, 'Chicago Ethanol'
union all
select 310, 'SWAP', 1636, 'HO 1st line/Brent'
go

insert into #products (oid, order_type, product_id, product_name)
select 311, 'SWAP', 1637, '3% USGCW'
union all
select 312, 'SWAP', 1638, 'ULSD USGC (WB)'
union all
select 313, 'SWAP', 1639, 'WTI DIFF swap'
union all
select 314, 'SWAP', 1640, 'LLS/WTI FORM swap'
union all
select 315, 'SWAP', 1641, 'LSGO 1st line swap'
union all
select 316, 'SWAP', 1642, 'LSGO 1st line/GO'
union all
select 317, 'SWAP', 1643, 'Brent NX 1st line'
union all
select 318, 'SWAP', 1644, 'Brent NX 1st Line'
union all
select 319, 'SWAP', 1645, 'ESPO Swap'
union all
select 320, 'SWAP', 1646, 'ESPO DIFF swap'
go

insert into #products (oid, order_type, product_id, product_name)
select 321, 'SWAP', 1647, 'TMX WCS 1a swap'
union all
select 322, 'SWAP', 1648, 'TMX WCS 1b swap'
union all
select 323, 'SWAP', 1649, 'MED Cargo FOB'
union all
select 324, 'SWAP', 1650, 'T2 German Ethanol'
union all
select 325, 'SWAP', 1651, 'Naphtha NWE CIF'
union all
select 326, 'SWAP', 1652, 'HO 1st line/Platts'
union all
select 327, 'SWAP', 1653, 'RB 1st line/Platts'
union all
select 328, 'SWAP', 1654, 'MARS 1st line/WTI'
go

insert into #products (oid, order_type, product_id, product_name)
select 329, 'EFP', 1400, 'Cycle PL EFP FP'
union all
select 330, 'EFP', 1403, 'Cycle PL EFP ID'
union all
select 331, 'EFP', 1404, 'Cycle PL EFP TBP'
union all
select 332, 'EFP', 1405, 'Date PL EFP FP'
union all
select 333, 'EFP', 1408, 'Date PL EFP ID'
union all
select 334, 'EFP', 1409, 'Date PL EFP TBP'
go

insert into #products (oid, order_type, product_id, product_name)
select 335, 'Physical', 1401, 'Cycle PL FP'
union all
select 336, 'Physical', 1402, 'Cycle PL ID'
union all
select 337, 'Physical', 1406, 'Date PL FP'
union all
select 338, 'Physical', 1407, 'Date PL ID'
union all
select 339, 'Physical', 1410, 'Cycle PL ID Event'
union all
select 340, 'Physical', 1411, 'Date PL ID Event'
go

/* More records can be added here */



print ''
print '=> Moving records in temp tabel to the icts_product table ...'
go


declare @rows_affected   int
        
begin tran
begin try
  insert into dbo.icts_product
     (product_id,
      product_name,
      order_type,
      trans_id)
  select product_id,
         product_name,
         order_type,
         1
  from #products a
  where not exists (select 1
                    from dbo.icts_product b
                    where a.product_id = b.product_id)
  select @rows_affected = @@rowcount
end try
begin catch
  if @@trancount > 0
     rollback tran
  print '=> Failed to add new records into the icts_product table due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch
commit tran
if @rows_affected > 0
   print '=> ' + cast(@rows_affected as varchar) + ' records were added into the icts_product table'
else
   print '=> No new records were added into the icts_product table'
   
endofscript:
go

print ' '
print 'The following records were not loaded into the icts_product table ...'
go

select substring(order_type, 1, 30) as order_type, 
       product_id, 
       substring(product_name, 1, 60) as product_name
from #products a
where not exists (select 1
                  from dbo.icts_product b
                  where a.product_id = b.product_id)
order by order_type, product_id
go

print ' '
print 'The following records in the icts_product table have different product names from source data set ...'
go

select substring(order_type, 1, 30) as order_type, 
       product_id, 
       substring(product_name, 1, 60) as product_name 
from dbo.icts_product a
where exists (select 1
              from #products b
              where a.product_id = b.product_id and
                    a.order_type = b.order_type and
                    a.product_name <> b.product_name)
order by order_type, product_id
go

print ''
print 'Dropping temp table #products ...'
go

if object_id('tempdb..#products', 'U') is not null
   exec('drop table #products')
go
