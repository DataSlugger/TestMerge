set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table icts_user_permission
go

print 'Loading permission data into the icts_user_permission table for standard users ...'
go

/* ********************************************************** */

if object_id('dbo.xxx_user_perms_991919') is not null
   drop table dbo.xxx_user_perms_991919
go

create table dbo.xxx_user_perms_991919
(
   oid           numeric(18, 0) IDENTITY,
   user_init     varchar(3) not null,
   function_num  int not null,
   perm_level    varchar(8) not null
)
go  

/* ********************************************************** */

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 2, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 3, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 4, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 5, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 6, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 11, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 12, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 13, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 16, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 17, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 18, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 19, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 20, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 21, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 22, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 23, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 24, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 31, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 32, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 33, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 34, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 41, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 42, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 43, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 100, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 101, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 102, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 103, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 191, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 192, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 193, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 194, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 195, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 197, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 198, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 201, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 202, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 203, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 204, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 205, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 206, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 207, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 210, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 211, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 212, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 214, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 215, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 216, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 220, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 221, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 222, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 230, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 231, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 301, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 302, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 304, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 305, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 306, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 308, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 309, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 310, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 311, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 312, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 313, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 400, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 401, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 402, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 601, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 602, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 603, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 604, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 605, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 700, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 701, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 702, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 703, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 704, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 800, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 810, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 820, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 821, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 822, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 823, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 830, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 840, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 901, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 902, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 903, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 904, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 905, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 906, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1000, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1001, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1002, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1003, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1100, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1200, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1201, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1202, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1203, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1214, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1215, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1216, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1217, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1218, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1300, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 1301, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICT', 4400, 'ANY')
go

/* ********************************************************** */

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 2, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 3, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 4, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 5, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 11, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 12, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 13, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 16, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 17, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 18, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 19, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 20, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 21, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 22, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 23, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 24, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 31, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 32, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 33, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 34, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 41, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 42, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 43, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 100, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 101, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 102, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 103, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 191, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 192, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 193, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 194, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 195, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 197, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 198, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 201, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 202, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 203, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 204, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 205, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 206, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 207, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 210, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 211, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 212, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 214, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 215, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 216, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 220, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 221, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 222, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 230, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 231, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 262, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 301, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 302, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 304, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 305, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 306, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 308, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 309, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 310, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 311, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 312, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 313, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 400, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 401, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 402, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 601, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 602, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 603, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 604, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 605, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 700, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 701, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 702, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 703, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 704, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 800, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 810, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 820, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 821, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 822, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 823, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 830, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 840, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 901, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 902, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 903, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 904, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 905, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 906, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1000, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1001, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1002, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1003, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1100, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1200, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1201, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1202, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1203, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1214, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1215, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1216, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1217, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1218, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1300, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('SVR', 1301, 'ANY')
go


/* ******************* ICU ********************* */
insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ADM', 4000, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 2, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 3, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 4, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 5, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 6, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 11, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 12, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 13, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 16, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 17, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 18, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 19, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 20, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 21, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 22, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 23, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 24, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 31, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 32, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 33, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 34, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 41, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 42, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 43, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 100, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 101, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 102, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 103, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 191, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 192, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 193, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 194, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 195, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 197, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 198, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 201, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 202, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 203, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 204, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 205, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 206, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 207, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 210, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 211, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 212, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 214, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 215, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 216, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 220, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 221, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 222, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 230, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 231, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 301, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 302, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 304, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 305, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 306, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 308, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 309, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 310, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 311, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 312, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 313, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 400, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 401, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 402, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 601, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 602, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 603, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 604, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 605, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 700, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 701, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 702, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 703, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 704, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 800, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 810, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 820, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 821, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 822, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 823, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 830, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 840, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 901, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 902, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 903, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 904, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 905, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 906, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1000, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1001, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1002, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1003, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1100, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1200, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1201, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1202, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1203, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1214, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1215, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1216, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1217, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1218, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1300, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1301, 'ANY')
go

/****  Java Maint App Perms   ****/

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1598, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1599, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1600, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1601, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1602, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1603, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1604, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1605, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1606, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1607, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1608, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1620, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1621, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1622, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1623, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1624, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1625, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1626, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1627, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1628, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 1629, 'ANY')
go

insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ICU', 3070, 'ANY')
go 

/* ******************* ADM ********************* */
insert into xxx_user_perms_991919 (user_init, function_num, perm_level) 
  values('ADM', 4000, 'ANY')
go


/* ********************************************************* */

declare @oid           int,
        @maxoid        int,
        @smsg          varchar(255),
        @function_num  int,
        @user_init     varchar(3),
        @perm_level    varchar(8),
        @fdv_id        int,
        @row_existed   int,
        @errcode       int

   select @oid = 1
   select @maxoid = max(oid)
   from xxx_user_perms_991919

   while @oid <= @maxoid
   begin
      select @user_init = user_init,
             @function_num = function_num,
             @perm_level = perm_level
      from xxx_user_perms_991919
      where oid = @oid
      select @row_existed = @@rowcount,
             @errcode = @@error
      if @errcode > 0
         break
      if @row_existed > 0
      begin
         select @fdv_id = fdv_id
         from function_detail fd,
              function_detail_value fdv
         where fd.function_num = @function_num and
               fd.entity_name = 'LEVEL' and
               fd.fd_id = fdv.fd_id and
               fdv.attr_value = @perm_level
         select @row_existed = @@rowcount,
                @errcode = @@error
         if @errcode > 0
            break
         if @row_existed = 0
         begin
            select @smsg = 'Failed to get fdv_id for function #' + convert(varchar, @function_num) + '/perm_level ''' + @perm_level + '''!'
            print @smsg
            break 
         end
         begin
            if not exists (select 1
                           from icts_user_permission
                           where user_init = @user_init and
                                 fdv_id = @fdv_id)
            begin
               begin tran
               insert into icts_user_permission
                  (user_init, fdv_id, trans_id)
                 values(@user_init, @fdv_id, 1)
               select @row_existed = @@rowcount,
                      @errcode = @@error
               if @errcode > 0 or @row_existed = 0
               begin
                  rollback tran
                  if @errcode > 0
                     break
               end
               else
               begin
                  commit tran
                  select @smsg = '=> icts_user_permission: (user_init ''' + @user_init + ''', '
                  select @smsg = @smsg + 'fdv_id #' + convert(varchar, @fdv_id) + ', '
                  select @smsg = @smsg + 'function #' + convert(varchar, @function_num) + ', '
                  select @smsg = @smsg + 'perm_level ''' + @perm_level + ''') was added ...'
                  print @smsg
               end
            end
         end
      end

      select @oid = @oid + 1
   end /* while */
go

drop table xxx_user_perms_991919
go
