set nocount on

set QUOTED_IDENTIFIER ON
go

print '=> Adding a TEMPLATE trade_item record if NOT EXISTS ...'
go

if not exists (select 1
               from dbo.trade_item
               where trade_num = 0 and
                     order_num = 0 and
		                 item_num = 0)
begin
   insert into dbo.trade_item
        (trade_num, order_num, item_num, item_type, avg_price, real_port_num,
         sched_status, max_accum_num, includes_excise_tax_ind, includes_fuel_tax_ind, 
		 is_lc_assigned, is_rc_assigned, use_mkt_formula_for_pl, trans_id)
   values(0, 0, 0, 'W', 0.01, 0, 0, 0, 0, 0, 'N', 'N', 'Y', 1)
end
go

