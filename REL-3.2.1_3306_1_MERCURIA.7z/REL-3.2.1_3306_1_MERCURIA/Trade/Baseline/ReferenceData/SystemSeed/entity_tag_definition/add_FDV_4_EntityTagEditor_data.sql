set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Adding new function_detail_value records (EntityTagEditor) for tags currently in the entity_tag_definition table ...'
go

declare @function_num       int,
        @fd_id              int,
	      @last_fdv_id        int,
	      @rows_affected      int,
      	@errcode            int

select @errcode = 0,
       @rows_affected = 0
              
select @function_num = function_num
from dbo.icts_function
where app_name = 'EntityTagEditor' and
      function_name = 'EDIT'

if @function_num is null
begin
   select @errcode = 1
   print '=> Could not find the icts_function record for the apps ''EntityTagEditor'' and the function ''EDIT''!'
   goto endofscript
end

select @fd_id = fd_id
from dbo.function_detail
where function_num = @function_num and
      entity_name = 'EntityTagDefinition' and 
      attr_name = 'entityTagName' and
      operation = '='

if @fd_id is null
begin
   select @errcode = 1
   print '=> Could not find the function_detail record for the entity ''EntityTagDefinition'' and the attr ''entityTagName''!'
   goto endofscript
end

create table #attrs
(
   oid            int IDENTITY primary key,
   attr_value     varchar(40) NULL
)

if not exists (select 1
               from dbo.function_detail_value
               where fd_id = @fd_id and
                     attr_value = 'AllocationItem.ALL')
   insert into #attrs (attr_value) values('AllocationItem.ALL')
   
if not exists (select 1
               from dbo.function_detail_value
               where fd_id = @fd_id and
                     attr_value = 'AiEstActual.ALL')
   insert into #attrs (attr_value) values('AiEstActual.ALL')
   
if not exists (select 1
               from dbo.function_detail_value
               where fd_id = @fd_id and
                     attr_value = 'TradeItem.ALL')
   insert into #attrs (attr_value) values('TradeItem.ALL')
   
if not exists (select 1
               from dbo.function_detail_value
               where fd_id = @fd_id and
                     attr_value = 'Portfolio.ALL')
   insert into #attrs (attr_value) values('Portfolio.ALL')
   
insert into #attrs (attr_value)
select entity_tag_name
from dbo.entity_tag_definition
where entity_tag_name not in (select attr_value
                              from dbo.function_detail_value
                              where fd_id = @fd_id)

if (select count(*) from #attrs) = 0
   goto endofscript

select @last_fdv_id = isnull(max(fdv_id), 0)
from dbo.function_detail_value

insert into dbo.function_detail_value
   (fdv_id,
    fd_id,
    data_type,
    attr_value,
    trans_id)
select @last_fdv_id + oid, @fd_id, 'S', attr_value, 1
from #attrs
select @rows_affected = @@rowcount

endofscript:
if object_id('tempdb.dbo.#attrs', 'U') is not null
   exec('drop table #attrs')
print ' '
if @errcode = 0 and @rows_affected > 0
   print 'function_detail_value (ENTITY): ' + cast(@rows_affected as varchar) + ' were successfully added'
go
                                                                                      
exec dbo.refresh_a_last_num 'function_detail_value', 'fdv_id'
go
