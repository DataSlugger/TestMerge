set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading entity tags owned by the ''Cost'' entity into the ''entity_tag_definition'' table ...'
go

declare @oid                numeric(18, 0),
        @newoid             int,
        @target_entity_id   int,
        @entity_id          int,
        @errcode            int,
        @row_affected       int,
        @entity_tag_name    varchar(16),
        @entity_tag_desc    varchar(64),
        @tag_required_ind   char(1),
        @tag_status         char(1),
        @entity_name        varchar(30),
        @target_entity_name varchar(30),
        @smsg               varchar(255)

create table #entity_tags
(
   oid                numeric(18, 0) IDENTITY,
   entity_tag_name    varchar(16) NOT NULL,
   entity_tag_desc    varchar(64) NULL,
   target_entity_id   int         NULL,
   tag_required_ind   char(1)     NOT NULL,
   tag_status         char(1)     NOT NULL,
   entity_id          int         NOT NULL,
   entity_name        varchar(30) NULL
)
     
select @errcode = 0

print '=> Saving Entity Tags for the entity ''Cost'' into temporary table ...'

select @target_entity_name = null,
       @entity_name = 'Cost',
       @target_entity_id = null,
       @entity_id = null

if @target_entity_name is not null
begin
   select @target_entity_id = oid
   from dbo.icts_entity_name
   where entity_name = @target_entity_name

   if @target_entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @target_entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

if @entity_name is not null
begin
   select @entity_id = oid
   from dbo.icts_entity_name
   where entity_name = @entity_name

   if @entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

/* ----------------------------------------------------------------------------
      oid                     : <next sequence #>
      entity_tag_name         : 'COST_BOOK_X_RATE'
      entity_tag_desc         : 'Booking Currency Conversion Rate For Costs'
      target_entity_id        : NULL
      tag_required_ind        : 'N'
      tag_status              : 'A'
      entity_id               : <ID for the 'Cost' entity>
    ---------------------------------------------------------------------------- */

insert into #entity_tags 
   (entity_tag_name, entity_tag_desc, target_entity_id,
    tag_required_ind, tag_status, entity_id, entity_name)
   values ('COST_BOOK_X_RATE', 'Booking Currency Conversion Rate For Costs', NULL, 'N', 'A', @entity_id, @entity_name)


/* ----------------------------------------------------------------------------
    The following entity_tag_definition records for entity 'Cost'

      oid                     : <next sequence #>
      entity_tag_name         : 'GST_Rate'
      entity_tag_desc         : 'GST rate applied on this cost'
      target_entity_id        : NULL
      tag_required_ind        : 'N'
      tag_status              : 'A'
      entity_id               : <oid for the entity_name = 'Cost'>
    ---------------------------------------------------------------------------- */

insert into #entity_tags 
   (entity_tag_name, entity_tag_desc, target_entity_id,
    tag_required_ind, tag_status, entity_id, entity_name)
   values ('GST_Rate', 'GST rate applied on this cost', NULL, 'N', 'A', @entity_id, @entity_name)

/* ----------------------------------------------------------------------------
    The following entity_tag_definition records for entity 'Cost'

      oid                     : <next sequence #>
      entity_tag_name         : 'PrepaymentQty'
      entity_tag_desc         : 'Informational cost override quantity'
      target_entity_id        : NULL
      tag_required_ind        : 'N'
      tag_status              : 'A'
      entity_id               : <oid for the entity_name = 'Cost'>
    ---------------------------------------------------------------------------- */

insert into #entity_tags 
   (entity_tag_name, entity_tag_desc, target_entity_id,
    tag_required_ind, tag_status, entity_id, entity_name)
   values ('PrepaymentQty', 'Informational cost override quantity', NULL, 'N', 'A', @entity_id, @entity_name)

/* ----------------------------------------------------------------------------
    The following entity_tag_definition records for entity 'Cost'

      oid                     : <next sequence #>
      entity_tag_name         : 'PrepaymentQty'
      entity_tag_desc         : 'Informational cost override quantity'
      target_entity_id        : NULL
      tag_required_ind        : 'N'
      tag_status              : 'A'
      entity_id               : <oid for the entity_name = 'Cost'>
   
    ---------------------------------------------------------------------------- */

insert into #entity_tags 
   (entity_tag_name, entity_tag_desc, target_entity_id,
    tag_required_ind, tag_status, entity_id, entity_name)
   values ('PrepaymentQty', 'Informational cost override quantity', NULL, 'N', 'A', @entity_id, @entity_name)

/* ----------------------------------------------------------------------------
    The following entity_tag_definition records for entity 'Cost'

      oid                     : <next sequence #>
      entity_tag_name         : 'EligibleClaims'
      entity_tag_desc         : 'Eligible for Claims'
      target_entity_id        : NULL
      tag_required_ind        : 'N'
      tag_status              : 'A'
      entity_id               : <ID for the entity 'Cost'>
    ---------------------------------------------------------------------------- */

insert into #entity_tags 
   (entity_tag_name, entity_tag_desc, target_entity_id,
    tag_required_ind, tag_status, entity_id, entity_name)
   values ('EligibleClaims', 'Eligible for Claims', NULL, 'N', 'A', @entity_id, @entity_name)

/* ----------------------------------------------------------------------------
      oid                     : <next sequence #>
      entity_tag_name         : 'ClaimCprty'
      entity_tag_desc         : 'Claim Counterparty'
      target_entity_id        : <ID for the entity 'Account'>
      tag_required_ind        : 'N'
      tag_status              : 'A'
      entity_id               : <ID for the entity 'Cost'>
    ---------------------------------------------------------------------------- */

insert into #entity_tags 
   (entity_tag_name, entity_tag_desc, target_entity_id,
    tag_required_ind, tag_status, entity_id, entity_name)
   values ('ClaimCprty', 'Claim Counterparty', @target_entity_id, 'N', 'A', @entity_id, @entity_name)

/* ----------------------------------------------------------------------------
      oid                     : <next sequence #>
      entity_tag_name         : 'ClaimAmount'
      entity_tag_desc         : 'Claim Amount'
      target_entity_id        : NULL
      tag_required_ind        : 'N'
      tag_status              : 'A'
      entity_id               : <ID for the entity 'Cost'>
  ---------------------------------------------------------------------------- */

insert into #entity_tags 
   (entity_tag_name, entity_tag_desc, target_entity_id,
    tag_required_ind, tag_status, entity_id, entity_name)
   values ('ClaimAmount', 'Claim Amount', NULL, 'N', 'A', @entity_id, @entity_name)


print ' '

/* ********************************************************************* */
/* The code cody for adding records into the entity_tag_definition table */
/* ********************************************************************* */

select @oid = min(oid)
from #entity_tags

while @oid is not null
begin
   select @entity_tag_name = entity_tag_name,
          @entity_tag_desc = entity_tag_desc,
          @target_entity_id = target_entity_id,
          @tag_required_ind = tag_required_ind,
          @tag_status = tag_status,
          @entity_id = entity_id,
          @entity_name = entity_name
   from #entity_tags
   where oid = @oid

   if not exists (select 1
                  from dbo.entity_tag_definition
                  where entity_tag_name = @entity_tag_name and
                        entity_id = @entity_id)
   begin
      begin tran
      select @newoid = isnull(max(oid), 0) + 1
      from dbo.entity_tag_definition
   
      insert into dbo.entity_tag_definition
          (oid, entity_tag_name, entity_tag_desc, target_entity_id, 
              tag_required_ind, tag_status, entity_id, trans_id)
         values(@newoid, @entity_tag_name, @entity_tag_desc, 
                  @target_entity_id, @tag_required_ind, @tag_status, @entity_id, 1)
      select @row_affected = @@rowcount,
             @errcode = @@error
      if @errcode > 0 or @row_affected = 0
      begin
         if @@trancount > 0
            rollback tran
         if @errcode > 0
            goto endofscript
      end
      else
      begin
         commit tran
         select @smsg = '=> The tag ''' + @entity_tag_name + ''' for the entity ''' + @entity_name + ''' was added successfully!' 
         print @smsg
      end  
   end
     
   select @oid = min(oid)
   from #entity_tags
   where oid > @oid        
end
endofscript:
drop table #entity_tags
go
                                 
exec refresh_a_last_num 'entity_tag_definition', 'oid'
go