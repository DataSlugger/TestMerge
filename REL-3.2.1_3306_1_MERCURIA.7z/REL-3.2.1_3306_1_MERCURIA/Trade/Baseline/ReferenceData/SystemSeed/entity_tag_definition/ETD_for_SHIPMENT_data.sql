set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading new entity tags into the ''entity_tag_definition'' table (Shipment) ...'
go

declare @oid                numeric(18, 0),
        @newoid             int,
        @target_entity_id   int,
        @entity_id          int,
        @errcode            int,
        @row_affected       int,
        @entity_tag_name    varchar(16),
        @entity_tag_desc    varchar(64),
        @tag_required_ind   char(1),
        @tag_status         char(1),
        @entity_name        varchar(30),
        @target_entity_name varchar(30),
        @smsg               varchar(255)

create table #entity_tags
(
   oid                numeric(18, 0) IDENTITY,
   entity_tag_name    varchar(16) NOT NULL,
   entity_tag_desc    varchar(64) NULL,
   target_entity_id   int         NULL,
   tag_required_ind   char(1)     NOT NULL,
   tag_status         char(1)     NOT NULL,
   entity_id          int         NOT NULL,
   entity_name        varchar(30) NULL
)
     
select @errcode = 0

/* ----------------------------------------------------------------------------
    The following entity_tag_definition records for entity 'Shipment'

      oid                     : <next sequence #>
      entity_tag_name         : 'MasterShipmentId'
      entity_tag_desc         : 'Master Shipment Id'
      target_entity_id        : NULL
      tag_required_ind        : 'N'
      tag_status              : 'A'
      entity_id               : <ID for the entity 'Shipment'>
    ---------------------------------------------------------------------------- */

print '=> Saving Entity Tags for the entity ''Shipment'' into temporary table ...'
       
select @target_entity_name = 'IctsUser',
       @entity_name = 'Shipment',
       @target_entity_id = null,
       @entity_id = null

if @target_entity_name is not null
begin
   select @target_entity_id = oid
   from dbo.icts_entity_name
   where entity_name = @target_entity_name

   if @target_entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @target_entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

if @entity_name is not null
begin
   select @entity_id = oid
   from dbo.icts_entity_name
   where entity_name = @entity_name

   if @entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

insert into #entity_tags 
   (entity_tag_name, entity_tag_desc, target_entity_id,
    tag_required_ind, tag_status, entity_id, entity_name)
   values ('MasterShipmentId', 'Master Shipment Id', NULL, 'N', 'A', @entity_id, @entity_name)


/* ----------------------------------------------------------------------------
    The following entity_tag_definition records for entity 'Shipment'

      oid                     : <next sequence #>
      entity_tag_name         : 'SHIPMENT_ROUTE'
      entity_tag_desc         : 'Shipment route name'
      target_entity_id        : NULL
      tag_required_ind        : 'N'
      tag_status              : 'S'
      entity_id               : <ID for the entity 'Shipment'>
    ---------------------------------------------------------------------------- */

insert into #entity_tags 
   (entity_tag_name, entity_tag_desc, target_entity_id,
    tag_required_ind, tag_status, entity_id, entity_name)
   values ('SHIPMENT_ROUTE', 'Shipment route name', NULL, 'N', 'S', @entity_id, @entity_name)






print ' '

/* ********************************************************************* */
/* The code cody for adding records into the entity_tag_definition table */
/* ********************************************************************* */

select @oid = min(oid)
from #entity_tags

while @oid is not null
begin
   select @entity_tag_name = entity_tag_name,
          @entity_tag_desc = entity_tag_desc,
          @target_entity_id = target_entity_id,
          @tag_required_ind = tag_required_ind,
          @tag_status = tag_status,
          @entity_id = entity_id,
          @entity_name = entity_name
   from #entity_tags
   where oid = @oid

   if not exists (select 1
                  from dbo.entity_tag_definition
                  where entity_tag_name = @entity_tag_name and
                        entity_id = @entity_id)
   begin
      begin tran
      select @newoid = isnull(max(oid), 0) + 1
      from dbo.entity_tag_definition
   
      insert into dbo.entity_tag_definition
          (oid, entity_tag_name, entity_tag_desc, target_entity_id, 
              tag_required_ind, tag_status, entity_id, trans_id)
         values(@newoid, @entity_tag_name, @entity_tag_desc, 
                  @target_entity_id, @tag_required_ind, @tag_status, @entity_id, 1)
      select @row_affected = @@rowcount,
             @errcode = @@error
      if @errcode > 0 or @row_affected = 0
      begin
         if @@trancount > 0
            rollback tran
         if @errcode > 0
            goto endofscript
      end
      else
      begin
         commit tran
         select @smsg = '=> The tag ''' + @entity_tag_name + ''' for the entity ''' + @entity_name + ''' was added successfully!' 
         print @smsg
      end  
   end
     
   select @oid = min(oid)
   from #entity_tags
   where oid > @oid        
end
endofscript:
drop table #entity_tags
go
                                 
exec refresh_a_last_num 'entity_tag_definition', 'oid'
go
