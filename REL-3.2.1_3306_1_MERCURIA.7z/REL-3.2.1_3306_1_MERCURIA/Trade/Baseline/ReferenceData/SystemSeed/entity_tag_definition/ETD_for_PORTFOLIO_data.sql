set nocount on

set QUOTED_IDENTIFIER ON
go

print ' '
print 'Loading new entity tags into the ''entity_tag_definition'' table (Portfolio) ...'
go

declare @oid                            numeric(18, 0),
        @newoid                         int,
        @target_entity_id               int,
        @entity_id                      int,
        @errcode                        int,
        @row_affected                   int,
        @entity_tag_name                varchar(16),
        @entity_tag_desc                varchar(64),
        @tag_required_ind               char(1),
        @tag_status                     char(1),
        @entity_name                    varchar(30),
        @smsg                           varchar(255),
        @ACCOUNT_target_entity_id       int,
        @ICTS_USER_target_entity_id     int,
        @PRICE_SOURCE_target_entity_id  int,
        @PORTFOLIO_target_entity_id     int

create table #entity_tags
(
   oid                numeric(18, 0) IDENTITY,
   entity_tag_name    varchar(16) NOT NULL,
   entity_tag_desc    varchar(64) NULL,
   target_entity_id   int         NULL,
   tag_required_ind   char(1)     NOT NULL,
   tag_status         char(1)     NOT NULL,
   entity_id          int         NOT NULL,
   entity_name        varchar(30) NULL
)
     
select @errcode = 0
print '=> Saving Entity Tags for the entity ''Portfolio'' into temporary table ...'
       
select @entity_name = 'Portfolio',
       @target_entity_id = null,
       @ACCOUNT_target_entity_id = null,
       @ICTS_USER_target_entity_id = null,
       @PRICE_SOURCE_target_entity_id = null,
       @entity_id = null

select @ACCOUNT_target_entity_id = oid
from dbo.icts_entity_name
where entity_name = 'Account'

if @ACCOUNT_target_entity_id is null
begin
   select @smsg = 'Could not find the entity ''Account'' in the icts_entity_name table!'
   print @smsg
   goto endofscript
end

select @ICTS_USER_target_entity_id = oid
from dbo.icts_entity_name
where entity_name = 'IctsUser'

if @ICTS_USER_target_entity_id is null
begin
   select @smsg = 'Could not find the entity ''IctsUser'' in the icts_entity_name table!'
   print @smsg
   goto endofscript
end

select @PRICE_SOURCE_target_entity_id = oid
from dbo.icts_entity_name
where entity_name = 'PriceSource'

if @PRICE_SOURCE_target_entity_id is null
begin
   select @smsg = 'Could not find the entity ''PriceSource'' in the icts_entity_name table!'
   print @smsg
   goto endofscript
end

if @entity_name is not null
begin
   select @entity_id = oid
   from dbo.icts_entity_name
   where entity_name = @entity_name

   if @entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

set @PORTFOLIO_target_entity_id = @entity_id

/* ----------------------------------------------------------------------------
    The following STANDARD 10 entity_tag_definition records for entity 'Portfolio'

      entity_tag_name   entity_tag_desc   target_entity_id         tag_required_ind  tag_status
      ----------------- ----------------- -----------------------  ----------------  ----------
      CLASS	        Classification	  NULL	                   Y	             A
      DEPT	        Department	  NULL	                   N	             I
      DESK	        Desk	          NULL	                   N	             I
      DIVISION	        Division	  NULL	                   Y	             A
      GROUP	        Group	          NULL	                   Y	             A
      LEGALENT	        Legal Entity	  NULL	                   Y	             A
      LOCATION	        Location	  NULL	                   Y	             A
      PRFTCNTR	        Profit Center	  NULL	                   Y	             A
      STRATEGY	        Strategy	  NULL	                   Y	             A
      TRADER	        Trader	          <ID of icts_user table>  Y	             A
   ---------------------------------------------------------------------------- */

insert into #entity_tags 
   (entity_tag_name, entity_tag_desc, target_entity_id,
    tag_required_ind, tag_status, entity_id, entity_name)
   values ('CLASS',    'Classification', NULL,                        'Y', 'A', @entity_id, @entity_name),
          ('DEPT',     'Department',     NULL,                        'N', 'I', @entity_id, @entity_name),
          ('DESK',     'Desk',           NULL,                        'N', 'I', @entity_id, @entity_name),
          ('DIVISION', 'Division',       NULL,                        'Y', 'A', @entity_id, @entity_name),
          ('GROUP',    'Group',          NULL,                        'Y', 'A', @entity_id, @entity_name),
          ('LEGALENT', 'Legal Entity',   NULL,                        'Y', 'A', @entity_id, @entity_name),
          ('LOCATION', 'Location',       NULL,                        'Y', 'A', @entity_id, @entity_name),
          ('PRFTCNTR', 'Profit Center',  NULL,                        'Y', 'A', @entity_id, @entity_name),
          ('STRATEGY', 'Strategy',       NULL,                        'Y', 'A', @entity_id, @entity_name),
          ('TRADER',   'Trader',         @ICTS_USER_target_entity_id, 'Y', 'A', @entity_id, @entity_name)  

/* ----------------------------------------------------------------------------
      entity_tag_name   entity_tag_desc                                            target_entity_id            tag_required_ind  tag_status
      ----------------- ---------------------------------------------------------- --------------------------  ----------------  ----------
      BOOKCOMP          Booking Company	                                           <ID of account table>       Y	         A
      INTRNSRC          Internal Price Source                                      <ID of price_source table>  N	         I
      UseBDENSITYSpec   Use BDENSITY tradeItem spec for UOM conversion if defined  NULL                        N                 A
   ---------------------------------------------------------------------------- */

insert into #entity_tags 
   (entity_tag_name, entity_tag_desc, target_entity_id,
    tag_required_ind, tag_status, entity_id, entity_name)
   values ('BOOKCOMP', 'Booking Company',       @ACCOUNT_target_entity_id,      'Y', 'A', @entity_id, @entity_name),
          ('INTRNSRC', 'Internal Price Source', @PRICE_SOURCE_target_entity_id, 'N', 'I', @entity_id, @entity_name),
          ('UseBDENSITYSpec', 'Use BDENSITY tradeItem spec for UOM conversion if defined', NULL, 'N', 'A', @entity_id, @entity_name)

/* ----------------------------------------------------------------------------
      entity_tag_name   entity_tag_desc                                            target_entity_id            tag_required_ind  tag_status
      ----------------- ---------------------------------------------------------- --------------------------  ----------------  ----------
      IWORLD            Infrastructure world portfolio                             <ID of portfolio table>     N	
   ---------------------------------------------------------------------------- */

   insert into #entity_tags 
   (entity_tag_name, entity_tag_desc, target_entity_id,
    tag_required_ind, tag_status, entity_id, entity_name)
   values ('IWORLD','Infrastructure world portfolio', @PORTFOLIO_target_entity_id, 'N', 'S', @entity_id, @entity_name)


print ' '

/* ********************************************************************* */
/* The code cody for adding records into the entity_tag_definition table */
/* ********************************************************************* */

select @oid = min(oid)
from #entity_tags

while @oid is not null
begin
   select @entity_tag_name = entity_tag_name,
          @entity_tag_desc = entity_tag_desc,
          @target_entity_id = target_entity_id,
          @tag_required_ind = tag_required_ind,
          @tag_status = tag_status,
          @entity_id = entity_id,
          @entity_name = entity_name
   from #entity_tags
   where oid = @oid

   if not exists (select 1
                  from dbo.entity_tag_definition
                  where entity_tag_name = @entity_tag_name and
                        entity_id = @entity_id)
   begin
      begin tran
      select @newoid = isnull(max(oid), 0) + 1
      from dbo.entity_tag_definition
   
      insert into dbo.entity_tag_definition
          (oid, entity_tag_name, entity_tag_desc, target_entity_id, 
              tag_required_ind, tag_status, entity_id, trans_id)
         values(@newoid, @entity_tag_name, @entity_tag_desc, 
                  @target_entity_id, @tag_required_ind, @tag_status, @entity_id, 1)
      select @row_affected = @@rowcount,
             @errcode = @@error
      if @errcode > 0 or @row_affected = 0
      begin
         if @@trancount > 0
            rollback tran
         if @errcode > 0
            goto endofscript
      end
      else
      begin
         commit tran
         select @smsg = '=> The tag ''' + @entity_tag_name + ''' for the entity ''' + @entity_name + ''' was added successfully!' 
         print @smsg
      end  
   end
     
   select @oid = min(oid)
   from #entity_tags
   where oid > @oid        
end
endofscript:
drop table #entity_tags
go
                                 
exec dbo.refresh_a_last_num 'entity_tag_definition', 'oid'
go
