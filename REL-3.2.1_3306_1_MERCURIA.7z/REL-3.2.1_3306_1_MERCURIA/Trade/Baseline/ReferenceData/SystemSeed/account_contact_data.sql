set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table account_contact
go

print 'Loading startup seed reference data into the account_contact table ...'
go

insert into dbo.account_contact values(1, 1, 'ANNUNZIATA', 'VINNIE', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, 'A', 1)
go

