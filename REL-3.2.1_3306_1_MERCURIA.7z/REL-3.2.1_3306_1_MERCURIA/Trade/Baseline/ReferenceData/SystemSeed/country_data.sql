set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the country table ...'
go

/*
       (country_code,
        country_name,
        no_bus_ind,
        country_num,
        country_status,
        calendar_code,
        int_curr_code,
        ext_curr_code,
        country_limit_amt,
        country_limit_util_amt,
        cmnt_num,
        exposure_priority_code,
        trans_id,
        iso_country_code


*/

insert into country values('062', 'ICELAND', 'Y', 61, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('A', 'AUSTRIA', 'Y', 9, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('ABD', 'ABU DHABI', 'Y', 169, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('ADN', 'YEMEN, PEOPL. DEMOCR. REPUBL.(SOUTH)', 'Y', 
151, 'A', NULL, 'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('AFG', 'AFGHANISTAN', 'Y', 1, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('AL', 'ALBANIA', 'Y', 2, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('AND', 'ANDORRA', 'Y', 5, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('ANG', 'ANGOLA', 'N', 163, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('ANT', 'ANTIGUA', 'Y', 181, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('AR', 'ARGENTINA', 'Y', 6, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('ARU', 'ARUBA', 'Y', 870, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('AUS', 'AUSTRALIA', 'Y', 8, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('B', 'BELGIUM', 'Y', 13, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BAN', 'BANGLADESH', 'Y', 165, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BDS', 'BARBADOS', 'Y', 12, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BEN', 'BENIN', 'Y', 173, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BER', 'BERMUDA', 'Y', 14, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BG', 'BULGARIA', 'Y', 22, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BHU', 'BHUTAN', 'Y', 195, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BOL', 'BOLIVIA', 'Y', 17, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BR', 'BRAZIL', 'Y', 20, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BRD', 'GERMANY', 'Y', 47, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BRN', 'BAHRAIN', 'Y', 11, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BRU', 'BRUENI', 'Y', 21, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BS', 'BAHAMA ISLANDS', 'Y', 10, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('BUR', 'BURMA', 'Y', 15, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('C', 'CUBA', 'N', 34, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('CDN', 'CANADA', 'Y', 26, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('CFS', 'SOMALIA', 'Y', 125, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('CH', 'SWITZERLAND', 'Y', 135, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('CI', 'IVORY COAST', 'Y', 69, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('CIS', 'COMMONWEALTH OF INDEPENDENT STATES', 'Y', 
129, 'A', NULL, 'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('CL', 'SRI LANKA (CEYLON)', 'Y', 131, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('CNB', 'NORTH BORNEO', 'Y', 18, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('CO', 'COLOMBIA', 'Y', 31, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('COM', 'COMOROS', 'Y', 174, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('CR', 'COSTA RICA', 'Y', 33, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('CS', 'CZECHOSLOVAKIA', 'Y', 36, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('CVI', 'CAPE VERDE ISLAND', 'Y', 170, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('CY', 'CYPRUS', 'Y', 35, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('DDR', 'GERMAN DEM REPUBLIC', 'Y', 48, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('DJI', 'DJIBOUTI', 'Y', 166, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('DK', 'DENMARK', 'Y', 37, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('DOM', 'DOMINICAN REPUBLIC', 'Y', 40, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('DUB', 'DUBAI', 'Y', 164, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('DY', 'DHOMEY', 'Y', 38, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('DZ', 'ALGERIA', 'Y', 3, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('E', 'SPAIN', 'Y', 130, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('EAK', 'KENYA', 'Y', 74, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('EAT', 'TANZANIA', 'Y', 139, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('EAU', 'UGANDA', 'Y', 145, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('EC', 'ECUADOR', 'Y', 41, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('ELS', 'EL SALVADOR', 'Y', 182, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('EQG', 'EQUATORIAL GUINEA', 'Y', 175, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('EST', 'ESTONIA', 'Y', 201, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('ET', 'EGYPT', 'Y', 42, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('ETH', 'ETHYOPIA', 'Y', 43, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('ETI', 'EAST TIMOR', 'Y', 198, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('F', 'FRANCE', 'Y', 45, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('FG', 'FRENCH GUINEA', 'Y', 188, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('FL', 'FUERST LIECHTENSTEIN', 'Y', 83, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GAB', 'REPUBLIC GABON', 'Y', 161, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GB', 'GREAT BRITAIN', 'Y', 16, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GBA', 'AURIGNY', 'Y', 7, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GBG', 'GUERNESEY', 'Y', 55, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GBJ', 'JERSEY', 'Y', 72, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GBM', 'MAN', 'Y', 90, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('GBZ', 'GIBRALTAR', 'Y', 51, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GC', 'GRAND CAYMAN', 'Y', 172, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GCA', 'GUATEMALA', 'Y', 54, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GEA', 'GUINEA', 'Y', 160, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GH', 'BRITISH HONDURAS', 'Y', 58, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GHA', 'GHANA', 'Y', 50, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GR', 'GREECE', 'Y', 52, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GRE', 'GREENLAND', 'Y', 189, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GUA', 'GUADALOUPE', 'Y', 183, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GUB', 'GUINEA BISSAU', 'Y', 176, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('GUY', 'GUYANA', 'Y', 56, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('H', 'HUNGARY', 'Y', 60, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('HK', 'HONG KONG', 'Y', 59, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('HON', 'HONDURUS', 'Y', 184, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('HV', 'UPPER VOLTA', 'Y', 150, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('I', 'ITALY', 'Y', 68, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('IL', 'ISRAEL', 'Y', 67, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('IND', 'INDIA', 'Y', 62, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('IR', 'IRAN', 'Y', 64, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('IRG', 'IRAQ', 'N', 65, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('IRL', 'IRELAND', 'Y', 66, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('J', 'JAPAN', 'Y', 71, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('JA', 'JAMAICA', 'Y', 70, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('JOR', 'JORDAN', 'Y', 73, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('K', 'CAMBODIA', 'N', 24, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('KL', 'KUALA LUMPUR', 'Y', 156, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('KOR', 'SOUTH KOREA', 'Y', 76, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('KWT', 'KUWAIT', 'Y', 77, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('L', 'LUXEMBOURG', 'Y', 84, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('LAO', 'LAOS', 'Y', 78, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('LAR', 'LIBYA', 'N', 82, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('LB', 'LIBERIA', 'Y', 81, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('LIC', 'LICHTENSTEIN', 'Y', 219, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('LS', 'LESOTHO', 'Y', 80, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('M', 'MALTA', 'Y', 88, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('MA', 'MOROCCO', 'Y', 95, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('MAC', 'MACAO', 'Y', 196, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('MAD', 'MADAGASCAR', 'Y', 157, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('MAL', 'REPUBLIC OF MALYSIA', 'Y', 89, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('MAR', 'MARTINIQUE', 'Y', 191, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('MAV', 'MALVIDES', 'Y', 197, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('MAY', 'MAYOTTE', 'Y', 177, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('MC', 'MONACO', 'Y', 94, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('MEX', 'MEXICO', 'Y', 93, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('MON', 'MONSERRAT', 'Y', 192, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('MOZ', 'MOZAMBIQUE', 'Y', 96, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('MS', 'MAURITIUS', 'Y', 92, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('MW', 'MALAWI', 'Y', 85, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('N', 'NORWAY', 'Y', 104, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('NA', 'NETHERLANDS ANTILLES', 'Y', 99, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('NEP', 'NEPAL', 'Y', 97, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('NIC', 'NICARAGUA', 'Y', 101, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('NIG', 'NIGER', 'Y', 103, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('NL', 'NETHERLANDS', 'Y', 98, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('NZ', 'NEW ZEALAND', 'Y', 100, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('OM', 'OMAN', 'Y', 162, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('P', 'PORTUGAL', 'Y', 111, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('PA', 'PANAMA', 'Y', 106, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('PAK', 'PAKISTAN', 'Y', 105, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('PE', 'PERU', 'Y', 108, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('PI', 'PHILIPPINES', 'Y', 109, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('PL', 'POLAND', 'Y', 110, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('PNG', 'PAPUA NEW GUINEA', 'Y', 190, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('PRC', 'PEOPLES REPUBLIC OF CHINA', 'Y', 30, 'A', 
NULL, 'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('PRI', 'PUERTO RICO', 'Y', 785, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('PY', 'PARAGUAY', 'Y', 107, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('QTR', 'QATAR', 'Y', 158, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('R', 'RUMANIA', 'Y', 113, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RB', 'BOTSWANA', 'Y', 19, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RC', 'TAIWAN', 'Y', 138, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RCA', 'CENTRAL AFRICAN REPUBLIC', 'Y', 27, 'A', 
NULL, 'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RCB', 'CONGO', 'Y', 32, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RCH', 'CHILE', 'Y', 29, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('REU', 'REUNION', 'Y', 178, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RH', 'HAITI', 'N', 57, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('RI', 'INDONESIA', 'Y', 63, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RIM', 'MAURITANIA', 'Y', 91, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RL', 'LEBANON', 'Y', 79, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RM', 'MALGASY REPUBLIC', 'Y', 86, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RMM', 'MALI', 'Y', 87, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('ROK', 'NORTH KOREA', 'N', 75, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RSM', 'SAN MARINO', 'Y', 115, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RU', 'BURUNDI', 'Y', 23, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RUS', 'RUSSIA', 'Y', 200, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('RWA', 'RWANDA', 'Y', 114, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('S', 'SWEDEN', 'Y', 136, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SA', 'SAUDI ARABIA', 'Y', 120, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SD', 'SWAZILAND', 'Y', 134, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SF', 'FINLAND', 'Y', 44, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SGP', 'SINGAPORE', 'Y', 124, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SK', 'SARAWAK', 'Y', 118, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SKN', 'ST KITTS - NEVIS', 'Y', 193, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SLO', 'SLOVENIA', 'Y', 200, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SME', 'SURINAM', 'Y', 133, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SN', 'SENEGAL', 'Y', 121, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SP', 'SOMALI (REPUBLIC)', 'Y', 126, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('STH', 'ST HELENA', 'Y', 180, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SU', 'SOVIET UNION', 'Y', 129, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SUD', 'SUDAN', 'Y', 132, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SWA', 'SOUTHWEST AFRICA', 'Y', 128, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SY', 'SEYCHELLES', 'Y', 122, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('SYR', 'SYRIA', 'Y', 137, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('T', 'THAILAND', 'Y', 140, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('TC', 'CAMEROON', 'Y', 25, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('TCH', 'CHAD', 'Y', 28, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('TCI', 'TURKS & CATCOS ISLANDS', 'Y', 194, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('TG', 'TOGO', 'Y', 141, 'A', NULL, 'USD', 'USD', 0.0, 
NULL, NULL, 'R', 1, NULL)
go

insert into country values('TN', 'TUNISIA', 'Y', 143, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('TR', 'TURKEY', 'Y', 144, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('TT', 'TRINIDAD AND TOBAGO', 'Y', 142, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('U', 'URUGUAY', 'Y', 146, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('UAE', 'UN ARAB EMIRATES', 'Y', 159, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('UK', 'UNITED KINGDOM', 'N', 16, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('UNKNOWN', 'NOT DEFINED IN IDMS', 'N', 999, 'A', 
NULL, 'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('V', 'VATICAN', 'Y', 147, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('VAN', 'VANUATU', 'Y', 199, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('VIU', 'VIRGIN ISLANDS (U.K.)', 'Y', 186, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('VN', 'VIETNAM', 'N', 149, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('VUS', 'VIRGIN ISLANDS (U.S.)', 'Y', 787, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('WAG', 'GAMBIA', 'Y', 46, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('WAL', 'SIERRA LEONE', 'Y', 123, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('WAN', 'NIGERIA', 'Y', 102, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('WD', 'DOMINICA', 'Y', 39, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('WG', 'GRENADA', 'Y', 53, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('WL', 'SANTA LUCIA', 'Y', 116, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('WS', 'WEST SAMOA', 'Y', 119, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('WSA', 'WESTERN SOMOA', 'Y', 179, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('WV', 'ST VINCENT', 'Y', 117, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('YMN', 'YEMEN, ARAB REPUBLIC (NORTH)', 'Y', 152, 'A', 
NULL, 'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('YU', 'YUGOSLAVIA', 'Y', 153, 'A', NULL, 'USD', 
'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('YV', 'VENEZUELA', 'Y', 148, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('Z', 'ZAMBIA', 'Y', 155, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('ZA', 'SOUTH AFRICAN UNION', 'Y', 127, 'A', NULL, 
'USD', 'USD', 0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('ZIM', 'ZIMBABWE', 'Y', 171, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

insert into country values('ZR', 'ZAIRE', 'Y', 154, 'A', NULL, 'USD', 'USD', 
0.0, NULL, NULL, 'R', 1, NULL)
go

/* ***************************************************************************** */

print ' '
print 'Loading ISO country codes into a temp table ...'
go

CREATE TABLE #iso_country
(
   country_name		    varchar(100) NOT NULL,
   iso_country_code	  char(2)	         
)
go

set nocount on

INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('AFGHANISTAN','AF')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ALAND ISLANDS','AX')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ALBANIA','AL')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ALGERIA','DZ') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('AMERICAN SAMOA','AS')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ANDORRA','AD') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ANGOLA','AO')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ANGUILLA','AI')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ANTARCTICA','AQ')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ANTIGUA AND BARBUDA','AG') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ARGENTINA','AR')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ARMENIA','AM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ARUBA','AW') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('AUSTRALIA','AU') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('AUSTRIA','AT') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('AZERBAIJAN','AZ')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BAHAMAS','BS')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BAHRAIN','BH') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BANGLADESH','BD')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BARBADOS','BB') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BELARUS','BY')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BELGIUM','BE') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BELIZE','BZ')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BENIN','BJ')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BERMUDA','BM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BHUTAN','BT')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BOLIVIA','BO')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BOSNIA AND HERZEGOVINA','BA')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BOTSWANA','BW') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BOUVET ISLAND','BV')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BRAZIL','BR') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BRITISH INDIAN OCEAN TERRITORY','IO') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BRUNEI DARUSSALAM','BN')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BULGARIA','BG') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BURKINA FASO','BF') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('BURUNDI','BI')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CAMBODIA','KH')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CAMEROON','CM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CANADA','CA')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CAPE VERDE','CV')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CAYMAN ISLANDS','KY')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CENTRAL AFRICAN REPUBLIC','CF')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CHAD','TD')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CHILE','CL')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CHINA','CN')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CHRISTMAS ISLAND','CX') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('COCOS (KEELING) ISLANDS','CC') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('DISTRICT OF COLUMBIA','CO')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('COMOROS','KM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CONGO','CG')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CONGO, THE DEMOCRATIC REPUBLIC OF THE','CD')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('COOK ISLANDS','CK')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('COSTA RICA','CR')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('COTE D''IVOIRE','CI') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CROATIA','HR')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CUBA','CU')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CYPRUS','CY')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CZECH REPUBLIC','CZ') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('DENMARK','DK') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('DJIBOUTI','DJ') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('DOMINICA','DM') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('DOMINICAN REPUBLIC','DO')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ECUADOR','EC')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('EGYPT','EG') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('EL SALVADOR','SV') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('EQUATORIAL GUINEA','GQ')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ERITREA','ER')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ESTONIA','EE')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ETHIOPIA','ET')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('FALKLAND ISLANDS (MALVINAS)','FK')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('FAROE ISLANDS','FO')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('FIJI','FJ') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('FINLAND','FI')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('FRANCE','FR')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('FRANCE, METROPOLITAN','FX') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('FRENCH GUIANA','GF')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('FRENCH POLYNESIA','PF') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('FRENCH SOUTHERN TERRITORIES','TF')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GABON','GA') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GAMBIA','GM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GEORGIA','GE')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GERMANY','DE')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GHANA','GH') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GIBRALTAR','GI') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GREECE','GR')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GREENLAND','GL')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GRENADA','GD')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GUADELOUPE','GP') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GUAM','GU')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GUATEMALA','GT') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GUINEA','GN')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GUINEA-BISSAU','GW') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('GUYANA','GY')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('HAITI','HT') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('HEARD ISLAND AND MCDONALD ISLANDS','HM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('HOLY SEE (VATICAN CITY STATE)','VA')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('HONDURAS','HN') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('HONG KONG','HK') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('HUNGARY','HU')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ICELAND','IS') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('INDIA','IN')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('INDONESIA','ID') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('IRAN, ISLAMIC REPUBLIC OF','IR') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('IRAQ','IQ')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('IRELAND','IE')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ISRAEL','IL') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ITALY','IT')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('JAMAICA','JM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('JAPAN','JP')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('JORDAN','JO')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('KAZAKHSTAN','KZ')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('KENYA','KE')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('KIRIBATI','KI')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('KOREA, DEMOCRATIC PEOPLE''S REPUBLIC OF','KP') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('KOREA, REPUBLIC OF','KR')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('KUWAIT','KW') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('KYRGYZSTAN','KG')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('LAO PEOPLE''S DEMOCRATIC REPUBLIC','LA') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('LATVIA','LV')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('LEBANON','LB')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('LESOTHO','LS')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('LIBERIA','LR')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('LIBYAN ARAB JAMAHIRIYA','LY') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('LIECHTENSTEIN','LI') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('LITHUANIA','LT') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('LUXEMBOURG','LU') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MACAU','MO') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MACEDONIA, THE FORMER YUGOSLAV REPUBLIC ','MK')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MADAGASCAR','MG')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MALAWI','MW') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MALAYSIA','MY')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MALDIVES','MV')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MALI','ML')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MALTA','MT') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MARSHALL ISLANDS','MH')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MARTINIQUE','MQ')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MAURITANIA','MR') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MAURITIUS','MU') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MAYOTTE','YT') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MEXICO','MX') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('FEDERATED STATES OF MICRONESIA','FM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MOLDOVA, REPUBLIC OF','MD')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MONACO','MC') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MONGOLIA','MN') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MONTSERRAT','MS') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MOROCCO','MA')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MOZAMBIQUE','MZ') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('MYANMAR','MM') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NAMIBIA','NA')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NAURU','NR') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NEPAL','NP')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NETHERLANDS','NL') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NETHERLANDS ANTILLES','AN')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NEW CALEDONIA','NC') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NEW ZEALAND','NZ') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NICARAGUA','NI')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NIGER','NE') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NIGERIA','NG') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NIUE','NU') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NORFOLK ISLAND','NF') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NORTHERN MARIANA ISLANDS','MP')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('NORWAY','NO') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('OMAN','OM') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('PAKISTAN','PK') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('PALESTINIAN TERRITORY, OCCUPIED','PS')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('PALAU','PW')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('PANAMA','PA')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('PAPUA NEW GUINEA','PG') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('PARAGUAY','PY') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('PERU','PE') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('PHILIPPINES','PH')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('PITCAIRN','PN')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('POLAND','PL')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('PORTUGAL','PT')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('PUERTO RICO','PR')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('QATAR','QA') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('REUNION','RE')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ROMANIA','RO') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('RUSSIAN FEDERATION','RU')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('RWANDA','RW') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SAINT KITTS AND NEVIS','KN') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SAINT LUCIA','LC')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SAINT VINCENT AND THE GRENADINES','VC')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SAMOA','WS')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SAN MARINO','SM') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SAO TOME AND PRINCIPE','ST')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SAUDI ARABIA','SA') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SENEGAL','SN') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SEYCHELLES','SC') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SIERRA LEONE','SL')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SERBIA AND MONTENEGRO','CS') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SINGAPORE','SG') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SLOVAKIA','SK')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SLOVENIA','SI')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SOLOMON ISLANDS','SB')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SOMALIA','SO') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SOUTH AFRICA','ZA') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SPAIN','ES')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SRI LANKA','LK')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SOUTH GEORGIA AND THE SOUTH SANDWICH ISL','GS')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SAINT HELENA','SH')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SAINT PIERRE AND MIQUELON','PM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SUDAN','SD') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SURINAME','SR') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SVALBARD AND JAN MAYEN','SJ')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SWAZILAND','SZ') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SWEDEN','SE')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SWITZERLAND','CH')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('SYRIAN ARAB REPUBLIC','SY')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TAIWAN, PROVINCE OF CHINA','TW')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TAJIKISTAN','TJ')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TANZANIA, UNITED REPUBLIC OF','TZ')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('THAILAND','TH') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TIMOR-LESTE','TL') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TOGO','TG') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TOKELAU','TK')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TONGA','TO')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TRINIDAD AND TOBAGO','TT') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TUNISIA','TN') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TURKEY','TR')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TURKMENISTAN','TM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TURKS AND CAICOS ISLANDS','TC')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('TUVALU','TV')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('UGANDA','UG')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('UKRAINE','UA')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('UNITED ARAB EMIRATES','AE')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('UNITED KINGDOM','GB')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('UNITED STATES OF AMERICA','US')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('UNITED STATES MINOR OUTLYING ISLANDS','UM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('URUGUAY','UY')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('UZBEKISTAN','UZ')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('VANUATU','VU') 
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('VIET NAM','VN')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('VIRGIN ISLANDS, BRITISH','VG')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('VIRGIN ISLANDS, U.S.','VI')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('WALLIS AND FUTUNA','WF')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('WESTERN SAHARA','EH')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('YEMEN','YE')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('YUGOSLAVIA','YU')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ZAIRE','ZR')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ZAMBIA','ZM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ZIMBABWE','ZW')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('VENEZUELA','VE')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('JERSEY','JE')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('ISLE OF MAN','IM')
GO 
INSERT INTO #iso_country (country_name, iso_country_code)
VALUES ('CURACAO','CW')
GO 

/* ****** */
print ' '
print 'Updating the value in the ''iso_country_code'' column ...'
print ' '
go

if OBJECT_ID('dbo.country_updtrg', 'TR') is not null
begin
   if OBJECTPROPERTY(object_id('dbo.country_updtrg'), 'ExecIsTriggerDisabled') = 0
      exec('alter table dbo.country disable trigger country_updtrg')
end
go

declare @rows_affected   int

update c 
set c.iso_country_code = ctemp.iso_country_code
from dbo.country c 
        INNER JOIN #iso_country ctemp 
           ON c.country_name = ctemp.country_name
where c.iso_country_code is null
select @rows_affected = @@rowcount
if @rows_affected > 0
   print '=> ' + cast(@rows_affected as varchar) + ' records were updated for the ISO country code successfully!'
else
   print '=> No country record(s) were updated for ISO country code!' 

endofscript:
go

drop table #iso_country
go

if OBJECT_ID('dbo.country_updtrg', 'TR') is not null
begin
   if OBJECTPROPERTY(object_id('dbo.country_updtrg'), 'ExecIsTriggerDisabled') = 1
      exec('alter table dbo.country enable trigger country_updtrg')
end
go

