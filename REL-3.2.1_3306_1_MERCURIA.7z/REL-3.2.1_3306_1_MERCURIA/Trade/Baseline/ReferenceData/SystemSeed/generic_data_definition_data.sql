set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the GDN/GDD/GDV tables ...'
go

/* ********************************************************
    load generic_data_name 'freight_codes'
   ******************************************************** */

declare @gdn_num int
if not exists (select * from generic_data_name
               where data_name = 'freight_codes')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'freight_codes', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'freight_codes'
end

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(1, @gdn_num, 'freight_codes', 'commkt_key', 1, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(2, @gdn_num, 'freight_codes', 'nbv_mkt_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(3, @gdn_num, 'freight_codes', 'world_scale_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(4, @gdn_num, 'freight_codes', 'flat_rate_code', 4, 1)
go


/* ********************************************************
    load generic_data_name 'crude_price_composition'
   ******************************************************** */

declare @gdn_num int
if not exists (select * from generic_data_name
               where data_name = 'crude_price_composition')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'crude_price_composition', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'crude_price_composition'
end

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(5, @gdn_num, 'crude_price_composition', 'commkt_key', 1, 1)


insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(6, @gdn_num, 'crude_price_composition', 'nbv_mkt_code', 4, 1)


insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(7, @gdn_num, 'crude_price_composition', 'mkt_percentage', 2, 1)
go


/* ********************************************************
    load generic_data_name 'crude_product_yield'
   ******************************************************** */

declare @gdn_num int
if not exists (select * from generic_data_name
               where data_name = 'crude_product_yield')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'crude_product_yield', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'crude_product_yield'
end


insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(8, @gdn_num, 'crude_product_yield', 'commkt_key', 1, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(9, @gdn_num, 'crude_product_yield', 'nbv_mkt_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(10, @gdn_num, 'crude_product_yield', 'product_cmdty_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(11, @gdn_num, 'crude_product_yield', 'product_yield_percentage', 2, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(12, @gdn_num, 'crude_product_yield', 'start_month', 1, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(13, @gdn_num, 'crude_product_yield', 'end_month', 1, 1)
go


/* ********************************************************
    load generic_data_name 'product_quote_factor'
   ******************************************************** */

declare @gdn_num int
if not exists (select * from generic_data_name
               where data_name = 'product_quote_factor')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'product_quote_factor', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'product_quote_factor'
end

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(14, @gdn_num, 'product_quote_factor', 'product_cmdty_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(15, @gdn_num, 'product_quote_factor', 'nbv_mkt_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(16, @gdn_num, 'product_quote_factor', 'from_date', 3, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(17, @gdn_num, 'product_quote_factor', 'to_date', 3, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(18, @gdn_num, 'product_quote_factor', 'quote_commkt_key', 1, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(19, @gdn_num, 'product_quote_factor', 'quote_price_source_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(20, @gdn_num, 'product_quote_factor', 'quote_trading_period', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(21, @gdn_num, 'product_quote_factor', 'quote_price_type', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(22, @gdn_num, 'product_quote_factor', 'quote_percentage', 2, 1)
go


/* ********************************************************
    load generic_data_name 'market_conversion_factor_nbvi'
   ******************************************************** */

declare @gdn_num int
if not exists (select * from generic_data_name
               where data_name = 'nbvi_conversion_factor')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'nbvi_conversion_factor', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'nbvi_conversion_factor'
end

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(107, @gdn_num, 'nbvi_conversion_factor', 'commkt_key', 1, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(108, @gdn_num, 'nbvi_conversion_factor', 'conversion_type_ind', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(109, @gdn_num, 'nbvi_conversion_factor', 'from_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(110, @gdn_num, 'nbvi_conversion_factor', 'to_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(111, @gdn_num, 'nbvi_conversion_factor', 'conversion_factor', 2, 1)
go

/* ********************************************************
    load generic_data_name 'market_costs_nbvi'
   ******************************************************** */

declare @gdn_num int
if not exists (select * from generic_data_name
               where data_name = 'market_costs_nbvi')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'market_costs_nbvi', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'market_costs_nbvi'
end

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(26, @gdn_num, 'market_costs_nbvi', 'commkt_key', 1, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(27, @gdn_num, 'market_costs_nbvi', 'nbv_mkt_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(28, @gdn_num, 'market_costs_nbvi', 'cost_name', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(29, @gdn_num, 'market_costs_nbvi', 'cost_amt', 2, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(30, @gdn_num, 'market_costs_nbvi', 'cost_curr_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(31, @gdn_num, 'market_costs_nbvi', 'cost_uom_code', 4, 1)
go


/* ********************************************************
    load generic_data_name 'flat_rate_values'
   ******************************************************** */

declare @gdn_num int
if not exists (select * from generic_data_name
               where data_name = 'flat_rate_values')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'flat_rate_values', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'flat_rate_values'
end

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(32, @gdn_num, 'flat_rate_values', 'flat_rate_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(33, @gdn_num, 'flat_rate_values', 'from_date', 3, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(34, @gdn_num, 'flat_rate_values', 'to_date', 3, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(35, @gdn_num, 'flat_rate_values', 'flat_rate_value', 2, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(36, @gdn_num, 'flat_rate_values', 'flat_rate_curr_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(37, @gdn_num, 'flat_rate_values', 'flat_rate_uom_code', 4, 1)
go


/* ********************************************************
    load generic_data_name 'world_scale_values'
   ******************************************************** */

declare @gdn_num int
if not exists (select * from generic_data_name
               where data_name = 'world_scale_values')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'world_scale_values', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'world_scale_values'
end


insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(38, @gdn_num, 'world_scale_values', 'world_scale_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(39, @gdn_num, 'world_scale_values', 'from_date', 3, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(40, @gdn_num, 'world_scale_values', 'to_date', 3, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(41, @gdn_num, 'world_scale_values', 'ws_percentage', 2, 1)
go


/* ********************************************************
    load generic_data_name 'realizable_price_differential'
   ******************************************************** */

declare @gdn_num int
if not exists (select * from generic_data_name
               where data_name = 'realizable_price_differential')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'realizable_price_differential', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'realizable_price_differential'
end

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(42, @gdn_num, 'realizable_price_differential', 'commkt_key', 1, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(43, @gdn_num, 'realizable_price_differential', 'rp_diff_value', 2, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(44, @gdn_num, 'realizable_price_differential', 'rp_diff_curr_code', 4, 1)

insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(45, @gdn_num, 'realizable_price_differential', 'rp_diff_uom_code', 4, 1)
go

/* ********************************************************
    load generic_data_name
   ******************************************************** */

declare @gdn_num int
if not exists (select * from generic_data_name
               where data_name = 'EXTENDED INFORMATION')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'EXTENDED INFORMATION', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'EXTENDED INFORMATION'
end

/* ********************************************************
    load generic_data_definition
   ******************************************************** */

declare @gdd_num int
if not exists (select * from generic_data_definition
               where gdn_num = @gdn_num and
                     attr_name = 'table_name')
begin
   select @gdd_num = max(gdd_num)
   from generic_data_definition

   if @gdd_num is null
      select @gdd_num = 1
   else
      select @gdd_num = @gdd_num + 1

   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'X', 'table_name', 4, 1)

   select @gdd_num = @gdd_num + 1  
   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'X', 'field_id', 1, 1)

   select @gdd_num = @gdd_num + 1  
   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'X', 'field_caption', 4, 1)

   select @gdd_num = @gdd_num + 1  
   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'X', 'field_datatype_ind', 4, 1)

   select @gdd_num = @gdd_num + 1  
   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'X', 'field_width', 1, 1)

   select @gdd_num = @gdd_num + 1  
   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'X', 'field_UI', 4, 1)

   select @gdd_num = @gdd_num + 1  
   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'X', 'UI_list', 4, 1)
end
go

/* ********************************************************
    load generic_data_name 'voyage'
   ******************************************************** */

declare @gdn_num int,
        @gdd_num int

if not exists (select * from generic_data_name
               where data_name = 'voyage')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'voyage', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'voyage'
end

if not exists (select * from generic_data_definition
               where gdn_num = @gdn_num and
                     attr_name = 'cmdty_group')
begin
   select @gdd_num = max(gdd_num)
   from generic_data_definition

   if @gdd_num is null
      select @gdd_num = 1
   else
      select @gdd_num = @gdd_num + 1

   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'voyage', 'cmdty_group', 4, 1)

   select @gdd_num = @gdd_num + 1  
   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'voyage', 'year', 4, 1)

   select @gdd_num = @gdd_num + 1  
   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'voyage', 'new_num', 1, 1)

   select @gdd_num = @gdd_num + 1  
   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'voyage', 'alloc_type', 4, 1)
end
go

/* ********************************************************
    load generic_data_name 'valid_price_adj_qty_choices'
   ******************************************************** */

declare @gdn_num int,
        @gdd_num int,
        @gdv_num int

if not exists (select * from generic_data_name
               where data_name = 'valid_price_adj_qty_choices')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'valid_price_adj_qty_choices', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'valid_price_adj_qty_choices'
end

if not exists (select * from generic_data_definition
               where gdn_num = @gdn_num and
                     attr_name = 'qty_name')
begin
   select @gdd_num = max(gdd_num)
   from generic_data_definition

   if @gdd_num is null
      select @gdd_num = 1
   else
      select @gdd_num = @gdd_num + 1

   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'valid_price_adj_qty_choices', 'qty_name', 4, 1)
end

if exists (select * from generic_data_definition
           where gdn_num = @gdn_num and
                 attr_name = 'qty_name')
begin
   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'L/D GROSS PRIMARY')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'L/D GROSS PRIMARY', 1)
   end

   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'L/D NET PRIMARY')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'L/D NET PRIMARY', 1)
   end

   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'B/L GROSS PRIMARY')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'B/L GROSS PRIMARY', 1)
   end

   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'B/L NET PRIMARY')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'B/L NET PRIMARY', 1)
   end

   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'L/D GROSS SECONDARY')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'L/D GROSS SECONDARY', 1)
   end

   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'L/D NET SECONDARY')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'L/D NET SECONDARY', 1)
   end

   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'B/L GROSS SECONDARY')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'B/L GROSS SECONDARY', 1)
   end

   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'B/L NET SECONDARY')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'B/L NET SECONDARY', 1)
   end

   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'ACTUAL PRIMARY GROSS')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'ACTUAL PRIMARY GROSS', 1)
   end

   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'ACTUAL PRIMARY NET')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'ACTUAL PRIMARY NET', 1)
   end

   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'ACTUAL SECONDARY GROSS')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'ACTUAL SECONDARY GROSS', 1)
   end

   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'ACTUAL SECONDARY NET')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'ACTUAL SECONDARY NET', 1)
   end

   if NOT exists (select * from generic_data_values
                  where gdd_num = @gdd_num and
                        string_value = 'CONTRACTED')
   begin
      select @gdv_num = max(gdv_num)
      from generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, 'CONTRACTED', 1)
   end
end
go

/* ********************************************************
    data name 'pipeline cycle year'
   ******************************************************** */

print 'Loading GDN/GDD/GDV data for data_name ''pipeline cycle year''...'
go

declare @gdn_num int,
        @gdd_num int

select @gdn_num = null,
       @gdd_num = null

if not exists (select 1 
               from generic_data_name
               where data_name = 'pipeline cycle year')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'pipeline cycle year', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'pipeline cycle year'
end

/* =================================================================
    Adding the following attributes into the generic_data_definition
    table:

        attr_name             data_type_ind
        --------------------- -------------
        year_num              1
   =================================================================
*/

print '==> adding attributes into generic_data_definition table ..'

/* ***** ATTRIBUTE #1: year_num ***** */

if not exists (select 1 
               from generic_data_definition
               where gdn_num = @gdn_num and
                     attr_name = 'year_num')
begin
   select @gdd_num = max(gdd_num)
   from generic_data_definition

   if @gdd_num is null
      select @gdd_num = 1
   else
      select @gdd_num = @gdd_num + 1

   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'pipeline cycle year', 'year_num', 1, 1)
end


print '==> adding attribute values into generic_data_values table ..'
go

declare @gdd_num1 int,
        @gdv_num  int,
        @gdn_num  int

select @gdd_num1 = null,
       @gdv_num = null,
       @gdn_num = null

if exists (select 1 
           from generic_data_name
           where data_name = 'pipeline cycle year')
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'pipeline cycle year'
end

if @gdn_num is null
begin
   print 'Failed to find the data name ''pipeline cycle year''!'
   goto endofscript
end

/* attribute #1 */
if exists (select 1 
           from generic_data_definition
           where gdn_num = @gdn_num and
                 attr_name = 'year_num')
begin
   select @gdd_num1 = gdd_num
   from generic_data_definition
   where gdn_num = @gdn_num and
         attr_name = 'year_num'
end

if @gdd_num1 is null
begin
   print 'One or some of attributes for data name ''pipeline cycle year'' are missing!'
   goto endofscript
end 


/* --------------------------------------------------------------------------------
    Adding attribute values into the generic_data_values table:
    
      GDV #   [ATTRIBUTE NAME]   ...
              (string_value)
      ------- -----------------  ...
      +1      [ATTRIBUTE VALUE]  ...
      ...           
   ------------------------------------------------------------------------------ */

/* ----------------------------------------------- 
   GDV row #1 

      GDV row #     year_num       
      ------------  -------------------  
      max(gdv)+1    2003
   ----------------------------------------------- */

select @gdv_num = null
select @gdv_num = gdv_num
from generic_data_values
where int_value = 2003 and
      gdd_num = @gdd_num1

if @gdv_num is null
begin
   select @gdv_num = max(gdv_num)
   from generic_data_values

   if @gdv_num is null
      select @gdv_num = 1
   else
      select @gdv_num = @gdv_num + 1
end

if not exists (select 1
               from generic_data_values
               where gdv_num = @gdv_num and
                     gdd_num = @gdd_num1)   
begin
   insert into generic_data_values
     (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
   values(@gdv_num, @gdd_num1, 2003, null, null, null, 1)
end

/* ----------------------------------------------- 
   GDV row #2 

      GDV row #     year_num       
      ------------  ------------------- 
      max(gdv)+2    2004  
   ----------------------------------------------- */

select @gdv_num = null
select @gdv_num = gdv_num
from generic_data_values
where int_value = 2004 and
      gdd_num = @gdd_num1

if @gdv_num is null
begin
   select @gdv_num = max(gdv_num)
   from generic_data_values

   if @gdv_num is null
      select @gdv_num = 1
   else
      select @gdv_num = @gdv_num + 1
end

if not exists (select 1
               from generic_data_values
               where gdv_num = @gdv_num and
                     gdd_num = @gdd_num1)   
begin
   insert into generic_data_values
     (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
   values(@gdv_num, @gdd_num1, 2004, null, null, null, 1)
end

/* ----------------------------------------------- 
   GDV row #3 

      GDV row #     year_num       
      ------------  ------------------- 
      max(gdv)+3    2005  
   ----------------------------------------------- */

select @gdv_num = null
select @gdv_num = gdv_num
from generic_data_values
where int_value = 2005 and
      gdd_num = @gdd_num1

if @gdv_num is null
begin
   select @gdv_num = max(gdv_num)
   from generic_data_values

   if @gdv_num is null
      select @gdv_num = 1
   else
      select @gdv_num = @gdv_num + 1
end

if not exists (select 1
               from generic_data_values
               where gdv_num = @gdv_num and
                     gdd_num = @gdd_num1)   
begin
   insert into generic_data_values
     (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
   values(@gdv_num, @gdd_num1, 2005, null, null, null, 1)
end


print 'All data items for data name ''pipeline cycle year'' were loaded ..'

endofscript:
go

