set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table dbo.account_instruction
go

print 'Loading seed reference data into the account_instruction table ...'
go

insert into dbo.account_instruction 
   (acct_num,
    acct_instr_num,
    cmdty_code,
    del_term_code,
    mot_code,
    pay_term_code,
    pay_method_code,
    acct_instr_type_code,
    acct_addr_num,
    acct_cont_num,
    bank_acct_num,
    num_of_doc_copies,
    send_doc_by_media,
    trans_id,
    instr_analyst_init,
    book_comp_num,
    currency_code)
values(1, 1, NULL, NULL, NULL, NULL, NULL, 
         'CONTRACT', 1, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL)
go

