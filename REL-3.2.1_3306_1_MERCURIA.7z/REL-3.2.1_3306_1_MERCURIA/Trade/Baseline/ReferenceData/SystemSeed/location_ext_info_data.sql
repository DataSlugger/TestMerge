set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the location_ext_info table ...'
go

declare @loc_code   char(8),
        @smsg       varchar(255),
        @n          int

select @n = 0
select @loc_code = min(loc_code)
from location

while @loc_code is not null
begin
   if not exists (select 1
                  from location_ext_info
                  where loc_code = @loc_code)
   begin
      select @n = @n + 1
      select @smsg = '=> Adding a location_ext_info record for the loc_code ''' + @loc_code + ''' ...'
      print @smsg
      insert into location_ext_info
         (loc_code,accountant_id,scheduler_id,trader_id,
          country_code,state_code,county_code,city_code,
          dflt_mot_code,trans_id,permit_holder_acct_num,              
          excise_warehouse_loc_ind,bonded_warehouse_loc_ind,
          postal_code)
        values(@loc_code, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
               NULL, 1, NULL, NULL, NULL, NULL)
   end

   select @loc_code = min(loc_code)
   from location
   where loc_code > @loc_code
end
if @n = 0
   print 'No new location_ext_info record was added!'
else
begin
   select @smsg = convert(varchar, @n) + ' location_ext_info records were added.'
   print @smsg
end
go
