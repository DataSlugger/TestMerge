set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the entity_tag_insp_attr table ...'
go

if object_id('tempdb..#tag_insp_attrs', 'U') is not null
   exec('drop table #tag_insp_attrs')
go

create table #tag_insp_attrs
(
	 tag_name                varchar(16) NOT NULL,
	 ref_insp_attr_name      varchar(30) NOT NULL,
	 ref_insp_attr_value     varchar(60) NOT NULL
)
go

insert into #tag_insp_attrs
      (tag_name, ref_insp_attr_name, ref_insp_attr_value)
   values('BOOKCOMP', 'AcctStatus', 'A'),
         ('BOOKCOMP', 'AcctTypeCode', 'PEICOMP'),
         ('BOOKCOMP', 'InspectorTitle', 'Booking Company')
go


/* ********************************************************************** */
/*  Populate data into the entity_tag_insp_attr table                     */
/* ********************************************************************** */

declare @tag_name          char(8),
        @attr_name         varchar(30),
        @attr_value        varchar(60),
        @smsg              varchar(255),
        @rows_affected     int,
        @errcode           int,
        @entity_tag_id     int
       
select @errcode = 0

select @tag_name = min(tag_name)
from #tag_insp_attrs

while @tag_name is not null
begin
   RAISERROR('*****', 0, 1) with nowait
   RAISERROR('=> Tag: %s', 0, 1, @tag_name) with nowait
   
   select @entity_tag_id = oid
   from dbo.entity_tag_definition
   where entity_tag_name = @tag_name and
         entity_id = (select oid
                      from dbo.icts_entity_name with (nolock)
                      where entity_name = 'Portfolio')
   
   select @attr_name = min(ref_insp_attr_name)
   from #tag_insp_attrs
   where tag_name = @tag_name
   
   while @attr_name is not null
   begin
      select @attr_value = ref_insp_attr_value
      from #tag_insp_attrs
      where tag_name = @tag_name and
            ref_insp_attr_name = @attr_name

      if not exists (select 1
                     from dbo.entity_tag_insp_attr
                     where entity_tag_id = @entity_tag_id and
                           entity_tag_attr_name = @attr_name)
      begin
         begin tran
         begin try
            insert into dbo.entity_tag_insp_attr
                  (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
               values(@entity_tag_id, @attr_name, @attr_value, 1)
         end try
         begin catch
      	   if @@trancount > 0
      	      rollback tran
      	   set @errcode = ERROR_NUMBER()
      	   set @smsg = ERROR_MESSAGE()
      	   RAISERROR('=> Failed to add an entity_tag_insp_attr record with the attr_name ''%s'' for the tag ''%s'' due to the error:', 0, 1, @attr_name, @tag_name) with nowait
      	   RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
           goto nextattr
         end catch
         commit tran
         RAISERROR('=> The entity_tag_insp_attr record with attr_name ''%s'' for the tag ''%s'' was successfully added.', 0, 1, @attr_name, @tag_name) with nowait
      end

nextattr:
      select @attr_name = min(ref_insp_attr_name)
      from #tag_insp_attrs
      where tag_name = @tag_name and
            ref_insp_attr_name > @attr_name
   end
   
   select @tag_name = min(tag_name)
   from #tag_insp_attrs
   where tag_name > @tag_name
end /* while */
endofscript:
go

if object_id('tempdb..#tag_insp_attrs', 'U') is not null
   exec('drop table #tag_insp_attrs')
go


/* ********************************************************************************* */

if object_id('tempdb..#porttagdefs', 'U') is not null
   exec('drop table #porttagdefs')
go

create table #porttagdefs
(
	tag_name                varchar(16) NOT NULL,
	ref_insp_name           varchar(30) NULL,
	ref_insp_formatter_key  varchar(30) NULL
)
go

insert into #porttagdefs 
      (tag_name, ref_insp_name, ref_insp_formatter_key)
   values ('TRADER', 'IctsUser','userInit'),
          ('INTRNSRC', 'PriceSource', 'priceSourceCode'),
          ('BOOKCOMP', 'Account', 'acctShortName')
go

declare @tag_name               char(8),
        @ref_insp_name          varchar(30),
        @ref_insp_formatter_key varchar(30),
        @smsg                   varchar(255),
        @rows_affected          int,
        @errcode                int,
        @entity_tag_id          int
       
select @errcode = 0

select @tag_name = min(tag_name)
from #porttagdefs

while @tag_name is not null
begin
   RAISERROR('*****', 0, 1) with nowait
   RAISERROR('=> Tag: %s', 0, 1, @tag_name) with nowait
   
   select @entity_tag_id = oid
   from dbo.entity_tag_definition
   where entity_tag_name = @tag_name
   
   select @ref_insp_name = ref_insp_name,
          @ref_insp_formatter_key = ref_insp_formatter_key
   from #porttagdefs
   where tag_name = @tag_name

   select @smsg = @ref_insp_name + '%'
   if not exists (select 1
                  from dbo.entity_tag_insp_attr
                  where entity_tag_id = @entity_tag_id and
                       entity_tag_attr_name = 'RefInspName' and
                       entity_tag_attr_value like @smsg)
   begin
      begin tran
      begin try
        insert into dbo.entity_tag_insp_attr
             (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
          values(@entity_tag_id, 'RefInspName', @ref_insp_name, 1)
      end try
      begin catch
      	if @@trancount > 0
      	   rollback tran
      	set @errcode = ERROR_NUMBER()
      	set @smsg = ERROR_MESSAGE()
      	RAISERROR('=> Failed to add an entity_tag_insp_attr record for the tag ''%s''and attr ''RefInspName'' due to the error:', 0, 1, @tag_name) with nowait
      	RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
        goto nexttag1
      end catch
      commit tran
      RAISERROR('=> An entity_tag_insp_attr record was successfully added for the tag ''%s''and attr ''RefInspName''.', 0, 1, @tag_name) with nowait
   end

   select @smsg = @ref_insp_formatter_key + '%'
   if not exists (select 1
                  from dbo.entity_tag_insp_attr
                  where entity_tag_id = @entity_tag_id and
                       entity_tag_attr_name = 'FormatterKey' and
                       entity_tag_attr_value like @smsg)
   begin
      begin tran
      begin try
        insert into dbo.entity_tag_insp_attr
             (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
           values(@entity_tag_id, 'FormatterKey', @ref_insp_formatter_key, 1)
      end try
      begin catch
      	if @@trancount > 0
      	   rollback tran
      	set @errcode = ERROR_NUMBER()
      	set @smsg = ERROR_MESSAGE()
      	RAISERROR('=> Failed to add an entity_tag_insp_attr record for the tag ''%s''and attr ''FormatterKey'' due to the error:', 0, 1, @tag_name) with nowait
      	RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
        goto nexttag1
      end catch
      commit tran
      RAISERROR('=> An entity_tag_insp_attr record was successfully added for the tag ''%s''and attr ''FormatterKey''.', 0, 1, @tag_name) with nowait
   end

nexttag1:   
   select @tag_name = min(tag_name)
   from #porttagdefs
   where tag_name > @tag_name
end /* while */
endofscript:
go

if object_id('tempdb..#porttagdefs', 'U') is not null
   exec('drop table #porttagdefs')
go



/* ****************************************************************************************** */

declare @oid                     numeric(18, 0),
        @target_entity_id        int,
        @entity_id               int,
        @errcode                 int,
        @row_affected            int,
        @entity_tag_id           int,
        @entity_tag_attr_name    char(16),
        @entity_tag_attr_value   varchar(255),
        @entity_name             varchar(30),
        @target_entity_name      varchar(30),
        @smsg                    varchar(255),
        @entity_tag_name         varchar(16),
        @status                  int  


CREATE TABLE #tag_insp_attrs
(
   oid                     numeric(18, 0) IDENTITY,
   entity_tag_id           int              NOT NULL,
   entity_tag_attr_name    char(16)         NOT NULL,
   entity_tag_attr_value   varchar(255)     NOT NULL,
   entity_tag_name         varchar(16)      NULL,
   entity_name             varchar(30)      NULL
)
      
select @errcode = 0

/* -------------------------------------------------------------------------- 
    Adding the following entity_tag_insp_attr records 

       entity_tag_id          : oid for entity tag 'TRADER' 
                                  (entity: Portfolio, target entity: NULL)
       entity_tag_attr_name   : UserStatus
       entity_tag_attr_value  : A

       entity_tag_id          : oid for entity tag 'TRADER' 
                                  (entity: Trade, target entity: Uom)
       entity_tag_attr_name   : InspectorTitle
       entity_tag_attr_value  : Trader

       entity_tag_id          : oid for entity tag 'TRADER' 
                                  (entity: Trade, target entity: Uom)
       entity_tag_attr_name   : InspectorTitle
       entity_tag_attr_value  : Trader
   -------------------------------------------------------------------------- */

print '=> Saving Attributes for the tag ''TRADER'' (entity ''Portfolio'') '
print '       into temporary table ...'

-- ***** TAG: TRADER       
select @target_entity_name = null,
       @entity_name = 'Portfolio',
       @target_entity_id = null,
       @entity_id = null,
       @entity_tag_name = 'TRADER'

if @target_entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @target_entity_name, @target_entity_id OUTPUT
   if @status > 0 or @target_entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @target_entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

if @entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @entity_name, @entity_id OUTPUT
   if @status > 0 or @entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

exec @status = dbo.usp_find_entity_tag_id @target_entity_id, @entity_id, @entity_tag_name, @entity_tag_id OUTPUT
if @status > 0 or @entity_tag_id is null
begin
   select @smsg = 'Could not find the ID for the entity_tag_name ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''') in the entity_tag_definition table!'
   print @smsg
   goto endofscript
end

insert into #tag_insp_attrs
     (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, entity_tag_name, entity_name)
   values (@entity_tag_id, 'UserStatus', 'A', @entity_tag_name, @entity_name)
insert into #tag_insp_attrs
     (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, entity_tag_name, entity_name)
   values (@entity_tag_id, 'InspectorTitle', 'Trader', @entity_tag_name, @entity_name)



/* -------------------------------------------------------------------------- 
    Adding the following entity_tag_insp_attr records 

       entity_tag_id          : oid for entity tag 'TotalQty' 
                                  (entity: Trade, target entity: NULL)
       entity_tag_attr_name   : RefInspName
       entity_tag_attr_value  : Quantity

       entity_tag_id          : oid for entity tag 'TotalQtyUom' 
                                  (entity: Trade, target entity: Uom)
       entity_tag_attr_name   : FormatterKey
       entity_tag_attr_value  : uomCode

       entity_tag_id          : oid for entity tag 'TotalQtyUom'
                                  (entity: Trade, target entity: Uom)
       entity_tag_attr_name   : RefInspName
       entity_tag_attr_value  : UOM
   -------------------------------------------------------------------------- */

print '=> Saving Attributes for the tags ''TotalQty''and ''TotalQtyUom'' (entity ''Trade'') '
print '       into temporary table ...'

-- ***** TAG: TotalQty       
select @target_entity_name = null,
       @entity_name = 'Trade',
       @target_entity_id = null,
       @entity_id = null,
       @entity_tag_name = 'TotalQty'

if @target_entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @target_entity_name, @target_entity_id OUTPUT
   if @status > 0 or @target_entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @target_entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

if @entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @entity_name, @entity_id OUTPUT
   if @status > 0 or @entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

exec @status = dbo.usp_find_entity_tag_id @target_entity_id, @entity_id, @entity_tag_name, @entity_tag_id OUTPUT
if @status > 0 or @entity_tag_id is null
begin
   select @smsg = 'Could not find the ID for the entity_tag_name ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''') in the entity_tag_definition table!'
   print @smsg
   goto endofscript
end

insert into #tag_insp_attrs
     (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, entity_tag_name, entity_name)
   values (@entity_tag_id, 'RefInspName', 'Quantity', @entity_tag_name, @entity_name)

-- ***** TAG: TotalQtyUom 
select @target_entity_name = 'Uom',
       @target_entity_id = null,
       @entity_tag_name = 'TotalQtyUom'

if @target_entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @target_entity_name, @target_entity_id OUTPUT
   if @status > 0 or @target_entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @target_entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

exec @status = dbo.usp_find_entity_tag_id @target_entity_id, @entity_id, @entity_tag_name, @entity_tag_id OUTPUT
if @status > 0 or @entity_tag_id is null
begin
   select @smsg = 'Could not find the ID for the entity_tag_name ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''') in the entity_tag_definition table!'
   print @smsg
   goto endofscript
end

insert into #tag_insp_attrs
     (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, entity_tag_name, entity_name)
   values (@entity_tag_id, 'FormatterKey', 'uomCode', @entity_tag_name, @entity_name)
insert into #tag_insp_attrs
     (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, entity_tag_name, entity_name)
   values (@entity_tag_id, 'RefInspName', 'UOM', @entity_tag_name, @entity_name)


/* -------------------------------------------------------------------------- 
    Adding the following entity_tag_insp_attr record

       entity_tag_id          : oid for entity tag 'COST_BOOK_X_RATE' 
                                  (entity: Cost, target entity: NULL)
       entity_tag_attr_name   : RefInspName
       entity_tag_attr_value  : Price
   -------------------------------------------------------------------------- */

print '=> Saving Attributes for the tags ''TotalQty''and ''TotalQtyUom'' (entity ''Trade'') '
print '        into temporary table ...'

select @target_entity_name = null,
       @entity_name = 'Cost',
       @target_entity_id = null,
       @entity_id = null,
       @entity_tag_name = 'COST_BOOK_X_RATE'

if @target_entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @target_entity_name, @target_entity_id OUTPUT
   if @status > 0 or @target_entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @target_entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

if @entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @entity_name, @entity_id OUTPUT
   if @status > 0 or @entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

exec @status = dbo.usp_find_entity_tag_id @target_entity_id, @entity_id, @entity_tag_name, @entity_tag_id OUTPUT
if @status > 0 or @entity_tag_id is null
begin
   select @smsg = 'Could not find the ID for the entity_tag_name ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''') in the entity_tag_definition table!'
   print @smsg
   goto endofscript
end

insert into #tag_insp_attrs
     (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, entity_tag_name, entity_name)
   values (@entity_tag_id, 'RefInspName', 'Price', @entity_tag_name, @entity_name)

/* -------------------------------------------------------------------------- 
     adding the following 1 entity_tag_insp_attr records

       entity_tag_id          : oid for entity tag 'EstimateQty' 
                                  (entity: Position, target entity: NULL)
       entity_tag_attr_name   : RefInspName
       entity_tag_attr_value  : Quantity

       entity_tag_id          : oid for entity tag 'EstPricedQty' 
                                  (entity: Position, target entity: NULL)
       entity_tag_attr_name   : RefInspName
       entity_tag_attr_value  : Quantity
   -------------------------------------------------------------------------- */

print '=> Saving Attributes for the tags ''EstimateQty'' and ''EstPricedQty'' (entity ''Position'') '
print '        into temporary table ...'

-- **** TAG: EstimateQty
select @target_entity_name = null,
       @entity_name = 'Position',
       @target_entity_id = null,
       @entity_id = null,
       @entity_tag_name = 'EstimateQty'

if @target_entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @target_entity_name, @target_entity_id OUTPUT
   if @status > 0 or @target_entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @target_entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

if @entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @entity_name, @entity_id OUTPUT
   if @status > 0 or @entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

exec @status = dbo.usp_find_entity_tag_id @target_entity_id, @entity_id, @entity_tag_name, @entity_tag_id OUTPUT
if @status > 0 or @entity_tag_id is null
begin
   select @smsg = 'Could not find the ID for the entity_tag_name ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''') in the entity_tag_definition table!'
   print @smsg
   goto endofscript
end

insert into #tag_insp_attrs
     (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, entity_tag_name, entity_name)
   values (@entity_tag_id, 'RefInspName', 'Quantity', @entity_tag_name, @entity_name)

-- **** TAG: EstPricedQty
select @entity_tag_name = 'EstPricedQty'

exec @status = dbo.usp_find_entity_tag_id @target_entity_id, @entity_id, @entity_tag_name, @entity_tag_id OUTPUT
if @status > 0 or @entity_tag_id is null
begin
   select @smsg = 'Could not find the ID for the entity_tag_name ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''') in the entity_tag_definition table!'
   print @smsg
   goto endofscript
end

insert into #tag_insp_attrs
     (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, entity_tag_name, entity_name)
   values (@entity_tag_id, 'RefInspName', 'Quantity', @entity_tag_name, @entity_name)







print ' '
/* ******************************************************************** */
/* The code cody for adding records into the entity_tag_insp_attr table */
/* ******************************************************************** */

declare @tag_attr_value varchar(255)

select @oid = min(oid)
from #tag_insp_attrs

while @oid is not null
begin
   select @entity_tag_id = entity_tag_id,
          @entity_tag_attr_name = entity_tag_attr_name,
          @entity_tag_attr_value = entity_tag_attr_value,
          @tag_attr_value = case when entity_tag_attr_value is null
                                    then '%'
                                 else
                                    rtrim(entity_tag_attr_value) + '%'
                            end,
          @entity_tag_name = entity_tag_name,
          @entity_name = entity_name
   from #tag_insp_attrs
   where oid = @oid
   
   if not exists (select 1
                  from dbo.entity_tag_insp_attr
                  where entity_tag_id = @entity_tag_id and
                        entity_tag_attr_name = @entity_tag_attr_name and
                        entity_tag_attr_value like @tag_attr_value)          
   begin
      begin tran   
      insert into dbo.entity_tag_insp_attr
          (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
        values(@entity_tag_id, @entity_tag_attr_name, @entity_tag_attr_value, 1)
      select @row_affected = @@rowcount,
             @errcode = @@error
      if @errcode > 0 or @row_affected = 0
      begin
         if @@trancount > 0
            rollback tran
         if @errcode > 0
            goto endofscript
      end
      else
      begin
         commit tran
         select @smsg = '=> TAG ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''')'
         print @smsg
         select @smsg = '==> The attr name ''' + rtrim(@entity_tag_attr_name) + ''' was added successfully!' 
         print @smsg
      end  
   end
   
   select @oid = min(oid)
   from #tag_insp_attrs
   where oid > @oid       
end
endofscript:
drop table #tag_insp_attrs
go
