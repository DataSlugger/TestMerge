set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table booking_period
go

print 'Loading seed reference data into the booking_period table ...'
go

insert into dbo.booking_period 
   values(1, 2000, 1, 'Jan  1 2000 12:00:00', 'Feb  1 2000 12:00:00', 'X', 1)
go

insert into dbo.booking_period 
   values(1, 2000, 2, 'Feb  1 2000 12:00:00', 'Mar  1 2000 12:00:00', 'X', 1)
go

insert into dbo.booking_period 
   values(1, 2000, 3, 'Mar  1 2000 12:00:00', 'Apr  1 2000 12:00:00', 'X', 1)
go

insert into dbo.booking_period 
   values(1, 2000, 4, 'Apr  1 2000 12:00:00', 'May  1 2000 12:00:00', 'X', 1)
go

insert into dbo.booking_period 
   values(1, 2000, 5, 'May  1 2000 12:00:00', 'Jun  1 2000 12:00:00', 'X', 1)
go

insert into dbo.booking_period 
   values(1, 2000, 6, 'Jun  1 2000 12:00:00', 'Jul  1 2000 12:00:00', 'X', 1)
go

insert into dbo.booking_period 
   values(1, 2000, 7, 'Jul  1 2000 12:00:00', 'Aug  1 2000 12:00:00', 'X', 1)
go

insert into dbo.booking_period 
   values(1, 2000, 8, 'Aug  1 2000 12:00:00', 'Sep  1 2000 12:00:00', 'X', 1)
go

insert into dbo.booking_period 
   values(1, 2000, 9, 'Sep  1 2000 12:00:00', 'Oct  1 2000 12:00:00', 'C', 1)
go

insert into dbo.booking_period 
   values(1, 2000, 10, 'Oct  1 2000 12:00:00', 'Nov  1 2000 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2000, 11, 'Nov  1 2000 12:00:00', 'Dec  1 2000 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2000, 12, 'Dec  1 2000 12:00:00', 'Jan  1 2001 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2001, 1, 'Jan  1 2001 12:00:00', 'Feb  1 2001 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2001, 2, 'Feb  1 2001 12:00:00', 'Mar  1 2001 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2001, 3, 'Mar  1 2001 12:00:00', 'Apr  1 2001 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2001, 4, 'Apr  1 2001 12:00:00', 'May  1 2001 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2001, 5, 'May  1 2001 12:00:00', 'Jun  1 2001 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2001, 6, 'Jun  1 2001 12:00:00', 'Jul  1 2001 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2001, 7, 'Jul  1 2001 12:00:00', 'Aug  1 2001 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2001, 8, 'Aug  1 2001 12:00:00', 'Sep  1 2001 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2001, 9, 'Sep  1 2001 12:00:00', 'Oct  1 2001 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2001, 10, 'Oct  1 2001 12:00:00', 'Nov  1 2001 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2001, 11, 'Nov  1 2001 12:00:00', 'Dec  1 2001 12:00:00', 'O', 1)
go

insert into dbo.booking_period 
   values(1, 2001, 12, 'Dec  1 2001 12:00:00', 'Jan  1 2002 12:00:00', 'O', 1)
go

