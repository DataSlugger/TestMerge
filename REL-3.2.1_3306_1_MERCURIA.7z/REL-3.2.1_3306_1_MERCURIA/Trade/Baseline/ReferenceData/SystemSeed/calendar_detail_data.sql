set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table calendar_detail
go

print 'Loading seed reference data into the calendar_detail table ...'
go

insert into calendar_detail values('APISTATS', 'Mar  1 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar  6 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar  8 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 10 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 13 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 15 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 16 2000 12:00:00', NULL, 
'Thursday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 20 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 22 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 24 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 27 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 29 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 31 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Apr  3 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Apr  5 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Apr  7 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Apr 10 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Apr 12 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Apr 14 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Apr 17 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Apr 19 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Apr 21 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Apr 24 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Apr 26 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Apr 28 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'May  1 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'May  3 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'May  5 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'May  8 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'May 10 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'May 12 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'May 15 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'May 17 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'May 18 2000 12:00:00', NULL, 
'Thursday', 1)
go

insert into calendar_detail values('APISTATS', 'May 22 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'May 24 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'May 26 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'May 29 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'May 31 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun  2 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun  5 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun  7 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun  9 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun 12 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun 14 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun 16 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun 19 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun 21 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun 23 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun 26 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun 28 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jun 30 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul  3 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul  5 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul  7 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul 10 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul 12 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul 14 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul 17 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul 19 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul 20 2000 12:00:00', NULL, 
'Thursday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul 24 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul 26 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul 28 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jul 31 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug  2 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug  4 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug  7 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug  9 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug 11 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug 14 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug 16 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug 18 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug 21 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug 23 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug 25 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug 28 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Aug 30 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep  1 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep  4 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep  6 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep  8 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep 11 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep 13 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep 15 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep 18 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep 20 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep 22 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep 25 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep 27 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Sep 29 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct  2 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct  4 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct  6 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct  9 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct 10 2000 12:00:00', NULL, 
'Tuesday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct 12 2000 12:00:00', NULL, 
'Thursday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct 16 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct 18 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct 20 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct 23 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct 25 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct 26 2000 12:00:00', NULL, 
'Thursday', 1)
go

insert into calendar_detail values('APISTATS', 'Oct 30 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov  1 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov  3 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov  6 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov  8 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov 10 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov 13 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov 15 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov 17 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov 20 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov 22 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov 23 2000 12:00:00', NULL, 
'Thursday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov 27 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Nov 29 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec  1 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec  4 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec  6 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec  8 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec 11 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec 13 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec 15 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec 18 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec 20 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec 22 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec 25 2000 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec 27 2000 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Dec 29 2000 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan  1 2001 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan  3 2001 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan  5 2001 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan  8 2001 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan 10 2001 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan 12 2001 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan 15 2001 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan 17 2001 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan 19 2001 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan 22 2001 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan 24 2001 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan 26 2001 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan 29 2001 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Jan 31 2001 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Feb  2 2001 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Feb  5 2001 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Feb  7 2001 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Feb  9 2001 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Feb 12 2001 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Feb 14 2001 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Feb 16 2001 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Feb 19 2001 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Feb 21 2001 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Feb 23 2001 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Feb 26 2001 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Feb 28 2001 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar  2 2001 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar  5 2001 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar  7 2001 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar  9 2001 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 12 2001 12:00:00', NULL, 
'Monday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 14 2001 12:00:00', NULL, 
'Wednesday', 1)
go

insert into calendar_detail values('APISTATS', 'Mar 16 2001 12:00:00', NULL, 
'Friday', 1)
go

insert into calendar_detail values('BANKSUS', 'Jan  1 1996 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jan 15 1996 12:00:00', NULL, 
'Martin Luther King''s B''Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Feb 19 1996 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'May 27 1996 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jul  4 1996 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Sep  2 1996 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Oct 14 1996 12:00:00', NULL, 
'Columbus Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Nov 11 1996 12:00:00', NULL, 
'Veterans Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Nov 28 1996 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Dec 25 1996 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jan 20 1997 12:00:00', NULL, 
'Martin Luther King''s B''Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Feb 17 1997 12:00:00', NULL, 
'Presidents Day', 1)
go

insert into calendar_detail values('BANKSUS', 'May 26 1997 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jul  4 1997 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Sep  1 1997 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Nov 27 1997 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Dec 25 1997 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jan  1 1998 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jan 19 1998 12:00:00', NULL, 
'Martin Luther King''s B''Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Feb 16 1998 12:00:00', NULL, 
'Presidents Day', 1)
go

insert into calendar_detail values('BANKSUS', 'May 25 1998 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jul  4 1998 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Sep  7 1998 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Oct 12 1998 12:00:00', NULL, 
'Columbus Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Nov 11 1998 12:00:00', NULL, 
'Veterans Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Nov 26 1998 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Dec 25 1998 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jan  1 1999 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jan 17 1999 12:00:00', NULL, 
'Martin Luther King''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Feb 21 1999 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Apr  5 1999 12:00:00', NULL, 
'Independance Day', 1)
go

insert into calendar_detail values('BANKSUS', 'May 31 1999 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Sep  6 1999 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Oct 11 1999 12:00:00', NULL, 
'Columbus Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Nov 11 1999 12:00:00', NULL, 
'Veterans Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Nov 25 1999 12:00:00', NULL, 
'Thanksgiving', 1)
go

insert into calendar_detail values('BANKSUS', 'Dec 25 1999 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jan  3 2000 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jan 17 2000 12:00:00', NULL, 
'Martin Luther King''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Feb 21 2000 12:00:00', NULL, 
'Presidents Day', 1)
go

insert into calendar_detail values('BANKSUS', 'May 29 2000 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jul  4 2000 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Sep  4 2000 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Oct  9 2000 12:00:00', NULL, 
'Columbus Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Nov 11 2000 12:00:00', NULL, 
'Veteran''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Nov 23 2000 12:00:00', NULL, 
'Thankgiving Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Dec 25 2000 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jan  1 2001 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jan 15 2001 12:00:00', NULL, 
'Martin Luther King''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Feb 19 2001 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'May 28 2001 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Jul  4 2001 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Sep  3 2001 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Oct  8 2001 12:00:00', NULL, 
'Columbus Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Nov 12 2001 12:00:00', NULL, 
'Veteran''s Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Nov 22 2001 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('BANKSUS', 'Dec 25 2001 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('CANADAGA', 'Jan  1 1995 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('CANADAGA', 'Jan  2 1995 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('CANADAGA', 'Jul  3 1995 12:00:00', NULL, 
'Dominion day', 1)
go

insert into calendar_detail values('CANADAGA', 'Jan  1 1996 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('CANADAGA', 'Jul  1 1996 12:00:00', NULL, 
'Dominion Day', 1)
go

insert into calendar_detail values('CANADAGA', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('CANADAGA', 'Jul  1 1997 12:00:00', NULL, 
'Canada Day', 1)
go

insert into calendar_detail values('CANADAGA', 'Jan  1 1998 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('CBOT', 'Jan  1 1993 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('CBOT', 'Feb 15 1993 12:00:00', NULL, 
'USA Presidents Day', 1)
go

insert into calendar_detail values('CBOT', 'Apr  9 1993 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('CBOT', 'May 31 1993 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('CBOT', 'Jul  5 1993 12:00:00', NULL, 
'USA Independence Day', 1)
go

insert into calendar_detail values('CBOT', 'Sep  6 1993 12:00:00', NULL, 
'USA Labor day', 1)
go

insert into calendar_detail values('CBOT', 'Nov 25 1993 12:00:00', NULL, 
'USA Thanksgiving Day', 1)
go

insert into calendar_detail values('CBOT', 'Nov 26 1993 12:00:00', NULL, 
'USA Thanksgiving Day', 1)
go

insert into calendar_detail values('CBOT', 'Dec 24 1993 12:00:00', NULL, 
'Christmas  Eve', 1)
go

insert into calendar_detail values('CBOT', 'Jan  2 1995 12:00:00', NULL, 
'New Years Day (Observed)', 1)
go

insert into calendar_detail values('CBOT', 'Feb 20 1995 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('CBOT', 'Apr 14 1995 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('CBOT', 'Jul  4 1995 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('CBOT', 'Sep  4 1995 12:00:00', NULL, 
'Labour Day', 1)
go

insert into calendar_detail values('CBOT', 'Nov 23 1995 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('CBOT', 'Dec 25 1995 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('CBOT', 'Jan  1 1996 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('CBOT', 'Feb 19 1996 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('CBOT', 'Apr  5 1996 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('CBOT', 'May 27 1996 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('CBOT', 'Jul  4 1996 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('CBOT', 'Jul  5 1996 12:00:00', NULL, 
'Day After Independence Day', 1)
go

insert into calendar_detail values('CBOT', 'Sep  2 1996 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('CBOT', 'Nov 28 1996 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('CBOT', 'Nov 29 1996 12:00:00', NULL, 
'Day After Thanksgiving', 1)
go

insert into calendar_detail values('CBOT', 'Dec 25 1996 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('CBOT', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('CBOT', 'Feb 17 1997 12:00:00', NULL, 
'Presidents Day', 1)
go

insert into calendar_detail values('CBOT', 'Mar 28 1997 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('CBOT', 'May 26 1997 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('CBOT', 'Jul  4 1997 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('CBOT', 'Sep  1 1997 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('CBOT', 'Nov 27 1997 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('CBOT', 'Nov 28 1997 12:00:00', NULL, 
'Day after Thanksgiving Day', 1)
go

insert into calendar_detail values('CBOT', 'Dec 25 1997 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('CBOT', 'Jan  1 1998 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('CBOT', 'Feb 16 1998 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('COMEX', 'Jul  5 1993 12:00:00', NULL, 
'USA Independence Day', 1)
go

insert into calendar_detail values('COMEX', 'Sep  6 1993 12:00:00', NULL, 
'USA Labor day', 1)
go

insert into calendar_detail values('COMEX', 'Nov 25 1993 12:00:00', NULL, 
'USA Thanksgiving Day', 1)
go

insert into calendar_detail values('COMEX', 'Nov 26 1993 12:00:00', NULL, 
'USA Thanksgiving Day', 1)
go

insert into calendar_detail values('COMEX', 'Dec 24 1993 12:00:00', NULL, 
'Christmas  Eve', 1)
go

insert into calendar_detail values('COMEX', 'Dec 31 1993 12:00:00', NULL, 
'New Years  Eve', 1)
go

insert into calendar_detail values('COMEX', 'Feb 20 1995 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('COMEX', 'Sep  4 1995 12:00:00', NULL, 
'Labour Day', 1)
go

insert into calendar_detail values('COMEX', 'Dec 25 1995 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('COMEX', 'Jan  1 1996 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('COMEX', 'Jan  8 1996 12:00:00', NULL, 
'Snow Day Holiday', 1)
go

insert into calendar_detail values('COMEX', 'Feb 19 1996 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('COMEX', 'May 27 1996 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('COMEX', 'Jul  4 1996 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('COMEX', 'Sep  2 1996 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('COMEX', 'Nov 28 1996 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('COMEX', 'Dec 25 1996 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('COMEX', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('COMEX', 'Feb 17 1997 12:00:00', NULL, 
'Presidents Day', 1)
go

insert into calendar_detail values('COMEX', 'May 26 1997 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('COMEX', 'Jul  4 1997 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('COMEX', 'Sep  1 1997 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('COMEX', 'Nov 27 1997 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('COMEX', 'Dec 25 1997 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('COMEX', 'Jan  1 1998 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('CSCE', 'Feb 20 1995 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('CSCE', 'Sep  4 1995 12:00:00', NULL, 
'Labour Day', 1)
go

insert into calendar_detail values('CSCE', 'Jan  1 1996 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('CSCE', 'Feb 19 1996 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('CSCE', 'May 27 1996 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('CSCE', 'Jul  4 1996 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('CSCE', 'Sep  2 1996 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('CSCE', 'Nov 28 1996 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('CSCE', 'Dec 25 1996 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('CSCE', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('CSCE', 'Feb 17 1997 12:00:00', NULL, 
'Presidents Day', 1)
go

insert into calendar_detail values('CSCE', 'May 26 1997 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('CSCE', 'Jul  4 1997 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('CSCE', 'Sep  1 1997 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('CSCE', 'Nov 27 1997 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('CSCE', 'Dec 25 1997 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('CSCE', 'Jan  1 1998 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 12 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 14 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 15 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 16 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 17 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 18 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 19 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 21 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 22 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 23 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 24 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 25 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 26 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 28 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 29 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('FRIDAYS', 'Sep 30 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('GASDAILY', 'Jan  1 1996 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('GASDAILY', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('GASDAILY', 'Jan  1 1998 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('IPE', 'Jan  1 1992 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('IPE', 'Apr 17 1992 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('IPE', 'Apr 20 1992 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('IPE', 'May  4 1992 12:00:00', NULL, 
'May Day', 1)
go

insert into calendar_detail values('IPE', 'May 20 1992 12:00:00', NULL, 
'May Spring Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Aug 31 1992 12:00:00', NULL, 
'Summer Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Dec 25 1992 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('IPE', 'Dec 28 1992 12:00:00', NULL, 
'Boxing Day', 1)
go

insert into calendar_detail values('IPE', 'Jan  3 1994 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('IPE', 'Apr  1 1994 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('IPE', 'Apr  4 1994 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('IPE', 'May  2 1994 12:00:00', NULL, 
'May Day', 1)
go

insert into calendar_detail values('IPE', 'May 30 1994 12:00:00', NULL, 
'Spring Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Aug 29 1994 12:00:00', NULL, 
'Summer Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Dec 26 1994 12:00:00', NULL, 
'Boxing Day', 1)
go

insert into calendar_detail values('IPE', 'Dec 27 1994 12:00:00', NULL, 
'Day after Boxing Day', 1)
go

insert into calendar_detail values('IPE', 'Jan  2 1995 12:00:00', NULL, 
'Day after New Year''s Day', 1)
go

insert into calendar_detail values('IPE', 'Apr 14 1995 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('IPE', 'Apr 17 1995 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('IPE', 'May  8 1995 12:00:00', NULL, 
'EARLY MAY HOLIDAY', 1)
go

insert into calendar_detail values('IPE', 'May 29 1995 12:00:00', NULL, 
'Spring Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Aug 28 1995 12:00:00', NULL, 
'Summer Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Dec 25 1995 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('IPE', 'Dec 26 1995 12:00:00', NULL, 
'Boxing Day', 1)
go

insert into calendar_detail values('IPE', 'Jan  1 1996 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('IPE', 'Apr  5 1996 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('IPE', 'Apr  8 1996 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('IPE', 'May  6 1996 12:00:00', NULL, 
'Early May Holiday', 1)
go

insert into calendar_detail values('IPE', 'May 27 1996 12:00:00', NULL, 
'Spring Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Aug 26 1996 12:00:00', NULL, 
'Summer Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Dec 25 1996 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('IPE', 'Dec 26 1996 12:00:00', NULL, 
'Boxing Day', 1)
go

insert into calendar_detail values('IPE', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('IPE', 'Mar 28 1997 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('IPE', 'Mar 31 1997 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('IPE', 'May  5 1997 12:00:00', NULL, 
'May Day Holiday', 1)
go

insert into calendar_detail values('IPE', 'May 26 1997 12:00:00', NULL, 
'Spring Holiday', 1)
go

insert into calendar_detail values('IPE', 'Aug 25 1997 12:00:00', NULL, 
'Late Summer Holiday', 1)
go

insert into calendar_detail values('IPE', 'Dec 25 1997 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('IPE', 'Dec 26 1997 12:00:00', NULL, 
'Boxing Day', 1)
go

insert into calendar_detail values('IPE', 'Jan  1 1998 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('IPE', 'Apr 10 1998 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('IPE', 'Apr 13 1998 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('IPE', 'May  4 1998 12:00:00', NULL, 
'May Day Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'May 25 1998 12:00:00', NULL, 
'Spring Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Aug 31 1998 12:00:00', NULL, 
'Summer Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Dec 25 1998 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('IPE', 'Dec 28 1998 12:00:00', NULL, 
'Boxing Day', 1)
go

insert into calendar_detail values('IPE', 'Jan  1 1999 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('IPE', 'Apr  2 1999 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('IPE', 'Apr  5 1999 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('IPE', 'May  3 1999 12:00:00', NULL, 
'Public Holiday', 1)
go

insert into calendar_detail values('IPE', 'May 31 1999 12:00:00', NULL, 
'Public Holiday', 1)
go

insert into calendar_detail values('IPE', 'Aug 30 1999 12:00:00', NULL, 
'Public Holiday', 1)
go

insert into calendar_detail values('IPE', 'Dec 27 1999 12:00:00', NULL, 
'Christmas Holiday', 1)
go

insert into calendar_detail values('IPE', 'Dec 28 1999 12:00:00', NULL, 
'Christmas Holiday', 1)
go

insert into calendar_detail values('IPE', 'Dec 31 1999 12:00:00', NULL, 
'New Years Eve Holiday', 1)
go

insert into calendar_detail values('IPE', 'Jan  3 2000 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('IPE', 'Apr 21 2000 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('IPE', 'Apr 24 2000 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('IPE', 'May  1 2000 12:00:00', NULL, 
'May Day Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'May 29 2000 12:00:00', NULL, 
'Spring Holiday', 1)
go

insert into calendar_detail values('IPE', 'Aug 28 2000 12:00:00', NULL, 
'Summer Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Dec 25 2000 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('IPE', 'Dec 26 2000 12:00:00', NULL, 
'Boxing Day', 1)
go

insert into calendar_detail values('IPE', 'Jan  1 2001 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('IPE', 'Apr 13 2001 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('IPE', 'Apr 16 2001 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('IPE', 'May  7 2001 12:00:00', NULL, 
'May Day Holiday', 1)
go

insert into calendar_detail values('IPE', 'May 28 2001 12:00:00', NULL, 
'Spring Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Aug 27 2001 12:00:00', NULL, 
'Summer Bank Holiday', 1)
go

insert into calendar_detail values('IPE', 'Dec 25 2001 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('IPE', 'Dec 26 2001 12:00:00', NULL, 
'Boxing Day', 1)
go

insert into calendar_detail values('NERC', 'Jan  1 1997 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('NERC', 'May 26 1997 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NERC', 'Jul  4 1997 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NERC', 'Sep  1 1997 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NERC', 'Nov 27 1997 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NERC', 'Dec 25 1997 12:00:00', NULL, 
'Xmas Day', 1)
go

insert into calendar_detail values('NERC', 'Jan  1 1998 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('NERC', 'May 25 1998 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NERC', 'Jul  4 1998 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NERC', 'Sep  7 1998 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NERC', 'Nov 26 1998 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NERC', 'Dec 25 1998 12:00:00', NULL, 
'Xmas Day', 1)
go

insert into calendar_detail values('NERC', 'Jan  1 1999 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('NERC', 'May 24 1999 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NERC', 'Jul  4 1999 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NERC', 'Sep  6 1999 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NERC', 'Nov 25 1999 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NERC', 'Dec 27 1999 12:00:00', NULL, 
'For Xmas Day', 1)
go

insert into calendar_detail values('NERC', 'Jan  1 2000 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('NGI', 'Jun  1 1995 12:00:00', NULL, 
'Jun  1', 1)
go

insert into calendar_detail values('NGI', 'Jun  2 1995 12:00:00', NULL, 
'Jun  2', 1)
go

insert into calendar_detail values('NGI', 'Jul  3 1995 12:00:00', NULL, 
'Jul   3', 1)
go

insert into calendar_detail values('NGI', 'Jul  4 1995 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NGI', 'Jul  5 1995 12:00:00', NULL, 
'Jul   5', 1)
go

insert into calendar_detail values('NGI', 'Jul  6 1995 12:00:00', NULL, 
'Jul   6', 1)
go

insert into calendar_detail values('NGI', 'Jul  7 1995 12:00:00', NULL, 
'Jul   7', 1)
go

insert into calendar_detail values('NGI', 'Aug  1 1995 12:00:00', NULL, 'Aug 1', 
1)
go

insert into calendar_detail values('NGI', 'Aug  2 1995 12:00:00', NULL, 'Aug 2', 
1)
go

insert into calendar_detail values('NGI', 'Aug  3 1995 12:00:00', NULL, 'Aug 3', 
1)
go

insert into calendar_detail values('NGI', 'Aug  4 1995 12:00:00', NULL, 'Aug 4', 
1)
go

insert into calendar_detail values('NGI', 'Sep  1 1995 12:00:00', NULL, 'Sep 1', 
1)
go

insert into calendar_detail values('NGI', 'Sep  4 1995 12:00:00', NULL, 
'Labour Day', 1)
go

insert into calendar_detail values('NGI', 'Nov  1 1995 12:00:00', NULL, 'Nov 1', 
1)
go

insert into calendar_detail values('NGI', 'Nov  2 1995 12:00:00', NULL, 'Nov 2', 
1)
go

insert into calendar_detail values('NGI', 'Nov  3 1995 12:00:00', NULL, 'Nov 3', 
1)
go

insert into calendar_detail values('NGI', 'Dec  1 1995 12:00:00', NULL, 'Dec 1', 
1)
go

insert into calendar_detail values('NGI', 'Jan  1 1996 12:00:00', NULL, 'Mon', 
1)
go

insert into calendar_detail values('NGI', 'Feb  1 1996 12:00:00', NULL, 'Thur', 
1)
go

insert into calendar_detail values('NGI', 'Feb  2 1996 12:00:00', NULL, 'Fri', 
1)
go

insert into calendar_detail values('NGI', 'Mar  1 1996 12:00:00', NULL, 'Fri', 
1)
go

insert into calendar_detail values('NGI', 'May  1 1996 12:00:00', NULL, 'Wed', 
1)
go

insert into calendar_detail values('NGI', 'May  2 1996 12:00:00', NULL, 'Thur', 
1)
go

insert into calendar_detail values('NGI', 'May  3 1996 12:00:00', NULL, 'Fri', 
1)
go

insert into calendar_detail values('NGI', 'Aug  1 1996 12:00:00', NULL, 'Thur', 
1)
go

insert into calendar_detail values('NGI', 'Aug  2 1996 12:00:00', NULL, 'Fri', 
1)
go

insert into calendar_detail values('NGI', 'Oct  1 1996 12:00:00', NULL, 'Tues', 
1)
go

insert into calendar_detail values('NGI', 'Oct  2 1996 12:00:00', NULL, 'Wed', 
1)
go

insert into calendar_detail values('NGI', 'Oct  3 1996 12:00:00', NULL, 'Thur', 
1)
go

insert into calendar_detail values('NGI', 'Oct  4 1996 12:00:00', NULL, 'Fri', 
1)
go

insert into calendar_detail values('NGI', 'Nov  1 1996 12:00:00', NULL, 'Fri', 
1)
go

insert into calendar_detail values('NGI', 'Jan  1 1997 12:00:00', NULL, 'Wed', 
1)
go

insert into calendar_detail values('NGI', 'Jan  2 1997 12:00:00', NULL, 'Thu', 
1)
go

insert into calendar_detail values('NGI', 'Jan  3 1997 12:00:00', NULL, 'Fri', 
1)
go

insert into calendar_detail values('NGI', 'Apr  1 1997 12:00:00', NULL, 'Tues', 
1)
go

insert into calendar_detail values('NGI', 'Apr  2 1997 12:00:00', NULL, 'Wed', 
1)
go

insert into calendar_detail values('NGI', 'Apr  3 1997 12:00:00', NULL, 'Thur', 
1)
go

insert into calendar_detail values('NGI', 'Apr  4 1997 12:00:00', NULL, 'Fri', 
1)
go

insert into calendar_detail values('NGI', 'May  1 1997 12:00:00', NULL, 'Thur', 
1)
go

insert into calendar_detail values('NGI', 'May  2 1997 12:00:00', NULL, 'Fri', 
1)
go

insert into calendar_detail values('NGI', 'Jul  1 1997 12:00:00', NULL, 'Tues', 
1)
go

insert into calendar_detail values('NGI', 'Jul  2 1997 12:00:00', NULL, 'Wed', 
1)
go

insert into calendar_detail values('NGI', 'Jul  3 1997 12:00:00', NULL, 'Thur', 
1)
go

insert into calendar_detail values('NGI', 'Jul  4 1997 12:00:00', NULL, 'Fri', 
1)
go

insert into calendar_detail values('NGI', 'Aug  1 1997 12:00:00', NULL, 'Fri', 
1)
go

insert into calendar_detail values('NGI', 'Oct  1 1997 12:00:00', NULL, 'Wed', 
1)
go

insert into calendar_detail values('NGI', 'Oct  2 1997 12:00:00', NULL, 'Thur', 
1)
go

insert into calendar_detail values('NGI', 'Oct  3 1997 12:00:00', NULL, 'Fri', 
1)
go

insert into calendar_detail values('NYCE', 'Jan  1 1993 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('NYCE', 'Feb 15 1993 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('NYCE', 'Apr  9 1993 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('NYCE', 'May 31 1993 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NYCE', 'Jul  5 1993 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NYCE', 'Sep  6 1993 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NYCE', 'Nov 25 1993 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYCE', 'Dec 24 1993 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('NYCE', 'Feb 20 1995 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('NYCE', 'Sep  4 1995 12:00:00', NULL, 
'Labour Day', 1)
go

insert into calendar_detail values('NYMEX', 'Feb 18 1991 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan  1 1992 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('NYMEX', 'Feb 17 1992 12:00:00', NULL, 
'Presidents Day', 1)
go

insert into calendar_detail values('NYMEX', 'Apr 17 1992 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('NYMEX', 'May 25 1992 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  3 1992 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Sep  7 1992 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 26 1992 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 27 1992 12:00:00', NULL, 
'Thanksgiving Day After', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 24 1992 12:00:00', NULL, 
'Christmas Day Eve', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 25 1992 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan  1 1993 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Feb 15 1993 12:00:00', NULL, 
'Presidents', 1)
go

insert into calendar_detail values('NYMEX', 'Apr  9 1993 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('NYMEX', 'May 31 1993 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  5 1993 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Sep  6 1993 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 25 1993 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 26 1993 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 24 1993 12:00:00', NULL, 
'Christmas Eve', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 31 1993 12:00:00', NULL, 
'New Years Eve', 1)
go

insert into calendar_detail values('NYMEX', 'Sep  5 1994 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 24 1994 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 25 1994 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 26 1994 12:00:00', NULL, 
'Christmas', 1)
go

insert into calendar_detail values('NYMEX', 'Jan  2 1995 12:00:00', NULL, 
'New Years', 1)
go

insert into calendar_detail values('NYMEX', 'Feb 20 1995 12:00:00', NULL, 
'u.s. presidents day', 1)
go

insert into calendar_detail values('NYMEX', 'Apr 14 1995 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('NYMEX', 'May 29 1995 12:00:00', NULL, 
'U.S. Memorial Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  3 1995 12:00:00', NULL, 
'U.S. Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  4 1995 12:00:00', NULL, 
'U.S. Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Sep  4 1995 12:00:00', NULL, 
'U.S. Labor Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 23 1995 12:00:00', NULL, 
'U.S. Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 24 1995 12:00:00', NULL, 
'U.S. Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 25 1995 12:00:00', NULL, 
'Christmas', 1)
go

insert into calendar_detail values('NYMEX', 'Jan  1 1996 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan  8 1996 12:00:00', NULL, 
'Snow Day Holiday', 1)
go

insert into calendar_detail values('NYMEX', 'Feb 19 1996 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Apr  5 1996 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('NYMEX', 'May 27 1996 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  4 1996 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  5 1996 12:00:00', NULL, 
'Day After Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Sep  2 1996 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 28 1996 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 29 1996 12:00:00', NULL, 
'Day After Thanksgiving', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 25 1996 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Feb 17 1997 12:00:00', NULL, 
'Presidents Day', 1)
go

insert into calendar_detail values('NYMEX', 'Mar 28 1997 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('NYMEX', 'May 26 1997 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  4 1997 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Sep  1 1997 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 27 1997 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 28 1997 12:00:00', NULL, 
'Day after Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 25 1997 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan  1 1998 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan 19 1998 12:00:00', NULL, 
'Martin Luther King Day', 1)
go

insert into calendar_detail values('NYMEX', 'Feb 16 1998 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Apr 10 1998 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('NYMEX', 'May 25 1998 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  3 1998 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Sep  7 1998 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 26 1998 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 27 1998 12:00:00', NULL, 
'Day after Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 25 1998 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan  1 1999 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan 18 1999 12:00:00', NULL, 
'Martin Luther King Day', 1)
go

insert into calendar_detail values('NYMEX', 'Feb 15 1999 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Apr  2 1999 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('NYMEX', 'May 31 1999 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  5 1999 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Sep  6 1999 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 25 1999 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 26 1999 12:00:00', NULL, 
'Day after Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 24 1999 12:00:00', NULL, 
'Christmas', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 31 1999 12:00:00', NULL, 
'New Years', 1)
go

insert into calendar_detail values('NYMEX', 'Jan  3 2000 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan 17 2000 12:00:00', NULL, 
'Martin Luther King Day', 1)
go

insert into calendar_detail values('NYMEX', 'Feb 21 2000 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Apr 21 2000 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('NYMEX', 'May 29 2000 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  3 2000 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  4 2000 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Sep  4 2000 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 23 2000 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 24 2000 12:00:00', NULL, 
'Day after Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 25 2000 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan  1 2001 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan 15 2001 12:00:00', NULL, 
'Martin Luther King Day', 1)
go

insert into calendar_detail values('NYMEX', 'Feb 19 2001 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Apr 13 2001 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('NYMEX', 'May 28 2001 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  4 2001 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Sep  3 2001 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 22 2001 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 25 2001 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan  1 2002 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jan 21 2002 12:00:00', NULL, 
'Martin Luther King Day', 1)
go

insert into calendar_detail values('NYMEX', 'Feb 18 2002 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('NYMEX', 'Mar 29 2002 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('NYMEX', 'May 27 2002 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('NYMEX', 'Jul  4 2002 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('NYMEX', 'Sep  2 2002 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('NYMEX', 'Nov 28 2002 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('NYMEX', 'Dec 25 2002 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSARG', 'Mar 16 2000 12:00:00', NULL, 
'Hari Raya Haji', 1)
go

insert into calendar_detail values('PLTSARG', 'Apr 21 2000 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSARG', 'May  1 2000 12:00:00', NULL, 
'May Day', 1)
go

insert into calendar_detail values('PLTSARG', 'May 18 2000 12:00:00', NULL, 
'Vesak Day', 1)
go

insert into calendar_detail values('PLTSARG', 'Aug  9 2000 12:00:00', NULL, 
'National Day', 1)
go

insert into calendar_detail values('PLTSARG', 'Oct 26 2000 12:00:00', NULL, 
'Deepavali', 1)
go

insert into calendar_detail values('PLTSARG', 'Dec 25 2000 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSARG', 'Dec 27 2000 12:00:00', NULL, 
'Hari Raya Puasa', 1)
go

insert into calendar_detail values('PLTSARG', 'Jan  1 2001 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 26 1994 12:00:00', NULL, 
'day after christmas day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 27 1994 12:00:00', NULL, 
'Day in Lieu of Boxing Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Jan  2 1995 12:00:00', NULL, 
'NEW YEARS DAY', 1)
go

insert into calendar_detail values('PLTSEURO', 'Apr 14 1995 12:00:00', NULL, 
'GOOD FRIDAY', 1)
go

insert into calendar_detail values('PLTSEURO', 'May 29 1995 12:00:00', NULL, 
'SPRING BANK (LONDON)', 1)
go

insert into calendar_detail values('PLTSEURO', 'Aug 28 1995 12:00:00', NULL, 
'SUMMER BANK HOLIDAY (LONDON)', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 25 1995 12:00:00', NULL, 
'CHRISTMAS DAY', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 26 1995 12:00:00', NULL, 
'BOXING DAY (LONDON)', 1)
go

insert into calendar_detail values('PLTSEURO', 'Jan  1 1996 12:00:00', NULL, 
'NEW YEARS DAY', 1)
go

insert into calendar_detail values('PLTSEURO', 'Apr  5 1996 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSEURO', 'May 27 1996 12:00:00', NULL, 
'Spring Bank Holiday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Aug 26 1996 12:00:00', NULL, 
'Summer Bank Holiday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 25 1996 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 26 1996 12:00:00', NULL, 
'Boxing Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Mar 28 1997 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Mar 31 1997 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('PLTSEURO', 'May 26 1997 12:00:00', NULL, 
'Spring Holiday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Aug 25 1997 12:00:00', NULL, 
'Late Summer Holiday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 25 1997 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 26 1997 12:00:00', NULL, 
'Boxing Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Jan  1 1998 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Apr 10 1998 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Apr 13 1998 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('PLTSEURO', 'May  4 1998 12:00:00', NULL, 
'May Day Bank Holiday', 1)
go

insert into calendar_detail values('PLTSEURO', 'May 25 1998 12:00:00', NULL, 
'Spring Bank Holiday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Aug 31 1998 12:00:00', NULL, 
'Summer Bank Holiday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 25 1998 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 28 1998 12:00:00', NULL, 
'Boxing Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Jan  1 1999 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Apr  2 1999 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Apr  5 1999 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('PLTSEURO', 'May  3 1999 12:00:00', NULL, 
'Constitution Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'May 31 1999 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Aug 30 1999 12:00:00', NULL, 
'Summer Bank Holiday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 27 1999 12:00:00', NULL, 
'Christmas Holiday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 28 1999 12:00:00', NULL, 
'Christmas Holiday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 31 1999 12:00:00', NULL, 
'New Years Eve', 1)
go

insert into calendar_detail values('PLTSEURO', 'Jan  3 2000 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Apr 21 2000 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Apr 24 2000 12:00:00', NULL, 
'Easter Monday', 1)
go

insert into calendar_detail values('PLTSEURO', 'May  1 2000 12:00:00', NULL, 
'May Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'May 29 2000 12:00:00', NULL, 
'Bank Holliday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Aug 28 2000 12:00:00', NULL, 
'Bank Holliday', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 25 2000 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Dec 26 2000 12:00:00', NULL, 
'Boxing Day', 1)
go

insert into calendar_detail values('PLTSEURO', 'Jan  1 2001 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Jan  2 1995 12:00:00', NULL, 
'NEW YEARS DAY', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Apr 14 1995 12:00:00', NULL, 
'GOOD FRIDAY', 1)
go

insert into calendar_detail values('PLTSJAPA', 'May  1 1995 12:00:00', NULL, 
'MAY DAY', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Dec 25 1995 12:00:00', NULL, 
'CHRISTMAS', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Jan  1 1996 12:00:00', NULL, 
'NEW YEARS DAY', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Apr  5 1996 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSJAPA', 'May  1 1996 12:00:00', NULL, 
'May Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Dec 25 1996 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Mar 28 1997 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSJAPA', 'May  1 1997 12:00:00', NULL, 
'May Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Dec 25 1997 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Jan  1 1998 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Apr 10 1998 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSJAPA', 'May  1 1998 12:00:00', NULL, 
'May Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Dec 25 1998 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Jan  1 1999 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Jan 15 1999 12:00:00', NULL, 
'Adults Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Jan 19 1999 12:00:00', NULL, 
'Hari Raya Rasa', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Feb 11 1999 12:00:00', NULL, 
'National Foundation Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Feb 16 1999 12:00:00', NULL, 
'Lunar New Year', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Feb 17 1999 12:00:00', NULL, 
'Lunar New Year', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Mar 22 1999 12:00:00', NULL, 
'Day After Vernal Equinox Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Mar 29 1999 12:00:00', NULL, 
'Day After Hari Raya Haji', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Apr  2 1999 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Apr 29 1999 12:00:00', NULL, 
'Greenery Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'May  3 1999 12:00:00', NULL, 
'Constitution Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'May  5 1999 12:00:00', NULL, 
'Childrens Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'May 31 1999 12:00:00', NULL, 
'Spring Bank Holiday', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Jul 20 1999 12:00:00', NULL, 
'Marine Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Aug  9 1999 12:00:00', NULL, 
'National Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Sep 15 1999 12:00:00', NULL, 
'Respect for Aged Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Sep 23 1999 12:00:00', NULL, 
'Autumn Equinox Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Oct 11 1999 12:00:00', NULL, 
'Day After Health Sports Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Nov  3 1999 12:00:00', NULL, 
'Culture Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Nov  8 1999 12:00:00', NULL, 
'Day After Deepavali', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Nov 23 1999 12:00:00', NULL, 
'Labor Thanksgiving Day', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Dec 23 1999 12:00:00', NULL, 
'Emperors Birthday', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Dec 27 1999 12:00:00', NULL, 
'Christmas Holiday', 1)
go

insert into calendar_detail values('PLTSJAPA', 'Jan  3 2000 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Dec 25 1995 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Jan  1 1996 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Dec 25 1996 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Mar 28 1997 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Dec 25 1997 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Jan  1 1998 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Apr 10 1998 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSMKTW', 'May 25 1998 12:00:00', NULL, 
'Memorial Day / Bank Holiday', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Dec 25 1998 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Jan  1 1999 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Apr  2 1999 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSMKTW', 'May 31 1999 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Dec 31 1999 12:00:00', NULL, 
'Millenium Holiday-see platts', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Jan  3 2000 12:00:00', NULL, 
'New Year''s Holiday', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Apr 21 2000 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSMKTW', 'May 29 2000 12:00:00', NULL, 
'Memorial Day/Bank Holiday', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Dec 25 2000 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Jan  1 2001 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Apr 13 2001 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSMKTW', 'May 28 2001 12:00:00', NULL, 
'Memorial Day/Bank Holiday', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Dec 25 2001 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Jan  1 2002 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Mar 29 2002 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSMKTW', 'May 27 2002 12:00:00', NULL, 
'Memorial Day/ Bank Holiday', 1)
go

insert into calendar_detail values('PLTSMKTW', 'Dec 25 2002 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Dec 26 1994 12:00:00', NULL, 
'day after christmas day', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan  2 1995 12:00:00', NULL, 
'NEW YEARS DAY', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan 31 1995 12:00:00', NULL, 
'CHINESE NEW YEAR', 1)
go

insert into calendar_detail values('PLTSSING', 'Feb  1 1995 12:00:00', NULL, 
'CHINESE NEW YEAR', 1)
go

insert into calendar_detail values('PLTSSING', 'Mar  3 1995 12:00:00', NULL, 
'HARI  RAYA  PUASA', 1)
go

insert into calendar_detail values('PLTSSING', 'Apr 14 1995 12:00:00', NULL, 
'GOOD FRIDAY', 1)
go

insert into calendar_detail values('PLTSSING', 'May  1 1995 12:00:00', NULL, 
'MAY DAY', 1)
go

insert into calendar_detail values('PLTSSING', 'May 10 1995 12:00:00', NULL, 
'HARI  RAYA  HAJI', 1)
go

insert into calendar_detail values('PLTSSING', 'May 15 1995 12:00:00', NULL, 
'POST VESAK DAY', 1)
go

insert into calendar_detail values('PLTSSING', 'Aug  9 1995 12:00:00', NULL, 
'SINGAPORE NATIONAL DAY', 1)
go

insert into calendar_detail values('PLTSSING', 'Oct 23 1995 12:00:00', NULL, 
'DEEPAVALI', 1)
go

insert into calendar_detail values('PLTSSING', 'Dec 25 1995 12:00:00', NULL, 
'CHRISTMAS DAY', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan  1 1996 12:00:00', NULL, 
'NEW YEARS DAY', 1)
go

insert into calendar_detail values('PLTSSING', 'Feb 19 1996 12:00:00', NULL, 
'Lunar New Year', 1)
go

insert into calendar_detail values('PLTSSING', 'Feb 20 1996 12:00:00', NULL, 
'Lunar New Year', 1)
go

insert into calendar_detail values('PLTSSING', 'Feb 21 1996 12:00:00', NULL, 
'Lunar New Year', 1)
go

insert into calendar_detail values('PLTSSING', 'Apr  5 1996 12:00:00', NULL, 
'Arbor Day/Good Friday', 1)
go

insert into calendar_detail values('PLTSSING', 'Apr 29 1996 12:00:00', NULL, 
'Hari Raya Haji', 1)
go

insert into calendar_detail values('PLTSSING', 'May  1 1996 12:00:00', NULL, 
'May Day', 1)
go

insert into calendar_detail values('PLTSSING', 'May 31 1996 12:00:00', NULL, 
'Vesak Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Aug  9 1996 12:00:00', NULL, 
'Singapore National Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Nov 11 1996 12:00:00', NULL, 
'Deepavali', 1)
go

insert into calendar_detail values('PLTSSING', 'Dec 25 1996 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Feb  7 1997 12:00:00', NULL, 
'Lunar New Year', 1)
go

insert into calendar_detail values('PLTSSING', 'Feb 10 1997 12:00:00', NULL, 
'Lunar New Year', 1)
go

insert into calendar_detail values('PLTSSING', 'Mar 28 1997 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSSING', 'Apr 17 1997 12:00:00', NULL, 
'HARI RAYA HAJI', 1)
go

insert into calendar_detail values('PLTSSING', 'May  1 1997 12:00:00', NULL, 
'May Day', 1)
go

insert into calendar_detail values('PLTSSING', 'May 22 1997 12:00:00', NULL, 
'Vesak Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Aug  8 1997 12:00:00', NULL, 
'Day before S''pore National Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Oct 30 1997 12:00:00', NULL, 
'DEEPAVALI', 1)
go

insert into calendar_detail values('PLTSSING', 'Dec 25 1997 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan  1 1998 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan 28 1998 12:00:00', NULL, 
'Lunar New Year', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan 29 1998 12:00:00', NULL, 
'Lunar New Year', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan 30 1998 12:00:00', NULL, 
'Lunar New Year', 1)
go

insert into calendar_detail values('PLTSSING', 'Apr  7 1998 12:00:00', NULL, 
'Hari Raya Haji', 1)
go

insert into calendar_detail values('PLTSSING', 'Apr 10 1998 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSSING', 'May  1 1998 12:00:00', NULL, 
'May Day', 1)
go

insert into calendar_detail values('PLTSSING', 'May 11 1998 12:00:00', NULL, 
'Day after Vesak Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Aug 10 1998 12:00:00', NULL, 
'Day after Singapore National Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Oct 19 1998 12:00:00', NULL, 
'Deepavali', 1)
go

insert into calendar_detail values('PLTSSING', 'Dec 25 1998 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan  1 1999 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan 19 1999 12:00:00', NULL, 
'Hari Raya Puasa', 1)
go

insert into calendar_detail values('PLTSSING', 'Feb 16 1999 12:00:00', NULL, 
'Lunar New Year', 1)
go

insert into calendar_detail values('PLTSSING', 'Feb 17 1999 12:00:00', NULL, 
'LUnar New Year', 1)
go

insert into calendar_detail values('PLTSSING', 'Mar 29 1999 12:00:00', NULL, 
'Day After Hari Raya Haji', 1)
go

insert into calendar_detail values('PLTSSING', 'Apr  2 1999 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSSING', 'May  5 1999 12:00:00', NULL, 
'Constitution Day', 1)
go

insert into calendar_detail values('PLTSSING', 'May 31 1999 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Aug  9 1999 12:00:00', NULL, 
'National Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Nov  8 1999 12:00:00', NULL, 
'Day After Deepavali', 1)
go

insert into calendar_detail values('PLTSSING', 'Dec 27 1999 12:00:00', NULL, 
'Christmas Holiday', 1)
go

insert into calendar_detail values('PLTSSING', 'Dec 31 1999 12:00:00', NULL, 
'New Years Eve', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan  3 2000 12:00:00', NULL, 
'New Years Holiday', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan 10 2000 12:00:00', NULL, 
'Hari Raya Puasa', 1)
go

insert into calendar_detail values('PLTSSING', 'Feb  7 2000 12:00:00', NULL, 
'Lunar New Year', 1)
go

insert into calendar_detail values('PLTSSING', 'Mar 16 2000 12:00:00', NULL, 
'Hari Raya Haji', 1)
go

insert into calendar_detail values('PLTSSING', 'Apr 21 2000 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSSING', 'May  1 2000 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('PLTSSING', 'May 18 2000 12:00:00', NULL, 
'Veska Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Aug  9 2000 12:00:00', NULL, 
'National Day', 1)
go

insert into calendar_detail values('PLTSSING', 'Oct 26 2000 12:00:00', NULL, 
'Deepavali', 1)
go

insert into calendar_detail values('PLTSSING', 'Dec 25 2000 12:00:00', NULL, 
'Christmas', 1)
go

insert into calendar_detail values('PLTSSING', 'Dec 27 2000 12:00:00', NULL, 
'Hari Raya Puasa', 1)
go

insert into calendar_detail values('PLTSSING', 'Jan  1 2001 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Dec 26 1994 12:00:00', NULL, 
'christmas day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jan  2 1995 12:00:00', NULL, 
'new years day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Feb 20 1995 12:00:00', NULL, 
'u.s. presidents day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Apr 14 1995 12:00:00', NULL, 
'good friday', 1)
go

insert into calendar_detail values('PLTSUSA', 'May 29 1995 12:00:00', NULL, 
'u.s. memorial day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jul  3 1995 12:00:00', NULL, 
'u.s independence day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jul  4 1995 12:00:00', NULL, 
'u.s independence day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Sep  4 1995 12:00:00', NULL, 
'u.s. labor day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Nov 23 1995 12:00:00', NULL, 
'u.s. thanksgiving day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Nov 24 1995 12:00:00', NULL, 
'u.s. thanksgiving day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Dec 25 1995 12:00:00', NULL, 
'christmas day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Feb 19 1996 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Apr  5 1996 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSUSA', 'May 27 1996 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jul  4 1996 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jul  5 1996 12:00:00', NULL, 
'Day After Independence Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Sep  2 1996 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Nov 28 1996 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Nov 29 1996 12:00:00', NULL, 
'Day After Thanksgiving', 1)
go

insert into calendar_detail values('PLTSUSA', 'Dec 25 1996 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Feb 17 1997 12:00:00', NULL, 
'Presidents Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Mar 28 1997 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSUSA', 'May 26 1997 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jul  4 1997 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Sep  1 1997 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Nov 27 1997 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Nov 28 1997 12:00:00', NULL, 
'Day after Thanksgiving Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Dec 25 1997 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jan  1 1998 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jan 19 1998 12:00:00', NULL, 
'Martin Luther King Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Feb 16 1998 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Apr 10 1998 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSUSA', 'May 25 1998 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jul  3 1998 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Sep  7 1998 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Nov 26 1998 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Nov 27 1998 12:00:00', NULL, 
'Day after Thanksgiving Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Dec 25 1998 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jan  1 1999 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jan 18 1999 12:00:00', NULL, 
'Martin Luther King Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Feb 15 1999 12:00:00', NULL, 
'Presidents Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Apr  2 1999 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSUSA', 'May 31 1999 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jul  5 1999 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Sep  6 1999 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Nov 25 1999 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Nov 26 1999 12:00:00', NULL, 
'Day After Thanksgiving Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Dec 24 1999 12:00:00', NULL, 
'Christmas Holiday', 1)
go

insert into calendar_detail values('PLTSUSA', 'Dec 31 1999 12:00:00', NULL, 
'New Years', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jan  3 2000 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jan 17 2000 12:00:00', NULL, 
'Martin Luther King Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Feb 21 2000 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Apr 21 2000 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('PLTSUSA', 'May 29 2000 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jul  3 2000 12:00:00', NULL, 
'Day Before July 4th', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jul  4 2000 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Sep  4 2000 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Nov 23 2000 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Nov 24 2000 12:00:00', NULL, 
'Day after Thanksgiving Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Dec 25 2000 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('PLTSUSA', 'Jan  1 2001 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('SIMEX', 'Jan  1 1999 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('SIMEX', 'Jan 19 1999 12:00:00', NULL, 
'Hari Raya Puasa', 1)
go

insert into calendar_detail values('SIMEX', 'Feb 16 1999 12:00:00', NULL, 
'Chinese New Years Day', 1)
go

insert into calendar_detail values('SIMEX', 'Feb 17 1999 12:00:00', NULL, 
'Chinese New Years Day', 1)
go

insert into calendar_detail values('SIMEX', 'Mar 28 1999 12:00:00', NULL, 
'Hari Raya Haji', 1)
go

insert into calendar_detail values('SIMEX', 'Mar 29 1999 12:00:00', NULL, 
'Hari Raya Haji (OBS)', 1)
go

insert into calendar_detail values('SIMEX', 'Apr  2 1999 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('SIMEX', 'May  1 1999 12:00:00', NULL, 
'Labour Day', 1)
go

insert into calendar_detail values('SIMEX', 'May 29 1999 12:00:00', NULL, 
'Vesak Day', 1)
go

insert into calendar_detail values('SIMEX', 'Aug  9 1999 12:00:00', NULL, 
'National Day', 1)
go

insert into calendar_detail values('SIMEX', 'Nov  7 1999 12:00:00', NULL, 
'Deepavali', 1)
go

insert into calendar_detail values('SIMEX', 'Nov  8 1999 12:00:00', NULL, 
'Deepavali (OBS)', 1)
go

insert into calendar_detail values('SIMEX', 'Dec 25 1999 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('THURSDAY', 'Jun  1 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun  2 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul  7 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  2 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  3 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  4 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  5 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  6 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  7 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  9 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 10 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 11 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 12 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 13 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 14 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 16 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 17 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 18 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 19 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 20 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 21 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 23 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 24 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 25 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 26 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 27 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 28 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 30 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 31 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  1 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  2 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  3 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  4 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  6 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  7 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  8 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  9 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 10 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 11 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 13 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 14 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 15 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 16 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 17 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 18 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 20 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 21 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 22 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 23 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 24 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 25 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 27 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 28 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 29 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 30 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  1 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  2 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  4 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  5 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  6 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  7 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  8 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  9 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 11 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 12 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 13 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 14 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 15 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 16 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 18 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 19 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 20 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 21 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 22 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 23 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 25 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 26 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 27 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 28 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 29 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 30 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  1 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  2 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  3 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  4 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  5 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  6 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  8 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 10 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 11 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 12 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 13 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 15 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 16 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 17 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 18 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 19 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 20 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 22 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 23 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 24 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 25 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 26 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 27 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 29 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 30 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  1 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  2 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  3 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  4 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  6 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  7 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  8 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  9 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 10 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 11 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 13 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 14 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 15 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 16 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 17 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 18 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 20 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 21 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 22 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 23 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 24 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 25 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 27 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 28 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 29 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 30 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 31 1996 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan  1 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan  2 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan  4 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan  5 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan  6 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan  7 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan  8 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 10 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 11 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 12 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 13 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 14 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 15 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 17 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 18 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 19 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 20 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 21 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 22 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 24 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 25 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 26 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 27 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 28 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 29 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jan 31 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb  1 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb  2 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb  3 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb  4 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb  5 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb  7 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb  8 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb  9 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 10 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 11 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 12 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 14 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 15 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 16 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 17 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 18 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 19 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 21 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 22 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 23 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 24 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 25 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 26 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Feb 28 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar  1 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar  2 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar  3 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar  4 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar  5 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar  7 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar  8 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar  9 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 10 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 11 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 12 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 14 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 15 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 16 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 17 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 18 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 20 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 21 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 22 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 23 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 24 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 25 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 26 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 28 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 29 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 30 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Mar 31 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr  1 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr  2 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr  4 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr  5 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr  6 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr  7 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr  8 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr  9 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 11 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 12 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 13 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 14 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 15 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 16 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 18 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 19 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 20 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 21 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 22 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 23 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 25 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 26 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 27 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 28 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 29 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Apr 30 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May  2 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May  3 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May  4 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May  5 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May  6 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May  7 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May  9 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 10 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 11 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 12 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 13 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 14 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 16 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 17 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 18 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 19 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 20 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 21 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 23 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 24 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 25 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 26 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 27 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 28 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 30 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'May 31 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun  1 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun  2 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun  3 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun  4 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun  6 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun  7 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun  8 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun  9 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 10 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 11 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 13 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 14 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 15 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 16 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 17 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 18 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 20 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 21 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 22 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 23 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 24 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 25 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 27 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 28 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 29 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jun 30 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul  1 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul  2 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul  4 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul  5 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul  6 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul  7 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul  8 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul  9 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 11 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 12 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 13 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 14 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 15 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 16 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 18 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 19 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 20 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 21 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 22 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 23 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 25 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 26 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 27 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 28 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 29 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Jul 30 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  1 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  2 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  3 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  4 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  5 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  6 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  8 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug  9 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 10 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 11 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 12 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 13 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 15 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 16 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 17 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 18 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 19 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 20 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 22 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 23 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 24 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 25 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 26 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 27 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 29 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 30 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Aug 31 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  1 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  2 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  3 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  5 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  6 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  7 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  8 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep  9 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 10 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 12 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 13 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 14 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 15 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 16 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 17 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 19 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 20 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 21 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 22 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 23 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 24 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 26 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 27 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 28 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 29 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Sep 30 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  1 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  3 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  4 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  5 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  6 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  7 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct  8 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 10 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 11 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 12 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 13 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 14 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 15 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 17 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 18 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 19 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 20 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 21 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 22 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 24 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 25 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 26 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 27 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 28 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 29 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Oct 31 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  1 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  2 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  3 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  4 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  5 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  7 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  8 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov  9 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 10 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 11 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 12 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 14 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 15 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 16 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 17 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 18 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 19 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 21 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 22 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 23 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 24 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 25 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 26 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 28 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 29 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Nov 30 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  1 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  2 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  3 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  5 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  6 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  7 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  8 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec  9 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 10 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 12 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 13 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 14 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 15 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 16 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 17 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 19 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 20 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 21 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 22 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 23 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 24 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 26 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 27 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 28 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 29 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 30 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('THURSDAY', 'Dec 31 1997 12:00:00', NULL, 
NULL, 1)
go

insert into calendar_detail values('USA', 'Sep  4 1995 12:00:00', NULL, 
'Labour Day', 1)
go

insert into calendar_detail values('USA', 'Nov 23 1995 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('USA', 'Nov 24 1995 12:00:00', NULL, 
'Day After Thanksgiving', 1)
go

insert into calendar_detail values('USA', 'Dec 25 1995 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('USA', 'Jan  1 1996 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('USA', 'Feb 19 1996 12:00:00', NULL, 
'Presidents Day', 1)
go

insert into calendar_detail values('USA', 'Apr  5 1996 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('USA', 'May 27 1996 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('USA', 'Jul  4 1996 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('USA', 'Jul  5 1996 12:00:00', NULL, 
'Day After Independence Day', 1)
go

insert into calendar_detail values('USA', 'Sep  2 1996 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('USA', 'Nov 28 1996 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('USA', 'Nov 29 1996 12:00:00', NULL, 
'Day After Thanksgiving', 1)
go

insert into calendar_detail values('USA', 'Dec 25 1996 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('USA', 'Jan  1 1997 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('USA', 'Feb 17 1997 12:00:00', NULL, 
'Presidents Day', 1)
go

insert into calendar_detail values('USA', 'Mar 28 1997 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('USA', 'May 26 1997 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('USA', 'Jul  4 1997 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('USA', 'Sep  1 1997 12:00:00', NULL, 
'Labor Day', 1)
go

insert into calendar_detail values('USA', 'Nov 27 1997 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('USA', 'Nov 28 1997 12:00:00', NULL, 
'Day after Thanksgiving Day', 1)
go

insert into calendar_detail values('USA', 'Dec 25 1997 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('USA', 'Jan  1 1998 12:00:00', NULL, 
'New Year''s Day', 1)
go

insert into calendar_detail values('USA', 'Feb 16 1998 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('USA', 'Jul  3 1998 12:00:00', NULL, 
'Independence day', 1)
go

insert into calendar_detail values('USA', 'Apr  2 1999 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('USA', 'May 31 1999 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('USA', 'Jul  5 1999 12:00:00', NULL, 
'Independance Day', 1)
go

insert into calendar_detail values('USA', 'Sep  6 1999 12:00:00', NULL, 
'Labour Day', 1)
go

insert into calendar_detail values('USA', 'Nov 25 1999 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('USA', 'Dec 24 1999 12:00:00', NULL, 
'Christmas', 1)
go

insert into calendar_detail values('USA', 'Dec 31 1999 12:00:00', NULL, 
'New Years', 1)
go

insert into calendar_detail values('USA', 'Jan  3 2000 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('USA', 'Jan 17 2000 12:00:00', NULL, 
'Martin Luther King Day', 1)
go

insert into calendar_detail values('USA', 'Feb 21 2000 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('USA', 'Apr 21 2000 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('USA', 'May 29 2000 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('USA', 'Jul  4 2000 12:00:00', NULL, 
'Independance Day', 1)
go

insert into calendar_detail values('USA', 'Sep  4 2000 12:00:00', NULL, 
'Labour Day', 1)
go

insert into calendar_detail values('USA', 'Nov 23 2000 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('USA', 'Nov 24 2000 12:00:00', NULL, 
'Day after Thanksgiving Day', 1)
go

insert into calendar_detail values('USA', 'Dec 25 2000 12:00:00', NULL, 
'Christmas Day', 1)
go

insert into calendar_detail values('USA', 'Jan  1 2001 12:00:00', NULL, 
'New Years Day', 1)
go

insert into calendar_detail values('USA', 'Jan 15 2001 12:00:00', NULL, 
'Martin Luther King Day', 1)
go

insert into calendar_detail values('USA', 'Feb 19 2001 12:00:00', NULL, 
'President''s Day', 1)
go

insert into calendar_detail values('USA', 'Apr 20 2001 12:00:00', NULL, 
'Good Friday', 1)
go

insert into calendar_detail values('USA', 'May 28 2001 12:00:00', NULL, 
'Memorial Day', 1)
go

insert into calendar_detail values('USA', 'Jul  2 2001 12:00:00', NULL, 
'Independence Day', 1)
go

insert into calendar_detail values('USA', 'Sep  3 2001 12:00:00', NULL, 
'Labour Day', 1)
go

insert into calendar_detail values('USA', 'Nov 22 2001 12:00:00', NULL, 
'Thanksgiving Day', 1)
go

insert into calendar_detail values('USA', 'Nov 23 2001 12:00:00', NULL, 
'Day after Thanksgiving Day', 1)
go

insert into calendar_detail values('USA', 'Dec 25 2001 12:00:00', NULL, 
'Christmas Day', 1)
go

