set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the rc_instr_type table ...'
go

if NOT EXISTS (select *
               from dbo.rc_instr_type
               where instr_type_code = 'RC_BANK')
   insert into dbo.rc_instr_type(instr_type_code,instr_type_desc,trans_id)
   values('RC_BANK', 'RISK COVER BANK', 1)
go

if NOT EXISTS (select *
               from dbo.rc_instr_type
               where instr_type_code = 'RC_BROKER')
   insert into dbo.rc_instr_type(instr_type_code,instr_type_desc,trans_id)
   values('RC_BROKER', 'RISK COVER BROKER', 1)
go