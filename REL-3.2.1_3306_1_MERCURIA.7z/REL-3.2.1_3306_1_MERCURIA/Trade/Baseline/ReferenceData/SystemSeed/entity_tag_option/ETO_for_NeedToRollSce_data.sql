set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading new tag options into the ''entity_tag_option'' table (NeedToRollSce) ...'
go
   
create table #entity_tag_option 
(
   oid               int not null identity(1,1),
   entity_tag_id     int not null,
   tag_option        char(16) not null,
   tag_option_desc   varchar(64) null,
   tag_option_status char(1) not null,
)

declare @entity_tag_id int,
		@tag_option char(16),
		@tag_option_desc varchar(64),
		@tag_option_status char(1),
		@oid int,
		@trans_id int,
		@row_affected int,
		@errcode  int,
		@smsg   varchar(255)
		
if exists(select 1 from entity_tag_definition where entity_tag_name='NeedToRollSce')
begin

select @entity_tag_id=oid from entity_tag_definition where entity_tag_name='NeedToRollSce'
 
insert into #entity_tag_option(entity_tag_id,tag_option,tag_option_desc,tag_option_status)
select @entity_tag_id,'Y','YES','A'
union all
select @entity_tag_id,'N','NO','A'

end

/* Begin - new trans_id script */
        
   begin tran
   begin try
       exec dbo.gen_new_transaction_NOI @app_name = 'DbIssue_1386831'
   end try
   begin catch
     if @@trancount > 0
        rollback tran
     print '=> Error occurred while executing the ''gen_new_transaction_NOI'' stored procedure!'    
     print ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran

   select @trans_id = null

   select @trans_id = last_num 
   from dbo.icts_trans_sequence 
   where oid = 1

   if @trans_id is null
   begin
      print '=> Failed to obtain a new trans_id for insert!'
      goto endofscript
   end

/* End - new trans_id script */

select @oid = min(oid)
from #entity_tag_option

while @oid is not null
begin
   select @entity_tag_id=entity_tag_id,
@tag_option=tag_option,
@tag_option_desc=tag_option_desc,
@tag_option_status=tag_option_status
   from #entity_tag_option
   where oid = @oid

   if not exists (select 1
                  from dbo.entity_tag_option
                  where entity_tag_id = @entity_tag_id and
                        tag_option = @tag_option)
   begin
      begin tran
      begin try
        insert into dbo.entity_tag_option
          (entity_tag_id,tag_option,tag_option_desc,tag_option_status, trans_id)
         values(@entity_tag_id,@tag_option,@tag_option_desc,@tag_option_status,@trans_id)
        select @row_affected = @@rowcount
      end try
      begin catch
        if @@trancount > 0
           rollback tran
        print '=> Failed to add an entity_tag_option record for the tag ''' + @tag_option + ''' due to the error:'
        print '==> ERROR: ' + ERROR_MESSAGE()
        select @errcode = ERROR_NUMBER()
        goto nextoid
      end catch
      commit tran
      select @smsg = '=> The tag ''' + @tag_option + ''' for the entity tag ''' + convert(varchar,@entity_tag_id) + ''' was added successfully!' 
      print @smsg
   end

nextoid:   
   select @oid = min(oid)
   from #entity_tag_option
   where oid > @oid        
end
endofscript:
drop table #entity_tag_option
                                 
go