set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading new tag options into the ''entity_tag_option'' table (EIPP) ...'
go
   
declare	   @entity_id		int,
	   @entity_tag_id	int,	   
	   @trans_id		int,
	   @rows_affected	int

		
select @entity_id = NULL
select @entity_tag_id = NULL

select @entity_id = oid from dbo.icts_entity_name where entity_name = 'Portfolio'

if @entity_id is NULL
begin
     print '=> Could not find icts entity name Portfolio '
     goto endofscript
end

select @entity_tag_id = oid from dbo.entity_tag_definition where entity_id = @entity_id and entity_tag_name = 'STRATEGY'

if @entity_tag_id is NULL
begin
     print 'Could not find icts entity tag name STRATEGY '
     goto endofscript
end

if exists ( select 1 from dbo.entity_tag_option where entity_tag_id = @entity_tag_id and tag_option = 'EIPP' )
begin
     print 'entity_tag_option table already has EIPP entry '
     goto endofscript
end


   begin tran
   begin try
	insert into dbo.entity_tag_option(entity_tag_id,tag_option,tag_option_desc,tag_option_status,trans_id)
	select @entity_tag_id, 'EIPP', 'EIPP', 'A', 1
	select @rows_affected = @@rowcount
   end try
   begin catch
	if @@trancount > 0
		rollback tran
	print '=> Failed insert EIPP entry into entity_tag_option table due to below error '
	print ERROR_MESSAGE()
   end catch
   commit tran
   if @rows_affected > 0
	print '=> Added EIPP entry into entity_tag_option table successfully '

endofscript:                                
go