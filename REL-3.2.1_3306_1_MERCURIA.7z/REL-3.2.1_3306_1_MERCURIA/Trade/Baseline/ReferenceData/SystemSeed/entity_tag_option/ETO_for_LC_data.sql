set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading new tag options into the entity_tag_option table (Lc) ...'
go

create table #tag_options
(
   oid                  numeric(18, 0) IDENTITY,
   entity_tag_id        int         NOT NULL,
   tag_option           char(16)    NOT NULL,
   tag_option_desc      varchar(64) NULL,
   tag_option_status    char(1)     NOT NULL,
   entity_tag_name      varchar(16) NULL,
   entity_name          varchar(30) NULL
)
go

declare @oid                  numeric(18, 0),
        @rows_added           int,
        @errcode              int,
        @entity_tag_id        int,
        @tag_option           char(16),
        @tag_option_desc      varchar(64),
        @tag_option_status    char(1),
        @smsg                 varchar(255),
        @entity_tag_name      varchar(16),
        @status               int,
        @target_entity_name   varchar(30),
        @entity_name          varchar(30),
        @target_entity_id     int,
        @entity_id            int

select @errcode = 0,
       @status = 0

select @target_entity_name = null,
       @entity_name = 'Lc',
       @target_entity_id = null,
       @entity_id = null

if @target_entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @target_entity_name, @target_entity_id OUTPUT
   if @status > 0 or @target_entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @target_entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

if @entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @entity_name, @entity_id OUTPUT
   if @status > 0 or @entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @entity_name + ''' in the ''icts_entity_name'' table!'
      print @smsg
      goto endofscript
   end
end

-- ----------------------------------------------------------------------------
-- TAG   : lcNettingInd
-- ENTITY: Lc
-- ----------------------------------------------------------------------------

print '=> Saving options for the tag ''lcNettingInd'' (entity = ''Lc'') into temporary table ...'

select @entity_tag_name = 'lcNettingInd'

exec @status = dbo.usp_find_entity_tag_id @target_entity_id, @entity_id, @entity_tag_name, @entity_tag_id OUTPUT
if @status > 0 or @entity_tag_id is null
begin
   select @smsg = 'Could not find the ID for the entity_tag_name ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''') in the entity_tag_definition table!'
   print @smsg
   goto endofscript
end

insert into #tag_options
     (entity_tag_id, tag_option, tag_option_desc, tag_option_status, entity_tag_name, entity_name)
   values (@entity_tag_id, 'Yes', 'Yes', 'A', @entity_tag_name, @entity_name)

-- ----------------------------------------------------------------------------
-- TAG   : LCDisputeStatus
-- ENTITY: Lc
-- ----------------------------------------------------------------------------

print '=> Saving options for the tag ''LCDisputeStatus'' (entity = ''Lc'') into temporary table ...'

select @entity_tag_name = 'LCDisputeStatus'

exec @status = dbo.usp_find_entity_tag_id @target_entity_id, @entity_id, @entity_tag_name, @entity_tag_id OUTPUT
if @status > 0 or @entity_tag_id is null
begin
   select @smsg = 'Could not find the ID for the entity_tag_name ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''') in the entity_tag_definition table!'
   print @smsg
   goto endofscript
end

insert into #tag_options
     (entity_tag_id, tag_option, tag_option_desc, tag_option_status, entity_tag_name, entity_name)
   values (@entity_tag_id, 'REJECTED', 'REJECTED', 'A', @entity_tag_name, @entity_name)
insert into #tag_options
     (entity_tag_id, tag_option, tag_option_desc, tag_option_status, entity_tag_name, entity_name)
   values (@entity_tag_id, 'RESOLVED', 'RESOLVED', 'A', @entity_tag_name, @entity_name)
insert into #tag_options
     (entity_tag_id, tag_option, tag_option_desc, tag_option_status, entity_tag_name, entity_name)
   values (@entity_tag_id, 'SUBMITTED', 'SUBMITTED', 'A', @entity_tag_name, @entity_name)


-- ----------------------------------------------------------------------------
-- TAG   : LCPriority
-- ENTITY: Lc
-- ----------------------------------------------------------------------------

print '=> Saving options for the tag ''LCPriority'' (entity = ''Lc'') into temporary table ...'

select @entity_tag_name = 'LCPriority'

exec @status = dbo.usp_find_entity_tag_id @target_entity_id, @entity_id, @entity_tag_name, @entity_tag_id OUTPUT
if @status > 0 or @entity_tag_id is null
begin
   select @smsg = 'Could not find the ID for the entity_tag_name ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''') in the entity_tag_definition table!'
   print @smsg
   goto endofscript
end

insert into #tag_options
     (entity_tag_id, tag_option, tag_option_desc, tag_option_status, entity_tag_name, entity_name)
   values (@entity_tag_id, 'HIGH', 'HIGH', 'A', @entity_tag_name, @entity_name)
insert into #tag_options
     (entity_tag_id, tag_option, tag_option_desc, tag_option_status, entity_tag_name, entity_name)
   values (@entity_tag_id, 'NORMAL', 'NORMAL', 'A', @entity_tag_name, @entity_name)
insert into #tag_options
     (entity_tag_id, tag_option, tag_option_desc, tag_option_status, entity_tag_name, entity_name)
   values (@entity_tag_id, 'URGENT', 'URGENT', 'A', @entity_tag_name, @entity_name)






print ' '

/* ******************************************************************** */
/* The code body for adding records into the entity_tag_option table    */
/* ******************************************************************** */

select @oid = min(oid)
from #tag_options

while @oid is not null
begin
   select @entity_tag_id = entity_tag_id,
          @tag_option = tag_option,
          @tag_option_desc = tag_option_desc,
          @tag_option_status = tag_option_status,
          @entity_tag_name = entity_tag_name,
          @entity_name = entity_name
   from #tag_options
   where oid = @oid
   
   if not exists (select 1
                  from dbo.entity_tag_option
                  where entity_tag_id = @entity_tag_id and
                        tag_option = @tag_option)
   begin
      begin tran
      begin try
      insert into dbo.entity_tag_option
           (entity_tag_id, tag_option, tag_option_desc, tag_option_status, trans_id)
         values(@entity_tag_id, @tag_option, @tag_option_desc, @tag_option_status, 1)
      select @rows_added = @@rowcount
      end try
      begin catch
         if @@trancount > 0
            rollback tran
	 print '=> Failed to add an entity_tag_option records for the tag ''' + @entity_tag_name + ''' due to the error:'
         print '==> ERROR: ' + ERROR_MESSAGE()
         select @errcode = ERROR_NUMBER()
         goto endofscript
      end catch
      commit tran
      select @smsg = '=> TAG ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''')'
      print @smsg
      select @smsg = '==>  The tag option ''' + rtrim(@tag_option) + ''' was added successfully!' 
     print @smsg
   end  
   select @oid = min(oid)
   from #tag_options
   where oid > @oid
end
endofscript:   
go                                 

if object_id('tempdb..#tag_options', 'U') is not null
   exec('drop table #tag_options')
go
