set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading new tag options into the entity_tag_option table (Portfolio) ...'
go

declare @oid                  numeric(18, 0),
        @rows_added           int,
        @errcode              int,
        @entity_tag_id        int,
        @tag_option           char(16),
        @tag_option_desc      varchar(64),
        @tag_option_status    char(1),
        @smsg                 varchar(255),
        @entity_tag_name      varchar(16),
        @status               int,
        @target_entity_name   varchar(30),
        @entity_name          varchar(30),
        @target_entity_id     int,
        @entity_id            int


create table #tag_options
(
   oid                  numeric(18, 0) IDENTITY,
   entity_tag_id        int         NOT NULL,
   tag_option           char(16)    NOT NULL,
   tag_option_desc      varchar(64) NULL,
   tag_option_status    char(1)     NOT NULL,
   entity_tag_name      varchar(16) NULL,
   entity_name          varchar(30) NULL
)

select @errcode = 0,
       @status = 0

select @entity_name = 'Portfolio',
       @entity_id = null

if @entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @entity_name, @entity_id OUTPUT
   if @status > 0 or @entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end

-- ----------------------------------------------------------------------------
-- TAG   : CLASS
-- ENTITY: Portfolio
-- ----------------------------------------------------------------------------

print '=> Saving options for the tag ''CLASS'' (entity = ''Portfolio'') into temporary table ...'

select @entity_tag_name = 'CLASS'

exec @status = dbo.usp_find_entity_tag_id null, @entity_id, @entity_tag_name, @entity_tag_id OUTPUT
if @status > 0 or @entity_tag_id is null
begin
   select @smsg = 'Could not find the ID for the entity_tag_name ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''') in the entity_tag_definition table!'
   print @smsg
   goto endofscript
end

insert into #tag_options
     (entity_tag_id, tag_option, tag_option_desc, tag_option_status, entity_tag_name, entity_name)
   values (@entity_tag_id, 'Active', 'Active', 'A', @entity_tag_name, @entity_name)
insert into #tag_options
     (entity_tag_id, tag_option, tag_option_desc, tag_option_status, entity_tag_name, entity_name)
   values (@entity_tag_id, 'Closed', 'Closed', 'A', @entity_tag_name, @entity_name)
insert into #tag_options
     (entity_tag_id, tag_option, tag_option_desc, tag_option_status, entity_tag_name, entity_name)
   values (@entity_tag_id, 'Inactive', 'Inactive', 'A', @entity_tag_name, @entity_name)


-- ----------------------------------------------------------------------------
-- TAG   : UseBDENSITYSpec
-- ENTITY: Portfolio
-- ----------------------------------------------------------------------------

print '=> Saving options for the tag ''UseBDENSITYSpec'' (entity = ''Portfolio'') into temporary table ...'

select @entity_tag_name = 'UseBDENSITYSpec'

exec @status = dbo.usp_find_entity_tag_id null, @entity_id, @entity_tag_name, @entity_tag_id OUTPUT
if @status > 0 or @entity_tag_id is null
begin
   select @smsg = 'Could not find the ID for the entity_tag_name ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''') in the entity_tag_definition table!'
   print @smsg
   goto endofscript
end

insert into #tag_options
     (entity_tag_id, tag_option, tag_option_desc, tag_option_status, entity_tag_name, entity_name)
   values (@entity_tag_id, 'Yes', 'Yes', 'A', @entity_tag_name, @entity_name)
insert into #tag_options
     (entity_tag_id, tag_option, tag_option_desc, tag_option_status, entity_tag_name, entity_name)
   values (@entity_tag_id, 'No', 'No', 'A', @entity_tag_name, @entity_name)



print ' '

/* ******************************************************************** */
/* The code body for adding records into the entity_tag_option table    */
/* ******************************************************************** */

select @oid = min(oid)
from #tag_options

while @oid is not null
begin
   select @entity_tag_id = entity_tag_id,
          @tag_option = tag_option,
          @tag_option_desc = tag_option_desc,
          @tag_option_status = tag_option_status,
          @entity_tag_name = entity_tag_name,
          @entity_name = entity_name
   from #tag_options
   where oid = @oid
   
   if not exists (select 1
                  from dbo.entity_tag_option
                  where entity_tag_id = @entity_tag_id and
                        tag_option = @tag_option)
   begin
      begin tran
      insert into dbo.entity_tag_option
           (entity_tag_id, tag_option, tag_option_desc, tag_option_status, trans_id)
         values(@entity_tag_id, @tag_option, @tag_option_desc, @tag_option_status, 1)
      select @rows_added = @@rowcount,
             @errcode = @@error
      if @errcode > 0 or @rows_added = 0
      begin
         if @@trancount > 0
            rollback tran
         if @errcode > 0
            goto endofscript
      end
      else
      begin
         commit tran
         select @smsg = '=> TAG ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''')'
         print @smsg
         select @smsg = '==>  The tag option ''' + rtrim(@tag_option) + ''' was added successfully!' 
         print @smsg
      end  
   end

   select @oid = min(oid)
   from #tag_options
   where oid > @oid
end
endofscript:   
go
