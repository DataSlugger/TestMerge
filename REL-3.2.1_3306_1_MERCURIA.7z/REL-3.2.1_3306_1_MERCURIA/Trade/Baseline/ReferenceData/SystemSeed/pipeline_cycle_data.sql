set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table pipeline_cycle
go

print 'Loading seed reference data into the pipeline_cycle table ...'
go

insert into dbo.pipeline_cycle 
   values(1, 'CPL', 1, 'F', 'JAN', NULL, 'Jan  1 1997 12:00:00', 'Jan  5 1997 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(2, 'CPL', 1, 'B', 'JAN', NULL, 'Jan  6 1992 12:00:00', 'Jan 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(3, 'CPL', 2, 'F', 'JAN', NULL, 'Jan 11 1992 12:00:00', 'Jan 15 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(4, 'CPL', 2, 'B', 'JAN', NULL, 'Jan 16 1992 12:00:00', 'Jan 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(5, 'CPL', 3, 'F', 'JAN', NULL, 'Jan 21 1992 12:00:00', 'Jan 25 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(6, 'CPL', 3, 'B', 'JAN', NULL, 'Jan 26 1992 12:00:00', 'Jan 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(7, 'CPL', 4, 'F', 'FEB', NULL, 'Feb  1 1992 12:00:00', 'Feb  5 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(8, 'CPL', 4, 'B', 'FEB', NULL, 'Feb  6 1992 12:00:00', 'Feb 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(9, 'CPL', 5, 'F', 'FEB', NULL, 'Feb 11 1992 12:00:00', 'Feb 15 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(10, 'CPL', 5, 'B', 'FEB', NULL, 'Feb 16 1992 12:00:00', 'Feb 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(11, 'CPL', 6, 'F', 'FEB', NULL, 'Feb 21 1992 12:00:00', 'Feb 25 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(12, 'CPL', 6, 'B', 'FEB', NULL, 'Feb 26 1992 12:00:00', 'Feb 28 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(13, 'CPL', 7, 'F', 'MAR', NULL, 'Mar  1 1992 12:00:00', 'Mar  5 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(14, 'CPL', 7, 'B', 'MAR', NULL, 'Mar  6 1992 12:00:00', 'Mar 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(15, 'CPL', 8, 'F', 'MAR', NULL, 'Mar 11 1992 12:00:00', 'Mar 15 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(16, 'CPL', 8, 'B', 'MAR', NULL, 'Mar 16 1992 12:00:00', 'Mar 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(17, 'CPL', 9, 'F', 'MAR', NULL, 'Mar 21 1992 12:00:00', 'Mar 25 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(18, 'CPL', 9, 'B', 'MAR', NULL, 'Mar 26 1992 12:00:00', 'Mar 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(28, 'CPL', 10, 'F', 'APR', NULL, 'Apr  1 1992 12:00:00', 'Apr  5 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(29, 'CPL', 10, 'B', 'APR', NULL, 'Apr  6 1992 12:00:00', 'Apr 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(30, 'CPL', 11, 'F', 'APR', NULL, 'Apr 11 1992 12:00:00', 'Apr 15 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(31, 'CPL', 11, 'B', 'APR', NULL, 'Apr 16 1992 12:00:00', 'Apr 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(32, 'CPL', 12, 'F', 'APR', NULL, 'Apr 21 1992 12:00:00', 'Apr 25 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(33, 'CPL', 12, 'B', 'APR', NULL, 'Apr 26 1992 12:00:00', 'Apr 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(34, 'CPL', 13, 'F', 'MAY', NULL, 'May  1 1992 12:00:00', 'May  5 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(35, 'CPL', 13, 'B', 'MAY', NULL, 'May  6 1992 12:00:00', 'May 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(36, 'CPL', 14, 'F', 'MAY', NULL, 'May 11 1992 12:00:00', 'May 15 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(37, 'CPL', 14, 'B', 'MAY', NULL, 'May 16 1992 12:00:00', 'May 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(38, 'CPL', 15, 'F', 'MAY', NULL, 'May 21 1992 12:00:00', 'May 25 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(39, 'CPL', 15, 'B', 'MAY', NULL, 'May 26 1992 12:00:00', 'May 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(40, 'CPL', 16, 'F', 'JUN', NULL, 'Jun  1 1992 12:00:00', 'Jun  5 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(41, 'CPL', 16, 'B', 'JUN', NULL, 'Jun  6 1992 12:00:00', 'Jun 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(42, 'CPL', 17, 'F', 'JUN', NULL, 'Jun 11 1992 12:00:00', 'Jun 15 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(43, 'CPL', 17, 'B', 'JUN', NULL, 'Jun 16 1992 12:00:00', 'Jun 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(44, 'CPL', 18, 'F', 'JUN', NULL, 'Jun 21 1992 12:00:00', 'Jun 25 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(45, 'CPL', 18, 'B', 'JUN', NULL, 'Jun 26 1992 12:00:00', 'Jun 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(46, 'CPL', 19, 'F', 'JUL', NULL, 'Jul  1 1992 12:00:00', 'Jul  5 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(47, 'CPL', 19, 'B', 'JUL', NULL, 'Jul  6 1992 12:00:00', 'Jul 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(48, 'CPL', 20, 'F', 'JUL', NULL, 'Jul 11 1992 12:00:00', 'Jul 15 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(49, 'CPL', 20, 'B', 'JUL', NULL, 'Jul 16 1992 12:00:00', 'Jul 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(50, 'CPL', 21, 'B', 'JUL', NULL, 'Jul 26 1992 12:00:00', 'Jul 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(51, 'CPL', 22, 'F', 'AUG', NULL, 'Aug  1 1992 12:00:00', 'Aug  5 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(52, 'CPL', 22, 'B', 'AUG', NULL, 'Aug  6 1992 12:00:00', 'Aug 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(53, 'CPL', 23, 'F', 'AUG', NULL, 'Aug 11 1992 12:00:00', 'Aug 15 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(54, 'CPL', 23, 'B', 'AUG', NULL, 'Aug 16 1992 12:00:00', 'Aug 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(55, 'CPL', 24, 'F', 'AUG', NULL, 'Aug 21 1992 12:00:00', 'Aug 25 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(56, 'CPL', 24, 'B', 'AUG', NULL, 'Aug 26 1992 12:00:00', 'Aug 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(57, 'CPL', 25, 'F', 'SEP', NULL, 'Sep  1 1992 12:00:00', 'Sep  5 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(58, 'CPL', 25, 'B', 'SEP', NULL, 'Sep  6 1992 12:00:00', 'Sep 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(59, 'CPL', 26, 'F', 'SEP', NULL, 'Sep 11 1992 12:00:00', 'Sep 15 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(60, 'CPL', 26, 'B', 'SEP', NULL, 'Sep 16 1992 12:00:00', 'Sep 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(61, 'CPL', 27, 'F', 'SEP', NULL, 'Sep 21 1992 12:00:00', 'Sep 25 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(62, 'CPL', 27, 'B', 'SEP', NULL, 'Sep 26 1992 12:00:00', 'Sep 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(63, 'CPL', 28, 'F', 'OCT', NULL, 'Oct  1 1992 12:00:00', 'Oct  5 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(64, 'CPL', 28, 'B', 'OCT', NULL, 'Oct  6 1992 12:00:00', 'Oct 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(65, 'CPL', 29, 'F', 'OCT', NULL, 'Oct 11 1992 12:00:00', 'Oct 15 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(66, 'CPL', 29, 'B', 'OCT', NULL, 'Oct 16 1992 12:00:00', 'Oct 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(67, 'CPL', 30, 'F', 'OCT', NULL, 'Oct 21 1992 12:00:00', 'Oct 25 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(68, 'CPL', 30, 'B', 'OCT', NULL, 'Oct 26 1992 12:00:00', 'Oct 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(69, 'CPL', 31, 'F', 'NOV', NULL, 'Nov  1 1992 12:00:00', 'Nov  5 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(70, 'CPL', 31, 'B', 'NOV', NULL, 'Nov  6 1992 12:00:00', 'Nov 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(71, 'CPL', 32, 'F', 'NOV', NULL, 'Nov 11 1992 12:00:00', 'Nov 15 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(72, 'CPL', 32, 'B', 'NOV', NULL, 'Nov 16 1992 12:00:00', 'Nov 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(73, 'CPL', 33, 'F', 'NOV', NULL, 'Nov 21 1992 12:00:00', 'Nov 25 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(74, 'CPL', 33, 'B', 'NOV', NULL, 'Nov 26 1992 12:00:00', 'Nov 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(75, 'CPL', 34, 'F', 'DEC', NULL, 'Dec  1 1992 12:00:00', 'Dec  5 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(76, 'CPL', 34, 'B', 'DEC', NULL, 'Dec  6 1992 12:00:00', 'Dec 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(77, 'CPL', 35, 'F', 'DEC', NULL, 'Dec 11 1992 12:00:00', 'Dec 15 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(78, 'CPL', 35, 'B', 'DEC', NULL, 'Dec 16 1992 12:00:00', 'Dec 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(79, 'CPL', 36, 'F', 'DEC', NULL, 'Dec 21 1992 12:00:00', 'Dec 25 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(80, 'CPL', 36, 'B', 'DEC', NULL, 'Dec 26 1992 12:00:00', 'Dec 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(81, 'CPL', 21, 'F', 'JUL', NULL, 'Jul 21 1992 12:00:00', 'Jul 25 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(82, 'CPL', 1, 'A', 'JAN', NULL, 'Jan  1 1992 12:00:00', 'Jan 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(83, 'CPL', 2, 'A', 'JAN', NULL, 'Jan 11 1992 12:00:00', 'Jan 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(84, 'CPL', 3, 'A', 'JAN', NULL, 'Jan 21 1992 12:00:00', 'Jan 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(85, 'CPL', 4, 'A', 'FEB', NULL, 'Feb  1 1992 12:00:00', 'Feb 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(86, 'CPL', 5, 'A', 'FEB', NULL, 'Feb 11 1992 12:00:00', 'Feb 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(87, 'CPL', 6, 'A', 'FEB', NULL, 'Feb 21 1992 12:00:00', 'Feb 28 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(88, 'CPL', 7, 'A', 'MAR', NULL, 'Mar  1 1992 12:00:00', 'Mar 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(89, 'CPL', 8, 'A', 'MAR', NULL, 'Mar 11 1992 12:00:00', 'Mar 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(90, 'CPL', 9, 'A', 'MAR', NULL, 'Mar 21 1992 12:00:00', 'Mar 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(91, 'CPL', 10, 'A', 'APR', NULL, 'Apr  1 1992 12:00:00', 'Apr 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(92, 'CPL', 11, 'A', 'APR', NULL, 'Apr 11 1992 12:00:00', 'Apr 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(93, 'CPL', 12, 'A', 'APR', NULL, 'Apr 21 1992 12:00:00', 'Apr 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(94, 'CPL', 13, 'A', 'MAY', NULL, 'May  1 1992 12:00:00', 'May 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(95, 'CPL', 14, 'A', 'MAY', NULL, 'May 11 1992 12:00:00', 'May 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(96, 'CPL', 15, 'A', 'MAY', NULL, 'May 21 1992 12:00:00', 'May 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(97, 'CPL', 16, 'A', 'JUN', NULL, 'Jun  1 1992 12:00:00', 'Jun 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(98, 'CPL', 17, 'A', 'JUN', NULL, 'Jun 11 1992 12:00:00', 'Jun 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(99, 'CPL', 18, 'A', 'JUN', NULL, 'Jun 21 1992 12:00:00', 'Jun 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(100, 'EPL', 1, 'A', 'JAN', NULL, 'Jan  1 1992 12:00:00', 'Jan 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(101, 'EPL', 2, 'A', 'JAN', NULL, 'Jan 11 1992 12:00:00', 'Jan 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(102, 'EPL', 3, 'A', 'JAN', NULL, 'Jan 21 1992 12:00:00', 'Jan 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(103, 'EPL', 4, 'A', 'FEB', NULL, 'Feb  1 1992 12:00:00', 'Feb 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(104, 'EPL', 5, 'A', 'FEB', NULL, 'Feb 11 1992 12:00:00', 'Feb 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(105, 'EPL', 6, 'A', 'FEB', NULL, 'Feb 21 1992 12:00:00', 'Feb 28 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(106, 'EPL', 7, 'A', 'MAR', NULL, 'Mar  1 1992 12:00:00', 'Mar 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(107, 'EPL', 8, 'A', 'MAR', NULL, 'Mar 11 1992 12:00:00', 'Mar 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(108, 'EPL', 9, 'A', 'MAR', NULL, 'Mar 21 1992 12:00:00', 'Mar 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(109, 'EPL', 10, 'A', 'APR', NULL, 'Apr  1 1992 12:00:00', 'Apr 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(110, 'EPL', 11, 'A', 'APR', NULL, 'Apr 11 1992 12:00:00', 'Apr 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(111, 'EPL', 12, 'A', 'APR', NULL, 'Apr 21 1992 12:00:00', 'Apr 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(112, 'EPL', 13, 'A', 'MAY', NULL, 'May  1 1992 12:00:00', 'May 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(113, 'EPL', 14, 'A', 'MAY', NULL, 'May 11 1992 12:00:00', 'May 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(114, 'EPL', 15, 'A', 'MAY', NULL, 'May 21 1992 12:00:00', 'May 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(115, 'EPL', 16, 'A', 'JUN', NULL, 'Jun  1 1992 12:00:00', 'Jun 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(116, 'EPL', 17, 'A', 'JUN', NULL, 'Jun 11 1992 12:00:00', 'Jun 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(117, 'EPL', 18, 'A', 'JUN', NULL, 'Jun 21 1992 12:00:00', 'Jun 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(118, 'EPL', 19, 'A', 'JUL', NULL, 'Jul  1 1992 12:00:00', 'Jul 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(119, 'EPL', 20, 'A', 'JUL', NULL, 'Jul 11 1992 12:00:00', 'Jul 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(120, 'EPL', 21, 'A', 'JUL', NULL, 'Jul 21 1992 12:00:00', 'Jul 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(121, 'EPL', 22, 'A', 'AUG', NULL, 'Aug  1 1992 12:00:00', 'Aug 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(122, 'EPL', 23, 'A', 'AUG', NULL, 'Aug 11 1992 12:00:00', 'Aug 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(123, 'EPL', 24, 'A', 'AUG', NULL, 'Aug 21 1992 12:00:00', 'Aug 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(124, 'EPL', 25, 'A', 'SEP', NULL, 'Sep  1 1992 12:00:00', 'Sep 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(125, 'EPL', 26, 'A', 'SEP', NULL, 'Sep 11 1992 12:00:00', 'Sep 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(126, 'EPL', 27, 'A', 'SEP', NULL, 'Sep 21 1992 12:00:00', 'Sep 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(127, 'EPL', 28, 'A', 'OCT', NULL, 'Oct  1 1992 12:00:00', 'Oct 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(128, 'EPL', 29, 'A', 'OCT', NULL, 'Oct 11 1992 12:00:00', 'Oct 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(129, 'EPL', 30, 'A', 'OCT', NULL, 'Oct 21 1992 12:00:00', 'Oct 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(130, 'EPL', 31, 'A', 'NOV', NULL, 'Nov  1 1992 12:00:00', 'Nov 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(131, 'EPL', 32, 'A', 'NOV', NULL, 'Nov 11 1992 12:00:00', 'Nov 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(132, 'EPL', 33, 'A', 'NOV', NULL, 'Nov 21 1992 12:00:00', 'Nov 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(133, 'EPL', 34, 'A', 'DEC', NULL, 'Dec  1 1992 12:00:00', 'Dec 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(134, 'EPL', 35, 'A', 'DEC', NULL, 'Dec 11 1992 12:00:00', 'Dec 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(135, 'EPL', 36, 'A', 'DEC', NULL, 'Dec 21 1992 12:00:00', 'Dec 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(150, 'CPL', 19, 'A', 'JUL', NULL, 'Jul  1 1992 12:00:00', 'Jul 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(151, 'CPL', 20, 'A', 'JUL', NULL, 'Jul 11 1992 12:00:00', 'Jul 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(152, 'CPL', 21, 'A', 'JUL', NULL, 'Jul 21 1992 12:00:00', 'Jul 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(153, 'CPL', 22, 'A', 'AUG', NULL, 'Aug  1 1992 12:00:00', 'Aug 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(154, 'CPL', 23, 'A', 'AUG', NULL, 'Aug 11 1992 12:00:00', 'Aug 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(155, 'CPL', 24, 'A', 'AUG', NULL, 'Aug 21 1992 12:00:00', 'Aug 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(156, 'CPL', 25, 'A', 'SEP', NULL, 'Sep  1 1992 12:00:00', 'Sep 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(157, 'CPL', 26, 'A', 'SEP', NULL, 'Sep 11 1992 12:00:00', 'Sep 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(158, 'CPL', 27, 'A', 'SEP', NULL, 'Sep 21 1992 12:00:00', 'Sep 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(159, 'CPL', 28, 'A', 'OCT', NULL, 'Oct  1 1992 12:00:00', 'Oct 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(160, 'CPL', 29, 'A', 'OCT', NULL, 'Oct 11 1992 12:00:00', 'Oct 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(161, 'CPL', 30, 'A', 'OCT', NULL, 'Oct 21 1992 12:00:00', 'Oct 31 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(162, 'CPL', 31, 'A', 'NOV', NULL, 'Nov  1 1992 12:00:00', 'Nov 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(163, 'CPL', 32, 'A', 'NOV', NULL, 'Nov 11 1992 12:00:00', 'Nov 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(164, 'CPL', 33, 'A', 'NOV', NULL, 'Nov 21 1992 12:00:00', 'Nov 30 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(165, 'CPL', 34, 'A', 'DEC', NULL, 'Dec  1 1992 12:00:00', 'Dec 10 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(166, 'CPL', 35, 'A', 'DEC', NULL, 'Dec 11 1992 12:00:00', 'Dec 20 1992 12:00:00', 1)
go

insert into dbo.pipeline_cycle 
   values(167, 'CPL', 36, 'A', 'DEC', NULL, 'Dec 21 1992 12:00:00', 'Dec 31 1992 12:00:00', 1)
go

