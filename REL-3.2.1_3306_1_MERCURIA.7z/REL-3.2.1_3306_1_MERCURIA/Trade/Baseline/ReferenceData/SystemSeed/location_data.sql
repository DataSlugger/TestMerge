set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the location table ...'
go

if NOT EXISTS (select *
               from dbo.location
               where loc_code = '/')
   insert into dbo.location
        (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
         loc_num, loc_status, trans_id)
      values('/', 'ROOT', 'N', 'N', 'N', 1, 'A', 1)
go

if NOT EXISTS (select *
               from dbo.location
               where loc_code = 'TC')
   insert into dbo.location
        (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
         loc_num, loc_status, trans_id)
      values('TC', 'TC', 'Y', 'N', 'N', 0, 'A', 1)
go

if NOT EXISTS (select *
               from dbo.location_group
               where loc_code = 'TC' and
                     parent_loc_code = '/' and
                     loc_type_code = 'OFF')
   insert into dbo.location_group 
        (parent_loc_code, loc_code, loc_type_code, virtual_ind, trans_id)
      values('/', 'TC', 'OFF', 'N', 1)
go

/* ********************************************************************** */

print ' '
print 'Filling location records with latitude and longitude data ...'
print ' '
go

create table #location_1358785
(    
   loc_code	  char(8) PRIMARY KEY,
   loc_name	  varchar(40),
   latitude	  numeric(9,6),
   longitude	numeric(9,6)
)
go

INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('ABUDHABI','ABU DHABI','24.466667','54.366667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('AMS','AMSTERDAM','52.366667','4.883333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('ANTWP','ANTWERP','51.216667','4.383333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('BTNROUGE','BATON ROUGE, LA','30.450000','-91.133333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('OAKLAND','PORT OF OAKLAND, CA','37.800000','-122.266667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('CANTON','CANTON, OH','40.783333','-81.366667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('CATTBURG','CATLETTSBURG, KY','38.400000','-82.600000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('CHIBA JP','CHIBA, JAPAN','35.600000','140.100000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('CHICAGO','CHICAGO. IL','41.866667','-87.616667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('CONCPCN','CONCEPCION, CHILE','-36.816667','-73.050000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('CONSTA','CONSTANTA, ROMANIA','44.166667','28.633333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('CORPUS','CORPUS CHRISTI, TX','27.800000','-97.383333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('CORYTON','CORYTON, CARDIFF','51.516667','-3.233333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('CUSHING','CUSHING, OK','35.983333','-96.766667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('DALIAN','DALIAN CHINA','38.900000','121.600000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('DETROIT','DETROIT,  MI','42.316667','-83.033333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('DOSBOCAS','DOS BOCAS, CUBA','20.083333','-75.766667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('GALENA','GALENA PARK, TX','29.733333','-95.216667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('GARYVILL','GARYVILLE, LA','30.050000','-90.616667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('GIBRALTA','GIBRALTAR','36.133333','-5.333333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('GTM','GUATEMALA','15.783333','-90.216667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('HARDISTY','HARDISTY, OR','44.700000','-119.100000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('HNRY HUB','HENRY HUB','29.950000','-92.033333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('HOCHMINH','HO CHI MINH','10.816667','106.616667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('HOUNDPT','HOUND POINT, UK','55.966667','-3.366667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('HOU TX','HOUSTON TX','29.750000','-95.366667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('HUANGPU','HUANGPU, CHINA','33.216667','121.466667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('HB','HUNTINGTON BEACH, CA','33.650000','-117.983333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('JEBELDHA','JEBEL DHANNA, ABU DHABI','24.150000','52.600000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('JEDDAH','JEDDAH SAUDI ARABIA','21.533333','39.166667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('JURONG','JURONG ISLAND, SINGAPORE','1.266667','103.666667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('LNGBEACH','LONG BEACH, CA','33.800000','-118.150000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('LOOP','LOUISIANA OFFSHORE OIL PORT','29.100000','-90.183333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('LOUISVIL','LOUISVILLE, KY','38.250000','-85.750000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('MLFRDHAV','MILFORD HAVEN, UK','51.700000','-5.016667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('MTBLVIEU','MONT BELVIEU','29.833333','-94.883333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('MUSCAT','MUSCAT, OMAN','23.600000','58.583333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('NEB','OMAHA, NE','41.250000','-95.983333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('N MEXICO','VAUGHN, NM','34.600000','-105.200000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('NYHARBOR','NEW YORK HARBOR','42.066667','-70.650000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('OK','OKLAHOMA CITY, ok','35.466667','-97.500000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('PALAUTEK','PULAU TEKONG, SINGAPORE','1.400000','104.050000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('PASADENA','PASADENA, TX','29.683333','-95.200000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('PATOKA','PATOKA, IN','38.400000','-87.583333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('P MOIN','PORT MOIN, PUERTO LIMON, COSTA RICA','18.183333','-67.050000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('PRIMORSK','PRIMORSK, RUSSIA','60.383333','28.583333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('PTLACRUZ','PUERTO LA CRUZ','10.183333','-64.633333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('QUAIBOE','QUA IBOE, NIGERIA','5.350000','7.516667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('RASTANUR','RAS TANURA, SAUDI ARABIA','26.716667','50.016667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('RIOHAINA','RIO HAINA, DOMICAN REPUBLIC','18.416667','-70.000000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('RDAM','ROTTERDAM','51.916667','4.466667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('ARUBA','SAN NICOLAS','12.416667','-69.916667')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('SERAYA','SERAYA','56.416667','38.750000')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('SDAKOTA','WHITE RIVER,SOUTH DAKOTA','43.566667','-100.733333')
go
INSERT INTO #location_1358785(loc_code,loc_name,latitude,longitude)
values('ST JAMES','ST JAMES LA','30.016667','-90.783333')
go


delete a
from #location_1358785 a
where not exists (select 1
                  from dbo.location b
                  where a.loc_code = b.loc_code)
go
                  
if (select count(*) from #location_1358785) = 0
   goto endofscript
   
declare @transId       int,
	      @rows_affected int
        
   begin tran
   begin try
     exec dbo.gen_new_transaction_NOI @app_name = 'StarterDB_1358785'
   end try
   begin catch
     if @@trancount > 0
        rollback tran
     print '=> Error occurred while executing the ''gen_new_transaction_NOI'' stored procedure due to the error:'    
     print '==> ERROR:' + ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran

   select @transId = null 
   select @transId = last_num 
   from dbo.icts_trans_sequence 
   where oid = 1

   if @transId is null
   begin
      print '=> Failed to obtain a new trans_id for newly created icts_transaction record!'
      goto endofscript
   end

   begin tran
   begin try
     update loc
     set loc.latitude = loc1.latitude,
         loc.longitude = loc1.longitude,
         trans_id = @transId
     from dbo.location loc, #location_1358785 loc1
     where loc.loc_code = loc1.loc_code and
           (isnull(loc.latitude,0) <> loc1.latitude or
	          isnull(loc.longitude,0) <> loc1.longitude)
     select @rows_affected = @@rowcount
   end try
   begin catch
     if @@trancount > 0
        rollback tran
     print '=> Failed to update latitude and longitude values in location table due to below error:'
     print '==> ERROR:' + ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
      print '=> ' + convert(char(3), @rows_affected) + 'Rows updated in location table successfully !'
   else
      print '=> No rows updated in location table seems latitude and logitude values in location table are already correct.'
endofscript:
drop table #location_1358785
go
