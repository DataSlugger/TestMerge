set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the vat_type table ...'
go

if not exists (select 1
               from dbo.vat_type 
               where vat_type_code = 'T1')
   insert into dbo.vat_type (vat_type_code, vat_type_desc, vat_type_status, trans_id)
      values ('T1', 'T1', 'A', 1)
go

if not exists (select 1
               from dbo.vat_type 
               where vat_type_code = 'EEC')
   insert into dbo.vat_type (vat_type_code, vat_type_desc, vat_type_status, trans_id)
      values ('EEC', 'EEC', 'A', 1)
go

if not exists (select 1
               from dbo.vat_type 
               where vat_type_code = 'VAT')
   insert into dbo.vat_type (vat_type_code, vat_type_desc, vat_type_status, trans_id)
      values ('VAT', 'Not EU Qualified Or Form-A', 'A', 1)
go

if not exists (select 1
               from dbo.vat_type 
               where vat_type_code = 'EU')
   insert into dbo.vat_type (vat_type_code, vat_type_desc, vat_type_status, trans_id)
      values ('EU', 'EU Qualified', 'A', 1)
go

if not exists (select 1
               from dbo.vat_type 
               where vat_type_code = 'Form-A')
   insert into dbo.vat_type (vat_type_code, vat_type_desc, vat_type_status, trans_id)
      values ('Form-A', 'Form-A Presented', 'A', 1)
go

if not exists (select 1
               from dbo.vat_type 
               where vat_type_code = 'EXCISE')
   insert into dbo.vat_type (vat_type_code, vat_type_desc, vat_type_status, trans_id)
      values ('EXCISE', 'EXCISE', 'A', 1)
go
