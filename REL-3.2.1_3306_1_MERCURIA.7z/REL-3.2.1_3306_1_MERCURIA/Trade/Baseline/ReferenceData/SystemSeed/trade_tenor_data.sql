set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the trade_tenor table ...'
go

if not exists (select 1
               from dbo.trade_tenor
               where tenor_code = 'PM')
   insert into dbo.trade_tenor (tenor_code, tenor_desc, trans_id) values('PM', 'Prompt month', 1)
go

if not exists (select 1
               from dbo.trade_tenor
               where tenor_code = '3M')
   insert into dbo.trade_tenor (tenor_code, tenor_desc, trans_id) values('3M', '3 months', 1)
go

if not exists (select 1
               from dbo.trade_tenor
               where tenor_code = '6M')
   insert into dbo.trade_tenor (tenor_code, tenor_desc, trans_id) values('6M', '6 months', 1)
go

if not exists (select 1
               from dbo.trade_tenor
               where tenor_code = '9M')
   insert into dbo.trade_tenor (tenor_code, tenor_desc, trans_id) values('9M', '9 months', 1)
go

if not exists (select 1
               from dbo.trade_tenor
               where tenor_code = '1Y')
   insert into dbo.trade_tenor (tenor_code, tenor_desc, trans_id) values('1Y', '1 year', 1)
go

if not exists (select 1
               from dbo.trade_tenor
               where tenor_code = '18M')
   insert into dbo.trade_tenor (tenor_code, tenor_desc, trans_id) values('18M', '18 months', 1)
go

if not exists (select 1
               from dbo.trade_tenor
               where tenor_code = '2Y')
   insert into dbo.trade_tenor (tenor_code, tenor_desc, trans_id) values('2Y', '2 years', 1)
go

if not exists (select 1
               from dbo.trade_tenor
               where tenor_code = '3Y')
   insert into dbo.trade_tenor (tenor_code, tenor_desc, trans_id) values('3Y', '3 years', 1)
go

if not exists (select 1
               from dbo.trade_tenor
               where tenor_code = '5Y')
   insert into dbo.trade_tenor (tenor_code, tenor_desc, trans_id) values('5Y', '5 years', 1)
go

