set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table booking_company_info
go

print 'Loading seed reference data into the booking_company_info table ...'
go

INSERT INTO dbo.booking_company_info(acct_num,dept_code,accounting_comp_id,
     dflt_ar_acct_code,dflt_ap_acct_code,dflt_gl_journal_code,
     dflt_data_class_code,dflt_book_curr_code,division_code,
     writeoff_tolerance,calendar_code,inventory_method_code,
     liquidation_method_code,mvmt_costs_inv_ind,
     non_mvmt_costs_inv_ind,trans_id)
VALUES(1,'TC',NULL,NULL,NULL,NULL,NULL,'USD','TC',9999.0,
       'BANKSUS',NULL,NULL,'N','N',1)
go

