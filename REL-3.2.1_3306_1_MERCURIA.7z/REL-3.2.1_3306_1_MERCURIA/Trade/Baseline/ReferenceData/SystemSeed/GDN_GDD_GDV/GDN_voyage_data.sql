/* ********************************************************
    GENERIC DATA SET: voyage
   ******************************************************** */

set nocount on

print 'Loading GDN/GDD/GDV data for data_name ''voyage'' ...'
go

declare @gdn_num int,
        @gdd_num int

if not exists (select * from dbo.generic_data_name
               where data_name = 'voyage')
begin
   select @gdn_num = max(gdn_num)
   from dbo.generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into dbo.generic_data_name 
   values(@gdn_num, 'voyage', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from dbo.generic_data_name
   where data_name = 'voyage'
end

if not exists (select * from dbo.generic_data_definition
               where gdn_num = @gdn_num and
                     attr_name = 'cmdty_group')
begin
   select @gdd_num = max(gdd_num)
   from dbo.generic_data_definition

   if @gdd_num is null
      select @gdd_num = 1
   else
      select @gdd_num = @gdd_num + 1

   insert into dbo.generic_data_definition
   values(@gdd_num, @gdn_num, 'voyage', 'cmdty_group', 4, 1)

   select @gdd_num = @gdd_num + 1  
   insert into dbo.generic_data_definition
   values(@gdd_num, @gdn_num, 'voyage', 'year', 4, 1)

   select @gdd_num = @gdd_num + 1  
   insert into dbo.generic_data_definition
   values(@gdd_num, @gdn_num, 'voyage', 'new_num', 1, 1)

   select @gdd_num = @gdd_num + 1  
   insert into dbo.generic_data_definition
   values(@gdd_num, @gdn_num, 'voyage', 'alloc_type', 4, 1)
end

print 'All data items for data name ''voyage'' were loaded ...'

endofscript:
go

exec dbo.refresh_a_last_num 'generic_data_name', 'gdn_num'
go
exec dbo.refresh_a_last_num 'generic_data_definition', 'gdd_num'
go
exec dbo.refresh_a_last_num 'generic_data_values', 'gdv_num'
go


