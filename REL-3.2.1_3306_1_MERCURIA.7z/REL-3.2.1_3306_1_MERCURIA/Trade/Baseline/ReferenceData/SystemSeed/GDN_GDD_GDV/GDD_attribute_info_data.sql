set nocount on

print ' '
print 'Inserting new gdd_num into gdd_attribute_info table IF NOT EXIST! '
go

create table #gdd_attr_info
(
gdd_num int not null,
)

insert into #gdd_attr_info(gdd_num)
select 1
union all
select 2
union all
select 3
union all
select 4
union all
select 5
union all
select 42
union all
select 43
union all
select 44
union all
select 45
union all
select 59
go

declare         @rows_affected          int,
		@transId               int


if exists (select 1 from #gdd_attr_info gai 
	left outer join gdd_attribute_info gdai on gai.gdd_num = gdai.gdd_num
	where gdai.gdd_num is null) 
begin

/* Begin - new trans_id script */
        
   begin tran
   begin try
       exec dbo.gen_new_transaction_NOI @app_name = 'DbUpgrade_1388118'
   end try
   begin catch
     if @@trancount > 0
        rollback tran
     print '=> Error occurred while executing the ''gen_new_transaction_NOI'' stored procedure!'    
     print '==> ERROR: ' + ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran

   select @transId = null

   select @transId = last_num 
   from dbo.icts_trans_sequence 
   where oid = 1

   if @transId is null
   begin
      print '=> Failed to obtain a new trans_id for insert!'
      goto endofscript
   end

/* End - new trans_id script */

   begin tran
   begin try
   insert into gdd_attribute_info(gdd_num,trans_id)
	select gai.gdd_num, @transId 
	from #gdd_attr_info gai left outer join gdd_attribute_info gdai 
	on gai.gdd_num = gdai.gdd_num
	where gdai.gdd_num is null 
      select @rows_affected = @@rowcount
   end try
   begin catch
   if @@trancount > 0 
            rollback tran 
      print '=> Failed to insert a record into the ''gdd_attribute_info'' table!'
      print '==> ERROR: ' + ERROR_MESSAGE()
      goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
      print '=> Records Inserted in the ''gdd_attribute_info'' table for Sucessfully! '
end
else 
      print '=> Record already exists in the ''gdd_attribute_info'' table.'

endofscript:
go

