/* ********************************************************
    GENERIC DATA SET: PASS_CONTROL_INFO
   ******************************************************** */
set nocount on

print 'Loading GDN/GDD/GDV data for data_name ''PASS_CONTROL_INFO'' ...'
go

declare @gdn_num int,
        @gdd_num int

set @gdn_num = null
set @gdd_num = null

if not exists (select 1 
               from dbo.generic_data_name
               where data_name = 'PASS_CONTROL_INFO')
begin
   select @gdn_num = max(gdn_num)
   from dbo.generic_data_name

   if @gdn_num is null
      set @gdn_num = 1
   else
      set @gdn_num = @gdn_num + 1
   
   insert into dbo.generic_data_name 
   values(@gdn_num, 'PASS_CONTROL_INFO', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from dbo.generic_data_name
   where data_name = 'PASS_CONTROL_INFO'
end

/* =================================================================
    Adding the following attributes into the generic_data_definition
    table:

        attr_name             data_type_ind
        --------------------- -------------
        pass_task_code        4
        column_number         1
        column_value          4
   =================================================================
*/

print '==> adding attributes into generic_data_definition table ..'

/* ***** ATTRIBUTE #1: pass_task_code ***** */

if not exists (select 1 
               from dbo.generic_data_definition
               where gdn_num = @gdn_num and
                     attr_name = 'pass_task_code')
begin
   select @gdd_num = max(gdd_num)
   from dbo.generic_data_definition

   if @gdd_num is null
      set @gdd_num = 1
   else
      set @gdd_num = @gdd_num + 1

   insert into dbo.generic_data_definition
   values(@gdd_num, @gdn_num, 'PASS_CONTROL_INFO', 'pass_task_code', 4, 1)
end

/* ***** ATTRIBUTE #2: column_number ***** */

if not exists (select 1 
               from dbo.generic_data_definition
               where gdn_num = @gdn_num and
                     attr_name = 'column_number')
begin
   select @gdd_num = max(gdd_num)
   from dbo.generic_data_definition

   if @gdd_num is null
      set @gdd_num = 1
   else
      set @gdd_num = @gdd_num + 1

   insert into dbo.generic_data_definition
   values(@gdd_num, @gdn_num, 'PASS_CONTROL_INFO', 'column_number', 1, 1)
end

/* ***** ATTRIBUTE #3: column_value ***** */

if not exists (select 1 
               from dbo.generic_data_definition
               where gdn_num = @gdn_num and
                     attr_name = 'column_value')
begin
   select @gdd_num = max(gdd_num)
   from dbo.generic_data_definition

   if @gdd_num is null
      set @gdd_num = 1
   else
      set @gdd_num = @gdd_num + 1

   insert into dbo.generic_data_definition
   values(@gdd_num, @gdn_num, 'PASS_CONTROL_INFO', 'column_value', 4, 1)
end
go


print '==> adding attribute values into generic_data_values table ...'
go

declare @gdd_num1        int,
        @gdd_num2        int,
        @gdd_num3        int,
		@gdn_num         int,
        @last_gdv_num    int,
        @smsg            varchar(255),
        @rows_affected   int,
        @errcode         int

declare @gdvs            table
(
   oid             int IDENTITY primary key,
   gdd_num         int,
   int_value       int null,
   string_value    nvarchar(255) null
)
        
select @gdd_num1 = null,
       @gdd_num2 = null,
       @gdd_num3 = null,
	   @gdn_num = null,
       @last_gdv_num = 0,
       @errcode = 0

select @gdn_num = gdn_num 
from dbo.generic_data_name
where data_name = 'PASS_CONTROL_INFO'

if @gdn_num is null
begin
   print '=> The GDN record for the data set "PASS_CONTROL_INFO" does not exist!'
   goto endofscript
end

select @gdd_num1 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'pass_task_code'

select @gdd_num2 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'column_number'

select @gdd_num3 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'column_value'
	  
/* 
   gdv_num       gdd_num                          int_value  string_value
   ------------- -------------------------------- ---------  ----------------------------------------------
   gdv_num+1     <gdd_num # for pass_task_code>              'FUTURE_BROKER_FIFO'
   gdv_num+2     <gdd_num # for column_number>    1          
   gdv_num+3     <gdd_num # for column_value>                'Brokers To Future FIFO'

   gdv_num+4     <gdd_num # for pass_task_code>              'OPTION_BROKER_FIFO'
   gdv_num+5     <gdd_num # for column_number>    2          
   gdv_num+6     <gdd_num # for column_value>                'Brokers To Options FIFO'

   gdv_num+7     <gdd_num # for pass_task_code>              'FUTURE_BROKER_FIFO'
   gdv_num+8     <gdd_num # for column_number>    3          
   gdv_num+9     <gdd_num # for column_value>                'Tag values to group Futures BROKER FIFO'

   gdv_num+10    <gdd_num # for pass_task_code>              'OPTION_BROKER_FIFO'
   gdv_num+11    <gdd_num # for column_number>    4          
   gdv_num+12    <gdd_num # for column_value>                'Tag values to group Options BROKER FIFO'
   
*/


insert into @gdvs
   (gdd_num, int_value, string_value)
  values(@gdd_num1, null, 'FUTURE_BROKER_FIFO'),         /* GDV row set #1  */
        (@gdd_num2, 1,    null),
        (@gdd_num3, null, 'Brokers To Future FIFO'),		
        (@gdd_num1, null, 'OPTION_BROKER_FIFO'),         /* GDV row set #2  */
        (@gdd_num2, 2,    null),
        (@gdd_num3, null, 'Brokers To Options FIFO'),		
        (@gdd_num1, null, 'FUTURE_BROKER_FIFO'),         /* GDV row set #3  */
        (@gdd_num2, 3,    null),
        (@gdd_num3, null, 'Tag values to group Futures BROKER FIFO'),
        (@gdd_num1, null, 'OPTION_BROKER_FIFO'),         /* GDV row set #4  */
        (@gdd_num2, 4,    null),
        (@gdd_num3, null, 'Tag values to group Options BROKER FIFO')
		

   begin tran
   select @last_gdv_num = isnull(max(gdv_num), 0) 
   from dbo.generic_data_values

   begin try
     insert into dbo.generic_data_values
          (gdv_num, gdd_num, int_value, string_value, trans_id)
	   select @last_gdv_num + oid, gdd_num, int_value, string_value, 1
	   from @gdvs
     set @rows_affected = @@rowcount
   end try
   begin catch
     set @errcode = ERROR_NUMBER()
     set @smsg = ERROR_MESSAGE()
     if @@trancount > 0
        rollback tran
     RAISERROR('=> Failed to add GDV records with correct gdv_num(s) due to the error below:', 0, 1) with nowait
     RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
      RAISERROR('=> %d GDV records with correct gdv_num(s) were added!', 0, 1, @rows_affected) with nowait
   else
      RAISERROR('=> No GDV records with correct gdv_num(s) were added!', 0, 1) with nowait

   RAISERROR('All data items for data name ''PASS_CONTROL_INFO'' were loaded ...', 0, 1) with nowait

endofscript:
go

exec dbo.refresh_a_last_num 'generic_data_name', 'gdn_num'
go
exec dbo.refresh_a_last_num 'generic_data_definition', 'gdd_num'
go
exec dbo.refresh_a_last_num 'generic_data_values', 'gdv_num'
go
