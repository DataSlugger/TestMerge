/* ********************************************************
    GENERIC DATA SET: account_ext_info
   ******************************************************** */

set nocount on

print 'Loading GDN/GDD/GDV data for data_name ''account_ext_info'' ...'
go

/* ********************************************************
    load generic_data_name 'acct_ext_info'
   ******************************************************** */

declare @gdn_num             int,
        @gdd_num             int,
        @data_name           varchar(80),
        @attr_name           varchar(40),
        @data_type_ind       tinyint

select @data_name = 'account_ext_info'

/* GDN */
if not exists (select 1 
               from dbo.generic_data_name
               where data_name = @data_name)
begin
   select @gdn_num = max(gdn_num)
   from dbo.generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into dbo.generic_data_name 
      values(@gdn_num, @data_name, 1)
end
else
begin
   select @gdn_num = gdn_num 
   from dbo.generic_data_name
   where data_name = @data_name
end

/* ***************************************************************** 
    Setting up the following attributes for the 'account_ext_info' 
    data set in the generic_data_definition table:
    
       gdd_num          attr_name           data_type_ind
       -------------    ------------------  -------------
       <gdd_num #1>     length              1
       <gdd_num #2>     caption             4
       <gdd_num #3>     id                  1
       <gdd_num #4>     list                4
       <gdd_num #5>     list_data           4
   ***************************************************************** */    
       
/* GDD - attribute 'length' */
select @attr_name = 'length',
       @data_type_ind = 1
if not exists (select 1 
               from dbo.generic_data_definition
               where gdn_num = @gdn_num and
		                 attr_name = @attr_name)
begin
   select @gdd_num = max(gdd_num)
   from dbo.generic_data_definition

   if @gdd_num is null
      select @gdd_num = 1
   else
      select @gdd_num = @gdd_num + 1

   insert into dbo.generic_data_definition
         (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
      values(@gdd_num, @gdn_num, @data_name, @attr_name, @data_type_ind, 1)
end

/* GDD - attribute 'caption' */
select @attr_name = 'caption',
       @data_type_ind = 4
if not exists (select 1 
               from dbo.generic_data_definition
               where gdn_num = @gdn_num and
		                 attr_name = @attr_name)
begin
   select @gdd_num = max(gdd_num)
   from dbo.generic_data_definition

   if @gdd_num is null
      select @gdd_num = 1
   else
      select @gdd_num = @gdd_num + 1

   insert into dbo.generic_data_definition
         (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
      values(@gdd_num, @gdn_num, @data_name, @attr_name, @data_type_ind, 1)
end

/* GDD - attribute 'id' */
select @attr_name = 'id',
       @data_type_ind = 1
if not exists (select 1 
               from dbo.generic_data_definition
               where gdn_num = @gdn_num and
		                 attr_name = @attr_name)
begin
   select @gdd_num = max(gdd_num)
   from dbo.generic_data_definition

   if @gdd_num is null
      select @gdd_num = 1
   else
      select @gdd_num = @gdd_num + 1

   insert into dbo.generic_data_definition
         (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
      values(@gdd_num, @gdn_num, @data_name, @attr_name, @data_type_ind, 1)
end

/* GDD - attribute 'type' */
select @attr_name = 'type',
       @data_type_ind = 4
if not exists (select 1 
               from dbo.generic_data_definition
               where gdn_num = @gdn_num and
		                 attr_name = @attr_name)
begin
   select @gdd_num = max(gdd_num)
   from dbo.generic_data_definition

   if @gdd_num is null
      select @gdd_num = 1
   else
      select @gdd_num = @gdd_num + 1

   insert into dbo.generic_data_definition
         (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
      values(@gdd_num, @gdn_num, @data_name, @attr_name, @data_type_ind, 1)
end

/* GDD - attribute 'list_data' */
select @attr_name = 'list_data',
       @data_type_ind = 4
if not exists (select 1 
               from dbo.generic_data_definition
               where gdn_num = @gdn_num and
		                 attr_name = @attr_name)
begin
   select @gdd_num = max(gdd_num)
   from dbo.generic_data_definition

   if @gdd_num is null
      select @gdd_num = 1
   else
      select @gdd_num = @gdd_num + 1

   insert into dbo.generic_data_definition
         (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
      values(@gdd_num, @gdn_num, @data_name, @attr_name, @data_type_ind, 1)
end
go



/* ************************************************************************************************ 
    Setup the following attribute values in the generic_data_values table:
    
       gdv_num      gdd_num for attribute   int_value      string_value
       ----------   ----------------------  -----------    -------------------------------------
       <gdv_num>    length                  20             null
       <gdv_num>    caption                 null           Credit Risk Status
       <gdv_num>    id                      1              null
       <gdv_num>    type                    null           list
       <gdv_num>    list_data               null           Low Risk, Medium Risk, High Risk, BLANK (old)
                                                           A Rated = Low Risk,B Rated = Low � Medium Risk,
                                                           C Rated = Medium � High Risk,D Rated = High Risk,
                                                           BLANK  (new - issue #1351026)    
   ************************************************************************************************ */

print ' '
print '==> adding attribute values into generic_data_values table ..'
go

declare @gdd_num1  int,
        @gdd_num2  int,
        @gdd_num3  int,
	      @gdd_num4  int,
	      @gdd_num5  int,
        @gdv_num   int,
        @gdn_num   int,
        @data_name varchar(80)

select @data_name = 'account_ext_info'

select @gdv_num = null,
       @gdn_num = null

select @gdn_num = null
select @gdn_num = gdn_num 
from dbo.generic_data_name
where data_name = @data_name

if @gdn_num is null
begin
   print '=> Could not find the data name ''' + @data_name + '''!'
   goto endofscript
end

select @gdd_num1 = null,
       @gdd_num2 = null,
       @gdd_num3 = null,
       @gdd_num4 = null,
       @gdd_num5 = null

/* attribute #1 - length */
select @gdd_num1 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'length'

/* attribute #2 - caption */
select @gdd_num2 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'caption'


/* attribute #3 - id */
select @gdd_num3 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'id'

/* attribute #4 - type */
select @gdd_num4 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'type'

/* attribute #5 - list_data */
select @gdd_num5 = gdd_num
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'list_data'

if @gdd_num1 is null or
   @gdd_num2 is null or
   @gdd_num3 is null or
   @gdd_num4 is null or
   @gdd_num5 is null 
begin
   print 'One or some of attributes for data name ''' + @data_name + ''' are missing!'
   goto endofscript
end 

select @gdv_num = 0
select @gdv_num = isnull(max(gdv_num), 0)
from dbo.generic_data_values

select @gdv_num = @gdv_num + 1
      

/* Value for the attribute #1 - 'length' */
if not exists (select 1
               from dbo.generic_data_values
               where int_value = 20 and
                     gdd_num = @gdd_num1)
begin      
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num1, 20, null, null, null, 1)
end

/* Value for the attribute #2 - 'caption' */
if not exists (select 1
               from dbo.generic_data_values
               where string_value = 'Credit Risk Status' and
                     gdd_num = @gdd_num2)
begin      
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num2, null, null, null, 'Credit Risk Status', 1)
end


/* Value for the attribute #3 - 'id' */
if not exists (select 1
               from dbo.generic_data_values
               where int_value = 1 and
                     gdd_num = @gdd_num3)
begin      
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num3, 1, null, null, null, 1)
end


/* Value for the attribute #4 - 'type' */
if not exists (select 1
               from dbo.generic_data_values
               where string_value = 'list' and
                     gdd_num = @gdd_num4)
begin      
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num4, null, null, null, 'list', 1)
end

/* Value for the attribute #5 - 'list_data' */
if not exists (select 1
               from dbo.generic_data_values
               where string_value = 'Low Risk, Medium Risk, High Risk, BLANK' and
                     gdd_num = @gdd_num5)
begin      
   insert into dbo.generic_data_values
        (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
      values(@gdv_num, @gdd_num5, null, null, null, 'A Rated = Low Risk,B Rated = Low � Medium Risk,C Rated = Medium � High Risk,D Rated = High Risk,BLANK', 1)
end

print 'All data items for data name ''account_ext_info'' were loaded ...'

endofscript:
go

exec dbo.refresh_a_last_num 'generic_data_name', 'gdn_num'
go
exec dbo.refresh_a_last_num 'generic_data_definition', 'gdd_num'
go
exec dbo.refresh_a_last_num 'generic_data_values', 'gdv_num'
go
