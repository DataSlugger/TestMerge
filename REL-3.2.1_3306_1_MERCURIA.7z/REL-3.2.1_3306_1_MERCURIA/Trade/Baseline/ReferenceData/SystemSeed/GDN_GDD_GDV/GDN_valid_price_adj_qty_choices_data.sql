/* ********************************************************
    GENERIC DATA SET: valid_price_adj_qty_choices
   ******************************************************** */

set nocount on

print 'Loading GDN/GDD/GDV data for data_name ''valid_price_adj_qty_choices'' ...'
go

declare @gdn_num int,
        @gdd_num int,
        @gdv_num int

select @gdn_num = gdn_num 
from dbo.generic_data_name
where data_name = 'valid_price_adj_qty_choices'

if @gdn_num is null
begin
   select @gdn_num = max(gdn_num)
   from dbo.generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into dbo.generic_data_name 
   values(@gdn_num, 'valid_price_adj_qty_choices', 1)
end

select @gdd_num = gdd_num 
from dbo.generic_data_definition
where gdn_num = @gdn_num and
      attr_name = 'qty_name'

if @gdd_num is null
begin
   select @gdd_num = max(gdd_num)
   from generic_data_definition

   if @gdd_num is null
      select @gdd_num = 1
   else
      select @gdd_num = @gdd_num + 1

   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'valid_price_adj_qty_choices', 'qty_name', 4, 1)
end

/* ****************************************************************************** */
create table #gdvs
(
   oid             int IDENTITY primary key,
   svalue          nvarchar(255)
)

insert into #gdvs (svalue)
      values('L/D GROSS PRIMARY'),
            ('L/D NET PRIMARY'),
            ('B/L GROSS PRIMARY'),
            ('B/L NET PRIMARY'),
            ('L/D GROSS SECONDARY'),
            ('L/D NET SECONDARY'),
            ('B/L GROSS SECONDARY'),
            ('B/L NET SECONDARY'),
            ('ACTUAL PRIMARY GROSS'),
            ('ACTUAL PRIMARY NET'),
            ('ACTUAL SECONDARY GROSS'),
            ('ACTUAL SECONDARY NET'),
            ('CONTRACTED');

declare @oid            int,
        @svalue         nvarchar(255)
        
select @oid = min(oid)
from #gdvs

while @oid is not null
begin
	 select @svalue = svalue
	 from #gdvs
	 where oid = @oid
	    
   select @gdv_num = gdv_num 
   from dbo.generic_data_values
   where gdd_num = @gdd_num and
         string_value = @svalue
   
   if @gdv_num is null
   begin                
      select @gdv_num = max(gdv_num)
      from dbo.generic_data_values

      if @gdv_num is null
         select @gdv_num = 1
      else
         select @gdv_num = @gdv_num + 1

      insert into dbo.generic_data_values
      values(@gdv_num, @gdd_num, null, null, null, @svalue, 1)
   end
   
   select @oid = min(oid)
   from #gdvs   
   where oid > @oid
end
drop table #gdvs

print 'All data items for data name ''valid_price_adj_qty_choices'' were loaded ...'

endofscript:
go

exec dbo.refresh_a_last_num 'generic_data_name', 'gdn_num'
go
exec dbo.refresh_a_last_num 'generic_data_definition', 'gdd_num'
go
exec dbo.refresh_a_last_num 'generic_data_values', 'gdv_num'
go

