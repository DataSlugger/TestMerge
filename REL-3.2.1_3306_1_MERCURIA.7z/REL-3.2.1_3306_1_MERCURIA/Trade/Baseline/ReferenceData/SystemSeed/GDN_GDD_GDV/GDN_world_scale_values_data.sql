/* ********************************************************
    GENERIC DATA SET: world_scale_values
   ******************************************************** */

set nocount on

print 'Loading GDN/GDD/GDV data for data_name ''world_scale_values'' ...'
go

declare @gdn_num      int,
        @gdd_num      int
		
if not exists (select * from generic_data_name
               where data_name = 'world_scale_values')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'world_scale_values', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'world_scale_values'
end

select @gdd_num = isnull(max(gdd_num), 0)
from dbo.generic_data_definition

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'world_scale_values', 'world_scale_code', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'world_scale_values', 'from_date', 3, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'world_scale_values', 'to_date', 3, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'world_scale_values', 'ws_percentage', 2, 1)

print 'All data items for data name ''world_scale_values'' were loaded ...'

endofscript:
go

exec dbo.refresh_a_last_num 'generic_data_name', 'gdn_num'
go
exec dbo.refresh_a_last_num 'generic_data_definition', 'gdd_num'
go
exec dbo.refresh_a_last_num 'generic_data_values', 'gdv_num'
go

