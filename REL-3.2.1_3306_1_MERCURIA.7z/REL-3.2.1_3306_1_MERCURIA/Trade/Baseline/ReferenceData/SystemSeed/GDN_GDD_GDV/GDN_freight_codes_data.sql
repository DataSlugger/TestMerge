/* ********************************************************
    GENERIC DATA SET: freight_codes
   ******************************************************** */

set nocount on

print 'Loading GDN/GDD/GDV data for data_name ''freight_codes'' ...'
go

declare @gdn_num     int,
        @gdd_num     int

if not exists (select * from generic_data_name
               where data_name = 'freight_codes')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'freight_codes', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'freight_codes'
end

select @gdd_num = isnull(max(gdd_num), 0)
from dbo.generic_data_definition

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'freight_codes', 'commkt_key', 1, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'freight_codes', 'nbv_mkt_code', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'freight_codes', 'world_scale_code', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'freight_codes', 'flat_rate_code', 4, 1)

print 'All data items for data name ''freight_codes'' were loaded ...'

endofscript:
go

exec dbo.refresh_a_last_num 'generic_data_name', 'gdn_num'
go
exec dbo.refresh_a_last_num 'generic_data_definition', 'gdd_num'
go
exec dbo.refresh_a_last_num 'generic_data_values', 'gdv_num'
go
