/* ********************************************************
    GENERIC DATA SET: pipeline cycle year
   ******************************************************** */

set nocount on

print 'Loading GDN/GDD/GDV data for data_name ''pipeline cycle year'' ...'
go

declare @gdn_num int,
        @gdd_num int

select @gdn_num = null,
       @gdd_num = null

if not exists (select 1 
               from generic_data_name
               where data_name = 'pipeline cycle year')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'pipeline cycle year', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'pipeline cycle year'
end

/* =================================================================
    Adding the following attributes into the generic_data_definition
    table:

        attr_name             data_type_ind
        --------------------- -------------
        year_num              1
   =================================================================
*/

print '==> adding attributes into generic_data_definition table ..'

/* ***** ATTRIBUTE #1: year_num ***** */

if not exists (select 1 
               from generic_data_definition
               where gdn_num = @gdn_num and
                     attr_name = 'year_num')
begin
   select @gdd_num = max(gdd_num)
   from generic_data_definition

   if @gdd_num is null
      select @gdd_num = 1
   else
      select @gdd_num = @gdd_num + 1

   insert into generic_data_definition
   values(@gdd_num, @gdn_num, 'pipeline cycle year', 'year_num', 1, 1)
end


print '==> adding attribute values into generic_data_values table ..'
go

declare @gdd_num1 int,
        @gdv_num  int,
        @gdn_num  int

select @gdd_num1 = null,
       @gdv_num = null,
       @gdn_num = null

if exists (select 1 
           from generic_data_name
           where data_name = 'pipeline cycle year')
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'pipeline cycle year'
end

if @gdn_num is null
begin
   print 'Failed to find the data name ''pipeline cycle year''!'
   goto endofscript
end

/* attribute #1 */
if exists (select 1 
           from generic_data_definition
           where gdn_num = @gdn_num and
                 attr_name = 'year_num')
begin
   select @gdd_num1 = gdd_num
   from generic_data_definition
   where gdn_num = @gdn_num and
         attr_name = 'year_num'
end

if @gdd_num1 is null
begin
   print 'One or some of attributes for data name ''pipeline cycle year'' are missing!'
   goto endofscript
end 


/* --------------------------------------------------------------------------------
    Adding attribute values into the generic_data_values table:
    
      GDV #   [ATTRIBUTE NAME]   ...
              (string_value)
      ------- -----------------  ...
      +1      [ATTRIBUTE VALUE]  ...
      ...           
   ------------------------------------------------------------------------------ */

/* ----------------------------------------------- 
   GDV row #1 

      GDV row #     year_num       
      ------------  -------------------  
      max(gdv)+1    2003
   ----------------------------------------------- */

select @gdv_num = null
select @gdv_num = gdv_num
from generic_data_values
where int_value = 2003 and
      gdd_num = @gdd_num1

if @gdv_num is null
begin
   select @gdv_num = max(gdv_num)
   from generic_data_values

   if @gdv_num is null
      select @gdv_num = 1
   else
      select @gdv_num = @gdv_num + 1
end

if not exists (select 1
               from generic_data_values
               where gdv_num = @gdv_num and
                     gdd_num = @gdd_num1)   
begin
   insert into generic_data_values
     (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
   values(@gdv_num, @gdd_num1, 2003, null, null, null, 1)
end

/* ----------------------------------------------- 
   GDV row #2 

      GDV row #     year_num       
      ------------  ------------------- 
      max(gdv)+2    2004  
   ----------------------------------------------- */

select @gdv_num = null
select @gdv_num = gdv_num
from generic_data_values
where int_value = 2004 and
      gdd_num = @gdd_num1

if @gdv_num is null
begin
   select @gdv_num = max(gdv_num)
   from generic_data_values

   if @gdv_num is null
      select @gdv_num = 1
   else
      select @gdv_num = @gdv_num + 1
end

if not exists (select 1
               from generic_data_values
               where gdv_num = @gdv_num and
                     gdd_num = @gdd_num1)   
begin
   insert into generic_data_values
     (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
   values(@gdv_num, @gdd_num1, 2004, null, null, null, 1)
end

/* ----------------------------------------------- 
   GDV row #3 

      GDV row #     year_num       
      ------------  ------------------- 
      max(gdv)+3    2005  
   ----------------------------------------------- */

select @gdv_num = null
select @gdv_num = gdv_num
from generic_data_values
where int_value = 2005 and
      gdd_num = @gdd_num1

if @gdv_num is null
begin
   select @gdv_num = max(gdv_num)
   from generic_data_values

   if @gdv_num is null
      select @gdv_num = 1
   else
      select @gdv_num = @gdv_num + 1
end

if not exists (select 1
               from generic_data_values
               where gdv_num = @gdv_num and
                     gdd_num = @gdd_num1)   
begin
   insert into generic_data_values
     (gdv_num, gdd_num, int_value, double_value, datetime_value, string_value, trans_id)
   values(@gdv_num, @gdd_num1, 2005, null, null, null, 1)
end

print 'All data items for data name ''pipeline cycle year'' were loaded ...'

endofscript:
go

exec dbo.refresh_a_last_num 'generic_data_name', 'gdn_num'
go
exec dbo.refresh_a_last_num 'generic_data_definition', 'gdd_num'
go
exec dbo.refresh_a_last_num 'generic_data_values', 'gdv_num'
go
