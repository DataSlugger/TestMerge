/* ********************************************************
    GENERIC DATA SET: market_costs_nbvi
   ******************************************************** */

set nocount on

print 'Loading GDN/GDD/GDV data for data_name ''market_costs_nbvi'' ...'
go

declare @gdn_num      int,
        @gdd_num      int

if not exists (select * from generic_data_name
               where data_name = 'market_costs_nbvi')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'market_costs_nbvi', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'market_costs_nbvi'
end

select @gdd_num = isnull(max(gdd_num), 0)
from dbo.generic_data_definition

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'market_costs_nbvi', 'commkt_key', 1, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'market_costs_nbvi', 'nbv_mkt_code', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'market_costs_nbvi', 'cost_name', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'market_costs_nbvi', 'cost_amt', 2, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'market_costs_nbvi', 'cost_curr_code', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'market_costs_nbvi', 'cost_uom_code', 4, 1)

print 'All data items for data name ''market_costs_nbvi'' were loaded ...'

endofscript:
go

exec dbo.refresh_a_last_num 'generic_data_name', 'gdn_num'
go
exec dbo.refresh_a_last_num 'generic_data_definition', 'gdd_num'
go
exec dbo.refresh_a_last_num 'generic_data_values', 'gdv_num'
go
