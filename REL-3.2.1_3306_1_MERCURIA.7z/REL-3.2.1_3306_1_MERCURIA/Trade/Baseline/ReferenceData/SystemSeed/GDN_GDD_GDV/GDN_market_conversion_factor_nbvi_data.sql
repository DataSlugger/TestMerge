/* ********************************************************
    GENERIC DATA SET: nbvi_conversion_factor
   ******************************************************** */

set nocount on

print 'Loading GDN/GDD/GDV data for data_name ''nbvi_conversion_factor'' ...'
go

declare @gdn_num      int,
        @gdd_num      int

if not exists (select * from generic_data_name
               where data_name = 'nbvi_conversion_factor')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'nbvi_conversion_factor', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'nbvi_conversion_factor'
end

select @gdd_num = isnull(max(gdd_num), 0)
from dbo.generic_data_definition

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'nbvi_conversion_factor', 'commkt_key', 1, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'nbvi_conversion_factor', 'conversion_type_ind', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'nbvi_conversion_factor', 'from_code', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'nbvi_conversion_factor', 'to_code', 4, 1)

print 'All data items for data name ''nbvi_conversion_factor'' were loaded ...'

endofscript:
go

exec dbo.refresh_a_last_num 'generic_data_name', 'gdn_num'
go
exec dbo.refresh_a_last_num 'generic_data_definition', 'gdd_num'
go
exec dbo.refresh_a_last_num 'generic_data_values', 'gdv_num'
go

