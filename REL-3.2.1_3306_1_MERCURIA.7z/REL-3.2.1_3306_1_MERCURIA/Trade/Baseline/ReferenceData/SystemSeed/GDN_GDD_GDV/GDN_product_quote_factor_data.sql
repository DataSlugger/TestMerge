/* ********************************************************
    GENERIC DATA SET: product_quote_factor
   ******************************************************** */

set nocount on

print 'Loading GDN/GDD/GDV data for data_name ''product_quote_factor'' ...'
go

declare @gdn_num      int,
        @gdd_num      int
		
if not exists (select * from generic_data_name
               where data_name = 'product_quote_factor')
begin
   select @gdn_num = max(gdn_num)
   from generic_data_name

   if @gdn_num is null
      select @gdn_num = 1
   else
      select @gdn_num = @gdn_num + 1
   
   insert into generic_data_name 
   values(@gdn_num, 'product_quote_factor', 1)
end
else
begin
   select @gdn_num = gdn_num 
   from generic_data_name
   where data_name = 'product_quote_factor'
end

select @gdd_num = isnull(max(gdd_num), 0)
from dbo.generic_data_definition

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'product_quote_factor', 'product_cmdty_code', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'product_quote_factor', 'nbv_mkt_code', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'product_quote_factor', 'from_date', 3, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'product_quote_factor', 'to_date', 3, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'product_quote_factor', 'quote_commkt_key', 1, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'product_quote_factor', 'quote_price_source_code', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'product_quote_factor', 'quote_trading_period', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'product_quote_factor', 'quote_price_type', 4, 1)

select @gdd_num = @gdd_num + 1
insert into generic_data_definition (gdd_num, gdn_num, data_name, attr_name, data_type_ind, trans_id)
values(@gdd_num, @gdn_num, 'product_quote_factor', 'quote_percentage', 2, 1)

print 'All data items for data name ''product_quote_factor'' were loaded ...'

endofscript:
go

exec dbo.refresh_a_last_num 'generic_data_name', 'gdn_num'
go
exec dbo.refresh_a_last_num 'generic_data_definition', 'gdd_num'
go
exec dbo.refresh_a_last_num 'generic_data_values', 'gdv_num'
go

