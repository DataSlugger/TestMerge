set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table alias_source
go

print 'Loading startup seed reference data into the alias_source table ...'
go

insert into dbo.alias_source 
   values('APPI', 'x', 'ASIAN PAC. PETR. INDEX', 1)
go

insert into dbo.alias_source 
   values('BSI', 'X', 'BSI FEED', 1)
go

insert into dbo.alias_source 
   values('DEWITT', 'X', 'DEWITT', 1)
go

insert into dbo.alias_source 
   values('DRI', 'X', 'DRI', 1)
go

insert into dbo.alias_source 
   values('OPIS', 'X', 'OPIS', 1)
go

insert into dbo.alias_source 
   values('PS1', 'X', 'Price Source 1', 1)
go

insert into alias_source
  (alias_source_code,alias_source_type,alias_source_desc, trans_id)
  values('LOGO', 'X', 'Filename of company logo', 1)
go

insert into alias_source
  (alias_source_code,alias_source_type,alias_source_desc, trans_id)
  values('MATERIAL', 'X', 'SAP Commodity code', 1)
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'TIFEED')
   insert alias_source values ('TIFEED','X','TI Feed',1)
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'POMAX')              
   insert into dbo.alias_source
        (alias_source_code, alias_source_type, alias_source_desc, trans_id)
     values ('POMAX', 'X', 'Symphony Pomax Interface', 1)
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'ISO')              
   insert into dbo.alias_source
        (alias_source_code, alias_source_type, alias_source_desc, trans_id)
     values ('ISO', 'X', 'ISO Codes', 1)
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'PETROMAN')              
   insert into dbo.alias_source
        (alias_source_code, alias_source_type, alias_source_desc, trans_id) 
     values('PETROMAN', 'X', 'Petroman Feed', 1)
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'RCLCITEM')              
   insert into dbo.alias_source
        (alias_source_code, alias_source_type, alias_source_desc, trans_id) 
     values('RCLCITEM', 'X', 'CostCodes allowed as RC/LC items', 1)
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'EIPPSTTL')              
   insert into dbo.alias_source
        (alias_source_code, alias_source_type, alias_source_desc, trans_id) 
     values('EIPPSTTL', 'X', 'EIPP settlement', 1)
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'EIPP')              
   insert into dbo.alias_source
        (alias_source_code, alias_source_type, alias_source_desc, trans_id) 
     values('EIPP', 'X', 'EIPP voucher', 1)
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'PEICOMP')              
   insert into dbo.alias_source
        (alias_source_code, alias_source_type, alias_source_desc, trans_id) 
     values('PEICOMP', 'X', 'EIPP BCId', 1)
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'CUSTOMER')              
   insert into dbo.alias_source
        (alias_source_code, alias_source_type, alias_source_desc, trans_id) 
     values('CUSTOMER', 'X', 'EIPP CptyId', 1)
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'CUSTOMER')              
   insert into dbo.alias_source
        (alias_source_code, alias_source_type, alias_source_desc, trans_id) 
      values('ASSAYLKR', 'X', 'Assay Locker', 1)
go
