set nocount on

set QUOTED_IDENTIFIER ON
go

print ' '
print 'Loading seed reference data into the uic_rpt_criteria table ...'
go

create table #report_criteria
(
   oid	                     numeric(18, 0) IDENTITY PRIMARY KEY,
   report_type	             varchar(50)	  null,
   criteria_desc	           varchar(50)	  null,
   display_entity_name	     varchar(30)	  null, 
   display_value_selector	   varchar(50)	  null,  
   report_value_selector	   varchar(50)	  null  
)

/* UIC REPORT TYPE
     oid  report_type
     ---  ------------------------
       1  Trade Entry
       2  Non-trade costs
       3  Allocation
       4  Vouchers
       5  All Entities
*/

/* ------------------------------------------------------------
     report_type - 'Allocation'
   ------------------------------------------------------------ */
insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Allocation', 'Allocation Item', NULL, NULL, NULL)

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Allocation', 'Allocation Number', NULL, NULL, NULL)
  
insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Allocation', 'MOT / Carrier', 'Mot', 'motShortName', 'motFullName')

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Allocation', 'Credit Approved For Loading', 'AllocationItem', 'okToLoadInd', 'okToLoadInd')

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Allocation', 'Shipment Number', NULL, NULL, NULL)

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Allocation', 'Parcel Number', NULL, NULL, NULL)


/* ------------------------------------------------------------
     report_type - 'Non-trade costs'
   ------------------------------------------------------------ */

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Non-trade costs', 'Booking company', 'Account', 'acctShortName', 'acctFullName')

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Non-trade costs', 'Cost Code/Commodity', 'Commodity', 'cmdtyShortName', 'cmdtyFullName')

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Non-trade costs', 'Counterparty', 'Account', 'acctShortName', 'acctFullName')
 
insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Non-trade costs', 'Due Date', NULL, NULL, NULL)
 
insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Non-trade costs', 'Portfolio', 'Portfolio', 'portShortName', 'portFullName')
 
 
/* ------------------------------------------------------------
     report_type - 'Trade Entry'
   ------------------------------------------------------------ */

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Trade Entry', 'Booking company', 'Account', 'acctShortName', 'acctFullName')

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Trade Entry', 'Commodity', 'Commodity', 'cmdtyShortName', 'cmdtyFullName')
 
insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Trade Entry', 'Contract date', NULL, NULL, NULL)

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Trade Entry', 'Counterparty', 'Account', 'acctShortName', 'acctFullName')
 
insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Trade Entry', 'Creation Date', NULL, NULL, NULL)

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Trade Entry', 'Custom Contract Number', NULL, NULL, NULL)
  
insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Trade Entry', 'delivery period', NULL, NULL, NULL)

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Trade Entry', 'MOT/Carrier', 'Mot', 'motShortName', 'motFullName')
 
insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Trade Entry', 'Real Portfolio', 'Portfolio', 'portShortName', 'portFullName')

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Trade Entry', 'Trading period', NULL, NULL, NULL)
 
insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Trade Entry', 'Credit Approved', 'TradeItem', 'okToLoadInd', 'okToLoadInd')
  
/* ------------------------------------------------------------
     report_type - 'Vouchers'
   ------------------------------------------------------------ */

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Vouchers', 'Booking Company', 'Account', 'acctShortName', 'acctFullName')

insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Vouchers', 'Counterparty', 'Account', 'acctShortName', 'acctFullName')
 
insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Vouchers', 'Custom Voucher Number', NULL, NULL, NULL)
 
insert into #report_criteria
    (report_type, criteria_desc, display_entity_name, display_value_selector, report_value_selector)
   values ('Vouchers', 'Voucher Due Date', NULL, NULL, NULL)
 
 


declare @oid                       numeric(18, 0),
        @newoid                    int,
        @report_type	             varchar(50),
        @criteria_desc	           varchar(50),
        @display_entity_name	     varchar(30), 
        @display_value_selector	   varchar(50),  
        @report_value_selector	   varchar(50),
        @report_type_id            int,
        @entity_id                 int,
        @errcode                   int,
        @errmsg                    varchar(255)
        
select @errcode = 0
select @oid = min(oid)
from #report_criteria

while @oid is not null
begin
   select @report_type	= report_type,
          @criteria_desc = criteria_desc,
          @display_entity_name = display_entity_name, 
          @display_value_selector = display_value_selector,  
          @report_value_selector = report_value_selector
   from #report_criteria
   where oid = @oid
   
   select @report_type_id = oid
   from dbo.uic_report_type
   where report_type = @report_type
   
   if @report_type_id is null
   begin
      select @errmsg = 'Could not find the report type ''' + @report_type + ''' in the uic_report_type table!'
      print @errmsg
      goto nextoid
   end

   select @entity_id = null
   if @display_entity_name is not null
   begin
      select @entity_id = oid
      from dbo.icts_entity_name
      where entity_name = @display_entity_name

      if @entity_id is null
      begin
         select @errmsg = 'Could not find the entity ''' + @display_entity_name + '''!'
         print @errmsg
         goto nextoid
      end
   end

   if not exists (select 1
                  from dbo.uic_rpt_criteria
                  where report_type_id = @report_type_id and
                        criteria_desc = @criteria_desc)
   begin
      select @newoid = null
      select @newoid = isnull(max(oid), 0) + 1
      from dbo.uic_rpt_criteria
      
      if @newoid is null
      begin
         print 'Failed to obtain a new oid for a new uic_rpt_criteria entry!'
         goto endofscript
      end

      insert into dbo.uic_rpt_criteria
         values(@newoid, @report_type_id, @criteria_desc, @entity_id, 
                @display_value_selector, @report_value_selector, 1)
      select @errcode = @@error
      if @errcode > 0
         goto endofscript
   end
   
nextoid:
   select @oid = min(oid)
   from #report_criteria
   where oid > @oid
end
endofscript:
drop table #report_criteria
go

exec refresh_a_last_num 'uic_rpt_criteria', 'oid'
go
