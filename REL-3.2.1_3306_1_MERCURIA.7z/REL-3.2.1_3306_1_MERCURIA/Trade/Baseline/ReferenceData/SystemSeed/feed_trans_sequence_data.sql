set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the feed_trans_sequence table ...'
go

if not exists (select 1
               from dbo.feed_trans_sequence
               where oid = 1)
   insert into dbo.feed_trans_sequence (oid, last_num)
      values(1, 0)
go

