set nocount on

set QUOTED_IDENTIFIER ON
go

print '=> Inserting entity tag records for the entity tag ''IsBunkerCommkt'' If not Exists!'
go

create table #commktToTag (commktKey int, etKey int identity(1,1))

	insert into #commktToTag
	select commkt_key 
	from dbo.commodity_market
	where cmdty_code = 'HSFO180' and 
	      mkt_code in ('SINGAPOR', 'SINGCARG', 'SINGDLVD', 'SINGEXWH')
	union
	select commkt_key 
	from dbo.commodity_market
	where cmdty_code = 'HSFO380' and 
	      mkt_code in ('FORMOSA','FUJAIRAH','HDGLTERM','MNEXWHF','SINGAPOR','SINGCARG','SINGDLVD','SINGEXWH')
	union 
	select commkt_key 
	from dbo.commodity_market
	where cmdty_code = 'LSFO' and 
	      mkt_code in ('SINGCARG','ROTTERDM')
	union
	select commkt_key 
	from dbo.commodity_market
	where cmdty_code = 'NO6FN30' and 
	      mkt_code in ('USGC3%')
	union
	select commkt_key 
	from dbo.commodity_market
	where cmdty_code = 'MDO' and 
	      mkt_code in ('LSGC')
	union
	select commkt_key 
	from dbo.commodity_market
	where cmdty_code = 'GASOIL' and 
	      mkt_code in ('IPE','SINGAPOR')
	union 
	select commkt_key 
	from dbo.commodity_market
	where cmdty_code = 'LSGO' and 
	      mkt_code in ('HDGLTERM','IPE','SINGDLVD')
	union
	select commkt_key 
	from dbo.commodity_market
	where cmdty_code = 'MGO' and 
	      mkt_code in ('HDGLTERM','SINGAPOR','SINGDLVD')
go	

declare @entity_tag_id int,
        @oid int,
        @transId int,
		    @errcode int,
        @rows_affected int,
        @minCommktKey int, 
		    @etKey int
            
select @entity_tag_id = oid 
from dbo.entity_tag_definition 
where entity_tag_name = 'IsBunkerCommkt'

if @entity_tag_id is null
begin
	 print '=> No entity tag exists as ''IsBunkerCommkt'' in the entity_tag_definition table'
	 goto endofscript
end

if not exists (select 1 
               from dbo.entity_tag 
               where entity_tag_id = @entity_tag_id and 
                     key1 in (select commkt_key 
                              from dbo.commodity_market
	                            where cmdty_code = 'HSFO180' and 
	                                  mkt_code in ('SINGAPOR', 'SINGCARG', 'SINGDLVD', 'SINGEXWH')))	
begin
 	 exec dbo.gen_new_transaction_NOI @app_name = 'ADSO-2109'
	 select @transId = last_num 
	 from dbo.icts_trans_sequence 
	 where oid = 1	

	 select @etKey = isnull(max(entity_tag_key),0) + 1 
	 from dbo.entity_tag

	 insert into dbo.entity_tag
		  (entity_tag_key,
       entity_tag_id,
       key1,
       target_key1,
       trans_id)
	 select @etKey + etKey, 
		      @entity_tag_id, 
		      convert(varchar(17), commktKey), 
		      'YES',
		      @transId
	 from #commktToTag
end
else
   print '=> No rows found to be added on the entity_tag table'

endofscript:
drop table #commktToTag
go

exec dbo.refresh_a_last_num 'entity_tag', 'entity_tag_key'
go
