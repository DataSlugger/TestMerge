set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Adding entity_tag records for ''CmdtyLotSize'' and ''CmdtyLotUom'' (Commodity) ...'
go

declare @entity_id           int,
        @entity_tag_id1      int,
        @entity_tag_id2      int,
        @newoid              int,
        @errcode             int,
        @rows_added          int,
        @total_rows_added    int

select @errcode = 0,
       @total_rows_added = 0

select @entity_id = oid 
from dbo.icts_entity_name 
where entity_name = 'Commodity'

if @entity_id is null
begin
   print 'Could not find the entity ''Commodity'' in the icts_entity_name table!'
   goto endofscript
end

select @entity_tag_id1 = oid 
from dbo.entity_tag_definition
where entity_tag_name = 'CmdtyLotSize' and
      entity_id = @entity_id

if @entity_tag_id1 is null
begin
   print 'Could not find the entity tag ''CmdtyLotSize'' in the entity_tag_definition table for the entity ''Commodity''!'
   goto endofscript
end

select @entity_tag_id2 = oid 
from dbo.entity_tag_definition
where entity_tag_name = 'CmdtyLotUom' and
      entity_id = @entity_id

if @entity_tag_id2 is null
begin
   print 'Could not find the entity tag ''CmdtyLotUom'' in the entity_tag_definition table for the entity ''Commodity''!'
   goto endofscript
end

if not exists (select 1
               from dbo.entity_tag
               where entity_tag_id = @entity_tag_id1 and
                     key1 = 'NATGAS' and
                     target_key1 = '2500')
begin
   begin tran
   select @newoid = isnull(max(entity_tag_key), 0) + 1
   from dbo.entity_tag

   insert entity_tag 
        (entity_tag_key, entity_tag_id, key1, target_key1, trans_id)
      values (@newoid, @entity_tag_id1, 'NATGAS', '2500', 1)
   select @rows_added = @@rowcount,
          @errcode = @@error
   if @errcode > 0 or @rows_added = 0
   begin
      rollback tran
      if @errcode > 0
         goto endofscript
   end
   else
   begin
      commit tran
      select @total_rows_added = @total_rows_added + @rows_added   
      print '=> entity_tag: Added a record (NATGAS/2500) for the entity tag ''CmdtyLotSize''!'
   end
end
   

if not exists (select 1
               from dbo.entity_tag
               where entity_tag_id = @entity_tag_id2 and
                     key1 = 'NATGAS' and
                     target_key1 = 'MMBT')
begin
   begin tran
   select @newoid = isnull(max(entity_tag_key), 0) + 1
   from dbo.entity_tag

   insert entity_tag 
        (entity_tag_key, entity_tag_id, key1, target_key1, trans_id)
      values (@newoid, @entity_tag_id2, 'NATGAS', 'MMBT', 1)
   select @rows_added = @@rowcount,
          @errcode = @@error
   if @errcode > 0 or @rows_added = 0
   begin
      rollback tran
      if @errcode > 0
         goto endofscript
   end
   else
   begin
      commit tran
      select @total_rows_added = @total_rows_added + @rows_added   
      print '=> entity_tag: Added a record (NATGAS/MMBT) for the entity tag ''CmdtyLotUom''!'
   end
end
endofscript:
go

exec set_last_nums 0
go
