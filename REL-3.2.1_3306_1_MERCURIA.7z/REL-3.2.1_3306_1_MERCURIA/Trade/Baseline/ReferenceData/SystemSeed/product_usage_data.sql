set nocount on

set QUOTED_IDENTIFIER ON
go


truncate table product_usage
go

print 'Loading seed reference data into the product_usage table ...'
go

insert into dbo.product_usage 
   values('BLEND', 'Blend', 1)
go

insert into dbo.product_usage 
   values('GOV', 'Government', 1)
go

insert into dbo.product_usage 
   values('STD', 'Standard Usage', 1)
go

