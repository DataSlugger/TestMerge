set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the pcg_type table ...'
go

if NOT EXISTS (select *
               from dbo.pcg_type
               where pcg_type_code = 'Time' and 
	                   pcg_type_short_name = 'Time Based' and 
		                 pcg_type_desc = 'PCG Time Based')
   insert into dbo.pcg_type
        (pcg_type_code, pcg_type_short_name, pcg_type_desc, trans_id)
      values ('Time','Time Based','PCG Time Based',1)
go

if NOT EXISTS (select *
               from dbo.pcg_type
               where pcg_type_code = 'Quantity' and 
	                   pcg_type_short_name = 'Quantity Based' and 
		                 pcg_type_desc = 'PCG Quantity Based')
   insert into dbo.pcg_type
        (pcg_type_code, pcg_type_short_name, pcg_type_desc, trans_id)
      values ('Quantity','Quantity Based','PCG Quantity Based',1)
go
