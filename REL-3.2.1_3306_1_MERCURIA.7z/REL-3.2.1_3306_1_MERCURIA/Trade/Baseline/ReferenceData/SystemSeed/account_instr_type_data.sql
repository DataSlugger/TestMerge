set nocount on

set QUOTED_IDENTIFIER ON
go

print ' '
print 'Loading seed reference data into the account_instr_type table ...'
go

if not exists (select 1
               from dbo.account_instr_type
               where acct_instr_type_code = 'CONTRACT')
   insert into dbo.account_instr_type 
       (acct_instr_type_code, acct_instr_type_desc, trans_id)
     values('CONTRACT', 'Instruction type for contract', 1)
go

if not exists (select 1
               from dbo.account_instr_type
               where acct_instr_type_code = 'INVOICE')
   insert into dbo.account_instr_type 
       (acct_instr_type_code, acct_instr_type_desc, trans_id)
     values('INVOICE', 'Instruction type for invoicing', 1)
go

if not exists (select 1
               from dbo.account_instr_type
               where acct_instr_type_code = 'CONFIRM')
   insert into dbo.account_instr_type 
       (acct_instr_type_code, acct_instr_type_desc, trans_id)
     values('CONFIRM', 'Used by AutoConfirm to send confirmation', 1)
go

if not exists (select 1
               from dbo.account_instr_type
               where acct_instr_type_code = 'OTCINV')
   insert into dbo.account_instr_type 
       (acct_instr_type_code, acct_instr_type_desc, trans_id)
     values('OTCINV', 'Instruction type for OTC invoicing', 1)
go

if not exists (select 1
               from dbo.account_instr_type
               where acct_instr_type_code = 'BANK')
   insert into dbo.account_instr_type 
       (acct_instr_type_code, acct_instr_type_desc, trans_id)
     values('BANK', 'Bank Instruction Contact', 1)
go

if not exists (select 1
               from dbo.account_instr_type
               where acct_instr_type_code = 'S_OFFICE')
   insert into dbo.account_instr_type 
       (acct_instr_type_code, acct_instr_type_desc, trans_id)
     values('S_OFFICE', 'Booking Company Selling Office Address', 1)
go

if not exists (select 1
               from dbo.account_instr_type
               where acct_instr_type_code = 'NOMIN')
   insert into dbo.account_instr_type 
       (acct_instr_type_code, acct_instr_type_desc, trans_id)
     values('NOMIN', 'Instr. type for Nomin. Document Creation', 1)
go

if not exists (select 1
               from dbo.account_instr_type
               where acct_instr_type_code = 'OPERATOR')
   insert into dbo.account_instr_type 
       (acct_instr_type_code, acct_instr_type_desc, trans_id)
     values('OPERATOR', 'OPERATOR', 1)
go

if not exists (select 1
               from dbo.account_instr_type
               where acct_instr_type_code = 'FCLYOPER')
   insert into dbo.account_instr_type 
       (acct_instr_type_code, acct_instr_type_desc, trans_id)
     values('FCLYOPER', 'Facility Operator', 1)
go


CREATE TABLE #acc_in_type_1349076
(
   acct_instr_type_code	char(8) NOT NULL,
   acct_instr_type_desc	varchar(40)	         
)
go

INSERT INTO #acc_in_type_1349076
     (acct_instr_type_code, acct_instr_type_desc)
select 'CONTRACT', 'Instruction type for contract'
union
select 'INVOICE', 'Instruction type for invoicing'
union
select 'CONFIRM', 'Used by AutoConfirm to send confirmation'
union
select 'OTCINV', 'Instruction type for OTC invoicing'
union
select 'BANK', 'Bank Instruction Contact'
union
select 'S_OFFICE', 'Booking Company Selling Office Address'
union
select 'NOMIN', 'Instr. type for Nomin. Document Creation'
union
select 'OPERATOR', 'OPERATOR'
union
select 'FCLYOPER', 'Facility Operator'
go

INSERT INTO #acc_in_type_1349076
     (acct_instr_type_code, acct_instr_type_desc)
select 'CONF_PHY','Physical Confirm'
union
select 'CONF_BIO','BioDiesel Confirm'
union
select 'CONF_B&R','BioDiesel with RINS Confirm'
union
select 'CONF_RIN','RINS Confirm'
union
select 'CONF_SWL','Swap Confirmation Long'
union
select 'CONF_SWS','Swap Confirmation Short'
union
select 'CONF_OPL','Option Confirm Long'
union
select 'CONF_OPS','Option Confirm Short'
union
select 'CONF_PYL','Physical Confirm Long'
union
select 'INV_BIO','Biofuels Invoice'
union
select 'INV_OPM','Option Premium Invoice'
union
select 'INV_OTC','OTC Financial Trade Invoice'
union
select 'INV_PP','Physical Pipe Invoice'
union
select 'INV_PNP','Physical Non Pipe Invoice'
union
select 'INV_SEC','Secondary Cost Invoice'
go


Declare @acct_instr_type_code char(8),
		    @acct_instr_type_desc varchar(40),
        @errcode              int
        
set @errcode = 0

select @acct_instr_type_code = min(acct_instr_type_code)
from #acc_in_type_1349076

while @acct_instr_type_code is not null
begin
   select @acct_instr_type_desc = acct_instr_type_desc
   from #acc_in_type_1349076
   where acct_instr_type_code = @acct_instr_type_code
   
   if not exists (select 1
                  from dbo.account_instr_type
                  where acct_instr_type_code = @acct_instr_type_code)
   begin
      begin try
        insert into dbo.account_instr_type 
             (acct_instr_type_code, acct_instr_type_desc, trans_id)
           values(@acct_instr_type_code, @acct_instr_type_desc, 1)
      end try
      begin catch
        print '=> Failed to add a new contract status due to the error:'
        print '==> ERROR: ' + ERROR_MESSAGE()
        set @errcode = ERROR_NUMBER()
        goto endofscript
      end catch
      print '=> acct_instr_type_code ''' + @acct_instr_type_code + ''' was added successfully!'
   end 
    
   select @acct_instr_type_code = min(acct_instr_type_code)
   from #acc_in_type_1349076 
   where acct_instr_type_code > @acct_instr_type_code   
end   
   
endofscript:
drop table #acc_in_type_1349076
go
