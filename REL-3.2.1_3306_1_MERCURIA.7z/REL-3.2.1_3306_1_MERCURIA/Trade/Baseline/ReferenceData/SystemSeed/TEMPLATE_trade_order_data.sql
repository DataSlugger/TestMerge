set nocount on

set QUOTED_IDENTIFIER ON
go

print '=> Adding a TEMPLATE trade_order record ...'
go

if not exists (select 1
               from dbo.trade_order
               where trade_num = 0 and
                     order_num = 0)
begin
   insert into dbo.trade_order
         (trade_num, order_num, strip_summary_ind, trans_id)
      values(0, 0, 'N', 1)
end
go
