set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the function_action table ...'
go

CREATE TABLE #function_action
(   
   oid			        int		NOT NULL PRIMARY KEY,
   function_num			int		NOT NULL,
   action_name			varchar(255)	NULL,
   action_type			varchar(40)	NULL,
)
go

print '=> Saving records into the temp table ...'
INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(1,602,'OpenPanelCommand',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(2,3200,'CreateNewShipment',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(3,3200,'AddParcel','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(4,3201,'AddParcel','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(5,3206,'RemoveActual',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(6,3200,'SaveShipment','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(7,3201,'SaveShipment','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(8,606,'ApproveCost',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(9,3203,'CancelShipment',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(10,3200,'UnAttachParcel','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(11,3201,'UnAttachParcel','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(12,3204,'CreateParcel',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(13,3200,'AddAllocationChain','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(14,3201,'AddAllocationChain','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(15,3200,'AddShipmentMot','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(16,3201,'AddShipmentMot','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(17,3200,'AddTransportAgreement','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(18,3201,'AddTransportAgreement','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(19,3200,'RemoveTransportAgreement','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(20,3201,'RemoveTransportAgreement','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(21,3200,'AddShipmentPath','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(22,3201,'AddShipmentPath','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(23,3200,'AddShipmentsToChain','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(24,3201,'AddShipmentsToChain','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(25,3200,'RemoveShipmentsFromChain','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(26,3201,'RemoveShipmentsFromChain','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(27,3200,'ClearShipmentChain','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(28,3201,'ClearShipmentChain','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(29,3200,'AddCost','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(30,3201,'AddCost','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(31,3202,'FinalizeShipment',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(32,3204,'SaveParcel','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(33,3205,'SaveParcel','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(34,3207,'CancelParcel',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(35,3204,'LinkTrade','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(36,3205,'LinkTrade','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(37,3206,'CreateActual',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(38,3204,'AddLcAssignments','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(39,3205,'AddLcAssignments','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(40,3204,'RemoveLcAssignments','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(41,3205,'RemoveLcAssignments','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(42,3204,'AddCost','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(43,3205,'AddCost','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(44,3204,'AddQualitySlate','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(45,3205,'AddQualitySlate','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(46,3204,'RemoveQualitySlate','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(47,3205,'RemoveQualitySlate','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(48,602,'OpenMultipleWorkspace',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(49,602,'OpenWorkSpaceCommand',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(50,602,'OpenOptionsCommand',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(51,602,'OpenShipmentManagementPanel',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(52,602,'NewWindowCommand',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(53,3200,'CopyCost','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(54,3201,'CopyCost','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(55,602,'DelinkCost',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(56,2,'CreateNewTransportAgreement','Modify')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(57,607,'AddNewCostItem','Add')
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(58,3210,'AddNewCostTemplate',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(59,3210,'AddToNewCostTemplateGroup',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(60,3213,'AddNewFacility',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(61,3213,'AddNewFacilityType',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(62,3213,'AddNewPath',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(63,3213,'AddFacilityLink',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(64,3210,'AddToTemplate',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(65,3212,'DeleteCostEqualizationRate',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(66,3212,'DeleteCostRate',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(67,3210,'AddCostItems',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(68,3210,'AddCostTemplateCounterParties',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(69,3210,'AddToTemplateGroup',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(70,3210,'AddNewCostItem',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(71,3216,'AddNewCostItem',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(72,3213,'AddSegments',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(73,3212,'DeleteCostItem',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(74,3212,'DeleteCost',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(75,3212,'DeleteCostTemplate',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(76,3212,'DeleteCostTemplateGroup',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(77,3215,'DeleteFacility',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(78,3215,'DeleteFacilityType',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(79,3215,'DeletePath',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(80,3215,'DeleteSegment',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(81,3216,'AddNewCostCode',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(82,3210,'AddNewCostRate',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(83,3210,'AddNewCostEqualizationRate',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(84,3210,'AddRealCostToTemplate',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(85,3212,'DeleteCostTemplateItem',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(86,3212,'DeleteCostTemplateGroupItem',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(87,3204,'AddCmdtySpecs',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(88,3205,'AddCmdtySpecs',NULL)

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(89,3204,'AddSpecTests',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(90,3205,'AddSpecTests',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(91,3213,'AddNewSegment',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(92,3208,'ModifySharedSearch',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(93,3209,'ModifySharedLayout',NULL)
go

INSERT INTO #function_action(oid,function_num,action_name,action_type)
VALUES(94, 3224, 'SetUpNewTransport', 'Add')
go

print '=> Moving records from temp table to the function_action table ...'
go


/* ********************************************************************* */
/* The code body for adding records into the function_action table       */
/* ********************************************************************* */

declare @oid                 int,
        @newoid              int,
        @function_num	       int,
        @row_affected        int,
        @smsg                varchar(255),
        @action_name			   varchar(255),
        @action_type			   varchar(40)
                
select @oid = min(oid)
from #function_action

while @oid is not null
begin
	 select @function_num = function_num,
	        @action_name = action_name,
	        @action_type = action_type
	 from #function_action
	 where oid = @oid
	 
	 if not exists (select 1
	                from dbo.function_action
	                where function_num = @function_num and
	                      action_name = @action_name)
	 begin
	 	  print '=> Adding function_action record (function_num #' + cast(@function_num as varchar) + ', action_name = ''' + @action_name + ''')'
      begin tran
      select @newoid = isnull(max(oid), 0) + 1
      from dbo.function_action
   
      begin try
        insert into dbo.function_action
            (oid, function_num, action_name, action_type, trans_id)
        values (@newoid, @function_num, @action_name, @action_type, 1)        
        select @row_affected = @@rowcount
      end try
      begin catch
        if @@trancount > 0
           rollback tran
        print '==> Failed to add new record due to the error:'
        print '===> ERROR: ' + ERROR_MESSAGE()
        goto endofscript
      end catch
      commit tran
      if @row_affected > 0
         print '==> The record was added successfully!' 
   end
     
   select @oid = min(oid)
   from #function_action
   where oid > @oid        
end
endofscript:
drop table #function_action
go
                                 
exec dbo.refresh_a_last_num 'function_action', 'oid'
go
