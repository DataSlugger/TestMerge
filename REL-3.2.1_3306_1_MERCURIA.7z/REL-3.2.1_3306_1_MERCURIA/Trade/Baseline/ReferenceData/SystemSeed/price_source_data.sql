set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table price_source
go

print 'Loading seed reference data into the price_source table ...'
go

insert into dbo.price_source 
   values('APPI', 'ASIAN PAC.PETROLEUM INDEX', NULL, 1)
go

insert into dbo.price_source 
   values('ARGUS', 'ARGUS', NULL, 1)
go

insert into dbo.price_source 
   values('BANKS', 'BANKS', NULL, 1)
go

insert into dbo.price_source 
   values('BGE', 'BALTIMORE GAS & ELECTRIC', NULL, 1)
go

insert into dbo.price_source 
   values('CANADIAN', 'CANADIAN PRICE REPORTER', NULL, 1)
go

insert into dbo.price_source 
   values('CANENERD', 'CANADIAN ENERDATA', NULL, 1)
go

insert into dbo.price_source 
   values('DEWITT', 'DEWITT', NULL, 1)
go

insert into dbo.price_source 
   values('DOWJONES', 'DOW JONES', NULL, 1)
go

insert into dbo.price_source 
   values('DRI', 'DRI', NULL, 1)
go

insert into dbo.price_source 
   values('EOTT POS', 'EOTT POSTING', 'P', 1)
go

insert into dbo.price_source 
   values('EXCHANGE', 'EXCHANGE', NULL, 1)
go

insert into dbo.price_source 
   values('FEDRESBK', 'FEDERAL RESERVE BANK OF NY', NULL, 
1)
go

insert into dbo.price_source 
   values('FERC', 'INSIDE FERC', NULL, 1)
go

insert into dbo.price_source 
   values('GASDAILY', 'GAS DAILY', NULL, 1)
go

insert into dbo.price_source 
   values('ICIS-LOR', 'ICIS-LOR', NULL, 1)
go

insert into dbo.price_source 
   values('INTERNAL', 'INTERNAL', NULL, 1)
go

insert into dbo.price_source 
   values('KNIGHTR', 'KNIGHT RIDDER', NULL, 1)
go

insert into dbo.price_source 
   values('KOCH', 'KOCH POSTING', 'P', 1)
go

insert into dbo.price_source 
   values('NATWEST', 'COUNTY NATWEST', NULL, 1)
go

insert into dbo.price_source 
   values('NG WEEK', 'NATURAL GAS WEEK', NULL, 1)
go

insert into dbo.price_source 
   values('NGC', 'NGC SETTLEMENTS LTD', NULL, 1)
go

insert into dbo.price_source 
   values('NGI', 'NATURAL GAS INTELLIGENCE', NULL, 1)
go

insert into dbo.price_source 
   values('NGREP', 'NG REPORTER', NULL, 1)
go

insert into dbo.price_source 
   values('NIGOSP', 'NIGERIAN OSP', NULL, 1)
go

insert into dbo.price_source 
   values('OPIS', 'OPIS', NULL, 1)
go

insert into dbo.price_source 
   values('PLATTAPO', 'IGNORE !!', NULL, 1)
go

insert into dbo.price_source 
   values('PLATTS', 'PLATTS', NULL, 1)
go

insert into dbo.price_source 
   values('PLATTSCT', 'PLATTS CONTRACT', NULL, 1)
go

insert into dbo.price_source 
   values('PLATTSOP', 'PLATTS OFFICIAL PRICE', NULL, 1)
go

insert into dbo.price_source 
   values('PLATTSPT', 'IGNORE', NULL, 1)
go

insert into dbo.price_source 
   values('POWERMKT', 'POWER MARKETS WEEK', NULL, 1)
go

insert into dbo.price_source 
   values('SCURPERM', 'SCURLOCK PERMIAN CORP', 'P', 1)
go

insert into dbo.price_source 
   values('SPREADS', 'SPREADS', NULL, 1)
go

insert into dbo.price_source 
   values('SUNREF', 'SUNREF', 'P', 1)
go

insert into dbo.price_source 
   values('TEXACO', 'TEXACO POSTING', NULL, 1)
go

insert into dbo.price_source 
   values('TPS', 'TPS', NULL, 1)
go

insert into dbo.price_source 
   values('USGOVERN', 'U S GOVERNMENT', NULL, 1)
go

