set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading a dummy portfolio into portfolio table ...'
go

IF NOT EXISTS (select * from dbo.portfolio
               where port_num = 0 and 
                     port_type = 'R')
begin
   if object_id('dbo.portfolio_instrg') is not null
      exec('alter table dbo.portfolio disable trigger portfolio_instrg')

   INSERT INTO dbo.portfolio
         (port_num, port_type, desired_pl_curr_code, port_short_name, 
          port_full_name, port_locked, trans_id) 
	    values (0, 'R', 'USD', 'Dummy Portfolio', 'Dummy Portfolio' ,1, 1)

   if object_id('dbo.portfolio_instrg') is not null
      exec('alter table dbo.portfolio enable trigger portfolio_instrg')
end
go
