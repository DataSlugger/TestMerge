set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the desk table ...'
go

if NOT EXISTS (select *
               from dbo.desk
               where desk_code = 'TC')
   insert into dbo.desk values('TC', 'TC', 'TC', NULL, 1)
go

