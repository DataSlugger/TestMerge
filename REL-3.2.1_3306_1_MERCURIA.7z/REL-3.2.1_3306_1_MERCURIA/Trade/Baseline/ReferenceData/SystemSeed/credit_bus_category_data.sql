set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the credit_bus_category table ...'
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'BCML')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('BCML', 'Bank-Commercial', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'BINV')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('BINV', 'Bank-Investment', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'EXCH')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('EXCH', 'Exchanges', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'GNGO')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('GNGO', 'Government & NGO', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'CONS')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('CONS', 'Consulting & Advisory Firm', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'MAJ')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('MAJ', 'Majors', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'GTR')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('GTR', 'General Trading', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'TR')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('TR', 'Trading', 1)
go


if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'EP')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('EP', 'E&P', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'REF')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('REF', 'Refining', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'BUNK')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('BUNK', 'Bunkering', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'DIST')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('DIST', 'Distribution', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'TRNA')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('TRNA', 'Transport-Airline', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'TRNS')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('TRNS', 'Transport-Shipping', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'WARE')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('WARE', 'Warehousing', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'CHEM')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('CHEM', 'Chemicals', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'UTL')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('UTL', 'Utility', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'STRR')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('STRR', 'Strategic Reserves', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'IND')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('IND', 'Industrial', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'INT')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('INT', 'Integrated', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'FDCO')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('FDCO', 'Food Company', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'AGR')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('AGR', 'Agricultural', 1)
go

if not exists (select 1
               from dbo.credit_bus_category
               where cr_bus_code = 'PIPE')
   insert into dbo.credit_bus_category (cr_bus_code, cr_bus_desc, trans_id) 
   values('PIPE', 'Pipelines', 1)
go