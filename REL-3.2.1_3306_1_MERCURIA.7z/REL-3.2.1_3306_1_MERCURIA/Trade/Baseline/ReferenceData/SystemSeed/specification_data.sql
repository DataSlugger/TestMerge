set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the specification table ...'
go

insert into specification (spec_code, spec_desc, trans_id, spec_type)
     values('ALUMINA', 'ALUMINA, AL2O3', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ALUMINUM', 'ALUMINUM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ANILC', 'ANILINE DEG.C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ANILINE', 'ANILINE PPM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('API', 'API GRAVITY', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ARCO', 'ARCO SPECS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('AROMATIC', 'AROMATICS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ASBOIL', 'ARGENTINIAN SOYABEAN OIL SPECS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ASH', 'ASH WT/PCT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ASHFUSTP', 'ASH FUSION TEMPERATURE (DEG C REDUCING/O', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ASPHALT', 'ASPHALTINES', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ASTMBEN', 'ASTM D2359-85A', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ASTMBEN2', 'ASTM D2359-90', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ASTMMETH', 'ASTM D1152-89', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ASTMSTYR', 'ASTM D2827-88', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ASTMTOL', 'ASTM D841-85', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ASTMXYL', 'ASTM D843-80', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('BASICNIT', 'BASIC NITROGEN (PPM, NULL )', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('BDENSITY', 'BASE DENSITY', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('BROCA', 'BROCA PERCENT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('BS&W', 'BOTTOM SEDIMENT AND WATER', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('BTU/GAL', 'BTU GALLON', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CARB', 'CARBON', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CARBON', 'CARBON RESIDUE 10% BOTTOM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CCR', 'CCR WT PCT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CETANE', 'CETANE INDEX', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CHLORIDE', 'TOTAL CHLORIDES', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CHLORINE', 'CHLORINE', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CLOUD', 'CLOUD POINT DEG.F', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CLOUDC', 'CLOUD POINT DEG.C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('COLDFILT', 'COLD FILTER PLUGGING POINT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('COLOR', 'COLOR ASTM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('COMPAT', 'COMPATIBILITY', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('COPPER', 'COPPER PPM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CORODE', 'CORROSION DEG. F', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CORRODC', 'CORROSION DEG.C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('COUNT100', 'BEAN COUNT FOR 100 GRAMS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL11', 'COLONIAL PIPELINE GRADE 11', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL12', 'COLONIAL PIPELINE GRADE 12', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL13', 'COLONIAL PIPELINE GRADE 13', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL15', 'COLONIAL PIPELINE GRADE 15', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL17', 'COLONIAL PIPELINE GRADE 17', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL18', 'COLONIAL PIPELINE GRADE 18', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL20', 'COLONIAL PIPELINE GRADE 20', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL21', 'COLONIAL PIPELINE GRADE 21', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL22', 'COLONIAL PIPELINE GRADE 22', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL23', 'COLONIAL PIPELINE GRADE 23', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL25', 'COLONIAL PIPELINE GRADE 25', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL26', 'COLONIAL PIPELINE GRADE 26', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL27', 'COLONIAL PIPELINE GRADE 27', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL28', 'COLONIAL PIPELINE GRADE 28', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL30', 'COLONIAL PIPELINE GRADE 30', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL33', 'COLONIAL PIPELINE GRADE 33', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL38', 'COLONIAL PIPELINE GRADE 38', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL41', 'COLONIAL PIPELINE GRADE 41', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL44', 'COLONIAL PIPELINE GRADE 44', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL45', 'COLONIAL PIPELINE GRADE 45', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL47', 'COLONIAL PIPELINE GRADE 47', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL48', 'COLONIAL PIPELINE GRADE 48', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL51', 'COLONIAL PIPELINE GRADE 51', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL54', 'COLONIAL PIPELINE GRADE 54', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL55', 'COLONIAL PIPELINE GRADE 55', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL75', 'COLONIAL PIPELINE GRADE 75', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL76', 'COLONIAL PIPELINE GRADE 76', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPL86', 'COLONIAL PIPELINE GRADE 86', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPLM1', 'COLONIAL PIPELINE GRADE M1', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPLM3', 'COLONIAL PIPELINE GRADE M3', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPLM4', 'COLONIAL PIPELINE GRADE M4', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPLU2', 'COLONIAL PIPELINE GRADE U2', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPLV1', 'COLONIAL PIPELINE GRADE V1', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPLV3', 'COLONIAL PIPELINE GRADE V3', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('CPLV4', 'COLONIAL PIPELINE GRADE V4', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DEFECTIV', 'PERCENTAGE OF DEFECTIVE BEANS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DEFSTAN', 'DEFSTAN 91-91 SPECIFICATIONS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DENS15C', 'DENSITY @ 15C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DENSITY', 'DENSITY DEG. C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DENSITY1', 'DENSITY AT 15 DEG C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DERD2494', 'DERD 2494 SPECIFICATIONS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DIST10', 'DISTILLATION 10 PCT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DIST20', 'DISTILLATION 20 PCT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DIST250C', 'DISTILLATION EVAPORATED AT 250 DEG C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DIST350C', 'DISTILLATION EVAPORATED AT 350 DEG C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DIST50', 'DISTILLATION 50 PCT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DIST90', 'DISTILLATION 90 PCT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DISTEND', 'DISTILLATION END POINT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DISTILC', 'DISTILLATION DEG.C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('DISTILL', 'DISTILLATION DEG. F', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EA7', 'EA7 SPECIFICATIONS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EDENSITY', 'ESTIMATED DENSITY', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EEC', 'EEC Tax Indicator', 1, 'A')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EG11', 'EG11 SPECIFICATIONS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EG9', 'EG9 SPECIFICATIONS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EK3', 'EK3 SPECIFICATIONS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EM13WINT', 'EM13 WINTER GRADE SPECIFICATIONS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP21', 'EXPLORER PIPELINE GRADE 21', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP23', 'EXPLORER PIPELINE GRADE 23', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP24', 'EXPLORER PIPELINE GRADE 24', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP25', 'EXPLORER PIPELINE GRADE 25', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP26', 'EXPLORER PIPELINE GRADE 26', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP29', 'EXPLORER PIPELINE GRADE 29', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP31', 'EXPLORER PIPELINE GRADE 31', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP33', 'EXPLORER PIPELINE GRADE 33', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP39', 'EXPLORER PIPELINE GRADE 39', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP41', 'EXPLORER PIPELINE GRADE 41', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP43', 'EXPLORER PIPELINE GRADE 43', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP49', 'EXPLORER PIPELINE GRADE 49', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP51', 'EXPLORER PIPELINE GRADE 51', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP76', 'EXPLORER PIPELINE GRADE 76', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EXP77', 'EXPLORER PIPELINE  GRADE 77', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('FEROXIDE', 'FERRIC OXIDE, FE2O3', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('FFABUTTR', 'FREE FATTY ACID CONTENT IN COCOA BUTTER', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('FIXCARB', 'FIXED CARBON (% BY WT, NULL )', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('FLASH', 'FLASH POINT DEG.F', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('FLASHC', 'FLASH POINT DEG.C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('FLUID', 'FLUID', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('GRAVITY', 'API GRAVITY', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('HAZE', 'HAZE RATING @70 DEG.F.', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('HEATVAL', 'HEATING VALUE (BTU/LB, NULL )', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('HEMISPHR', 'HEMISPHERICAL', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('HGI', 'HGI', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('HUMIDITY', 'HUMIDITY', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('HYDROGEN', 'HYDROGEN', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('IBP', 'INITIAL BOILING POINT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('INITDFRM', 'INITIAL DEFORMATION', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('INITDIL', 'INITIAL DILATION, DEG C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('INITSOFT', 'INITIAL SOFTENING, DEG C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('IRON', 'IRON PPM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('LANDED', 'LANDED WEIGHTS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('LIME', 'LIME, CAO', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('M1', 'M1', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MAGNESIA', 'MAGNESIA, MGO', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MANGOXID', 'MANGANESE OXIDE, MN3O4', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MAXDIL', 'MAXIMUM DILATION, DEG C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MAXFLUID', 'MAXIMUM FLUIDITY, PPM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MINASHAN', 'MINERAL ASH ANALYSIS (% OF ASH, IGNITED', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-ABRS', 'BRAND : ALBRAS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-ACO', 'BRAND : ALCOA', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-ALBA', 'BRAND : ALBA', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-ALC', 'BRAND : ALCAN', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-ALCA', 'BRAND : ALCASA', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-ALT', 'BRAND : ALOUETTE', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-AMAX', 'BRAND : ALUMAX', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-BAS', 'BRAND : RUSSIAN BAS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-BLL1', 'BRAND : BILLITON SAO LUIS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-CAA3', 'BRAND : RUSSIAN CAA3', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-CANB', 'BRAND : ALCAN BRAZIL', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-CCCP', 'BRAND : RUSSIAN CCCP', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-CH', 'BRAND : ALUSUISSE', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-CML', 'BRAND : COMALCO', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-CMLC', 'BRAND : COMALCO', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-COAB', 'BRAND : ALCOA BRAZIL', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-DUBL', 'BRAND : DUBAL', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-HKA3', 'BRAND : RUSSIAN HKA3', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-ID', 'BRAND : RUSSIAN ID', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-KOR', 'BRAND : KORALU', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-KPA3', 'BRAND : RUSSIAN KPA3', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-NALC', 'BRAND : NALCO', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-NPA3', 'BRAND : RUSSIAN NPA3', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-PECH', 'BRAND : PECHINEY', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-RA0', 'RUSSIAN A0', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-RA5', 'RUSSIAN A5', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-RA5E', 'RUSSIAN A5E', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-RA6', 'RUSSIAN A6', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-RA7', 'RUSSIAN A7', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-RA7E', 'RUSSIAN A7E', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-RA8', 'RUSSIAN A8', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-REY', 'BRAND : REYNOLDS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-SAF', 'BRAND : ALUSAF', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-TAD3', 'BRAND : TADA3', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-TADA', 'BRAND : RUSSIAN TADA3', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-TALC', 'BRAND : TALCO', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-UPA3', 'BRAND : RUSSIAN UPA3', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-VALS', 'BRAND : VALESUL', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-VAW', 'BRAND : VAW', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTB-VENA', 'BRAND : VENALUM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTC-AL', 'ALUMINIUM CONTENT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTC-FE', 'IRON CONTENT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTC-SI', 'SILICON CONTENT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-AUST', 'ORIGIN : AUSTRALIA', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-AZBJ', 'ORIGIN : CIS - AZERBAIJAN', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-BAHR', 'ORIGIN : BAHRAIN', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-BRAZ', 'ORIGIN : BRAZIL', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-CANA', 'ORIGIN : CANADA', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-CH', 'ORIGIN : SWITZERLAND', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-DUBA', 'ORIGIN : DUBAI', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-FRAN', 'ORIGIN : FRANCE', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-INDI', 'ORIGIN : INDIA', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-RUS', 'ORIGIN : CIS - RUSSIA', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-SAF', 'ORIGIN : SOUTH AFRICA', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-SKOR', 'ORIGIN : SOUTH KOREA', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-TADZ', 'ORIGIN : TADZHIKISTAN', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-TWAN', 'ORIGIN : SWITZERLAND', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-UK', 'ORIGIN : UNITED KINGDOM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-USA', 'ORIGIN : UNITED STATES OF AMERICA', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTO-VEN', 'ORIGIN : VENEZUELA', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTS-ANY', 'STANDARD INGOTS, T-BARS, OR SOWS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTS-BILL', 'BILLETS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTS-BRIQ', 'BRIQUETTES', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTS-CATS', 'CATHODES', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTS-ING', 'STANDARD INGOTS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTS-PLAT', 'STANDARD PLATES', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTS-RODS', 'RODS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTS-SLAB', 'SLABS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTS-SOWS', 'SOWS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTS-TBAR', 'T-BARS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MTS-WBAR', 'WIRE BARS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('MXFLUTMP', 'MAXIMUM FLUIDITY TEMP., DEG C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('N+A', 'N PLUS A', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('NAP', 'NAPHTHENES', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('NDW', 'NET DELIVERED WEIGHTS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('NICKEL', 'NICKEL', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('NITRO', 'NITROGEN', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('NITROGEN', 'NITROGEN PPM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('NSW', 'NET SHIPPED WEIGHTS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('NYMERC', 'NEW YORK MERCANTILE', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('OLEFINS', 'OLEFINS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('OXIDAT', 'OXIDATION STABILITY MG/100 ML.', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('OXYGEN', 'OXYGEN', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('PARAFINS', 'PARAFINS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('PCT10', '10 %', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('PCT50', '50 %', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('PCT73', '73 %', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('PHOSPENT', 'PHOS PENTOXIDE, P2O5', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('PLSTCTMP', 'PLASTIC TEMP. RANGE, DEG C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('POLARIZA', 'POLARIZATION PCT FOR SUGAR', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('POTOXIDE', 'POTASSIUM OXIDE, K2O', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('POUR', 'POUR POINT DEG.F', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('POURC', 'POUR POINT DEG.C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('PRCNTCNT', 'PERCENT CONTRACTION', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('PRCNTDIL', 'PERCENT DILATION', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('PURITY', 'PURITY FOR HIGH GRADE ALUMINUM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('REWEIGHT', 'REWEIGHTS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('RVP', 'RVP', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SG60F', 'SPECIFIC GRAVITY @ 60F', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SHELL', 'SHELL HOT FILTRATION', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SILICA', 'SILICA, SIO2', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SILICON', 'SILICON', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SIZE', 'SIZE (MM., NULL )', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SLATEY', 'PERCENTAGE OF SLATEY  BEANS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SODIUM', 'SODIUM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SODOXIDE', 'SODIUM OXIDE, NA2O', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SOFTENNG', 'SOFTENING (H=W, NULL )', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SOFTTEMP', 'SOFTENING TEMP., DEG C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SOLIDTMP', 'SOLIDIFICATION TEMP., DEG C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SULFUR', 'SULPHUR WT/PCT.', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SULP/PPM', 'SULPHUR PPM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('SULTRIOX', 'SULPHUR TRIOXIDE, SO3', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TAREACT', 'ACTUAL TARE', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TARESHP', 'SHIPPING TARE', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TEMP-C', 'TEMPERATURE - CELSIUS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TEMP-F', 'TEMPERATURE - FAHRENHEIT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TET22', 'TET GRADE 22', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TET40', 'TET GRADE 40', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TET44', 'TET GRADE 44', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TET51', 'TET GRADE 51', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TET52', 'TET GRADE 52', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TET55', 'TET GRADE 55', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TET76', 'TET GRADE 76', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('THERMAL', 'THERMAL STABILITY DEG.F.', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('THERMC', 'THERMAL STABILITY DEG.C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TITOXIDE', 'TITANIUM OXIDE, TIO2', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TOTMOIST', 'TOTAL MOISTURE (% BY WT, NULL)', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TOTSULPH', 'TOTAL SULPHUR', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ULTANALY', 'ULTIMATE ANALYSIS (%, NULL)', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('VANADIUM', 'VANADIUM', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('VICOS', 'VISCOSITY', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('VOLMAT', 'VOLATILE MATTER (% BY WT, NULL )', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WARRANT', 'WARRANT WEIGHTS', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WATERSED', 'WATER AND SEDIMENT', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WPL/J', 'WILLIAMS  GRADE J', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WPL/O', 'WILLLIAMS GRADE O', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WPLA', 'WILLIAMS PIPELINE GRADE A', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WPLA5', 'WILLIAMS PIPELINE GRADE A5', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WPLM', 'WILLIAMS PIPELINE GRADE M', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WPLM5', 'WILLIAMS PIPELINE GRADE M5', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WPLMN5', 'WILLIAMS PIPELINE GRADE N5', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WPLN', 'WILLIAMS PIPELINE GRADE N5', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WPLR', 'WILLIAMS PIPELINE GRADE R', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WV_Qty', 'WV_Qty', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('WV_Uom', 'WV_Uom', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('ADJUSTIN', 'Adjusted average density factor', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('NBVI', 'Net Back Value initial', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('RP_DIFF', 'Realizable Price Differential', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('PR_ADJQ1', 'Price adjustment quantity 1', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('PR_ADJQ2', 'Price adjustment quantity 2', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('FIN','Final Commodity Rollup Type', 1, 'A')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('BaseCRV','Base CRV', 1, 'A')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('EstCRV','Estimate CRV', 1, 'A')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('GROSSLIT', 'Gross Liters(Actual temp)', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('NETLIT15', 'Net liters @ 15C', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('FRANCHIS', 'Franchise Charge', 1, 'N')
go

insert into specification (spec_code, spec_desc, trans_id, spec_type) 
     values('TOTDELQT', 'Total Delivered Qty', 1, 'N')
go

