set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the execution_type table ...'
go

if not exists (select 1
               from execution_type
               where exec_type_code = 'FUTURE')
   insert into execution_type (exec_type_code, exec_type_desc, fifo_priority, trans_id)
     values('FUTURE', 'Simple Future', 1, 1)
go

if not exists (select 1
               from execution_type
               where exec_type_code = 'EFP')
   insert into execution_type (exec_type_code, exec_type_desc, fifo_priority, trans_id)
     values('EFP', 'EFP', 2, 1)
go

if not exists (select 1
               from execution_type
               where exec_type_code = 'EFS')
   insert into execution_type (exec_type_code, exec_type_desc, fifo_priority, trans_id)
     values('EFS', 'EFS', 3, 1)
go

if not exists (select 1
               from execution_type
               where exec_type_code = 'CROSS')
   insert into execution_type (exec_type_code, exec_type_desc, fifo_priority, trans_id)
     values('CROSS', 'Cross', 4, 1)
go

if not exists (select 1
               from execution_type
               where exec_type_code = 'NETTING')
   insert into execution_type (exec_type_code, exec_type_desc, fifo_priority, trans_id)
     values('NETTING', 'Netting Commission', 5, 1)
go

if not exists (select 1
               from execution_type
               where exec_type_code = 'ZERO')
   insert into execution_type (exec_type_code, exec_type_desc, fifo_priority, trans_id)
     values('ZERO', 'Zero Commission', 6, 1)
go
					
