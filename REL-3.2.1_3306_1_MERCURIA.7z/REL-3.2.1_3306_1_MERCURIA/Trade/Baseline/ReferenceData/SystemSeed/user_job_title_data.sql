set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table user_job_title
go

print 'Loading seed reference data into the user_job_title table ...'
go

insert into dbo.user_job_title values('ANALYST', 1)
go

insert into dbo.user_job_title values('CONTRACT ANALYST', 1)
go

insert into dbo.user_job_title values('NONE', 1)
go

insert into dbo.user_job_title values('SCHEDULER', 1)
go

insert into dbo.user_job_title values('TRADER', 1)
go

