set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the uic_rpt_values_config table ...'
go

create table #rpt_values_config
(
   oid	                     numeric(18, 0) IDENTITY PRIMARY KEY,
   entity_name	             varchar(30)    null,
   entity_value_selector     varchar(255)	  null, 
   description	             varchar(50)	  null
)
go

/* Allocation */
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Allocation', 'allocStatus', 'allocStatus')
go

/* AllocationItem */
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItem', 'titleTranLocCode', 'Title Transfer Location')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItem', 'okToLoadInd', 'Credit Approved for Loading')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItem','schQty','Scheduled Quanity')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItem','nominQtyMax','Nomin Max Quanity')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItem','nominQtyMin','Nomin Min Quanity')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItem','actualGrossQty','Actual Gross Quanity')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItem','secondaryActualQty','Secondary Actual Quanity')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItem',  'estimateEventDate',  'Estimate Event Date')
go

/* AllocationItemTransport */
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItemTransport', 'transportation', 'MOT')
go

insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItemTransport', 'layDaysStartDate', 'Lay Days Start Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItemTransport', 'layDaysEndDate', 'Lay Days End Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItemTransport', 'etaDate', 'Eta Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItemTransport', 'blDate', 'B/L Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItemTransport', 'norDate', 'NOR Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItemTransport', 'loadCmncDate', 'Load Cmnc Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItemTransport', 'loadComplDate', 'Load Compl Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItemTransport', 'dischCmncDate', 'Disch Cmnc Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItemTransport', 'dischComplDate', 'Disch Compl Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItemTransport', 'loadDischDate', 'Load Disch Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('AllocationItemTransport', 'negotiatedDate', 'Negotiated Date')    
go

/* Cost */
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Cost', 'account.acctShortName', 'Counterparty')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Cost', 'costAmt', 'Cost Amount')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Cost', 'costCommodity.cmdtyShortName', 'Cost Code/ Commodity')
go 
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Cost', 'costPriceCurrCode', 'Cost Price Currency')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Cost', 'costPriceUomCode', 'Cost Price UOM')
go 
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Cost', 'costQty', 'Cost Quantity')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Cost', 'costQtyUomCode', 'Cost Qty UOM')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Cost', 'costUnitPrice', 'Cost Unit Price')
go 
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Cost', 'payTermCode', 'Payment Term')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Cost', 'costBookExchRate', 'Cost BookExchange Rate')
go

/* CostExtInfo */
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('CostExtInfo', 'fxLockingStatus', 'Fx Locking Status')
go

/* Parcel */
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Parcel', 'schQty', 'Scheduled Quanity')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Parcel', 'nominQty', 'Nomin Quanity')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Parcel', 'statusText', 'Parcel Status')
go

/* Shipment */
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Shipment', 'statusText', 'Shipment Status') 
go

/* Trade */
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Trade', 'creationDate', 'Creation Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Trade', 'contrDate', 'Contract Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Trade', 'contrStatus.contrStatusDesc', 'Contract Status')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Trade', 'trader.fullName', 'Trader')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Trade', 'tradeConfirmedInd', 'Trade Confirmed Ind')
go


/* TradeItem */
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'brkrCommAmt', 'Broker unit price')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'brkrCommCurrCode', 'Broker commission currency')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'brkrCommUomCode', 'Broker commission UOM')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'brkrRefNum', 'Broker Ref #')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'broker.acctShortName', 'Broker')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'commodity', 'Commodity')
go 
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'contrQtyAmountPerLife', 'Contract Quantity')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
values('TradeItem', 'contrQtyUomCode', 'Contract Qty UOM')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'formulaString', 'Trade Formula')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'pSInd', 'P S Indicator')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'realPortfolio.portShortName', 'Portfolio')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'riskMarket', 'riskMarket')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'riskTradingPeriod', 'Trading Period')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'okToLoadInd', 'Credit Approved')
go   
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'priceUomCode', 'Price UOM')
go   
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'priceCurrCode', 'Price Currency')
go   
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'bookingCompany.acctShortName', 'Booking Company')
go   
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'formulaUOMConversion', 'Formula UOM Conversion Rate')
go   
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'priceString', 'Trade Price')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'realPortfolio.portNum', 'Portfolio Number') 
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'deliveryTerm.delTermDesc', 'Delivery Term')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'mot.motFullName', 'MOT')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'deliveryLocation.locName', 'Title Transfer Location')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'loadPortLocCode', 'Load Port')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'dischPortLocCode', 'Discharge Port')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'titleMktCode', 'Title Market')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'tradeItemWetPhy.tolQty', 'Tolerance')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'financingBank.acctShortName', 'Financing Bank')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'exceptionsAdditions.excpAddnsDesc', 'Exceptions/Additions')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'riskTradingPeriod.tradingPrdDesc', 'Risk Trading Period')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'deemedDueDate', 'Pay On Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'tradeItemExtension.creditTerm.creditTermDesc', 'Credit Term')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'estimateInd', 'EstimateInd')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'includesExciseTax', 'Includes Excise Tax')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'includesFuelTax', 'Includes Fuel Tax')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'relativeDeclrDateInd', 'Relative Declare Date Ind')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'declarDateRelativeType', 'Relative Declare Date Type')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'declarDateFromGUI', 'Relative Declare Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItem', 'declarRelDays', 'Relative Declare Days')
go


 
/* TradeItemWetPhy */
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItemWetPhy', 'delDateFrom', 'Delivery Date From')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItemWetPhy', 'delDateTo', 'Delivery Date To') 
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItemWetPhy', 'creationDate', 'Creation Date')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItemWetPhy', 'prelimPrice', 'PreliminaryPrice')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItemWetPhy', 'prelimPaymentTerm.payTermDesc', 'PreliminaryPaymentTerm')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItemWetPhy', 'prelimDueDate', 'PreliminaryDueDate')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItemWetPhy', 'prelimPercentage', 'PreliminaryPercentage')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItemWetPhy', 'prelimQtyBase', 'PreliminaryQuantityBase')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItemWetPhy', 'paymentTerm.payTermDesc', 'PaymentTerm')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('TradeItemWetPhy', 'densityInd', 'Density Ind')
go


/* Voucher */
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Voucher', 'voucherDueDate', 'voucherDueDate')
go
insert into #rpt_values_config
    (entity_name, entity_value_selector, description)
   values ('Voucher', 'voucherTotAmt', 'voucher Total Amount')
go 
 
/* ********************************************************************** */
insert into #rpt_values_config 
    (entity_name, entity_value_selector, description)
select 'TradeItemSpec',  'specMinVal',  'Spec Min Value'   
union all
select 'TradeItemSpec',  'specMaxVal',  'Spec Max Value'   
union all
select 'TradeItemSpec',  'specTypicalVal',  'Spec Typical Value'   
union all
select 'TradeItemSpec',  'specTestCode',  'Spec Test Code'   
union all
select 'TradeItemSpec',  'specProvisionalVal',  'Spec Prov Value'   
union all
select 'TradeItemSpec',  'splittingLimit',  'Splitting Limit'   
union all
select 'TradeItemSpec',  'equivPayDeductInd',  'Equiv Pay Deduct Ind'   
union all
select 'TradeItemSpec',  'equivDelCmdtyCode',  'Equiv Del Cmdty Code'   
union all
select 'TradeItemSpec',  'equivDelMktCode',  'Equiv Del Mkt Code'   
union all
select 'AiEstActualSpec',  'specActualValue',  'Spec Actual Value'   
union all
select 'AiEstActualSpec',  'specActualValueText',  'Spec Actual Value Text'   
union all
select 'AiEstActualSpec',  'specProvisionalVal',  'Spec Prov Value'   
union all
select 'FormulaBodyTrigger',  'triggerQty',  'Trigger Qty'   
union all
select 'FormulaBodyTrigger',  'triggerDate',  'Trigger Date'   
union all
select 'FormulaBodyTrigger',  'triggerPrice',  'Trigger Price'   
union all
select 'FormulaBodyTrigger',  'triggerPriceCurrCode',  'Trigger Price Curr Code'   
union all
select 'FormulaBodyTrigger',  'triggerPriceUomCode',  'Trigger Price Uom Code'   
union all
select 'FormulaBodyTrigger',  'triggerQtyUomCode',  'Trigger Qty Uom Code'   
union all
select 'FormulaBodyTrigger',  'inputQty',  'Input Qty'   
union all
select 'FormulaBodyTrigger',  'inputQtyUomCode',  'Input Qty Uom code'   
union all
select 'FormulaBodyTrigger',  'inputLockInd',  'Input Lock Ind'   
union all
select 'FormulaComponent',  'formulaCompVal',  'Variable Value'   
union all
select 'FormulaComponent',  'formulaCompCurrCode',  'Variable Currency'   
union all
select 'FormulaComponent',  'formulaCompUomCode',  'Variable Uom' 
go

insert into #rpt_values_config 
    (entity_name, entity_value_selector, description)
  values('Cost',  'costPayRecInd',  'Cost Pay Rec Ind')
go



   
declare @oid                       numeric(18, 0),
        @newoid                    int,
        @entity_value_selector     varchar(255),
        @entity_id	               int,
        @description	             varchar(50),
        @entity_name	             varchar(30),
        @errcode                   int,
        @errmsg                    varchar(255)
        
select @oid = min(oid)
from #rpt_values_config

while @oid is not null
begin
   select @entity_name = entity_name,
          @entity_value_selector	= entity_value_selector,
          @description = description
   from #rpt_values_config
   where oid = @oid
   
   select @entity_id = oid
   from dbo.icts_entity_name
   where entity_name = @entity_name

   if @entity_id is null
   begin
      select @errmsg = 'Failed to find an icts_entity_name record for the entity ''' + @entity_name + '''!'
      print @errmsg
      goto nextoid
   end
      
   if not exists (select 1
                  from dbo.uic_rpt_values_config
                  where entity_id	= @entity_id and
                        entity_value_selector	= @entity_value_selector and
                        description = @description)
   begin
      select @newoid = null
      select @newoid = isnull(max(oid), 0) + 1
      from dbo.uic_rpt_values_config
      
      if @newoid is null
      begin
         print 'Failed to obtain a new oid for a new uic_rpt_values_config entry!'
         goto endofscript
      end
   
      insert into dbo.uic_rpt_values_config
          values(@newoid, @entity_id, @entity_value_selector, @description, 1)
      select @errcode = @@error
      if @errcode > 0
         goto endofscript
   end

nextoid:
   select @oid = min(oid)
   from #rpt_values_config
   where oid > @oid
end
endofscript:
drop table #rpt_values_config
go

exec refresh_a_last_num 'uic_rpt_values_config', 'oid'
go
