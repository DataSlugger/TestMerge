set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table uom_conversion
go

print 'Loading seed reference data into the uom_conversion table ...'
go

insert into dbo.uom_conversion values(1, 'BBL', 'BG60', NULL, NULL, NULL, 2.222497, 
'M', 1)
go

insert into dbo.uom_conversion values(2, 'BBL', 'GAL', NULL, NULL, NULL, 42.000000, 
'M', 1)
go

insert into dbo.uom_conversion values(3, 'BBL', 'MB', NULL, NULL, NULL, 1000.000000, 
'D', 1)
go

insert into dbo.uom_conversion values(4, 'BBL', 'MT', NULL, NULL, NULL, 0.133350, 
'M', 1)
go

insert into dbo.uom_conversion values(5, 'CMBT', 'MMBT', NULL, NULL, NULL, 
10000.000000, 'M', 1)
go

insert into dbo.uom_conversion values(6, 'GAL', 'MB', NULL, NULL, NULL, 
42000.000000, 'D', 1)
go

insert into dbo.uom_conversion values(7, 'GAL', 'MG', NULL, NULL, NULL, 100.000000, 
'D', 1)
go

insert into dbo.uom_conversion values(8, 'GAL', 'MT', NULL, NULL, NULL, 0.003175, 
'M', 1)
go

insert into dbo.uom_conversion values(9, 'GJ', 'MMBT', NULL, NULL, NULL, 1.054615, 
'D', 1)
go

insert into dbo.uom_conversion values(10, 'KG', 'BG60', NULL, NULL, NULL, 60.000000, 
'D', 1)
go

insert into dbo.uom_conversion values(11, 'KG', 'BG69', NULL, NULL, NULL, 69.000000, 
'D', 1)
go

insert into dbo.uom_conversion values(12, 'KG', 'BG70', NULL, NULL, NULL, 70.000000, 
'D', 1)
go

insert into dbo.uom_conversion values(13, 'KG', 'LB', NULL, NULL, NULL, 2.204623, 
'M', 1)
go

insert into dbo.uom_conversion values(14, 'KG', 'MT', NULL, NULL, NULL, 1000.000000, 
'D', 1)
go

insert into dbo.uom_conversion values(15, 'LB', 'BG60', NULL, NULL, NULL, 
132.277380, 'D', 1)
go

insert into dbo.uom_conversion values(16, 'LB', 'BG69', NULL, NULL, NULL, 
152.118959, 'D', 1)
go

insert into dbo.uom_conversion values(17, 'LB', 'BG70', NULL, NULL, NULL, 
154.323582, 'D', 1)
go

insert into dbo.uom_conversion values(18, 'LB', 'MT', NULL, NULL, NULL, 0.000454, 
'M', 1)
go

insert into dbo.uom_conversion values(19, 'LT', 'LB', NULL, NULL, NULL, 2240.000000, 
'M', 1)
go

insert into dbo.uom_conversion values(20, 'LT', 'STN', NULL, NULL, NULL, 1.016000, 
'M', 1)
go

insert into dbo.uom_conversion values(21, 'MB', 'BBL', NULL, NULL, NULL, 
1000.000000, 'M', 1)
go

insert into dbo.uom_conversion values(22, 'MB', 'GAL', NULL, NULL, NULL, 
42000.000000, 'M', 1)
go

insert into dbo.uom_conversion values(23, 'MB', 'MT', NULL, NULL, NULL, 133.351113, 
'M', 1)
go

insert into dbo.uom_conversion values(24, 'MMBT', 'CMBT', NULL, NULL, NULL, 
10000.000000, 'D', 1)
go

insert into dbo.uom_conversion values(25, 'MT', 'BBL', NULL, NULL, NULL, 6.92, 
'M', 1)
go

insert into dbo.uom_conversion values(26, 'MT', 'BG60', NULL, NULL, NULL, 16.666644, 
'M', 1)
go

insert into dbo.uom_conversion values(27, 'MT', 'LB', NULL, NULL, NULL, 2204.620000, 
'M', 1)
go

insert into dbo.uom_conversion values(28, 'MT', 'MB', NULL, NULL, NULL, 0.007499, 
'M', 1)
go

insert into dbo.uom_conversion values(29, 'STN', 'LB', NULL, NULL, NULL, 
2000.000000, 'M', 1)
go

insert into dbo.uom_conversion values(30, 'UNIT', 'BBL', NULL, NULL, NULL, 1.000000, 
'D', 1)
go

insert into dbo.uom_conversion values(277, 'MB', 'MT', 'BROKERAG', NULL, NULL, 
133.333333, 'M', 1)
go

insert into dbo.uom_conversion values(358, 'MT', 'BBL', 'OTCPREM', NULL, NULL, 
7.499063, 'M', 1)
go

insert into dbo.uom_conversion values(364, 'MT', 'BBL', 'BROKERAG', NULL, NULL, 
7.499063, 'M', 1)
go

insert into dbo.uom_conversion values(366, 'MT', 'BBL', 'CASH_ADJ', NULL, NULL, 
7.499063, 'M', 1)
go

insert into dbo.uom_conversion values(376, 'MT', 'BBL', 'SETTLEME', NULL, NULL, 
7.499063, 'M', 1)
go

insert into dbo.uom_conversion values(695, 'MT', 'MG', 'BROKERAG', NULL, NULL, 
3.149606, 'M', 1)
go

insert into dbo.uom_conversion values(696, 'M3', 'LITR', NULL, NULL, NULL, 1000.0, 'M', 1)
go

insert into dbo.uom_conversion
   (uom_conv_num, uom_code_conv_from, uom_code_conv_to,
    uom_conv_rate, uom_conv_oper, trans_id)
  values(697, 'GAL', 'LITR', 3.7854, 'M', 1)
go
