set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the calendar table ...'
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'APISTATS')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('APISTATS', 'API Oil Stats', 'N', 
            'API Statistics (CONTAINS NO HOLIDAYS!!!)', 'YYYYYNN', 'A', 1)
go


if not exists (select 1
               from dbo.calendar
               where calendar_code = 'BANKSUS')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('BANKSUS', 'U S Banks', 'N', 'U S Bank Holidays', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'CANADAGA')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('CANADAGA', 'Canada Enerdata', 'N', 'Nat Gas', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'CBOT')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('CBOT', 'Chicago Board of Trade', 'N', 'Chicago Board of Trade', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'COMEX')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('COMEX', 'Commodity Exchange, Inc.', 'N', 'Commodity Exchange, Inc.', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'CSCE')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('CSCE', 'Coffee Sugar Cocoa Exchange', 'N', 'Coffee Sugar Cocoa Exchange', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'FRIDAYS')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('FRIDAYS', 'Isis-Lor - Fridays', 'N', 'Fridays Europe', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'GASDAILY')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('GASDAILY', 'U S GAS DAILY', 'N', 'U S', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'IPE')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('IPE', 'International 21-4- Exchange', 'N', 'International Petroleum Exchange', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'LCE')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('LCE', 'London Commodity Exchange', 'N', 'London Commodity Exchange', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'LME')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('LME', 'London Metal Exchange', 'N', 'London Metal Exchange', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'LONOFC')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('LONOFC', 'London Office', 'N', 'London Office', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'NERC')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('NERC', 'North America', 'N', 'Energy Reliability', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'NGI')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('NGI', 'NatGasIntelignce', 'N', '1st Mon.of Month', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'NYCE')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
      values('NYCE', 'New York Cotton Exchange', 'N', 'New York Cotton Exchange', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'NYMEX')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('NYMEX', 'New York Mercantile Exchange', 'N', 'New York Mercantile Exchange', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'PLTSARG')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('PLTSARG', 'Platts Arab Gulf', 'N', 'Singapore', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'PLTSEURO')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('PLTSEURO', 'Platts Europe', 'N', 'Platts Europe', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'PLTSJAPA')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('PLTSJAPA', 'Platts Japan', 'N', 'Platts Japan', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'PLTSMKTW')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('PLTSMKTW', 'CrudeMarketwire', 'N', 'Xmas & New Year', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'PLTSSING')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('PLTSSING', 'Platts Singapore', 'N', 'Platts Singapore', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'PLTSUSA')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('PLTSUSA', 'Platts USA', 'N', 'Platts USA', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'SIMEX')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
      values('SIMEX', 'Singapore Exchange', 'N', 'Singapore', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'THURSDAY')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('THURSDAY', 'Tapis etc', 'N', 'Thursdays Only', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'USA')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('USA', 'United States Calendar', 'N', 'United States Calendar', 'YYYYYNN', 'A', 1)
go
