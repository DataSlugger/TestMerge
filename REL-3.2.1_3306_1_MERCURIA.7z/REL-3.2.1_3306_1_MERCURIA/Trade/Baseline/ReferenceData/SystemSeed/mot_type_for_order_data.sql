set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the mot_type_for_order table ...'
go

if not exists (select 1
               from dbo.mot_type_for_order
               where mot_type_code = 'BARGE' and
                     order_type_code = 'BUNKER')
   insert into dbo.mot_type_for_order (mot_type_code, order_type_code, virtual_ind, trans_id)
   values('BARGE', 'BUNKER', 'N', 1)
go

if not exists (select 1
               from dbo.mot_type_for_order
               where mot_type_code = 'TRUCK' and
                     order_type_code = 'BUNKER')
   insert into dbo.mot_type_for_order (mot_type_code, order_type_code, virtual_ind, trans_id)
   values('TRUCK', 'BUNKER', 'N', 1)
go

if not exists (select 1
               from dbo.mot_type_for_order
               where mot_type_code = 'NONE' and
                     order_type_code = 'BUNKER')
   insert into dbo.mot_type_for_order (mot_type_code, order_type_code, virtual_ind, trans_id)
   values('NONE', 'BUNKER', 'Y', 1)
go
