set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading 10 standard tags into the entity_tag_definition table, '
print '   the icts_function table and its related reference tables ...'
go

create table #tentags
(
	  tag_name          varchar(16) NOT NULL PRIMARY KEY,
	  tag_desc          varchar(64) NOT NULL,
    function_name     varchar(40) not null,
    function_num      int default 0
)
go

insert into #tentags (tag_name, tag_desc, function_name, function_num)
   values('CLASS', 'Classification', 'PORT_TAG_MODIFY_CLASS', 0),
         ('DEPT','Department','PORT_TAG_MODIFY_DEPT', 0),
         ('DESK','Desk', 'PORT_TAG_MODIFY_DESK', 0),
         ('DIVISION','Division', 'PORT_TAG_MODIFY_DIVISION', 0),
         ('GROUP','Group', 'PORT_TAG_MODIFY_GROUP', 0),
         ('LEGALENT','Legal Entity', 'PORT_TAG_MODIFY_LEGALENT', 0),
         ('LOCATION','Location', 'PORT_TAG_MODIFY_LOCATION', 0),
         ('PRFTCNTR','Profit Center', 'PORT_TAG_MODIFY_PRFTCNTR', 0),
         ('STRATEGY','Strategy', 'PORT_TAG_MODIFY_STRATEGY', 0),
         ('TRADER','Trader', 'PORT_TAG_MODIFY_TRADER', 0)
go
   

/* ********************************************************************** */
/*  Load the same data into the entity_tag_definition table               */
/* ********************************************************************** */

declare @entity_id         int,
        @tag_name          char(8),
        @newoid            int,
        @tag_desc          varchar(64),
        @smsg              varchar(255),
        @rows_affected     int,
        @errcode           int,
        @next_num          int,
        @function_name     varchar(40)
       
select @errcode = 0

select @entity_id = oid
from dbo.icts_entity_name
where entity_name = 'Portfolio'

if @entity_id is null
begin
   print 'Failed to find the entity ''Portfolio'' in the icts_entity_name table!'
   goto endofscript
end

select @tag_name = min(tag_name)
from #tentags

while @tag_name is not null
begin
   select @tag_desc = tag_desc,
          @function_name = function_name 
   from #tentags
   where tag_name = @tag_name
   
   if not exists (select 1
                  from dbo.entity_tag_definition
                  where entity_tag_name = @tag_name and
                        entity_id = @entity_id)
   begin
      select @newoid = isnull(max(oid), 0) + 1 from dbo.entity_tag_definition
      begin tran  
      begin try    
        insert into dbo.entity_tag_definition
              (oid, entity_tag_name, entity_tag_desc, tag_required_ind, 
               tag_status, entity_id, trans_id)
           values(@newoid, @tag_name, @tag_desc, 'N', 'A', @entity_id, 1)
      end try
      begin catch
      	if @@trancount > 0
      	   rollback tran
      	set @errcode = ERROR_NUMBER()
      	set @smsg = ERROR_MESSAGE()
      	RAISERROR('=> Failed to add an entity_tag_definition record for the tag ''%s'' due to the error:', 0, 1, @tag_name) with nowait
      	RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
        goto nexttag
      end catch
      commit tran
      RAISERROR('=> The tag ''%s'' was successfully added into the entity_tag_definition table.', 0, 1, @tag_name) with nowait
   end

   if not exists (select 1
                  from dbo.icts_function
                  where function_name = @function_name)
   begin
   	  begin tran
      begin try
        update dbo.new_num 
        set last_num = last_num + 1 
        where num_col_name = 'portfolio_tag_num' and
              loc_num = 0  
      end try
      begin catch
      	if @@trancount > 0
      	   rollback tran
      	set @errcode = ERROR_NUMBER()
      	set @smsg = ERROR_MESSAGE()
      	RAISERROR('=> Failed to obtain a new function_num for the function_name ''%s'' due to the error:', 0, 1, @function_name) with nowait
      	RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
        goto nexttag
      end catch

      set @next_num = 0
      select @next_num = last_num 
      from dbo.new_num 
      where  num_col_name = 'portfolio_tag_num' and 
             loc_num = 0 
      RAISERROR('=> Obtaining the new function_num #%d for the function_name ''%s''!', 0, 1, @next_num, @function_name) with nowait
      
      begin try
        insert into dbo.icts_function 
          values(@next_num, 'PortfolioManager', @function_name, 1)
      end try
      begin catch
      	if @@trancount > 0
      	   rollback tran
      	set @errcode = ERROR_NUMBER()
      	set @smsg = ERROR_MESSAGE()
      	RAISERROR('=> Failed to add an icts_function record for the function_name ''%s'' due to the error:', 0, 1, @function_name) with nowait
      	RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
        goto nexttag
      end catch
      commit tran
      RAISERROR('=> The icts_function with the function_name ''%s'' was successfully added.', 0, 1, @function_name) with nowait
      
      update #tentags
      set function_num = @next_num
      where tag_name = @tag_name
   end
   
nexttag:      
   select @tag_name = min(tag_name)
   from #tentags
   where tag_name > @tag_name
end /* while */
endofscript:
go


RAISERROR(' ', 0, 1) with nowait
RAISERROR('Adding function_detail/function_detail_value records if needed for function(s) in icts_function table ...', 0, 1) with nowait
go

declare @fd_id          int,
        @fdv_id         int,
        @smsg           varchar(255),
        @function_num   int,
        @errcode        int

select @function_num = min(function_num)
from #tentags
where function_num > 0

while @function_num is not null
begin
   if not exists (select 1
                  from dbo.function_detail
                  where function_num = @function_num and
                        entity_name = 'LEVEL')
   begin
      RAISERROR('=> function_detail (LEVEL): function #%d ...', 0, 1, @function_num) with nowait
      begin tran
      begin try
         select @fd_id = isnull(max(fd_id), 0) + 1
         from dbo.function_detail
         insert into dbo.function_detail
              (fd_id,function_num,entity_name,attr_name,operation,entity_ind,trans_id)
           values(@fd_id, @function_num, 'LEVEL', NULL, NULL, 0, 1)
      end try
      begin catch
      	if @@trancount > 0
      	   rollback tran
      	set @errcode = ERROR_NUMBER()
      	set @smsg = ERROR_MESSAGE()
      	RAISERROR('=> Failed to add a function_detail record for the function_num ''%d'' due to the error:', 0, 1, @function_num) with nowait
      	RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
        goto nextfunc
      end catch
      RAISERROR('=> A function_detail record was successfully added for the function_num ''%d''.', 0, 1, @function_num) with nowait
     
      begin try
        select @fdv_id = isnull(max(fdv_id), 0) + 1
        from dbo.function_detail_value
        insert into dbo.function_detail_value
              (fdv_id,fd_id,data_type,attr_value,trans_id)
          values(@fdv_id, @fd_id, 'S', 'OWN', 1)
      end try
      begin catch
      	if @@trancount > 0
      	   rollback tran
      	set @errcode = ERROR_NUMBER()
      	set @smsg = ERROR_MESSAGE()
      	RAISERROR('=> Failed to add a function_detail_value record (OWN) for the function_num ''%s'' due to the error:', 0, 1, @function_num) with nowait
      	RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
        goto nextfunc
      end catch
      RAISERROR('=> A function_detail_value record (OWN) was successfully added for the function_num ''%d''.', 0, 1, @function_num) with nowait

      begin try
        select @fdv_id = @fdv_id + 1
        insert into dbo.function_detail_value
              (fdv_id,fd_id,data_type,attr_value,trans_id)
           values(@fdv_id, @fd_id, 'S', 'DEPT', 1)
      end try
      begin catch
      	if @@trancount > 0
      	   rollback tran
      	set @errcode = ERROR_NUMBER()
      	set @smsg = ERROR_MESSAGE()
      	RAISERROR('=> Failed to add a function_detail_value record (DEPT) for the function_num ''%s'' due to the error:', 0, 1, @function_num) with nowait
      	RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
        goto nextfunc
      end catch
      RAISERROR('=> A function_detail_value record (DEPT) was successfully added for the function_num ''%d''.', 0, 1, @function_num) with nowait
      
      begin try
        select @fdv_id = @fdv_id + 1
        insert into dbo.function_detail_value
              (fdv_id,fd_id,data_type,attr_value,trans_id)
           values(@fdv_id, @fd_id, 'S', 'ANY', 1)
      end try
      begin catch
      	if @@trancount > 0
      	   rollback tran
      	set @errcode = ERROR_NUMBER()
      	set @smsg = ERROR_MESSAGE()
      	RAISERROR('=> Failed to add a function_detail_value record (ANY) for the function_num ''%s'' due to the error:', 0, 1, @function_num) with nowait
      	RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
        goto nextfunc
      end catch
      RAISERROR('=> A function_detail_value record (ANY) was successfully added for the function_num ''%d''.', 0, 1, @function_num) with nowait
      commit tran
   end

nextfunc:
   select @function_num = min(function_num)
   from #tentags
   where function_num > @function_num   
end
go

if object_id('tempdb..#tentags', 'U') is not null
   exec('drop table #tentags')
go

exec dbo.refresh_a_last_num 'function_detail', 'fd_id'
go

exec dbo.refresh_a_last_num 'function_detail_value', 'fdv_id'
go
