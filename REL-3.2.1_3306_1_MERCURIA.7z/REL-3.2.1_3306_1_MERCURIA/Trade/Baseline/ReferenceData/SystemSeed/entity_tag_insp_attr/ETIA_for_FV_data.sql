set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading tag attributes owned by the ''ForecastValue'' entity into the ''entity_tag_insp_attr'' table ...'
go

declare @oid                     numeric(18, 0),
        @target_entity_id        int,
        @entity_id               int,
        @errcode                 int,
        @row_affected            int,
        @entity_tag_id           int,
        @entity_tag_attr_name    char(16),
        @entity_tag_attr_value   varchar(255),
        @entity_name             varchar(30),
        @target_entity_name      varchar(30),
        @smsg                    varchar(255),
        @entity_tag_name         varchar(16),
        @status                  int  


CREATE TABLE #tag_insp_attrs
(
   oid                     numeric(18, 0) IDENTITY,
   entity_tag_id           int              NOT NULL,
   entity_tag_attr_name    char(16)         NOT NULL,
   entity_tag_attr_value   varchar(255)     NOT NULL,
   entity_tag_name         varchar(16)      NULL,
   entity_name             varchar(30)      NULL
)
      
/* ENTITY : ForecastValue */
select @errcode = 0
select @entity_name = 'ForecastValue',
       @entity_id = null
       
if @entity_name is not null
begin
   exec @status = dbo.usp_find_entity_id @entity_name, @entity_id OUTPUT
   if @status > 0 or @entity_id is null
   begin
      select @smsg = 'Could not find the entity ''' + @entity_name + ''' in the icts_entity_name table!'
      print @smsg
      goto endofscript
   end
end
/* -------------------------------------------------------------------------- 
    TAG: ForecastBalQty
       entity_tag_id  entity_tag_attr_name  entity_tag_attr_value
       -------------  --------------------- ----------------------
       <oid>          RefInspName           Quantity
   -------------------------------------------------------------------------- */

print '=> Saving Attributes for the tag ''ForecastBalQty'' into temporary table ...'

select @target_entity_name = null,
       @target_entity_id = null,
       @entity_tag_name = 'ForecastBalQty'

exec @status = dbo.usp_find_entity_tag_id @target_entity_id, @entity_id, @entity_tag_name, @entity_tag_id OUTPUT
if @status > 0 or @entity_tag_id is null
begin
   select @smsg = 'Could not find the ID for the entity_tag_name ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''') in the entity_tag_definition table!'
   print @smsg
   goto endofscript
end

insert into #tag_insp_attrs
     (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, entity_tag_name, entity_name)
   values (@entity_tag_id, 'RefInspName', 'Quantity', @entity_tag_name, @entity_name)





print ' '
/* ******************************************************************** */
/* The code cody for adding records into the entity_tag_insp_attr table */
/* ******************************************************************** */

declare @tag_attr_value varchar(255)

select @oid = min(oid)
from #tag_insp_attrs

while @oid is not null
begin
   select @entity_tag_id = entity_tag_id,
          @entity_tag_attr_name = entity_tag_attr_name,
          @entity_tag_attr_value = entity_tag_attr_value,
          @tag_attr_value = case when entity_tag_attr_value is null
                                    then '%'
                                 else
                                    rtrim(entity_tag_attr_value) + '%'
                            end,
          @entity_tag_name = entity_tag_name,
          @entity_name = entity_name
   from #tag_insp_attrs
   where oid = @oid
   
   if not exists (select 1
                  from dbo.entity_tag_insp_attr
                  where entity_tag_id = @entity_tag_id and
                        entity_tag_attr_name = @entity_tag_attr_name)
   begin
      begin tran   
      insert into dbo.entity_tag_insp_attr
          (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
        values(@entity_tag_id, @entity_tag_attr_name, @entity_tag_attr_value, 1)
      select @row_affected = @@rowcount,
             @errcode = @@error
      if @errcode > 0 or @row_affected = 0
      begin
         if @@trancount > 0
            rollback tran
         if @errcode > 0
            goto endofscript
      end
      else
      begin
         commit tran
         select @smsg = '=> TAG ''' + @entity_tag_name + ''' (entity ''' + @entity_name + ''')'
         print @smsg
         select @smsg = '==> The attr name ''' + rtrim(@entity_tag_attr_name) + ''' was added successfully!' 
         print @smsg
      end  
   end
   else
   begin
      if not exists (select 1
                     from dbo.entity_tag_insp_attr
                     where entity_tag_id = @entity_tag_id and
                           entity_tag_attr_name = @entity_tag_attr_name and
                           entity_tag_attr_value like @tag_attr_value) 
      begin
         print '=> The following entity_tag_insp_attr record exists but with different attr value!'
         select @entity_tag_attr_value = entity_tag_attr_value
         from dbo.entity_tag_insp_attr
         where entity_tag_id = @entity_tag_id and
               entity_tag_attr_name = @entity_tag_attr_name
         print '==> entity_tag_name             = ' + @entity_tag_name + ' (' + cast(@entity_tag_id as varchar) + ')'
         print '==> entity_tag_attr_name        = ' + @entity_tag_attr_name
         print '==> entity_tag_attr_value       = ' + @entity_tag_attr_value
         print '==> entity_tag_attr_value (new) = ' + @tag_attr_value
         print ' '
      end         
   end
   
   select @oid = min(oid)
   from #tag_insp_attrs
   where oid > @oid       
end
endofscript:
drop table #tag_insp_attrs
go
