set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Adding new inspector attributes for the PORTFOLIO tags ...'
go

declare @entity_tag_id     int

select @entity_tag_id = oid
from dbo.entity_tag_definition
where entity_tag_name = 'TRADER'

if @entity_tag_id is not null
begin
	 if not exists (select 1
	                from dbo.entity_tag_insp_attr
	                where entity_tag_id = @entity_tag_id and
	                      entity_tag_attr_name = 'FormatterKey')
      insert into dbo.entity_tag_insp_attr
           (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
         values(@entity_tag_id, 'FormatterKey', 'userInit', 1)

	 if not exists (select 1
	                from dbo.entity_tag_insp_attr
	                where entity_tag_id = @entity_tag_id and
	                      entity_tag_attr_name = 'InspectorTitle')
      insert into dbo.entity_tag_insp_attr
           (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
         values(@entity_tag_id, 'InspectorTitle', 'Trader', 1)
    
	 if not exists (select 1
	                from dbo.entity_tag_insp_attr
	                where entity_tag_id = @entity_tag_id and
	                      entity_tag_attr_name = 'RefInspName')
      insert into dbo.entity_tag_insp_attr
           (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
         values(@entity_tag_id, 'RefInspName', 'IctsUser', 1)

	 if not exists (select 1
	                from dbo.entity_tag_insp_attr
	                where entity_tag_id = @entity_tag_id and
	                      entity_tag_attr_name = 'UserJobTitle')
      insert into dbo.entity_tag_insp_attr
           (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
         values(@entity_tag_id, 'UserJobTitle', 'TRADER', 1)

	 if not exists (select 1
	                from dbo.entity_tag_insp_attr
	                where entity_tag_id = @entity_tag_id and
	                      entity_tag_attr_name = 'UserJobTitle')
      insert into dbo.entity_tag_insp_attr
           (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
         values(@entity_tag_id, 'UserStatus', 'A', 1)           
end
else
   RAISERROR('Unable to find ID for the entity tag ''TRADER''!', 0, 1) with nowait
go

/* ************************************************************************** */
declare @entity_tag_id     int

select @entity_tag_id = oid
from dbo.entity_tag_definition
where entity_tag_name = 'BOOKCOMP'

if @entity_tag_id is not null
begin
	 if not exists (select 1
	                from dbo.entity_tag_insp_attr
	                where entity_tag_id = @entity_tag_id and
	                      entity_tag_attr_name = 'AcctStatus')
      insert into dbo.entity_tag_insp_attr
           (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
         values(@entity_tag_id, 'AcctStatus', 'A', 1)           

	 if not exists (select 1
	                from dbo.entity_tag_insp_attr
	                where entity_tag_id = @entity_tag_id and
	                      entity_tag_attr_name = 'AcctTypeCode')
      insert into dbo.entity_tag_insp_attr
           (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
         values(@entity_tag_id, 'AcctTypeCode', 'PEICOMP', 1)          

	 if not exists (select 1
	                from dbo.entity_tag_insp_attr
	                where entity_tag_id = @entity_tag_id and
	                      entity_tag_attr_name = 'FormatterKey')
      insert into dbo.entity_tag_insp_attr
           (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
         values(@entity_tag_id, 'FormatterKey', 'acctShortName', 1)          

	 if not exists (select 1
	                from dbo.entity_tag_insp_attr
	                where entity_tag_id = @entity_tag_id and
	                      entity_tag_attr_name = 'InspectorTitle')
      insert into dbo.entity_tag_insp_attr
           (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
         values(@entity_tag_id, 'InspectorTitle', 'Booking Company', 1)          

	 if not exists (select 1
	                from dbo.entity_tag_insp_attr
	                where entity_tag_id = @entity_tag_id and
	                      entity_tag_attr_name = 'RefInspName')
      insert into dbo.entity_tag_insp_attr
           (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
         values(@entity_tag_id, 'RefInspName', 'Account', 1)                     
end
else
   RAISERROR('Unable to find ID for the entity tag ''BOOKCOMP''!', 0, 1) with nowait
go

/* ************************************************************************** */
declare @smsg              varchar(255),
        @entity_tag_id     int,
        @rows_affected     int,
        @errcode           int,
        @entity_tag_name   varchar(16)
        
select @errcode = 0

create table #tags
(
   entity_tag_id      int 
)

insert into #tags
select etd.oid 
from dbo.entity_tag_definition etd, 
     dbo.icts_entity_name ien 
where ien.entity_name = 'Portfolio' and 
      ien.oid = etd.entity_id and 
      etd.entity_tag_name not in ('PortReconAmtTol', 'MaterialGroup')

select @entity_tag_id = min(entity_tag_id)
from #tags

while @entity_tag_id is not null
begin
   select @entity_tag_name = entity_tag_name
   from dbo.entity_tag_definition
   where oid = @entity_tag_id
      
   select @smsg = '=> Adding attribute ''RestrictSubClass'' for the entity tag ''' + @entity_tag_name + ''' ... '
   if not exists (select 1
                  from dbo.entity_tag_insp_attr
                  where entity_tag_id = @entity_tag_id and
                        entity_tag_attr_name = 'RestrictSubClass')
   begin      
      begin tran
      insert into dbo.entity_tag_insp_attr
           (entity_tag_id, entity_tag_attr_name, entity_tag_attr_value, trans_id)
         values(@entity_tag_id, 'RestrictSubClass', 'RealPortfolio', 1)
      select @rows_affected = @@rowcount,
             @errcode = @@error
      if @errcode > 0
      begin
         if @@trancount > 0
            rollback tran
         goto endofscript
      end
      commit tran
      if @rows_affected > 0
         select @smsg = @smsg + 'Added OK'
      else
         select @smsg = @smsg + 'Not Added???'
   end
   else
      select @smsg = @smsg + 'Added Already'
   print @smsg
      
   select @entity_tag_id = min(entity_tag_id)
   from #tags
   where entity_tag_id > @entity_tag_id
end
endofscript:
drop table #tags
go

