set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table state
go

print 'Loading seed reference data into the state table ...'
go

insert into dbo.state 
   values('AK', 'ALASKA', 50, NULL, 1)
go

insert into dbo.state 
   values('AL', 'ALABAMA', 1, NULL, 1)
go

insert into dbo.state 
   values('AR', 'ARKANSAS', 3, NULL, 1)
go

insert into dbo.state 
   values('AZ', 'ARIZONA', 2, NULL, 1)
go

insert into dbo.state 
   values('CA', 'CALIFORNIA', 4, NULL, 1)
go

insert into dbo.state 
   values('CO', 'COLORADO', 5, NULL, 1)
go

insert into dbo.state 
   values('CT', 'CONNECTICUT', 6, NULL, 1)
go

insert into dbo.state 
   values('DC', 'DIST. OF COLUMBIA', 8, NULL, 1)
go

insert into dbo.state 
   values('DE', 'DELAWARE', 7, NULL, 1)
go

insert into dbo.state 
   values('FL', 'FLORIDA', 9, NULL, 1)
go

insert into dbo.state 
   values('GA', 'GEORGIA', 10, NULL, 1)
go

insert into dbo.state 
   values('HI', 'HAWAII', 51, NULL, 1)
go

insert into dbo.state 
   values('IA', 'IOWA', 14, NULL, 1)
go

insert into dbo.state 
   values('ID', 'IDAHO', 11, NULL, 1)
go

insert into dbo.state 
   values('IL', 'ILLINOIS', 12, NULL, 1)
go

insert into dbo.state 
   values('IN', 'INDIANA', 13, NULL, 1)
go

insert into dbo.state 
   values('KS', 'KANSAS', 15, NULL, 1)
go

insert into dbo.state 
   values('KY', 'KENTUCKY', 16, NULL, 1)
go

insert into dbo.state 
   values('LA', 'LOUISIANA', 17, NULL, 1)
go

insert into dbo.state 
   values('MA', 'MASSACHUSETTS', 20, NULL, 1)
go

insert into dbo.state 
   values('MD', 'MARYLAND', 19, NULL, 1)
go

insert into dbo.state 
   values('ME', 'MAINE', 18, NULL, 1)
go

insert into dbo.state 
   values('MI', 'MICHIGAN', 21, NULL, 1)
go

insert into dbo.state 
   values('MN', 'MINNESOTA', 22, NULL, 1)
go

insert into dbo.state 
   values('MO', 'MISSOURI', 24, NULL, 1)
go

insert into dbo.state 
   values('MS', 'MISSISSIPPI', 23, NULL, 1)
go

insert into dbo.state 
   values('MT', 'MONTANA', 25, NULL, 1)
go

insert into dbo.state 
   values('NA', 'Not Applicable', 0, NULL, 1)
go

insert into dbo.state 
   values('NB', 'NEBRASKA', 26, NULL, 1)
go

insert into dbo.state 
   values('NC', 'NORTH CAROLINA', 32, NULL, 1)
go

insert into dbo.state 
   values('ND', 'NORTH DAKOTA', 33, NULL, 1)
go

insert into dbo.state 
   values('NH', 'NEW HAMPSHIRE', 28, NULL, 1)
go

insert into dbo.state 
   values('NJ', 'NEW JERSEY', 29, NULL, 1)
go

insert into dbo.state 
   values('NM', 'NEW MEXICO', 30, NULL, 1)
go

insert into dbo.state 
   values('NV', 'NEVADA', 27, NULL, 1)
go

insert into dbo.state 
   values('NY', 'NEW YORK', 31, NULL, 1)
go

insert into dbo.state 
   values('OH', 'OHIO', 34, NULL, 1)
go

insert into dbo.state 
   values('OK', 'OKLAHOMA', 35, NULL, 1)
go

insert into dbo.state 
   values('OR', 'OREGON', 36, NULL, 1)
go

insert into dbo.state 
   values('PA', 'PENNSYLVANIA', 37, NULL, 1)
go

insert into dbo.state 
   values('PR', 'PEURTO RICO', 52, NULL, 1)
go

insert into dbo.state 
   values('RI', 'RHODE ISLAND', 38, NULL, 1)
go

insert into dbo.state 
   values('SC', 'SOUTH CAROLINA', 39, NULL, 1)
go

insert into dbo.state 
   values('SD', 'SOUTH DAKOTA', 40, NULL, 1)
go

insert into dbo.state 
   values('TN', 'TENNESSEE', 41, NULL, 1)
go

insert into dbo.state 
   values('TX', 'TEXAS', 42, NULL, 1)
go

insert into dbo.state 
   values('UT', 'UTAH', 43, NULL, 1)
go

insert into dbo.state 
   values('VA', 'VIRGINIA', 45, NULL, 1)
go

insert into dbo.state 
   values('VI', 'VIRGIN ISLANDS (U.S.)', 0, NULL, 1)
go

insert into dbo.state 
   values('VT', 'VERMONT', 44, NULL, 1)
go

insert into dbo.state 
   values('WA', 'WASHINGTON', 46, NULL, 1)
go

insert into dbo.state 
   values('WI', 'WISCONSIN', 48, NULL, 1)
go

insert into dbo.state 
   values('WV', 'WEST VIRGINIA', 47, NULL, 1)
go

insert into dbo.state 
   values('WY', 'WYOMING', 49, NULL, 1)
go

insert into dbo.state 
   values('na', 'Not Appplicable', 0, NULL, 1)
go

