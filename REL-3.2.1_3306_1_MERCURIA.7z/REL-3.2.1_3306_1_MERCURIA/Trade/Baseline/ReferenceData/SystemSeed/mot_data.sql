set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the mot table ...'
go

create table #mots 
(
   mot_code                char(8)     primary key,
   mot_type_code           char(1)     NOT NULL,
   mot_short_name          varchar(15) NOT NULL,
   mot_full_name           varchar(40) NOT NULL,
   ppl_cycle_freq          char(1)     NULL,
   ppl_num_of_cycles       tinyint     NULL,
   ppl_split_cycle_ind     char(1)     NULL
)
go

print '=> Load mot record set #1 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select '-', 'V', '-', 'STAR BERGEN'
UNION ALL
select '1', 'V', '1', 'SINGA STAR'
UNION ALL
select '2', 'V', '2', 'ENALIOS ZERYPHOS'
UNION ALL
select '3', 'V', '3', 'ALANDIA SURF'
UNION ALL
select '4', 'V', '4', 'BONA SAILOR'
UNION ALL
select '5', 'V', '5', 'MOSOCEAN'
UNION ALL
select '6', 'V', '6', 'KIM JACOB'
UNION ALL
select '7', 'V', '7', 'ALANDIA LYNX'
UNION ALL
select '8', 'V', '8', 'ALANDIA ORIENT'
UNION ALL
select 'A ANTARE', 'V', 'ASTRO ANTARES', 'ASTRO ANTARES'
UNION ALL
select 'A ARCTUR', 'V', 'ASTRO ARCTURUS', 'ASTRO ARCTURUS' 
UNION ALL
select 'A G', 'V', 'ALFA GERMANIA', 'ALFA GERMANIA'
UNION ALL
select 'A P', 'V', 'ATLANTIC PROSPE', 'ATLANTIC PROSPERITY'
UNION ALL
select 'A PATRIO', 'V', 'ALANDIA PATRIOT', 'ALANDIA PATRIOT'
UNION ALL
select 'A SEA', 'V', 'ALANDIA SEA', 'ALANDIA SEA'
UNION ALL
select 'ACADIAN', 'P', 'ACADIAN GAS PIP', 'ACADIAN GAS PIPELINE'
UNION ALL
select 'AD', 'V', 'ANDROS GEORGIOS', 'ANDROS GEORGIOS'
UNION ALL
select 'ADAMAS', 'V', 'ADAMAS', 'ADAMAS'
UNION ALL
select 'AFID', 'V', 'ATHENIAN FIDELI', 'ATHENIAN FIDELITY' 
UNION ALL
select 'AFLOAT', 'S', 'AFLOAT', 'AFLOAT'
UNION ALL
select 'AGIPNAPO', 'V', 'AGIPNAPOLI', 'AGIPNAPOLI'
UNION ALL
select 'ALA-TEN', 'P', 'ALABAMA-TENNESS', 'ALABAMA-TENNESSEE NATURAL GAS'
UNION ALL
select 'ALANDIA', 'V', 'ALANDIA STREAM', 'ALANDIA STREAM'
UNION ALL
select 'ALBERTA', 'V', 'ALBERTA', 'ALBERTA'
UNION ALL
select 'ALEXAND', 'V', 'ALEXANDROS', 'ALEXANDROS'
go


print '=> Load mot record set #2 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'ALEXANDR', 'V', 'ALEXANDROS', 'ALEXANDR' 
UNION ALL
select 'ALFA BRI', 'V', 'ALFA BRITANNIA', 'ALFA BRITANNIA'
UNION ALL
select 'ALGONQ', 'P', 'ALGONQUIN GAS T', 'ALGONQUIN GAS TRANSMISSION'
UNION ALL
select 'ALIM', 'V', 'ALIM', 'ALIM' 
UNION ALL
select 'ALMANAMA', 'V', 'ALMANAMA', 'ALMANAMA' 
UNION ALL
select 'ALMARE O', 'V', 'AMARE OTTAWA', 'ALMARE OTTAWA'
UNION ALL
select 'AMOCO', 'P', 'AMOCO', 'AMOCO' 
UNION ALL
select 'AN FU', 'V', 'AN FU', 'AN FU'
UNION ALL
select 'ANDREAA', 'V', 'ANDREAA', 'ANDREAA' 
UNION ALL
select 'ANIA', 'V', 'ANIA', 'ANIA'
UNION ALL
select 'ANR', 'P', 'ANR PIPELINE CO', 'ANR PIPELINE COMPANY'
UNION ALL
select 'ANTIPARO', 'V', 'ANTIPAROS', 'ANTIPAROS' 
UNION ALL
select 'ANWIJA', 'V', 'ANWIJA', 'ANWIJA' 
UNION ALL 
select 'ARCO', 'P', 'ARCO', 'ARCO PIPELINE'
UNION ALL
select 'ARCTICSW', 'V', 'ARCTIC SWAN', 'ARCTIC SWAN' 
UNION ALL
select 'ARDENNE', 'V', 'ARDENNE', 'ARDENNE' 
UNION ALL
select 'ARGIRONI', 'V', 'ARGIRONISSOS', 'ARGIRONISSOS' 
UNION ALL
select 'ARKLA', 'P', 'ARKLA ENERGY RE', 'ARKLA ENERGY RESOURCES' 
UNION ALL 
select 'ARTEMIS', 'V', 'ARTEMIS', 'ARTEMIS'
UNION ALL 
select 'ASARI', 'V', 'ASARI', 'ASARI' 
UNION ALL 
select 'ASTRA', 'V', 'ASTRA', 'ASTRA' 
UNION ALL 
select 'ASTRO CA', 'V', 'ASTRO CANOPUS', 'ASTRO CANOPUS' 
UNION ALL 
select 'ASTRO SI', 'V', 'ASTROSIRIUS', 'ASTRO SIRIUS' 
UNION ALL 
select 'ATH BEAU', 'V', 'ATHENIAN BEAUTY', 'ATHENIAN BEAUTY' 
UNION ALL
select 'ATHENIAN', 'V', 'ATHENIAN CHARM', 'ATHENIAN CHARM' 
UNION ALL
select 'ATL SERV', 'V', 'ATLANTIC SERVIC', 'ATLANTIC SERVICE' 
UNION ALL
select 'ATL SUP', 'S', 'ATLANTIC SUPPLI', 'ATLANTIC SUPPLIER' 
UNION ALL
select 'ATL TRAD', 'S', 'ATLANTIC TRADER', 'ATLANTIC TRADER' 
UNION ALL
select 'ATL TRAN', 'S', 'ATLANTIC TRANSP', 'ATLANTIC TRANSPORT'
UNION ALL
select 'ATLANTIC', 'V', 'ATLANTIC TRADER', 'ATLANTIC TRADER' 
UNION ALL
select 'ATLLIB', 'V', 'ATLANTIC LIBERT', 'ATLANTIC LIBERTY' 
UNION ALL
select 'ATLNTSPL', 'B', 'ATLANTIC SUPPLI', 'BARGE/ATLANTIC SUPPLIER' 
UNION ALL
select 'AVV', 'V', 'ATHENIAN VICTOR', 'ATHENIAN VICTORY' 
UNION ALL
select 'AXX', 'V', 'ATHENIAN XENOPH', 'ATHENIAN XENOPHON' 
UNION ALL
select 'AYBERK', 'V', 'AYBERK KALKAVAN', 'AYBERK KALKAVAN' 
go

print '=> Load mot record set #3 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'B 165', 'V', 'B 165', 'B 165' 
UNION ALL
select 'B RIDER', 'V', 'BONA RIDER', 'BONA RIDER' 
UNION ALL
select 'BARGE', 'B', 'BARGE', 'BARGE'
UNION ALL
select 'BARGEGO', 'B', 'BARGE GASOIL', 'BARGE GASOIL BARGES'
UNION ALL
select 'BERYL', 'V', 'BERYL', 'BERYL' 
UNION ALL
select 'BH', 'V', 'BERGE HUS', 'BERGE HUS' 
UNION ALL
select 'BLANC', 'V', 'BLANC', 'BLANC' 
UNION ALL
select 'BRABANT', 'V', 'BRABANT', 'BRABANT' 
UNION ALL
select 'BRAVUR', 'V', 'BRAVUR', 'BRAVUR'
UNION ALL
select 'BRIDGEL', 'P', 'BRIDGELINE GAS', 'BRIDGELINE GAS DISTRIBUTION' 
UNION ALL
select 'BRO STAR', 'V', 'BRO STAR', 'BRO STAR' 
UNION ALL
select 'BT', 'V', 'BRITISH VIGILAN', 'BRITISH VIGILANCE' 
UNION ALL
select 'BT STREA', 'V', 'BT STREAM', 'BT STREAM'
UNION ALL
select 'BUCKEYE', 'P', 'BUCKEYE', 'BUCKEYE PIPELINE' 
UNION ALL
select 'BULDRI', 'V', 'BULDURI', 'BULDURI' 
UNION ALL
select 'BULDURI', 'V', ' BULDURI', 'BULDURI'
UNION ALL
select 'BUNA', 'V', 'BUNA', 'BUNA' 
UNION ALL
select 'BURGAS', 'V', 'BURGAS', 'BURGAS' 
UNION ALL
select 'Brit Tam', 'V', 'British Tamar', 'BRITISH TAMAR' 
go

print '=> Load mot record set #4 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'C KNUTSE', 'V', 'CATHERINE KUNTS', 'CATHERINE KNUTSEN' 
UNION ALL
select 'CAITHNES', 'V', 'CAITHNESS', 'CAITHNESS'
UNION ALL
select 'CALENDUL', 'V', 'CALENDULA 10', 'CALENDULA 10' 
UNION ALL
select 'CAPE', 'V', 'CAPE BLANC', 'CAPE BLANC' 
UNION ALL
select 'CAPLINE', 'P', 'CAPLINE', 'CAPLINE' 
UNION ALL 
select 'CAPTAIN', 'V', 'CAPTAIN X KYRIA', 'CAPTAIN  X KYRIAKOU'
UNION ALL 
select 'CELTICA', 'V', 'CELTICA', 'CELTICA'
UNION ALL
select 'CENTAUR', 'V', 'CENTAUR', 'CENTAUR'
UNION ALL
select 'CIG', 'P', 'COLORADO INTERS', 'COLORADO INTERSTATE GAS' 
UNION ALL
select 'CIRCLE O', 'V', 'CIRCLE OUT', 'CIRCLE OUT' 
UNION ALL
select 'CNGTRANS', 'P', 'CNG TRANSMISSIO', 'CNG TRANSMISSION'
UNION ALL
select 'COLGAS', 'P', 'COLUMBIA GAS TR', 'COLUMBIA GAS TRANSMISSION' 
UNION ALL 
select 'COLGULF', 'P', 'COLUMBIA GULF T', 'COLUMBIA GULF TRANSMISSION' 
UNION ALL 
select 'COMMUTER', 'V', 'COMMUTER', 'COMMUTER'
UNION ALL
select 'CONCORD', 'V', 'CONCORD', 'CONCORD' 
UNION ALL 
select 'CONGER', 'V', 'CONGER', 'CONGER'
UNION ALL 
select 'CROMA', 'V', 'CROMA', 'CROMA' 
go

print '=> Load mot record set #5 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'DAINA', 'V', 'DAINA', 'DAINA' 
UNION ALL
select 'DALANAES', 'V', 'DALANAES', 'DALANAES' 
UNION ALL 
select 'DALNATI', 'V', 'DALNATI', 'DALNATI' 
UNION ALL 
select 'DELHI', 'P', 'DELHI PIPELINE', 'DELHI PIPELINE' 
UNION ALL 
select 'DELTA', 'V', 'DELTA', 'DELTA' 
UNION ALL 
select 'DIANA', 'V', 'DIANA', 'DIANA' 
UNION ALL 
select 'DOWINTRA', 'P', 'DOW INTRASTATE', 'DOW INTRASTATE GAS'
UNION ALL 
select 'DUBULTI', 'V', 'DUBULTI', 'DUBULTI' 
go

print '=> Load mot record set #6 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name) 
select 'E', 'V', 'EATON', 'EATON' 
UNION ALL 
select 'E AFRICA', 'V', 'ECO AFRICA', 'ECO AFRICA'
UNION ALL 
select 'E EUROPA', 'V', 'ECO EUROPA', 'ECO EUROPA'
UNION ALL 
select 'EBERHARD', 'V', 'EBERHARD', 'EBERHARD' 
UNION ALL
select 'EILT', 'V', 'EILTANK 50', 'EILTANK 50' 
UNION ALL 
select 'EILTAN', 'V', 'EILTANK 15', 'EILTANK 15' 
UNION ALL 
select 'EILTANK', 'V', 'EILTANK 23', 'EILTANK 23'
UNION ALL 
select 'EK CLOUD', 'V', 'EK CLOUD', 'EK CLOUD'
UNION ALL
select 'EK FJORD', 'V', 'EK FJORD', 'EK FJORD' 
UNION ALL
select 'EKTURUS', 'V', 'EKTURUS', 'EKTURUS' 
UNION ALL
select 'ELAINE', 'V', 'ELAINE', 'ELAINE'
UNION ALL
select 'ELHANI', 'V', 'ELHANI', 'ELHANI'
UNION ALL
select 'ELIANNE', 'V', 'ELIANNE', 'ELIANNE' 
UNION ALL
select 'ELPASO', 'P', 'EL PASO NATURAL', 'EL PASO NATURAL GAS' 
UNION ALL
select 'EM', 'V', 'EVELYN MAERSK', 'EVELYN MAERSK' 
UNION ALL
select 'EMERALD', 'V', 'EMERALD STAR', 'EMERALD STAR' 
UNION ALL
select 'EMPIRE', 'P', 'EMPIRE PIPELINE', 'EMPIRE STATE PIPELINE' 
UNION ALL
select 'ENERGIE', 'V', 'ENERGIE 11', 'ENERGIE 11' 
UNION ALL
select 'EOTT', 'S', 'EOTT', 'EOTT Terminal' 
UNION ALL
select 'EQUI', 'P', 'EQUITRANS', 'EQUITRANS'
UNION ALL
select 'ERATI', 'V', 'ERATI', 'ERATI' 
UNION ALL
select 'ESTELLA', 'V', 'ESTELLA', 'ESTELLA'
UNION ALL
select 'ETEN', 'P', 'EAST TENNESSEE', 'EAST TENNESSEE'
UNION ALL
select 'EUROPOOR', 'V', 'EUROPOORT', 'EUROPOORT' 
go

print '=> Load mot record set #8 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name) 
select 'F MAPLE', 'V', 'FRONT MAPLE', 'FRONT MAPLE'
UNION ALL
select 'FA', 'V', 'FRONT ARCHER', 'FRONT ARCHER' 
UNION ALL
select 'FAIR SKI', 'V', 'FAIR SKIES', 'FAIR SKIES' 
UNION ALL
select 'FLORIDA', 'P', 'FLORIDA GAS TRA', 'FLORIDA GAS TRANSMISSION' 
UNION ALL
select 'FNDTRNSF', 'P', 'FUND TRANSFER', 'FUND TRANSFER' 
UNION ALL
select 'FOOT', 'P', 'FOOTHILLS PIPEL', 'FOOTHILLS PIPELINES' 
UNION ALL
select 'FOUR WIN', 'V', 'FOUR WINDS', 'FOUR WINDS' 
UNION ALL
select 'FP', 'V', 'FRONT PRIDE', 'FRONT PRIDE' 
UNION ALL
select 'FREDERIQ', 'V', 'FREDERIQUE', 'FREDERIQUE' 
UNION ALL
select 'FRONT WA', 'V', 'FRONT WARRIOR', 'FRONT WARRIOR' 
UNION ALL
select 'FRYKEN', 'V', 'FRYKEN', 'FRYKEN' 
UNION ALL
select 'FUTURA', 'V', 'FUTURA', 'FUTURA' 
go

print '=> Load mot record set #9 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name) 
select 'G F', 'V', 'G FOUNTAIN', 'GOLDEN FOUNTAIN' 
UNION ALL
select 'G SPIRIT', 'V', 'GOTLAND SPIRIT', 'GOTLAND SPIRIT' 
UNION ALL
select 'GATE', 'P', 'GATEWAY PIPELIN', 'GATEWAY PIPELINE' 
UNION ALL
select 'GB', 'V', 'GOLAR DUNDEE', 'GOLAR DUNDEE' 
UNION ALL
select 'GELOVANI', 'V', 'GELOVANI', 'GELOVANI' 
UNION ALL
select 'GEROI CH', 'V', 'GEROI CHERNOMYR', 'GEROI CHERNOMYRA' 
UNION ALL
select 'GLEN ROY', 'V', 'GLEN ROY', 'GLEN ROY' 
UNION ALL
select 'GLENROSS', 'V', 'GLENROSS', 'GLENROSS' 
UNION ALL
select 'GOLDRIVE', 'V', 'GOLDRIVER', 'GOLDRIVER' 
UNION ALL
select 'GREATLAK', 'P', 'GREAT LAKES GAS', 'GREAT LAKES GAS TRANSMISSION' 
UNION ALL
select 'GRIZZLY', 'V', 'GRIZZLY', 'GRIZZLY' 
UNION ALL
select 'GS', 'V', 'GOLAR STIRLING', 'GOLAR STIRLING'
UNION ALL
select 'GULF GRA', 'V', 'GULF GRACE', 'GULF GRACE'
UNION ALL
select 'Greda', 'V', 'Greda', 'Greda' 
go

print '=> Load mot record set #10 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name) 
select 'H S', 'V', 'HAMANE SPIRIT', 'HAMANE SPIRIT' 
UNION ALL
select 'HARTING', 'V', 'HARTING', 'HARTING'
UNION ALL
select 'HERMES', 'V', 'HERMES', 'HERMES' 
UNION ALL
select 'HIOS', 'P', 'HIGH ISLAND OFF', 'HIGH ISLAND OFFSHIRE' 
UNION ALL
select 'HOBBY', 'V', 'HOBBY', 'HOBBY'
UNION ALL
select 'HPL', 'P', 'HOUSTON PIPELIN', 'HOUSTON PIPELINE'
UNION ALL
select 'HWD-2522', 'V', 'HWD-2522', 'HWD-2522' 
UNION ALL
select 'ICARO', 'V', 'ICARO', 'ICARO' 
UNION ALL
select 'IN-TANK', 'V', 'IN-TANK', 'IN-TANK' 
UNION ALL
select 'INAGO', 'V', 'INAGO', 'INAGO' 
UNION ALL
select 'INO', 'V', 'INO', 'INO' 
UNION ALL
select 'IPE', 'V', 'IPE', 'IPE' 
UNION ALL
select 'IRAN SAR', 'V', 'IRAN SARVESTAN', 'IRAN SARVESTAN' 
UNION ALL
select 'IROQ', 'P', 'IROQUOIS GAS TR', 'IROQUOIS GAS TRANS' 
UNION ALL
select 'ISOLA GI', 'V', 'ISOLA GIALLA', 'ISOLA GIALLA'
UNION ALL
select 'ISOLA TU', 'V', 'ISOLA TURCHESE', 'ISOLA TURCHESE' 
UNION ALL
select 'JAG L', 'V', 'JAG LAADKI', 'JAG LAADKI' 
UNION ALL
select 'JANIS SU', 'V', 'JANIS SUDRABKAL', 'JANIS SUDRABKALNS'
UNION ALL
select 'JERNAVIK', 'V', 'JERNAVIK', 'JERNAVIK' 
UNION ALL
select 'JULIA', 'V', 'JULIA', 'JULIA'
go

print '=> Load mot record set #11 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'KAM', 'V', 'KAMLESH', 'KAMLESH' 
UNION ALL
select 'KASTELOR', 'V', 'KASTELORIZO', 'KASTELORIZO'
UNION ALL
select 'KATJA', 'V', 'KATJA', 'KATJA' 
UNION ALL
select 'KERN', 'P', 'KERN RIVER GAS', 'KERN RIVER GAS TRANS' 
UNION ALL
select 'KGPC', 'P', 'KOCH GATEWAY PI', 'KOCH GATEWAY PIPELINE CO.' 
UNION ALL
select 'KIHU', 'V', 'KIHU', 'KIHU' 
UNION ALL
select 'KIRSTEN', 'V', 'KIRSTEN', 'KIRSTEN' 
UNION ALL
select 'KNEN', 'P', 'KN ENERGY', 'KN ENERGY' 
UNION ALL
select 'KNOCK AN', 'V', 'KNOCK AN', 'KNOCK AN' 
UNION ALL
select 'KONSTANT', 'V', 'KONSTANTINOS D', 'KONSTANTINOS D' 
UNION ALL
select 'KRONVIKE', 'V', 'KRONVIKEN', 'KRONVIKEN' 
UNION ALL
select 'KTC155', 'V', 'KTC 155', 'KTC 155' 
UNION ALL
select 'L SAILOR', 'V', 'LUCKY SAILOR', 'LUCKY SAILOR' 
UNION ALL
select 'L SPIRIT', 'V', 'LUZON SPIRIT', 'LUZON SPIRIT' 
UNION ALL
select 'LAND ANG', 'V', 'LAND ANGEL', 'LAND ANGEL' 
UNION ALL
select 'LAURA', 'V', 'LAURA', 'LAURA' 
UNION ALL
select 'LIG', 'P', 'LOUISIANA INTRA', 'LOUISIANA INTRASTATE GAS' 
UNION ALL
select 'LONDON I', 'V', 'LONDON II', 'LONDON II'
UNION ALL
select 'LONE', 'P', 'LONE STAR GAS', 'LONE STAR GAS' 
UNION ALL
select 'LRC', 'P', 'LOUISIANA RESOU', 'LOUISIANA RESOURCES COMPANY' 
UNION ALL
select 'LUKOIL 2', 'V', 'LUKOIL 2', 'LUKOIL 2' 
UNION ALL
select 'M RIVER', 'V', 'MOSCOW RIVER', 'MOSCOW RIVER' 
UNION ALL
select 'MAERSK B', 'V', 'MAERSK BOTHNIA', 'MAERSK BOTHNIA' 
UNION ALL
select 'MAINLINE', 'P', 'MAINLINE PIPELI', 'MAINLINE PIPELINE (UK)'
UNION ALL
select 'MAJORI', 'V', 'MAJORI', 'MAJORI'
UNION ALL
select 'MANTINIA', 'V', 'MANTINIA', 'MANTINIA'
UNION ALL
select 'MAR', 'V', 'MAR', 'MAR'
UNION ALL
select 'MARBLE', 'V', 'MARBLE', 'MARBLE' 
UNION ALL
select 'MARIA TS', 'V', 'MARIA TSAKOS', 'MARIA TSAKOS' 
UNION ALL
select 'MARSHAL', 'V', 'MARSHAL VASILEV', 'MARSHAL VASILEVSKIY' 
UNION ALL
select 'MASTERA', 'V', 'MASTERA', 'MASTERA' 
UNION ALL
select 'MED PROL', 'V', 'MED PROLOGUE', 'MED PROLOGUE' 
UNION ALL
select 'MEKHANIK', 'V', 'MEKHANIK SLAUGH', 'MEKHANIK SLAUGHTA' 
UNION ALL
select 'MERIOM S', 'V', 'MERIOM STAR', 'MERIOM STAR' 
UNION ALL
select 'METEORA', 'V', 'METEORA', 'METEORA' 
UNION ALL
select 'MGT', 'P', 'MIDWESTERN GAS', 'MIDWESTERN GAS TRANS' 
UNION ALL
select 'MICHCON', 'P', 'MICHCON PIPE', 'MICHCON PIPELINE'
UNION ALL
select 'MID-LA', 'P', 'MID-LOUISIANA G', 'MID-LOUISIANA GAS' 
UNION ALL
select 'MONTEREY', 'P', 'MONTEREY PIPELI', 'MONTEREY PIPELINE' 
UNION ALL
select 'MOSK', 'V', 'MOSK', 'MOSKOVSKIY FESTIVAL' 
UNION ALL
select 'MOT', 'V', 'SKAUFAST', 'SKAUFAST'
UNION ALL
select 'MPRINCES', 'V', 'MARE PRINCESS', 'MARE PRINCESS'
UNION ALL
select 'MRT', 'P', 'MISSISSIPPI RIV', 'MISSISSIPPI RIVER TRANSMISSION'
UNION ALL
select 'MYSTRAS', 'V', 'MYSTRAS II', 'MYSTRAS II'
UNION ALL
select 'N PACIFI', 'V', 'NORTH PACIFIC', 'NORTH PACIFIC' 
UNION ALL
select 'N S', 'V', 'NAVION SCOTIA', 'NAVION SCOTIA' 
UNION ALL
select 'N STAR', 'V', 'NORTH STAR', 'NORTH STAR' 
UNION ALL
select 'N SVENIT', 'V', 'NORDIC SVENITA', 'NORDIC SVENITA' 
UNION ALL
select 'N WISDOM', 'V', 'NEW WISDOM', 'NEW WISDOM' 
UNION ALL
select 'NAGATINO', 'V', 'NAGATINO', 'NAGATINO' 
UNION ALL
select 'NANNY', 'V', 'NANNY', 'NANNY' 
UNION ALL
select 'NATFUEL', 'P', 'NATIONAL FUEL G', 'NATIONAL FUEL GAS SUPPLY' 
UNION ALL
select 'NATURA', 'V', 'NATURA', 'NATURA'
UNION ALL
select 'NECHES', 'P', 'NECHES PIPELINE', 'NECHES PIPELINE' 
go

print '=> Load mot record set #12 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'NEW WIZD', 'V', 'NEW WIZDOM', 'NEW WIZDOM' 
UNION ALL
select 'NGPL', 'P', 'NATURAL GAS PIP', 'NATURAL GAS PIPELINE COMP' 
UNION ALL
select 'NIGAS', 'P', 'N. ILLINOIS GAS', 'NORTHERN ILLINOIS GAS CO.' 
UNION ALL
select 'NIPAYIA', 'V', 'NIPAYIA', 'NIPAYIA' 
UNION ALL
select 'NIPSCO', 'P', 'N. INDIANA PUBL', 'NORTHERN INDIANA PUBLIC SERVICE CO.' 
UNION ALL
select 'NO', 'V', 'NEPTUNE OTOME', 'NEPTUNE OTOME' 
UNION ALL
select 'NORBOARD', 'P', 'NORTHERN BOARDE', 'NORTHERN BOARDER PIPELINE'
UNION ALL
select 'NORDIC L', 'V', 'NORDIC LIBERITA', 'NORDIC LIBERITA' 
UNION ALL
select 'NORDIC T', 'V', 'NORDIC TORINITA', 'NORDIC TORINITA' 
UNION ALL
select 'NORISSIA', 'V', 'NORRISIA', 'NORISSIA' 
UNION ALL
select 'NORNAT', 'P', 'NORTHERN NATURA', 'NORTHERN NATURAL GAS'
UNION ALL
select 'NORTHIA', 'V', 'NORTHIA', 'NORTHIA' 
UNION ALL
select 'NORWEST', 'P', 'NORTHWEST PIPEL', 'NORTHWEST PIPELINE' 
UNION ALL
select 'NOVA', 'P', 'NOVA CORPORATIO', 'NOVA CORPORATION' 
UNION ALL
select 'NSD', 'V', 'NORTH SEA DOWEL', 'NORTH SEA DOWEL' 
UNION ALL
select 'O FAITH', 'V', 'OLYMPIC FAITH', 'OLYMPIC FAITH' 
UNION ALL
select 'O SPIRIT', 'V', 'ORKNEY SPIRIT', 'ORKNEY SPIRIT' 
UNION ALL
select 'OCEANIDA', 'V', 'OCEANIDA', 'OCEANIDA' 
UNION ALL
select 'ODERSTER', 'V', 'ODERSTERN', 'ODERSTERN' 
UNION ALL
select 'OMEGA VE', 'V', 'OMEGA VENTURE L', 'OMEGA VENTURE L' 
UNION ALL
select 'OMEGAVEN', 'S', 'OMEGAVENTUREL', 'OMEGAVENTUREL' 
UNION ALL
select 'OMIKR', 'V', 'OMIKRONVENTURE', 'OMIKRONVENTURE L' 
UNION ALL
select 'ONG', 'P', 'OKLAHOMA NATURA', 'OKLAHOMA NATURAL GAS' 
UNION ALL
select 'OPALIA', 'V', 'OPALIA', 'OPALIA' 
UNION ALL
select 'P RUBY', 'V', 'PACIFIC RUBY', 'PACIFIC RUBY' 
UNION ALL
select 'PACIFIC', 'V', 'PACIFIC SAPPHIR', 'PACIFIC SAPPHIRE'
UNION ALL
select 'PALVA', 'V', 'PALVA', 'PALVA' 
UNION ALL
select 'PANAREA', 'V', 'PANAREA', 'PANAREA' 
UNION ALL
select 'PELICAN', 'P', 'PELICAN INTERST', 'PELICAN INTERSTATE GAS SYSTEM' 
UNION ALL
select 'PEPL', 'P', 'PANHANDLE EASTE', 'PANHANDLE EASTERN PIPELINE' 
UNION ALL
select 'PETR', 'V', 'PETR SCHMIDT', 'PETR SCHMIDT' 
UNION ALL
select 'PETROSKA', 'V', 'PETROSKALD', 'PETROSKALD' 
UNION ALL
select 'PETRSHMI', 'V', 'PETR SCHMIDT', 'PETR SHMIDT' 
UNION ALL
select 'PGT', 'P', 'PACIFIC GAS TRA', 'PACIFIC GAS TRANSMISSION' 
UNION ALL
select 'PIPE', 'P', 'PIPELINE', 'PIPELINE' 
UNION ALL
select 'PLAINSTE', 'S', 'PLAINS TERMINAL', 'PLAINS TERMINAL CUSHING, OK' 
UNION ALL
select 'PLANTAT', 'P', 'PLANTAT', 'PLANTATION PIPELINE' 
UNION ALL
select 'POLAR', 'V', 'POLAR', 'POLAR' 
UNION ALL
select 'POMTHULE', 'V', 'POM THULE', 'POM THULE'
UNION ALL
select 'POWER', 'P', 'POWER LINE', 'POWER LINE' 
UNION ALL
select 'PRIMERA', 'V', 'PRIMERA', 'PRIMERA'
UNION ALL
select 'PROSPECT', 'V', 'PROSPECT', 'PROSPECT' 
UNION ALL
select 'PSARA', 'V', 'PSARA', 'PSARA'
UNION ALL
select 'PUMPURI', 'V', 'PUMPURI', 'PUMPURI' 
UNION ALL
select 'QSTR', 'P', 'QUESTAR PIPELIN', 'QUESTAR PIPELINE'
go

print '=> Load mot record set #13 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'RADWAN', 'V', 'RADWAN', 'RADWAN'
UNION ALL
select 'RAIL', 'R', 'RAIL', 'RAIL CAR' 
'0'UNION ALL
select 'RAMONA', 'V', 'RAMONA', 'RAMONA' 
UNION ALL
select 'RANKKI', 'V', 'RANKKI', 'RANKKI' 
UNION ALL
select 'REGENT P', 'V', 'REGENT PARK', 'REGENT PARK'
UNION ALL
select 'ROBIJN', 'V', 'ROBIJN', 'ROBIJN' 
UNION ALL
select 'RP BRUSS', 'V', 'RP BRUSSEL', 'RP BRUSSEL' 
UNION ALL
select 'RPANTWER', 'V', 'RP ANTWERPEN', 'RP ANTWERPEN'
UNION ALL
select 'S COMPAS', 'V', 'STENA COMPASS', 'STENA COMPASS' 
UNION ALL
select 'S CONST', 'V', 'STELLA CONSTELL', 'STELLA CONSTELLATION' 
UNION ALL
select 'S TRADER', 'V', 'SANKO TRADER', 'SANKO TRADER'
UNION ALL
select 'SABINE', 'P', 'SABINE PIPELINE', 'SABINE PIPELINE' 
UNION ALL
select 'SAKOERA', 'V', 'SAKOERA', 'SAKOERA' 
UNION ALL
select 'SANFELIX', 'V', 'SANFELIX', 'SANFELIX' 
UNION ALL
select 'SANTALUC', 'V', 'SANTA LUCIA', 'SANTA LUCIA' 
UNION ALL
select 'SCARLET', 'V', 'SCARLET STAR', 'SCARLET STAR' 
UNION ALL
select 'SCORPIOU', 'V', 'SCORPIOUS', 'SCORPIOUS' 
UNION ALL
select 'SEAFORD', 'V', 'SEAFORD', 'SEAFORD' 
UNION ALL
select 'SEALADY', 'V', 'SEALADY', 'SEALADY' 
go

print '=> Load mot record set #14 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'SEAPR', 'V', 'SEA PROMISE', 'SEA PROMISE' 
UNION ALL
select 'SEAROB', 'P', 'SEA ROBIN PIPEL', 'SEA ROBIN PIPELINE' 
UNION ALL
select 'SEATURBO', 'V', 'SEATURBOT', 'SEATURBOT' 
UNION ALL
select 'SERICATA', 'V', 'SERICATA', 'SERICATA'
UNION ALL
select 'SHAMAKHY', 'V', 'SHAMAKHY', 'SHAMAKHY' 
UNION ALL
select 'SHCH', 'P', 'SHIP CHANNEL', 'SHIP CHANNEL'
UNION ALL
select 'SHUTTANK', 'V', 'SHUTTLE TANKER', 'SHUTTLE TANKER' 
UNION ALL
select 'SIBONATA', 'V', 'SIBONATA', 'SIBONATA' 
UNION ALL
select 'SITAMIA', 'V', 'SITAMIA', 'SITAMIA' 
UNION ALL
select 'SKS', 'V', 'SKS TRINITY', 'SKS TRINITY' 
UNION ALL
select 'SKS B', 'V', 'SKS BANNER', 'SKS BANNER' 
UNION ALL
select 'SKS TWEE', 'V', 'SKS TWEED', 'SKS TWEED' 
UNION ALL
select 'SOMBRA', 'V', 'SOMBRA', 'SOMBRA' 
UNION ALL
select 'SONAT', 'P', 'SOUTHERN NATURA', 'SOUTHERN NATURAL GAS' 
UNION ALL
select 'SP', 'V', 'SHANNON SPIRIT', 'SHANNON SPIRIT'
UNION ALL
select 'SPECTRUM', 'V', 'SPECTRUM', 'SPECTRUM'
UNION ALL
select 'SPIRIT', 'V', 'SPIRIT', 'SPIRIT'
UNION ALL
select 'SPIRITE', 'V', 'SPIRITE E', 'SPIRITE E' 
UNION ALL
select 'SPYROS', 'V', 'SPYROS', 'SPYROS' 
UNION ALL
select 'SR', 'V', 'STENA SIRITA', 'STENA SIRITA' 
UNION ALL
select 'SS', 'V', 'SEASPRITE', 'SEASPRITE' 
UNION ALL
select 'ST  PETE', 'V', 'ST PETERSBURG', 'ST PETERSBURG' 
UNION ALL
select 'ST NICK', 'V', 'ST NICHOLAS II', 'ST NICHOLAS II'
UNION ALL
select 'ST. NICH', 'V', 'ST. NICHOLAS', 'ST. NICHOLAS' 
UNION ALL
select 'STARBRG', 'V', 'STARBERGEN', 'STARBERGEN' 
UNION ALL
select 'STAVTANK', 'V', 'STAVTANK', 'STAVTANK' 
go

print '=> Load mot record set #15 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'STELAPOL', 'V', 'STELLA POLARIS', 'STELLA POLARIS' 
UNION ALL
select 'STENA', 'V', 'STENA CONSTELLA', 'STENA CONSTELLATION' 
UNION ALL
select 'STINGRAY', 'P', 'STINGRAY PIPELI', 'STINGRAY PIPELINE' 
UNION ALL
select 'STOCK TR', 'P', 'STOCK TRANSFER', 'STOCK TRANSFER'
UNION ALL
select 'STOCKTRA', 'V', 'STOCKTRANSFER', 'STOCKTRANSFER'
UNION ALL
select 'STORAGE', 'S', 'STORAGE', 'STORAGE'
UNION ALL
select 'SU', 'V', 'SOVEREIGN UNITY', 'SOVEREIGN UNITY' 
UNION ALL
select 'SYNERGOS', 'V', 'SYNERGOS', 'SYNERGOS' 
UNION ALL
select 'Sun Rive', 'V', 'Sun River', 'SUN RIVER'
UNION ALL
select 'T-2055', 'V', 'T-2055', 'T-2055'
UNION ALL
select 'TALAVA', 'V', 'TALAVA', 'TALAVA' 
UNION ALL
select 'TANK T20', 'V', 'TANK T2080', 'TANK T2080'
UNION ALL
select 'TARNSUND', 'V', 'TARNSUND', 'TARNSUND'
UNION ALL
select 'TBN', 'V', 'TBN', 'TBN' 
UNION ALL
select 'TCPL', 'P', 'TRANSCANADA PIP', 'TRANSCANADA PIPELINE' 
UNION ALL
select 'TEEKAY F', 'V', 'TEEKAY FORTUNA', 'TEEKAY FORTUNA' 
UNION ALL
select 'TELLUS', 'V', 'TELLUS', 'TELLUS' 
go

print '=> Load mot record set #16 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'TENN', 'P', 'TENNESSEE GAS P', 'TENNESSEE GAS PIPELINE' 
UNION ALL
select 'TENN500', 'P', 'TENNESSEE 500 L', 'TENNESSEE 500 PIPELINE' 
UNION ALL
select 'TENN800', 'P', 'TENNESSEE 800 L', 'TENNESSEE 800 PIPELINE'
UNION ALL
select 'TERVI', 'V', 'TERVI', 'TERVI' 
UNION ALL
select 'TETCO', 'P', 'TEXAS EASTERN G', 'TEXAS EASTERN GAS PIPELINE' 
UNION ALL
select 'TEXASGAS', 'P', 'TEXAS GAS TRANS', 'TEXAS GAS TRANSMISSION' 
UNION ALL
select 'TPROV', 'V', 'TOMIS PROVIDENC', 'TOMIS PROVIDENCE'
UNION ALL
select 'TRAILBLZ', 'P', 'TRAILBLAZER PIP', 'TRAILBLAZER PIPELINE'
UNION ALL
select 'TRANSCO', 'P', 'TRANSCONTINENTA', 'TRANSCONTINENTAL GAS PIPELINE' 
UNION ALL
select 'TRANSWST', 'P', 'TRANSWESTERN PI', 'TRANSWESTERN PIPELINE' 
UNION ALL
select 'TREGUIER', 'V', 'TREGUIER', 'TREGUIER'
UNION ALL
select 'TROK', 'P', 'TRANSOK', 'TRANSOK' 
UNION ALL
select 'TROMAAS', 'V', 'TROMAAS', 'TROMAAS' 
UNION ALL
select 'TROMSO F', 'V', 'TROMSO FIDELITY', 'TROMSO FIDELITY' 
UNION ALL
select 'TROPIC B', 'V', 'TROPIC BRILLIAN', 'TROPIC BRILLIANCE' 
UNION ALL
select 'TRUCK', 'T', 'TRUCK', 'TRUCK'
UNION ALL
select 'TRUNK', 'P', 'TRUNKLINE GAS C', 'TRUNKLINE GAS COMPANY' 
UNION ALL
select 'TWIN', 'S', 'TWIN', 'TWIN' 
UNION ALL
select 'Tebo', 'V', 'Tebo Olympia', 'Tebo Olympia' 
go

print '=> Load mot record set #17 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'U', 'V', 'ULAN', 'ULAN' 
UNION ALL
select 'UGPL', 'P', 'UNION GAS PIPE', 'UNION GAS PIPELINE' 
UNION ALL
select 'UKTHA RI', 'V', 'UKTHA RIVER', 'UKTHA RIVER' 
UNION ALL
select 'UNITED M', 'V', 'UNITED MOONLIGH', 'UNITED MOONLIGHT'
UNION ALL
select 'URAI', 'V', 'URAI', 'URAI'
UNION ALL
select 'UTOS', 'P', 'UTOS', 'UTOS'
UNION ALL
select 'V.HELENA', 'V', 'VINGA HELENA', 'VINGA HELENA' 
UNION ALL
select 'VARIK', 'V', 'VARIK', 'VARIK'
UNION ALL 
select 'VEERA', 'V', 'VEERA', 'VEERA' 
UNION ALL
select 'VEERE', 'V', 'VEERE', 'VEERE' 
UNION ALL 
select 'VEGHEL', 'V', 'VEGHEL', 'VEGHEL'
UNION ALL 
select 'VELDHOVE', 'V', 'VELDHOVEN', 'VELDHOVEN'
UNION ALL
select 'VELSEN', 'V', 'VELSEN', 'VELSEN'
UNION ALL
select 'VENETIA', 'V', 'VENETIA', 'VENETIA' 
UNION ALL
select 'VERDI', 'V', 'VERDI', 'VERDI' 
UNION ALL
select 'VESSEL', 'V', 'VESSEL', 'VESSEL'
UNION ALL
select 'VESSELGO', 'V', 'VESSEL GASOIL', 'VESSEL GASOIL CARGOES'
UNION ALL
select 'VESSEM', 'V', 'VESSEM', 'VESSEM'
UNION ALL
select 'VIGDIS K', 'V', 'VIGDIS KNUTSEN', 'VIGDIS KNUTSEN'
UNION ALL
select 'VIGOUR', 'V', 'VIGOUR', 'VIGOUR'
UNION ALL
select 'VILVOORD', 'V', 'VILVOORDE', 'VILVOORDE' 
UNION ALL
select 'VLAK', 'V', 'VLAKE', 'VLAKE' 
UNION ALL
select 'VLIELAND', 'V', 'VLIELAND', 'VLIELAND' 
UNION ALL
select 'VORDEN', 'V', 'VORDEN', 'VORDEN' 
UNION ALL 
select 'VREESWIJ', 'V', 'VREESWIJK', 'VREESWIJK' 
UNION ALL
select 'VRN', 'V', 'VUREN', 'VUREN' 
UNION ALL
select 'VSLLIGHT', 'V', 'VESSEL LGHT', 'LIGHTERING VESSEL' 
UNION ALL
select 'Vaestsjo', 'V', 'VAESTSJOE', 'VAESTSJOE' 
UNION ALL
select 'Vierhuiz', 'V', 'Vierhuizen', 'Vierhuizen' 
UNION ALL
select 'V', 'V', 'V', 'REGAL UNITY'
go

print '=> Load mot record set #18 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'W YUKON', 'V', 'WILMA YUKON', 'WILMA YUKON'
UNION ALL
select 'WAREHSE', 'S', 'WAREHOUSE', 'WAREHOUSE'
UNION ALL
select 'WASHOUT', 'V', 'WASHOUT', 'WASHOUT'
UNION ALL
select 'WESTMINI', 'V', 'WESTMINISTER', 'WESTMINISTER' 
UNION ALL
select 'WILLIAMN', 'P', 'WILLIAMS NATURA', 'WILLIAMS NATURAL GAS' 
UNION ALL
select 'WINDSOR', 'V', 'WINDSOR', 'WINDSOR'
UNION ALL
select 'WTRBRN', 'V', 'PIONEER', 'PIONEER'
UNION ALL
select 'Y.TITOV', 'V', 'YEVGENIY TITOV', 'YEVGENIY TITOV'
UNION ALL
select 'YELLOW S', 'V', 'YELLOW STAR', 'YELLOW STAR'
UNION ALL
select 'ZOJA 1', 'V', 'ZOJA 1', 'ZOJA 1' 
UNION ALL
select 'ZOJA 11', 'V', 'ZOJA 11', 'ZOJA 11'
go

print '=> Load mot record set #19 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'adriatik', 'V', 'adriatiki', 'ADRIATIKI' 
UNION ALL
select 'agapenor', 'V', 'agapenor', 'AGAPENOR' 
UNION ALL
select 'alba', 'V', 'alba', 'ALBA' 
UNION ALL
select 'antinoor', 'V', 'antinoor', 'ANTINOOR'
UNION ALL
select 'ara', 'V', 'ara', 'ARA' 
UNION ALL
select 'artemis', 'S', 'artemis', 'ARTEMIS' 
UNION ALL
select 'atl carr', 'V', 'atlantic carrie', 'ATLANTIC CARRIER' 
UNION ALL
select 'atl ener', 'V', 'atlantic energy', 'ATLANTIC ENERGY' 
UNION ALL
select 'atl supp', 'V', 'atlantic suppli', 'ATLANTIC SUPPLIER' 
UNION ALL
select 'atl tran', 'V', 'atlantic transp', 'ATLANTIC TRANSPORT' 
UNION ALL
select 'b-235', 'V', 'b-235', 'B-235' 
UNION ALL
select 'barge ni', 'B', 'barge nipaya', 'BARGE NIPAYA'
UNION ALL
select 'bge', 'S', 'vessel', 'LOTUS'
UNION ALL
select 'bookout', 'V', 'bookout', 'BOOKOUT' 
UNION ALL
select 'bro bara', 'V', 'bro bara', 'BRO BARA'
UNION ALL
select 'burgas', 'S', 'burgas', 'BURGAS'
go

print '=> Load mot record set #20 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'calendul', 'V', 'calendula12', 'CALENDULA 12'
UNION ALL
select 'ceeblend', 'V', 'ceeblender', 'CEEBLENDER'
UNION ALL
select 'chopin', 'V', 'chopin', 'CHOPIN' 
UNION ALL
select 'christa', 'V', 'christa', 'CHRISTA' 
UNION ALL
select 'corelli', 'V', 'corelli', 'CORELLI' 
UNION ALL
select 'courage', 'V', 'courage', 'COURAGE' 
UNION ALL
select 'daniella', 'V', 'daniella', 'DANIELLA' 
UNION ALL
select 'della &', 'V', 'della & teco', 'DELLA & TECO' 
UNION ALL 
select 'dong tin', 'V', 'dong ting hu', 'DONG TING HU' 
UNION ALL
select 'e', 'V', 'ESTERE', 'ESTERE'
UNION ALL
select 'ek sky', 'V', 'ek sky', 'EK SKY' 
UNION ALL
select 'energie', 'V', 'energie 12', 'ENERGIE 12' 
UNION ALL
select 'eric 2', 'V', 'eric 2', 'ERIC 2'
UNION ALL
select 'estellas', 'S', 'estellastorage', 'estellastorage'
UNION ALL
select 'explorer', 'V', 'explorer', 'EXPLORER' 
go

print '=> Load mot record set #21 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'falco', 'V', 'falco', 'FALCO' 
UNION ALL
select 'fidelity', 'V', 'fidelity', 'FIDELITY' 
UNION ALL
select 'folegand', 'V', 'folegandros', 'FOLEGANDROS' 
UNION ALL
select 'four sta', 'V', 'four stars', 'FOUR STARS' 
UNION ALL
select 'geroi no', 'V', 'geroi novoross', 'GEROI NOVOROSS' 
UNION ALL
select 'giannutr', 'V', 'giannutri', 'GIANNUTRI' 
UNION ALL 
select 'halki', 'V', 'halki', 'HALKI' 
UNION ALL 
select 'hwd-2522', 'S', 'hwd-2522', 'HWD-2522' 
UNION ALL 
select 'isola ro', 'V', 'isola rossa', 'ISOLA ROSSA' 
UNION ALL 
select 'j.b.rawl', 'V', 'j.b.rawles', 'j.b.rawles' 
UNION ALL 
select 'kand', 'V', 'kand', 'KANDILOUSA'
UNION ALL
select 'kite', 'V', 'kite', 'KITE'
UNION ALL
select 'kogalym', 'V', 'kogalym', 'kogalym'
UNION ALL
select 'kriti co', 'V', 'kriti colour', 'KRITI COLOUR'
UNION ALL
select 'ladon', 'S', 'ladon', 'LADON'
UNION ALL
select 'ledaster', 'V', 'ledastern', 'LEDASTERN'
UNION ALL
select 'london', 'V', 'london', 'LONDON'
UNION ALL
select 'maga', 'V', 'maga', 'MAGA' 
UNION ALL
select 'magpie', 'V', 'magpie', 'MAGPIE' 
UNION ALL
select 'mar nuri', 'V', 'mar nuria', 'mar nuria' 
UNION ALL
select 'matvik', 'V', 'matvik', 'MATVIK'
UNION ALL
select 'montreau', 'V', 'montreaux', 'MONTREUX' 
UNION ALL
select 'montrose', 'V', 'MONTROSE', 'MONTROSE' 
UNION ALL
select 'mos fest', 'V', 'moscovskiy fest', 'MOSCOVSKIY FESTIVAL' 
UNION ALL
select 'mot', 'V', 'HILDEGAARD', 'HILDEGAARD' 
UNION ALL
select 'ndumbadz', 'V', 'n dumbadze', 'N DUMBADZE' 
UNION ALL
select 'nestos', 'V', 'nestos', 'NESTOS'
UNION ALL
select 'nevada', 'V', 'nevada', 'NEVADA' 
UNION ALL 
select 'nordfast', 'V', 'nordfast', 'NORDFAST' 
UNION ALL
select 'nordic a', 'V', 'nordic alandia', 'NORDIC ALANDIA'
UNION ALL
select 'pablo', 'V', 'PABLO NERUDA', 'PABLO NERUDA' 
UNION ALL
select 'pax', 'V', 'pax', 'PAX'
UNION ALL
select 'pbl 1801', 'V', 'pbl 1801', 'PBL 1801' 
UNION ALL
select 'pbl 901', 'V', 'pbl 901', 'PBL 901' 
UNION ALL
select 'peregrin', 'V', 'peregrine', 'PEREGRINE'
UNION ALL
select 'perla ne', 'V', 'perla nera', 'PERLA NERA' 
UNION ALL
select 'pumpover', 'V', 'pumpover', 'PUMPOVER'
go

print '=> Load mot record set #22 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'remboue', 'V', 'remboue', 'REMBOUE'
UNION ALL
select 'rita mae', 'V', 'rita maersk', 'RITA MAERSK'
UNION ALL
select 'robella', 'V', 'robella', 'robella' 
UNION ALL 
select 'rojas 2', 'V', 'rojas 2', 'ROJAS 2'
UNION ALL
select 'romito', 'V', 'romito', 'ROMITO'
UNION ALL
select 'sacha', 'V', 'sacha', 'SACHA'
UNION ALL
select 'san seba', 'V', 'san sebastian', 'SAN SEBASTIAN' 
UNION ALL
select 'sc breez', 'V', 'sc breeze', 'SC BREEZE'
UNION ALL
select 'scf trus', 'V', 'scf trust', 'SCF TRUST' 
UNION ALL
select 'scopas', 'V', 'scopas', 'SCOPAS' 
UNION ALL
select 'sea magi', 'V', 'SEA MAGIC', 'SEA MAGIC' 
UNION ALL
select 'sebong', 'V', 'sebong', 'SEBONG' 
UNION ALL
select 'serifopo', 'V', 'serifopoulo', 'SERIFOPOULO'
UNION ALL 
select 'serifos', 'V', 'serifos', 'SERIFOS'
UNION ALL 
select 'shinouss', 'V', 'shinoussa', 'SHINOUSSA'
UNION ALL 
select 'skirapou', 'V', 'skirapoula', 'SKIRAPOULA'
UNION ALL 
select 'sporades', 'V', 'sporades', 'SPORADES' 
UNION ALL
select 'star jap', 'V', 'star japan', 'STAR JAPAN' 
UNION ALL 
select 'stefan', 'V', 'stefan', 'STEFAN' 
UNION ALL 
select 'stephan', 'V', 'stephan', 'STEPHAN'
UNION ALL
select 'storage', 'S', 'storage', 'EILTANK 17' 
UNION ALL
select 'sun rive', 'V', 'sun river', 'SUN RIVER' 
UNION ALL 
select 't s', 'V', 'TORBEN SPIRIT', 'TORBEN SPIRIT' 
go

print '=> Load mot record set #23 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name)
select 'tbn', 'V', 'tbn', 'TBN'
UNION ALL
select 'terra', 'V', 'terra', 'TERRA'
UNION ALL
select 'twin', 'V', 'twin', 'TWIN'
UNION ALL
select 'united t', 'V', 'united triton', 'UNITED TRITON'
UNION ALL 
select 'vaals', 'V', 'vaals', 'VAALS' 
UNION ALL 
select 'valeriyc', 'V', 'valeriy chkalov', 'VALERIY CHKALOV'
UNION ALL
select 'vigo', 'V', 'vigo', 'vigo'
UNION ALL
select 'vlijmen', 'V', 'vlijmen', 'VLIJMEN'
UNION ALL
select 'vsl', 'V', 'vessel', 'BREGEN' 
UNION ALL
select 'vulcan', 'V', 'vulcan', 'VULCAN'
UNION ALL
select 'vuren', 'S', 'vuren', 'VUREN'
UNION ALL
select 'BLENDING','L','Blending','Blending'
go

print '=> Load mot record set #24 ...'
go
insert into #mots (mot_code, mot_type_code, mot_short_name, mot_full_name, 
                   ppl_cycle_freq, ppl_num_of_cycles, ppl_split_cycle_ind)
select 'CPL', 'P', 'COLONIAL', 'COLONIAL PIPELINE', 'Y', 3, 'Y'
UNION ALL
select 'EPL', 'P', 'EXPLORER', 'EXPLORER PIPELINE', 'Y', 36, 'N' 
go


print '=> Copying records from temp table to the mot table ...'
go


declare @rows_affected     int

begin try
  insert into dbo.mot
      (mot_code, mot_type_code, mot_short_name, mot_full_name, 
       ppl_cycle_freq, ppl_num_of_cycles, ppl_split_cycle_ind, 
       mot_status, trans_id)    
  select 
     mot_code,
     mot_type_code,
     mot_short_name,
     mot_full_name,
     ppl_cycle_freq,
     ppl_num_of_cycles,
     ppl_split_cycle_ind,
     'A',
     1
  from #mots a
  where not exists (select 1
                    from dbo.mot b
                    where a.mot_code = b.mot_code)
  select @rows_affected = @@rowcount
end try
begin catch
  print '=> Failed to load records into the mot table due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch
if @rows_affected > 0
   print '=> ' + cast(@rows_affected as varchar) + ' mot records were added.'
else
   print '=> No mot records were added.'
   
endofscript:
go

--drop table #mots
go
