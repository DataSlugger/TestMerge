set nocount on

set QUOTED_IDENTIFIER ON
go

print '=> Adding a TEMPLATE trade record ...'
go

if not exists (select 1
               from dbo.trade
               where trade_num = 0)
begin
   insert into dbo.trade
         (trade_num, creation_date, creator_init, trans_id)
      values(0, getdate(), 'ICT', 1)
end
go
