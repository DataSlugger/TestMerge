set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table gtc
go

print 'Loading seed reference data into the gtc table ...'
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
  values('ADNOC', 'CRUDE FOB 12/92', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ADNOC1', 'REF PROD FOB 12/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('AMOCOCF', 'C&F CIF 1/82', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('AMOCODEL', 'DELIVERED 1/86', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('AMOCOFOB', 'FOB GTC''S 1/85', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ANRO', 'CIF LITTLEBROOK HSFO', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ASHLAND', 'FOB CRUDE 4/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('BAYWAY', 'GTC''S 3/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('BAYWAY1', 'MARINE PROVISIONS 4/93', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('BHP', 'SPOT CIF CF EXSHIP 1/87', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('BHP1', 'SPOT FOB 1/88', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('BPOI', 'FOB PRODUCTS 12/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('BPOI1', 'FOB CRUDE 2/85', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('BPOI2', 'CRUDE CFR CIF EXSHIP 10/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('BPOI3', 'PROD CFR CIF EXSHIP 2/96', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('BPOI4', 'FOB SING SINGLE SHIPMENT 2/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('BPOSC91', 'BP FOR ANS DLVD. OUT NOV.91', null, null, 'ICU', getdate(), 1)
go

insert into gtc 
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('BREG', 'BREGANAFT', null, null, 'ICU', getdate(), 1)
go


insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('C/P', 'CHARTER PARTY', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CALTEX', 'FOB CT367.1  (11/86)', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CALTEX90', 'CALTEX FOB CT367.1 (1/90)', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CARGILL', 'PIPELINE', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CFD', 'CONTRACT FOR DIFFERENCES', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CFP', 'CIF 6/1/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVRON', 'NANHAI LIGHT FOB', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVRON1', 'FOB SPOT SALES 1/92', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVRON2', 'CFR CIF SPOT SALES 1/92', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVRON3', 'DELIVERED EX-SHIP SPOT 1/92', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVRON4', 'ALBA EXSHIP 4/98', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVUSA', 'CRUDE&PROD EXCH&P/S 9/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVUSA1', 'FOB SAUDI ARABIA 7/84', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVUSA2', 'FOB PORT LOADING 9/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVUSA3', 'FOB TERM (THEVENARD) 5/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVUSA4', 'ALBA EXSHIP 4/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVUSA5', 'FOB SULLOM VOE', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVUSA6', 'EXSHIP BOSTON NO2 HO 3/88', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CHEVUSA7', 'MARIN PROV EAST. REG 5/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CITGO1', 'PROD PURCH/SLS 12/95', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CITGO2', 'PRODUCT EXCHANGE 10/95', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CITGO3', 'MARINE PROV 10/95', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('COASTAL', 'SALE/PUR/EXCH REF PETR 5/92', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('COASTAL1', 'US SALES & DELIVERIES 3/82', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('COASTAL2', 'INTL FOB CIF CF 5/79 C BERMUDA LTD', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CONOCO', 'MARINE PROV 3/86', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CONOCO 3', 'DUBAI FOB GTCS 1/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CONOCO1', 'EXCHANGE GTCS 3/86', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CONOCO2', 'PUR/SALE GTC''S 1/86', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CONOCO4', 'DEL EXSHIP SLS 6/83', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CONOCO5', 'DOM CRUDE AGREEMENTS 1/93', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CONOCO83', 'CONOCO  83  FOR DOMESTIC', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CONOCO88', 'CONOCO 88 FOR DUBAI', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('CORPOVEN', 'CORPOVEN', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('DOW', 'NAPHTHA CONTRACT 1/92', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ECOPETRO', 'ECOPETROL GTC''S 9/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('EGPC', 'FOB EGYPTIAN CRUDE PART II STD T&C 8/91', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ELFCALED', 'FOB ELF ENT CALEDONIA 1/92', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ELFSOCA1', 'CF/CIF CRUDE ''90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ELFSOCA2', 'PET PROD/FEEDST 12/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ELFSOCA3', 'CF/CIF NON US DOM 12/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ELFSOCA4', 'DELVD CRUDE NONUS DOM 12/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ELFSOCA5', 'US CRUDE DOMESTIC NON-MARINE 12/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ELFSOCAP', 'CRUDE FOB GTC ''92', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ENEL', 'ENEL', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ENRON', 'CRUDE PROD PETROCHEM 3/96', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ENRON 3', 'DELIVERED MARINE PROV CRUDE/PROD 3/96', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ENRON1', 'FOB MARINE PROV CRUDE/PROD 3/96', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ENRON2', 'CIF/CFR MARINE PROV CRUDE/PROD', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ESSO', 'ESSO', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ETAP', 'ENT. TUNISIENNE D ACT. PET.', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('EXXONTC1', 'C+F CIF PART II GEN PROV ''85', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('EXXONTC2', 'EXSHIP PART II GEN PROV ''85', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('EXXONTC3', 'UK NO SEA CRUDE LIFTINGS 85', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('EXXONTCI', 'PART II FOB GEN PROV ''84', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('EXXUSA', 'MARINE PROV EXXON CO USA 7/91', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('EXXUSA1', 'REV RAW MATERIALS GEN PROVS 11/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('EXXUSA2', 'PETROLEUM PRODUCST P/S GEN PROVS 10/1/89', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('FINA', 'GTC''S FINA OIL & CHEM CO 1/29/93', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('GULFTR', 'GOTCO STD TERMS/COND DOM CRUDE 3/84', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('HESS', 'PIPELINE', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('HESSVI', 'FOB ST CROIX USVI PT II GENPROV 4/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('INCO', 'INCOTERMS 1990', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('INCO2000', 'INCOTERMS2000', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('IOC', 'EXPORT PRODS INDIAN OIL CO GTC 1/85', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('IOC1', 'IMPORT PRODS INDIAN OIL CO GTC 2/93', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('IRAN', 'PRODUCT 1/93', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('IRAN2', 'CRUDE 5/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('IRVING', 'IRVING OIL LTD GTC''S', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('ISDA', 'ISDA', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('KOCH', 'PRODUCTS P/S EXCH KOCH IND INC GTC 8/92', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('KUWAIT', 'KPC FOB/C&F/CIF 7/89 GTC', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('KUWAIT1', 'FOB KPC GTC 7/89', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('KUWAIT2', 'KPC LPG FOB GTC 10/86', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('KUWAIT3', 'CRUDE EXSHIP KPC GTC 5/93', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('LDREYFUS', 'PROD NGAS SALES + EXCH', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('LLE', 'GEN PROVISIONS 2/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('LLE1', 'MARINE PROV SUP GTC 9/85', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('LUKOIL', 'STANDARD CONTRACT', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('MOBIL', 'FOB CIF C&F PURC&SALES STD T&C', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('MOBIL1', 'EXSHIP FOBDEST PURCH&SLS STD T+C 7/85', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('MOBIL2', 'CFR CIF P&S OIL IN BULK VSL 3/97', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('MURCO', 'FOB PRODUCT SALES GTC''S 3/92', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('MURPHY', 'FOB CRUDE SALES T+C''S 5/88', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('NAFTA', 'SOVIET EXP BLEND CRUDE GTC''S 11/91', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('NETHERLA', 'TANK STORAGE GTC''S NETHERLANDS 1/84', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('NIOC', 'CRUDE SALES/PURCHASES GTC''S 1/93', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('NNPC', 'SALE NIGERIAN CRUDE GEN COND''S', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('NORTHVIL', 'COL PIPELINE GTC''S NORTHVILLE 2/25/92', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('OCCIDEN1', 'FOB SALE OF OIL GTC''S OCCIDENTAL 1/86', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('OCCIDENT', 'CF/CIF SALES GTC''S 2/90 OCCIDENTAL', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('OMAN', 'OMAN EXP BLEND S/P 6/91', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('OPA', 'OFFSHORE UKS CRUDE CONDS SALE 11/86 OIL', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('OPA1', 'FOB UK PORTS COND SALE 11/86 OIL&P/L AGE', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PACIFIC', 'PROD P/S EXCH PACIFIC REFINING GTC 4/92', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PAKTANK1', 'PAKTANK, GOTHENBURG', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PAKTANK2', 'PAKTANK, ROTTERDAM', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PDVSA', 'FOB CRUDE/PROD CONTRACT/GTC 1/98', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PDVSA1', 'C&F/CIF CRUDE/PROD CONTRACT/GTC''S 1/98', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PECTEN', 'FOB HYDROCARB 12/85 PEC CAMEROON', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PECTEN1', 'DLVD SALES HYDROCARB GEN PROV 7/91', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PERTAMIN', 'PERTAMINA', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PETROEC', 'PETROECUADOR GTC LAYTIME/DEM 5/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PETROFIN', 'PETROFINA S.A.', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PETROMIN', 'CRUDE OIL DELIVERIES 8/84', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PETRONAS', 'FOB MALAYSIAN CRUDE 3/91', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PETRONOR', 'FOB SALES 3/83', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PETROTRN', 'PETROTRIN FOB SALE GTC''S', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PHIBRO', 'PETROLEUM PRODUCTS GTC''S 6/91', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PHILLIP1', 'MAUREEN OFFSHORE CONDS 9/83', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PHILLIPS', 'EKOFISK GEN PROVS 11/92', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PMI', 'FOB PRODUCT SALES GTC''S', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('PREEM', 'FOB CIF CFR GEN COND''S OF SALE 1998 PREE', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('REPSOL', 'FOB SALES PETROLEUM PRODUCTS 9/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SAGA', 'EXSHIP DURWARD OFFSHORE LOAD 5/97', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SARAS', 'FOB - SARAS SPA 11/96 GTC', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SAUDIAR', 'SAUDI ARAMCO FORMS A&B 11/1/93', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SEMPRBRG', 'SEMPRABARGES FOB', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SEMPRC-D', 'SEMPRACIF-DELVD', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SEMPRCFR', 'SEMPRA CFR', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SEMPRCIF', 'SEMPRA CIF', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SEMPRDDU', 'SEMPRA DDU', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SEMPRDES', 'SEMPRA DES', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SEMPRFOB', 'SEMPRA FOB', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SHELLCU1', 'FOB (SHELL CURACAO) 4/81', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SHELLCUR', 'CIF (SHELL CURACAO) 3/82', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SHELLNE1', 'C&F CIF CRUDE&PROD 1/88 SHELL NEDERLANDS', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SHELLNE2', 'FOB CRUDE&PROD 1/88 SHELL NEDERLANDS', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SHELLNED', 'CRUDE& HYDROCARBONPROD GEN CONDS 1/88', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SHELLOI1', 'C&F CIF HYDROCARBONS 1/88 SHELL OIL CO', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SHELLOI2', 'FOB HYDROCARBONS 7/87 SHELL OIL CO', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SHELLOIL', 'DELIVERED HYDROCARBONS 1/90 SHELL OIL CO', null, null, 'ICU', getdate(), 1) 
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SHELLOPR', 'SHELL OIL PROD CO DEL EX SHIP', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SINOCHEM', 'FOB C&F', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SITCO', 'FOB CRUDE 1/93', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SITCO1', 'C&F CRUDE 6/88', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SITCO2', 'C&F CIF PETR PROD FEEDDSTOCKS 8/88', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SITCO3', 'FOB PETR PROD FEEDSTOCKS 8/88', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SITCO4', 'PETR PROD FFEDSTOCKS ALT PROVS 1/85', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SITCO5', 'DELIVERED OUTTURN NON USA US TERR 3/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SITCOCFD', 'CONTRACT FOR DIFFERENCES', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SO', 'SO', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SOHIO', 'FOB 11/83', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SOHIOANS', 'ANS DELIVERED USGC CARIB 1/86', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SOMO', 'FOB CRUDE SALES', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SONANGOL', 'GTC''S 5/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SONATRAC', 'FOB PRODUCTS 11/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STANDARD', 'STANDARD', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STAR', 'PROD EXCH GEN PROV 10/91 (STAR ENTERPRIS', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STAR1', 'SHORT TERM SPOT PURCH/SALES 10/91 (STAR', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STAR2', 'MARINE PROV TANKERS/TOWS/BARGES', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STAR3', 'PROD MARINE PROV LOADING OCEAN TANKERS', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STASCO', 'C&F CIF PROD/FEEDSTOCK 12/1/97', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STATOI10', 'CIF OSEBERG 12/88 STATOIL', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STATOIL', 'FOB/FIP TERMINAL CRUDE 8/97', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STATOIL1', 'CIF/C&F TERMINAL CRUDE 8/97', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STATOIL2', 'DELIVERED OUTTURN 8/97', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STATOIL3', 'CIF OFFSHORE LOADED CRUDE 8/97', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STATOIL4', 'CRUDE FOB  SALES 11/91', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STATOIL5', 'CIF STATFJORD/GULLFAKS OFFSHORE LOAD 11/', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STATOIL6', 'FOB EKOFISK BRENT 3/88', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STATOIL7', 'CIF EKOFISK BRENT 3/88', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STATOIL8', 'FOB MONGSTAD TERMINAL 3/88', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STATOIL9', 'CIF MONGSTAD TERMINAL 3/88', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('STS', 'STS, GOTHENBURG', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SUKO1', 'OFFSHORE UKCS CRUDES 4/82 SHELL UK', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SUKO2', 'FOB UK PORTS SPOT SALES 6/86', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SUKO90', 'SHELL 15 DAY BRENT 1990', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SUMED', 'IRANIAN SIDI KERIR', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SUNREF', 'WATERBORNE  2/83 (SUN REF AND MKT CO)', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SUNREF1', 'FOB/DLVD CRUDE PROD 2/83 SUN REF & MKT C', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SUNREF2', 'FOB DLVD SUN REF & MKT CO 8/83', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('SYRIAN', 'GTC''S 12/94', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('TOTAL', '(CFP) CIF 6/1/90', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('TRANSMA1', 'MARINE REF PRODS GTC''S TRANSMARKETING', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('TRANSMAR', 'MARINE TANK BARGE GTC TRANSMARKETING HOU', null, null, 'ICU', getdate(), 1) 
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('TRANSWO1', 'GTC''S TRANSWORLD', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('TRANSWOR', 'REF PROD SLS/PUR EXCH 2/83 TRANSWORLD', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('TXO1/94', 'TEXACO C&F, CIF, OUTTURN', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('TXO10', 'TEXACO PIPELINE & BARGE (PRODUCTS)', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('TXO11/94', 'TEXACO FOB', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('TXO4', 'TEXACO SWAP GTC''S', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('TXO5', 'TEXACO SWAP GTC''S', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('TXO6/97', 'TEXACO CAPTAIN - OUTTURN SHUTTLE TANKERS', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('UNOCAL', 'GTC''S 1/83', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('VOTT', 'VOTT, ROTTERDAM', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('YEMEN', 'YEMEN OIL & MINERAL CORP GEN PROV 3/91', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('YEMEN1', 'YEMEN HUNT OIL PROCED SCHEDULING TANKER', null, null, 'ICU', getdate(), 1)
go

insert into gtc
    (gtc_code, gtc_desc, agreement_num, agreement_date,
     creator_init, creation_date, trans_id)
   values('YPF', 'YPF SA.', null, null, 'ICU', getdate(), 1)
go

