set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Saving Symphony OIL db version info into the database_info table ...'
go

insert into dbo.database_info 
    (owner_code, major_revnum, minor_revnum, last_touch_date, data_source, usage, patch_level, note)
values('TC', '3306', '1', getdate(), 'StarterDB', NULL, NULL, 'asof REL-3.2.1000_build_14')
go