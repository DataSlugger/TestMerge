set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table account_group_type
go

print 'Loading seed reference data into the account_group_type table ...'
go

insert into dbo.account_group_type 
   values('LEGAL', 'LEGAL ENTITY GROUPING', 1)
go

insert into dbo.account_group_type 
   values('REPORT', 'REPORT ENTITY 1 GROUPING', 1)
go

