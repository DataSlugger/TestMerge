set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the eo_sequence_table table ...'
go

IF NOT EXISTS (select * 
               from eo_sequence_table
               where table_name = 'eipp_task')
   INSERT INTO dbo.eo_sequence_table(table_name, counter)
   VALUES('eipp_task',0)
go

IF NOT EXISTS (select * 
               from eo_sequence_table
               where table_name = 'eipp_task_name')
   INSERT INTO dbo.eo_sequence_table(table_name, counter)
   VALUES('eipp_task_name',0)
go
