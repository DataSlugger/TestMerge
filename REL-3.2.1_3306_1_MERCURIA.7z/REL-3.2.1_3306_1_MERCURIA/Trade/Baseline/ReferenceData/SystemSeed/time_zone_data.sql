set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table time_zone
go

print 'Loading seed reference data into the time_zone table ...'
go

insert into dbo.time_zone 
   values('GMT', 0, 'GMT', 1)
go

insert into dbo.time_zone 
   values('HOUSTON', 0, 'CDT - US/Central', 1)
go

insert into dbo.time_zone 
   values('LONDON', 0, 'DMT - GB-Eire', 1)
go

insert into dbo.time_zone 
   values('NEW YORK', 0, 'EDT - US/Eastern', 1)
go

insert into dbo.time_zone 
   values('SING', 0, 'SGT - Singapore', 1)
go

insert into dbo.time_zone 
   values('ROME', 0, 'CET - Europe/Rome', 1)
go
