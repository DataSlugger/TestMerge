/* ********************************************************
    The followings are special entries:

     num_col_name        last_num           owner_table        owner_column
                         (max value allowed
                          2147483647
     ------------------- ------------------ ------------------ ------------
     qf_num              80000000           trade              trade_num
     portfolio_tag_num   20000              icts_function      function_num
     acct_agreement_num  90000000           account_agreement  agreement_num
     gtc_agreement_num   90000000           gtc                agreement_num

    NOTE: The entry 'gtc_agreement_num' is obsoleted. It will be
          removed by a future release. 
   ******************************************************** */
set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading static entries into the new_num table ...'
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'ComputronAP' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('ComputronAP',0,0,NULL,NULL,1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'ComputronARAP' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('ComputronARAP',0,0,NULL,NULL,1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'ComputronGL' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('ComputronGL',0,0,NULL,NULL,1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'ComputronInterface' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('ComputronInterface',0,0,NULL,NULL,1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'PostingVouchers' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('PostingVouchers',0,0,NULL,NULL,1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'acct_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('acct_num',0,10,'account','acct_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'alarm_cmnt_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('alarm_cmnt_num',0,0,'credit_alarm_comment','alarm_cmnt_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'alarm_log_cmnt_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('alarm_log_cmnt_num',0,0,'credit_alarm_log_comment','alarm_log_cmnt_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'alloc_chain_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('alloc_chain_num',0,0,'allocation_chain','alloc_chain_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'alloc_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('alloc_num',0,0,'allocation','alloc_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'assign_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('assign_num',0,0,'assign_trade','assign_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'autopool_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('autopool_num',0,0,'autopool_criteria','autopool_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'bb_ref_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('bb_ref_num',0,0,'trade_item','idms_bb_ref_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'bc_fate_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('bc_fate_num',0,0,'bus_cost_fate','bc_fate_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'bc_mail_list_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('bc_mail_list_num',0,0,'bus_cost_mail_list','bc_mail_list_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'bc_type_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('bc_type_num',0,0,'bus_cost_type','bc_type_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'book_pl_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('book_pl_num',0,0,'portfolio_book_pl','book_pl_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'bsi_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('bsi_num',0,0,'trade_item_fill','bsi_fill_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'cash_coll_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('cash_coll_num',0,0,'cash_collateral','cash_coll_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'cff_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('cff_num',0,0,'cash_forecast_file','cff_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'cmnt_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('cmnt_num',0,0,'comment','cmnt_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'coll_party_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('coll_party_num',0,0,'collateral_party','coll_party_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'coll_pledged_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('coll_pledged_num',0,0,'collateral_pledged','coll_pledged_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'commkt_key' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('commkt_key',0,0,'commodity_market','commkt_key',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'cost_approval_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('cost_approval_num',0,0,'cost_approval','cost_approval_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'cost_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('cost_num',0,0,'cost','cost_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'credit_limit_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('credit_limit_num',0,0,'credit_limit','credit_limit_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'dist_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('dist_num',0,0,'trade_item_dist','dist_num',1)
go


IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'doc_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('doc_num',0,0,'document','doc_num',1)
go


IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'edpl_event_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('edpl_event_oid',0,0,'edpl_event','oid',1)
go


IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'eom_pb_process_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('eom_pb_process_num',0,0,'eom_posting_batch','eom_pb_process_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'exposure_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('exposure_num',0,0,'exposure','exposure_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'formula_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('formula_num',0,0,'formula','formula_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'glfile_bh_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('glfile_bh_num',0,0,'glfile_bh','glfile_bh_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'glfile_fh_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('glfile_fh_num',0,0,'glfile_fh','glfile_fh_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'glfile_td_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('glfile_td_num',0,0,'glfile_td','glfile_td_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'glfile_th_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('glfile_th_num',0,0,'glfile_th','glfile_th_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'group_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('group_num',0,0,'credit_group','group_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'inv_b_d_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('inv_b_d_num',0,0,'inventory_build_draw','inv_b_d_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'inv_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('inv_num',0,0,'inventory','inv_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'invoice_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('invoice_num',0,0,'mca_invoice_terms','invoice_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'lc_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('lc_num',0,0,'lc','lc_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'license_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('license_num',0,0,'license','license_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'limit_cmnt_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('limit_cmnt_num',0,0,'credit_limit_comment','limit_cmnt_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'long_cmnt_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('long_cmnt_num',0,0,'pei_comment_cmnt','long_cmnt_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'macc_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('macc_num',0,0,'material_adv_chg_clause','macc_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'margin_call_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('margin_call_num',0,0,'margin_call','margin_call_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'mca_cmnt_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('mca_cmnt_num',0,0,'mca_comment','mca_cmnt_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'mca_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('mca_num',0,0,'master_coll_agreement','mca_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'mkt_info_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('mkt_info_num',0,0,'market_info','mkt_info_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'mkt_security_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('mkt_security_num',0,0,'marketable_security','mkt_security_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'paper_alloc_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('paper_alloc_num',0,0,'paper_allocation','paper_alloc_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'pg_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('pg_num',0,0,'parent_guarantee','pg_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'port_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('port_num',0,0,'portfolio','port_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'posting_account_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('posting_account_num',0,0,'posting_account','posting_account_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'price_change_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('price_change_num',0,0,'price_change','price_change_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'recap_item_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('recap_item_num',0,0,'recap_item','recap_item_num',1)
go

/*  Table has been removed. Do not need this entry any more
IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'rep_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('rep_num',0,800,'report','rep_num',1)
*/
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'simple_formula_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('simple_formula_num',0,0,'simple_formula','simple_formula_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'special_cond_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('special_cond_num',0,0,'special_condition','special_cond_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'tablet_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('tablet_num',0,0,'trade','trade_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'tax_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('tax_num',0,0,'tax','tax_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'tax_rate_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('tax_rate_num',0,0,'tax_rate','tax_rate_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'trade_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('trade_num',0,0,'trade','trade_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'uom_conv_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('uom_conv_num',0,0,'uom_conversion','uom_conv_num',1)
go


/*  Table has been removed. Do not need this entry any more
IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'user_rep_group_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('user_rep_group_num',0,0,'user_report_group','user_rep_group_num',1)
*/
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'voucher_approval_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('voucher_approval_num',0,0,'voucher_approval','voucher_approval_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'voucher_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('voucher_num',0,0,'voucher','voucher_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'alloc_criteria_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('alloc_criteria_num',0,0,'allocation_criteria','alloc_criteria_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'acct_bank_id' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('acct_bank_id',0,0,'account_bank_info','acct_bank_id',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'cmf_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('cmf_num',0,0,'commodity_market_formula','cmf_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'mpt_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('mpt_num',0,0,'market_pricing_term','mpt_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'sap_row_id' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('sap_row_id',0,0,'send_to_SAP','row_id',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'sap_file_id' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('sap_file_id',0,0,'SAP_file','file_id',1)
go

/* QUICKFILL */
IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'qf_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('qf_num',0,80000000,'trade','trade_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'key_value' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('key_value',0,0,'key_value','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'gdd_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('gdd_num',0,0,'generic_data_definition','gdd_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'gdv_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('gdv_num',0,0,'generic_data_values','gdv_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'rptext_result_set_id' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('rptext_result_set_id',0,0,NULL,NULL,1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'gdn_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('gdn_num',0,0,'generic_data_name','gdn_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'event_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('event_num',0,0,'event','event_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'reprice_event_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('reprice_event_oid',0,0,'reprice_event','reprice_event_oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'tcs_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('tcs_oid',0,0,'transport_cost_schedule','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'bppl_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('bppl_oid',0,0,'bunker_pur_price_lookup','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'psg_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('psg_oid',0,0,'purchase_sale_group','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'inv_loop_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('inv_loop_num',0,0,'inventory','inv_loop_num',1)
go


/* The following three items are used by 4GenInterface and Credit Interface to identify records in
   flat file. Therefore, it does not owner table and owner column


   Peter Lo     Nov-13-2002
*/
IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'bulk_seq_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('bulk_seq_num',0,0,NULL,NULL,1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'credit_seq_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('credit_seq_num',0,0,NULL,NULL,1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'inv_seq_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('inv_seq_num',0,0,NULL,NULL,1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'pl_reconciliation_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('pl_reconciliation_num',0,0,'pl_reconciliation','pl_reconciliation_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'roll_criteria_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('roll_criteria_num',0,0,'inventory_roll_criteria','roll_criteria_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'importer_reason_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('importer_reason_oid',0,0,'importer_record_reason','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'portfolio_tag_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('portfolio_tag_num',0,20000,'icts_function','function_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'external_trade_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('external_trade_oid',0,0,'external_trade','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'external_mapping_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('external_mapping_oid',0,0,'external_mapping','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'external_comment_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('external_comment_oid',0,0,'external_comment','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'job_schedule_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('job_schedule_num',0,0,'job_schedule','job_schedule_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'voucher_pay_approval_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('voucher_pay_approval_num',0,0,'voucher_pay_approval','voucher_pay_approval_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'interface_exec_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('interface_exec_num',0,0,'interface_exec_params','exec_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'wakeup_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('wakeup_num', 0, 0, 'wakeup', 'wakeup_num', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'uic_report_type_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('uic_report_type_oid',0,0,'uic_report_type','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'uic_report_mod_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('uic_report_mod_oid',0,0,'uic_report_modification','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'uic_rpt_values_config_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('uic_rpt_values_config_oid',0,0,'uic_rpt_values_config','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'uic_rpt_criteria_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('uic_rpt_criteria_oid',0,0,'uic_rpt_criteria','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'uic_rpt_criteria_entity_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('uic_rpt_criteria_entity_oid',0,0,'uic_rpt_criteria_entity','oid',1)
go



/* VAT 2/26/2004 */
IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'acct_fiscal_rep_id' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('acct_fiscal_rep_id', 0, 0, 'acct_fiscal_rep', 'acct_fiscal_rep_id', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'acct_vat_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('acct_vat_num', 0, 0, 'acct_vat_number', 'acct_vat_num', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'cmdty_nomenclature_id' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('cmdty_nomenclature_id', 0, 0, 'cmdty_nomenclature', 'cmdty_nomenclature_id', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'vat_declaration_id' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('vat_declaration_id', 0, 0, 'vat_declaration', 'vat_declaration_id', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'cost_autogen_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('cost_autogen_num',0,0,'broker_cost_autogen','cost_autogen_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'fifo_group_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('fifo_group_num',0,0,'fifo_group','fifo_group_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'pass_control_id' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('pass_control_id',0,0,'pass_control_info','pass_control_id',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'fifo_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('fifo_num',0,0,'trade_item_fill_fifo','fifo_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'qty_adj_rule_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('qty_adj_rule_num',0,0,'qty_adj_rule','qty_adj_rule_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'exch_fifo_alloc_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('exch_fifo_alloc_num',0,0,'exch_fifo_alloc','exch_fifo_alloc_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'gtc_agreement_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('gtc_agreement_num',0,90000000,'gtc','agreement_num',1)
go

/* The following entry will replace the entry 'gtc_agreement_num' */
IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'acct_agreement_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('acct_agreement_num',0,90000000,'account_agreement','agreement_num',1)
go

/* For Java Application -- requested by Paul S.  9/28/2004 */

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'user_login_history_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('user_login_history_oid',0,0,'user_login_history','oid',1)
go


IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'fx_hedge_rate_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('fx_hedge_rate_num',0,0,'fx_hedge_rate','fx_hedge_rate_num',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'fd_id' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('fd_id',0,0,'function_detail','fd_id',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'fdv_id' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('fdv_id',0,0,'function_detail_value','fdv_id',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'ti_field_mod_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('ti_field_mod_oid', 0, 0, 'ti_field_modified','oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'als_module_group_id' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('als_module_group_id',0,0,'server_config','als_module_group_id',1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'trade_group_num' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('trade_group_num', 0, 0, 'trade_group', 'trade_group_num', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'dflt_num' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('dflt_num', 0, 0, 'trade_default', 'dflt_num', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'pipeline_cycle_num' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('pipeline_cycle_num', 0, 0, 'pipeline_cycle', 'pipeline_cycle_num', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'icts_entity_name_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('icts_entity_name_oid', 0, 0, 'icts_entity_name', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'entity_tag_definition_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('entity_tag_definition_oid', 0, 0, 'entity_tag_definition', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'entity_tag_key' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('entity_tag_key', 0, 0, 'entity_tag', 'entity_tag_key', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'actual_lot_num' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('actual_lot_num', 0, 0, 'actual_lot', 'actual_lot_num', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'tank_num' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('tank_num', 0, 0, 'location_tank_info', 'tank_num', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'custom_voucher_range_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('custom_voucher_range_oid', 0, 0, 'custom_voucher_range', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'custom_contract_range_num' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('custom_contract_range_num', 0, 0, 'custom_contract_range', 'range_num', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'user_default_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('user_default_oid', 0, 0, 'user_default', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'vessel_dist_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('vessel_dist_oid', 0, 0, 'vessel_dist', 'oid', 1)
go

IF NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'truck_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num (num_col_name,loc_num,last_num,owner_table,owner_column,trans_id) 
   VALUES('truck_num',0,0,'truck','truck_num',1)
go

IF NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'driver_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num (num_col_name,loc_num,last_num,owner_table,owner_column,trans_id) 
   VALUES('driver_num',0,0,'driver', 'driver_num',1)
go

IF NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'release_doc_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num (num_col_name,loc_num,last_num,owner_table,owner_column,trans_id) 
   VALUES('release_doc_num',0,0,'release_document','release_doc_num',1)
go

IF NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'release_doc_driver_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num (num_col_name,loc_num,last_num,owner_table,owner_column,trans_id) 
   VALUES('release_doc_driver_oid',0,0,'release_document_driver','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'icts_message_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('icts_message_oid', 0, 0, 'icts_message', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'icts_message_detail_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('icts_message_detail_oid', 0, 0, 'icts_message_detail', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'acct_bookcomp_key' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('acct_bookcomp_key', 0, 0, 'acct_bookcomp', 'acct_bookcomp_key', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'acct_restriction_num' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('acct_restriction_num', 0, 0, 'acct_bookcomp_restrict', 'acct_restriction_num', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'acct_collat_num' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('acct_collat_num', 0, 0, 'acct_bookcomp_collatera', 'acct_collat_num', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'acct_guarantee_num' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('acct_guarantee_num', 0, 0, 'acct_bookcomp_guarantee', 'acct_guarantee_num', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'var_run_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('var_run_oid', 0, 0, 'var_run', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'uic_report_type_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('uic_report_type_oid',0,0,'uic_report_type','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'uic_report_mod_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('uic_report_mod_oid',0,0,'uic_report_modification','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'uic_rpt_values_config_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('uic_rpt_values_config_oid',0,0,'uic_rpt_values_config','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'uic_rpt_criteria_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('uic_rpt_criteria_oid',0,0,'uic_rpt_criteria','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'uic_rpt_criteria_entity_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('uic_rpt_criteria_entity_oid',0,0,'uic_rpt_criteria_entity','oid',1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'credit_reserve_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('credit_reserve_oid', 0, 0, 'credit_reserve', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'rms_seq_num' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('rms_seq_num', 0, 0, null, null, 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'rms_conf_seq_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('rms_conf_seq_num', 0, 0, NULL, NULL, 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'posting_search_prec_num' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('posting_search_prec_num', 0, 0, 'posting_search_prec', 'posting_search_prec_num', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'scenario_oid' and
                     loc_num = 0)
   insert into dbo.new_num 
         (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('scenario_oid', 0, 0, 'scenario', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'scenario_item_oid' and
                     loc_num = 0)
   insert into dbo.new_num 
         (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('scenario_item_oid', 0, 0, 'scenario_item', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'live_scenario_oid' and
                     loc_num = 0)
   insert into dbo.new_num 
         (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('live_scenario_oid', 0, 0, 'live_scenario', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'live_scenario_item_oid' and
                     loc_num = 0)
   insert into dbo.new_num 
         (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('live_scenario_item_oid', 0, 0, 'live_scenario_item', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'ext_trade_loading_sched_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('ext_trade_loading_sched_oid', 0, 0, 'ext_trade_loading_sched', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'fx_exposure_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('fx_exposure_oid', 0, 0, 'fx_exposure', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'fx_exposure_currency_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('fx_exposure_currency_oid', 0, 0, 'fx_exposure_currency', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'fx_linking_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('fx_linking_oid', 0, 0, 'fx_linking', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'fx_cost_draw_down_hist_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('fx_cost_draw_down_hist_oid', 0, 0, 'fx_cost_draw_down_hist', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'acct_bc_ot_crinfo_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('acct_bc_ot_crinfo_oid', 0, 0, 'acct_bc_ot_crinfo', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'lc_bankfee_autogen_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('lc_bankfee_autogen_oid', 0, 0, 'lc_bankfee_autogen', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'lc_bankfee_refdata_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('lc_bankfee_refdata_oid', 0, 0, 'lc_bankfee_refdata', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'fx_exposure_dist_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('fx_exposure_dist_oid', 0, 0, 'fx_exposure_dist', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'pos_limit_def_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('pos_limit_def_oid', 0, 0, 'pos_limit_definition', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'cost_template_group_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('cost_template_group_oid', 0, 0, 'cost_template_group', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'cost_template_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('cost_template_oid', 0, 0, 'cost_template', 'oid', 1)
go

if NOT EXISTS (select 1
               from new_num
               where num_col_name = 'shipment_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('shipment_oid', 0, 0, 'shipment', 'oid', 1)
go

if NOT EXISTS (select 1
               from new_num
               where num_col_name = 'parcel_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('parcel_oid', 0, 0, 'parcel', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'quality_slate_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('quality_slate_oid', 0, 0, 'quality_slate', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'qual_slate_cmdty_spec_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('qual_slate_cmdty_spec_oid', 0, 0, 'qual_slate_cmdty_spec', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'qual_slate_cmdty_sptest_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('qual_slate_cmdty_sptest_oid', 0, 0, 'qual_slate_cmdty_sptest', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'parcel_quality_slate_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('parcel_quality_slate_oid', 0, 0, 'parcel_quality_slate', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'cost_rate_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('cost_rate_oid', 0, 0, 'cost_rate', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'facility_link_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('facility_link_oid', 0, 0, 'facility_link', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'segment_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('segment_oid', 0, 0, 'segment', 'oid', 1)
go


if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'path_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('path_oid', 0, 0, 'path', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'sys_resources_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('sys_resources_oid', 0, 0, 'sys_resources', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'user_resources_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('user_resources_oid', 0, 0, 'user_resources', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'function_action_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('function_action_oid', 0, 0, 'function_action', 'oid', 1)
go

if NOT EXISTS (select 1
               from new_num
               where num_col_name = 'ext_pos_num' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('ext_pos_num', 0, 0, 'external_position', 'ext_pos_num', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'route_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('route_oid', 0, 0, 'route', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'route_point_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('route_point_oid', 0, 0, 'route_point', 'oid', 1)
go

if NOT EXISTS (select 1
               from new_num
               where num_col_name = 'lm_acctdata_mapping_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('lm_acctdata_mapping_oid', 0, 0, 'lm_acctdata_mapping', 'oid', 1)
go

if NOT EXISTS (select 1
               from new_num
               where num_col_name = 'lm_marketdata_mapping_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('lm_marketdata_mapping_oid', 0, 0, 'lm_marketdata_mapping', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'lm_net_position_history_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('lm_net_position_history_oid', 0, 0, 'lm_net_position_history', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'lm_margin_history_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('lm_margin_history_oid', 0, 0, 'lm_margin_history', 'oid', 1)
go

if NOT EXISTS (select 1
               from new_num
               where num_col_name = 'lm_risk_file_oid' and loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('lm_risk_file_oid', 0, 0, 'lm_risk_file', 'oid', 1)
go


if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'rin_definition_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('rin_definition_oid', 0, 0, 'rin_definition', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'rin_equivalence_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('rin_equivalence_oid', 0, 0, 'rin_equivalence', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'rin_obligation_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('rin_obligation_oid', 0, 0, 'rin_obligation', 'oid', 1)
go

if NOT EXISTS (select 1
               from new_num
               where num_col_name = 'rg_staging_acct_addr_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('rg_staging_acct_addr_oid', 0, 0, 'rg_staging_acct_address', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'confirm_method_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('confirm_method_oid', 0, 0, 'confirm_method', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'confirm_template_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('confirm_template_oid', 0, 0, 'confirm_template', 'oid', 1)
go


-- Added by issue #1341748
if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'symphony_outbound_data_row_id' and
                     loc_num = 0)
   insert into dbo.new_num(num_col_name, loc_num, last_num, owner_table, owner_column, trans_id)
      values('symphony_outbound_data_row_id', 0, 0, 'symphony_outbound_data', 'row_id', 1)
go

-- Added by issue 1316673, #1338184
if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'risk_cover_num' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('risk_cover_num', 0, 1, 'risk_cover', 'risk_cover_num', 1)
go

-- Added by issue #1336020
if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'feed_cash_inbound_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('feed_cash_inbound_oid', 0, 0, 'feed_cash_inbound', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'rc_assign_num' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('rc_assign_num', 0, 1, 'rc_assign_trade', 'assign_num', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'feed_definition_xsd_xml_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('feed_definition_xsd_xml_oid', 0, 0, 'feed_definition_xsd_xml', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'ag_external_codes_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('ag_external_codes_oid', 0, 0, 'ag_external_codes', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'fips_state_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('fips_state_oid', 0, 0, 'fips_state', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'fips_county_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('fips_county_oid', 0, 0, 'fips_county', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'fips_city_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('fips_city_oid', 0, 0, 'fips_city', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'feed_refdata_mapping_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('feed_refdata_mapping_oid', 0, 0, 'feed_refdata_mapping', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'eipp_task_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id)
      values ('eipp_task_oid', 0, 0, 'eipp_task', 'oid', 1)
go

-- Added by issue #1357435
if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'ag_consignee_tankage_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('ag_consignee_tankage_oid', 0, 0, 'ag_consignee_tankage', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'win_id' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('win_id', 0, 0, 'riskmgr_win_def', 'win_id', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'piv_def_id' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('piv_def_id', 0, 0, 'riskmgr_win_pivot_def', 'piv_def_id', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'row_id' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('row_id', 0, 0, 'cki_outbound_data', 'row_id', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'pl_offset_transfer_oid' and loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('pl_offset_transfer_oid', 0, 0, 'pl_offset_transfer', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'detail_num' and loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('detail_num', 0, 0, 'ai_est_actual_detail', 'detail_num', 1)
go

-- In FR9, this entry has been moved to the new icts_trans_sequence table. However, the JAVA apps
-- uses new_num table as a metadata table. So, we still need to keep this entry in new_num table
-- for JAVA apps.
IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'trans_id' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('trans_id',0,1,'icts_transaction','trans_id',0)
go

/* ---------------------------------------------------------------------------------
    The following 5 entries were added for LIVE PRICES
   --------------------------------------------------------------------------------- */

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'implied_pr_curve_hist_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('implied_pr_curve_hist_oid', 0, 0, 'implied_pr_curve_hist', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'implied_pr_curve_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('implied_pr_curve_oid', 0, 0, 'implied_pr_curve', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'implied_pr_differential_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('implied_pr_differential_oid', 0, 0, 'implied_pr_differential', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'live_option_pr_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('live_option_pr_oid', 0, 0, 'live_option_pr', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'live_option_pr_hist_oid' and
                     loc_num = 0)
   insert into new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('live_option_pr_hist_oid', 0, 0, 'live_option_pr_hist', 'oid', 1)
go

/* ---------------------------------------------------------------------------------
    The following entries were added for Mercuria's Bank Position Reporting
   --------------------------------------------------------------------------------- */

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'cost_credit_exposure_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('cost_credit_exposure_oid',0,0,'cost_credit_exposure','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'inv_credit_exposure_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('inv_credit_exposure_oid',0,0,'inv_credit_exposure','oid',1)
go

/* *****************************************************************
    CVX TI Project
   ***************************************************************** */

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_feed_definition_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_feed_definition_oid',0,0,'TI_feed_definition','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_inbound_data_xml_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_inbound_data_xml_oid',0,0,'TI_inbound_data_xml','oid',1)
go      

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'ti_plan_exch_obj_feed_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('ti_plan_exch_obj_feed_oid',0,0,'ti_plan_exch_obj_feed','oid',1)
go        

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_demand_forecast_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_demand_forecast_oid',0,0,'TI_demand_forecast','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_feed_error_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_feed_error_oid',0,0,'TI_feed_error','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_RS_refinery_plan_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_RS_refinery_plan_oid',0,0,'TI_RS_refinery_plan','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_SOP_refinery_plan_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_SOP_refinery_plan_oid',0,0,'TI_SOP_refinery_plan','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_refinery_actual_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_refinery_actual_oid',0,0,'TI_refinery_actual','oid',1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_sop_trade_plan_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_sop_trade_plan_oid',0,0,'TI_sop_trade_plan','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_PSMV_feed_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_PSMV_feed_oid',0,0,'TI_PSMV_feed','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_TSW_schedule_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_TSW_schedule_oid',0,0,'TI_TSW_schedule','oid',1)
go         

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_rate_table_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_rate_table_oid',0,0,'TI_rate_table','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'booked_inv_reconcil_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('booked_inv_reconcil_oid',0,0,'booked_inv_reconcil','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_book_inv_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_book_inv_oid',0,0,'TI_book_inv','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_exch_bal_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_exch_bal_oid',0,0,'TI_exch_bal','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_ZDEF_exch_objective_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_ZDEF_exch_objective_oid',0,0,'TI_ZDEF_exch_objective','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_financial_results_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_financial_results_oid',0,0,'TI_financial_results','oid',1)
go         

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_PSMVal_feed_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_PSMVal_feed_oid',0,0,'TI_PSMVal_feed','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'financial_reconcil_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('financial_reconcil_oid',0,0,'financial_reconcil','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_TSW_spot_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_TSW_spot_oid',0,0,'TI_TSW_spot','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_PSMVol_spot_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_PSMVol_spot_oid',0,0,'TI_PSMVol_spot','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_feed_schedule_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_feed_schedule_oid',0,0,'TI_feed_schedule','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_req_res_xml_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_req_res_xml_oid',0,0,'TI_req_res_xml','oid',1)
go          

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'TI_feed_transaction_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
   VALUES('TI_feed_transaction_oid',0,0,'TI_feed_transaction','oid',1)
go         

/* *****************************************************************
    Symphony Gateway - Mercuria/Navita and Pomax
   ***************************************************************** */

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'feed_definition_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('feed_definition_oid', 0, 0, 'feed_definition', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'feed_data_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('feed_data_oid', 0, 0, 'feed_data', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'feed_detail_data_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('feed_detail_data_oid', 0, 0, 'feed_detail_data', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'feed_error_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('feed_error_oid', 0, 0, 'feed_error', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'feed_scheduler_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('feed_scheduler_oid', 0, 0, 'feed_scheduler', 'oid', 1)
go

go
if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'feed_xsd_xml_text_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('feed_xsd_xml_text_oid', 0, 0, 'feed_xsd_xml_text', 'oid', 1)
go

/* *****************************************************************
    Mapping of the external data with symphony
   ***************************************************************** */

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'ext_ref_keys_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('ext_ref_keys_oid', 0, 0, 'ext_ref_keys', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'ext_refdata_mapping_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('ext_refdata_mapping_oid', 0, 0, 'ext_refdata_mapping', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'ext_trans_keys_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('ext_trans_keys_oid', 0, 0, 'ext_trans_keys', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'ext_trandata_mapping_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('ext_trandata_mapping_oid', 0, 0, 'ext_trandata_mapping', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'pm_trade_match_criteria_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('pm_trade_match_criteria_oid', 0, 0, 'pm_trade_match_criteria', 'oid', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'external_trade_type_oid' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('external_trade_type_oid', 0, 0, 'external_trade_type', 'oid', 1)
go

IF NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'bulk_voucher_queue_oid' and
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('bulk_voucher_queue_oid', 0, 0, 'bulk_voucher_queue', 'oid', 1)
go

IF NOT EXISTS (select 1 
               from dbo.new_num
               where num_col_name = 'msi_feed_data_oid' and 
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('msi_feed_data_oid', 0, 0, 'msi_feed_data', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'inv_actual_fifo_oid' and 
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('inv_actual_fifo_oid', 0, 0, 'inv_actual_fifo', 'oid', 1)
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'inv_actual_oid' and 
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('inv_actual_oid', 0, 0, 'inv_actual', 'oid', 1)
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'market_formula_default_oid' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('market_formula_default_oid', 0, 0, 'market_formula_default', 'id', 1);
go

IF NOT EXISTS (select * 
               from dbo.new_num
               where num_col_name = 'inv_fifo_num' and 
                     loc_num = 0)
   INSERT INTO dbo.new_num(num_col_name,loc_num,last_num,owner_table,owner_column,trans_id)
      VALUES('inv_fifo_num', 0, 0, 'inventory', 'inv_fifo_num', 1)
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'marketdata_supplier_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('marketdata_supplier_id', 0, 0, 'marketdata_supplier', 'id', 1);
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'market_value_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('market_value_id', 0, 0, 'market_value', 'id', 1);
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'parser_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('parser_id', 0, 0, 'parser', 'id', 1);
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'parser_field_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('parser_field_id', 0, 0, 'parser_field', 'id', 1);
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'parser_field_map_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('parser_field_map_id', 0, 0, 'parser_field_map', 'id', 1);
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'priced_quote_period_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('priced_quote_period_id', 0, 0, 'priced_quote_period', 'id', 1);
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'product_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('product_id', 0, 0, 'product', 'id', 1);
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'quote_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('quote_id', 0, 0, 'quote', 'id', 1);
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'quote_marketdata_source_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('quote_marketdata_source_id', 0, 0, 'quote_marketdata_source', 'id', 1);
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'quote_period_description_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('quote_period_description_id', 0, 0, 'quote_period_description', 'id', 1);
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'quote_period_duration_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('quote_period_duration_id', 0, 0, 'quote_period_duration', 'id', 1);
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'valid_quote_duration_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('valid_quote_duration_id', 0, 0, 'valid_quote_duration', 'id', 1);
go

if not exists (select 1 
               from dbo.new_num 
               where num_col_name = 'venue_id' and 
                     loc_num = 0) 
   insert into dbo.new_num 
        (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id) 
      values ('venue_id', 0, 0, 'venue', 'id', 1);
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'file_load_id' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id)
      values ('file_load_id', 0, 0, 'file_load', 'id', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'data_file_id' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id)
      values ('data_file_id', 0, 0, 'data_file', 'id', 1)
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'trigger_actual_num' and
                     loc_num = 0)
   insert into dbo.new_num (num_col_name, loc_num, last_num, owner_table, owner_column, trans_id)
      values ('trigger_actual_num', 0, 0, 'formula_body_trigger_actual', 'trigger_actual_num', 1)
go
