set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table account
go

print 'Loading system seed data into the account table ...'
go

insert into dbo.account 
    (acct_num, acct_short_name, acct_full_name, acct_status,
     acct_type_code, acct_parent_ind, acct_sub_ind, trans_id)
values(1, 'TC', 'AMPHORA', 'A', 'PEICOMP', 'N', 'N', 1)
go

insert into dbo.account 
    (acct_num, acct_short_name, acct_full_name, acct_status,
     acct_type_code, acct_parent_ind, acct_sub_ind, trans_id)
values(2, 'TBDACCT', 'TBD ACCOUNT', 'I', 'CUSTOMER', 'N', 'N', 1)
go

exec dbo.refresh_a_last_num 'account', 'acct_num'
go
