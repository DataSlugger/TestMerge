set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table uom
go

print 'Loading seed reference data into the uom table ...'
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id)
      values('%', 'N', 'A', 'PERCENT', 'PERCENT', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('AC', 'V', 'A', 'ALLOWANCE CREDI', 'ALLOWANCE CREDIT', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('BAGS', 'W', 'A', 'BAGS', 'BAGS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('BBL', 'V', 'A', 'BARREL', 'BARRELS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('BF', 'V', 'A', 'BOARD FEET', 'BOARD FEET', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('BG60', 'W', 'A', '60 KILO BAG', '60 KILO BAGS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('BG69', 'W', 'A', '69 KILO BAG', '69 KILO BAGS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('BG70', 'W', 'A', '70 KILO BAG', '70 KILO BAGS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('BG75', 'W', 'A', '75 KILO BAG', '75 KILO BAGS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('BU', 'V', 'A', 'BUSHEL', 'BUSHELS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('CF', 'V', 'A', 'CUBIC FEET', 'CUBIC FEET', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('CMBT', 'V', 'A', 'CONTRACT OF NYM', 'CONTRACTS OF NYMEX MMBTU''S', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('CWT', 'W', 'A', 'HUNDRED POUND W', 'HUNDRED POUNDS WEIGHT', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('DLTT', 'W', 'A', 'DRY LONG TON', 'DRY LONG TONS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('DMT', 'W', 'A', 'DRY METRIC TON', 'DRY METRIC TONS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('FTO', 'W', 'A', 'FTO', 'FINE TROY OUNCES', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('GAL', 'V', 'A', 'GALLON', 'GALLONS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('GJ', 'E', 'A', 'GIGA-JOULE', 'GIGA-JOULES', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('GM', 'W', 'A', 'GRAM', 'GRAMS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('KG', 'W', 'A', 'KILOGRAM', 'KILOGRAMS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('KG46', 'W', 'A', '46 KILOGRAMS', '46 KILOGRAMS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('KG50', 'W', 'A', '50 KILOGRAMS', '50 KILOGRAMS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('LB', 'W', 'A', 'POUND', 'POUNDS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('LITR', 'V', 'A', 'LITERS', 'LITERS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('LOTS', 'N', 'A', 'EXCHANGE LOT', 'EXCHANGE LOT', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('LT', 'W', 'A', 'LONG TON', 'LONG TONS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('M3', 'V', 'A', 'CUBIC METERS', 'CUBIC METERS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('MB', 'V', 'A', ',000 BARREL', 'THOUSAND BARRELS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('MBU', 'V', 'A', ',000 BUSHELS', 'THOUSAND BUSHELS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('MG', 'V', 'A', 'THOUSAND GALLON', 'THOUSAND GALLONS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('MMBT', 'E', 'A', 'MMBTU', 'MILLION BRITISH THERMAL UNITS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('MMUN', 'N', 'A', 'MILLION UNIT', 'MILLIONS OF UNITS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('MT', 'W', 'A', 'METRIC TON', 'METRIC TONS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('MTU', 'W', 'A', 'MT UNIT', 'METRIC TON UNITS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('MUN', 'N', 'A', ',000 UNIT', 'THOUSAND OF UNITS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('MW', 'P', 'A', 'MEGAWATT', 'MEGAWATTS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('MWH', 'E', 'A', 'MEGAWATT HOUR', 'MEGAWATT HOURS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('QUI', 'W', 'A', 'QUINTALES', 'QUINTALES (SPANISH POUNDS)', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('STN', 'W', 'A', 'SHORT TON', 'SHORT TONS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('STU', 'W', 'A', 'ST UNIT', 'SHORT TON UNITS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('THER', 'E', 'A', 'THERMS', 'THERMS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('TROZ', 'W', 'A', 'TROY OZ', 'TROY OUNCES', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('UNIT', 'N', 'A', 'UNIT', 'CURRENCY UNITS', NULL, 1)
go

insert into dbo.uom (uom_code, uom_type, uom_status, uom_short_name, uom_full_name, uom_num, trans_id) 
      values('WMT', 'W', 'A', 'WET METRIC TON', 'WET METRIC TONS', NULL, 1)
go
