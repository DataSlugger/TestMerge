set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the commodity table ...'
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('ALL', 'N', 'G', 'I', 'ALL COMMODITIES', 
'ROLLUP GROUP INCLUDING ALL PRODUCTS', 'USA', NULL, 'USD', NULL, NULL, NULL, 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('BROKERAG', 'N', 'P', 'A', 'BROKERAG', 'Brokerage', 
'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('CASH_ADJ', 'N', 'O', 'A', 'CASH ADJUSTMENT', 
'CASH ADJUSTMENT', NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('FRT-R', 'N', 'O', 'A', 'FREIGHT-RAILCAR', 
'FREIGHT COST FOR RAILCAR', NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('FUT_COMM', 'N', 'O', 'A', 'FUTURES COMM', 
'FUTURES COMMISSION', NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('OTCPREM', 'N', 'P', 'A', 'OTC Premium', 
'Over The Counter Options', 'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('PL', 'N', 'O', 'A', 'PL COST', 
'PROFIT LOSS-RELATED COST', 'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('REMAINDR', 'N', 'G', 'A', 'REMAINDER', 
'REMAINDER', NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('RES', 'N', 'O', 'A', 'RESERVE COST', 
'RESERVE COST FOR PORTFOLIO', NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('SETTLEME', 'N', 'O', 'A', 'SETTLEMENT', 
'SETTLEMENT COST FOR OTC OPT', 'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('TAX', 'N', 'O', 'A', 'TAX', 
'TAX-RELATED COST', 'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('WRITEOFF', 'N', 'G', 'I', 'WRITE-OFF', 
'WRITE-OFF', NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into dbo.commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('USD', 'N', 'C', 'A', 'USD', 'U.S. DOLLAR', 'USA', 
         NULL, 'USD', 1.000000, NULL, NULL, 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, trans_id)
values('JV', 'N', 'O', 'A', 'JV Cost', 
'Joint Venture Cost', 'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, 
 cmdty_category_code, trans_id)
values('TRANSPRT', 'N', 'O', 'A', 'TRANSPORT', 'TRANSPORT', NULL, 
       NULL, NULL, 0.0, NULL, 'MT', 'DOMESTIC', 1) 
go

insert into dbo.commodity 
(cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
 cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
 prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, 
 cmdty_category_code, trans_id)
values('/', 'N', 'T', 'A', 'Root Commodity', 'Root Commodity for Rollup Table',
       NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

if not exists (select 1
               from dbo.commodity
               where cmdty_code = 'TARIFF')               
   insert into dbo.commodity 
      (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
       cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
       prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, 
       cmdty_category_code, trans_id)
   values('TARIFF', 'N', 'O', 'A', 'Tariff', 'Tariff', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

if not exists (select 1 
               from dbo.commodity 
               where cmdty_code = 'POMAXSEC')
   insert into dbo.commodity
        (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
         cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
         prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, 
         cmdty_category_code, trans_id)
      values('POMAXSEC', 'N', 'G', 'A', 'POMAX SEC', 'POMAX SEC COST GROUP', 
             NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

if not exists (select 1 
               from dbo.commodity 
               where cmdty_code = 'CANCELFE' and 
                     cmdty_full_name='CANCEL FOR FEE')
    insert into dbo.commodity
        (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
         cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
         prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, 
         cmdty_category_code, trans_id)
        values('CANCELFE', 'N', 'O', 'A', 'CANCELFORFEE', 'CANCEL FOR FEE', 
                NULL, NULL, NULL, NULL, NULL, NULL, NULL,1)
go

if not exists (select 1 
               from dbo.commodity 
               where cmdty_code = 'FMLCOST')
   insert into dbo.commodity
        (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
         cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
         prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, 
         cmdty_category_code, trans_id)
      values('FMLCOST', 'N', 'O', 'A', 'FORMULACOST', 'FORMULA COST', 
             NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

if not exists (select 1 
               from dbo.commodity 
               where cmdty_code = 'ExcisTax')
   insert into dbo.commodity
        (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
         cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
         prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, 
         cmdty_category_code, trans_id)
      values('ExcisTax', 'N', 'O', 'A', 'ExciseTax', 'Excise Tax', 'USA',
             NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

if not exists (select 1 
               from dbo.commodity 
               where cmdty_code = 'SalesTax')
   insert into dbo.commodity
        (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
         cmdty_short_name, cmdty_full_name, country_code, cmdty_loc_desc,
         prim_curr_code, prim_curr_conv_rate, prim_uom_code, sec_uom_code, 
         cmdty_category_code, trans_id)
      values('SalesTax', 'N', 'O', 'A', 'SalesTax', 'Sales Tax', 'USA',
             NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

if not exists (select 1 
               from dbo.commodity 
               where cmdty_code = 'DEMURRA' and 
                     cmdty_full_name = 'DEMURRA')
   insert into dbo.commodity
        (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
         cmdty_short_name, cmdty_full_name, trans_id)
      values('DEMURRA', 'N', 'O', 'A', 'DEMURRA', 'DEMURRA', 1)
go

if not exists (select 1 
               from dbo.commodity 
               where cmdty_code = 'EIPP' and 
                     cmdty_full_name = 'EIPP CMDTYS')
   insert into dbo.commodity
        (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
         cmdty_short_name, cmdty_full_name, trans_id)
      values('EIPP', 'N', 'G', 'A', 'EIPP', 'EIPP CMDTYS', 1)
go

if not exists (select 1 
               from dbo.commodity 
               where cmdty_code = 'GOODS' and 
                     cmdty_full_name = 'EIPP CMDTYS')
   insert into dbo.commodity
        (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
         cmdty_short_name, cmdty_full_name, trans_id)
      values('GOODS', 'N', 'G', 'A', 'GOODS', 'EIPP CMDTYS', 1)
go

if not exists (select 1 
               from dbo.commodity 
               where cmdty_code = 'BRENT' and 
                     cmdty_full_name = 'BRENT CRUDE')
   insert into dbo.commodity
        (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
         cmdty_short_name, cmdty_full_name, trans_id)
      values('BRENT', 'Y', 'P', 'A', 'BRENT CRUDE', 'BRENT CRUDE', 1)
go

if not exists (select 1 
               from dbo.commodity 
               where cmdty_code = 'BROKBLOC' and 
                     cmdty_full_name = 'BROKERAGE-BLOCK')
   insert into dbo.commodity
        (cmdty_code, cmdty_tradeable_ind, cmdty_type, cmdty_status,
         cmdty_short_name, cmdty_full_name, trans_id)
      values('BROKBLOC', 'N', 'O', 'A', 'BROKERAGE-BLOCK', 'BROKERAGE-BLOCK', 1)
go
