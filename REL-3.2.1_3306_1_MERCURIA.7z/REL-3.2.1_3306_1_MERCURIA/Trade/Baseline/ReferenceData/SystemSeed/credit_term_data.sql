set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table credit_term
go

print 'Loading system seed data into the credit_term table ...'
go

insert into dbo.credit_term values('B/G', 'BANK GUARANTEE', 'BANK GUARANTEE', 'N', 
NULL, 1)
go

insert into dbo.credit_term values('BB', 'BID BOND', 'BID BOND', 'Y', 'BIDBOND', 1)
go

insert into dbo.credit_term values('CDOCLC', 'CONFIRMED DOC L/C', 
'CONFIRMED DOC L/C', 'Y', 'DOCMNTRY', 1)
go

insert into dbo.credit_term values('COLCASH', 'COLLATERAL CASH', 'COLLATERAL CASH', 
'N', NULL, 1)
go

insert into dbo.credit_term values('COLSEC', 'COLLATERAL SECURITIES', 
'COLLATERAL SECURITIES', 'N', NULL, 1)
go

insert into dbo.credit_term values('IFRLC', 'IF REQUIRED L/C', 'IF REQUIRED L/C', 
'N', NULL, 1)
go

insert into dbo.credit_term values('LC', 'DOCUMENTARY L/C', 'DOCUMENTARY L/C', 'Y', 
'DOCMNTRY', 1)
go

insert into dbo.credit_term values('LCCOL', 'COLLATERAL L/C', 'COLLATERAL L/C', 'Y', 
'DOCMNTRY', 1)
go

insert into dbo.credit_term values('LCPB', 'DOC LC PERFORMANCE BOND', 
'DOC LC PERFORMANCE BOND', 'Y', 'DOCMNTRY', 1)
go

insert into dbo.credit_term values('NONE-SRV', 'NONE-SERVICE PROVIDER', 
'NONE -SRVC PROVIDER', 'N', NULL, 1)
go

insert into dbo.credit_term values('OPEN', 'OPEN CREDIT', 'OPEN CREDIT', 'N', NULL, 
1)
go

insert into dbo.credit_term values('OPENDLC', 'OPEN IF REQUIRED DOC. L/C', 
'OPEN IF REQUIRED DOC. L/C', 'N', 'DOCMNTRY', 1)
go

insert into dbo.credit_term values('OPENLCPP', 'OPEN / STANDBY L/C OR PREPAY', 
'OPEN / STANDBY L/C OR PREPAY', 'N', 'STANDBY', 1)
go

insert into dbo.credit_term values('OPENNL', 'OPEN  NO LIMIT', 'OPEN  NO LIMIT', 
'N', NULL, 1)
go

insert into dbo.credit_term values('OPENPB', 'OPEN PERFORMANCE BOND', 'OPEN', 'N', 
'PERFORM', 1)
go

insert into dbo.credit_term values('OPENPG', 'OPEN PARENT CO. GUARANTEE', 
'OPEN PARENT CO. GUARANTEE', 'N', 'PG', 1)
go

insert into dbo.credit_term values('OPENSBLC', 'OPEN IF REQUIRED STANDBY L/C', 
'OPEN IF REQUIRED STANDBY L/C', 'N', 'STANDBY', 1)
go

insert into dbo.credit_term values('OPENUN', 'OPEN PAYMENT UNDERTAKING', 
'OPEN PAYMENT UNDERTAKING', 'N', 'PYMNTUND', 1)
go

insert into dbo.credit_term values('PARTPP', 'PART PRE PAYMENT', 'PART PRE PAYMENT', 
'N', NULL, 1)
go

insert into dbo.credit_term values('PAYUNDER', 'PAYMENT UNDERTAKING', 
'PAYMENT UNDERTAKING', 'N', 'PYMNTUND', 1)
go

insert into dbo.credit_term values('PCG', 'PCG, IF RESCINDED', 'PCG, IF RESCINDED', 
'N', 'PG', 1)
go

insert into dbo.credit_term values('PPSBLC', 'PREPAY OR STANDBY L/C', 
'PREPAY OR STANDBY L/C', 'N', 'STANDBY', 1)
go

insert into dbo.credit_term values('SBLC', 'STANDBY L/C', 
'STANDBY LETTER OF CREDIT', 'Y', 'STANDBY', 1)
go

insert into dbo.credit_term values('SEE CRDT', 'SEE CREDIT', 
'CREDIT HAS YET TO BE SET UP', 'N', NULL, 1)
go

if not exists (select 1
               from dbo.credit_term
               where credit_term_code = 'CLEARED')
   insert into dbo.credit_term
       (credit_term_code, credit_term_desc, credit_term_contr_desc,
        credit_secure_ind, doc_type_code, trans_id)
     values('CLEARED', 'Clearing service', 'Clearing service', 'Y', null, 1)
go
