set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the risk_transfer_indicator table ...'
go

insert into dbo.risk_transfer_indicator 
   (risk_transfer_ind_code, risk_transfer_ind_desc, trans_id)
  values('EB', 'Eurobank', 1)
go

insert into dbo.risk_transfer_indicator 
   (risk_transfer_ind_code, risk_transfer_ind_desc, trans_id)
  values('SG', 'SG', 1)
go

