set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table commodity_category
go

print 'Loading seed reference data into the commodity_category table ...'
go

insert into dbo.commodity_category 
      (cmdty_category_code, cmdty_category_desc, trans_id)
   values('FOREIGN', 'Foreign', 1)
go

insert into dbo.commodity_category 
      (cmdty_category_code, cmdty_category_desc, trans_id)
   values('DOMESTIC', 'Domestic', 1)
go

insert into dbo.commodity_category 
      (cmdty_category_code, cmdty_category_desc, trans_id)
   values('NA', 'Not Applicable', 1)
go
