set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the department table ...'
go

if NOT EXISTS (select *
               from dbo.department
               where dept_code = 'TC')
   insert into dbo.department (dept_code, dept_name, profit_center_ind, trans_id)
      values('TC', 'TC', 'Y', 1)
go

