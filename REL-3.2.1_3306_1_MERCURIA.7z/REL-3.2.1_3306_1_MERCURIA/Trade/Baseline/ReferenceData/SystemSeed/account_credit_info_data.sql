set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the account_credit_info table ...'
go

/*
 account_credit_info 
    acct_num               int             NOT NULL,
    cr_status              char(1)         NOT NULL,
    dflt_cr_anly_init      char(3)         NOT NULL,
    primary_sic_num        smallint        NULL,
    acct_bus_desc          varchar(40)     NULL,

    first_trade_date       datetime        NULL,
    doing_bus_since_date   datetime        NULL,
    acct_cr_info_source    varchar(40)     NULL,
    fiscal_year_end_date   datetime        NULL,

    last_fin_doc_date      datetime        NULL,
    acct_fin_rep_freq      char(1)         NULL,
    confident_ind          char(1)         NULL,
    confident_sign_name    varchar(40)     NULL,
    acct_audit_code        varchar(100)    NULL,

    invoice_freq           char(1)         NULL,
    invoice_date           datetime        NULL,
    invoice_formula        varchar(40)     NULL,
    dflt_telex_hold_ind    char(1)         NOT NULL,

    bus_restriction_type   char(1)         NOT NULL,
    dflt_cr_term_code      char(8)         NOT NULL,
    country_code           char(8)         NOT NULL,
    pvt_ind_code           char(8)         NULL,
    bank_telex_cap_ind     char(1)         NULL,
    pei_guarantee_ind      char(1)         NULL,
    broker_pns_type        char(1)         NULL,
    cmnt_num               int             NULL,
    exposure_priority_code char(1)         NOT NULL,
    prim_cr_term_code      char(8)         NULL,
    sec_cr_term_code       char(8)         NULL,
    credit_agency_acct_num int             NULL,
    credit_rating          char(10)        NULL,

    trans_id               int             NOT NULL,
    country_risk           char(8)         NULL,
    pvt_public_desc        varchar(255)    NULL,
    use_dflt_cr_info       char(1)         NULL,
    sector_code	           char(4)         NULL,
    acct_bus_desc1	       varchar(80)     NULL,
    acct_bus_desc2	       varchar(80)     NULL
    margin_doc_email	     varchar(40)	   NULL,
    minimum_transfer_amt	 numeric(20, 8)  NULL
*/


insert into account_credit_info 
(
    acct_num,
    cr_status,
    dflt_cr_anly_init,
    primary_sic_num,
    acct_bus_desc,
    first_trade_date,
    doing_bus_since_date,
    acct_cr_info_source,
    fiscal_year_end_date,
    last_fin_doc_date,
    acct_fin_rep_freq,
    confident_ind,
    confident_sign_name,
    acct_audit_code,
    invoice_freq,
    invoice_date,
    invoice_formula,
    dflt_telex_hold_ind,
    bus_restriction_type,
    dflt_cr_term_code,
    country_code,
    pvt_ind_code,
    bank_telex_cap_ind,
    pei_guarantee_ind,
    broker_pns_type,
    cmnt_num,
    exposure_priority_code,
    prim_cr_term_code,
    sec_cr_term_code,
    credit_agency_acct_num,
    credit_rating,
    trans_id,
    country_risk,
    pvt_public_desc,
    use_dflt_cr_info,
    sector_code,
    acct_bus_desc1,
    acct_bus_desc2,
    margin_doc_email,
    minimum_transfer_amt
)
values(1,                           /* acct_num */
       'A',                         /* cr_status */
       'ICA',                       /* dflt_cr_anly_init */
       NULL,                        /* primary_sic_num */
       'DFLT',                      /* acct_bus_desc */
       'Jan  1 1900 12:00:00',      /* first_trade_date */
       'Jan  1 1900 12:00:00',      /* doing_bus_since_date */
       NULL,                        /* acct_cr_info_source */
       'Jan  1 1900 12:00:00',      /* fiscal_year_end_date */
       'Jan  1 1900 12:00:00',      /* last_fin_doc_date */
       NULL,                        /* acct_fin_rep_freq */
       NULL,                        /* confident_ind */
       NULL,                        /* confident_sign_name */
       NULL,                        /* acct_audit_code */
       NULL,                        /* invoice_freq */
       'Jan  1 1900 12:00:00',      /* invoice_date */
       NULL,                        /* invoice_formula */
       'Y',                         /* dflt_telex_hold_ind */
       'U',                         /* bus_restriction_type */
       'OPEN',                      /* dflt_cr_term_code */
       'USA',                       /* country_code */
       NULL,                        /* pvt_ind_code */
       NULL,                        /* bank_telex_cap_ind */
       NULL,                        /* pei_guarantee_ind */
       NULL,                        /* broker_pns_type */
       NULL,                        /* cmnt_num */
       'R',                         /* exposure_priority_code */
       NULL,                        /* prim_cr_term_code */
       NULL,                        /* sec_cr_term_code */
       NULL,                        /* credit_agency_acct_num */
       NULL,                        /* credit_rating */
       1,                           /* trans_id */
       NULL,                        /* country_risk */
       NULL,                        /* pvt_public_desc */
       'N',                         /* use_dflt_cr_info */
       NULL,                        /* sector_code */
       NULL,                        /* acct_bus_desc1 */
       NULL,                        /* acct_bus_desc2 */
       NULL,                        /* margin_doc_email */
       NULL                         /* minimum_transfer_amt */
)
go

