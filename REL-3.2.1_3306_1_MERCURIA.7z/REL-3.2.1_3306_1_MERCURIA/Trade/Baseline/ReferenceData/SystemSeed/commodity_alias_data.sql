set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the commodity_alias table ...'
go

declare @rows_affected int

if exists (select 1 
           from dbo.alias_source 
           where alias_source_code = 'RCLCITEM')
begin
   select cmdty_code, 'RCLCITEM' as alias_source_code into #comm
   from dbo.commodity cm
   where cmdty_type = 'O' and 
         cmdty_status = 'A' and
         not exists (select 1
	                   from dbo.commodity_alias ca
	                   where ca.alias_source_code = 'RCLCITEM' and
	                         cm.cmdty_code = ca.cmdty_code)
	 select @rows_affected = @@rowcount
	 
	 if @rows_affected > 0
	 begin   
	    select @rows_affected = 0
        
		  begin tran
		  begin try   
			  insert into dbo.commodity_alias
			        (cmdty_code, alias_source_code, cmdty_alias_name, trans_id)
			  select cmdty_code, alias_source_code, cmdty_code, 1 
			  from #comm
				select @rows_affected = @@rowcount
		  end try
		  begin catch
		    if @@trancount > 0
	         rollback tran 
			  print '=> Failed to add a new commodity_alias due to below error:' 
			  print '==> ERROR: ' + ERROR_MESSAGE()
			  goto endofscript
		  end catch
		  commit tran
			if @rows_affected > 0
				 print '=> Added the new alias_source_code ''RCLCITEM'' into the ''commodity_alias'' table.'
	 end
	 else
		  print '=> The alias_source_code ''RCLCITEM'' has alreay existed in table ''commodity_alias'' table.'
		
end
else 
   print '=> The alias_source_code ''RCLCITEM'' does not exist in the ''alias_source'' table.'

endofscript:
go

if object_id('tempdb..#comm', 'U') is not null
   exec('drop table #comm')
go
