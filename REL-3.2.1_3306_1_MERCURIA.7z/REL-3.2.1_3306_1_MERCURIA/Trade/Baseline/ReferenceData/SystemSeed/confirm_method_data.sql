set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the confirm_method table ...'
go

create table #confirm_method
(
   oid                   int IDENTITY primary key,
   confirm_method_name   varchar(50) not null,
)
go     
       
insert into #confirm_method(confirm_method_name)
select 'EMAIL'
union all
select 'FAX'
union all
select 'PREVIEW'
go


print ' '
go




/* ********************************************************************* */
/* The code body for adding records into the confirm_method table */
/* ********************************************************************* */

declare @oid                   int,
        @newoid                int,
        @confirm_method_name   varchar(50),
        @row_affected          int,
        @trans_id			         int,
        @smsg                  varchar(255)

   /* Begin - new trans_id script */        
   begin tran
   begin try
     exec dbo.gen_new_transaction_NOI @app_name = 'DbIssue_1354923'
   end try
   begin catch
     if @@trancount > 0
        rollback tran
     print '=> Error occurred while executing the ''gen_new_transaction_NOI'' stored procedure due to the error:'    
     print '==> ERROR: ' + ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran

   select @trans_id = null

   select @trans_id = last_num 
   from dbo.icts_trans_sequence 
   where oid = 1

   if @trans_id is null
   begin
      print '=> Failed to obtain a new trans_id for insert!'
      goto endofscript
   end

  /* End - new trans_id script */


select @oid = min(oid)
from #confirm_method

while @oid is not null
begin
   select @confirm_method_name = confirm_method_name
   from #confirm_method
   where oid = @oid

   if not exists (select 1
                  from dbo.confirm_method
                  where confirm_method_name = @confirm_method_name)
   begin
      begin tran
      select @newoid = isnull(max(oid), 0) + 1
      from dbo.confirm_method
   
      begin try
        insert into dbo.confirm_method
          (oid, confirm_method_name, trans_id)
         values(@newoid, @confirm_method_name, @trans_id)
        select @row_affected = @@rowcount
      end try
      begin catch
        if @@trancount > 0
           rollback tran
        print '=> Failed to add an confirm_method record for ''' + @confirm_method_name + ''' due to the error:'
        print '==> ERROR: ' + ERROR_MESSAGE()
        goto nextoid
      end catch
      commit tran
      select @smsg = '=> Added ''' + @confirm_method_name + ''' to the confirm_method table successfully!' 
      print @smsg
   end

nextoid:   
   select @oid = min(oid)
   from #confirm_method
   where oid > @oid        
end
endofscript:
drop table #confirm_method
go
                               
exec dbo.refresh_a_last_num 'confirm_method', 'oid'
go