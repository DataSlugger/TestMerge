set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the account_bank_info table ...'
go

declare @acct_num       int,
        @acct_bank_id   int,
        @errcode        int,
        @smsg           varchar(800),
        @rows_affected  int
        
  set @acct_num = (select acct_num
                   from dbo.account
                   where acct_short_name = 'TBDACCT' and
                         acct_type_code = 'CUSTOMER')
    
  if @acct_num is null
     goto endofscript
                          
  exec dbo.get_new_num_NOI 'acct_bank_id'
  set @acct_bank_id = null
  select @acct_bank_id = last_num 
  from dbo.new_num 
  where num_col_name = 'acct_bank_id'
		
  if @acct_bank_id is null
  begin
     RAISERROR('=> Failed to obtain a acct_bank_id!', 0, 1) with nowait
     goto endofscript
  end	
  		
	begin try
    insert into dbo.account_bank_info
         (acct_bank_id, acct_num, bank_name, p_or_r_ind, pay_method_code, acct_bank_info_status, trans_id) 
			values (@acct_bank_id, @acct_num, 'Cpty Bank To Be Filled', 'R', 'TBD', 'I', 1)
		set @rows_affected = @@rowcount
	end try
  begin catch
		set @errcode = ERROR_NUMBER()
		set @smsg = ERROR_MESSAGE()
		RAISERROR('=> Failed to add an account_bank_info record (with p_or_r_ind = ''R'') for the acct_num #%d due to the error:', 0, 1, @acct_num) with nowait
		RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait 
		goto endofscript
	end catch		   
	if @rows_affected > 0
		 RAISERROR('=> 1 account_bank_info record (with p_or_r_ind = ''R'') was added successfully!', 0, 1) with nowait
		 
  set @acct_bank_id = @acct_bank_id + 1
	begin try
    insert into dbo.account_bank_info
         (acct_bank_id, acct_num, bank_name, p_or_r_ind, pay_method_code, acct_bank_info_status, trans_id) 
			values (@acct_bank_id, @acct_num, 'Cpty Bank To Be Filled', 'P', 'TBD', 'I', 1)
		set @rows_affected = @@rowcount
	end try
  begin catch
		set @errcode = ERROR_NUMBER()
		set @smsg = ERROR_MESSAGE()
		RAISERROR('=> Failed to add an account_bank_info record (with p_or_r_ind = ''P'') for the acct_num #%d due to the error:', 0, 1, @acct_num) with nowait
		RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait 
		goto endofscript
	end catch		   
	if @rows_affected > 0
		 RAISERROR('=> 1 account_bank_info record (with p_or_r_ind = ''P'') was added successfully!', 0, 1) with nowait

	exec dbo.refresh_a_last_num 'account_bank_info', 'acct_bank_id'
	
endofscript:
go

