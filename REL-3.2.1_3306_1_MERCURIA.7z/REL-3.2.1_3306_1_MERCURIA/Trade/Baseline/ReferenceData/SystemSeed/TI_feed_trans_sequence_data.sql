set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Adding a TI_feed_trans_sequence record ...'
go

IF NOT EXISTS (select * 
               from dbo.TI_feed_trans_sequence
               where oid = 1)
   INSERT INTO dbo.TI_feed_trans_sequence (oid, last_num)
      VALUES(1, 0)
go
