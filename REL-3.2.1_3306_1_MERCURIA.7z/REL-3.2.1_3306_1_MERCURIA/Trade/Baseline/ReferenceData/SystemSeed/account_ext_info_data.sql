set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the account_ext_info table ...'
go

insert into dbo.account_ext_info  
    (acct_num, trans_id)
  values(1, 1)
go

