set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the uic_rpt_criteria_entity table ...'
go

create table #rpt_criteria_entity
(
   oid	                     numeric(18, 0)	IDENTITY PRIMARY KEY,
   report_type	             varchar(50)	  null,
   criteria_desc	           varchar(50)    null,
   entity_name	             varchar(30)    null,
   entity_criteria_selector	 varchar(255)	  null
)
go

/* ------------------------------------------------------------
     report_type   - 'Allocation'
     criteria_desc - 'Allocation Item'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Allocation Item', 'AiEstActual', 'allocItemNum')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Allocation Item', 'AllocationItem', 'allocItemNum')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Allocation Item', 'AllocationItemTransport', 'allocItemNum')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Allocation Item', 'Parcel', 'allocItemNum')
go


/* ------------------------------------------------------------
     report_type   - 'Allocation'
     criteria_desc - 'Allocation Number'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Allocation Number', 'AiEstActual', 'allocNum')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Allocation Number', 'Allocation', 'allocNum')
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Allocation Number', 'AllocationItem', 'allocNum')
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Allocation Number', 'AllocationItemTransport', 'allocNum')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Allocation Number', 'Parcel', 'allocNum')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Allocation Number', 'Shipment', 'allocNum')
go

/* ------------------------------------------------------------
     report_type   - 'Allocation'
     criteria_desc - 'MOT / Carrier'
   ------------------------------------------------------------ */
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'MOT / Carrier', 'AiEstActual', 'allocationItem.allocationItemTransport.motCode')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'MOT / Carrier', 'Allocation', 'motCode')
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'MOT / Carrier', 'AllocationItem', 'allocationItemTransport.transportation')
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'MOT / Carrier', 'AllocationItemTransport', 'transportation')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'MOT / Carrier', 'Parcel', 'allocationItem.allocationItemTransport.motCode')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'MOT / Carrier', 'Shipment', 'allocationItem.allocationItemTransport.motCode')
go

/* ------------------------------------------------------------
     report_type   - 'Allocation'
     criteria_desc - 'Credit Approved For Loading'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Credit Approved For Loading', 'AllocationItem', 'okToLoadInd')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Credit Approved For Loading', 'Parcel', 'allocationItem.okToLoadInd')
go

/* ------------------------------------------------------------
     report_type   - 'Allocation'
     criteria_desc - 'Shipment Number'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Shipment Number', 'AiEstActual', 'allocation.shipment.oid')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Shipment Number', 'Allocation', 'shipment.oid')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Shipment Number', 'AllocationItem', 'allocation.shipment.oid')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Shipment Number', 'AllocationItemTransport', 'allocation.shipment.oid')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Shipment Number', 'Parcel', 'shipmentNum')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Shipment Number', 'Shipment', 'oid')
go


/* ------------------------------------------------------------
     report_type   - 'Allocation'
     criteria_desc - 'Parcel Number'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Parcel Number', 'AiEstActual', 'allocationItem.parcel.oid')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Parcel Number', 'AllocationItem', 'parcel.oid')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Parcel Number', 'AllocationItemTransport', 'allocationItem.parcel.oid')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Allocation', 'Parcel Number', 'Parcel', 'oid')
go														    

/* ------------------------------------------------------------
     report_type   - 'Non-trade costs'
     criteria_desc - 'Booking company'
   ------------------------------------------------------------ */
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Non-trade costs', 'Booking company', 'Cost', 'costBookCompNum')
go

/* ------------------------------------------------------------
     report_type   - 'Non-trade costs'
     criteria_desc - 'Cost Code/Commodity'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Non-trade costs', 'Cost Code/Commodity', 'Cost', 'costCommodity.cmdtyCode')
go

/* ------------------------------------------------------------
     report_type   - 'Non-trade costs'
     criteria_desc - 'Counterparty'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Non-trade costs', 'Counterparty', 'Cost', 'acctNum')
go

/* ------------------------------------------------------------
     report_type   - 'Non-trade costs'
     criteria_desc - 'Due Date'
   ------------------------------------------------------------ */
  
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Non-trade costs', 'Due Date', 'Cost', 'costDueDate')
go

/* ------------------------------------------------------------
     report_type   - 'Non-trade costs'
     criteria_desc - 'Portfolio'
   ------------------------------------------------------------ */
  
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Non-trade costs', 'Portfolio', 'Cost', 'portfolio.portNum')
go 

/* ------------------------------------------------------------
     report_type   - 'Trade Entry'
     criteria_desc - 'Booking company'
   ------------------------------------------------------------ */
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Booking company', 'Cost', 'costBookCompNum')
	                                                                                                                            
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Booking company', 'TradeItem', 'bookingCompany.acctNum')
go

/* ------------------------------------------------------------
     report_type   - 'Trade Entry'
     criteria_desc - 'Commodity'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Commodity', 'TradeItem', 'commodity.cmdtyCode')
go

/* ------------------------------------------------------------
     report_type   - 'Trade Entry'
     criteria_desc - 'Contract date'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Contract date', 'Cost', 'tradeItem.tradeOrder.trade.contrDate')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Contract date', 'Trade', 'contrDate')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Contract date', 'TradeItem', 'tradeOrder.trade.contrDate')
go
 
/* ------------------------------------------------------------
     report_type   - 'Trade Entry'
     criteria_desc - 'Counterparty'
   ------------------------------------------------------------ */
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Counterparty', 'Cost', 'tradeItem.tradeOrder.trade.account.acctNum')
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Counterparty', 'Trade', 'account.acctNum')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Counterparty', 'TradeItem', 'tradeOrder.trade.account.acctNum')
go
 
/* ------------------------------------------------------------
     report_type   - 'Trade Entry'
     criteria_desc - 'Creation Date'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Creation Date', 'Cost', 'tradeItem.tradeOrder.trade.creationDate')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Creation Date', 'Trade', 'creationDate')
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Creation Date', 'TradeItem', 'tradeOrder.trade.creationDate')
go
 
/* ------------------------------------------------------------
     report_type   - 'Trade Entry'
     criteria_desc - 'Custom Contract Number'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Custom Contract Number', 'Cost', 'tradeItem.tradeOrder.trade.specialContractNum')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Custom Contract Number', 'Trade', 'specialContractNum')
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Custom Contract Number', 'TradeItem', 'tradeOrder.trade.specialContractNum')
go
 
/* ------------------------------------------------------------
     report_type   - 'Trade Entry'
     criteria_desc - 'delivery period'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'delivery period', 'TradeItem', 'delDateFrom')
go
 
/* ------------------------------------------------------------
     report_type   - 'Trade Entry'
     criteria_desc - 'MOT/Carrier'
   ------------------------------------------------------------ */
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'MOT/Carrier', 'TradeItem', 'mot.motShortName')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'MOT/Carrier', 'TradeItemWetPhy', 'motCode')
go 
 
/* ------------------------------------------------------------
     report_type   - 'Trade Entry'
     criteria_desc - 'Real Portfolio'
   ------------------------------------------------------------ */
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Real Portfolio', 'Cost', 'tradeItem.realPortfolio.portNum')

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Real Portfolio', 'TradeItem', 'realPortfolio.portNum')
go
 
/* ------------------------------------------------------------
     report_type   - 'Trade Entry'
     criteria_desc - 'Trading period'
   ------------------------------------------------------------ */
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Trading period', 'TradeItem', 'riskTradingPeriod')
go
	                                                                                                                            
/* ------------------------------------------------------------
     report_type   - 'Trade Entry'
     criteria_desc - 'Credit Approved'
   ------------------------------------------------------------ */
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Trade Entry', 'Credit Approved', 'TradeItem', 'okToLoadInd')
go

/* ------------------------------------------------------------
     report_type   - 'Vouchers'
     criteria_desc - 'Booking Company'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Vouchers', 'Booking Company', 'Voucher', 'voucherBookCompNum')
go

/* ------------------------------------------------------------
     report_type   - 'Vouchers'
     criteria_desc - 'Counterparty'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Vouchers', 'Counterparty', 'Voucher', 'acctNum')
go
 
/* ------------------------------------------------------------
     report_type   - 'Vouchers'
     criteria_desc - 'Custom Voucher Number'
   ------------------------------------------------------------ */
 
insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Vouchers', 'Custom Voucher Number', 'Voucher', 'voucherNum')
go

/* ------------------------------------------------------------
     report_type   - 'Vouchers'
     criteria_desc - 'Voucher Due Date'
   ------------------------------------------------------------ */

insert into #rpt_criteria_entity
    (report_type, criteria_desc, entity_name, entity_criteria_selector)
   values ('Vouchers', 'Voucher Due Date', 'Voucher', 'voucherDueDate')
go 




/* *********************************************************************** 
    Logic to add records into the 'uic_rpt_criteria_entity' table starts
    here
   *********************************************************************** */      
declare @oid                       int,
        @newoid                    int,
        @report_criteria_id 	     int,
        @entity_id	               int,
        @report_type	             varchar(50),
        @criteria_desc	           varchar(50),
        @entity_name	             varchar(30),
        @entity_criteria_selector	 varchar(255),
        @errcode                   int,
        @errmsg                    varchar(255)
  
select @oid = min(oid)
from #rpt_criteria_entity

while @oid is not null
begin
   select @report_type = report_type,
          @criteria_desc = criteria_desc,
          @entity_name = entity_name,
          @entity_criteria_selector	= entity_criteria_selector
   from #rpt_criteria_entity
   where oid = @oid
   
   select @report_criteria_id = oid
   from dbo.uic_rpt_criteria
   where report_type_id = (select oid
                           from dbo.uic_report_type
                           where report_type = @report_type) and
         criteria_desc = @criteria_desc
   
   if @report_criteria_id is null
   begin
      select @errmsg = 'Failed to find a uic_rpt_criteria record for the report_type ''' + @report_type + ''' and '
      select @errmsg = @errmsg + 'the criteria ''' + @criteria_desc + '''!'
      print @errmsg
      goto nextoid
   end

   select @entity_id = oid
   from dbo.icts_entity_name
   where entity_name = @entity_name

   if @entity_id is null
   begin
      select @errmsg = 'Failed to find an icts_entity_name record for the entity ''' + @entity_name + '''!'
      print @errmsg
      goto nextoid
   end
      
   if not exists (select 1
                  from dbo.uic_rpt_criteria_entity
                  where report_criteria_id = @report_criteria_id and
                        entity_id	= @entity_id and
                        entity_criteria_selector = @entity_criteria_selector)
   begin
      select @newoid = null
      select @newoid = isnull(max(oid), 0) + 1
      from dbo.uic_rpt_criteria_entity
      
      if @newoid is null
      begin
         print 'Failed to obtain a new oid for a new uic_rpt_criteria_entity entry!'
         goto endofscript
      end
      
      insert into dbo.uic_rpt_criteria_entity
          values(@newoid, @report_criteria_id, @entity_id, @entity_criteria_selector, 1)
      select @errcode = @@error
      if @errcode > 0
      begin
         select @errmsg = 'ERROR (uic_rpt_criteria_entity): new oid = ' + convert(varchar, @newoid) + ', ' 
         select @errmsg = @errmsg + 'report_criteria_id = ' + convert(varchar, @report_criteria_id) + ', '
         select @errmsg = @errmsg + 'entity_id = ' + convert(varchar, @entity_id) + ', '
         select @errmsg = @errmsg + 'entity_criteria_selector = ''' + @entity_criteria_selector + ''')'
         print @errmsg
         goto endofscript
      end
   end

nextoid:
   select @oid = min(oid)
   from #rpt_criteria_entity
   where oid > @oid
end
endofscript:
drop table #rpt_criteria_entity
go

exec refresh_a_last_num 'uic_rpt_criteria_entity', 'oid'
go
