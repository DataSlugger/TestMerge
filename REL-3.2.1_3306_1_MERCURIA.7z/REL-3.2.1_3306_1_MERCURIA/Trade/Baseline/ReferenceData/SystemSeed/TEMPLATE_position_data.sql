set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading a dummy position into position table ...'
go

IF NOT EXISTS (select * from dbo.position
               where pos_num = 0 and 
                     real_port_num = 0 and 
                     pos_type = 'I')
begin
   if object_id('dbo.position_instrg') is not null
      exec('alter table dbo.position disable trigger position_instrg')

   INSERT INTO dbo.position
        (pos_num, real_port_num, pos_type, is_equiv_ind,
         what_if_ind, is_hedge_ind, long_qty, short_qty, trans_id) 
      values(0,0,'I','N','N','N',0,0,1)

   if object_id('dbo.position_instrg') is not null
      exec('alter table dbo.position enable trigger position_instrg')
end
go
