set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the commodity_group table ...'
go

if not exists (select 1 
               from dbo.commodity_group 
               where parent_cmdty_code = 'GOODS' and 
                     cmdty_code = 'BRENT')
   insert into dbo.commodity_group(parent_cmdty_code,cmdty_code,cmdty_group_type_code,trans_id)
   select  'GOODS', 'BRENT', 'EIPP', 1
go