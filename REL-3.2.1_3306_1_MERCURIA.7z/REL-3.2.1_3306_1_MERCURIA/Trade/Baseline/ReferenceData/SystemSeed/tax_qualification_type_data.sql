set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the tax_qualification_type table ...'
go

if not exists (select 1
               from tax_qualification_type
               where code = 'EU')
   insert into tax_qualification_type (code, long_description, trans_id)
      values('EU', 'Countries Qualified for EU', 1)
go
