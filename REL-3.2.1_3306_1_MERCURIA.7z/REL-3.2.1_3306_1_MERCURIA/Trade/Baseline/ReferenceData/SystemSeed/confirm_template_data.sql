set nocount on

set QUOTED_IDENTIFIER ON
go
   
print 'Loading seed reference data into the confirm_template table ...'
go

CREATE TABLE #confirm_template_1349076
(
   oid	          int not null identity(1,1) primary key,
   template_name	varchar(40)	         
)
go

INSERT INTO #confirm_template_1349076 (template_name)
select  'PhysicalConfirmBioDiesel'
union
select  'PhysicalConfirmBioDieselWithRin'
union
select  'PhysicalConfirmRin'
union
select  'PhysicalConfirmLong'
union
select  'BiofuelsInvoice'
union
select  'OptionConfirmLong'
union
select  'OptionConfirmShort'
union
select  'OptionPremiumInvoice'
union
select  'OTCFinancialTradeInvoice'
union
select  'PhysicalConfirm'
union
select  'PhysicalNonPipeInvoice'
union
select  'PhysicalPipeInvoice'
union
select  'SecondaryCostInvoice'
union
select  'SwapConfirmationLong'
union
select  'SwapConfirmationShort'
go



Declare @oid                  int,
	      @template_name        varchar(40),
	      @newoid               int,
        @errcode              int
        
set @errcode = 0

select @oid = min(oid)
from #confirm_template_1349076

while @oid is not null
begin
   select @template_name = template_name
   from #confirm_template_1349076
   where oid = @oid
   
   if not exists (select 1
                  from dbo.confirm_template
                  where template_name = @template_name)
   begin
      select @newoid = isnull(max(oid), 0) + 1
      from dbo.confirm_template
   
      begin try
        insert into dbo.confirm_template 
             (oid, template_name, trans_id)
           values(@newoid, @template_name, 1)
      end try
      begin catch
        print '=> Failed to add a new template_name due to the error:'
        print '==> ERROR: ' + ERROR_MESSAGE()
        set @errcode = ERROR_NUMBER()
        goto endofscript
      end catch
      print '=> The template ''' + @template_name + ''' was added successfully!'
   end 
    
   select @oid = min(oid)
   from #confirm_template_1349076 
   where oid > @oid   
end   
   
endofscript:
drop table #confirm_template_1349076
go

exec dbo.refresh_a_last_num 'confirm_template', 'oid'
go
