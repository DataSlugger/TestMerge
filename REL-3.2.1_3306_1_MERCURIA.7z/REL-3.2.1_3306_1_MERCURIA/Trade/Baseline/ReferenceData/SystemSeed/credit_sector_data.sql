set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the credit_sector table ...'
go

if not exists (select 1
               from dbo.credit_sector
               where sector_code = 'OP')
   insert into dbo.credit_sector (sector_code, sector_desc, trans_id)
       values('OP', 'Oil & Products', 1)
go

if not exists (select 1
               from dbo.credit_sector
               where sector_code = 'GP')
   insert into dbo.credit_sector (sector_code, sector_desc, trans_id)
       values('GP', 'Gas & Power', 1)
go

if not exists (select 1
               from dbo.credit_sector
               where sector_code = 'VB')
   insert into dbo.credit_sector (sector_code, sector_desc, trans_id)
       values('VB', 'Vegoil & Biofuel', 1)
go

if not exists (select 1
               from dbo.credit_sector
               where sector_code = 'CL')
   insert into dbo.credit_sector (sector_code, sector_desc, trans_id)
       values('CL', 'Coal', 1)
go

if not exists (select 1
               from dbo.credit_sector
               where sector_code = 'CB')
   insert into dbo.credit_sector (sector_code, sector_desc, trans_id)
       values('CB', 'Carbon', 1)
go

