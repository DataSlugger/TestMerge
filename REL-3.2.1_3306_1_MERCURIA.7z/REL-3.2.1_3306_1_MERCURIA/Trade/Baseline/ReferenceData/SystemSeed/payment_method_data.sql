set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table payment_method
go

print 'Loading seed reference data into the payment_method table ...'
go

insert into payment_method 
  (pay_method_code, pay_method_desc, accounting_pay_method, trans_id) 
values('CASH', 'CASH', 'CSH', 1)
go

insert into payment_method 
  (pay_method_code, pay_method_desc, accounting_pay_method, trans_id) 
values('CHK', 'CHECK', 'CHK', 1)
go

insert into payment_method 
  (pay_method_code, pay_method_desc, accounting_pay_method, trans_id) 
values('DFT', 'DRAFT', 'DFT', 1)
go

insert into payment_method 
  (pay_method_code, pay_method_desc, accounting_pay_method, trans_id) 
values('N/A', 'NON-APPLICABLE', 'N/A', 1)
go

insert into payment_method 
  (pay_method_code, pay_method_desc, accounting_pay_method, trans_id) 
values('WIR', 'WIRE TRANSFER', 'WIR', 1)
go

insert into payment_method 
  (pay_method_code, pay_method_desc, accounting_pay_method, trans_id) 
values('TBD', 'TOBEDETERMINED', 'TBD', 1)
go

