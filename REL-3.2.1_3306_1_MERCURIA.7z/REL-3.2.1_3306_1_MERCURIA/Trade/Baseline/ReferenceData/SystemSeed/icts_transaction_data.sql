set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading a default record into the icts_transaction table ...'
go

if NOT EXISTS (select *
               from dbo.icts_transaction
               where trans_id = 1)
   insert into dbo.icts_transaction (
     trans_id, 
     type,
     user_init,
     tran_date,
     app_name, 
     app_revision, 
     spid, 
     workstation_id )
   values(1, 'S', 'SAA', getdate(), 'System', NULL, 40, NULL)
go

