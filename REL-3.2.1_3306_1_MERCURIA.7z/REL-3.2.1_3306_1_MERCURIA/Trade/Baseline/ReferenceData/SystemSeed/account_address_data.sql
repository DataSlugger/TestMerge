set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table account_address
go

print 'Loading seed reference data into the account_address table ...'
go

insert into dbo.account_address values(1, 1, 'ONE LANDMARK SQUARE', '18TH FLOOR', 
NULL, NULL, 'STAMFORD', 'CT', 'USA', '06901', NULL, NULL, NULL, NULL, NULL, 'A', 
NULL, NULL, 1)
go
