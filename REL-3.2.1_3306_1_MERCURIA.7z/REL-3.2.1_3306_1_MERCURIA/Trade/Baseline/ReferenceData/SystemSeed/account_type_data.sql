set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading seed reference data into the account_type table ...'
go

insert into dbo.account_type values('ACCTING', 'ACCOUNTING', 9999, 1)
go

insert into dbo.account_type values('BANKGTR', 'BANK GUARANTOR', 12, 1)
go

insert into dbo.account_type values('BROKER', 'BROKER', 15, 1)
go

insert into dbo.account_type values('COMMEXCH', 'COMMODITY EXCHANGE', 4, 1)
go

insert into dbo.account_type values('CPYAGENT', 'COMPANY''S AGENT', 17, 1)
go

insert into dbo.account_type values('CUSTEXP', 'CUST EXPOSURE SELECTION', 69, 1)
go

insert into dbo.account_type values('CUSTOMER', 'COUNTERPARTY', 1, 1)
go

insert into dbo.account_type values('DINTERCO', 'DOMESTIC INTERCOMPANY', 31, 1)
go

insert into dbo.account_type values('EXCHBRKR', 'EXCHANGE BROKER', 5, 1)
go

insert into dbo.account_type values('FINTERCO', 'FOREIGN INTERCOMPANY', 32, 1)
go

insert into dbo.account_type values('FLRBRKR', 'FLOOR BROKER', 6, 1)
go

insert into dbo.account_type values('LOCALVDR', 'LOCAL VENDOR', 18, 1)
go

insert into dbo.account_type values('MINTERCO', 'METALS INTERCOMPANY', 27, 1)
go

insert into dbo.account_type values('NOTRADE', 'NO TRADE CUSTOMER', 70, 1)
go

insert into dbo.account_type values('PEBANK', 'BANK', 11, 1)
go

insert into dbo.account_type values('PEICOMP', 'BOOKING COMPANY', 7, 1)
go

insert into dbo.account_type values('PORTAGT', 'PORT AGENT', 23, 1)
go

insert into dbo.account_type values('PROVTRDE', 'PROVISIONAL TRADE', 71, 1)
go

insert into dbo.account_type values('SHIPOWNE', 'SHIPOWNER', 62, 1)
go

insert into dbo.account_type values('SRVENDOR', 'SERVICE VENDOR', 20, 1)
go

insert into dbo.account_type values('TAXAUTH', 'TAX AUTHORITY', 0, 1)
go

insert into dbo.account_type values('TAXSRV', '1099 SERVICES', 1099, 1)
go

insert into dbo.account_type values('WAREHSRE', 'WAREHOUSER', 3, 1)
go

insert into dbo.account_type values('TRDNGNTT', 'TRADING ENTITY', 40, 1)
go

insert into dbo.account_type values('CRDTAGNC', 'Credit Agency', 41, 1)
go

insert into dbo.account_type values('FISCALRE', 'FISCAL REPRESENTATIVE', 100, 1)
go

insert into dbo.account_type values('LEGAL', 'LEGAL ENTITY', 101, 1)
go

-- Added for FuelQuest
insert into dbo.account_type values ('CUSAGENT', 'CUSTOM AGENT', 0, 1)
go

if not exists (select 1
               from dbo.account_type
               where acct_type_code = 'CLRSRVC')
   insert into dbo.account_type
       (acct_type_code, acct_type_desc, acct_type_num, trans_id)
     values('CLRSRVC', 'Clearing Service', 0, 1)
go

if not exists (select 1
               from dbo.account_type
               where acct_type_code = 'FCLYOWNR')
   insert into dbo.account_type 
       (acct_type_code, acct_type_desc, acct_type_num, trans_id)
     values('FCLYOWNR', 'Facility Owner', 1000, 1)
go

if not exists (select 1
               from dbo.account_type
               where acct_type_code = 'BKOUTBRK')
   insert into dbo.account_type
       (acct_type_code, acct_type_desc, acct_type_num, trans_id)
     values('BKOUTBRK', 'Bookout Services Company', 0, 1)
go

if not exists (select 1
               from dbo.account_type
               where acct_type_code = 'LEASEOP')
   insert into dbo.account_type
       (acct_type_code, acct_type_desc, acct_type_num, trans_id)
     values('LEASEOP', 'Lease Operator', 0, 1)
go

if not exists (select 1
               from dbo.account_type
               where acct_type_code = 'LEASEOWN')
   insert into dbo.account_type
       (acct_type_code, acct_type_desc, acct_type_num, trans_id)
     values('LEASEOWN', 'Lease Owner', 0, 1)
go

if not exists (select 1
               from dbo.account_type
               where acct_type_code = 'TRIPARTI')
   insert into dbo.account_type
       (acct_type_code, acct_type_desc, acct_type_num, trans_id)
     values('TRIPARTI', 'Tripartite Assignment Bank', 0, 1)
go


