set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Adding an user_default record for the ''ExcelPositionReport'' domain ...'
go

declare @domain_id     int,
        @oid           int,
        @errcode       int,
        @rows_affected int

select @errcode = 0

select @domain_id = oid
from dbo.defaults_domain
where name = 'ExcelPositionReport'

if @domain_id is null
begin
   print 'Missing ''ExcelPositionReport'' entry in the defaults_domain table!'
   goto endofscript
end
 
select @oid = isnull(max(oid), 0) + 1
from dbo.user_default

if not exists (select 1
               from dbo.user_default
               where defaults_key = 'ShouldPositionPLOnTop' and
                     domain_id = @domain_id) 
begin         
   begin tran
   insert into dbo.user_default
      (oid, defaults_key, domain_id, may_not_override, user_init, defaults_value, trans_id)
      values(@oid, 'ShouldPositionPLOnTop', @domain_id, 0, null, 'N', 1)
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0 or @rows_affected = 0
   begin
      rollback tran
      goto endofscript
   end
   commit tran
end
endofscript:
go

exec dbo.refresh_a_last_num 'user_default', 'oid'
go
