set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table cost_code
go

print 'Loading seed reference data into the cost_code table ...'
go

if not exists (select 1
               from dbo.cost_code
               where cost_code = 'BROKBLOC')
  insert into dbo.cost_code
      (cost_code, cost_code_desc, cost_code_type_ind, cost_code_order_num, pl_implication, trans_id)
     values('BROKBLOC', 'BROKERAGE-BLOCK', 'M', NULL, 'OPEN', 1)
go

if not exists (select 1
               from dbo.cost_code
               where cost_code = 'BROKERAG')
   insert into dbo.cost_code 
      (cost_code, cost_code_desc, cost_code_type_ind, cost_code_order_num, trans_id)
     values ('BROKERAG','Brokerage Cost', 'N', NULL, 1)
go

insert into dbo.cost_code 
   (cost_code, cost_code_desc, cost_code_type_ind, 
    cost_code_order_num, trans_id)
select cmdty_code, cmdty_full_name, 'M', NULL, 1
from dbo.commodity
where cmdty_type = 'O' and
      cmdty_code not in (select cost_code
                         from dbo.cost_code)
go

