print 'Loading additional seed data into the commodity_location table ...'
go

insert into commodity_location values("ANS", "CANADA", NULL, "ANS", "ANS", 1)
go

insert into commodity_location values("BELIDA", "INDONESI", NULL, "BELIDA", 
"BELIDA", 1)
go

insert into commodity_location values("BONNYL", "BONNY", NULL, "BONNYL", 
"BONNYL", 1)
go

insert into commodity_location values("BONNYM", "BONNY", NULL, "BONNYM", 
"BONNYM", 1)
go

insert into commodity_location values("BRASS", "BRASS", NULL, "BRASS", "BRASS", 
1)
go

insert into commodity_location values("BRENT", "NEW13", NULL, "BRENT", "BRENT", 
1)
go

insert into commodity_location values("BRENT", "SULLOM", 40.000000, "BRENT", 
"BRENT", 1)
go

insert into commodity_location values("CAPTAIN", "DONGES", 1.000000, "CAPTAIN", 
"CAPTAIN", 1)
go

insert into commodity_location values("DUBAI", "Fateh", NULL, "DUBAI", "DUBAI", 
1)
go

insert into commodity_location values("DUC", "FREDERIC", 1.000000, "DUC", "DUC", 
1)
go

insert into commodity_location values("DURI", "DUMAI", 1.000000, "DURI", "DURI", 
1)
go

insert into commodity_location values("EN228", "WATERSTN", NULL, "EN228", 
"EN228", 1)
go

insert into commodity_location values("EOCENE", "MINASAUD", NULL, "EOCENE", 
"EOCENE", 1)
go

insert into commodity_location values("ESCRAVOS", "ESCRAVOS", NULL, "ESCRAVOS", 
"ESCRAVOS", 1)
go

insert into commodity_location values("FLOTTA", "FLOTTA", 1.000000, "FLOTTA", 
"FLOTTA", 1)
go

insert into commodity_location values("FORCADOS", "FORCADOS", NULL, "FORCADOS", 
"FORCADOS", 1)
go

insert into commodity_location values("FORTIES", "HOUNDS", NULL, "FORTIES", 
"FORTIES", 1)
go

insert into commodity_location values("GASOIL", "WATERSTN", NULL, "GASOIL", 
"GASOIL", 1)
go

insert into commodity_location values("GOIL590", "WATERSTN", NULL, "GOIL590", 
"GOIL590", 1)
go

insert into commodity_location values("JET", "Everglad", NULL, "JET", "JET", 1)
go

insert into commodity_location values("JET", "WATERSTN", NULL, "JET", "JET", 1)
go

insert into commodity_location values("KERO", "WATERSTN", NULL, "KERO", "KERO", 
1)
go

insert into commodity_location values("MASILA", "YEMEN", NULL, "MASILA", 
"MASILA", 1)
go

insert into commodity_location values("MINAS", "DUMAI", 1.000000, "MINAS", 
"MINAS", 1)
go

insert into commodity_location values("ORIENTE", "ARGENTIN", 26.000000, 
"ORIENTE", "ORIENTE", 1)
go

insert into commodity_location values("ORIENTE", "BRAZIL", 26.000000, "ORIENTE", 
"ORIENTE", 1)
go

insert into commodity_location values("ORIENTE", "CHILIE", 26.000000, "ORIENTE", 
"ORIENTE", 1)
go

insert into commodity_location values("ORIENTE", "Peru", 26.000000, "ORIENTE", 
"ORIENTE", 1)
go

insert into commodity_location values("QUAIBOE", "QUA", NULL, "QUAIBOE", 
"QUAIBOE", 1)
go

insert into commodity_location values("RATAWI", "GARYVILL", 1.000000, "RATAWI", 
"RATAWI", 1)
go

insert into commodity_location values("RATAWI", "MINASAUD", 1.000000, "RATAWI", 
"RATAWI", 1)
go

insert into commodity_location values("SOYO", "ANGOLA", NULL, "SOYO", "SOYO", 1)
go

insert into commodity_location values("UNL87", "COLLINS", NULL, "UNL87", 
"UNL87", 1)
go

insert into commodity_location values("UNL87", "MNDVILLE", NULL, "UNL87", 
"UNL87", 1)
go

insert into commodity_location values("WTI", "NEW13", NULL, "WTI", "WTI", 1)
go

