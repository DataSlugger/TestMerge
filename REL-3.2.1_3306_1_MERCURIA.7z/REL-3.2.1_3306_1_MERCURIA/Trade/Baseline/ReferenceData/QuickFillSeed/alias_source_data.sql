if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'RISC-FUT')
   insert into dbo.alias_source ( 
       alias_source_code, 
       alias_source_type, 
       alias_source_desc, 
       trans_id) 
     values ('RISC-FUT', 
             'X', 
             'RISC Futures Print Format', 
             1) 
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'RISC-OPT')
   insert into dbo.alias_source ( 
       alias_source_code, 
       alias_source_type, 
       alias_source_desc, 
       trans_id) 
     values ('RISC-OPT', 
             'X', 
             'RISC Options Print Format', 
             1) 
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'RISC-STR')
   insert into dbo.alias_source ( 
       alias_source_code, 
       alias_source_type, 
       alias_source_desc, 
       trans_id) 
     values ('RISC-STR', 
             'X', 
             'RISC Strike Conversion Factor', 
             1) 
go

if not exists (select 1
               from dbo.alias_source
               where alias_source_code = 'QF_TPS')
   insert into dbo.alias_source ( 
       alias_source_code, 
       alias_source_type, 
       alias_source_desc, 
       trans_id) 
     values ('QF_TPS', 
             'X', 
             'Quickfill to TPS commkt mapping', 
             1) 
go
