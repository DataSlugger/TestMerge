INSERT new_num ( 
  num_col_name, 
  loc_num, 
  last_num, 
  owner_table, 
  owner_column, 
  trans_id 
) VALUES ( 
  "qf_num", 
  0, 
  80000000, 
  "trade", 
  "trade_num", 
  1 
) 
go

INSERT application ( 
  app_name, 
  trans_id 
) VALUES ( 
  "QuickFill", 
  1 
) 
go

INSERT application ( 
  app_name, 
  trans_id 
) VALUES ( 
  "Inhouse", 
  1 
) 
go

INSERT INTO icts_function ( 
  function_num, 
  app_name, 
  function_name, 
  trans_id 
) VALUES ( 
  50, 
  "QuickFill", 
  "VIEW", 
  1 
) 
go

INSERT INTO icts_function ( 
  function_num, 
  app_name, 
  function_name, 
  trans_id 
) VALUES ( 
  51, 
  "QuickFill", 
  "EDIT", 
  1 
) 
go

INSERT INTO icts_function ( 
  function_num, 
  app_name, 
  function_name, 
  trans_id 
) VALUES ( 
  52, 
  "QuickFill", 
  "MAINTAIN_TRADER_PORTS", 
  1 
) 
go

INSERT INTO icts_function ( 
  function_num, 
  app_name, 
  function_name, 
  trans_id 
) VALUES ( 
  53, 
  "Inhouse", 
  "EDIT", 
  1 
) 
go

INSERT INTO icts_function ( 
  function_num, 
  app_name, 
  function_name, 
  trans_id 
) VALUES ( 
  54, 
  "Inhouse", 
  "VIEW", 
  1 
) 
go

