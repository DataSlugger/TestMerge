exec set_last_nums 0
go
exec set_sequence_table
go

