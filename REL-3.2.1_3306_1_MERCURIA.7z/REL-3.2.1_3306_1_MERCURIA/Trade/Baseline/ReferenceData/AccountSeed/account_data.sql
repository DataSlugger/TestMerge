print 'Loading additional seed data into the account table ...'
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2, 
"BAYOIL SUP", "BAY OIL SUPPLY & TRADING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(3, 
"IPLOM SPA", "IPLOM SPA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(4, 
"DOW EUROPE", "DOW EUROPE SA", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(5, 
"SUMITOMO", "SUMITOMO CORPORATION (SINGAPORE) PTE", "A", "CUSTOMER", "N", "Y", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(6, 
"PETRONED", "PETRONED BELGIUM N.V.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(7, 
"COSMO OIL", "COSMO OIL CO. LTD", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(8, 
"J ARON LN", "J. ARON & COMPANY (UK)", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(9, 
"MARUBENI", "MARUBENI INTERNATIONAL PETROLEUM (S) PTE LTD", "A", "CUSTOMER", 
"N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(10, 
"AMEREX", "AMEREX FUTURES NJ INC.", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(11, 
"AGIP SPA", "AGIP PETROLI S.P.A.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(12, "AIG", 
"AIG TRADING CORPORATION", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(13, 
"AM HESS", "AMERADA HESS CORPORATION", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(14, 
"HESS TRLTD", "AMERADA HESS TRADING LIMITED", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(15, 
"AMERAIR", "AMERICAN AIRLINES INC.", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(16, 
"AOT TRADIG", "AOT TRADING AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(17, 
"ARCADIA", "ARCADIA PETROLEUM LTD.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(18, 
"J ARON NY", "J. ARON & COMPANY", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(19, 
"ATTOCK OIL", "ATTOCK OIL INTERNATIONAL LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(20, 
"NATIONSBK", "NATIONSBANK OF NORTH CAROLINA , N.A.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(21, 
"CH PET TAI", "CHINESE PETROLEUM CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(22, "CITGO", 
"CITGO PETROLEUM CORP. TULSA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(23, 
"GLENCORE L", "GLENCORE LTD", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(24, 
"CLARKREF", "THE PREMCOR REFINING GROUP INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(25, 
"CLARKOIL", "CLARK OIL TRADING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(26, 
"COASTAL", "COASTAL (BERMUDA) PETROLEUM LIMITED", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(27, 
"COASTAL HN", "COASTAL STATES TRADING, INC. TX", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(28, 
"COASTAL AR", "COASTAL PETROLEUM N.V. - ARUBA", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(29, 
"COASTAL RE", "COASTAL ARUBA REFINING NV", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(30, 
"COASTAL F", "COASTAL FUELS MARKETING, INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(31, 
"COASTAL G", "COASTAL GAS MARKETING COMPANY", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(32, 
"CONOCO I", "CONOCO INTERNATIONAL INC. SINGAPORE BRANCH", "A", "CUSTOMER", "N", 
"Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(33, 
"CONOCO NOR", "CONOCO NORWAY INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(34, 
"CONOCO LN", "CONOCO LIMITED LONDON", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(35, 
"CONOCO HTN", "CONOCO INCORPORATED", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(36, 
"CREDITLYONNNY", "CREDIT LYONNAIS NEW YORK", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(37, 
"CRED DERIV", "CREDIT LYONNAIS ROUSE DERIVATIVES", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(38, "CROWN", 
"CROWN CENTRAL PETROLEUM CORP", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(39, 
"DSHELL", "DEUTSCHESHELL AKTIENGESELLSCHAFT", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(40, 
"DILLONENER", "DILLON ENERGY INC", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(41, 
"LOUIS DREY", "LOUIS DREYFUS ENERGY LTD", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(42, 
"EL PASO CD", "EL PASO ENERGY MARKETING CANADA INC", "A", "CUSTOMER", "N", "Y", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(43, 
"ELF HSTN", "ELF TRADING INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(44, 
"ELF GEN", "ELF TRADING S.A. ,GENEVA", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(45, 
"ENTERPR", "ENTERPRISE OIL PLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(46, 
"ESSO E&P", "ESSO EXPLORATION AND PRODUCTION UK LTD.", "A", "CUSTOMER", "N", 
"Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(47, 
"ESSONETHR", "ESSO NEDERLAND B.V.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(48, 
"ESSO LTD", "ESSO PETROLEUM COMPANY LIMITED", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(49, 
"ESSO SOC", "ESSO SOCIETE ANONYME FRANCAISE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(50, "EXXON", 
"EXXON COMPANY, U.S.A.", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(51, 
"EXXON PRD", "EXXON SUPPLY COMPANY", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(52, 
"FARMLAND", "FARMLAND INDUSTRIES, INC", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(53, 
"FERRELL", "FERRELL NORTH AMERICA, A DIVISION OF FERRELL GAS LP", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(54, "FINA", 
"FINA OIL AND CHEMICAL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(55, 
"FINA NATGS", "FINA NATURAL GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(56, 
"GALAXY LTD", "GALAXY ENERGY INTERNATIONAL LIMITED", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(57, 
"ICI PLC", "ICI CHEMICALS & POLYMERS LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(58, 
"IRISH NPC", "IRISH NATIONAL PETROLEUM CORP., LTD.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(59, 
"ITOCHU SIN", "ITOCHU PETROLEUM CO (SINGAPORE) PTE LTD", "A", "CUSTOMER", "N", 
"Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(60, 
"ITOCHU", "ITOCHU INTERNATIONAL INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(61, 
"ITOCHU PET", "ITOCHU CORPORATION (PCO ITOCHU PETROLEUM CO (HONG KONG) LTD)", 
"A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(62, 
"KOCH SP", "KOCH SUPPLY AND TRADING COMPANY", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(63, "KOCH", 
"KOCH OIL COMPANY", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(64, 
"KUO OIL", "KUO OIL (S) PTE LTD", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(65, "MAPCO", 
"MAPCO PETROLEUM INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(66, 
"MARATHON", "MARATHON OIL COMPANY", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(67, 
"INSPECTOR", "INSPECTORATE AMERICA CORP.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(68, 
"MARU NY", "MARUBENI PETROLEUM CO. LIMITED", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(69, 
"MASEFIELD", "MASEFIELD AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(70, 
"MERRILL", "MERRILL LYNCH  CAPITAL SERVICES, INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(71, 
"MIECO HSTN", "MIECO, INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(72, 
"MITSUI HTN", "MITSUI & CO (U.S.A.) INC.", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(73, 
"MOBIL NRTH", "MOBIL NORTH SEA LIMITED", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(74, "MOBIL", 
"MOBIL OIL CORPORATION", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(75, 
"MOBIL TR", "MOBIL TRADING AND SUPPLY LIMITED", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(76, 
"MORGAN G", "MORGAN GUARANTY TRUST COMPANY OF NEWYORK", "A", "CUSTOMER", "N", 
"Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(77, 
"JPMORGAN", "J.P. MORGAN & CO. INCORPORATED", "A", "EXCHBRKR", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(78, 
"MORGAN", "MORGAN STANLEY CAPITAL GROUP INC", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(79, 
"MORG ST SG", "MORGAN STANLEY CAPITAL GROUP (SINGAPORE)", "A", "CUSTOMER", "N", 
"Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(80, 
"NAT COREF", "NATIONAL COOPERATIVE REFINING ASSOC.", "A", "CUSTOMER", "N", "Y", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(81, 
"NESTE ESP", "NESTE OY", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(82, "NORSK", 
"NORSK HYDRO A.S.", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(83, 
"NISSHO", "NISSHO IWAI CORPORATION", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(84, 
"NISSHO SN", "NISSHO IWAI PETROLEUM CO (SINGAPORE)", "A", "CUSTOMER", "N", "Y", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(85, 
"N'RIDGE P", "NORTHRIDGE PETROLEUM MKTING, A DIV OF TRANSCANADA ENERGY LTD", 
"A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(86, 
"N'VILLE", "NORTHVILLE INDUSTRIES CORP", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(87, "NOVA", 
"NOVA PETROLEUM INTERNATIONAL ESTABLISHME", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(88, 
"PREEM PETR", "PREEM PETROLEUM AB", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(89, 
"PACIFIC GE", "PACIFIC GAS AND ELECTRIC COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(90, 
"P'FINA BR", "PETROFINA S.A", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(91, 
"PETROTR IN", "PETROTRADE INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(92, 
"PHILLIPS", "PHILLIPS PETROLEUM COMPANY", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(93, 
"PHILLIPSUK", "PHILLIPS PETROLEUM COMPANY UK LTD", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(94, "RHEIN", 
"RHEINOEL LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(95, 
"GLENCORE I", "GLENCORE INTERNATIONAL AG", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(96, "SAGAN", 
"SAGA PETROLEUM A/S", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(97, 
"SHEARSON", "LEHMAN BROTHERS COMMERCIAL CORP.", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(98, "SUKO", 
"SHELL UK LTD", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(99, 
"SHELL HSTN", "SHELL OIL COMPANY", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(100, 
"SOCAP INTL", "SOCAP INTERNATIONAL LTD", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(101, 
"SOC GEN", "SOCIETE GENERALE, PARIS", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(102, 
"STATOIL NO", "DEN NORSKE STATS OLJESELSKAP A.S", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(103, 
"STINNES NJ", "STINNES INTEROIL, INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(104, 
"SUN REF", "SUNOCO INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(105, 
"SUN OIL", "SUN OIL TRADING COMPANY", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(106, 
"SUN REFMKT", "SUN REFINING & MARKETING CO.,", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(107, 
"TCT ENGY", "TCT ENERGY INC.", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(108, 
"TEXACO LN", "TEXACO LIMITED", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(109, 
"TEXACO", "TEXACO INC.", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(110, 
"TEX INTL T", "TEXACO INTERNATIONAL TRADER INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(111, 
"TEXACO GAS", "TEXACO NATURAL GAS INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(112, 
"TEX R&M NY", "TEXACO REFINING AND MARKETING INC.", "A", "CUSTOMER", "N", "Y", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(113, 
"TEX TTI", "TEXACO TRADING AND TRANSPORTATION INC.", "A", "CUSTOMER", "N", "Y", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(114, 
"TEX E&P HN", "TEXACO EXPLORATION AND PRODUCTION INC.", "A", "CUSTOMER", "N", 
"Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(115, 
"TOSCO REF", "TOSCO REFINING COMPANY,  A DIVISION OF T", "A", "CUSTOMER", "N", 
"Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(116, 
"TOTAL LTD", "TOTAL INTERNATIONAL LTD", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(117, 
"TOTAL OIL", "TOTAL OIL GREAT BRITAIN LTD.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(118, 
"TOTAL", "TOTAL PETROLEUM, INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(119, 
"TOMEN SN", "TOMEN PETROLEUM (SINGAPORE) PTE, LTD", "A", "CUSTOMER", "N", "Y", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(120, 
"UNOCAL INT", "UNOCAL INTERNATIONAL", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(121, 
"ENRON", "ENRON OIL TRADING AND TRANSPORTATION", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(122, 
"VITOL ASIA", "VITOL ASIA PTE LTD.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(123, 
"VITOL HSTN", "VITOL S.A. INC", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(124, 
"GE WARREN", "GEORGE E. WARREN CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(125, 
"DIAMOND", "DIAMOND SHAMROCK REFINING COMPANY, L.P.", "A", "CUSTOMER", "N", "Y", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(126, 
"INCHCAPE", "INCHCAPE SHIPPING SERVICES", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(127, 
"CITIBANK", "CITIBANK, NA", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(128, 
"TCTOPTIONS", "TCT OPTIONS INC.", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(129, "PMI", 
"PMI TRADING LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(130, 
"STATOIL AP", "STATOIL ASIA PACIFIC PTE. LTD.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(131, 
"EXXON TRAD", "EXXON TRADING COMPANY, INTL.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(132, 
"LIBRA", "LIBRA PETROLEUM", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(133, 
"HESSOIL VI", "HESS OIL VIRGIN ISLANDS CORP.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(134, 
"ELPASO MKT", "EL PASO MERCHANT ENERGY-GAS, LP", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(135, "WESC", 
"WILLIAMS ENERGY MARKETINGAND TRADING COMPANY", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(136, 
"PHIBRO", "PHIBRO INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(137, 
"GLOBAL", "GLOBAL PETROLEUM CORP.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(138, 
"ATLNTCRICH", "ATLANTIC RICHFIELD CORP", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(139, 
"MOBIL BV", "MOBIL SALES & SUPPLY CORP AAF MOBIL TRADING BV", "A", "CUSTOMER", 
"N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(140, 
"VALERO MKT", "VALERO MARKETING & SUPPLY CO.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(141, 
"VASTARRES", "VASTAR RESOURCES", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(142, 
"KOCH REF C", "KOCH REFINING COMPANY, LP", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(143, 
"JARONSING", "J. ARON & CO. SINGAPORE PTE. LTD.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(144, 
"SUNCOMPANY", "SUN COMPANY INC", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(145, 
"CONAG EGY", "CONAGRA ENERGY SERVICES, INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(146, 
"SUMMIT-BRO", "SUMMIT FUELS, INC", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(147, 
"STATOIL CT", "STATOIL  NORTH AMERICA, INC.", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(148, 
"TALISMAN", "TALISMAN ENERGY INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(149, 
"DANE ENGY", "DANE ENERGY CORPORATION", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(150, 
"SPECTRONBA", "SPECTRON ENERGY LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(151, "CARR", 
"CARR FUTURES", "A", "EXCHBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(152, 
"CRED LYONN", "CREDIT LYONNAIS", "A", "BANKGTR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(153, 
"MERFWDS", "MERRILL LYNCH FUTURES", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(154, 
"VITOL GEN", "VITOL SA GENEVA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(155, "TCPL", 
"TRANSCANADA PIPELINES LIMITED", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(156, 
"SING PETRO", "SINGAPORE PETROLEUM COMPANY LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(157, 
"GALAXY AG", "GALAXY ENERGY (USA) INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(158, 
"MAXUS", "MAXUS ENERGY CORPORATION", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(159, 
"AQUILA EGY", "AQUILA ENERGY MARKETING CORPORATION", "A", "CUSTOMER", "Y", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(160, 
"VASTAR RES", "VASTAR RESOURCES, INC.", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(161, 
"STAMP EXP", "STAMPEDER EXPLORATION LTD.", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(162, 
"STINNES AG", "STINNES INTEROIL AG", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(163, 
"NORTHRIDGEMKT", "NORTHRIDGE PETROLEUM MARKETING U.S., INC", "A", "CUSTOMER", 
"N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(164, 
"AIG LDN", "AIG TRADING LIMITED", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(165, 
"ENCOR", "ENCOR ENERGY CORPORATION INC.", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(166, 
"ENDEVCO", "ENDEVCO NATURAL GAS CO.", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(167, 
"TORCH ADV", "TORCH ENERGY ADVIORS INCORPORATED", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(168, 
"TRAFIG AG", "TRAFIGURA AG", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(169, 
"PETROTRIN", "PETROLEUM COMPANY OF TRINIDAD AND TOBAGO", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(170, 
"CONAGRA", "CONAGRA, INC.", "A", "CUSTOMER", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(171, 
"ECHOENERGY", "ECHO ENERGY", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(172, 
"BRK-ASPEN", "ASPEN OIL (BROKING) LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(173, 
"SGSWAREHOUSE", "SGS WAREHOUSE SERVICES BV", "A", "WAREHSRE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(174, 
"ROYAL BANK", "ROYAL BANK OF CANADA", "A", "BANKGTR", "Y", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(175, 
"TAURUS PET", "TAURUS PETROLEUM LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(176, 
"FIRST UNB", "FIRST UNION NAT'L BANK OF NORTH CAROLINA", "A", "BANKGTR", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(177, "ITS", 
"INTERTEK TESTING SERVICES (UK) LTD", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(178, 
"ACCORD", "ACCORD ENERGY LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(179, "CIBC", 
"CANADIAN IMPERIAL BK OF COMMERCE", "A", "CUSTOMER", "N", "Y", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(180, 
"STASCO", "SHELL INTL TRADING AND SHIPPING CO. LTD", "A", "CUSTOMER", "N", "Y", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(181, 
"SGSANTWERPEN", "SGS DEPAUW & STOKOE NV", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(182, 
"ALBA RES", "ALBA RESOURCES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(183, 
"GLENCORE S", "GLENCORE SINGAPORE PTE LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(184, "STS", 
"SCANDINAVIAN (SWEDISH) TANK STORAGE AB", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(185, 
"SINOCHM SN", "SINOCHEM INTERNATIONAL OIL (SINGAPORE)", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(186, 
"TRAFIGURA", "TRAFIGURA BEHEER B.V", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(187, 
"GULFSTREAM", "GULF STREAM TRADING LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(188, 
"SIETCO", "SHELL INTERNATIONAL EASTERN TRADING CO", "A", "CUSTOMER", "N", "Y", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(189, 
"INTERLINK", "INTERLINK PETROLEUM RESOURCES INC. (BERM", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(190, 
"COSCO FEOS", "COSCO-FEOSO (S) PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(191, 
"BRITANNIC", "BRITANNIC TRADING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(192, 
"PARIBAS", "BANQUE PARIBAS", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(193, 
"BARCLAYS P", "BARCLAYS BANK PLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(194, 
"BHP ASIA", "BHP PETROLEUM TRD & MKT PTE (ASIA) LTD.", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(195, 
"BPEXP", "BP EXPLORATION OPERATING CO. LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(196, 
"BP NA PETR", "BP N. AMERICA PETROLEUM INC. -A DIV. OF BP EXP. & OIL CO. INC", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(197, 
"BP SNGPRE", "BP SINGAPORE PTE. LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(198, 
"CARGILL AN", "CARGILL INT'L  S.A., ANTIGUA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(199, 
"CARGILL CH", "CARGILL PETROLEUM, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(200, "CHEM", 
"CHEMICAL BANK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(201, 
"CHEV INT", "CHEVRON INTERNATIONAL OIL CO. LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(202, 
"CHEV SF", "CHEVRON INTERNATIONAL TRADING COMPANY", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(203, 
"DEA MINERA", "DEA MINERALOEL A.G.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(204, 
"KG HK", "KG INTERNATIONAL PETROLEUM LTD.,  HK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(205, 
"MITSUBICORPUKLT", "MITSU UK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(206, 
"MITSU", "MITSUBISHI CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(207, 
"MURPHY USA", "MURPHY OIL U.S.A. INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(208, 
"KANG OIL", "KANGQI OIL PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(209, 
"NATURAL", "NATURAL GAS CLEARINGHOUSE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(210, 
"UTILICORP", "UTILICORP UNITED INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(211, 
"CARGILL MA", "CARGILL INC., MASSACHUSETTS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(212, 
"CHEV PROD", "CHEVRON USA PRODUCTS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(213, 
"METRO", "METRO OIL CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(214, 
"PETRO D SN", "PETRO DIAMOND SINGAPORE (PTE) LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(215, 
"PMI COMER", "PMI COMERCIO INTERNACIONAL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(216, 
"SONATRACH", "ENTERPRISE NATIONALE SONATRACH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(217, 
"BRITAIR", "BRITISH AIRWAYS PLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(218, 
"CHEMOIL", "CHEMOIL CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(219, 
"DUKE USA", "DUKE ENERGY TRADING AND MKT LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(220, "EREC", 
"EQUITABLE RESOURCES ENERGY COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(221, 
"BP OIL LN", "BP OIL INTERNATIONAL LTD. LONDON", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(222, 
"PENNZOIL INC", "PENNZOIL INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(223, 
"PETRONOR", "PETROLEOS DEL NORTE, S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(224, 
"AMEREXLONDON", "AMEREX PETROLEUM LTD LONDON", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(225, 
"EDF MAN", "E.D.F. MAN CAPITAL INC.", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(226, "PL", 
"PREBON YAMANE (UK) LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(227, 
"PREBON SN", "PREBON ENERGY (SINGAPORE) PTE LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(228, 
"STARSUPPNJ", "STARSUPPLY DERIVATIVES INC.", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(229, 
"FAMMLDN", "FUEL & MARINE MARKETING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(230, 
"EDFMAN", "E.D.&F. MAN INTL.", "A", "EXCHBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(231, 
"SK ENERGY", "SK ENERGY ASIA PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(232, 
"HESS EGYTR", "HESS ENERGY TRADING COMPANY, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(233, "GFI", 
"GFI", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(234, 
"CHASE", "CHASE MANHATTAN BANK, N.A. NY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(235, 
"MAERSK", "MAERSK OLIE AND GAS AS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(236, 
"HUNT REF", "HUNT REFINING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(237, 
"EURO GULF", "EURO GULF PETROLEUM LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(238, 
"TRANSMONT", "TRANSMONTAIGNE PRODUCT SERVICES INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(239, 
"SEMINOLE", "SEMINOLE TRADING AND MARKETING, INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(240, 
"CEPSA", "CIA ESPANOLA DE PETROLES SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(241, 
"MITSUI HK", "MITSUI OIL (ASIA) HONG KONG LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(242, 
"TRADLDN", "TRADITIONAL FINANCIAL SERVICES", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(243, 
"ENRON INTL", "ENRON CAPITAL&TRADE RESOURCES INTL CORP", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(244, 
"SARAS SPA", "SARAS S.P.A. RAFFINERIE SARDE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(245, 
"UNITED", "UNITED ENERGY INC", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(246, 
"TOSCO EURO", "TOSCO EUROPE LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(247, 
"CROWN TRAD", "CROWN TRADE AND FINANCE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(248, 
"TAUBER", "TAUBER OIL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(249, 
"STATIOILMKT", "STATOIL MARKETING & TRADING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(250, 
"TEXACO NED", "TEXACO NEDERLAND B.V.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(251, 
"PROJCTR CH", "PROJECTOR GENEVA S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(252, 
"GAS TEAM", "GASTEAM USA, INC.", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(253, 
"NTERMOILLTD", "N-TERMINAL OIL LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(254, 
"BP OIL CL", "BP OIL SUPPLY COMPANY, OHIO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(255, 
"ENRON LTD", "ENRON CAPITAL AND TRADE RESOURCES LTD.", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(256, 
"EQUIVA", "EQUIVA TRADING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(257, 
"PETRONAS", "PETRONAS TRADING CORPORATION SDN BHD", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(258, "SPEC", 
"SPECTRON", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(259, 
"REFCO", "REFCO", "A", "EXCHBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(260, "SCS", 
"SCS COMMODITIES CORP.", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(261, 
"PARAMOUNT BRK", "PARAMOUNT OPTIONS INC", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(262, 
"GNI LTD", "GERRARD & NATIONAL INTER COMMODITIES", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(263, 
"ALBION", "ALBION OIL LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(264, 
"EAGLE", "EAGLE FUTURES INC", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(265, 
"SGS INSP. UK", "SGS REDWOOD INSPECTION, UK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(266, 
"INSPECTORATE,UK", "INSPECTORATE OIL AND PETROCHEMICAL DIV", "A", "SRVENDOR", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(267, 
"REPSOL PET", "REPSOL PETROLEO S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(268, 
"DYNEGY MKT", "DYNEGY MARKETING AND TRADE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(269, "NOIS", 
"NATIONAL OIL INSPECTION SERVICES B,V,", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(270, 
"SAYBOLT", "SAYBOLT INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(271, 
"ROUSE", "ROUSE", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(272, 
"BRUGGERMAN", "A. E. BRUGGEMANN AND COMPANY, INC.", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(273, 
"ARCO CRUDE", "ARCO CRUDE OIL AND NGL MARKETING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(274, 
"LAGLORIA", "LA GLORIA OIL AND GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(275, 
"GLENCOR AG", "GLENCORE AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(276, 
"SGS CONTROL SRV", "SGS CONTROL SERVICES INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(277, 
"PETROPLUS", "PETROPLUS POWER BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(278, 
"CHINA NAT", "CHINA NATIONAL CHEMICALS IMPORT & EXPORT CORP", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(279, 
"LUKOIL", "LUKOIL PETROLEUM LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(280, 
"STARSUP LT", "STARSUPPLY PETROLEUM DERIVATIVESLTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(281, 
"ALT ENERGY", "CREDIT AGRICOLE INDOSUEZ", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(282, "VEBA", 
"VEBA OIL SUPPLY & TRADING INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(283, 
"PREBON", "PREBON-USA", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(284, 
"BANGOR HYD", "BANGOR HYDROELECTRIC COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(285, 
"ORYX E", "KERR-MCGEE CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(286, 
"BANKERS", "BANKERS TRUST COMPANY NEW YORK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(287, 
"DOM E&P", "DOMINION EXPLORATION & PRODUCTION, INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(288, 
"GULFMARK", "GULFMARK ENERGY, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(289, 
"PLAINS MKT", "PLAINS MARKETING & TRANSPORTATION INC.", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(290, 
"CHESAPEAKE", "CHESAPEAKE ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(291, 
"ZOLLER", "ZOLLER ENERGY", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(292, 
"MRICH", "MARC RICH & CO LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(293, 
"CINRGY CAP", "CINERGY CAPITAL & TRADE INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(294, 
"SOC GEN EN", "SOCIETE GENERALE ENERGIE (USA)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(295, 
"SPRAGUE EN", "SPRAGUE ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(296, 
"ALLRND FT", "ALLROUND FUEL TRADING B.V.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(297, 
"STARDUST", "STARDUST OIL SERVICES BV", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(298, "UBSN", 
"UNION BANK OF SWITZERLAND", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(299, 
"BERKLEY PE", "BERKLEY PETROLEUM CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(300, 
"BI-PETRO", "BI-PETRO INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(301, 
"NOVARCO AG", "NOVARCO AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(302, 
"TEPPCO", "TEPPCO CRUDE OIL, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(303, 
"NOVARCOLTD", "NOVARCO LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(304, 
"MERRION OIL", "MERRION OIL & GAS CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(305, 
"MOBIL S LN", "MOBIL SALES & SUPPLY CORP., LDN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(306, 
"MOBIL S SN", "MOBIL SALES & SUPPLY CORP., SING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(307, 
"MOBIL S FA", "MOBIL SALES & SUPPLY CORP., VA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(308, 
"CXYEGY USA", "CXY ENERGY MARKETING INC. (HOUSTON)", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(309, 
"PAKTANK AB", "PAKTANK AB", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(310, 
"ELF EXP", "ELF EXPLORATION, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(311, 
"SCPERM", "SCURLOCK PERMIAN LLC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(312, 
"BLACK HILS", "BLACK HILLS ENERGY RESOURCES, IN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(313, 
"ONYX OIL", "ONYX OIL LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(314, 
"BRK-SYNTEX", "SYNTEX BRK", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(315, 
"UNOCAL EGT", "UNOCAL EGT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(316, 
"JDSQUARED", "JDSQUARED-BRK", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(317, 
"GENESIS", "GENESIS CRUDE OIL, L.P.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(318, 
"BURLINGTON", "BURLINGTON RESOURCES TRADING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(319, 
"CENTRAL CR", "CENTRAL CRUDE CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(320, 
"ENRON RES", "ENRON RESERVE ACQUISITION CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(321, 
"NIOC BUNKR", "N.I.O.C. BUNKERING B.V.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(322, 
"MARA ASLND", "MARATHON ASHLAND PETROLEUM LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(323, 
"DUKE TRANS", "DUKE ENERGY TRANSPORT & TRADING COMPANY", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(324, "ARC", 
"ARC - BROKER", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(325, 
"CHEV PR", "CHEVRON PRODUCTS CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(326, 
"PHILLIPS66", "PHILLLIPS 66 COMPANY, A DIVISION OF PHILLIPS PETROLEUM COMPANY", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(327, "TCT", 
"TCT OIL BROKERS", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(328, 
"AMEREX FLR BRK", "AMEREX", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(329, 
"BANK AMER", "BANK OF AMERICA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(330, "HESS", 
"AMERADA HESS TRADING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(331, 
"BANK MONTR", "BANK OF MONTREAL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(332, 
"BANQUE PAR", "BANQUE PARIBAS - NEW YORK BRANCH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(333, 
"AMOCO PL", "AMOCO PIPELINE COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(334, 
"BELCO OIL", "BELCO OIL & GAS CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(335, 
"GIANT", "GIANT INDUSTRIES ARIZONA INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(336, 
"HOUSE CASH", "HOUSE CASH INTERDESK TRADES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(337, "CSFP", 
"CREDIT SUISSE FINANCIAL PRODUCTS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(338, 
"ELECHABEL", "ELECTRABEL SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(339, 
"FERREL RES", "FERREL RESOURCES L.L.C.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(340, 
"HEADINGTON", "HEADINGTON OIL COMPANY LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(341, 
"REDAN", "REDAN FUTURES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(342, 
"MORAN TRAN", "MORAN TRANSPORTATION COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(343, 
"PGE EGY TR", "PG&E ENERGY TRADING-GAS CORPORATION", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(344, 
"TOK MIT LN", "TOKYO-MITSUBISHI INTL. PLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(345, 
"SOUTHRN CO", "SOUTHERN COMPANY SERVICES INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(346, 
"SOTHRN EGY", "SOUTHERN CO. ENGY. MKTG, L.P. (POWER)", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(347, 
"OPENING INV.", "OPENING INVENTORY 01/99", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(348, "ENEL", 
"ENEL - SOCIETA PER AZIONI", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(349, 
"BP EXP&OIL", "BP EXPLORATION & OIL COMPANY INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(350, 
"STARR", "STARR", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(351, "PVM", 
"PVM OIL ASSOCIATES LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(352, 
"INTER", "INTERCAPITAL OIL BROKERS", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(353, 
"SHIP OWNER", "SHIP OWNER FOR TRANPORTATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(354, 
"EUROAMER", "EUROAMERICAN ENERGY SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(355, 
"DO NOT USE", "DO NOT USE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(356, 
"COOLKEERAG", "COOLKEERAGH POWER LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(357, 
"CONTINENT", "CONTINENTAL COMMODITIES GROUP", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(358, 
"REPSOL MA", "REPSOL S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(359, 
"COSCO", "CHINA OCEAN SHIPPING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(360, 
"ECHO BAY", "ECHO BAY MINES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(361, "NCRA", 
"NATIONAL COOPERATIVE REFINERY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(362, 
"GERALD", "GERALD", "A", "EXCHBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(363, "UPFI", 
"UPR ENERGY MARKETING INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(364, 
"ELECTRABEL", "ELECTRABEL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(365, 
"SPECTRONLD", "SPECTRON PRODUCTS LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(366, 
"D&R ENERGY", "D&R ENERGY LLC", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(367, 
"SAYBOLTSWEDEN", "SAYBOLT SWEDEN AB", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(368, 
"CARGILL NY", "CARGILL INVESTON SERVICES, NY", "A", "EXCHBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(369, 
"EXXON CORP", "EXXON CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(370, 
"DIMON OIL", "DIMON OIL", "A", "EXCHBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(371, 
"FIMAT", "FIMAT", "A", "EXCHBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(372, 
"BRK-TOP", "TOP ENERGY INC", "A", "EXCHBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(373, 
"SMITHB", "SMITHB", "A", "EXCHBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(374, 
"DAI-ACCESS", "DAIWA SECURITIES AMERICA INC", "A", "EXCHBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(375, 
"FRISOL OIL", "FRISOL OIL PRODUCTS NEDERLAND BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(376, 
"STATOIL LN", "STATOIL UK LTD. , LONDON", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(377, 
"ENERGEX", "ENERGEX", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(378, 
"CHICAGO CO", "ABN AMRO CHICAGO CORP", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(379, "ZONE", 
"ZONE EGY GROUP", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(380, "TSA", 
"TULLETT & TOKYO SYDNEY SWITCH", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(381, 
"BRK-AZUR", "BRK-AZUR", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(382, 
"ACCESS-SEM", "ACCESS-SEM", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(383, 
"UNION PAC", "UNION PACIFIC FUELS INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(384, 
"APIOIL", "API OIL LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(385, 
"PHIBRO GMBH ZUG", "PHIBRO GMBH - ZUG BRANCH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(386, 
"FIRSTNAT", "FIRSTNAT", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(387, 
"N'RIDGE", "NORTHRIDGE ENERGY MARKETING CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(388, 
"IVG LOGIST", "IVG LOGISTIK GMBHIVG LOGISTIK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(389, 
"ARCAD EGY", "ARCADIA ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(390, 
"PAKTANK OI", "PAKTANK OIL NEDERLAN BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(391, 
" STORAGE SPRE", " STORAGE SPRE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(392, "CIM", 
"COMPAGNIE INDUSTRIELLE MARITIME", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(393, 
"KOCH REF", "KOCH PETROLEUM GROUP LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(394, "J&S", 
"J AND  S SERVICES AND INVESTMENTS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(395, 
"HESS (UK)", "HESS ENERGY TRADING UK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(396, 
"APIOIL LTD", "API OIL LIMITED UK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(397, 
"PETRONED BV", "PETRONED BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(398, 
"INTER-INA", "INTER-INA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(399, 
"MASTERWORK", "MASTERWORKS LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(400, 
"CARGIL DIV", "CARGILL ENERGY A DIV OF CARGILL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(401, 
"FORTUM GAS", "FORTUM GAS LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(402, 
"FORTUM OIL", "FORTUM OIL AND GAS OY (FKA NES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(403, 
" TEST", " TEST", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(404, 
"FARREL N.AMER", "FARREL N.AMER", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(405, 
"AEBRUGGEM", "A.E.BRUGGEMAN", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(406, 
"ECHO EGY L", "ECHO EGY L", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(407, 
"DYNEGY UK LTD", "DYNEGY UK LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(408, "OMV", 
"OMV SUPPLY & TRADING AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(409, 
"PRUBACHE", "PRUBACHE", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(410, 
"BRITOIL", "BRITOIL PLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(411, 
"FIRST RES", "FIRST RESERVE OIL GAS & CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(412, 
"JPMORGAN", "JPMORGAN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(413, 
"KERMCGEE", "KERR-MCGEE ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(414, 
"TIPPERARY", "TIPPERARY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(415, 
"NORWEGIAN", "NORWEGIAN OIL TRADINGS AS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(416, 
"TEXON", "TEXON CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(417, 
"TRAF DERIV", "TRAFIGURA  DERIVATIVES LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(418, 
"SEMPRA IRE", "SEMPRA OIL TRADING IRELAND LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(419, 
"SHELL ROT", "SHELL NEDERLAND BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(420, 
"COAST ENGY", "COAST ENERGY GROUP, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(421, 
"ANADARKO", "ANADARKO ENERGY  SERVICES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(422, 
"GARY W", "GARY WILLIAMS ENERGY CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(423, 
"TORCH ENGY", "TORCH ENERGY MARKETING, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(424, 
"GATXPROD SER", "GATXPRODUCERS SERVICES, LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(425, 
"SJB PETRO", "SJB PETROLEUM PRODUCTS BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(426, 
"GRZ ENERGY", "GRZ ENERGY", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(427, 
"QUIKTRIP", "QUIKTRIP CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(428, "ORYX", 
"ORYX CRUDE TRADING AND TRANSPORTATION LIMITED PARTNERSHIP", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(429, 
"STAR EGY", "STARENERGYUSA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(430, 
"ORION REF", "ORION REFINING CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(431, 
"VA ELEC PO", "VA ELEC PO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(432, 
"EAGLE WING", "EAGL.EWING TRADING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(433, 
"ENTECH", "ENTECH INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(434, 
"LYONDELL", "LYONDELL PETROCHEMICAL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(435, 
"NAVAJO", "NAVAJO REFINING CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(436, 
"ENJET", "ENJET INC.,TX", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(437, 
"POWERGEN", "POWERGEN PLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(438, 
"OXY T", "OCCIDENTAL ENERGY MARKETING, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(439, 
"PADD 7", "PADD 7", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(440, 
"CALTEX", "CALTEX TRADING PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(441, "ESB", 
"ELECTRICITY SUPPLY BOARD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(442, 
"MAN ACCESS", "MAN ACCESS", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(443, 
"MOTIVA", "MOTIVA ENTERPRISES LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(444, 
"CABINDA", "CABINDA GULF OIL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(445, 
"DOMINION", "DOMCAN EAST ALBERTA LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(446, 
"PENZOL GAS", "PENNZOIL GAS MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(447, 
"RELIANT", "RELIANT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(448, 
"NORTHVILLE", "NORTHVILLE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(449, 
"SK CORP", "SK CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(450, 
"OILEX", "OILEX", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(451, 
"MOBIL OIL", "MOBIL OIL & GAS ASSOCIATES LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(452, 
"SINOPEC KAN", "SINOPEC KANTONS HOLDINGS LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(453, 
"CANADIAN FORE", "CANADIAN FORE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(454, 
"VEBA PTE", "VEBA OIL SUPPLY & TRADING PTE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(455, "VOTT", 
"VOTT NORDIC TANK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(456, "HQ", 
"HQ", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(457, 
"BP AMOCO", "BP AMOCO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(458, 
"EOTT ENRGY", "EOTT ENERGY OPERATING LIMITED PARTNERSHIP", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(459, 
" INVNTRY TR", " INVNTRY TRNS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(460, 
"ADDAXBV", "ADDAX B.V. GENEVA BRANCH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(461, 
"SINCLAIR", "SINCLAIR OIL CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(462, 
"US GYPSUM", "U.S. GYPSUM COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(463, 
"AGRAMOR", "AGRAMOR", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(464, 
"VULCAN GEN", "VTT VULCAN PETROLEUM SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(465, 
"ENRON L&I", "ENRON LIQUID FUEL INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(466, 
"PETRAIN", "PETRAIN", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(467, 
"GLOBAL-BRK", "GLOBAL", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(468, 
"CALPAM BV", "CALPAM BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(469, 
"ULTRAMAR", "ULTRAMAR LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(470, 
"PVM(FUTURES)", "PVM", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(471, 
"CARTHAGE", "CARTHAGE ENERGY SERVICES INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(472, 
"DAMOIL", "DAMOIL SRL", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(473, "GMC", 
"GENERAL MARITIME CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(474, 
"BRIDGE MAR", "BRIDGE MARINE FUELS BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(475, 
"SITHE ENGY", "SITHE ENERGIES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(476, 
"INTRA CO", "INTRA COMPANY MARKETING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(477, 
"SONAT EXP", "SONAT EXPLORATION CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(478, 
"AB SHIPPING", "AB SHIPPING LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(479, 
"ROLL INVEN", "INVENTORYROLL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(480, 
"UNIONPACIFIC", "UNIONPACIFIC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(481, 
"TRANS POWR", "TRANSCANADA POWER A DIV OF TRANSCANADA ENERGY LTD", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(482, 
"WESTERN RES", "WESTERN GAS RESOURCES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(483, 
"GREENENERGY", "GREENENERGY SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(484, 
"POSTOILS B", "POSTOIL BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(485, 
" MASEFIELD", "MASEFIELD AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(486, 
"AMOCO PROD", "AMOCO PRODUCTION COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(487, 
"EDP (CPPE)", "EDP (CPPE)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(488, 
"ORLANDO UT", "ORLANDO UTILITIES COMMISSION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(489, 
"TREFOIL BV", "TREFOIL TRADING BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(490, "ABC", 
"ABC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(491, 
"WILJO NV", "WILJO NV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(492, 
"HINCHEST", "HINCHEST (HK) LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(493, 
"CARGILL", "CARGILL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(494, "CG", 
"CARGILL NY BROKER", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(495, 
"AMER. HESS COMO", "AMERADA HESS COMMODITIES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(496, 
"SHENZHEN", "SHENZHEN ENERGY (HK) INTL LID", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(497, 
"ARGOMAR", "ARGOMAR OIL LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(498, 
"INTERCON ENTRPS", "INTERCON ENTERPRISE LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(499, 
"SAMOTA", "SAMOTA SHIPPING COMPANY LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(500, 
"SOVEREIGN", "SOVEREIGN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(501, 
" MARUBENI", " MARUBENI INTERNATIONAL PETROLEUM (S) PTE LTD", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(502, 
"SINOMART K", "SINOMART KTS DEVELOPMENT LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(503, 
"GERALD2", "GERALD2", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(504, 
"PETROSOURCE", "PETROSOURCE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(505, 
"CANADIAN P", "CANADIANOXY INTERNATIONAL MARKETING LTD", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(506, 
"CONT FUR", "CONTINENTAL LAND & FUR COMPANY, INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(507, "D", 
"DIRECT", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(508, 
"LG CALTEX", "LG CALTEX GAS CO, LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(509, 
"THISTLE", "THISTLE ENERGY  BROKER", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(510, 
"INHOUSE", "INHOUSE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(511, 
"VTT VULCAN", "VTT VULCAN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(512, 
"DEFAULT", "DEFAULT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(513, 
"NUEVO EGY", "NUEVO ENERGY COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(514, 
"GULF CANDA", "GULF CANDA RESOURCES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(515, 
"FIRE CREEK", "FIRE CREEK OIL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(516, 
"VERBEKE", "VERBEKE BUNKERING NV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(517, 
"RANGER", "RANGER OIL LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(518, 
"WEST HOLDINGS", "WEST HOLDINGS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(519, 
"PETROGAL", "PETROLGAL, SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(520, "HUNT", 
"HUNT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(521, 
"SANTA FE", "SANTA FE SNYDER CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(522, 
"CORAL", "CORAL ENERGY HOLDING LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(523, 
"CANAD NAT", "CANADIAN NATURAL RESOURCES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(524, 
"SHELL CAD", "SHELL CANADA LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(525, 
"SEMPRA ENERGY", "SEMPRA ENERGY TRADING CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(526, 
"JACKSONS", "JACKSONS", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(527, 
"LONDON CLE", "THE LONDON CLEARING HOUSE LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(528, "UPR", 
"UNION PACIFIC RESOURCES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(529, 
" S.J.B.", " S.J.B.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(530, 
"DYNAMICOIL", "DYNAMIC OIL SERVICES N.V.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(531, 
"ENICHEM", "ENICHEM SPA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(532, 
"FALCON-BRK", "FALCON PRODUCTS INC.", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(533, 
"KILDAIR", "KILDAIR SERVICE LTEE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(534, 
"WESTPORT", "WESTPORT PETROLEUM INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(535, 
"HUNT ICI", "HUNTSMAN ICI PETROCHEMICALS (UK) LTD.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(536, 
"CONTI", "CONTINENTAL AIRLINES INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(537, 
"NRG POWER", "NRG POWER MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(538, "EMC", 
"EUROPEAN MARINE CONSULTANTS", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(539, 
"FLOATSTORAGE", "FLOATSTORAGE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(540, 
"PJM TRANS", "PJM TRANSMISSION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(541, 
"ACANTHUS", "ACANTHUS RESOURCES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(542, 
"ACME BRICK", "ACME BRICK COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(543, 
"ADA CRUDE", "ADA CRUDE OIL COMPANY HOUSTON", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(544, 
"AEC MKT", "AEC MARKETING (FORMERLY KNOWN AS AEC OIL AND GAS PARTNERSHIP)", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(545, 
"DELETE TEST", "DELETE TESTING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(546, 
"AEC MKT US", "AEC MARKETING (USA) INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(547, 
"AEC OIL", "AEC OIL & GAS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(548, 
"AVISTA COR", "AVISTA CORPORATION (POWER ONLY)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(549, 
"AEC STORAG", 
"AEC STORAGE AND HUB SERVICES, A DIVISION OF ALBERTA ENERGY COMANY LTD", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(550, 
"AEC WEST", "AEC WEST LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(551, 
"AECTRA", "AECTRA REFINING & MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(552, 
"AEDC USA", "AEDC (USA) INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(553, 
"AEP EG SER", "AEP ENERGY SERVICES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(554, 
"AES CORP", "AES CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(555, 
"AES PLACER", "AES PLACERITA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(556, 
"AG ENG INC", "AG ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(557, 
"AG ENERGY", "AG-ENERGY, LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(558, 
"NORTHRIDGE", "NORTHRIDGE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(559, "AGIP", 
"AGIP  (OVERSEAS) LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(560, 
"AGIP PETRO", "AGIP PETROLEUM CO. INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(561, 
"AGRIC MIN", "AGRICULTURAL MINERALS, LIMITED PARTNERSHIP", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(562, 
"AGRIUM INC", "AGRIUM INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(563, 
"AIG FP", "AIG FINANCIAL PRODUCTS CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(564, 
"AIR FRANCE", "AIR FRANCE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(565, 
"AIR INTER", "AIR INTER FRANCE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(566, 
"ALBRTA LTD", "ALBERTA ENERGY COMPANY LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(567, 
"ALBRTA PET", "ALBERTA PETROLEUM MARKETING COMMISSION", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(568, 
"ALCALDE", "ALCALDE ENERGY CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(569, 
"ALENCO GAS", "ALENCO GAS SERVICES INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(570, "ALFA", 
"ALFA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(571, 
"ALLENERGY", "ALLENERGY MARKETING COMPANY LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(572, 
"ALLIANCE", "ALLIANCE ENERGY SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(573, 
"ALLIED SIG", "ALLIED-SIGNAL INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(574, 
"ALMA E", "ALMA ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(575, 
"ALTOGAS", "ALTAGAS SERVICES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(576, 
"ALTANA EXP", "ALTANA EXPLORATION CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(577, 
"ALTER EGY", "ALTER ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(578, 
"ALTOS HORN", "ALTOS HORNOS DE MEXICO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(579, 
"ALCOA", "ALUMINUM COMPANY OF AMERICA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(580, 
"HESS HYDR", "AMERADA HESS (HYDROCARBONS) LIMITED", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(581, 
"AMEREN", "AMEREN ENERGY, INC., AS AGENT FOR AMEREN SERVICES COMPANY", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(582, 
"BARRICK", "AMERICAN BARRICK CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(583, 
"AM CENTRAL", "AMERICAN CENTRAL GAS COMPANIES INC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(584, 
"AMER E P", "AMERICAN ELECTRIC POWER SERVICE CORP.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(585, 
"AMER EX", "AMERICAN EXPLORATION CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(586, 
"AMER GAS", "AMERICAN GAS MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(587, 
"AMER HUNTR", "AMERICAN HUNTER ENERGY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(588, "AMPO", 
"AMERICAN MUNICIPAL POWER - OHIO INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(589, 
"AM NAT PWR", "AMERICAN NATIONAL POWER", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(590, 
"AM O&G TX", "AMERICAN OIL AND GAS COPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(591, 
"AMER TRAD", "AMERICAN TRADING AND PRODUCTION CO.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(592, 
"ATAPCO", "AMERICAN TRADING PRODUCTION COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(593, 
"AMER WARR", "AMERICAN WARRIOR", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(594, 
"AMGAS", "AMGAS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(595, 
"AMOCO CMKT", "AMOCO CANADA MARKETING CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(596, 
"AMOCO CAN", "AMOCO CANADA PETROLEUM COMPANY LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(597, 
"AMOCO CORP", "AMOCO CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(598, 
"AMPOLEX", "AMPOLEX LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(599, 
"AMTRAK", "AMTRAK - NATIONAL PASSENGER RAILROAD CORP.", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(600, 
"ANDERS EXP", "ANDERSON EXPLORATION LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(601, 
"ANR PIPE", "ANR PIPELINE CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(602, 
"ANSCHU RAN", "ANSCHUTZ RANCH EAST CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(603, 
"APACHE", "APACHE CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(604, 
"APTIAN", "APTIAN ENERGY SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(605, 
"AQUILA CAD", "AQUILA CANADA CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(606, 
"AQUILA POW", "AQUILA POWER CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(607, 
"AQUILA SW", "AQUILA SOUTHWEST MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(608, "ARCH", 
"ARCH PETROLEUM INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(609, 
"ARCHER DAD", "ARCHER-DANIELS-MIDLAND COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(610, 
"ARCO GAS", "ARCO GAS MARKETING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(611, "ARCO", 
"ARCO OIL AND GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(612, "XXXX", 
"ARCO PIPE LINE COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(613, 
"ARCO PROD", "ARCO PRODUCTS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(614, 
"AZ PUBLIC", "ARIZONA PUBLIC SERVICE COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(615, 
"ARK ELEC C", "ARKANSAS ELECTRIC COOPERATIVE, A DIVISION OF ASHLAND INC.", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(616, 
"ASHLND CHM", "ASHLAND CHEMICAL, A DIVISION OF ASHLAND INC.", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(617, 
"ASHLND GAS", "ASHLAND GAS MARKETING, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(618, 
"ASHLAND", "ASHLAND PETROLEUM COMPANY, A DIVISION OF ASHLAND INC.", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(619, 
"ASH SCUR", "ASHLAND SCURLOCK PERMIAN CANADA LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(620, 
"ASSOC BUNK", "ASSOCIATED BUNKEROIL CONTRACTORS BV", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(621, 
"ATLANTA GL", "ATLANTA GAS LIGHT COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(622, 
"ATLANTIC E", "ATLANTIC CITY ROFING CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(623, 
"ATLAS", "ATLAS ROOFING CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(624, 
"AURORA", "AURORA NATURAL GAS AND PRODUCTS LC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(625, 
"AUSSIE AIR", "AUSTRALIAN AIRLINE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(626, 
"AUTO ALINC", "AUTO ALLIANCE INTERNATIONAL INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(627, 
"AVENOR", "AVENOR INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(628, 
"AVERY DENN", "AVERY DENNISON", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(629, 
"AVIARRA", "AVIARA ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(630, 
"AVISTA EGY", "AVISTA ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(631, 
"AXEL J", "AXEL JOHNSON INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(632, 
"BLACKBRD", "AXEM-BLACKBIRD LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(633, 
"AYP ENERGY", "AYP ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(634, 
"B BRAWN", "B BRAUN MEDICAL INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(635, 
"BAKERS EGY", "BAKERSFIELD ENERGY RESOURCES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(636, 
"BALL FOSTR", "BALL-FOSTER GLASS CONTAINER CO LLC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(637, 
"BALT GE", "BALTIMORE GAS & ELECTRIC COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(638, 
"BANESTO", "BANESTO FALCON CURRENCY FUND", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(639, 
"DEGROOF", "BANQUE DEGROOF", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(640, 
"BANQUE IND", "BANQUE INDOSUEZ LONDON", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(641, 
"INDOSUEZ", "BANQUE INDOSUEZ, NY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(642, 
"BK PAR-GEN", "BANQUE PARIBAS, GENEVA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(643, 
"BARRETT F", "BARRETT FUELS CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(644, 
"BARRETT", "BARRETT REFINING CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(645, 
"BARRETT R", "BARRETT RESOURCES CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(646, 
"BASIN", "BASIN EXPLORATION INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(647, 
"BATTLE CRK", "BATTLE CREEK GAS CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(648, 
"BAYOIL ST", "BAY OIL (USA) INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(649, 
"BAYOIL NA", "BAY OIL LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(650, 
"BAY STATE", "BAY STATE GAS CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(651, 
"BC GAS", "BC GAS UTILITY LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(652, 
"BEAU CAN", "BEAU CANADA EXPLORATION LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(653, "BELL", 
"BELL FUELS, INC (CHICAGO)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(654, 
"BELLWETHER", "BELLWETHER EXPLORATION COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(655, 
"BERCO RES", "BERCO RESOURCES, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(656, 
"BERRY META", "BERRY METAL CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(657, 
"BERRY PETR", "BERRY PETROLEUM COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(658, 
"BIG WEST", "BIG WEST COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(659, 
"BLAZER EGY", "BLAZER ENERGY CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(660, 
"BOMINFLOT", "BOMINFLOT BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(661, 
"BONNEVILLE", "BONNEVILLE POWER ADMINISTRATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(662, 
"BORDER", 
"BORDER REFINING & MARKETING COMPANY, AS AGENT FOR REFINERY HOLDING CO.", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(663, 
"CHAMBERSBG", "BOROUGH OF CHAMBERSBURG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(664, 
"BOSTON ED", "BOSTON EDISON COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(665, 
"BOSTON GAS", "BOSTON GAS CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(666, 
"BOW VALLEY", "BOW VALLEY ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(667, "800", 
"BOWDOIN COLLEGE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(668, 
"BOX ENERGY", "BOX ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(669, 
"BOYD ROSE", "BOYD ROSENE AND ASSOCIATES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(670, 
"BP NA HSTN", "BP NA PETROLEUM INC (TEXAS)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(671, 
"BP NA NY", "BP NA PETROLEUM INC (NEW YORK)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(672, 
"BP NEDERLN", "BP NEDERLAND BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(673, 
"AIR BP", "BP OIL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(674, 
"BP PET", "BP PETROLEUM DEVELOPMENT LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(675, 
"BRASOIL UK", "BRASOIL UK LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(676, 
"PETRIAN", "PETRIAN SHIPBROKERS LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(677, 
"BRIDGE", "BRIDGE OIL CO LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(678, 
"BRIDGE PL", "BRIDGELINE GAS DISTRIBUTION CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(679, 
"BRIDGELINE", "BRIDGELINE GAS MARKETING LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(680, 
"BRIT F", "BRITANNIC FUTURE TRADING LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(681, 
"BRITISH BO", "BRITISH BORNEO PETROLEUM SYNDICATE PLC", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(682, 
"BRITISH CO", "BRITISH COLUMBIA POWER EXCHANGE CORP.", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(683, 
"BROOKLYN", "BROOKLYN INTERSTATE NATURAL GAS CORP.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(684, 
"BROOK", "BROOKLYN OIL ASSOCIATES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(685, 
"BROOKLYN UN", "BROOKLYN UNION  GAS COMPANY D/B/A KEYSPAN EGY DELIVERY NY", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(686, 
"BRYMORE", "BRYMORE ENERGY LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(687, "BMH", 
"BURLINGTON MOTOR HOLDINGS INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(688, 
"BURNS", "BURNS & MCBRIDE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(689, 
"C ITOH LN", "C. ITOH PETROLEUM CO. (UK) LTD. LDN", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(690, 
"CABOT MKT", "CABOT OIL & GAS MARKETING CORPORATION", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(691, 
"CABRE EXPL", "CABRE EXPLORATION LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(692, 
"CAIRN", "CAIRN ENERGY, PLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(693, 
"CAIRO", "CAIRO PUBLIC UTILITY COMMISSION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(694, 
"CALCAS GAS", "CALCASIEU GAS GATHERING SYSTEM", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(695, 
"CALCASIEU", "CALCASIEU REFINING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(696, 
"CAL DPT WR", "CALIFORNIA DEPARTMENT OF WATER RESOURCES", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(697, 
"CALPORT CM", "CALIFORNIA PORTLAND CEMENT COMPANY", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(698, 
"ARZNA PORT", "CALIFIORNIA PORTLAND CEMENT COMPANY", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(699, 
"CALPIN FU", "CALPINE FUELS CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(700, 
"CALPINE", "CALPINE POWER SERVICES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(701, 
"CAMBIOR", "CAMBIOR INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(702, 
"CAN PET", "CAN PET ENERGY GROUP (USA), INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(703, 
"CANNWENR", "CANADA NORTHWEST ENERGY LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(704, 
"CAN FOREST", "CANADIAN  FOREST OIL LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(705, 
"CANAD HUNT", "CANADIAN HUNTER EXPLORATION LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(706, 
"CANENERCO", "CANENERCO ENERGY SERVICES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(707, 
"CANTOR FTZ", "CNTOR FITZGERALD BROKERAGE, LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(708, 
"CANWEST", "CANWEST GAS SUPPLY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(709, 
"CAN USA", "CANWEST GAS SUPPLY USA INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(710, 
"CAPE FEAR", "CAPE FEAR ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(711, 
"CARGILL AL", "CARGILL ALLIANT LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(712, 
"CAROLINA", "CAROLINA POWER AND LIGHT COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(713, 
"CASCADE", "CASCADE NATURAL GAS CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(714, 
"CASTLE", "CASTLE SUPPLY & MARKETING INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(715, 
"CAT/CORAL", "CATEX CORAL ENERGY LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(716, 
"CATHAY HK", "CATHAY PACIFIC AIRWAYS LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(717, 
"PHOEBE INT", "CAXTON INTERNATIONAL LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(718, 
"CELERON", "CELERON TRADING & TRANSPORTATION COMPANY", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(719, 
"AUGHINISH", "AUGHINISH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(720, 
"CELSIUS", "CELSIUS ENERGY COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(721, 
"CENRPRIS", "CENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(722, 
"CENEX", "CENEX INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(723, 
"CENTER", "CENTER OIL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(724, 
"CENTRA MAN", "CENTRA GAS MANITOBA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(725, 
"CENTRA ONT", "CENTRA GAS ONTARIO INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(726, 
"CENTRAL SW", "CENTRAL & SOUTH WEST SERVICES, INC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(727, 
"CENTRAL", "CENTRAL HUDSON GAS & ELECTRIC CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(728, 
"CENT IL LC", "CENTRAL ILLINOIS LIGHT COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(729, 
"CIPSCO", "CENTRAL ILLINOIS PUBLIC SERVICE CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(730, 
"CLECO CORP", "CENTRAL LOUISIANA ELECTRIC COMPANY", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(731, 
"CENTRAL VT", "CENTRAL VERMONT PUBLIC SERVICE CORP.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(732, 
"CHANDLER", "CHANDLER ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(733, 
"CHANNEL GM", "CHANNEL GAS MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(734, 
"CHANNEL LK", "CHANNEL LAKE PETROLEUM LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(735, 
"CHESAP MKT", "CHESAPEAKE ENERGY MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(736, 
"CHEV CANRE", "CHEVRON CANADA RESOURCES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(737, 
"CHEV HSTN", "CHEVRON USA INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(738, 
"CIBOLA", "CIBOLA CANADA ENERGY MARKETING CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(739, 
"CIBOLA CRP", "CIBOLA ENERGY SERVICES CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(740, 
"CIG MERCH", "CIG MERCHANT COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(741, 
"CINRGY RES", "CINERGY RESOURCES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(742, 
"CINERGY", "CINERGY SERVCIES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(743, 
"CITIZENS", "CITIZENS GAS &COKE UTILITY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(744, 
"CIT LEH PO", "CITIZENS POWER SALES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(745, 
"CTY ASUZA", "CITY OF ASUZA LIGHT & WATER DEPARTMENT", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(746, 
"CTY BANNIN", "CITY OF BANNING ELECTRIC UTILITY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(747, 
"CTY BURBNK", "CITY OF BURBANK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(748, 
"CTY COLTON", "CITY OF COLTAN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(749, 
"CTY DANVIL", "CITY OF DANVILLE, VIRGINIA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(750, 
"CTY GLNDAL", "CITY OF GLENDALE PUBLIC SERVICE DEPARTMENT", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(751, 
"LONGBCH GD", "CITY OF LONG BEACH GAS & ELECTRIC DEPT", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(752, 
"NORWICH", "CITY OF NORWICH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(753, 
"CTY PASADE", "CITY OF PASADENA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(754, 
"CTY REDDIN", "CITY OF REDDING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(755, 
"CTY SANCLR", "CITY OF SANTA CLARA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(756, 
"CTY OF VER", "CITY OF VERNON", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(757, 
"TONKAWA", "TONKAWA GAS PROCESSING CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(758, 
"CLARDN CT", "CLAREDON LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(759, 
"CLEVELAND", "CLEVELAND ELECTRIC ILLUMINATING CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(760, 
"CLINTN EMS", "CLINTON ENERGY MANAGEMENT SERVICES INC", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(761, 
"TORONTO D", "TORONTO DISTRICT HEATING CORPORATION", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(762, 
"TOTAL MINA", "TOTAL MINATOME CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(763, 
"TOTAL O", "TOTAL OIL INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(764, 
"SMYRNA", "TOWN OF SMYRNA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(765, 
"UTICA TOWN", "TOWN OF UTICA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(766, 
"CONT NAT", "CMS CONTINENTAL NATURAL GAS INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(767, 
"TEJAS POW", "ENERGYUSA-TPC COPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(768, 
"CMS GAS", "CMS GAS MARKETING CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(769, 
"CMS MKT", "CMS MARKETING, SERVICES &TRADING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(770, 
"NOMECO", "CMS NOMECO OIL & GAS CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(771, 
"TRACTABEL", "TRACTEBEL ENERGY MARKETING, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(772, 
"CNE DEVPMT", "CNE DEVELOPMENT CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(773, 
"TRAMMO GAS", "TRAMMO GAS CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(774, 
"CNE PEAK", "CNE PEAK LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(775, 
"TRANSMRK", "TRANS MARKETING HOUSTON, INC,", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(776, 
"TWA AIR", "TRANS WORLD AIRLINES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(777, 
"TRANS US", "TRANSALTA ENERGY MARKETING (U.S.) INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(778, 
"CNG GAS", "CNG ENERGY SERVICES CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(779, 
"TRANS EGY", "TRANSCANADA ENERGY FINANCIAL PRODUCTS LIMITED", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(780, 
"CNG FIELD", "DOMINION FIELD SERVICES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(781, 
"CNG POWER", "CNG POWER SERVICES CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(782, 
"TRANS MKT", "TRANSCANADA ENERGY MARKETING USA INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(783, 
"CNG RETAIL", "CNG RETAIL SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(784, 
"CNG TRANS", "CNG TRANSMISSION CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(785, 
"TRANS GAS", "TRANSCANADA GAS SERVICES INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(786, 
"COAST ELEC", "COASTAL ELECTRIC SERVICES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(787, 
"TRANS LTD", "TRANSCANADA GAS SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(788, 
"COASTAL CD", "COASTAL GAS MARKETING CANADA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(789, 
"TRANSCOE", "TRANSCO ENERGY MARKETING CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(790, 
"COASTAL HO", "COASTAL HOLDING CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(791, 
"TRANSCOPIPE", "TRANSCONTINENTAL GAS PIPE LINE CORPORATION", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(792, 
"COASTAL PE", "COASTAL PETROLEUM (FAR EAST) PTE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(793, "CODA", 
"CODA ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(794, 
"TRANSOK GS", "TRANSOK GAS LLC", "A", "CPYAGENT", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(795, 
"TRANSOK", "TRANSOK INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(796, 
"COENERGY R", "COENERGY ROCKIES, INC C/O ENERGY WEST", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(797, 
"COENEREGY T", "COENERGY TRADING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(798, 
"COENERGY", "COENERGY VENTURES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(799, 
"COG-EPCO", "COG-EPCO 1992 LIMITED PARTNER", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(800, 
"TRANSPORT", "TRANSPORT GAS CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(801, 
"COKINOS", "COKINOS NATURAL GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(802, 
"COLONIAL", "COLONIAL ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(803, 
"TRANSTEX", "TRANSTEXAS GAS CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(804, 
"COLON GAS", "COLONIAL GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(805, 
"TRANSWST P", "TRANSWESTERN PIPELINE COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(806, 
"COL SPR UT", "COLORADO SPRINGS UTILITIES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(807, 
"TRASIMEX", "TRASIMEX  SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(808, 
"TRISTAR GM", "TRISTAR  GAS MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(809, 
"TROUT", "TROUT TRADING FUND LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(810, 
"TRUNKLINE", "TRUNKLINE LNG COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(811, 
"COL PWRMKT", "COLUMBIA ENERGY POWER MARKETING CORPORATION", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(812, 
"COL ENERGY", "COLUMBIA ENERGY SERVICES CORPORATION", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(813, 
"TST INC", "TST INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(814, 
"TUSCON  PWR", "TUSCON ELECTRIC POWER COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(815, 
"COL GAS", "COLUMBIA GAS DEVELOPMENT CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(816, 
"TWISTER", "TWISTER GAS SERVICES, L.L.C.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(817, 
"COL G DIST", "COLUMBIA GAS DITRIBUTION CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(818, 
"TXG GAS KY", "TXG GAS MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(819, 
"US GAS TPT", "U.S. GAS TRANSPORTATION , INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(820, 
"COLGAS KY", "COLUMBIA GAS OF KENTUCKY, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(821, "USX", 
"U. S. STEEL GROUP, A UNIT OF USX CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(822, 
"UGI UTL", "UGI UTILITIES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(823, 
"ULSTER", "ULSTER PETROLEUMS LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(824, 
"UNION CARB", "UNION CARBINE CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(825, 
"UNION ELEC", "UNION ELECTRIC COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(826, 
"COLGAS MD", "COLUMBIA GAS OF MARYLAND INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(827, 
"COL OHIO", "COLUMBIA GAS OF OHIO INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(828, 
"COL GAS PL", "COLUMBIA GAS PIPELINE CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(829, 
"COL NAT", "COLUMBIA NATURAL GAS RESOURCES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(830, 
"COLUMBUS E", "COLUMBUS ENERGY CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(831, 
"COM ED", "COMMONWEALTH EDISON COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(832, 
"COMN GS CO", "COMMONWEALTH GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(833, 
"COMMONWLTH", "COMMONWEALTH GAS SERVICES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(834, 
"CONCORDE", "CONCORDE GAS MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(835, 
"CONFED OIL", "CONFED OIL INCORPORATED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(836, 
"CONN L&P", "CONNECTICUT LIGHT AND POWER C/O NORTHEAST UTILITIES SERVICES", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(837, 
"CT NAT GAS", "CONNECTICUT NATURAL GAS CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(838, 
"CONOCO PWR", "CONOCO POWER MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(839, 
"CONOCO TR", "CONOCO TRADING COMP., HOUSTON", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(840, 
"CON ED NY", "CONSOLIDATED EDISON CO. OF NY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(841, 
"CON ED SOL", "CONSOLIDATED EDISON SOLUTIONS INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(842, 
"CONSOLIDLTD", "CONSOLDATED FUEL CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(843, 
"CONSOL OIL", "CONSOLIDATED OIL & GAS INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(844, 
"CONSTEL EG", "CONSTELLATION ENERGY SOURCE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(845, 
"CONSTEL PW", "CONSTELLATION POWER SOURCE INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(846, 
"CONSUM PWR", "CONSUMERS ENERGY COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(847, 
"CONWEST", "CONWEST EXPLORATION COMPANY LIMITED C/O ALBERTA ENERGY COMPANY LTD", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(848, 
"COOK INLET", "COOK INLET ENERGY SUPPLY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(849, 
"CORAL CAD", "CORAL ENERGY CANADA INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(850, 
"CORAL RES", "CORAL ENERGY RESOURCES LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(851, 
"UNION GAS", "UNION GAS LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(852, 
"CORAL PWR", "CORAL POWER LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(853, 
"UNOCAL", "UNION OIL COMPANY OF CALIFORNIA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(854, 
"CORAL REDW", "CORAL REDW", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(855, 
"CORNY", "CORN PRODUCTS INTERNATIONAL INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(856, 
"UNION TX", "UNION TEXAS PRODUCTS CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(857, 
"UNIT ILLUM", "UNITED ILLUMINATING CO,", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(858, 
"CORNERSTON", "CORNERSTONE NATURAL GAS INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(859, 
"UNITED MER", "UNITED MERIDIAN CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(860, 
"CORNING", "CORNING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(861, 
"UNIVER RES", "UNIVERSAL RESOURCES CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(862, 
"U OF TEXAS", "UNIVERSITY OF TEXAS SYSTEM", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(863, 
"UNOCAL CAN", "UNOCAL CANADA LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(864, 
"USGEN FUEL", "USGEN FUEL SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(865, 
"PEMBINA PL", "PEMBINA PIPELINE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(866, 
"USX-KOBE", "USS/KOBE STEEL CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(867, 
"PEMEX", "PEMEX GAS Y PETROQUIMICA BASICA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(868, 
"UTIL 2000", "UTILITY - 2000 ENERGY CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(869, 
"CORPUS TX", "CORPUS CHRISTI GAS MARKETING LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(870, 
"VALERO N", "VALERO NATURAL GAS PARTNERS, LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(871, 
"COWEST", "COWEST ENERGY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(872, 
"PENNFUEL", "PENN FUEL GAS, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(873, 
"CPC INT", "CPC INTERNATIONA.L INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(874, 
"VALLECITO", "VALLECITO GAS L.L.C.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(875, 
"PENNACO", "PENNACO ENERGY, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(876, 
"VANCOUVER", "VANCOUVER ISLAND GAS JOINT VENTURES", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(877, 
"PENNUNION", "PENNUNION ENERGY SERVICES, L.L.C.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(878, 
"CRESTAR", "CRESTAR ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(879, 
"VANGUARD", "VANGUARD PETROLEUM CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(880, 
"PENNZ CAN", "PENNZOIL CANADA INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(881, 
"CROSS ENER", "CROSS TIMBERS ENERGY SERVICES, INC C/O CROSS TIN=MBERS OIL CO", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(882, 
"VANTUS", "VANTUS POWER SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(883, 
"CROSSALT", "CROSSALTA GAS STORAGE & SERVICES LTD", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(884, 
"PENNZ E&P", "PENNZOIL EXPLORATION & PRODUCTION CO.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(885, 
"CROSSTX ES", "CROSSTEX ENERGY SERVICES LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(886, 
"VESTAR GAS", "VASTAR GAS MARKETING INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(887, 
"PENNZ PRDC", "PENNZOIL PRODUCING COMP, TX", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(888, 
"PENNZOIL PR", "PENNZOIL PRODUCTS COMP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(889, 
"PEOPLES GL", "PEOPLES GAS LIGHT & COKE CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(890, 
"CROWN VANT", "CROWN VANTAGE C/O KIMBALL RESOURCES", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(891, 
"PEOPLESNAT", "PEOPLES NATURAL GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(892, 
"CSRES", "CS RESOURCES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(893, 
"CUNRAD", "CUNRAD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(894, 
"PEPCO", "PEPCO SERVICES (GASLANTIC DIVISION)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(895, 
"VEBA GMBH", "VEBA OIL SUPPLY & TRADING GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(896, 
"PEREZ CO", "PEREZ COMPANC S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(897, 
"PERRY GAS", "PERRY GAS COMPANIES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(898, 
"VERMILION", "VERMILION GAS MARKETING INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(899, 
"CXY MKT US", "CXY ENERGY (USA) INC. FORMERLY WASCANA MARKETING", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(900, 
"PETRO LPG", "PETRO CANADA LPG, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(901, 
"VESSELS", "VESSELS OIL & GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(902, 
"CXY EGY CD", "CXY ENERGY MARKETING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(903, 
"PETRO CAD", "PETRO CANADA OIL & GAS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(904, 
"CYTEC", "CYTEC INDUSTRIES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(905, 
"DAKOTA GAS", "DAKOTA GASUFICATION COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(906, 
"PETROSOURC", "PETRO SOURCE CANADA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(907, 
"DART POWER", "DARTMOUTH POWER ASSOCIATES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(908, 
"PETRO CORP", "PETRO SOURCE CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(909, 
"CAD GOV QS", "CANADIAN GOVERNMENT QST", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(910, 
"DAYTON PWR", "DAYTON POWER & LIGHT COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(911, "DEAL", 
"DEAL ENERGY PARTNERS, LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(912, 
"DELANEY LN", "DELANEY (USA) INC., C/O DELANEY INTERNATIONAL LTD", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(913, 
"DELHI ESI", "DELHI ENERGY SERVICES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(914, 
"DELHI PIPE", "DELHI GAS PIPELINE CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(915, 
"DELMAR POW", "DELMARVA POWER & LIGHT CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(916, 
"DELPHI PET", "DELPHI PERTOLEUM, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(917, 
"DEN NORSKE", "DEN NORSKE AMERIKALINJE A/S", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(918, 
"DENVER RIO", "DENVER & RIO GRANDE WESTERN RAILROAD COMPANY", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(919, 
"DESTEC", "DESTEC ENERGY INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(920, 
"DETROIT ED", "DETROIT EDISON COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(921, 
"DEVON ENER", "DEVON ENERGY CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(922, 
"DFDS DENMK", "DFDS A/S", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(923, 
"DGS CORP", "DGS TRADING, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(924, 
"DIRECT MKT", "DIRECT ENERGY MARKETING LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(925, 
"DISCOV WST", "DISCOVERY WEST CORP, CALGARY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(926, 
"DGN D CHI", "DISTRIBUIDORA DE GAS NATURAL DE CHIHUAHUA", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(927, 
"ECOGAS", "DISTRIBUIDORA DE GAS NATURAL DE MEXICALI S. DE RL", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(928, 
"DOFAS", "DOFAS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(929, 
"DOURO", "DOURO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(930, 
"DOW CANADA", "DOW CHEMICAL CANADA INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(931, 
"DOW CHEM", "DOW CHEMICAL USA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(932, 
"DOW HYDRO", "DOW HYDROCARBONS & RESOURCES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(933, 
"DRACO GAS", "DRACO GAS PARTNERS LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(934, 
"DTE EGY TR", "DTE ENERGY TRADING INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(935, 
"DUKE CAD", "DUKE ENERGY MARKETING LIMITED PARTNERSHIP", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(936, 
"PAN SERV", "DUKE ENERGY NGL SERVICES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(937, 
"DUKE PWR-T", "DUKE POWER COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(938, 
"DUKE/LOUIS", "DUKE/LOUIS DREYFUS, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(939, 
"DUPONT POW", "DUPONT POWER MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(940, "804", 
"DUQUESNE FUND, LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(941, 
"DUQUESNE", "DUQUESNE LIGHT COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(942, 
"DYNERGY CD", 
"DYNERGY MARKETING AND TRADE, A DIVISION OF DYNEGY CANADA GAS MARKETINGLTD", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(943, 
"E-PRIME", "E PRIME, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(944, 
"EP OPERTNG", "EP OPERATING CO (ENSEARCH)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(945, 
"EP OP LTD", "EP OPERATING LIMITED PARTNER", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(946, 
"EAGLE GAS", "EAGLE GAS MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(947, 
"EAGLE NAT", "EAGLE NATURAL GAS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(948, 
"EAST KENTU", "EAST KENTUCKY POWER COOPERATIVE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(949, 
"EAST AMER", "EAST AMERICAN ENERGY CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(950, 
"EASTEX POW", "EASTEX POWER MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(951, 
"EDISON SRC", "EDISON SOURCE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(952, 
"EIL PETRO", "EIL PETROLEUM, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(953, 
"EL PASO GM", "EL PASO GAS MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(954, 
"EL PASO", "EL PASO NATURAL GAS CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(955, 
"EL PAS PWR", "EL PASO POWER SERVICES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(956, "ELAN", 
"ELAN ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(957, 
"ELAND", "ELAND ENERGY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(958, "ECI", 
"ELECTRIC CLEARINGHOUSE, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(959, 
"ELECTROMEC", "ELECTRO-MEC INCORPORATED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(960, 
"ELIZABETH", "ELIZABETHTOWN GAS CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(961, 
"EMISSIONS", "EMISSIONS TRDING LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(962, 
"ENCAL EGY", "ENCAL ENERGY LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(963, 
"ENCINA", "ENCINA GAS MARKETING CO., LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(964, 
"ENERCHANGE", "ENERCHANGE LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(965, 
"ENERGISTIC", "ENERGISTICS GROUP, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(966, 
"ENERGY AMR", "ENERGY AMERICA, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(967, 
"ENERGY", "ENERGY DEVELOPMENT CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(968, 
"PETROBRAS", "PETROBRAS S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(969, 
"LUMEN EGY", "ENERGY DYNAMICS, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(970, 
"ENER PACIF", "ENERGY PACIFIC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(971, 
"PETROMAR", "PETROLEUM MARKETING INTERNATIONAL A.V.V.", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(972, 
"COMN EGYSR", "ENERGY PACIFIC, DOING BUSINESS AS COMMONWEALTH ENERGY SERVICES", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(973, 
"PETRON", "PETRON OIL CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(974, 
"ENERGY TRD", "ENERGY TRADING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(975, 
"MARK RES", "ENERMARK INC (FORMERLY MARK RESOURCES)", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(976, 
"ENERTEK", "ENERTEK SA DE CV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(977, 
"ENERTRADE", "ENERTRADE INCORPORATED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(978, 
"PG ENERGY", "PG ENERGY SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(979, 
"ENERZ", "ENERZ CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(980, 
"ENGAGE CAD", "ENGAGE ENERGY CANADA LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(981, 
"PGE EGYPWR", "PG&E ENERGY TRADING - POWER, L.P.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(982, 
"ENGAGE USA", "ENGAGE ENERGY US LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(983, 
"ENGELHARD", "ENGELHARD POWER MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(984, 
"ENOGEX", "ENOGEX SERVICES CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(985, 
"ENRON CDNA", "ENRON CANADA CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(986, 
"PGE ENERGY", "PG&E ENERGY TRADING, CANADA CORPORATION", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(987, 
"ENRON CAP", "ENRON NORTH AMERICA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(988, 
"ENRON EGSR", "ENRON ENERGY SERVICES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(989, 
"VALEROGMLP", "PG&E TEXAS VGM, L.P.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(990, 
"ENRON LIQ", "ENRON GAS LIQUIDS, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(991, 
"PGE UEG", "PGE - UEG, A DIVISION OF PACIFIC GAS & ELECTRIC CO.", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(992, 
"ENRON HYD", "ENRON HYRDROCARBONS MARKETING CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(993, 
"PHIBRO E", "PHIBRO GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(994, 
"ENRON IND", "ENRON INDUSTRIAL NATURAL CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(995, 
"PHILAD GW", "PHILADELPHIA GAS WORKS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(996, 
"ENRON OIL", "ENRON OIL & GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(997, 
"PHIL CHEM", "PHILLIPS CHEMICAL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(998, 
"PHILPS GAS", "PHILLIPS GAS MARKETING CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(999, 
"ENRON OGMI", "ENRON OIL & GAS MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1000, 
"VESTA ENGY", "VESTA  ENERGY COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1001, 
"ENRON POWR", "ENRON POWER MARKETING, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1002, 
"PIEDMONT", "PIEDMONT NATURAL GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1003, 
"ENRON P", "ENRON PRODUCTS MARKETING CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1004, 
"PINACLE", "PINNACLE RESOURCES LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1005, 
"ENRON STRG", "ENRON STORAGE COMPAMY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1006, 
"PION EGMKT", "PIONEER ENERGY MARKETING COMPANY, INC.", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1007, 
"PITTSFIELD", "PITTSFIELD GENERATING COMPANY, L.P.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1008, 
"PJM INTER", "PJM INTERCONNECTION, L.L.C.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1009, 
"VINTAGE", "VINTAGE PETROLEUM INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1010, 
"ENSEAR PRO", "ENSEARCH PROCESS INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1011, 
"PLACID OIL", "PLACID OIL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1012, 
"ENSERCH CD", "TXU ENERGY TRADING CANADA LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1013, 
"PLACID", "PLACID REFINING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1014, 
"ENSERCH", "ENSERCH ENERGY SERVICES, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1015, 
"PMC 1988", "PMC 1988", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1016, 
"VIRIDIAN", "VIRIDIAN INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1017, 
"ENSEARCH", "ENSERCH EXPLORATION CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1018, 
"PMC 1990", "PMC 1990", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1019, 
"VISION", "VISION RESOURCES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1020, 
"ENSERCO", "ENSERCO ENERGY, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1021, 
"PMC 1993", "PMC 1993", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1022, 
"ENSIGN O&G", "ENSIGN OIL AND GAS, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1023, 
"VISTARESLP", "VISTA RESOURCES PARTNERS L.P.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1024, 
"PNM EGYMKT", 
"PNM ENERGY MARKETING, A DIVISION OF PUBLIC SERVICE COMPANY OF NEW MEXICO", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1025, 
"ENSOURCE", "ENSOURCE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1026, 
"VITOL GAS", "VITOL GAS & ELECTRIC LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1027, 
"PNM GAS SERVICE", 
"PNM GAS SERVICES, A DIVISION OF PUBLIC SERVICE COMPANY OF NEW MEXICO", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1028, 
"ENTERGY AK", "ENTERGY ARKANSAS, INCORPORATED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1029, 
"VOLANT", "VOLANT ENERGY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1030, 
"POCO MKT", "POCO MARKETING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1031, 
"ENTERGY", "ENTERGY GULF STATES, INCORPORATED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1032, 
"VOLUNTEER", "VOLUNTEER ENERGY CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1033, 
"POCO PETRO", "BURLINGTON RESOURCES CANADA ENERGY LTD", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1034, 
"ENTERGY LA", "ENTERGY LOUISIANA, INCORPORATED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1035, 
"POGO PROD", "POGO PRODUCING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1036, 
"ENTERGY MS", "ENTERGY MISSISSIPPI", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1037, 
"PONTCHATRN", "PONTCHARTRAIN NATURAL GAS SYSTEM", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1038, 
"ENTERGY NO", "ENTERGY NEW ORLEANS, INCORPORATED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1039, 
"PORTLAND", "PORTLAND GENERAL ELECTRIC COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1040, 
"WARREN GAS", "WARREN GAS LIQUIDS INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1041, 
"ENTERGY PW", "ENTERGY POWER MARKETING CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1042, 
"POTOMAC", "POTOMAC ELECTRIC POWER COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1043, 
"WARREN PET", "PARREN PETROLEUM COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1044, 
"POWER RES", "POWER RESOURCES OPERATING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1045, 
"ENTER LN", "ENTERPRISE PETROLEUM LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1046, 
"PENN POWER", "PP&L ELECTRIC UTILITIES CORP DBA PPL UTILITES", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1047, "PPG", 
"PPG INDUSTRIES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1048, 
"WASATCH EG", "-WASATCH ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1049, 
"WASCANA US", "WASCANA ENERGY MARKETING (U.S.)INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1050, 
"WASCANA", "WASCANA MARKETING, A DIVISION OF WASCANA ENERGY INC.", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1051, 
"ENTERPRISE", "ENTERPRISE PRODUCTS CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1052, 
"WASH ENGY", "WASHINGTON ENERGY GAS MARKETING INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1053, 
"WASH GLC", "WASHINGTON GAS LIGHT COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1054, 
"ENTEX", "ENTEX GAS MARKETING COMPANY, A NORAM COMPANY", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1055, 
"WASH NATGS", "WASHINGTON NATURAL GAS CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1056, 
"EPEM MKT", "EPEM MARKETING COMPANT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1057, 
"QUIMICA", "QUIMICA DEL REY, S.A. DE C.V.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1058, 
"EP TR", "EPSILON TRADING, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1059, 
"WATSON CO", "WATSON COGENERATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1060, 
"QUESTR GAS", "QUESTAR GAS CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1061, 
"EQUISTAR", "EQUISTAR CHEMICALS LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1062, 
"QUESTAR", "QUESTAR ENERGY TRADING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1063, 
"EQUIT ENER", "EQUITABLE ENERGY LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1064, 
"WEST TEX", "WEST TEXAS GAS, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1065, 
"EQUIT GAS", "EQUITABLE GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1066, 
"EQUIT POWR", "EQUITABLE POWER RESOURCES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1067, 
"WESTCST US", "WESTCOAST GAS SERVICES (USA), INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1068, 
"EQUIT STOR", "EQUITABLE STOR", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1069, 
"WESTRN STR", "WESTERN GAS RESOURCES STORAGE, INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1070, 
"WEST PWR", "WESTERN POWER SERVICES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1071, 
"WESTERN RESRC", "WESTERN RESOURCES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1072, "903", 
"QUASAR INTERNATIONAL PARTNERS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1073, "901", 
"QUANTUM PARTNERS INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1074, 
"WST RET EG", "WESTERN RETAIL ENERGY CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1075, 
"WESTLAKE", "WESTLAKE PETROCHEMICAL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1076, "907", 
"QUANTUM INDUSTRIAL HOLDINGS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1077, "902", 
"QUANTUM EMERGING GROWTH PARTNERS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1078, 
"WGR CANADA", "WGR CANADA INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1079, 
"QUANT CHEM", "QUANTUM CHEMICAL CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1080, 
"WHELABRATR", "WHEELABRATOR NORWALK ENERGY COMPANY INC.", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1081, 
"QST ENERGY", "QST ENERGY TRADING, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1082, 
"WICKFORD", "WICKFORD ENERGY MARKETING L.C.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1083, 
"PUGET", "PUGET SOUND ENERGY, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1084, 
"DOUGLAS PU", "PUBLIC UTILITY DISTRICT NO.1 OF DOUGLAS COUNTY", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1085, 
"ERI SER CD", "ERI SERVICES CANADA LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1086, 
"WILDHORSE", "WILDHORSE ENERGY PARTNERS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1087, 
"CHELAN", "PUBLIC UTILITY DISTRICT NO. 1 OF CHELAN COUNTY", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1088, "ERI", 
"ERI SERVICES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1089, 
"PUB SER NC", "PUBLIC SERVICE OF NORTH CAROLINA, INC. D/B/A/ PSNC ENERGY.", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1090, 
"ESCO MA", "ESCO (MASS) INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1091, 
"WILLIAMS", "WILLIAMS GAS MARKETING & TRADING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1092, 
"ESSO PET", "ESSO PETROLEUM CANADA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1093, 
"PSEG", "PUBLIC SERVICE ELECTRIC & GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1094, 
"EUGENE", "EUGEN WATER & ELECTRIC BOARD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1095, 
"PUB SER NW", "PUBLIC SERVICE COMPANY OF NEW MEXICO", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1096, 
"EXXON CHEM", "EXXON CHEMICAL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1097, 
"WISC POWER", "WISCONSIN POWER & LIGHT COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1098, 
"WISC PUBLI", "WISCONSIN PUBLIC SERVICE CORPORATION", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1099, 
"PUB SER CO", "PUBLIC SEVICE COMPANY OF COLORADO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1100, 
"PRUDENTIAL", "PRUDENTIAL INSURANCE CO. OF AMERICA", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1101, 
"PROLIANCE", "PROLIANCE ENERGY L.L.C.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1102, 
"PROGAS USA", "PROGAS USA, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1103, 
"PROGAS LTD", "PROGAS LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1104, 
"WASTE", "WMX TECHNOLOGIES L.L.C.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1105, 
"PROGAS ENT", "PROGAS ENTERPRISES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1106, 
"PROD PIPE", "PRODUCERS PIPELINES INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1107, 
"PROD MARK", "PRODUCERS MARKETING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1108, 
"PRO ENERGY", "PRODUCERS ENERGY MARKETING, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1109, 
"PRIOR ENER", "PRIOR ENERGY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1110, 
"WOODWARD", "WOODWARD MARKETING L.L.C.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1111, 
"PRINCETON", "PRINCETON NATURAL GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1112, 
"PRIMERO", "PRIMERO GAS MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1113, 
"PRIMA", "PRIMA OIL AND GAS CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1114, 
"WPS ENERGY", "WPS ENERGY SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1115, 
"PRI HSTN", "PRI INTERNATIONAL INC, HOUSTON", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1116, 
"WYOMING", "WYOMING REFINING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1117, 
"PRESTON", "PRESTON CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1118, 
"HARVARD", "PRESIDENT AND FELLOWS OF HARVARD COLLEGE", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1119, 
"XERON", "XERON, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1120, 
"PREMIER", "PREMIER GAS CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1121, 
"MULTI CAST", "PRECISION CASTINGS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1122, 
"FALCON", "FALCON GENEVA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1123, 
"PRAXAIR", "PRAXAIR, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1124, 
"FALCON MNG", "FALCON MANAGEMENT CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1125, 
"FALCON BR", "FALCONBRIDGE LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1126, 
"FALL RIVER", "FALL RIVER GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1127, 
"FED PL", "FEDERATED PIPE LINES LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1128, 
"FEDNAV SI", "FEDNAV INTERNATIONAL LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1129, 
"FINA PET", "FINA PETRO AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1130, "801", 
"UNIGESTION INTERNATIONAL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1131, 
"FINA SUP", "FINA SUPPLY LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1132, "803", 
"TOWER TRADING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1133, 
"FIRST GAS", "FIRST CRUDE - A DIVISION OF AMERADA HESS CORPORATION", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1134, 
"FST CHICGO", "BANK ONE, NATIONAL ASSOCIATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1135, 
"FIRST UNUM", "FIRST UNUM LIFE INSURANCE CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1136, 
"FLORID PWR", "FLORIDA POWER &LIGHT COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1137, 
"FLOR PWR C", "FLORIDA POWER CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1138, 
"TIDE WEST", "TIDE WEST OIL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1139, 
"THERMOGAS", "THERMOGAS, A DIVISION OF MAPCO INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1140, 
"WASH WATR2", "THE WASHINGTON WATER POWER COMPANY", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1141, 
"FORCENERGY", "FORCENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1142, "806", 
"THE TRUSTEES OF SPENCE SCHOOL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1143, 
"FORD MOTOR", "FORD MOTOR COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1144, 
"TENN VALLE", "THE TENNESSEE VALLEY AUTHORITY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1145, 
"FORD LOUIS", "FORD MOTOR COMPANY (LOUISVILLE ASSEMBLY PLANT)", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1146, 
"TENN EGY A", "THE TENNESSEE ENERGY ACQUISITION CORPORATION", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1147, 
"FORD TRUCK", "FORD MOTOR COMPANY ( TRUCK ASSEMBLY PLANT)", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1148, 
"STONE PETR", "THE STONE PETROLEUM CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1149, 
"NEWARK", "THE NEWARK GROUP, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1150, 
"FORD CAD", "FORD MOTOR COMPANY OF CANADA, LIMITED", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1151, 
"MONTANA", "THE MONTANA POWER TRADING AND MARKETING COMPANY", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1152, 
"FOREST", "FOREST OIL CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1153, 
"MERCHANT", "THE MERCHANT DIVISION OF COLORADO INTERSTATE GAS COMPANY", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1154, 
"FORMOSA", "FORMOSA PLASTICS CORPORATION, USA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1155, 
"MEDICAL", "THE MEDICAL CENTER CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1156, 
"ANSCHUTZ T", "FRED B. ANSCHUTZ TRUST", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1157, 
"EASTERN", "THE EASTERN GROUP, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1158, 
"EAST OHIO", "THE EAST OHIO GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1159, 
"FREEPORT M", "FREEPORT-MCMORAN RESOURCES PARTNERS LP", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1160, 
"CONSUMERS", "THE CONSUMERS'GAS COMPANY LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1161, 
"TEXLA EGY", "TEXLA ENERGY MANAGEMENT, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1162, 
"FRITO LAY", "FRITO LAY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1163, 
"FRONTR LLC", "FRONTIER ENERGY LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1164, 
"TEXAS OHIO", "TEXAS-OHIO GAS, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1165, 
"TX-NM PWR", "TEXAS-NEW MEXICO POWER COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1166, 
"FRONTIER", "FRONTIER OIL AND REFINING CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1167, 
"TUEG", "TEXAS UTILITIES ELECTRIC CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1168, 
"GALAXY ITA", "GALAXY ENERGY SRL ITALY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1169, 
"TEXACO INC", "TEXACO TERMINALS INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1170, 
"TEXACO LPG", 
"TEXACO NATURAL GAS LIQUIDS (A DIVISION OF TEXACO NATURAL GAS, INC.)", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1171, 
"TEX INC HN", "TEXACO INC., HOUSTON", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1172, 
"GALO GLASS", "GALLO GLASS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1173, 
"TERRA NTRO", "TERRA NITROGEN LIMITED PARTNERSHIP", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1174, 
"GAS PROD", "GAS PRODUCERS LIQUIDS, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1175, 
"TERRA", "TERRA INTERNATIONAL INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1176, 
"GATEWAY", "GATEWAY GATHERING & MARKETING CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1177, 
"TERRA LTD", "TERRA ENERGY LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1178, 
"TERRA CAPI", "TERRA CAPITAL, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1179, 
"GAZ METRO", "GAZ METROPOLITAN AND COMAPNY, LIMITED PARTNERSHIP", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1180, 
"GCRL MKT", "GCRL MARKETING LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1181, 
"GDK INC", "GDK INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1182, 
"GED ENERGY", 
"GED ENERGY SERVICES INC, A DIVISION OF HOWARD ENERGY MARKETING INC", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1183, 
"GEDI", "GED GAS SERVICES LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1184, 
"GELBERT", "GELBERT GROUP INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1185, 
"GEN ELECT", "GENERAL ELECTRIC CAPITAL CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1186, 
"GEN EL COM", "GENERAL ELECTRIC COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1187, 
"GEOGAS", "GEOGAS, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1188, 
"GGR RES", "GGR ENERGY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1189, 
"GIBSON PTR", "GIBSON PETROLEUM COMPANY LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1190, 
"GM HYDRO", "GM HYDROCARBONS, LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1191, "GPM", 
"GPM GAS SERVICES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1192, 
"GPU GENERA", "GPU GENERATION INC., AS AGENT FOR JERSEY CENTRAL POWER & LIGHT", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1193, 
"GPU SERVIC", "GPU SERVICE CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1194, 
"GRAND DAM", "GRAND RIVER DAM AUTHORITY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1195, 
"GRAND VAL", "GRAND VALLEY GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1196, 
"OMNI GRAPH", "GRAPHIC MANAGEMENT ASSOCIATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1197, 
"GLENCO", "GREAT LAKES ENERGY CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1198, 
"GREAT WEST", "GREAT WEST", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1199, 
"GREEN MT", "GREEN MOUNTAIN POWER CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1200, 
"GREENSBURG", "GREENSBURG ENERGY PARTNERS LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1201, 
"GREENWICH", "GREENWICH ENERGY PARTNERS LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1202, 
"GREERSTEEL", "GREER STEEL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1203, 
"GREYHOUND", "GREYHOUND LINES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1204, 
"HADSON CAD", "HADSON CANADA, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1205, 
"HALWOD CON", "HALLWOOD CONSOLIDATED RESOURCES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1206, 
"HALLWOOD", "HALLWOOD ENERGY PARTNERS LP C/O HALLWOOD ENERGY CORP.", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1207, 
"HARDEE POW", "HARDEE POWER PARTNERS LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1208, 
"HARDY O&G", "HARDY OIL AND GAS USA INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1209, 
"HEARTLAND", "HEARTLAND ENERGY SERVICES, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1210, 
"HELMERICH", "HELMERICH & PAYNE ENERGY SERVICES, INC", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1211, 
"HERMISTON", "HERMISTON GENERATING COMPANY, LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1212, 
"HESS SVCS", "HESS ENERGY SERVICES COMPANY, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1213, 
"HIGHLAND", "HIGHLAND ENERGY COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1214, 
"HMS FUEL", "HMS FUELS, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1215, 
"HOLLY SUGR", "HOLLY SUGAR CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1216, 
"HOPE GAS", "HOPE GAS INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1217, 
"HOPE (GE)", "HOPE GAS INC., AS AGENT FOR GENERAL ELECTRIC COMPANY", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1218, 
"HORTON", "HORTON HIGHWAY UTILITY DISTRICT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1219, 
"HOUST EXP", "HOUSTON EXPLORATION COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1220, 
"HOUSTN LP", "HOUSTON LIGHT AND POWER COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1221, 
"HOWARD EGY", "HOWARD ENERGY MARKETING LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1222, 
"HOWARD AVI", "HOWARD/AVISTA ENERGY LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1223, 
"HOWELL PET", "HOWELL CRUDE  OIL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1224, "HPL", 
"HPL RESOURCES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1225, 
"HS EGY SVC", "HS ENERGY SERVICES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1226, 
"HUGOTON", "HUGOTON ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1227, 
"HUNT PETRO", "HUNT PETROLEUM COPRORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1228, 
"HUNTSMAN", "HUNTSMAN CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1229, 
"HUSKY OIL", "HUSKY OIL OPERATIONS LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1230, 
"HYDRO QUEB", "HYDRO-QUEBEC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1231, 
"HYDRO PROC", "HYDROCARBON PROCESSING PARTNERS LTD", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1232, 
"IDAHO PWR", "IDAHO POWER COMPANY DBA IDACORP ENERGY", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1233, 
"IGI RESRCS", "IGI RESOURCES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1234, 
"ILLINOIS", "ILLINOIS POWER COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1235, 
"ILLINOVA", "ILLINOVA ENERGY PARTNERS, INC (IEPI)", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1236, 
"IMD-KOCH", "IMD STORAGE AND TRANSPORTATION AND ASSET MANAGEMENT COMPANY", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1237, 
"IMPER IRRI", "IMPERIAL IRRIGATION DISTRICT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1238, 
"IMPERIAL", "IMPERIAL OIL LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1239, 
"INDECK EGY", "INDECK ENERGY SERVICES, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1240, 
"INDECK O", "INDECK OSWEGO LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1241, 
"INDECK-COR", "INDECK-CORINTH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1242, 
"INDECK ILL", "INDECK-ILION, LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1243, 
"INESPAL SA", "INEPSAL METAL SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1244, 
"INLAND GAS", "INLAND GAS MARKETING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1245, 
"INLAND LTD", "INLAND PACIFIC ENERGY SERVICES LTD", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1246, 
"INLAND PAP", "INLAND PAPERBOARD & PACKAGING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1247, "IGS", 
"INNOVATIVE GAS SERVICES, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1248, 
"INTER GSC", "INTERCOAST GAS SERVICES, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1249, 
"INTERCOAST", "INTERCOAST TRADE & RESOURCES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1250, 
"INTER CORP", "INTERENERGY GAS SERVICES CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1251, 
"INTER RES", "INTERENERGY RESOURCES CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1252, 
"INTER SCAN", "INTERMARKET TRADING/SCANA ENERGY MARKETING INC", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1253, "IGC", 
"INTERMOUNTAIN GAS CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1254, 
"INTER COLN", "INTERNATIONAL COLIN ENERGY CORPORATION", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1255, 
"IPCO", "INTERNATIONAL PETROLEUM COMPANY LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1256, "ING", 
"INTERNATIONAL NEDERLANDEN (US) CAPITAL MARKETS, INC", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1257, 
"IPL PL", "INTERPROVINCIAL PIPE LINE INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1258, 
"INTERSTATE", "INTERSTATE GAS SUPPLY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1259, 
"INT POW", "INTERSTATE POWER COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1260, "IMD", 
"INVENTORY MANAGEMENT & DISTRIBUTION COMPANY LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1261, 
"IROQUOIS", "IROQUOIS GAS TRANSMISSION SYSTEM", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1262, 
"ISPAT MEX", "ISPAT MEXICNANA SA DE CV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1263, 
"JM HUBR CP", "JM HUBER CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1264, 
"JP OIL", "JP OIL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1265, 
"JAMES RIVER", "JAMES RIVER PAPER CO., INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1266, 
"JEFF SMURF", "JEFFERSON SMURFIT PLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1267, 
"JM PET", "JM PETROLEUM CORP, TEXAS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1268, 
"JN PETRO", "JN PETROLEUM MARKETING, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1269, 
"JOHNCARROL", "JOHN CAROLL UNIVERSITY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1270, 
"JORDAN", "JORDAN PETROLEUM LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1271, 
"JYSKEBANK", "JYSKE BANK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1272, 
"ONEOK EGY", "ONEOK ENERGY MARKETING AND TRADING COMPANY, LP.", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1273, 
"K2ENERGY", "K2 ENERGY CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1274, 
"KAISER", "KAISER-FRANCIS OIL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1275, 
"KAMINO", 
"KCS ENERGY MANAGEMENT SERVICES INC, (AGENT FOR KAMINE BESICORP CARTHIDGE)", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1276, 
"KELLEY OIL", "KELLEY OIL & GAS CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1277, 
"KENTUCKY U", "KENTUCKY UTILITIES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1278, 
"KERRMCGE", "KERR MCGEE REFINING CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1279, 
"KERR CHEM", "KERR-MCGEE CHEMICAL CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1280, 
"KERR COAL", "KERR-MCGEE COAL CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1281, 
"KERR NGAS", "KERR-MCGEE NATURAL GAS INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1282, 
"KEYSPAN ES", "KEYSPAN ENERGY SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1283, 
"KEYSTONE", "KEYSTONE RUSTPROOFING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1284, 
"KG LN", "KG INTERNATIONAL PETROLEUM LTD, LONDON", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1285, 
"KIDDER", "KIDDER PEABODY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1286, 
"KIMBAL EGY", "KIMBALL ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1287, 
"KIMBALL RE", "KIMBALL RESOURCES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1288, 
"KIMBALTRIP", "KIMBALL TRIPPE ENERGY ASSOCIATES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1289, 
"KING RANCH", "KING RANCH OIL AND GAS, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1290, 
"KLM AIR", "KLM ROYAL DUTCH AIRLINES (AMS/DX)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1291, 
"KN GAS MKT", "KN GAS MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1292, 
"KN MKT", "KN MARKETING, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1293, 
"KN TRADING", "KN TRADING, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1294, 
"KOCH GAS", "KOCH ENERGY TRADING, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1295, 
"KOCH POWER", "KOCH ENERGY TRADING, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1296, 
"KOCH F", "KOCH FUELS INCORPORATED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1297, 
"KOCH CAD", "KOCH ENERGY TRADING CANADA LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1298, 
"KOCH GPC", "KOCH GATEWAY PIPELINE COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1299, 
"KOCH HYDRO", "KOCH HYDROCARBON COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1300, 
"KOCH OIL", "KOCH OIL COMPANY LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1301, 
"KOCH INTL", "KOCH REFINING INT'L OIL CO., A DIVISION OF KOCH FUELS INC", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1302, 
"KOCH RM", "KOCH REFINING MARKETING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1303, 
"KOCH SP LT", "KOCH SUPPLY AND TRADING COMPANY, LONDON", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1304, 
"RAINBOW", "RAINBOW GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1305, 
"KUW PET IT", "KUWAIT PETROLEUM ITALIA SPA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1306, 
"XXXXX", "RAINBOW PIPE LINE COMPANY, LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1307, 
"RANCH", "RANCHMEN'S RESOURES LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1308, 
"LAKESIDE", "LAKESIDE OIL CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1309, 
"LANTERN", "LANTERN PETROLEUM CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1310, 
"LEDCO TX", "LEDCO INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1311, 
"REDWOOD", "REDWOOD RESOURCES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1312, 
"REFINER NO", "REFINERIA DEL NORTE S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1313, 
"RELIANT RE", "RELIANT ENERGY RESOURCES CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1314, 
"LEVEL EGY", "LEVEL ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1315, 
"LEXAS OIL", "LEXAS OIL LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1316, 
"RELIANT SV", "RELIANT ENERGY SERVICES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1317, 
"LGE EGYMKT", "LG&E ENERGY MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1318, 
"RENAISSNCE", "RENAISSANCE ENERGY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1319, 
"LIQUID EGY", "LIQUID ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1320, 
"LL&E PM", "LL&E PETROLEUM MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1321, 
"RE ENGY ST", "REPUBLIC ENGINEERED STEEL INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1322, 
"LL&E PETRO", "LL&E PETROLEUM RESOURCES MARKETING LP", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1323, 
"RES EGY SV", "RESOURCE ENERGY SERVICES COMPANY, LLC", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1324, 
"REXENE", "REXENE CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1325, 
"REYNOLDS M", "REYNOLDS METALS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1326, 
"RICHARDSON", "RICHARDSON PRODUCTS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1327, 
"RIGEL", "RIGEL OIL & GAS LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1328, 
"RILEY NAT", "RILEY NATURAL GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1329, 
"RIO ALTO", "RIO ALTO EXPLORATION LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1330, 
"NATL EGY", "NATIONAL ENERGY & TRADE, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1331, 
"LA WATER", "LOS ANGELES DEPARTMENT OF WATER AND POWER", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1332, 
"ROCH GAS", "ROCHESTER GAS AND ELECTRIC CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1333, 
"ROYALE EGY", "ROYALE ENERGY INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1334, 
"RUSSELL", "RUSSELL STANDARD CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1335, 
"SABINE HUB", "SABINE HUB SERVICES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1336, 
"ALBRTA HJV", 
"SABINE HUB SERVICES, A DIVISION OF TEXACO CANADA PETROLEUM INC., AS AGENT FOR", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1337, 
"SMUD", "SACREMENTO MUNICIPAL UTILITY DISTRICT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1338, 
"SALT RIVER", "SALT RIVER PROJECT AGRICULTURAL IMPROVEMENT AND POWER DISTRICT", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1339, 
"SAMEDAN", "SAMEDAN OIL CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1340, 
"SAN DIEGO", "SAN DIEGO GAS AND ELECTRIC COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1341, 
"SAN JUAQ", "SAN JOAQUIN COGEN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1342, 
"SAN-OBRIEN", "SANCHEZ-O'BRIEN OIL & GAS CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1343, 
"DREYFUS AT", "LOUIS DREYFUS ENERGY CORP ATLANTA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1344, 
"SANDIA", "SANDIA ENERGY RESOURCES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1345, 
"DREYFUS", "LOUIS DREYFUS ENERGY CORP CT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1346, 
"DREYFUS NG", "LOUIS DREYFUS NATURAL GAS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1347, 
"SANTA INT", "SANTA FE INTERNATIONAL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1348, 
"LOUIS GM", "LOUISIANA GAS MARKETING, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1349, 
"LOUIS LAND", "LOUISIANA LAND & EXPLORATION COMPANY", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1350, 
"SANTA MIN", "SANTA FE MINERALS INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1351, 
"LOUIS NGAS", "LOUISIANA NAT GAS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1352, 
"SARATOGA", "SARATOGA-BROKER", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1353, "LRC", 
"LOUISIANA RESOURCE COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1354, 
"SASK ENGY", "SASKENERGY, INCORPORATED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1355, 
"LOUISVILLE", "LOUISVILLE GAS & ELECTRIC CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1356, 
"COLORADO", "LOWER COLORADO RIVER AUTHORITY (LCRA)", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1357, 
"SCANA ENER", "SCANA ENERGY MARKETING, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1358, 
"LS POWER C", "LS POWER COTTAGE GROVE LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1359, 
"LS POWER W", "LS POWER WHITEWATER LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1360, 
"LTV STEEL", "LTV STEEL COMPANY, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1361, 
"SCANA HYDO", "SCANA HYDROCARBONS INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1362, 
"SCEPTRE R", "SCEPTRE RESOURCES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1363, 
"SEA-3", "SEA-3 ,INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1364, 
"LYON CITGO", "LYONDELL-CITGO REFINING CO LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1365, 
"SEAGULL MS", "SEAGULL MARKETING SERVICES, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1366, 
"MABANAFT", "MABANAFT INTERNATIONAL GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1367, 
"SEATTLE CL", "SEATTLE CITY LIGHT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1368, "99", 
"MAGAR KULKERESKDELMI BANK RT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1369, 
"MAPCO NAT", "MAPCO NATURAL GAS LIQUIDS INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1370, 
"SECONDCR", "SECOND CRUDE CORP - A DIVISION OF AMERADA HESS CORPORATION", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1371, 
"MKT RESPON", "MARKET RESPONSIVE ENERGY, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1372, 
"SELKIRK", "SELKIRK COGEN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1373, 
"MARK WEST", "MARKWEST HYDROCARBON INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1374, 
"SEMCO GAS", "SEMCO ENERGY GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1375, 
"MARQUEST", "MARQUEST LIMITED PARTNERSHIP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1376, 
"SEMCO EGY", "SEMCO ENERGY SERVICES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1377, 
"SEMPRA SOL", "SEMPRA ENERGY SOLUTIONS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1378, 
"SEMPRA CAN", "SEMPRA ENERGY TRADING (CANADA) LIMITED", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1379, 
"AVALANCHE", "SEMPRA ENERGY TRADING SERVICES CORP.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1380, 
"MARTIN GAS", "MARTIN GAS SALES, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1381, 
"SENECA POW", "SENECA POWER PARTNERS, L.P.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1382, 
"MARTIN OIL", "MARTIN OIL MARKETING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1383, 
"SENECA TX", "SENECA RESOURCES CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1384, 
"MASS MUNI", "MASSACHUSETTS MUNICIPAL WHOLESALE ELECTRIC COMPANY", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1385, 
"MASSPOWER", "MASSPOWER", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1386, 
"SERENPET", "SERENPET INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1387, 
"MAXUS GAS", "MAXUS GAS MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1388, "101", 
"SFF ASSOCIATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1389, 
"MBFFX", "MBF FX CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1390, 
"MCMURRAY", "MCMURRY OIL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1391, 
"SHELL DEN", "SHELL DENMARK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1392, 
"MCNIC", "MCNIC OIL & GAS PROPERTIES, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1393, 
"SHELL SWED", "SHELL SWEDEN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1394, 
"MELAMPY", "MELAMPY MANUFACTURES CO INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1395, 
"MEMPHIS", "MEMPHIS LIGHT GAS AND WATER DIVISION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1396, 
"MEGA", "MERCHANT ENERGY GROUP OF THE AMERICAS, INC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1397, 
"SHELL WEST", "SHELL WESTERN E & P INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1398, 
"SHERRITT", "SHERRITT INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1399, 
"SIERRA", "SIERRA PACIFIC POWER COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1400, 
"SIGCORP", "SIGCORP ENERGY SERVICES,  INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1401, 
"SIMPLOT CD", "SIMPLOT CANADA LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1402, 
"SINOCHM LN", "SINOCHEM INTERNATIONAL OIL COMPANY LTD.", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1403, 
"SINOCHM HK", "SINOCHEM PETROLEUM, HONG KONG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1404, 
"SNOHOMISH", "SNOHOMISH COUNTY PUBLIC UTILITY DISTRICT", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1405, 
"METHANEX", "METHANEX CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1406, 
"SNYDER GM", "SNYDER GAS MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1407, 
"METMEX", "ET-MEX PENOLES, SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1408, 
"MICH CONS", "MICHIGAN CONSOLIDATED GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1409, 
"SNYDER", "SNYDER OIL CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1410, 
"MIGAS", "MICHIGAN GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1411, 
"MIDAMERICA", "MID AMERICAN ENERGY CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1412, 
"SONAT", "EL PASO MERCHANT ENERGY - GAS, LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1413, 
"MID CON", "MID CONTINENT MARKETING CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1414, 
"SONAT PWR", "SONAT POWER MARKETING LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1415, 
"MIDCON MKT", "MIDCON GAS MARKETING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1416, 
"MIDCON GAS", "MIDCON GAS SERVICES CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1417, 
"S CAROL PL", "SOUTH CAROLINA PIPELINE CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1418, 
"MIDCON PWR", "MIDCON POWER SERVICES CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1419, 
"SO JERSEY", "SOUTH JERSEY GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1420, 
"MIDCON TX", "MIDCON TEXAS GAS SERVICES CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1421, "MCV", 
"MIDLAND COGENERATION VENTURE LIMITED PARTNERSHIP", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1422, 
"S JERSEY", "SOUTH JERSEY RESOURCES GROUP LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1423, 
"MIDLND PC", "MIDLAND CRUDE OIL PURCHASING CORPORATION", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1424, 
"SO-CAL ED", "SOUTHERN CALIFORNIA EDISON, CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1425, 
"MIDLND MKT", "MIDLAND MARKETING CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1426, 
"MIDLAND", "MIDLAND PETROLEUM INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1427, 
"SO-CAL GAS", "SOUTHERN CALIFORNIA GAS, CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1428, 
"MILFORD", "MILFORD POWER LIMITED PARTNERSHIP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1429, 
"SOCAL WATER", "SOUTHERN CALIFORNIA WATER COMPANY", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1430, 
"MILL INORG", "MILLENIUM INORGANIC CHEMICALS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1431, 
"MILLENIUM", "MILLENIUM PARTNERS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1432, 
"SOCO EGMKT", "SOUTHERN COMPANY ENERGY MARKETING, L.P.", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1433, 
"MINNEGASCO", "MINNEGASCO, A DIVISION OF NORAM INDUSTRIES", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1434, 
"SOUTH CT", "SOUTHERN CONNECTICUT GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1435, 
"MISSPPI VG", "MISSISSIPPI VALLEY GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1436, 
"MISSOURI", "MISSOURI GAS ENERGY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1437, 
"MITCHELL", "MITCHELL ENERGY & DEVELOPMENT CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1438, 
"SO IND GAS", "SOUTHERN INDIANA GAS & ELECTRIC COMPANY", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1439, 
"MITCHL GAS", "MITCHELL GAS SERVICES LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1440, 
"SO MARYLND", "SOUTHERN MARYLAND OIL CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1441, 
"MITCH MKT", "MITCHELL MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1442, 
"SOUTHRN UN", "SOUTHERN UNION CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1443, 
"MITSUB TOK", "MITSUBISHI CORP TOKYO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1444, 
"MITSUB FIN", "MITSUBISHIFINANCE INTERNATIONAL PLC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1445, 
"SOUTH GAS", "SOUTHWEST GAS CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1446, 
"MITSUB LN", "MITSUBISHI UK LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1447, 
"MITSUI LN", "MITSUI UK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1448, 
"SW  EGY SVC", "SOUTHWESTERN ENERGY SERVICES CO.,", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1449, 
"MOBIL NGAS", "MOBIL NATURAL GAS INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1450, 
"SW PUB SER", "SOUTHWESTERN PUBLIC SERVICE COMPANY", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1451, 
"MOBIL CAD", "MOBIL OIL CANADA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1452, 
"SPRING RES", "SPRING RESOURCES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1453, 
"ST CLR FEE", "ST. CLAIR LTD FEE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1454, 
"STALWART E", "STALWART ENERGY COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1455, 
"STAMPEDER", "STAMPEDER ENERGY (A DIVISION OF STAMPEDER EXPLORATION LTD.)", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1456, 
"STAND EGY", "STAND ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1457, 
"STATOIL DM", "STATOIL DENMARK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1458, 
"STATOIL EG", "STATOIL ENERGY TRADING, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1459, "807", 
"STEELER FUND, LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1460, 
"SITHE/STER", "STERLING POWER PARTNERS L.P.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1461, 
"ELF UK", "ELF UK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1462, 
"STONE CNTR", "STONE CONTAINER CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1463, 
"STONE EGY", "STONE ENERGY CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1464, 
"STRIKE EGY", "STRIKE ENERGY, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1465, 
"SUBURBAN", "SUBURBAN PROPANE, L.P.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1466, 
"SUNCOR INC", "SUNCOR ENERGY INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1467, 
"SUNKYONG", "SUNKYONG AMERICA INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1468, 
"SUPERIOR", "SUPERIOR NATURAL GAS CORP.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1469, "805", 
"SWAT FUND, LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1470, 
"MOBIL T", "MOBIL TADING BV - EUROPE BRANCH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1471, 
"MOCK EGY", "MOCK ENERGY SERVICES, LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1472, 
"SWIFT EGY", "SWIFT ENERGY COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1473, 
"MODESTO ID", "MODESTO IRRIGATION DISTRICT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1474, 
"MORGAN HYD", "MORGAN HYDROCARBONS INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1475, 
"SWISS BANK", "SWISS BANK CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1476, 
"MORRISON", "MORRISON PETROLEUMS LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1477, 
"MOUNT FRNT", "MOUNTAIN FRONT PIPELINE CO INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1478, 
"MUNIGAS GA", "MUNICIPAL GAS AUTHORITY OF GEORGIA", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1479, 
"TAMCO STEEL", "TAMCO STEEL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1480, 
"MURCO", "MURCO PETROLEUM LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1481, 
"TARPON", "TARPON GAS MARKETING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1482, 
"TARRAGON", "TARRAGON OIL AND GAS LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1483, 
"MURPHY", 
"MURPHY OIL USA INC AS AGENT FOR MURPHY EXPLORATION & PRODUCTION COMPANY", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1484, 
"TARTAN ER", "TARTAN ENERGY RESOURCES, L.P.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1485, 
"MUSTANG FL", "MUSTANG FUEL CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1486, 
"TAURUS EXP", "TAURUS EXPLORATION, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1487, 
"TRUST CO", "TCW ASSET MANAGEMENT CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1488, 
"TECO", "TECO GAS MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1489, 
"NABISCO", "NABISCO, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1490, 
"NAT WEST", "NAT WEST CAPITAL MARKETS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1491, 
"TEJAS MKTG", "TEJAS GAS MARKETING LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1492, 
"NAT GAS IN", "NATGAS CANADA INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1493, 
"NATFUEL GD", "NATIONAL FUEL GAS DISTRIBUTION CORPORATION", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1494, 
"TEJAS GAS", "TEJAS GAS OPERATING, LLC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1495, 
"NATFUEL MK", "NATIONAL FUEL MARKETING CO LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1496, 
"TENASK CAD", 
"TENASKA MARKETING CANADA, A DIVISION OF TENASKA MARKETING VENTURES CORP.", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1497, 
"NAT FUEL", "NATIONAL FUEL RESOURCES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1498, 
"NAT PIPE", "NATURAL GAS PIPELINE CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1499, 
"TENASKA", "TENESKA MARKETING VENTURES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1500, 
"NAT GAS TS", "NATURAL GAS TRANSMISSION SERVICES INC", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1501, 
"TENCO GAS", "TENNECO GAS TRADING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1502, 
"NAT RES GP", "NATURAL RESOURCES GROUP, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1503, 
"NAV LLC", "NAV LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1504, 
"TENNECO", "TENNECO OIL COMPANY PM", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1505, 
"NAVIGATOR", "NAVIGATOR FUND LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1506, 
"NAV GLOBAL", "NAVIGATOR GLOBAL FUND LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1507, 
"TENNESSEE", "TENNESSEE GAS PIPELINE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1508, 
"NBB ENERGY", "NBB ENERGY PARTNERS LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1509, 
"GIBSON-BRK", "EA GIBSON SHIPBROKERS LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1510, 
"MID-MICH", "MID-MICHIGAN STORAGE COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1511, 
"NESI", "NESI ENERGY MARKETINGLLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1512, 
"NEVADA POW", "NEVADA POWER COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1513, 
"NEW ENGLAN", "NEW ENGLAND POWER COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1514, 
"NJ ENERGY", "NEW JERSEY NATURAL ENERGY CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1515, 
"NJ NATURAL", "NEW JERSEY NATURAL GAS CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1516, 
"NYS ELEC", "NEW YORK STATE ELECTRIC & GAS CORPORATION", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1517, 
"NEWFIELD", "NEWFIELD EXPLORATION COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1518, 
"NGC OIL", "NGC OIL TRADING &TRANSPORTATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1519, 
"NGC OIL CD", "NGC OIL TRADING AND TRANSPORTATION CANADA", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1520, 
"NGE GENERA", "NGE GENERATION, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1521, 
"NGL SUPPLY", "NGL SUPPLY, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1522, 
"NGTS LLC", "NGTS LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1523, 
"IMTT", "INTERNATIONAL MATEX TANK TERMINALS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1524, 
"PLUM EGMKT", "NIAGARA MOHAWK ENERGY MARKETING, INC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1525, 
"PLUM ENTER", "NIAGARA MOHAWK ENERGY , INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1526, 
"NIAGARA", "NIAGARA MOHAWK POWER CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1527, 
"NIPPON GAS", "NIPPON OIL AND GAS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1528, 
"NIPSCO TR", "NIPSCO ENERGY TRADING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1529, 
"NJR ENERGY", "NJR ENERGY COPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1530, 
"NJR EGY SV", "NJR ENERGY SERVICES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1531, "802", 
"NO MARGIN FUND LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1532, 
"NOBLE", "NOBLE AFFILIATES & SAMEDAN OIL CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1533, 
"NOBLE GAS", "NOBLE GAS MARKETING, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1534, 
"NOBLE TRAD", "NOBLE TRADING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1535, 
"NORCEN EGY", "NORCEN ENERGY RESOURCES LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1536, 
"NORCEN EXP", "NORCEN EXPLORER, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1537, 
"NORCEN OPL", "NORCEN OFFSHORE  PROPERTIES LTD CO", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1538, 
"NORSTAR", "NORSTAR ENERGY LIMITED PARTNERSHIP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1539, 
"NORTECH", "NORTECH ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1540, 
"N AMERICAN", "NORTH AMERICAN ENERGY LIFE ASSURANCE", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1541, 
"NORTH AMER", "NORTH AMERICAN RESOURCES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1542, 
"NORTH CAR", "NORTH CAROLINA NATURAL GAS CORPORATION", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1543, 
"NORTH STAR", "NORTH STAR STEEL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1544, 
"N STAR ST", "NORTH STAR STEEL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1545, 
"NORTHEAS", "NORTHEAST PETROLEUM, A DIVISION OF CARGILL", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1546, 
"NORTHEASTU", "NORTHEAST UTILITIES SERVICE COMPANY", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1547, 
"NIPSCO", "NORTHERN INDIANA PUBLIC SERVICE COMPANY", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1548, 
"NORTH NAT", "NORTHERN NATURAL GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1549, 
"NSP MINNOS", "NORTHERN STATES POWER COMPANY, MINNESOTA CORPORATION", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1550, 
"NORTH SPC", "NORTHERN STATES POWER COMPANY, WISCONSIN CORPORATION", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1551, 
"NO VA ELEC", "NORTHERN VIRGINIA ELECTRIC COOPERATIVE", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1552, 
"NORTHLAND", "NORTHLAND POWER PARTNERSHIP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1553, 
"NORTHSTAR", "NORTHSTAR ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1554, 
"NORTHW NGS", "NORTHWEST NATURAL GAS CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1555, 
"NOR PAC EM", "NORTHWEST PACIFIC ENERGY MARKETING INC", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1556, 
"NOVA CHEM", "NOVA CHEMICALS (CANADA) LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1557, 
"NOVA SCOTA", "NOVA SCOTIA RESOURCES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1558, 
"NOVA GAS", "NOVAGAS CLEARINGHOUSE LIMITED PARTNERSHIP", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1559, 
"NOVERGAZ", "NOVERGAZ INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1560, 
"NP ENERGY", "NP ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1561, 
"NUI CORP", "NUI CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1562, 
"NUI EGY BR", "NUI ENERGY BROKERS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1563, 
"NUMAC ENGY", "NUMAC ENERGY, A PARTNERSHIP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1564, 
"OCELOT", "OCELOT ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1565, 
"OGE RES IN", "OGE ENERGY RESOURCES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1566, 
"OH EDISON", "OHIO EDISON COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1567, 
"OIL REF", "OIL REFINERIES LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1568, 
"OIL SEARCH", "OIL SEARCH LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1569, 
"OK PET", "OK PETROLEUM AB", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1570, 
"OMERS", "OMERS RESOURCES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1571, 
"ONEOK EII", "ONEOK ENERGY MARKETING AND TRADING COMPANY II", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1572, 
"OPTRACO BV", "OPTRACO BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1573, 
"ORANGE UTL", "ORANGE & ROCKLAND UTILITIES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1574, 
"ORMET", "ORMET PRIMARY ALUMINUM CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1575, 
"ORTELIUS", "ORTELIUS LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1576, 
"ORYX LN", "ORYX ENERGY UK LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1577, 
"OWENS CORN", "OWENS CORNING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1578, 
"PN PARTNER", "P&N PARTNERS LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1579, 
"PACFIC INT", "PACIFIC INTERSTATE TRANSMISSION COMPANY", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1580, 
"PACIFICORP", "PACIFICORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1581, 
"PACIF PWR", "PACIFICORP POWER MARKETING, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1582, 
"PACKERLAND", "PACKERLAND ENERGY SERVICES, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1583, 
"PAINE WEBR", "PAINE WEBBER BROKERAGE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1584, 
"PALAMUNDO", "PALAMUNDO LDC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1585, 
"PAN-ALBRTA", "PAN ALBERTA GAS LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1586, 
"PAN ALB US", "PAN-ALBERTA GAS (US) INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1587, 
"PAN CAN ES", "PANCANADIAN ENERGY SERVICES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1588, 
"PANCAN", "PANCANADIAN PETROLEUM LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1589, 
"PANDA", "PANDA - BRANDYWINE LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1590, 
"PARKER P", "PARKER & PARSLEY PETROLEUM USA INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1591, 
"PAWTUCKET", "PAWTUCKET POWER ASSOCIATES LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1592, 
"PBS COALS", "PBS COALS INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1593, 
"PCS NITRO", "PCS NITROGEN FERTILIZER, LP FORMERLY ARCADIAN FERTILIZER LP", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1594, 
"PECO", "PECO ENERGY COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1595, 
"PECO GAS", "PECO GAS SUPPLY COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1596, 
"PEGASUS", "PEGASUS GOLD CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1597, 
"C`NDA OCTL", "CANADIAN OCCIDENTAL PETROLEUM LTD.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1598, 
"C`NDA PAFC", "CANADIAN PACIFIC FORESTS PRODUCTS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1599, 
"N`AMER ENE", "NORTH AMERICAN ENERGY CONSERVATION, INC", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1600, 
"N`TH CANCO", "NORTH CANADIAN MARKETING CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1601, 
"N`TH CANDA", "NORTH CANADIAN OILS LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1602, 
"O`BRIEN PA", "O`BRIEN (PARLIN) COGENERATION, INC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1603, 
"O`BRIEN NE", "O`BRIEN (NEWARK) COGENERATION, INC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1604, 
"P`CANADA", "PETRO-CANADA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1605, 
"P`CAN HYD", "PETRO-CANADA HYDROCARBONS INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1606, 
"P`DIA HK", "PETRODIAMOND INC (HONG KONG)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1607, 
"P`DIA IRV", "PETRODIAMOND INC (IRVINE)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1608, 
"P`DIA NY", "PETRO-DIAMOND INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1609, 
"P`FINA DE", "PETROFINA DELAWARE INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1610, 
"CARGIL-GERMNY", "DEUTSCHE CARGILL GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1611, 
"INHOUSE MARKT", "INHOUSE MARKT", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1612, 
"ALLEGHENY", "ALLEGHENY INTERNATIONAL DEVLEOPMENT INC", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1613, 
"MASONITE", "MASONITE CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1614, 
"UNITED FUE", "UNITED FUEL INTERNATIONAL", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1615, 
"STARSUPROT", "STARSUPPLY PETROLEUM EUROPE BV", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1616, 
"GEORGIA N", "SOUTHSTAR ENERGY SERVICES LLC DBA GEORGIA NATURAL GAS SERVICES", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1617, 
"SITHE POWE", "SITHE POWER MARKETING LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1618, 
"ALGOMA", "ALGOMA STEEL INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1619, 
"WESTERN GAS", "WESTERN GAS RESOURCES INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1620, 
"GARMATORIA", "GESTIONE ARMATORIALI SPA", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1621, 
"KASOSSHIP", "KASOS SHIPPING LTD", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1622, 
"AMEREXPOW", "AMEREX POWER", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1623, 
"GFI LDN", "GFI LTD (LONDON)", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1624, 
"EXCO", "EXCO (INTERCAP) BROKERAGE", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1625, 
"STARPETNJ", "STARSUPPLY PETROLEUM INC NJ", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1626, 
"STARSUPBER", "STARSUPPKY PETROLEUM FEEDSTOCKS INC BERMUDA", "A", "BROKER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1627, 
"STARDINTL", "STARDUST INTL PRODUCT LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1628, 
"TCT NATGAS", "TCT NATURAL GAS BROKER", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1629, 
"TCT CRUDE", "TCT CRUDE", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1630, 
"TFS BRKR", "TRADITION FS INC NY", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1631, 
"UNITEDCRUD", "UNITED CRUDE INC", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1632, 
"UNITEDPOWE", "UNITED POWER INC", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1633, 
"CITATION C", "CITATION  CRUDE MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1634, 
"BRK-RAFF", "RAFFERTY ASSOCIATES", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1635, 
"STAR NAT", "STAR NATURAL GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1636, 
"SET LTD", "SEMPRA ENERGY EUROPE LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1637, 
"CONT RES", "CONTINENTAL RESOURCES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1638, 
"SET EUROPE", "SET EUROPE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1639, 
"BG INTL", "BG INTERNATIONAL LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1640, 
"CHOCTAW", "CHOCTAW II OIL & GAS LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1641, 
"DYNEGY POW", "DYNEGY POWER MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1642, 
"KOCHREFI", "KOCH REFINING INTERNATIONAL PTE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1643, 
"OIL CHART", "OIL CHART INTERNATIONAL NV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1644, 
"FAMMROTT", "FUEL AND MARINE MARKETING BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1645, 
"METROSHIP", "METROPOLITAN WORLD MARITIME CORP", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1646, 
"LBH GROUP", "LBH SHIPPPING ROTTERDAM NETHERLANDS BV", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1647, 
"ARGENTLDN", "ARGENT SHIPPING LIMITED", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1648, 
"SD CTY", "THE CITY OF SAN DIEGO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1649, 
"MARUBENIUS", "MARUBENI INTERNATIONAL PETROLEUM CO (USA)", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1650, 
"ECOAST NAT", "EAST COAST NATURAL GAS COOPERATIVE LLC", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1651, 
"N-KOCH", "KOCH (MERC MATCH UP)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1652, 
"N-BP", "BP (MERC MATCH UP)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1653, 
"FRANCE FIN", "FRANCE FINANCIAL CONSULTING", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1654, 
"PDV MIDWEST", "PEDAVESA MIDWEST REFINING L.L.C.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1655, 
"WILLIS COR", "WILLIS CORROON", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1656, 
"LACLEDE", "LACLEDE GAS COMPANY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1657, 
"KARLSHAMN", "KARLSHAMN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1658, 
"MALMO", "MALMO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1659, 
"UNIPEC", "CHINA INTERNATIONAL UNITED PETROLEUM AND CHEMICALS CO, LTD", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1660, 
"ATLANTIC SC", "ATLANTIC SCHEPEN EXPLOITATIE MAATSCHAPPIJ BV", "A", "SHIPOWNE", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1661, 
"CARLBOM", "CARLBOM SHIPPPING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1662, 
"PETRAKNV", "PETRAK DIVISION OF CORE LABORATORIES NV", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1663, 
"NAVITANK", "NAVITANK AB", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1664, 
"NEPTUN", "NEPTUN SCHIFFAHRTS-AGENTUR GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1665, 
"NOVOSHIP", "NOVOROSSIYSK SHIPPPING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1666, 
"MARITRANS", "MARITRANS OPERATING PARTNERS LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1667, 
"OW BUNKER", "OW BUNKER BALTIC A/S", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1668, 
"ITS PORT", "CALEB BRETT PORTUGAL, LDA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1669, 
"SAYBANTW", "SAYBOLT BELGIUM NV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1670, 
"SAYBCURA", "SAYBOLT CURACAO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1671, 
"KASCO SEOU", "KOREAN ADJUSTERS AND SURVEYORS COPORATION", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1672, 
"APACHE CRU", "APACHE CRUDE MARKETING, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1673, 
"LUNDQUIST", "LUNDQUIST SHIPPING COMPANY LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1674, 
"FAMMUSA", "FUEL AND MARINE MARKETING LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1675, 
"N-CHASE", "N-CHASE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1676, 
"CHINA AVIA", "CHINA AVIATION OIL (SINGAPORE) PTE LTD", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1677, 
"EASTWIND", "EASTWIND MARITIME SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1678, 
"GALAXY", "GALAXY ENERGY PACIFIC LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1679, 
"EURONAV", "EURONAV LUXEMBOURG SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1680, 
"GLOBAL ES", "GLOBAL COMPANIES, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1681, 
"ANDROSCOGG", "ANDROSCOGGIN ENERGY LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1682, 
"INSP-MADRID", "INSPECTORATE ESPANOLA, SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1683, 
"SOUTHLAND", "SOUTHLAND OIL COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1684, 
"EUROPEAN  E", "EUROPEAN ENERGY SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1685, 
"LOUIS PLAS", "LOUIS DREYFUS PLASTICS CORPORATION", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1686, 
"VEAG", "VEREINIGTE ENERGIEWERKE AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1687, 
"ITOCHU UK", "ITOCHU PETROLEUM CO (UK) LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1688, 
"AQUILA LTD", "AQUILA ENERGY LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1689, 
"NCPA", "NORTHERN CALIFORNIA POWER AGENCY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1690, 
"SELECT EGY", "SELECT ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1691, 
"ADM IVEST", "ADM INVESTOR SERVICES INTERNATIONAL LIMITED", "A", "FLRBRKR", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1692, 
"CARGILL LN", "CARGILL INVESTOR SERVICES LTD", "A", "EXCHBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1693, 
"CITY OF VI", "CITY OF VINELAND ELECTRIC UTILITY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1694, 
"SAMSON INV", "SAMSON INVESTMENT COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1695, 
"LONMETOFF", "LONDON METEOROLOGICAL OFFICE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1696, 
"NRG ENERGY", "NRG ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1697, 
"W WINDSOR", "WEST WINDSOR POWER", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1698, 
"ADAMS RES", "ADAMS RESOURCES MARKETING, LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1699, 
"CHINA ENGY", "CHINA AVIATION ENERGY SINGAPORE PTE LTD", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1700, 
"BP MARINE", "BP MARINE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1701, 
"SANTRON", "SANTRON LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1702, 
"WATFORD", "WATFORD PETROLEUM LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1703, 
"HIN LEONG", "HIN LEONG TRADING PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1704, 
"PARKLAND", "PARKLAND ALFALFA PRODUCTS LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1705, 
"ICON NAV", "ICON NAVIGATION CORPORATION C/O HANSEATIC SHIPPING CO LTD", "A", 
"SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1706, 
"MITSUI OIL", "MITSUI AND CO LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1707, 
"POTASH COR", "POTASH CORPORATION OF SASKATCHEWAN INC", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1708, 
"PIED EGY C", "SOUTHSTAR ENERGY SERVICES LLC DBA PIEDMONT ENERGY CO", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1709, 
"CERESHELLE", "CERES HELLENIC ENTERPRISE LTD", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1710, 
"SOUND SHIP", "SOUND SHIPPING AB", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1711, 
"SWEDIA", "SWEDIA REDERI AB", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1712, 
"THEODORA", "THEODORA TANKERS- REDERIJ THEODORA BV", "A", "SHIPOWNE", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1713, 
"EURODEKCOP", "EURODEK COPEHNAGEN A/S", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1714, 
"EURODEKROT", "EURODEK TRADING SERVICES BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1715, 
"ATEL", "AARE-TESSIN LTD FOR ELECTRICTY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1716, 
"WSCC", "WESTERN SYSTEMS COORDINATING COUNCIL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1717, 
"TRANSALTA", "TRANSALTA ENERGY COPRORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1718, 
"DOFASCO", "DOFASCO INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1719, 
"VOBOTLEK2005", "VOBOTLEK2005", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1720, 
"CIGNA", "CIGNA PROPERTY & CASUALTY INSURANCE COMPANY", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1721, 
"OCEAN ENGY", "OCEAN ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1722, 
"ST LAWRENC", "ST. LAWRENCE GAS COMPANY, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1723, 
"GP FLAKE", "G-P FLAKEBOARD COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1724, 
"FIRSTENERG", "FIRSTENERGY TRADING SERVICES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1725, "SCS", 
"SCS", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1726, "HEW", 
"HAMBURGISCHE ELECTRICITATS-WERK AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1727, 
"CKW AG", "CENTRALSCHWEIZERISCHE KRAFTWERKE AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1728, "SBB", 
"SCHWEIZERISCHE BUNDESBAHNEN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1729, 
"VOBOTLEK0406", "VOBOTLEK0406", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1730, 
"OGDEN", "OGDEN  MARTIN SYSTEMS OF UNION, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1731, 
"WILLISTON", "WILLISTON BASIN INTERSTATE PIPELINE COMPANY", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1732, 
"CCNG, INC", "CCNG, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1733, 
"PETBRAS UK", "PETROBRAS UK LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1734, "EWB", 
"ELEKTRIZITAETSWERK DER STADT BERN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1735, 
"TERRA CAD", "TERRA INTERNATIONAL (CANADA) INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1736, 
"COLONIAL O", "COLONIAL OIL INDUSTRIES, INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1737, 
"PENNZOIL", "PENNZOIL-QUAKER STATE COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1738, "RWE", 
"RWE ENERGIE AKTIENGESELLSCHAFT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1739, 
"PAKBOT0590", "PAKBOT0590", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1740, 
"PAKBOT0582", "PAKBOT0582", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1741, 
"CVSL", "CLAIMS VALIDATION SERVICES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1742, 
"HS RESOURC", "HS RESOURC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1743, 
"BEWAG", "BEWAG AKTIENGESELLSCHAFT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1744, 
"ONS ENERGI", "N.V. ONS-ENERGIE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1745, 
"ENECO", "ENECO/SHELL ENERGY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1746, 
"CONT AIR", "CONT AIR", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1747, 
"SUMMIT GAS", "SUMMIT NATURAL GAS & POWER SOLUTIONS, INC.", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1748, 
"MYSTRASII NOV", "MYSTRASII NOV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1749, 
"QUICK BRKR", "ALTRADE TRANSACTION, LLC (BROKER)", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1750, 
"QUICKTRADE", "ATRADE TRANSACTION, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1751, 
"VOBOTLEK1907", "VOBOTLEK1907", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1752, 
"VOBOTLEK0202", "VOBOTLEK0202", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1753, 
"WESTERNREF", "WESTERN REFINING CO AS AGENT FOR REFINERY HOLDING COMPANY LP", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1754, 
"ORION POWR", "ASTORIA GENERATING COMPANY, LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1755, 
"SEMPRA EGY", "SEMPRA ENERGY", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1756, 
"WATERSON", "WATERSON HICKS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1757, 
"BKW AG", "BKW FMB ENERGIE AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1758, 
"MARGATE", "MARGATE NAVIGATION LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1759, 
"BALTDUTCH", "BALT DUTCH SHIPPING AGENCIES BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1760, 
"TORBAY", "TORBAY & BRIXHAM SHIPPING AGENT LIMITED", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1761, 
"FCJUNGE", "FRANCHCONTOR JUNGE BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1762, 
"ENMO LTD", "ENMO LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1763, 
"TOTAL BER", "TOTAL INT'L LTD., BERMUDA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1764, "EOS", 
"ENERGIE OUEST SUISSE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1765, "MVV", 
"MVV ENERGIE AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1766, 
"PAKBOTLEK0582", "PAKBOTLEK0582", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1767, 
"PAKBOTLEK0590", "PAKBOTLEK0590", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1768, 
"ENBW STROM", "ENBW GESELLSHAFT FUR STROMHANDEL MBH", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1769, 
"TEAM EGY", "TEAM ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1770, 
"BEVILL", "EPI SERVICES SA AS AGENT FOR BEVILL TRADING NASSAU BAHAMAS", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1771, 
"RELIANTHLP", "RELIANT ENERGY HL&P", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1772, 
"EXMAR", "EXMAR NV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1773, 
"PNGTS", "PORTLAND NATURAL GAS TRANSMISSION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1774, 
"EDF MAN LT", "ED&F MAN SHIPPING LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1775, 
"LQM PET", "LQM PETROLEUM SERVICES, INC", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1776, 
"SUNBURY", "SUNBURY GENERATION, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1777, 
"SEMPRA UKL", "SEMPRA OIL TRADING UK LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1778, 
"ONEOK PM", "ONEOK POWER MARKETING COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1779, 
"NYISO", "THE NEW YORK INDEPENDENT SYTEM OPERATOR, INC", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1780, 
"NEISO", "ISO NEW ENGLAND INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1781, 
"ITSCBUSA", "INTERTEK TESTING SERVICE/CALEB BRETT", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1782, 
"AB SHIP", "AB SHIPPING LIMITED", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1783, 
"SHELL TRAD", "SHELL TRADING (US) COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1784, 
"CHARLES LE", "SEA-INVEST FRANCE", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1785, 
"SHMIDTSHIP", "SHMIDT SHIPPING LTD", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1786, 
"WORLD NAV", "WORLD NAVIGATION, LTD", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1787, 
"ELETSON", "EMC INVESTMENT CORPORATION", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1788, 
"DALMARE", "DALMARE SPA", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1789, 
"AEP LTD", "AEP ENERGY SERVICES LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1790, 
"IMC KAL", "IMC KALIUM CANADA LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1791, 
"SOC GEN PA", "SOCIETE GENERALE ENERGIE (PARIS) SA", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1792, 
"LISTAGUS", "LISTAGUS LTDA", "A", "PORTAGT", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1793, 
"NICOLE EGY", "NICOLE ENERGY SERVICES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1794, 
"BRAVO", "BRAVO TANKERS", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1795, 
"ARGIRONISS", "ARGIRONISSOS SHIPPPING CORPORATION", "A", "SHIPOWNE", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1796, 
"SENERGY SA", "SENERGY SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1797, 
"SOUTH UN B", "SOUTHERN UNION GAS COMPANY, A DIV OF SOUTHERN UNION CO (BUY)", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1798, 
"SOUTH UN S", "SOUTHERN UNION GAS COMPANY, A DIV OF SOUTHERN UNION SO (SELL)", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1799, 
"SSL INTL", "SSL INTERNATIONAL MARINE LTD", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1800, 
"MARC RICH", "MARC RICH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1801, 
"CHALKBOARD", "CHALKBOARD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1802, 
"TOTALFINAN", "TOTALFINA NV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1803, 
"STREAM CAP", "STREAM CAPITAL INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1804, 
"MERITA", "MERITA BANK PLC", "A", "PEBANK", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1805, 
"KAU TAK", "KAU TAK HOLDINGS LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1806, 'TRANSCORP', 
'TRANSCORP PTE LTD', "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1807, 
"COST ACCR", "COST ACCRUAL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1808, 
"FOSDYKE", "FOSDYKE S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1809, 
"CM CAP MKT", "C.M. CAPITAL MARKETS FUTURE S.A.", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1810, "AWP", 
"ARKANSAS WESTERN PIPELINE, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1811, 
"EN ONLINE", "ENRON ONLINE", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1812, 
"INTESE", "INSPECTION TECHNICAL SERVICES SRL, ITALY", "A", "SRVENDOR", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1813, 
"SENERGY", "SENERGY S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1814, 
"GASTEAM UK", "GASTEAM UK LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1815, 
"SYNERGIA", "SYNERGIA TRADING SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1816, 
"SKS ENERGY", "SKS ENERGY TRADING SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1817, 
"CZECHPOL", "CZECHPOL ENERGY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1818, 
"NAVIOS", "NAVIOS CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1819, 
"CANAD NATL", "CANADIAN NATURAL RESOURCES LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1820, 
"VASA GMBH", "VASA ENERGY GMBH & CO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1821, 
"VOBOTLEK1904", "VOBOTLEK1904", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1822, 
"CAD GOV GS", "CANADIAN GOVERNMENT  GST", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1823, 
"BAYERN GRD", "BAYERNWERK HOCHSPANNUNGSNETZ GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1824, 
"SUPERB", "SUPERB DRAGON LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1825, 
"SIB SRL", "SIB SOCIETA A RESPONSABILITA LIMITATA", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1826, 
"INGENCO", "INDUSTRIAL POWER GENERATING CORPORATION", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1827, 
"INTL SHIP", "INTERNATIONAL SHIPHOLDING CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1828, 
"AEB BV", "AMSTERDAM BROKERS BV", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1829, 
"BOREAS", "BOREAS RESOURCES LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1830, 
"STRATEGIC", "STRATEGIC SHIIPING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1831, 
"UNIONPWR", "UNION POWER PARTNERS, LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1832, 
"READING MU", "READING MUNICPAL LIGHT DEPARTMENT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1833, 
"ALTRAD CAD", "ALTRADE CANADA INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1834, 
"ENTRADE AG", "ENTRADE AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1835, 
"ENRGY PLUS", "ENERGY PLUS LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1836, 
"BARWIL AGE", "BARWIL AGENCIES LTD", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1837, 
"MARE PRINC", "MARE PRINCESS INC", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1838, 
"ALTRD PWR", "ALTRADE POWER BROKER", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1839, 
"MARITIM CD", "MARITIMES & NORTHEAST PIPELINE LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1840, 
"MARITIM US", "MARITIMES & NORTHEAST PIPELINE, LLC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1841, 
"MARE PRINCESS", "MARE PRINCESS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1842, 
"TURNER SHI", "TURNER SHIPPING CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1843, 
"ENTRADE BV", " ENTRADE BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1844, 
"INTRCP COM", "INTERCAPITAL COMMODITY SWAPS LTD, LONDON", "A", "BROKER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1845, 
"NEW ENERGY", "NEW ENERGY INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1846, 
"UNION FENO", "UNION FENOSA GENERACION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1847, 
"LGE ETS", "LG&E ENERGY TRANSMISSION SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1848, 
"VERBUND", "OSTERREICHISCHE ELEKTRIZITATSWIRTSCHAFTS-AG", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1849, 
"GEW KOELN", "GAS-ELEKTRIZITAETS-UND WASSERWERKE KOELN AG", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1850, 
"ELEC FRANC", "ELECTRICITE DE FRANCE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1851, 
"TXU EURLTD", "TXU EUROPE ENERGY TRADING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1852, 
"INDECK SS", "INDECK ENERGY SERVICES OF SILVER SPRINGS, INC", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1853, 
"HOVENSA", "HOVENSA LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1854, 
"ENDESA", "ENDESA SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1855, 
"CMS TRUNKL", "CMS TUNKLINE GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1856, 
"STIR", "SOCIETE TUNISIENNE DES INDUSTRIES DE RAFFINAGE", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1857, "ERG", 
"ERG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1858, 
"NEWOIL", "NEWOIL", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1859, 
"NEWOIL ITALY", "NEWOIL ITALY", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1860, "VEW", 
"VEW ENERGIE AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1861, 
"EPEM", "EL PASO MERCHANT ENERGY LP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1862, 
"TEXEX EGY", "TEXEX ENERGY PARTNERS LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1863, 
"TRIAD EGY", "TRIAD ENERGY RESOURCES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1864, 
"ERG SPA", "ERG SPA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1865, 
"VEPCO", "VIRGINIA POWER SERVICES ENERGY CORP, INC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1866, 
"PLAKA SHIP", "PLAKA SHIPPING CORP, MONROVIA", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1867, 
"BELLA MARI", "BELLA MARITIME CORP", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1868, 
"VAN OMMERE", "VAN OMMEREN INLAND TANKER SHIPPING BV", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1869, 
"ILNOVA POW", "ILLINOVA POWER MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1870, 
"NEREUS", "NEREUS SHIPPING SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1871, "HQ", 
"HQ", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1872, 
"FIDEL SHIP", "FIDELITY SHIPPING PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1873, 
"UNITEDOVERSEA", "UNITEDOVERSEA", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1874, 
"POTEN&PART", "POTEN & PARTNERS (UK) LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1875, 
"DISAM AS", "DISAM AS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1876, 
"PREUSN GRD", "PREUSSEN ELEKTRA NETZ GMBH & CO KG", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1877, 
"CHANNOIL", "WILLOW HOUSE", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1878, 
"ITS CALEB", "ITS CALEB BRETT FRANCE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1879, 
"TULLETT", "TULLET AND TOKYO LIMITED", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1880, 
"TITOV", "TITOV SHIPPING LTD", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1881, 
"AQUATICPRI", "AQUATIC PRINCESS SHIPPING LTD LIBERIA", "A", "SHIPOWNE", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1882, 
"WALC", "WAPA LOWER COLORADO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1883, 
"WACM", "WAPA MONTROSE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1884, 
"ENTEGA", "ENTEGA GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1885, 
"ALANDIAORIENT", "ALANDIAORIENT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1886, 
"VALENTIA", "VALENTIA", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1887, 
"WUMS", "WAPA UPPER MISSOURI", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1888, 
"SUN INTL", "SUN INTERNATIONAL LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1889, 
"BORD GAIS", "BORD GAIS EIREANN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1890, 
"STTKRFT DE", "STATKRAFT EBERGY DEUTSCHLAND GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1891, 
"ANDROMEDA", "ANDROMEDA MANAGEMENT LTD", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1892, 
"MARITIME", "MARITIME BUNKERING LTD", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1893, 
"KOM STROM", "KOM-STROM AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1894, 
"SEMPRA RES", "SEMPRA ENERGY RESOURCES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1895, 
"NAVENNA", "NAVENNA SRL", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1896, 
"D&L GASMKT", "D&L GAS MARKETING LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1897, 
"PROJCTR BE", "PROJECTOR SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1898, 
"ALEGHENY E", "ALLEGHENY ENERGY SUPPLY COMPANY LLC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1899, "PCC", 
"PETRO CARBO CHEM GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1900, 
"ELEKTROMRK", 
"ELEKTROMARK KOMMUNALES ELEKTRIZITAETSWERK MARK AKTIENGESELLSCHAFT", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1901, 
"NAFTABNV", "NAFTA (B) NV - TERMINAL", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1902, 
"PNC BRKR", "PNC BORKER", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1903, 
"NRTHRN ELE", "NORTHERN ELECTRIC & GAS LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1904, 
"CINNABAR", "CINNABAR ENERGY SERVICES & TRADING LLC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1905, 
"STW DUSSEL", "STADTWERKE DUSSELDORF AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1906, 
"ELPASO PRO", "EL PASO PRODUCTIONCO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1907, 
"SHERWOOD M", "SHERWOOD MARITIME LTD", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1908, 
"DYNEGY LIQ.", "DYNEGY GLOBAL LIQUIDS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1909, 
"STRAT EGY", "STRATEGIC ENERGY LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1910, 
"AGIP TR BV", "AGIP TRADING, B.V.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1911, "EBV", 
"ERDOLBEVORRATUNGS-VERBAND (E.B.V.)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1912, 
"VEAG NETZ", "VEREINIGTE ENERGIEWERKE AG NETZ", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1913, 
"STW MUNCH", "STADTWERKE MUCHEN  GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1914, "NWS", 
"NWS ENERGIEHANDEL GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1915, 
"LUKTRANS", "LUKTRANS SHIPPING CO LTD", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1916, 
"PUB SER NH", "PUBLIC SERVICE CO OF NEW HAMPSHIRE", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1917, 
"`BAYERN GRD", "BAYERNWERK NETZ GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1918, 
"ENBW GRD", "ENBW TRANSPORTNETZE AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1919, 
"`PENN POWER", "PPL ELECTRIC UTILITIES CORP DBA PPL UTILITIES", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1920, 
"RWE GRD", "RWE ENERGIE AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1921, 
"AETS", "ALLEGHENY ENERGY SUPPLY COMPANY LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1922, 
"RIVA GMBH", "RIVA ENERGIE GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1923, 
"SEMPRA GMB", "SEMPRA ENERGY EUROPE GMBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1924, 
"ADAMAS", "CARLYLE SHIPPING ENTERPRISES S.A", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1925, 
"M MOSER", "M MOSER ASSOCIATES (S) PTE LTD", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1926, 
"FOSTER YEO", "FOSTER YEOMAN LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1927, 
"MAPP", "MID-ATLANTIC POWER POOL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1928, 
"WORLD FUEL", "WORLD FUEL SERVICES CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1929, 
"INTERARGEM", "INTERARGEM GBR", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1930, 
"PLAISANT", "PLAISANT S.R.I.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1931, 
"GASTALDI", "GASTALDI & CO S.P.A.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1932, 
"LIA OIL SA", "LIA OIL SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1933, 
"SASK MINRL", "SASK MINRL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1934, 
"OPPD", "OMAHA PUBLIC POWER DISTRICT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1935, 
"MAGNA OIL", "MAGNA OIL AND GAS LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1936, 
"EES INC", "ENTERGY SERVICES INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1937, 
"INTERMED", "INTERMED S.R.L.", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1938, 
"CEPSA INT", "CEPSA INTERNATIONAL BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1939, 
"FPL ENERGY", "FPL ENERGY POWER MARKETING, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1940, 
"VAT AUTHOR", "VAT AUTHORITY", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1941, 
"FLETCHER", "FLETCHER CHALLENGE ENERGY CANADA INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1942, 
"HONEYWELL", "HONEYWELL INTERNATIONAL INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1943, 
"BUNGE FOOD", "BUNGE FOODS CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1944, 
"RESID PSEG", "RESIDENTIAL EGA PSE&G", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1945, 
"RESID RIVA", "RESIDENTIAL RIVA RWE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1946, 
"AMEREX SN", "AMEREX PETROLEUM SINGAPORE PTE LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1947, 
"GINA SN", "GINA PETROLEUM (S) PTE LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1948, 
"INTRCP SN", "INTERCAPITAL COMMODITY SWAPS TEP LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1949, 
"LIBRA SN", "LIBRA PETROLEUM (FE) PTE LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1950, 
"PVM SN", "PVM SHOGUN PTE LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1951, 
"SPECTRON A", "SPECTRON ENERGY (ASIA) PTE LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1952, 
"STARSUP SN", "STARSUPPLY PACIFIC (S) PTE LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1953, 
"TFS EGY SN", "TFS ENERGY (S) PTE LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1954, 
"TULLETT SN", "TULLETT & TOKYO (ENERGY) PTE LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1955, 
"SPECTRN GE", "SPECTRON GAS & ELECTRICITY (UK) LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1956, 
"TULLETT SE", "TULLETT & TOKYO INTERNATIONAL SECURITIES LTD", "A", "BROKER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1957, 
"TULLET TSA", "TULLETT TSA", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1958, 
"BAKRI TRAD", "BAKRI TRADING CO (ASIA) PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1959, 
"BANGCHAK P", "THE BANGCHAK PETROLEUM PUBLIC CO LTD", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1960, 
"BP JAPAN", "BP JAPAN TRADING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1961, 
"CARGILL S", "CARGILL INTERNATIONAL S.A. (SINGAPORE BRANCH)", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1962, 
"UNIPEC UK", "UNIPEC UK CO LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1963, 
"UINPEC ASA", "UNIPEC ASIA CO LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1964, 
"CNOOC", "CHINA NATIONAL OFFSHORE OIL CORP (CNOOC)", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1965, 
"CHINA OIL", "CHINA NATIONAL OIL CORP (CHINA OIL)", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1966, 
"CHINA RES", "CHINA RESOURCES PETROLEUM CO LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1967, 
"CAD PETRO", "CANADIAN PETROLEUM INTERNATIONAL MARKETING LIMITED", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1968, 
"ELF ASIA", "ELF TRADING ASIA PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1969, 
"ENGEN PETR", "ENGEN PETROLEUM INTERNATIONAL LTD (SOUTH AFRICA)", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1970, 
"ENRON SN", "ENRON CAPITAL & TRADE RESOURCES SINGAPORE PTE LTD", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1971, 
"FORMOSA T", "FORMOSA TAIWAN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1972, 
"FAMMSING", "FUEL & MARINE MARKETING LLC (SINGAPORE BRANCH)", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1973, 
"FUJI OIL", "FUJI OIL CO LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1974, 
"ARABIAN", "ARABIAN OIL CO LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1975, 
"PETRO PROG", "PETRO PROGRESS PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1976, 
"GLENCOR UK", "CLENCORE UK LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1977, 
"IDEMITSU E", "IDEMITSU INTERNATIONAL (EUROPE) PLC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1978, 
"IND OIL CO", "INDIAN OIL CORPORATION LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1979, 
"JAPAN EGY", "JAPAN ENERGY CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1980, 
"KASHIMA", "KASHIMA OIL CO LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1981, 
"KASHIMA SN", "KASHIMA OIL (SINGAPORE) PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1982, 
"KOA OIL", "KOA OIL  CO LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1983, 
"KNOC", "KOREA PETROLEUM DEVELOPMENT CORP (KNOC)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1984, 
"LG CALTEX S", "LG CALTEX OIL SINGAPORE PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1985, 
"MARUBENI M", "MARUBENI PETROPLEUM CO LTD C.O MARUBENI CORPORATION", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1986, 
"MASEFIELD L", "MASEFIELD LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1987, 
"MASEFIELD SN", "MASEFIELD (SINGAPORE) PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1988, 
"NIPN MITSU", "NIPPON MITSUBISHI OIL CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1989, 
"NIPN MIT A", "NIPPON MITSUBISHI OIL (ASIA) PTE LTD", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1990, 
"PETRO D HK", "PETRO DIAMOND CO LTD (HONG KONG)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1991, 
"EXXON M SN", "EXXON MOBIL", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1992, 
"MARCRICH S", "MARC RICH (SINGAPORE) PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1993, 
"MORGAN SN", "MORGAN STANLEY DEAN WITTER CAPITAL GROUP (SINGAPORE)", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1994, 
"ONYX O PTE", "ONYX OIL (PTE) LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1995, 
"PETAUTHAI", "PETROLEUM AUTHORITY OF THAILAND (PTT)", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1996, 
"PETROLIAM", "PETROLIAM NASIONAL BERHAD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1997, 
"RELIANCE", "RELIANCE PETROLEUM LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1998, 
"RELIANCE E", "RELIANCE EUROPE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(1999, 
"SHELL JPN", "SHELL JAPAN TRADING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2000, 
"SHOWA", "SHOWA SHELL SEKIYU KK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2001, 
"SINOPEC", "SINOPEC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2002, 
"SINOPEC SN", "SINOPEC (SINGAPORE) PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2003, 
"SINOPEC HK", "SINOPEC (HONG KONG) LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2004, 
"SK GLOBAL", "SK GLOBAL CO LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2005, 
"SK GLA", "SK GLOBAL ASIA PACIFIC PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2006, 
"SOGS", "SOCIETE GENERALE SINGAPORE BRANCH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2007, 
"TESORO SN", "TESORO PETROLEUM (SINGAPORE) PTE LTD", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2008, 
"TKYOM INTL", "TOKYO MITSUBISHI INTERNATIONAL INC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2009, 
"TRAF BV SW", "TRAFIGURA BEHEER BV SWITZERLAND", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2010, 
"GEORGIA G", "GEORGIA GULF CHEMICALS & VINYLS LLC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2011, 
"NIMO EGMKT", "NIAGRA MOHAWK ENERGY MARKETING, INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2012, 
"TXU EGYTR", "TXU ENERGY TRADING CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2013, 
"ONEOK TRAN", "ONEOK GAS TRANSPORTATION LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2014, 
"QUANTUM PL", "QUANTUM GAS MANAGEMENT PLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2015, 
"CITZ", "CITIZENS POWER SALES LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2016, 
"WEYERHAEUS", "WEYERHAEUSER CANADA, SASKATCHEWAN DIVISION", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2017, 
"TRIANEL", "TRIANEL EUROPEAN ENERGY TRADING GBMH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2018, 
"AMEREN SER", "AMEREN SERVICES COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2019, 
"JAMES RAWE", "JAMES RAWES & CA. LDA.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2020, 
"SEABRIDGE", "SEABRIDGE INTERNATIONAL SHIPPING INC.", "A", "SRVENDOR", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2021, 
"NG TRADING", "NG TRADING LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2022, 
"VATTENFALL", "VATTENFALL AB", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2023, 
"ITS ITALY", "ITS CALEB BRETT ITALY", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2024, 
"ELF TR&MKT", "ELF TRADING AND MARKETING B.V.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2025, 
"NORTH SHOR", "NORTH SHORE GAS CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2026, 
"ENOC S & T", "ENOC SUPPLY & TRADING CO. LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2027, 
"BOYD SSHIP", "BOYD STEAMSHIP CORPORATION", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2028, 
"NHEC", "NEW HAMPSHIRE ELECTRIC COOPERATIVE, INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2029, 
"CSAV", "COMPANIA SUD AMERICANO DE VAPORES S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2030, 
"CORUS UK", "CORUS TRADING (UK) LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2031, 
"TEMPO", "TEMPO TRADE SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2032, 
"BANKERS IN", "BANKERS TRUST INTERNATIONAL LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2033, 
"ENEMALTA", "ENEMALTA CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2034, 
"REPSOL YPF", "REPSOL YPF TRADING & TRANSPORT S. A.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2035, 
"DUKE MER", "DUKE ENERGY MERCHANTS, L.L.C.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2036, 
"OCEANSTAT1", "OCEAN STATE POWER", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2037, 
"OCEANSTAT2", "OCEAN STATE POWER II", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2038, 
"BP NA FUT", "BP NORTH AMERICA FUTURES", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2039, 
"ESKAY S&T", "ESKAY SHIPPING AND TRADING INC.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2040, 
"NOVARCO F", "NOVARCO AG FUTURES", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2041, 
"COM FEC EL", "COMISION FEDERAL DE ELECTRICIDAD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2042, 
"SYS FUEL", "SYSTEM FUELS INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2043, 
"CWEC", "CHINA WANBAO ENGINEERING CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2044, 
"TRANSMARIN", "TRANSMARINE NAVIGATION CORP", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2045, 
"FEARNOIL", "FEARNOIL-BROKER", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2046, 
"OLYMPOS", "OLYMPOS SHIPPING COMPANY LIMITED", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2047, 
"ALASKA AIR", "ALASKA AIRLINES INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2048, 
"BURKE&NOVI", "BURKE & NOVI", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2049, 
"EDFTL", "EDF TRADING LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2050, 
"SAMSUNG", "SAMSUNG CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2051, 
"WILMARK", "WILLIAMS-GULFMARK ENERGY COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2052, 
"NBPM", "NEW BRUNSWICK POWER CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2053, "EGL", 
"ELEKTRIZITAWTSGESELLSCHAFT LAUFENBURG AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2054, 
"ITS DENMK", "ITS CALEB BRETT DENMARK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2055, 
"MULLER BV", "WM. H. MULLER AND CO NEDERLAND B.V.", "A", "SRVENDOR", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2056, 
"CINRGY GLO", "CINERGY GLOBAL TRADING LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2057, 
"PRIME EGY", "PRIME ENERGY AS", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2058, 
"RINEX ASIA", "RINEX OIL ASIA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2059, 
"TORM WTRFT", "TORM WATERFRONT TANDERS OF COPENHAGEN", "A", "SHIPOWNE", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2060, 
"HYDRO Q-T", "TRANSENERGIE DIV D'HYDRO QUEBEC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2061, 
"BUFF CITY", "DEPARTMENT OF PUBLIC WORKS CITY OF BUFFALO NY", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2062, 
"GAS NATRL", "GAS NATURAL INTERNATIONAL LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2063, 
"HORIZON IN", "HORIZON INTERNATIONAL TRADING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2064, 
"ENAGAS SA", "ENAGAS, S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2065, 
"ARB OIL", "ARB OIL INC. BROKERAGE", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2066, 
"WESTRN PET", "WESTERN PETROLEUM N.V.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2067, 
"KCPL", "KANSAS CITY POWER & LIGHT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2068, 
"SEASCOPE", "SEASCOPE SHIPPING LIMITED", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2069, 
"MARC R INV", "MARC RICH & CO INVESTMENT AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2070, 
"BACTON AGT", "BACTON AGENT COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2071, 
"STAR TANKR", "HEIDEN MARINE A/A/F STAR TANKERS INC", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2072, 
"PETROLA H", "PETROLA HELLAS S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2073, 
"A LEFFLER", "AB AUGUST LEFFLER", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2074, 
"STORAGE/IN", "STORAGE / INJECTION", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2075, 
"STORAGE/WD", "STORAGE WIDTHDRAWL", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2076, 
"ELITE", "ELITE BROKERS", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2077, 
"TINTRADE", "TINTRADE LTD. BRANCH ESTONIA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2078, 
"GISELLE", "GISELLE MARITIME LTD.", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2079, 
"PROSE", "PROSE SHIPPING LTD.", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2080, 
"AIG ARB LP", "AIG COMMODITY ARBITRAGE FUND L.P.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2081, 
"AIG ARB LT", "AIG COMMODITY ARBITRAGE FUND LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2082, 
"OCEANPAC", "OCEANPAC LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2083, 
"CONECTIVES", "CONECTIV ENERGY SUPPLY INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2084, 
"PADO O&C", "PADO OIL AND CHEMICAL S.A.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2085, 
"ONPOWGEN", "ONTARIO POWER GENERATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2086, 
"POWERBRK", "POWERBROKER", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2087, 
"AEPM-T", "TRANS - AMERICAN ELECTRIC POWER", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2088, 
"AZPS-T", "ARIZONA PUBLIC SERVICE CO.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2089, 
"BPA-T", "TRANS - BONNEVILLE POWER ADMINISTRATION", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2090, 
"CLECO-T", "TRANS - CENTRAL LOUISIANA ELECTRIC CO.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2091, 
"EES INC-T", "TRANS - ENTERGY SERVICES INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2092, 
"DEUTSCHEAG", "DEUTSCHE BANK AG, NEW YORK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2093, 
"MEAG-T", "TRANS - MUNICIPAL ELECTRIC AUTHORITY OF GEORGIA", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2094, 
"APPALACHN", "APPALACHIAN PRODUCER SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2095, 
"ENLINE EGY", "ENLINE ENERGY SOLUTIONS, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2096, 
"AP MOELLER", "AM MOELLER / TANKER DEPARTMENT", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2097, 
"AARMATORIA", "GESTIONI ARMATORIALI SPA - NAPOLI", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2098, 
"MARCUM", "MARCUM ASHLAND", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2099, 
"GRANT PUD", "GRANT COUNTY PUD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2100, 
"BBA NE", "BILL BLACK AGENCY (NEW ENGLAND) INC.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2101, 
"SEAFORD", "SEAFORD MARINE INC.", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2102, 
"LA GENERAT", "NRG POWER MARKETING INC AAF LOUISIANA GENERATING LLC", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2103, "UCI", 
"UNIVERSITY OF CALIFORNIA IRVINE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2104, 
"UCI MEDCTR", "UNIVERSITY OF CALIFORNIA MEDIACAL CENTER", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2105, 
"TRANSCOR", "TRANSCOR ENERGY SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2106, 
"WISVEST CT", "WISVEST CONNECTICUT LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2107, 
"WALLS INTL", "WALLS INTERNATIONAL INC", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2108, 
"MACLAREN", "MACLAREN ENERGY INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2109, 
"GAS ROSA", "GASODUCTO ROSARITO, S. DE R.L. DE C.V.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2110, 
"REDERI", "REDERI AB BREVIK", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2111, 
"SOMERSET", "SOMERSET OIL & GAS COMPANY, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2112, 
"VPPSA", "VERMONT PUBLIC POWER SUPPLY AUTHORITY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2113, 
"CANTABRICO", "HIDROELECTRICA DEL CANTABRICO", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2114, 
"VEW NETZ", "VEW GRD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2115, 
"PRONET", "PRONET HOLDING LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2116, 
"NRG-TULLET", "NATSOURCE-TULLETT EUROPE LTD.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2117, 
"N-CORAL R", "CORAL STRUCTURING LLC - NYMEX", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2118, 
"JOHN S OIL", "JOHN W. STONE OIL DISTRIBUTOR, L.L.C.", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2119, 
"OMV UK LTD", "OMV (UK) LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2120, "SAB", 
"SABINE GAS OPERATING COMPANY", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2121, 
"GWATSONGRY", "G. WATSON GRAY (HOLLAND) B.V.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2122, 
"WINTERSEA", "WINTERSEA MARITIME COMPORATION", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2123, "CRW", 
"CRW - EXCHANGE BROKER", "A", "EXCHBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2124, 
"FREEPORT N", "FREEPORT NAVIGATION CO. LTD.", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2125, 
"OMISA", "OMISA RESOURCES (BERMUDA) LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2126, 
"M OIL HELL", "MOTOR OIL (HELLAS) CORINTH REFINERIES S.A.", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2127, 
"SIMON PRAT", "SIMON PRATT & PARTNERS (UK) LIMITED", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2128, 
"MITSUI PTE", "MITSUI OIL (ASIA) PTE LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2129, 
"OILTANK M", "OILTANKING GMBH, MALTA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2130, 
"KEYSPAN GE", "KEYSPAN GAS EAST CORP D/B/A/ KEYSPAN EGY DELVRY LONG ISLAND", 
"A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2131, 
"COASTAL T", "COASTAL TOWING, INC.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2132, 
"OILTEST", "OILTEST, INC.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2133, 
"PETROCOM", "PETRO.COM PTE LTD.", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2134, 
"EKCHARTER", "EKCHARTERING / EKSHIP C/O ORIENTAL SHIPMANAGEMENT", "A", 
"SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2135, 
"SEA STAR M", "SEA STAR MARITIME PTE LTD", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2136, 
"RIO EGY I", "RIO ENERGY INTERNATIONAL, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2137, 
"TMLP", "ENERGY NEW ENGLAND ACTING AS AGENT FOR TAUNTON MUNICIPAL", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2138, 
"AECI", "ASSOCIATED ELECTRIC COOPERATIVE, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2139, 
"BELD", "ENERGY NEW ENGLAND ACTING AS AGENT FOR BRAINTREE ELECTRIC", "A", 
"CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2140, 
"LELD", "LITTLETON ELECTRIC LIGHT DEPT.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2141, 
"PACIF FUEL", "PACIFICORP  FUEL RESOURCES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2142, 
"PACIF SVCS", "PACIFICORP WHOLESALE SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2143, 
"JP FUEL R", "JP FUEL RESOURCES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2144, 
"PPL MT", "PP&L MONTANA, LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2145, 
"CARGIL CAD", "CARGILL ENERGY TRADING CANADA, INC.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2146, 
"SCEG", "SOUTH CAROLINA ELECTRIC & GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2147, 
"SCEG-T", "SOUTH CAROLINA ELECTRIC & GAS COMPANY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2148, 
"NAVIGAZION", "NAVIGAZIONE MONTANARI SPA", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2149, 
"FSG EGY SV", "FSG ENERGY SERVICES", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2150, 
"AP M AGENT", "AP MOLLER AGENT", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2151, 
"CEPSA SHIP", "COMPANIA ESPAOLA DE PETROLEOS, S.A.", "A", "SHIPOWNE", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2152, 
"SOCO CAD", "SOUTHERN COMPANY ENERGY MARKETING CANADA LTD.", "A", "CUSTOMER", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2153, 
"ATCO PWR", "ATCO POWER CANADA LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2154, 
"GLORY SHIP", "GLORY SHIP MANAGEMENT PTE LTD", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2155, 
"RELIANT BV", "RELIANT ENERGY TRADING AND MARKETING BV", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2156, 
"N-HESS EGY", "HESS ENERGY TRADING CORP (NYMEX)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2157, 
"N-VITOL SA", "VITOL SA INC (NYMEX)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2158, 
"CLARION", "CLARION (FLOOR BROKER)", "A", "FLRBRKR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2159, 
"EDISON M&T", "EDISON MISSION MARKETING & TRADING INC.", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2160, 
"ITS-TRIN", "INTERTEK TESTING SERVICES, CALEB BRETT TRINIDAD LTD.", "A", 
"SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2161, 
"SKM EGY", "SKM DEUTCHLAND GMBH", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2162, 
"SCBLNYNY", "STANDARD CHARTERED BANK NEW YORK", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2163, 
"MED TS CO", "MEDITERRANIAN TRADING SHIPPING CO LTD", "A", "SHIPOWNE", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2164, 
"RUNICOM", "RUNICOM LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2165, 
"HARMONY WW", "HARMONY WORLDWIDE CORP. S/A", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2166, 
"MAERSK BRO", "MAERSK BROKER AGENCY", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2167, 
"AIC LTD", "AIC LIMITED", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2168, 
"ELLER & CO", "ELLER & COMPANY, INC", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2169, 
"BELTANK", "BELTANK NV", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2170, 
"POMME", "AGENCES MARITIMES POMME", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2171, 
"KOCH CARBO", "KOCH CARBON, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2172, 
"HESS INC", "HESS ENERGY INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2173, 
"SAYBOLT EH", "SAYBOLT EASTERN HEMISPHERE BV", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2174, 
"CARGO INSP", "CARGO INSPECTIONS LTD.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2175, 
"PETRO SA", "PETRO SURVEY ASSISTANCE S.A.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2176, 
"REDERI HER", "REDERI AB HERON", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2177, 
"MARUBENI B", "MARUBENI PETROLEUM CO LTD (BERMUDA)", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2178, 
"TIDAL EGY", "TIDAL ENERGY MARKETING INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2179, 
"BROSTROM", "BROSTROM  TANKERS AB", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2180, 
"ALVTANK", "ALVTANK HB", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2181, 
"N-CORNERST", "NYMEX CORNERSTONE PROPANE INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2182, 
"N-EPRIME", "NYMEX EPRIME", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2183, 
"SOUTHERNBV", "SOUTHERN ENERGY-EUROPE BV", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2184, 
"N-WARDWOOD", "NYMEX WARDWOOD MARKETING", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2185, 
"COMMON EGY", "COMMON ENERGY CORPORATION", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2186, "NOK", 
"NORDOSTSCHWEIZERISCHE KRAFTWERKE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2187, 
"SABENA SA", "SABENA SOCIETE ANONYME", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2188, 
"OIL TANK S", "OIL TANKING GMBH, SINGAPORE", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2189, 
"RADIX SING", "RADIX ENERGY (SINGAPORE) PTE LTD", "A", "BROKER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2190, 
"HGED", "HOLYOKE GAS & ELECTRIC DEPT", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2191, 
"E&T EGY", "E&T ENERGIE HANDELSGESELLSCHAFT M.B.H.", "A", "CUSTOMER", "N", "N", 
1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2192, 
"OIL TANK G", "OIL TANKING G", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2193, 
"N-PREMCOR", "THE PREMCOR REFINING GROUP INC. (MERC)", "A", "CUSTOMER", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2194, 
"OBC SHIP", "OBC SHIPPING LTD", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2195, 
"BOMIN INC", "BOMINFLOT INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2196, 
"NAT COAL", "NATIONAL COAL SUPPY CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2197, 
"INTERLNK S", "INTERLINK INC (S) PTE, LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2198, 
"PERC", "PEOPLE'S ENERGY RESOURCES CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2199, 
"ELSAM AS", "ELSAM A/S", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2200, 
"ASSOC BULK", "ASSOCIATED BULK CARRIERS LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2201, 
"MGI SUPPLY", "MGI SUPPLY, LTD.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2202, 
"GER TANKER", "GERMAN TANKER SHIPPING", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2203, 
"ITOCHU MAR", "ITOCHU MARINE CORPORATION LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2204, 
"CROWN RES", "CROWN RESOURCES AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2205, 
"RAETIA", "RAETIA ENERGIE AG", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2206, 
"IND PET GR", "INDEPENDENT PETROLEUM GROUP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2207, 
"ONT EGY SC", "ONTARIO ENERGY SAVINGS CORP", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2208, 
"SARTORI", "SARTORI & BERGER", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2209, 
"PRO BARGE", "PROGRESSIVE BARGE LINE, INC.", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2210, 
"NOVA SCOT", "NOVA SCOTIA POWER INC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2211, 
"AGENCE MAR", "AGENCE MARITIME HUMANN", "A", "SHIPOWNE", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2212, 
"NATIONAL P", "NATIONAL POWER PLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2213, 
"KEYSPAN RA", "KEYSPAN RAVENSWOOD, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2214, 
"VAN ANTWRP", "VAN OMMEREN ANTWERPEN", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2215, 
"MAERSK K/S", "MAERSK BROKER K/S", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2216, 
"RETEX", "RETEX INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2217, 
"SCANDIC", "SCANDIC ENERGY AS", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2218, 
"TITAN EGY", "TITAN ENERGY, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2219, 
"ESSO TRANS", "ESSO S.A.F. SERVICE TRANSPORT MARITIME", "A", "SHIPOWNE", "N", 
"N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2220, 
"KANGQIOIL", "KANGQI OIL TRADING LTD, LABUAN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2221, 
"HERMES PAN", "HERMES SHIPPING AND TRADING CORP. SA PANAMA", "A", "SHIPOWNE", 
"N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2222, 
"HUMAN DUNK", "AGENCE MARITIME HUMANN", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2223, 
"GREEN NAV", "GREEN NAVIGATION PTE LTD", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2224, 
"BBEGY ASIA", "B.B. ENERGY (ASIA) PTE. LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2225, 
"EON PE", "E.ON ENERGIE AG (HANNOVER)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2226, 
"EON BAG", "E.ON ENERGIE AG (MUNICH)", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2227, 
"PETRO EGY", "PETROCOM ENERGY GROUP, LTD", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2228, 
"FOYLE SHIP", "FOYLE SHIPPING SERVICES", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2229, 
"EQUILON EN", "EQUILON ENTERPRISES LLC", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2230, 
"RINEX EGY", "RINEX ENERGY SA", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2231, 
"TORCH TM", "TORCH ENERGY TM, INC.", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2232, 
"A/S TRUMF", "A/S TRUMF BUNKER", "A", "SRVENDOR", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2233, 
"N-CONECTIV", "CONECTIV ENERGY - NYMEX", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2234, 
"AFC MBH", "AFC AVIATION FUEL COMPANY MBH", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2235, 
"VP EGY", "V-P ENERGY", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2236, 
"KINDRMORGN", "KINDER MORGAN", "A", "CUSTOMER", "N", "N", 1)
go

insert into account (acct_num, acct_short_name, acct_full_name, acct_status, 
  acct_type_code, acct_parent_ind, acct_sub_ind, trans_id) values(2237, 
"SPECTRUM", "SPECTRUM OIL BROKERS, INC.", "A", "BROKER", "N", "N", 1)
go

