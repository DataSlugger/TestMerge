print ' '
print 'Loading additional seed data into the account_ext_info table ...'
go

insert into dbo.account_ext_info
   (acct_num, trans_id)
select acct_num, 1
from account a
where not exists (select 1
                  from dbo.account_ext_info b
                  where a.acct_num = b.acct_num)
go
