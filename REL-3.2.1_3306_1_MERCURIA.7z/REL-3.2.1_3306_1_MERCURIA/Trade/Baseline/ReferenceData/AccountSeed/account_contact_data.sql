print 'Loading additional seed data into the account_contact table ...'
go

insert into account_contact values(2, 1, "CONNORS", "PEGGY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "9149462513", 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2, 2, "HAMBLIN", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-222-7100", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(4, 1, "HEKKERT", "JAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "CH", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(4, 2, "WILLIAMSON", "NICO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "CH", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(5, 2, "UESUGI", "KEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(5, 3, "MAIKAWA", "TADAMASA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "655389693", NULL, NULL, 
NULL, NULL, NULL, 2, "A", 1)
go

insert into account_contact values(6, 1, "VAN DER HEYDEN", "MR", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(7, 1, "MASAUDA", "M", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(7, 2, "FUSHIMI", "MS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(7, 3, "NAKAYAMA", "MASASHI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(7, 4, "KUSAKABE", "ISAO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "81-33798-3272", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(7, 5, "SATO", "YOSHIHIKO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(8, 1, "CAMP", "ANDY", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(8, 2, "LINDSAY", "HORN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7741021", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(8, 3, "O'BRIEN", "JAMES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(8, 4, "KEEN", "ROB", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "01717741021", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(9, 1, "MOCHIZUKI", "KENT", NULL, NULL, 
"HONG LEONG BUILDING #40-01A", "16 RAFFLES QUAY", "SINAGPORE 0104", NULL, 
"SINAGPORE 0104", "NA", "SGP", NULL, NULL, NULL, NULL, "21900", NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(9, 2, "FUJISHIRO", "MR.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(9, 3, "FUJISHIRO", "NAOKI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(9, 4, "TSUBOI", "T", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(9, 5, "WEN", "RONG", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(9, 6, "LIEN", "SAN", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(9, 7, "SEOW", "ALOYSIOS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(9, 8, "TSUBOI", "T", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(9, 9, "WENG YEE", "YIP", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "786 RS21900", NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(9, 10, "GOH", "PETER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "RS21900", NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(9, 11, "SATOH", "SHOETSU", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "RS21900", NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(10, 1, "PUGH", "CHRIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(11, 2, "ANTONUTTI", "JULIO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(11, 3, "PULCINI", "ANDREA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(11, 4, "CIRILLI", "FRANCO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(11, 5, "DEL FINE", "MICHELE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "390659827327", NULL, 
"620360", "390659827603", NULL, NULL, 5, "A", 1)
go

insert into account_contact values(11, 6, "STEVENSON", "PHILLIP", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 6, "A", 1)
go

insert into account_contact values(11, 7, "ALESSANDRO", "CARINI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 5, "A", 1)
go

insert into account_contact values(11, 8, "PASELLA", "VITTORINA", NULL, 
"RISK DEPARTMENT", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "620039-613521", "011-39-06-59887", NULL, NULL, 6, "A", 1)
go

insert into account_contact values(11, 9, "SEGRETO", "G.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"39-06-5988-7912", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(12, 37, "PETERSEN", " CARL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2038613765", NULL, 
"170125", "2038613828", NULL, NULL, 73, "A", 1)
go

insert into account_contact values(12, 38, "STEIN", "SIMON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2038613790", NULL, NULL, 
"2038613828", NULL, NULL, 73, "A", 1)
go

insert into account_contact values(12, 39, "SCHEILPMAN", "PETER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2038613771", NULL, NULL, 
"2038613828", NULL, NULL, 73, "A", 1)
go

insert into account_contact values(13, 1, "SWEET", "DARIUS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(13, 2, "TUTTLE", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(13, 3, "GASSAWAY", "MARK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7136094950", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(13, 4, "MORTIMER", "ESTHER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "212-536-8985", NULL, 
NULL, "212-536-8505", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(15, 1, "ULRICK", "FRANK", NULL, NULL, 
"CENTER PORT V", "P.O. BOX 619616, MD 5662", NULL, NULL, 
"DFW INTERNATIONAL AIRPORT", "TX", "USA", "75261", NULL, "8179632674", NULL, 
NULL, "8179632033", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(15, 2, "JACKSON", "J.M.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "8179631234", NULL, NULL, 
"8179674318", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(15, 3, "TOM", "DOLAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(16, 1, "BLUM", "BRUNO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "CH", NULL, NULL, NULL, NULL, "865428 AOT CH", 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(16, 2, "JENSEN", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "CH", NULL, NULL, NULL, NULL, "865428 AOT CH", 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(16, 3, "HIM", "KOH SIAK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "CH", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(16, 4, "YIP", "LOH FAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "CH", NULL, NULL, NULL, NULL, "865428 AOT CH", 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(16, 5, "GOH", "MR", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "CH", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(16, 6, "MUELLER", "MAUREEN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "901141417100422", NULL, 
"865428AOTCH", "901141417266900", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(17, 8, "GORDON", "ALASTAIR", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(17, 9, "GREEN", "MARCUS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(17, 10, "POTTER", "KERRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(17, 11, "FRENCH", "ROBERT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 31, "TAN", "T.H.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 32, "CHIA", "L.H.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 45, "RESNICK", "JEFF", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 47, "KEEN", "ROB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 52, "LEWIS", "RICHARD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 53, "MARSTON", "ALAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 59, "EALET", "ISABELLE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(18, 60, "SOH", "HARRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 61, "MURTHY", "ARUN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 62, "YOUNG", "GILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 64, "BERTUZZI", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 65, "YOUNG", "GILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 66, "YOUNG", "GILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 67, "YOUNG", "GILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 68, "BATUZZI", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 69, "PIERRE", "JEAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 70, "KAPLAN", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2129028986", NULL, NULL, 
"2123443457", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(18, 71, "LISENBY", "STEVE", NULL, NULL, 
"85 BROAD STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10004", NULL, 
NULL, NULL, "6720148", "2123443457", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(18, 72, "OHAGAN", "PETER", NULL, NULL, 
"85 BROAD STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10004", NULL, 
NULL, NULL, "6720148", "2123443457", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(18, 73, "COOPER", "EDITH", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 74, "VAN", "REIT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 75, "VANREIT", "STEVEN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(18, 76, "TAN", "JON", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(18, 77, "MCFADZEN", "IAN", NULL, NULL, 
"85 BROAD STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10004", NULL, 
NULL, NULL, "6720148", "2123443457", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(18, 78, "SCHNEIDER", "J", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 79, "SCALA", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 80, "HORN", "LINDSAY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 81, "WAREBORN", "HENRY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(18, 82, "ERRINGTON", "JIM", NULL, NULL, 
"85 BROAD STREET", "FLOOR 5 DEPT. 490", NULL, NULL, "NEW YORK", "NY", "USA", 
"10004", NULL, NULL, NULL, "6720148", "2123443457", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(18, 83, "WAREBORN", "HENRIC", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(18, 84, "LEE", "GWO", NULL, NULL, 
"85 BROAD STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10004", NULL, 
"(212)902-0777", NULL, "6720148", "2123443457", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(18, 85, "SHERIFF", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(18, 86, "CASTURO", "DON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(18, 87, "ERICSON", "ANDRE", NULL, NULL, 
"85 BROAD STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10004", NULL, 
NULL, NULL, "6720148", "2123443457", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(18, 88, "NELSON", "SARA", NULL, NULL, 
"85 BROAD STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", NULL, NULL, 
"212-902-5920", NULL, NULL, NULL, NULL, NULL, 6, "A", 1)
go

insert into account_contact values(19, 1, "/ASAD SHAH", "SANDRA  WARD", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 7, "A", 1)
go

insert into account_contact values(19, 2, "ELAHI", "ANWAR", NULL, NULL, 
"2 QUEEN ANNE'S GATE BUILDING", "DARTMOUTH STREET", NULL, NULL, 
"LONDON SW1H 9BP", NULL, "GB", NULL, NULL, "2221188", NULL, "976-8580", 
"44 171 99797685", NULL, NULL, 5, "A", 1)
go

insert into account_contact values(20, 1, "PEER", "HADLEY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3122345422", NULL, NULL, 
"3122345750", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(20, 2, "WONG", "DALE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7132476346", NULL, NULL, NULL, 
NULL, NULL, 74, "A", 1)
go

insert into account_contact values(20, 3, "ROSE", "BOB", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7132476347", NULL, NULL, NULL, NULL, 
NULL, 74, "A", 1)
go

insert into account_contact values(20, 4, "AYME", "BYRON", NULL, NULL, 
"440 S. LASALLE STREET", "SUITE 3300", NULL, NULL, "CHICAGO", "IL", "USA", 
"60605", NULL, NULL, NULL, NULL, "3122345601", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(20, 5, "LEE", "PAM", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(20, 6, "O'HAGAN", "P", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(20, 7, "LEONI", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(20, 8, "JEREMY", "SORKIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(21, 1, "HO", "KEVIN", NULL, NULL, 
"83 CHUNG HWA RD, SEC 1", NULL, NULL, NULL, NULL, NULL, "RC", NULL, NULL, 
"886-2-312-6127", NULL, NULL, "886-2-381-4624", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(21, 2, "CHAO", "CHARLES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "88623611541", NULL, "11215", 
"88623319645", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(21, 3, "LAI", "S.T.", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "8862312347", "8862119286", NULL, NULL, 
"88623612018", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(22, 10, "DAVIS", "J", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(22, 15, "LEDO", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(22, 22, "BARTLEY", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(22, 23, "HARPER", "TRAVIS", NULL, NULL, 
"6100 SOUTH YALE", NULL, NULL, NULL, "TULSA", "OK", "USA", "74136", NULL, NULL, 
NULL, "158157", "918-495-5141", NULL, NULL, 4, "A", 1)
go

insert into account_contact values(22, 24, "MCCRAY", "SCOTT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "918-495-7207", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(22, 25, "CRITES", "LEON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "(918) 495-4702", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(23, 22, "BARDEZAK", "RAY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(23, 23, "WATERS", "SIMON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(23, 24, "SHURR", "ALAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(23, 25, "GLASSICK", "BRUCE", NULL, NULL, 
"THREE STAMFORD PLAZA", "301 TRESSER BLVD", NULL, NULL, "STAMFORD", "CT", "USA", 
"06901", NULL, NULL, NULL, "6819406", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(24, 6, "FRAZIER", "BARRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(24, 7, "O'CONNOR", "RANDY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(24, 10, "BLUME", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(24, 12, "PAZERO", "JAY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(24, 14, "OVERBY", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(24, 15, "NEISE", "JOHN", NULL, NULL, 
"8182 MARYLAND AVENUE", NULL, NULL, NULL, "CLAYTON", "MO", "USA", "63105-372", 
NULL, NULL, NULL, "434509", "713-873-1530", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(25, 6, "SAMSEL", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(25, 8, "WAHL", "ED", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(26, 1, "CHURCH", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(27, 11, "BISCHOFF", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(27, 17, "SHIPOS", "MARK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(27, 18, "ODEN", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(27, 19, "PUDDY", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7138777132", 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(27, 20, "MURTHA", "HUGH", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7138773878", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(27, 21, "EWING", "VINCE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-877-7161", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(27, 22, "VILAS", "ALFREDO", NULL, NULL, 
"NINE GREENWAY PLAZA", NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77046", NULL, 
"713-877-6009", NULL, "166008", "7138776693", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(27, 23, "ADKINS", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7138777132", 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(27, 24, "BUCEK", "STAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(27, 25, "PINELL", "JOHN", NULL, NULL, 
"NINE GREENWAY PLAZA", NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77046", NULL, 
NULL, NULL, "166008", "7138776693", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(27, 26, "WOOD", "ED", NULL, NULL, 
"NINE GREENWAY PLAZA", NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77046", NULL, 
NULL, NULL, "166008", "7138776693", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(27, 27, "HAMBURGER", "KENNY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(28, 1, "JOHNSON", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(28, 2, "SCOTT", "DAVID C.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(28, 3, "SMITH", "A", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(29, 5, "JOHNSON", "JOHN", NULL, NULL, 
"9 GREENWAY PLAZA", NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77046", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(29, 10, "SLY", "KEN", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "49616710", NULL, NULL, 
NULL, 6, "A", 1)
go

insert into account_contact values(29, 14, "WALL", "CHRIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(29, 15, "GRAMS", "KEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(29, 16, "ROBERTS", "CRAIG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(29, 17, "MCCANNA", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(29, 18, "PETRY", "MARY", NULL, NULL, 
"9 GREENWAY PLAZA", "COASTAL TOWER", NULL, NULL, "HOUSTON", "TX", "USA", 
"77046", NULL, "713-877-6417", NULL, "774254", "7138776752", NULL, NULL, 4, "A", 
1)
go

insert into account_contact values(29, 19, "PUDDY", "MIKE", NULL, NULL, 
"NINE GREENWAY PLAZA", "HOUSTON, TX 77046", NULL, NULL, NULL, "NA", "USA", NULL, 
NULL, "713-877-7491", NULL, "79-0186", "TWX: 910 881 63", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(32, 3, "CALVERT", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "RS50645CII", 
"655360012", NULL, NULL, 6, "A", 1)
go

insert into account_contact values(32, 5, "HIMSWORTH", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(34, 6, "BIXBY", "JOHN A", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(34, 8, "HIMSWORTH", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(34, 9, "PENROSE", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(34, 10, "NICK", "ALLEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(34, 11, "KIRK", "RICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(34, 12, "KEVIN", "LOWE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "408 6018", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(34, 13, "EDWARDS", "PLAYER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0171 - 408 6208", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(34, 14, "WOODS", "PHIL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"011441926404234", NULL, NULL, 5, "A", 1)
go

insert into account_contact values(34, 15, "STANLEY", "NICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(35, 23, "ALBOSTA", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(35, 24, "TIPTON", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7132932009", NULL, NULL, NULL, 
NULL, NULL, 12, "A", 1)
go

insert into account_contact values(35, 25, "ALLEN", "NICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(35, 26, "SHINGLETON", "LOX", NULL, NULL, 
"600 NORTH DAIRY ASHFORD", "P.O. BOX 2197, MA 3051", NULL, NULL, "HOUSTON", 
"TX", "USA", "77252", NULL, "281-293-2010", NULL, "775347", "7132931211", NULL, 
NULL, 6, "A", 1)
go

insert into account_contact values(35, 27, "ADAMS", "JIM", NULL, NULL, 
"P.O. BOX 2197", "600 NORTH DAIRY ASHFORD", NULL, NULL, "HOUSTON", "TX", "USA", 
"77252", NULL, "281-293-2712", NULL, "775347", NULL, NULL, NULL, 2, "A", 1)
go

insert into account_contact values(35, 28, "MONSALVE", "ROMULO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(36, 1, "BRANCKEN", "ROB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(36, 2, "SMETHURST", "STEPHAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(37, 3, "GOOCH", "ANDREW", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(37, 4, "DORFMAN", "CHRIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(37, 5, "SMETHURST", "STEEVE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(37, 6, "LATHAM", "PATRICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(37, 7, "JACKSON", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(37, 8, "SMETHURST", "STEVE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(37, 9, "HOWIE", "ANNIE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(37, 10, "KELLET", "JACK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(37, 11, "KELLETT", "JACK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(37, 12, "GOLDMAN", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(38, 1, "EAKENS", "RANDY", NULL, NULL, 
"4747 BELLAIRE BLVD.", NULL, NULL, NULL, "BELLAIRE", "TX", "USA", "77401", NULL, 
"713-664-6017", NULL, "509504", "713 660 4550", NULL, NULL, 4, "A", 1)
go

insert into account_contact values(38, 2, "MANNERY", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(40, 1, "MARKETING", "BULK", NULL, 
"               OL99       0091", "1990 POST OAK BLVD.", "SUITE 1090", 
"HOUSTON, TX  77056", NULL, "HOUSTON, TX  77056", "NA", "USA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 2, "A", 1)
go

insert into account_contact values(40, 2, "MORALES", "RICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 2, "A", 1)
go

insert into account_contact values(40, 3, "CHRISTMAS", "MARK", NULL, NULL, 
"1990 POST OAK BLVD.", "SUITE 1090", NULL, NULL, "HOUSTON, TX  77056", "NA", 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, "A", 1)
go

insert into account_contact values(40, 4, "GERMICK", "MARTY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7138501599", NULL, NULL, NULL, 
NULL, NULL, 2, "A", 1)
go

insert into account_contact values(41, 15, "MURPHY", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(41, 19, "CLASKY", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(41, 38, "BARRE", "JERRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "203 7618072", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(41, 39, "SON OOI", "CHEE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7705183771", NULL, NULL, NULL, 
NULL, NULL, 6, "A", 1)
go

insert into account_contact values(41, 40, "MCEVOY", "COLIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7705183771", NULL, NULL, NULL, 
NULL, NULL, 6, "A", 1)
go

insert into account_contact values(41, 41, "RINTOUL", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(41, 42, " RINTOUL", "JIM", NULL, NULL, 
"162 QUEEN VICTORIA STREET", NULL, NULL, NULL, "LONDON EC4V 4BS ENGLAND", NULL, 
"GB", "EC4V 4BS", NULL, NULL, NULL, "914570 LDE G", NULL, NULL, NULL, 4, "A", 1)
go

insert into account_contact values(42, 10, "VANDERMULLEN", "JEFF", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713 510 - 2744", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(42, 11, "RANK", "CONLEY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713 510-2744", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(42, 12, "COOPER", "SEAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7135102913", NULL, NULL, NULL, 
NULL, NULL, 3, "A", 1)
go

insert into account_contact values(42, 13, "OTIENO", "JOHN PAUL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7135102819", NULL, NULL, 
NULL, NULL, NULL, 3, "A", 1)
go

insert into account_contact values(42, 14, "PAUL", "WILLIAM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7135102759", NULL, NULL, NULL, 
NULL, NULL, 3, "A", 1)
go

insert into account_contact values(43, 6, "PARADISE", "GARY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(43, 9, "TRABIA", "XAVIER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(43, 10, "FEDELE", "Y", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(43, 11, "CHAPPELLE", "ETIENNE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(44, 1, "VERNAY", "ANNE SOPHIE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "CH", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(44, 2, "CHAPMAN", "KURT", NULL, NULL, 
"WORLD TRADE CENTER", "CASE POSTALE 532", "10, ROUTE DE L'AEROPORT", NULL, 
"10, ROUTE DE L'AEROPORT", "NA", "CH", NULL, NULL, "TEL:(022)710-11", 
"01141227981211", "412147", "415 535 ETS CH", NULL, NULL, 1, "I", 1)
go

insert into account_contact values(44, 3, "STEED", "REX", NULL, NULL, 
"WORLD TRADE CENTER", "CASE POSTALE 532", "10, ROUTE DE L'AEROPORT", NULL, 
"10, ROUTE DE L'AEROPORT", "NA", "CH", NULL, NULL, "TEL:(022)710-11", 
"01141227981211", "412147", "415 535 ETS CH", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(44, 4, "MAKKAWI", "ZIAD", NULL, NULL, 
"WORLD TRADE CENTER", "CASE POSTALE 532", "10, ROUTE DE L'AEROPORT", NULL, 
"10, ROUTE DE L'AEROPORT", "NA", "CH", NULL, NULL, "TEL:(022)710-11", "0", 
"412147", "415 535 ETS CH", NULL, NULL, 1, "I", 1)
go

insert into account_contact values(44, 5, "JORGE", "D'ALMEIDA", NULL, NULL, 
"WORLD TRADE CENTER", "CASE POSTALE 532", "10, ROUTE DE L'AEROPORT", NULL, 
"10, ROUTE DE L'AEROPORT", "NA", "CH", NULL, NULL, "TEL:(022)710-11", "123", 
"415 535", "7101110", NULL, "CONTRACTS", 1, "I", 1)
go

insert into account_contact values(44, 6, "CORDIER", "JEAN", NULL, NULL, 
"WORLD TRADE CENTER", "CASE POSTALE 532", "10, ROUTE DE L'AEROPORT", NULL, 
"10, ROUTE DE L'AEROPORT", "NA", "CH", NULL, NULL, "TEL:(022)710-11", NULL, 
"412147", "415 535 ETS CH", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(44, 7, "DAVOINE", "JACQUES", NULL, NULL, 
"WORLD TRADE CENTER", "CASE POSTALE 532", NULL, NULL, "10, ROUTE DE L'AEROPORT", 
"NA", "CH", NULL, NULL, "TEL:(022)710-11", NULL, "412147", "415 535 ETS CH", 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(44, 8, "D'ALMEIDA", "JORGE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "I", 1)
go

insert into account_contact values(44, 9, "GIRARD", "XXXXX", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(44, 10, "BRECHET", "PHILLIPE", NULL, NULL, 
"10, ROUTE DE L'AEROPORT", "CASE POSTALE 532", NULL, NULL, "CH 1215 GENEVA", 
"NA", "CH", NULL, NULL, "708-818-1800", NULL, "412147", "415 535 ETS CH", NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(44, 11, "GUILLEBON", "VALERY", NULL, NULL, 
"10, ROUTE DE L'AEROPORT", "CASE POSTALE 532", NULL, NULL, "CH 1215 GENEVA", 
"NA", "CH", NULL, NULL, "708-818-1800", NULL, "412147", "415 535 ETS CH", NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(44, 12, "TREBIA", "XAVIER", NULL, 
"CRUDE OIL DEPT", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "845415535", NULL, NULL, "CONTRACTS", 1, "A", 1)
go

insert into account_contact values(44, 13, "JORGE", "D'ALMEIDA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(44, 14, "SOKEL", "STUART", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(44, 15, "ABADIE", "OLIVIER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "I", 1)
go

insert into account_contact values(44, 16, "SHOLES", "CLAIRE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "41.22.710.1201", NULL, 
"415535", "41227101110", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(44, 17, "AITKEN", "PETER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(44, 18, "MARC", "JOHN", NULL, NULL, 
"10, ROUTE DE L'AEROPORT", "CASE POSTALE 532", NULL, "CH 1215 GENEVA", 
"GENEVA, SWITZERLAND", "NA", "CH", NULL, NULL, NULL, NULL, "415535", "7101110", 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(44, 19, "VIAL", "ERIC", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(44, 20, "CHANG", "CHARMIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(44, 21, "SPEICH-COUTTET", "SOPHIE", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "41227101315", NULL, 
NULL, "41227101110", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(44, 22, "YING", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(44, 23, "BONALUMI", "MICHAEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(44, 24, "GIRARD", "JACQUES", NULL, NULL, 
"10, ROUTE DE L'AEROPORT", "CASE POSTALE 276", NULL, "CH 1215 GENEVA", 
"GENEVA, SWITZERLAND", "NA", "CH", NULL, NULL, NULL, NULL, "415535", 
" 41227031110", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(44, 25, "CARLE", "JEAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(44, 26, "TAN", "CHARK HOE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(44, 27, "ELZIR", "ANTOINE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(44, 28, "SCHUMACHER", "DINA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(44, 29, "STERNBERG", "JM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(44, 30, "SIEW", "EDWIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(44, 31, "D'ALAEIDA", "GEORGE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(44, 32, "BANFIELD", "N", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(44, 33, "STERNBERG", "JEAN-MATTIEU", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(44, 34, "BROWN", "SCOTT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(44, 35, "VOURC'H", "NILS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(44, 36, "TENNANT", "STACEY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(44, 37, "ORTI", "JOSE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0033147445153", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(44, 38, "TJANDERMAGA", "NICOLAS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(44, 39, "CHRISTIAN", "SABATINI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(44, 40, "SPITZ", "MICHAELA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "41 22 710 1655", NULL, 
NULL, "41 22 710 1110", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(45, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0719254000", NULL, "8950611", 
"0719254321", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(46, 2, "HAINES", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(46, 3, "SPRATT", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(46, 4, "PANZA", "MARK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(46, 5, "BJORN", "BERGESEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "01372 223929", NULL, NULL, 
NULL, NULL, NULL, NULL, "I", 1)
go

insert into account_contact values(46, 6, "NORTH KERR", "TED BURKE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 4, "A", 1)
go

insert into account_contact values(48, 2, "HAINES", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(48, 3, "PANZA", "MARK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(48, 4, "ELLIS", "KEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 2, "A", 1)
go

insert into account_contact values(48, 5, "BOB", "WEBB", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "01372222924", NULL, NULL, "x", NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(48, 6, "BALLARD", "KERRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "01372 223470", NULL, NULL, 
"01372 223452", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(48, 7, "BIENEFELT", "ILSE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "171 412 2359", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(49, 1, "CAYLA", "JEAN FRANCOIS", NULL, 
"OPERATIONAL CONTACT", NULL, NULL, NULL, NULL, NULL, NULL, "F", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(50, 1, "J", "T", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(50, 2, "J", "T", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(50, 3, "PERSOHN", "ANNETT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(50, 4, "WAHL", "ERIC", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(51, 11, "DIXON", "PETE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(52, 4, "BRADDOCK", "DEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(52, 5, "BURTON", "LEONARD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(52, 9, "ADAM", "LOUIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(52, 10, "QUINN", "PATRICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "9136810137", "8164595131", NULL, 
NULL, "8164595944", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(52, 11, "SENECAUT", "RICHARD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "9134927919", "8164596738", 
NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(52, 12, "PAJNIC", "LINDA", NULL, NULL, 
"3315 NORTH OAK TRAFFICWAY", NULL, NULL, NULL, "KANSAS CITY", "MO", "USA", 
"64116", NULL, NULL, NULL, "981305", "8164595944", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(52, 13, "KURWIN", "TIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(53, 1, "HINSEY", "JOHN", NULL, NULL, 
"16800 GREENSPOINT PARK DRIVE", "SUITE 225, SOUTH ATRIUM", NULL, NULL, 
"HOUSTON, TX 77060", "NA", "USA", NULL, NULL, "713-874-9494", NULL, 
"FAX: 713-874-95", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(53, 2, "LEAHY", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(53, 3, "GAUTIER", "LARRY", NULL, NULL, 
"16800 GREENSPOINT PARK DRIVE", "SUITE 225, SOUTH ATRIUM", NULL, NULL, 
"HOUSTON, TX 77060", "NA", "USA", NULL, NULL, NULL, NULL, "FAX: 713-874-95", 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(54, 4, "HILL", "AUDREA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "214.890.1978", NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(54, 5, "BERRY", "CLIFT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(54, 20, "SHAW", "BLAKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(54, 21, "TOM", "KNIGHT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(55, 1, "HILL", "AUDRIA", NULL, 
"NATURAL GAS DEPT.", "8350 NORTH CENTRAL EXPRESSWAY", "DALLAS, TEXAS", NULL, 
NULL, NULL, "NA", "USA", "75206", NULL, NULL, "214.890.1978", NULL, 
"2147504185", NULL, "CONTRACTS", 1, "A", 1)
go

insert into account_contact values(55, 3, "HECTOR", "WILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "214.750.2356", NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(55, 4, "SHADE", "KEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(55, 5, " VAN DE BOOM", "WILL", NULL, NULL, 
"8350 NORTH CENTRAL EXPRESSWAY", "DALLAS, TEXAS", NULL, NULL, NULL, "NA", "USA", 
"75206", NULL, NULL, "214-890-1158", "FAX: 214-750-25", NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(55, 6, "GANAWAY", "BYRON", NULL, NULL, 
"8350 NORTH CENTRAL EXPRESSWAY", "DALLAS, TEXAS", NULL, NULL, NULL, "NA", "USA", 
"75206", NULL, NULL, NULL, "FAX: 214-750-25", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(55, 7, "MCFAIL", "LISA", NULL, NULL, 
"8350 NORTH CENTRAL EXPRESSWAY", NULL, NULL, NULL, "DALLAS", "TX", "USA", 
"75206", NULL, NULL, NULL, NULL, "2147504185", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(55, 8, "MARTIN", "DEBBIE", NULL, NULL, 
"8350 NORTH CENTRAL EXPRESSWAY", NULL, NULL, NULL, "DALLAS", "TX", "USA", 
"75206", NULL, NULL, NULL, NULL, "2147504185", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(55, 9, "HARRINGTON", "VALERIE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "214-706-4236", NULL, 
NULL, "214-890-1196", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(56, 1, "DE  STEFANO", "ENRICO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(56, 2, "O'SHEA", "GERRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(56, 4, "MASEK", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(56, 5, "KOLLER", "ROSS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(56, 6, "BARBIR", "TARIK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(56, 7, "WONG", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(57, 1, "MCMANN", "LISA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "01642432215", NULL, 
"587202  ICIKLM", NULL, NULL, NULL, 2, "A", 1)
go

insert into account_contact values(57, 2, "DOWNING", "D", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(57, 3, "HOLMES", "KEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(58, 1, "FAHEY", "SEAMUS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(59, 6, "HIROMATSU", "T", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "44 207 638 4018", NULL, NULL, 
"44 207 638 4019", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(59, 8, "TAHARA", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(59, 9, "HIROMATSU", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(59, 10, "KOMIYAMA", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(59, 13, "MR.", "YASUDA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(59, 14, "YASUDA", "TAKASHI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(59, 15, "RICHARD", "NG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(60, 2, "WILLIAMS", "R", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(60, 6, "LIM", "STEVEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(60, 7, "COOK", "TERRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(61, 3, "HASEBE", "SHINYA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(61, 4, "YASUDA", "TAKASHI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(61, 5, "HIROMATSU", "TOMOYUKI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "81-3497-6617", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(61, 6, "OOBA", "SHUNSUKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "813-3497-6602", NULL, 
"RS 21275 ITOCHU", "813-3497-6514", NULL, NULL, 6, "A", 1)
go

insert into account_contact values(61, 7, "ITOCHU", "HK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(62, 11, "WARFORD", "CHUCK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-739-4536", NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(62, 13, "PAUL", "BUTCHER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(62, 17, "KAISER", "BRIAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(62, 19, "THONG", "CHU SAID", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(62, 20, "EATON", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(62, 22, "HARRISON", "TOBY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(62, 23, "SCHAFFER", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(62, 25, "LARUE", "ROD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(62, 27, "FLEMING", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(62, 28, "CHU", "SEID THONG", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(62, 29, "MILLER", "KAY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3168284382", NULL, NULL, 
"3168287977", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(62, 30, "PISANI", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(62, 31, "DOWNING", "D", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(62, 32, "KOMINSKI", "MARK", NULL, NULL, 
"2ND FLOOR, KIERRAN CROSS", "11 STRAND", NULL, NULL, "LONDON WC2N 5HR", NULL, 
"GB", NULL, NULL, NULL, NULL, "263173", "44 171 839 2086", NULL, NULL, 76, "A", 
1)
go

insert into account_contact values(62, 33, "EGELAND", "FRODE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(63, 11, "BUTCHER", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(63, 12, "CRENSHAW", "KIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3168288013", NULL, NULL, 
"3168327977", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(63, 13, "HARRISON", "TOBY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3168283888", NULL, NULL, NULL, 
NULL, NULL, 3, "A", 1)
go

insert into account_contact values(63, 14, "LARUE", "ROD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3168285365", NULL, NULL, NULL, 
NULL, NULL, 3, "A", 1)
go

insert into account_contact values(63, 15, "WITTENBERG", "DOUG", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7132296063", NULL, NULL, 
NULL, NULL, NULL, 3, "A", 1)
go

insert into account_contact values(63, 16, "MARTLAND", "JONATHAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(63, 17, "WYMAN", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(63, 18, "HAMILTON", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(64, 1, "WEI MIN", "WUAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(65, 9, "MARTIN", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(65, 12, "MR", "KEVIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "918-582-7288", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(66, 13, "MCCLEAVE", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(66, 15, "MENDEL", "DICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7132962450", 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(66, 16, "GOULD", "BRYANT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-296-2457", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(66, 17, "BRADLEY", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "01712982526", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(66, 18, "UNGER", "VINCE", NULL, NULL, 
"539 SOUTH MAIN STREET", NULL, NULL, NULL, "FINDLAY", "OH", "USA", "45840", 
NULL, "419-421-2600", NULL, "196230", "4194257040", NULL, NULL, 10, "A", 1)
go

insert into account_contact values(66, 19, "BERGER", "DAVID", NULL, NULL, 
"5555 SAN FELIPE", NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77056", NULL, 
NULL, NULL, "792069", "4194257040", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(66, 20, "SCHLEIMER", "ALAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-296-3724", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(69, 1, "FAX:629-4160", "LONDON", NULL, 
"               OL99       0091", "CHAMERSTRASSE 50", NULL, 
"CH-6300  ZUG, SWITZERLAND", NULL, "CH-6300  ZUG, SWITZERLAND", "NA", "GB", 
NULL, NULL, NULL, NULL, "862379", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(69, 2, "NORTON", "RUSSELL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(69, 3, "EXL", "THOMAS M.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(70, 9, "PANIS", "PETER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(70, 10, "FOLEY", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(70, 11, "WALKER", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(70, 12, "TOTH", "MICHELE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2124494336", NULL, NULL, 
"2124494309", NULL, NULL, 5, "A", 1)
go

insert into account_contact values(70, 13, "MALDONADO", "DIANA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2124497562", NULL, NULL, 
"2124494309", NULL, NULL, 5, "A", 1)
go

insert into account_contact values(70, 14, "FOX", "CHERYL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2124490401", NULL, NULL, 
"2124494309", NULL, NULL, 5, "A", 1)
go

insert into account_contact values(70, 15, "JACOBS", "PETER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2124497051", NULL, NULL, NULL, 
NULL, NULL, 2, "A", 1)
go

insert into account_contact values(71, 11, "BRATTLOF", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(71, 12, "GRAYSON", "JOHN", NULL, NULL, 
"HOUSTON, TX", NULL, NULL, NULL, "HOUSTON", "TX", "USA", NULL, NULL, NULL, NULL, 
"TLX 765265", NULL, NULL, NULL, 72, "A", 1)
go

insert into account_contact values(71, 13, "FRECKE", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "281-775-8900", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(72, 7, "KAMOSAKI", "M", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(72, 9, "TAMATSUKURI", "M", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(72, 10, "KAMOSAKI", "AKIRA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(72, 11, "TAMATSUKURI", "SHINTARO", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(72, 12, "TAKAGI", "YUGI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 2, "A", 1)
go

insert into account_contact values(73, 1, "LEVENSTEIN", "MARK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(74, 8, "KENT", "JIM", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "703-846-6750", NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(74, 9, "MILLER", "TODD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(74, 10, "KACHER", "FRED", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(74, 31, "MARTENAK", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(74, 32, "BROWER", "KURT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(74, 33, "LEVENSTEIN", "MARK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(74, 34, "WEAVER", "KEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(74, 35, "FILLMYR", "STEVE", NULL, NULL, 
"3225 GALLOWS ROAD", NULL, NULL, NULL, "FAIRFAX", "VA", "USA", "22037-000", 
NULL, NULL, NULL, "232561", "7108330372", NULL, NULL, 5, "A", 1)
go

insert into account_contact values(74, 36, "DAVIS", "PAUL", NULL, NULL, 
"3225 GALLOWS ROAD", NULL, NULL, NULL, "FAIRFAX", "VA", "USA", "22037-000", 
NULL, NULL, NULL, "232561", "7108330372", NULL, NULL, 5, "A", 1)
go

insert into account_contact values(74, 37, "WOLF", "BOB", NULL, NULL, 
"3225 GALLOWS ROAD", NULL, NULL, NULL, "FAIRFAX", "VA", "USA", "22037-000", 
NULL, "703-846-6736", NULL, "232561", "7108330372", NULL, NULL, 5, "A", 1)
go

insert into account_contact values(74, 38, "BOBENAGE", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(75, 1, "MARKETING", "BULK", NULL, 
"               OL99       0091", "MOBIL COURT", "3 CLEMENTS INN", 
"LONDON ,ENGLAND", NULL, "LONDON ,ENGLAND", "NA", "GB", "WC2A 2EB", NULL, NULL, 
NULL, "8812411", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(75, 2, "KENT", "JIM", NULL, NULL, 
"MOBIL COURT", "3 CLEMENTS INN", NULL, NULL, "LONDON ,ENGLAND", "NA", "GB", 
"WC2A 2EB", NULL, NULL, "703-846-6788", "8812411", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(75, 3, "RUDD", "JOE", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(75, 4, "GUSTOVSON", "MIKE", NULL, NULL, 
"MOBIL COURT", "3 CLEMENTS INN", NULL, NULL, "LONDON ,ENGLAND", "NA", "GB", 
"WC2A 2EB", NULL, NULL, NULL, "8812411", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(75, 5, "NESBIT", "BUTCH", NULL, NULL, 
"MOBIL COURT", "3 CLEMENTS INN", NULL, NULL, "LONDON ,ENGLAND", "NA", "GB", 
"WC2A 2EB", NULL, NULL, NULL, "8812411", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(75, 6, "PERRELLE", "CYRIELLE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "8812411", 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(75, 7, "GRIFFIN", "GRAHAM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(75, 8, "LEVENSTEIN", "MARK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(76, 8, "MENG", "LEE YEE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(76, 9, "SMITH", "PHIL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(76, 14, "FISHER", "B", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(76, 18, "MASTERS", "DANIEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(76, 21, "HANSJEE", "NAMESH", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(76, 22, "BAILEY", "VANCE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2126484237", NULL, NULL, 
"2126485601/5168", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(76, 23, "BITTNER", "PAT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2126484021", NULL, NULL, 
"2126485601", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(76, 24, "ERICSSON", "LARS", NULL, NULL, 
"60 VICTORIA EMBANKMENT", "P.O.BOX 161", "LONDON EC4Y OJP", NULL, "LONDON", 
NULL, "GB", NULL, NULL, NULL, NULL, "896631", NULL, NULL, NULL, 5, "A", 1)
go

insert into account_contact values(76, 25, "PHAIR", "IAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(76, 26, "MOONEY", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(76, 27, "FILDES", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(76, 28, "DEMARTINO", "TONY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(77, 1, "RUCK", "TOM", NULL, NULL, 
"60 WALL STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10260", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(77, 2, "MASTERS", "DANNY", NULL, 
"CRUDE OIL DEPT", "60 WALL STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", 
"10260", NULL, NULL, NULL, "6734137", NULL, NULL, "CONTRACTS", 1, "A", 1)
go

insert into account_contact values(77, 3, "NEWTON", "RUSS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(77, 4, "CANNON", "TIM", NULL, 
"CRUDE OIL DEPT", "60 WALL STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", 
"10260", NULL, NULL, "212-648-2166", "6734137", NULL, NULL, "CONTRACTS", 1, "A", 
1)
go

insert into account_contact values(77, 5, "SMITH", "PHILLIP", NULL, NULL, 
"60 WALL STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10260", NULL, 
NULL, NULL, "212 837 5930", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(77, 6, "RETSINE", "MITCH", NULL, NULL, 
"60 WALL STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10260", NULL, 
NULL, NULL, "212 837 5930", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(77, 7, "HOOPER", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(77, 8, "FISHER", "B", NULL, NULL, 
"60 WALL STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10260", NULL, 
NULL, NULL, "6734137", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(77, 9, "FIORELLO", "JOHN", NULL, NULL, 
"60 WALL STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10260", NULL, 
NULL, NULL, "6734137", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(77, 10, "FRANCE", "KELLY", NULL, NULL, 
"60 WALL STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10260", NULL, 
NULL, NULL, "6734137", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(77, 11, "SWEENEY", "DOUG", NULL, NULL, 
"60 WALL STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10260", NULL, 
NULL, NULL, "6734137", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(77, 12, "FAIR", "IAN", NULL, NULL, 
"60 WALL STREET", NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10260", NULL, 
NULL, NULL, "6734137", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(78, 11, "LORD", "TIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 22, "EVERS", "ALAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 23, "CHILD", "TIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 25, "LIBMAN", "BORIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 26, "KAMINS", "H", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 28, "VOELKER", "HEIKO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 29, "BAIARDI", "PETER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2127615746", NULL, NULL, 
"2127610294/3", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(78, 30, "BARON", "SUSAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2127615878", NULL, NULL, 
"2127610294", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(78, 31, "GARY", "KING", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 32, "WISE", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 33, "WISE", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 34, "WYSE", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 35, "BRENNAN", "MICHAEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(78, 36, "VONDERHEIDE", "M", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 37, "KURODA", "A", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 38, "KOH", "ALAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 39, "KHOSLA", "SANJIV", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 40, "MCMILLAN", "ANDREW", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(78, 41, "WISE", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 42, "SETO", "RICHARD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 43, "MILLER", "TODD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 44, "JONES", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 3, "A", 1)
go

insert into account_contact values(78, 45, "TEED", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 46, "KONGSIRI", "DENNIS", NULL, NULL, 
"1585 BROADWAY", "COMMODITIES 4TH FLOOR", NULL, NULL, "NEW YORK", "NY", "USA", 
"10036", NULL, "(65) 439-6902", NULL, NULL, "2127610292", NULL, NULL, 4, "A", 1)
go

insert into account_contact values(78, 47, "RANKIN", "CHARLES", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(78, 48, "EISENSTEIN", "IRA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(78, 49, "DUTTON", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 50, "GUPTA", "AMIT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(78, 51, "SUMMERS", "ANNE", NULL, NULL, 
"1221 AVENUE OF THE AMERICAS", "COMMODITIES DEPT - 5TH FLOOR", NULL, NULL, 
"NEW YORK", "NY", "USA", "10020", NULL, "(212)  761-8785", NULL, "6801347", 
NULL, NULL, NULL, 3, "A", 1)
go

insert into account_contact values(79, 7, "HO", "LARRY", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(79, 8, "KING", "GARY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(79, 9, "LEONG", "MICHAEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "654396900", NULL, "RS28299", 
"654396968", NULL, NULL, 4, "A", 1)
go

insert into account_contact values(79, 10, "WISE", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2127615916", NULL, NULL, NULL, 
NULL, NULL, 3, "A", 1)
go

insert into account_contact values(79, 11, "SETO", "RICH", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2127615910", NULL, NULL, NULL, 
NULL, NULL, 3, "A", 1)
go

insert into account_contact values(79, 12, "REFVIK", "OLAV", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2127615914", NULL, NULL, NULL, 
NULL, NULL, 3, "A", 1)
go

insert into account_contact values(79, 13, "MILLER", "TODD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2127615915", NULL, NULL, NULL, 
NULL, NULL, 3, "A", 1)
go

insert into account_contact values(79, 14, "ADAMS", "CHARLIE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2127618750", NULL, NULL, NULL, 
NULL, NULL, 3, "A", 1)
go

insert into account_contact values(79, 15, "VONDERHEIDE", "MARK", NULL, NULL, 
"1251 AVENUE OF THE AMERICAS", NULL, NULL, NULL, "NEW YORK", "NY", "USA", 
"10020", NULL, NULL, NULL, NULL, "2122962487", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(79, 16, "JONES", "STEVE", NULL, NULL, 
"MORGAN STANLEY INTERNATIONAL
", NULL, NULL, NULL, "LONDON", NULL, "GB", NULL, 
NULL, NULL, NULL, NULL, "01144715137648", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(79, 17, "TRAPP", "GORAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(79, 18, "GUPTA", "AMIT", NULL, NULL, 
"1251 AVENUE OF THE AMERICAS", NULL, NULL, NULL, "NEW YORK", "NY", "USA", 
"10020", NULL, NULL, NULL, NULL, "2122962487", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(79, 19, "TEED", "DAVID", NULL, NULL, 
"1251 AVENUE OF THE AMERICAS", NULL, NULL, NULL, "NEW YORK", "NY", "USA", 
"10020", NULL, NULL, NULL, NULL, "2122962487", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(80, 1, "BOHNENBLUST", "DAVE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3162418213", "3162419240", 
NULL, "6736745", "7136213055", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(80, 2, "BERGEN", "MELVIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3165852271", "3162419232", NULL, 
"6736745", "7136213055", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(80, 3, "SINNETT", "JEFF", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(81, 10, "KARPPINEN", "RISTO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(81, 12, "NEW", "MANDY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(81, 14, "VAN", "TIEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(81, 23, "TAN", "CHAD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(81, 24, "LAMBERT", "MIKA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(81, 25, "ROHNER", "KURT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(81, 26, "PURHO", "PEKKA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "125867", NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(81, 27, "PLYMELL", "JEFF", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3765325", 
"7134074480", NULL, NULL, 74, "A", 1)
go

insert into account_contact values(81, 28, "CHWEE JUAN", "HAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "RS78625771", 
"652233246", NULL, NULL, 5, "A", 1)
go

insert into account_contact values(81, 29, "HIDALGO", "AMALIO", NULL, NULL, 
"30 CHARLES 11 STREET", "ST. JAMES'S SQUARE", NULL, NULL, "LONDON", NULL, "UK", 
"SW1Y 4AE", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 75, "A", 1)
go

insert into account_contact values(81, 30, "HICKEY", "MIKE", NULL, NULL, 
"30 CHARLES 11 STREET", "ST. JAMES'S SQUARE", NULL, NULL, "LONDON", NULL, "UK", 
"SW1Y 4AE", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 75, "A", 1)
go

insert into account_contact values(81, 31, "JOKINEN", "TIMO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(82, 1, "EINAR", "LIE", NULL, NULL, 
"DRAMMENSVEIEN 264", NULL, "N-1321 STABEKK   NORWAY", NULL, 
"N-1321 STABEKK   NORWAY", "NA", "N", NULL, NULL, NULL, "273 9385", 
"76288  HYDRO N", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(82, 2, "DAMMEN", "HEGE", NULL, NULL, 
"DRAMMENSVEIEN 264", NULL, "N-1321 STABEKK   NORWAY", NULL, 
"N-1321 STABEKK   NORWAY", "NA", "N", NULL, NULL, NULL, NULL, "76288  HYDRO N", 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(82, 3, "BJORN", "NOREN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(82, 4, "THOMSETH", "KNUT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(82, 5, "MORTENSON", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(85, 1, "LANSFORD", "KYLE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2815394560", NULL, NULL, NULL, 
NULL, NULL, 2, "A", 1)
go

insert into account_contact values(85, 2, "CRAIG", "DEAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2815394595", NULL, NULL, NULL, 
NULL, NULL, 2, "A", 1)
go

insert into account_contact values(85, 3, "FRASIER", "MATT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2815394525", NULL, NULL, NULL, 
NULL, NULL, 2, "A", 1)
go

insert into account_contact values(85, 4, "MCGRANE", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(86, 14, "VANDERGRAF", "HANK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "I", 1)
go

insert into account_contact values(86, 16, "SPROTT", "DAVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(86, 17, "HOUGLAND", "SAM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "303-773-8570", NULL, NULL, 
NULL, NULL, NULL, NULL, "I", 1)
go

insert into account_contact values(86, 18, "SPROTT", "DAVID", NULL, NULL, 
"49B CHEMIN D'EYSINS", NULL, NULL, NULL, "CH-1260 NYON, VORD", NULL, "CH", NULL, 
NULL, NULL, NULL, "419705", "41 22 3629656", NULL, NULL, 5, "A", 1)
go

insert into account_contact values(87, 1, "MARKETING", "BULK", NULL, 
"               OL99       0091", "C/O AVIN OIL ANSTALT", "8 XENOFONTOS STREET", 
"ATHENS 10557", NULL, "ATHENS 10557", "NA", "GR", NULL, NULL, NULL, NULL, 
"219411", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(87, 2, "WATSON", "MIKE", NULL, NULL, 
"C/O AVIN OIL ANSTALT", "8 XENOFONTOS STREET", "ATHENS 10557", NULL, 
"ATHENS 10557", "NA", "GR", NULL, NULL, NULL, "01144714957484", "219411", NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(87, 3, "CHAMBERLAIN", "JEREMY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(87, 4, "SAUNDERS", "JEREMY", NULL, NULL, 
"C/O AVIN OIL ANSTALT", "8 XENOFONTOS STREET", NULL, NULL, "ATHENS 10557", "NA", 
"GR", NULL, NULL, NULL, NULL, "219411", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(88, 1, "MARKETING", "BULK", NULL, 
"               OL99       0091", NULL, NULL, NULL, NULL, NULL, NULL, "S", NULL, 
NULL, NULL, NULL, "12892", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(88, 2, "ANNA LENA", "MAX", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(88, 3, "VIKINGSON", "LARS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(88, 4, "EKMANN", "PETER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(88, 5, "JOHANNSEN", "GUNNAR", NULL, NULL, 
"WARFVINGES VAG 25", NULL, NULL, NULL, "S-11291 STOCKHOLM", "NA", "S", NULL, 
NULL, NULL, NULL, "12892", "6609021", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(88, 6, "WALLENBERT", "MAGNUS", NULL, NULL, 
"SANDHAMNSGATAN 51", "S-115 90 STOCKHOLM", NULL, NULL, "STOCKHOLM", NULL, "S", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, "A", 1)
go

insert into account_contact values(88, 7, "MELLANDER", "YVONNE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+46 8 450 1000", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(88, 8, "LARSSON", "EIVOR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0046 8 450 1090", NULL, NULL, 
"0046 8 662 7894", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(89, 1, "MCCLUER", "RAY", NULL, 
"               OL99       0091", "444 MARKET STREET, ROOM 5204", 
"SAN FRANCISCO, CA. 94111", NULL, NULL, NULL, "NA", "USA", NULL, "415-973-2257", 
NULL, NULL, "FAX: 415-973-92", NULL, NULL, NULL, 1, "I", 1)
go

insert into account_contact values(90, 3, "CHAPELLE", "ETIENNE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(90, 4, "BELEVITCH", "ANIOUTA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(90, 5, "BLONDEL", "FRANCOIS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(90, 6, "CLAES", "BERNARD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(90, 7, "DAEMS", "HANS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0032 2 288 3631", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(91, 1, "SHANGER", "INGA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(91, 2, "GLEAVE", "FRANK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(91, 3, "HOWELLS", "WILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(91, 4, "KUNZ", "JURG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(91, 5, "GOETSCH", "FREDDY", NULL, NULL, 
"CAYMAN ISLANDS", "C/O EPS SERVICES SA AS AGENTS", "3 QUAI DU MONT BLANC", 
"BP 1457", "1211 GENEVA,  SWITZERLAND", NULL, "CH", NULL, NULL, 
"41 22 909 1617", NULL, NULL, "41 22 909 1680", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(92, 6, "LYNN", "KEN", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(92, 7, "SHAW", "MALCOLM", NULL, NULL, 
"611 ADAMS BUILDING", NULL, NULL, NULL, "BARTVILLE", "OK", "USA", "74004", NULL, 
"918-661-4171", NULL, "49-2455", "FAX: 918-661-08", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(93, 1, "MARK MATTHEISEN", "MR.", NULL, 
"               OL99       0091", "35 GUILDFORD ROAD", "WOKING SURREY", 
"GU22 7QT", NULL, "GU22 7QT", "NA", "GB", NULL, "0483 756666", NULL, NULL, 
"859763", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(93, 2, "BELL", "SARAH", NULL, NULL, 
"35 GUILDFORD ROAD", "WOKING SURREY", NULL, NULL, "GU22 7QT", "NA", "GB", NULL, 
NULL, "0483 756666", NULL, "859763", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(94, 1, "BALZER", "DORIS", NULL, NULL, 
"22 CARLISLE PLACE", "LONDON, ENGLAND", "SW1P 1JA", NULL, "SW1P 1JA", "NA", 
"GB", NULL, NULL, "TEL 233 5377", "0", "918470 RO UK", "FAX 233 6743", NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(94, 2, "DAVIDSON", "RON", NULL, NULL, 
"22 CARLISLE PLACE", "LONDON, ENGLAND", NULL, NULL, "SW1P 1JA", "NA", "GB", 
NULL, NULL, "TEL 233 5377", NULL, "918470 RO UK", "FAX 233 6743", NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(94, 3, "NEWTON", "RUS", NULL, NULL, 
"22 CARLISLE PLACE", "LONDON, ENGLAND", NULL, NULL, "SW1P 1JA", "NA", "GB", 
NULL, NULL, "TEL 233 5377", NULL, "918470 RO UK", "FAX 233 6743", NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(94, 4, "BAINBRIDGE", "ROWAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(94, 5, "JAMESON", "DON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "901144171233537", NULL, 
"918470 RO UK G", "901144171233674", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(95, 7, "HEUZE", "JEAN-CLAUDE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "I", 1)
go

insert into account_contact values(95, 11, "HOBBS", "MICHAEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 12, "CATTON", "MARK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 13, "BEARD", "ALEX", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 14, "ALVAREZ", "LEWIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 16, "WATERS", "SIMON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 17, "LIM", "CHEE KEONG", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "I", 1)
go

insert into account_contact values(95, 18, "YANG", "CHEONG SHUN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "I", 1)
go

insert into account_contact values(95, 19, "FRANKS", "NIEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 20, "HO", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 21, "UJO", "USMANTO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 22, "TOH", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 23, "OZAK", "RAYBART", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 24, "BARTOSZEK", "RAY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 25, "NICHOLS", "SUE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 26, "DOWNING", "D", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 27, "YASS", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(95, 28, "TARIQ", "BARBIRA", NULL, NULL, 
"49 WIGMORE STREET", NULL, NULL, NULL, "LONDON", NULL, "GB", "WHL 9LE", NULL, 
"0171-4123212", NULL, "85121223", "441714123189", NULL, NULL, 2, "I", 1)
go

insert into account_contact values(95, 29, "ZADORA", "MICHELLE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(96, 1, "MARTIN", "RAY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(96, 2, "HAUGHMANN", "THOR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(97, 22, "HAHN", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(97, 23, "TAYLOR", "JONATHAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(97, 25, "JEVONS", "DOMINIC", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(97, 26, "WILLIAMS", "JONATHAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2125268781", NULL, NULL, 
"2125286865", NULL, NULL, 73, "A", 1)
go

insert into account_contact values(97, 27, "GILMORE", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "011441712602652", NULL, NULL, 
"011441712602933", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(98, 1, "MARKETING", "BULK", NULL, 
"               OL99       0091", "THE STRAND", "P.O. BOX 148", 
"LONDON WC2R ODX", NULL, "LONDON WC2R ODX", "NA", "GB", NULL, NULL, NULL, NULL, 
"22585", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(98, 2, "NEWTON", "RUSS", NULL, NULL, 
"THE STRAND", "P.O. BOX 148", "LONDON WC2R ODX", NULL, "LONDON WC2R ODX", "NA", 
"GB", NULL, NULL, NULL, "0", "22585", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(98, 3, "MILLWARD", "ANDREW", NULL, NULL, 
"THE STRAND", "P.O. BOX 148", "LONDON WC2R ODX", NULL, "LONDON WC2R ODX", "NA", 
"GB", NULL, NULL, NULL, "257 1886", "22585", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(98, 4, "KEITH", "DAVIES", NULL, NULL, 
"THE STRAND", "P.O. BOX 148", "LONDON WC2R ODX", NULL, "LONDON WC2R ODX", "NA", 
"GB", NULL, NULL, NULL, "257 1886", "22585", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(98, 5, "QUARTERMAIN", "MARK", NULL, NULL, 
"STRAND", NULL, "LONDON WC2R ODX", NULL, "LONDON WC2R ODX", "NA", "GB", NULL, 
NULL, NULL, NULL, "22585 SHELL G", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(98, 6, "HOWARD", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "24662", NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(98, 7, "SAUNDERS", "JEREMY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(98, 8, "HARTREE", "ANDREW", NULL, NULL, 
"SHELL-MEX HOUSE", "STRAND", NULL, NULL, "LONDON WC2R ODX", "NA", "UK", NULL, 
NULL, NULL, NULL, "22585 SHELL G", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(98, 9, "DOCKERY", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "UK", NULL, NULL, "44 171 5463756", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(98, 10, "ROWLES", "ADAM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "44 171 5462287", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(98, 11, "HOWARTS UOTS1211", "DAVID SWAP", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"44-171-257-1430", NULL, NULL, "44-171-257-1340", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(98, 12, "TAYLOR UOTS1733", "EDNA SWAPS", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"44-171-257-1468", NULL, NULL, "44-171-257-1340", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(98, 13, "O' CONNOR", "JOHN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(98, 14, "RIMBEY", "TYLER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(98, 15, "CATTERALL", "NIGEL", NULL, NULL, 
"SHELL-MEX HOUSE", "STRAND", NULL, NULL, "LONDON WC2R ODX", NULL, "UK", NULL, 
NULL, NULL, NULL, "24661 SHELL G", "44 171 546 5666", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(99, 15, "SHARP", "LARRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(99, 16, "GILTON", "MICHAEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(99, 19, "FALKENBURY", "JEFF", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(99, 24, "CARLSEN", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(99, 25, "TRGOVICH", "MARK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "762248", 
"7132410004", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(99, 26, "BUTLER", "HILTON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(99, 27, "WOLFE", "RICK", NULL, NULL, 
"P.O. BOX 2463", NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77252", NULL, 
"713-241-6034", NULL, "762248", "7132410004", NULL, NULL, 6, "A", 1)
go

insert into account_contact values(99, 28, "MANTTUK", "MARIO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "011-511-224-161", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(99, 29, "WRIGHT", "DAVE", NULL, NULL, 
"ONE SHELL PLAZA", "910 LOUISIANA", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, "713-241-3446", NULL, "762248", "7132410004", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(99, 30, "JUE", "TINGATE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(99, 31, "DIMASELI", "PETE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(99, 32, "LLYOD", "GARRISON", NULL, NULL, 
"ONE SHELL PLAZA", "910 LOUISIANA", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, "713-555-1212", NULL, "762248", NULL, NULL, NULL, 2, "A", 1)
go

insert into account_contact values(100, 1, "GUITTON", "NADINE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "33147446674", NULL, 
"615585", NULL, NULL, NULL, 3, "A", 1)
go

insert into account_contact values(100, 2, "STERNBERG", "JEAN-MATTIEU", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(101, 3, "DEVELIOTTE", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(101, 4, "XXXXXX", "XXXXX", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "33142137115", NULL, 
"33142136548", "33142136812", NULL, NULL, 5, "A", 1)
go

insert into account_contact values(101, 5, "RAEVEL", "O", NULL, NULL, 
"1221 AVENUE OF THE AMERICAS", "11 FL. IBG/COMMODITIES", NULL, NULL, "NEW YORK", 
"NY", "USA", "10020", NULL, NULL, NULL, NULL, "2122787462", NULL, NULL, 6, "A", 
1)
go

insert into account_contact values(101, 6, "REILLY", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(101, 7, "DEGAN", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(101, 8, "LARAISON", "PHILIPPE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "33-142-134-892", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(101, 9, "G", "FEFQUEST", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(101, 10, "MALKA", "JEROME", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(102, 10, "OXNEVAD", "SIGRUN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(102, 13, "BERENSTEN", "OYSTEIN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "171 - 409 0015", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(102, 14, "BROWN", "CHRIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(102, 15, "YEUNG", "LOUIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(102, 16, "BING-LARSEN", "LASSE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(102, 17, "SPENCER", "JERRY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(102, 18, "TRUDY", "GROVINBECH", NULL, NULL, 
"N-4035", NULL, NULL, NULL, "STAVANGER", NULL, "N", NULL, NULL, NULL, NULL, 
"73600", "51807042", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(102, 19, "SHMIDT", "JAN", NULL, NULL, 
"N-4035", NULL, NULL, NULL, "STAVANGER", NULL, "N", NULL, NULL, "45 33 42 4314", 
NULL, "73600", "47 51 99 2549", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(103, 4, "TAN", "STEVEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(103, 5, "BROWN", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(103, 6, "ELSNER", "GUNTHER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(103, 7, "WITT", "THORSTEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(104, 1, "SWEERTS", "ANDREW", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "I", 1)
go

insert into account_contact values(104, 2, "TORPEY", "DAVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(104, 3, "SULLIVAN", "SHERRY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(106, 8, "SHIVE", "RON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(106, 12, "IMSAIROVIC", "ADI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(106, 13, "TORPEY", "DAVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(106, 14, "FREY", "GEORGE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "215-977-6037", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(107, 1, "MARKETING", "BULK", NULL, 
"               OL99       0091", "1100 LOUISIANA, SUITE 4675", 
"HOUSTON, TX   77002", NULL, NULL, NULL, "NA", "USA", NULL, "713-655-1010", 
NULL, NULL, "62953842", NULL, NULL, NULL, 2, "A", 1)
go

insert into account_contact values(107, 2, "IRELAND", "DICK", NULL, NULL, 
"1100 LOUISIANA, SUITE 4675", "HOUSTON, TX   77002", NULL, NULL, NULL, "NA", 
"USA", NULL, NULL, "713-655-1010", NULL, "62953842", NULL, NULL, NULL, 2, "A", 
1)
go

insert into account_contact values(107, 3, "MCCONN", "LUKE", NULL, NULL, 
"1100 LOUISIANA, SUITE 4675", "HOUSTON, TX   77002", NULL, NULL, NULL, "NA", 
"USA", NULL, NULL, "713-655-1010", NULL, "62953842", NULL, NULL, NULL, 2, "A", 
1)
go

insert into account_contact values(107, 4, "FRIEDMAN", "RICH", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 2, "A", 1)
go

insert into account_contact values(107, 5, "BEST", "JOHN", NULL, NULL, 
"1100 LOUISIANA, SUITE 4675", NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, "713-655-1010", NULL, "62953842", "713-655-1626", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(107, 6, "SPEER", "MARK", NULL, NULL, 
"1100 LOUISIANA, SUITE 4675", NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, "713-655-1010", NULL, "62953842", "713-655-1626", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(107, 7, "GOULD", "D", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(108, 4, "IMSIROVIC", "ADI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(108, 5, "MAYNARD", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(108, 6, "LATHAM", "PATRICK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(108, 8, "ORTIZ", "JOSE MIGUEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(108, 9, "LEWIS", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(108, 11, "GLIEBE", "FRANK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(108, 12, "CONWAY", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(108, 13, "SPENSER", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(108, 14, "BERTUZZI", "JOHN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(108, 15, "TOM", "SIMPSON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3109", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(108, 16, "SPENCER", "JOHN", NULL, NULL, 
"1 WESTFERRY CIRCUS", "CANARY WHARF", NULL, NULL, "LONDON", NULL, "UK", 
"E14 4HA", NULL, NULL, NULL, "8956681", "441717195159", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(108, 17, "JANE", "PRICE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "01646 649561", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(108, 18, "YATES", "CHRIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(108, 19, "MALLINSON", "TREVOR", NULL, NULL, 
"1 WESTFERRY CIRCUS", "CANARY WHARF", NULL, NULL, "LONDON", NULL, "UK", 
"E14 4HA", NULL, NULL, NULL, "8956681", "441717195159", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(108, 20, "PATTAR", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(108, 21, "BALL", "JOHN", NULL, NULL, 
"1 WESTFERRY CIRCUS", "CANARY WHARF", NULL, NULL, "LONDON", NULL, "UK", 
"E14 4HA", NULL, "+44 171 719 311", NULL, "8956681", NULL, NULL, NULL, 2, "A", 
1)
go

insert into account_contact values(109, 5, "NELSON", "KEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713.752.7712", NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(109, 7, "NOVITSKY", "JONATHAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(109, 8, "ORTIZ", "JOSE MIGUEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(110, 8, "SAN", "TAY CHENG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(110, 13, "BROU", "SHARMAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(110, 14, "DIXON", "SHANDA", NULL, NULL, 
"2000 WESTCHESTER AVENUE", NULL, NULL, NULL, "WHITE PLAINS", "NY", "USA", 
"10650", NULL, NULL, NULL, NULL, "9142537111", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(110, 15, "AYALA", "HERB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(111, 13, "LEMON", "RON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713.752.7723", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(112, 14, "COPELY", "ELISE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(112, 15, "CARGILE", "SCOTT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(112, 21, "COPLEY", "ELISE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(112, 24, "HOFFMAN", "LAURI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(112, 28, "WOLFE", "RICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(112, 29, "SIRES", "LYNN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(115, 1, "EIDMAN", "JOHN", NULL, NULL, 
"2300 CLAYTON ROAD", "SUITE 1100", "CONCRD, CA 94520-2100", NULL, 
"CONCRD, CA 94520-2100", "NA", "USA", NULL, NULL, "415-602-4000", "5106024280", 
"691-2530", "FAX: 415-602-40", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(115, 2, "FABRITZI", "STEVE", NULL, NULL, 
"2300 CLAYTON ROAD", "SUITE 1100", NULL, NULL, "CONCRD", "CA", "USA", 
"94520-210", NULL, NULL, NULL, "691-2530", "FAX: 415-602-40", NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(115, 3, "ANCHETTA", "RICK", NULL, NULL, 
"2300 CLAYTON ROAD", "SUITE 1100", NULL, NULL, "CONCRD", "CA", "USA", 
"94520-210", NULL, NULL, NULL, "691-2530", "FAX: 415-602-40", NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(115, 4, "KOPP", "J", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(115, 5, "O'CONNER", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(115, 6, "CHOTTINER", "SCOTT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "203-326-7556", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(116, 8, "DE RICHEMONT", "OLIVIER", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(116, 9, "SIBAUD", "PHILIPPE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(116, 14, "MATHERON", "LUCAS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(116, 16, "CLEMENT", "CHUA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(116, 17, "THOMPSON", "SUSANNE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(116, 21, "CLEMENT", "CHUA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(116, 22, "CREMENT", "CHUA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(116, 23, "TOYODA", "TETSUO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(116, 24, "DE REYNIES", "EMMANUEL", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(116, 25, "RENIE", "B", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(116, 29, "USUI", "HIROMICHI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "81-35562-5215", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(116, 30, "D'OREY", "SOPHIE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "01717534854", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(116, 31, "CHALLANDE", "PATRICK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(116, 32, "FARRELL", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+44 171 753 481", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(116, 33, "MATHIS", "PIERRE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"01133141352258", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(117, 1, "LAWRENCE", "JANET", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(117, 2, "FARREL", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+44 171 753 481", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(118, 5, "LAWRENCE", "JANET", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(118, 8, "DOYLE", "JACK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(119, 1, "SUZUKI", "MR.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(119, 2, "USHIKU", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(120, 1, "MARKETING", "BULK", NULL, 
"               OL99       0091", "1201 WEST FIFTH ST.", 
"LOS ANGELES, CA  90017", NULL, NULL, NULL, "NA", "USA", NULL, NULL, NULL, NULL, 
"188 393", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(120, 2, "AWE", "DARVIN", NULL, NULL, 
"1201 WEST FIFTH ST.", "LOS ANGELES, CA  90017", NULL, NULL, NULL, "NA", "USA", 
NULL, NULL, NULL, NULL, "188 393", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(120, 3, "ATOR", "PHIL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0065-975 02493", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(121, 15, "TOWNSEND", "MAUREEN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(121, 16, "COOPER", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "9108813768", 
"7139935821", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(122, 1, "TAYLOR", "IAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "I", 1)
go

insert into account_contact values(122, 2, "YIP", "LOH FAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(122, 3, "MENG", "KHO HUI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "786RS26396", NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(122, 4, "HARDY", "RUSSEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(122, 5, "LOO", "SUSAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "65.737.9922", NULL, "78633473", 
"657370917", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(122, 6, "GOHARY", "R", NULL, NULL, 
"HEX 03-02 THONGSIA BUILDING", "30 BIDEFORD ROAD", NULL, NULL, "SINGAPORE 0923", 
"NA", "SGP", NULL, NULL, NULL, NULL, "78633473", "657370917", NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(122, 7, "LEONG", "ANG SENG", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(122, 8, "CHEE", "SUSANNA TAPIS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(122, 9, "LEE WAH", "SONG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(122, 10, "PING", "SOON  GASOIL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(122, 11, "TIONG", "TAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(122, 12, "CHAN", "SHAMAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(122, 13, "TAN", "TIONG HOCK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(122, 14, "MING", "KOH HUI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "786334373", 
"657370917", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(122, 15, "KHO", "HUI MENG", NULL, NULL, 
"THE HEEREN", "260 ORCHARD ROAD, HEX 07-01/05", NULL, NULL, "SINGAPORE 238855", 
NULL, "SGP", NULL, NULL, NULL, NULL, "78633473", "657370917", NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(123, 20, "SNYDER", "DALE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(123, 22, "BAKE", "CHRIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(123, 23, "SCHMIDT", "KARL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(123, 24, "HOPPER", "DENNIS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "203346", 
"7132252515", NULL, NULL, 73, "A", 1)
go

insert into account_contact values(123, 25, "BUTCHER", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(123, 26, "GLASGOW", "ERIC", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-230-1008", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(123, 27, "MAARRAOUI", "ANTONIO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-230-1151", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(123, 28, "DOVE", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(123, 29, "GRAHAM", "WIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-000-0000", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(124, 1, "MARKETING   DENISE J", "BULK", NULL, 
"               OL99       0091", "605 17TH STREET", NULL, 
"VERO BEACH, FLORIDA  32960-5518", NULL, "VERO BEACH, FLORIDA  32960-5518", 
"NA", "USA", "32960", NULL, NULL, NULL, "160008 GEORGE W", NULL, NULL, NULL, 4, 
"A", 1)
go

insert into account_contact values(124, 2, "CORR", "JOE", NULL, NULL, 
"605 17TH STREET", NULL, NULL, NULL, "VERO BEACH, FLORIDA  32960-5518", "NA", 
"USA", "32960", NULL, NULL, "407 778 7100", "160008 GEORGE W", NULL, NULL, NULL, 
4, "A", 1)
go

insert into account_contact values(124, 3, "SNEIDER", "ROBIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(124, 4, "HUPPENTHAL", "ROLAND", NULL, NULL, 
"605 17TH STREET", NULL, NULL, NULL, "VERO BEACH, FLORIDA  32960-5518", "NA", 
"USA", "32960", NULL, NULL, NULL, "160008 GEORGE W", NULL, NULL, NULL, 4, "A", 
1)
go

insert into account_contact values(124, 5, "DEAN", "JAY", NULL, NULL, 
"605 17TH STREET", NULL, NULL, NULL, "VERO BEACH, FLORIDA  32960-5518", "NA", 
"USA", "32960", NULL, NULL, NULL, "160008 GEORGE W", NULL, NULL, NULL, 4, "A", 
1)
go

insert into account_contact values(124, 6, "MORAIN", "MARK", NULL, NULL, 
"605 17TH STREET", NULL, NULL, NULL, "VERO BEACH, FLORIDA  32960-5518", "NA", 
"USA", "32960", NULL, NULL, NULL, "160008 GEORGE W", NULL, NULL, NULL, 4, "A", 
1)
go

insert into account_contact values(124, 7, "SCHNEIDER", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(124, 8, "CORR", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(124, 9, "HAHN", "TOM", NULL, NULL, 
"605 17TH STREET", NULL, NULL, NULL, "VERO BEACH, FLORIDA  32960-5518", "NA", 
"USA", "32960", NULL, "5617787100", NULL, "160008 GEORGE W", NULL, NULL, NULL, 
4, "A", 1)
go

insert into account_contact values(125, 3, "DOMINIC", "DENNIS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(125, 4, "O'BRIEN", "KERRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(125, 5, "LES", "HARDING", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "555-1212", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(127, 2, "MOONEY", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(127, 3, "RAHIM", "FAREENA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "4169479210", NULL, NULL, 
"4169417432", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(127, 4, "CURTICE", "EVANS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7182481516", NULL, NULL, 
"7182489426", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(127, 5, "GREENWALD", "RODNEY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2122915164", NULL, NULL, 
NULL, NULL, NULL, 3, "A", 1)
go

insert into account_contact values(127, 6, "CRUMBINE", "PETER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2122915164", NULL, NULL, 
NULL, NULL, NULL, 3, "A", 1)
go

insert into account_contact values(128, 1, "DAVIS", "GREG", NULL, NULL, 
"TCT OPTIONS INC.", "1100 LOUISIANA ST.", "SUITE 4675", NULL, "HOUSTON", "TX", 
"USA", "77002", NULL, "7136555050", NULL, NULL, "7136551626", NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(128, 2, "DAVEY", "BERT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713.655.5081", NULL, NULL, 
"7136551626", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(128, 3, "RAZOOK", "SCOTT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(128, 4, "THOMPSON", "SCOTT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7136551010", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(128, 5, "BILL", "BOESCHENSTEIN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(128, 6, "GOULD", "DAVID", NULL, NULL, 
"1100 LOUISIANA", "SUITE 4675", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, NULL, NULL, NULL, "7136551626", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(129, 1, "CONTRERAS", "CARLOS", NULL, NULL, 
"S.A. MARINA NACIONAL 329", NULL, NULL, NULL, "TORRE EJECUTIVA, PISO", "NA", 
"MEX", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "I", 1)
go

insert into account_contact values(129, 2, "HINOJOS", "ALBERTO", NULL, NULL, 
"S.A. DE C.V.", "A.V. MARINA NACIONAL 329", NULL, NULL, "TORRE EJECUTIVA, PISO", 
"NA", "MEX", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "I", 1)
go

insert into account_contact values(129, 3, "NARANJO", "SAMIRA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "I", 1)
go

insert into account_contact values(129, 4, "NAVARRO", "MARTHA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "5252270131", NULL, 
"1773509", "5252270118", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(129, 5, "GOMEZ", "VICTOR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "I", 1)
go

insert into account_contact values(129, 6, "HERNANDEZ", "OLIMPA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-567-0125", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(129, 7, "PEREZ", "AGUSTIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713 - 567 - 017", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(129, 8, "RANGEL", "SILVIA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "(713) 567-0120", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(129, 9, "VILAS", "ALFREDO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(129, 10, "RODRIGUEZ", "JAIME", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "I", 1)
go

insert into account_contact values(129, 11, "TURRENT", "GUILLERMO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(129, 12, "TROOP", "JORGE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(129, 13, "OHEA", "SEAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(129, 14, "LOPEZ", "EDGAR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "5252270131", NULL, "1773509", 
"5252270118", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(129, 15, "NUNEZ", "DANIELLA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3831773671", 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(129, 16, "BLENDA", "MARIO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(129, 17, "BANOS", "TOMAS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(130, 4, "YEUNG", "LOUIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "654632829", "657361833", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(131, 1, "DEAN", "ROCKLAND", NULL, NULL, 
"NONE", "NONE", NULL, NULL, "NONE", "NY", "USA", "10000", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "I", 1)
go

insert into account_contact values(131, 2, "RUNKLE", "DEAN", NULL, NULL, 
"DEFAULT ADDRESS", NULL, NULL, NULL, "DEFAULT CITY", "NY", "USA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(131, 3, "STAPLETON", "JACK", NULL, NULL, 
"200 PARK AVENUE", NULL, NULL, NULL, "FLORHAM PARK", "NJ", "USA", "07932", NULL, 
"201 765 5444", NULL, "132092", "201 765 4983", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(131, 4, "SPRATT", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(131, 5, "HAYNES", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(131, 6, "PANZA", "MARK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(131, 7, "BERGESEN", "BJORN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(131, 8, "PUGLISI", "DENNIS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(132, 1, "WINTER", "GEORGES", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "33142961626", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(132, 2, "RENAUD", "NICOLE", NULL, NULL, 
"10, RUE DE CASTIGLIONE", NULL, NULL, NULL, "75001 PARIS", "NA", "F", NULL, 
NULL, "33142961626", NULL, "212679", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(132, 3, "NORMAN", "JON", NULL, NULL, 
"10, RUE DE CASTIGLIONE", NULL, NULL, NULL, "75001 PARIS", "NA", "F", NULL, 
NULL, "33142961626", NULL, "212679", "33142619475", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(132, 4, "MOTTE", "PATRICK", NULL, NULL, 
"10, RUE DE CASTIGLIONE", NULL, NULL, NULL, "75001 PARIS FRANCE", NULL, "F", 
NULL, NULL, "33142961626", NULL, "212679", "33142619475", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(132, 5, "HEMRIKA", "ROBBERT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(133, 1, "CONNORS", "JOHN", NULL, NULL, 
"1185 AVENUE OF THE AMERICAS", NULL, NULL, NULL, "NEW YORK", "NY", "USA", 
"10036", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(133, 2, "MERISON", "GUY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2125368116", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(133, 3, "EICHMAN", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2125368116", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(133, 4, "DARIUS", "SWEET", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(134, 1, "DALE", "RICHARD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, "7136592745", 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(134, 2, "RODRIGUEZ", "SHELLY", NULL, NULL, 
"1000 LOUISIANA", "SUITE 1100", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, NULL, NULL, NULL, "7136592745", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(134, 3, "FLETCHER", "TOM", NULL, NULL, 
"1000 LOUISIANA", "SUITE 1100", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, NULL, NULL, NULL, "7136592745", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(134, 4, "LEVERT", "LARRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7136592745", 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(134, 5, "PERKINS", "BILL", NULL, NULL, 
"1000 LOUISIANA", "SUITE 1100", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, NULL, NULL, NULL, "7136592745", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(135, 1, "KOHN", "RICH", NULL, 
"NATURAL GAS DEPT.", NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, 
NULL, NULL, NULL, "9185884074", NULL, "CONTRACTS", 1, "I", 1)
go

insert into account_contact values(135, 2, "BOTTINGLY", "CINDY", NULL, NULL, 
"ONE WILLIAMS CENTER", NULL, NULL, NULL, "TULSA", "OK", "USA", "74101", NULL, 
"918 588 3900", NULL, "918 588 3108", NULL, NULL, NULL, 1, "I", 1)
go

insert into account_contact values(135, 3, "CHENG", "DAVID", NULL, NULL, 
"ONE WILLIAMS CENTER", NULL, NULL, NULL, "TULSA", "OK", "USA", "74101", NULL, 
"918 588 3900", NULL, "918 588 3108", NULL, NULL, NULL, 1, "I", 1)
go

insert into account_contact values(135, 4, "ANNUNZIATA", "KIM", NULL, 
"CRUDE OIL DEPT", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "CONTRACTS", 1, "I", 1)
go

insert into account_contact values(135, 5, "THORNBURG", "DAN", NULL, NULL, 
"ONE WILLIAMS CENTER", NULL, NULL, NULL, "TULSA", "OK", "USA", "74172", NULL, 
NULL, NULL, "FAX 918 588 407", NULL, NULL, NULL, 1, "I", 1)
go

insert into account_contact values(135, 6, "CROW", "SHARON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "9185885222", NULL, 
"FAX 9185884074", "9185884074", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(135, 7, "KEENER", "DENNIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "918.588.2063", NULL, NULL, 
"9185884074", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(135, 8, "LEMMER", "CHRIS", NULL, NULL, 
"TRADING COMPANY", "ONE WILLIAMS CENTER", NULL, NULL, "TULSA", "OK", "USA", 
"74172", NULL, "918-588-5917", NULL, NULL, "9185884074", NULL, NULL, 1, "I", 1)
go

insert into account_contact values(135, 10, "PALEY", "KEVIN", NULL, NULL, 
"ONE WILLIAMS CENTER", NULL, NULL, NULL, "TULSA", "OK", "USA", "74172", NULL, 
NULL, NULL, NULL, "9185884074", NULL, NULL, 1, "I", 1)
go

insert into account_contact values(135, 11, "MCLAUGHLIN", "DAN", NULL, NULL, 
"ONE WILLIAMS CENTER", NULL, NULL, NULL, "TULSA", "OK", "USA", "74172", NULL, 
NULL, NULL, NULL, "9185884074", NULL, NULL, 1, "I", 1)
go

insert into account_contact values(135, 12, "MCCALL", "TOM", NULL, NULL, 
"ONE WILLIAMS CENTER", NULL, NULL, NULL, "TULSA", "OK", "USA", "74172", NULL, 
"918.588.4072", NULL, NULL, "9185884074", NULL, NULL, 1, "I", 1)
go

insert into account_contact values(135, 13, "MANTZ", "BRAD", NULL, NULL, 
"ONE WILLIAMS CENTER", NULL, NULL, NULL, "TULSA", "OK", "USA", "74172", NULL, 
"918.588.4656", NULL, NULL, "9185884074", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(135, 14, "BUCKSPAN", "ANGIE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "9185884592", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(135, 15, "FJELD-HANSEN", "JP", NULL, NULL, 
"ONE WILLIAMS CENTER", NULL, NULL, NULL, "TULSA", "OK", "USA", "74172", NULL, 
"9185882682", NULL, NULL, "9185884074", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(135, 16, "WANG", "STEVE", NULL, NULL, 
"ONE WILLIAMS CENTER", "P.O. BOX 2848", NULL, NULL, "TULSA", "OK", "USA", 
"74101-956", NULL, NULL, NULL, NULL, "9185884074", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(135, 17, "FJELD-HANSON", "J", NULL, NULL, 
"ONE WILLIAMS CENTER", "P.O. BOX 2848", NULL, NULL, "TULSA", "OK", "USA", 
"74101-956", NULL, NULL, NULL, NULL, "9185884074", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(135, 18, "LEMMER", "C", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(135, 19, "OTEY", "GEORGE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "9185616002", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(135, 20, "CAPRA", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(135, 21, "TEVEDAUGH", "TRYNOR", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(135, 22, "MORGAN", "TODD", NULL, NULL, 
"ONE WILLIAMS CENTER", NULL, NULL, NULL, "TULSA", "OK", "USA", "74172", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(135, 23, "WILSON", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-215-3560", NULL, NULL, 
"713-215-3560", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(136, 1, "CASTELLANO", "MIKE", NULL, "CFO", 
"500 NYALA FARMS", NULL, NULL, NULL, "WESTPORT", "CT", "USA", "06880", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(136, 2, "MC GRATH", "ROB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2032215944", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(136, 3, "DELCASTILLO", "VICENTE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(136, 4, "BORRELLO", "PHIL", NULL, NULL, 
"500 NYALA FARMS", NULL, NULL, NULL, "WESTPORT", "CT", "USA", "06880", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(136, 5, "ALVARADO", "ROGER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(136, 6, "GREENLEAF", "PETER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2032216184", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(136, 7, "OZTOMEL", "GLEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2032215904", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(136, 8, "INCARDONA", "TERESA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2032216167", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(136, 9, "HERFORT", "DEBBIE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2032215858", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(136, 10, "BURCHMAN", "HILLARY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "203-221-6184", NULL, 
NULL, "203-221-6771", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(136, 11, "LAWRENCE", "HO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(136, 12, "HO", "LAWRENCE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(136, 13, "HAMBURGER", "K", NULL, NULL, 
"500 NYALA FARMS", NULL, NULL, NULL, "WESTPORT", "CT", "USA", "06880", NULL, 
NULL, NULL, "141009", "2032216775", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(136, 14, "PEAK", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(136, 15, "WOOD", "ED", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(136, 16, "PETTY", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "203-221-5980", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(137, 10, "PRESSER", "THOMAS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(137, 11, "QUINT", "ELLIOTT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(138, 1, "HORTON", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "214.880.2111", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(138, 2, "WALTON", "WES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "214.880.2111", NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(139, 3, "WOOLABY", "LANCE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "703-846-6746", NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(139, 4, "BROWER", "K", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(139, 5, "EWING", "VINCE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(139, 6, "APTER", "ADAM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(139, 12, "VARGHESE", "PHILIP", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(139, 14, "CAVALLO", "P", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(139, 20, "BRYCE", "DAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(139, 21, "KERKHOVEN", "MIKE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(139, 24, "SANDERS", "S", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(139, 27, "TOBIA", "MICHAEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "(65) 660 6469", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(139, 28, "MCBRIDE", "PETER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(139, 29, "LEVENSTEIN", "MARK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 1, "TICE", "MARK", NULL, NULL, 
"1200 SMITH STREET", "SUITE 900", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, NULL, NULL, NULL, "7139512233", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 2, "CITTADINE", "STEVE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "708.954.2360", 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(140, 3, "ELLIS", "MISSY", NULL, NULL, 
"1200 SMITH STREET", "SUITE 900", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, "713-951-2000", NULL, NULL, "7139512233", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 4, "KENNEDY", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713.951.2000", NULL, NULL, 
NULL, NULL, NULL, NULL, "I", 1)
go

insert into account_contact values(140, 5, "KENNEDY", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713.951.2000", NULL, NULL, 
"7139512233", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 6, "STEFFES", "MIKE", NULL, NULL, 
"1200 SMITH STREET", "SUITE 900", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, NULL, NULL, NULL, "7139512233", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 7, "GROETZINGER", "PETE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 8, "EDWARDS", "GENE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(140, 9, "MCCLAIN", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7139512000", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 10, "HABBAS", "AMJAD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7139512000", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 11, "WILLIG", "GEOFF", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7139512000", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 12, "JOHNSON", "DEANN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 13, "STANICH", "GRAIG", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 14, "DEPT", "CRUDE OIL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 15, "UPTON", "WADE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(140, 16, "MAHAN", "PHILLIP", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 17, "WILLSON", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(140, 18, "WILSON", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(140, 19, "HOPPER", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-951-5037", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(140, 20, "GLENN", "BRIAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "(713)393-5222", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(140, 21, "LEE", "ENRIQUE", NULL, NULL, 
"1200 SMITH STREET", "SUITE 900", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, NULL, NULL, "713-951-2252", "7139512233", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 22, "MENGLEBURGER", "JUDY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(140, 23, "MANGLEBERGER", "JUDY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(141, 3, "DEEMER", "BRICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713.260.1800", NULL, NULL, 
"7135843905", NULL, NULL, 4, "A", 1)
go

insert into account_contact values(141, 5, "DELAY", "TIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713.584.3922", NULL, NULL, 
"7135843905", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(141, 7, "MCCONN", "RICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713.584.3948", NULL, NULL, 
"7135843905", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(141, 8, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7135843972", NULL, NULL, 
"7135843907", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(141, 9, "EDELFELT", "JONATHAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"7135846160", NULL, NULL, 4, "A", 1)
go

insert into account_contact values(141, 10, "BOISTER", "BRAD", NULL, NULL, 
"C/O VASTAR RESOURCES, INC.", "15375 MEMORIAL DRIVE", NULL, NULL, "HOUSTON", 
"TX", "USA", "77079", NULL, "713-463-1203", NULL, NULL, NULL, NULL, NULL, 4, 
"A", 1)
go

insert into account_contact values(142, 2, "HEBRINK", "GREG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(142, 3, "HEBRANK", "GREG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(142, 5, "SHAFFER", "JEFF", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(142, 6, "CHU", "SAID THONG", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(142, 10, "PATERSON", "ROBERT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(142, 12, "YEE MENG", "LEE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(142, 13, "DARLAND", "TYE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3168288623", NULL, NULL, 
"3168283133", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(142, 14, "JOHNSON", "DONNA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"27326 KOCH G", "3168287977", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(142, 15, "HARRISON", "TOBY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(142, 16, "FOQUET", "ARIAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(142, 17, "THEOFILOU", "TERRY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(142, 18, "CLOPINE", "RUSS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(142, 19, "HAMILTON", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(143, 2, "GLEN", "HOLLINDER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "000-000-000", NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(143, 8, "LEWIS", "RICHARD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(143, 9, "TUKE", "CHARLES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(143, 10, "LISENBY", "STEVE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2129020776", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(143, 11, "MCFADZEN", "IAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2129020772", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(143, 12, "LUA", "JENNY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(143, 13, "TAN", "JON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(143, 14, "VAN", "RIET", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(144, 1, "SULLIVAN", "SHERRY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "215 977-3851", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(144, 2, "EVANS", "MARSHALL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(144, 3, "GERRY", "FLAHERTY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(144, 4, "IMSIROVIC", "ADI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(144, 5, "TAYLOR", "SY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2159773267", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(144, 6, "MCCAULEY", "TAYLOR", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2159776806", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(144, 7, "TORPEY", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(145, 1, "O'CONNELL", "JAMES", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(146, 1, "BOUGERE", "RON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(146, 2, "MCGAHA", "BARBARA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2814477992", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(146, 3, "BALLARD", "AL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2814478008", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(147, 1, "DOLAN", "BRIAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "203 978 6908", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(147, 2, "TARAN", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "203.978.6953", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(147, 3, "DEPT.", "CRUDE OIL", NULL, 
"CRUDE OIL DEPT.", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "2039786952", NULL, "CONTRACTS", 1, "A", 1)
go

insert into account_contact values(147, 4, "WARD", "ANITA", NULL, NULL, 
"225 HIGH RIDGE ROAD", NULL, NULL, NULL, "STAMFORD", "CT", "USA", "06905", NULL, 
NULL, NULL, "6819522", "2039786953", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(147, 5, "ABRAHAMSEN", "THOR", NULL, NULL, 
"225 HIGH RIDGE ROAD", NULL, NULL, NULL, "STAMFORD", "CT", "USA", "06905", NULL, 
NULL, NULL, "6819522", "2039786953", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(147, 6, "EICHMAN", "JIM", NULL, NULL, 
"225 HIGH RIDGE ROAD", NULL, NULL, NULL, "STAMFORD", "CT", "USA", "06905", NULL, 
NULL, NULL, "6819522", "2039786953", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(148, 1, "SLOAN", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "403-229-3229", NULL, NULL, 
"403-237-1078", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(148, 2, "MAKI", "RICHARD", NULL, 
"NATURAL GAS DEPT.", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"4032371467", NULL, NULL, "4032371324", NULL, "CONTRACTS", 1, "A", 1)
go

insert into account_contact values(148, 3, "DYKSTRA", "LARRY", NULL, NULL, 
"SUITE 2400", "855 2ND ST. S.W.", NULL, NULL, "CALGARY, ALBERTA T2P 4J9", NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, "403-237-1078", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(148, 4, "BOUCK", "BARRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(148, 5, "FARRAS-ORR", "ADAM", NULL, NULL, 
"SUITE 2400", "855 2ND ST. S.W.", NULL, NULL, "CALGARY, ALBERTA T2P 4J9", NULL, 
"CDN", NULL, NULL, "012244313394", NULL, NULL, "403-237-1078", NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(148, 6, "ADAM", "FARIS-ORR", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(148, 7, "FARRIS-ORR", "ADAM", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(149, 1, "FASANO", "RICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "9144211700", NULL, NULL, 
"9144210421", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(149, 2, "ZISI", "VINCE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "914.421.1700", NULL, NULL, 
"9144210421", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(149, 3, "RISI", "VINCE", NULL, NULL, 
"CRESTWOOD OFFICE CENTER", "399 KNOLLWOOD ROAD", "SUITE 204", NULL, 
"WHITE PLAINS", "NY", "USA", "10603", NULL, NULL, NULL, NULL, "9144210421", 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(149, 4, "LAICO", "CHRIS", NULL, NULL, 
"CRESTWOOD OFFICE CENTER", "399 KNOLLWOOD ROAD", "SUITE 204", NULL, 
"WHITE PLAINS", "NY", "USA", "10603", NULL, NULL, NULL, NULL, "9144210421", 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(150, 1, "YOSHIDA", "MASA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "4412951432", NULL, 
"3736/3205SPCTBA", "4412950121", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(150, 2, "TANSLEY", "RICHARD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "4412951432", NULL, 
"3736/3205SPCTBA", "4412950121", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(150, 3, "HAMILTON", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(150, 4, "THAM", "LENNART", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(150, 5, "DARLING", "PAR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0171 823 5500", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(150, 6, "LUA", "JENNY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(150, 7, "MILNE", "JO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(150, 8, "CHONG", "CASEY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(151, 1, "DUTRA", "SEAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(152, 1, "WARD", "MR J", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "GB", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(153, 1, "CHRISTIE", "GUY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "212-236-3645", NULL, 
"7607920MLFS UR", "212-236-1643", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(153, 2, "BLANEY", "JAMES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(153, 3, "NADELBERG", "ERIC", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(154, 9, "PATEL", "ROHINI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(154, 10, "CHAUTRAD", "GILLES", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(154, 11, "ZREIKAT", "SAMIR", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(154, 13, "KHO", "HUI MENG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(154, 15, "OOTANI", "MR.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "81-3-3433-0681", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(154, 16, "HARDY", "RUSSEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(154, 17, "BUTCHER", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(154, 18, "GREENSLADE", "PAUL", NULL, NULL, 
"BOWATER HOUSE", "68 KNIGHTSBRIDGE", NULL, NULL, "LONDON", NULL, "GB", 
"SW1X7LT", NULL, NULL, NULL, "929101", NULL, NULL, NULL, 2, "A", 1)
go

insert into account_contact values(155, 1, "CONTRACTS", "GAS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(155, 2, "OHEARN", "KEVIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "403 781-8231", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(156, 3, "CHUAN", "WOO SIEW", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(156, 4, "CHENG", "WOO SIEW", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(157, 1, "MASEK", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(157, 2, "HOPPER", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(157, 3, "GOULD", "DAVID", NULL, NULL, 
"FOUR GREENSPOINT PLAZA", "16945 NORTHCHASE DRIVE, SUITE 2300", NULL, NULL, 
"HOUSTON", NULL, "USA", "77060", NULL, NULL, NULL, "77042", "7138762565", NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(158, 1, "KEHL", "MONTY", NULL, 
"ASSISTANT TREASURER", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(159, 1, "SCHUELE", "JIM", NULL, 
"SUPERVISOR, CREDIT ACCOUNTING", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "402- 498-4490", NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(160, 1, "WILEY", "MICHAEL", NULL, 
"PRES. & CEO", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "7135843905", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(161, 1, "WILLIAMS", "PETER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(162, 1, "WAHLERS", "RICH", NULL, 
"TREASURER STINNESINTEROIL, INC", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "908-842-4200", NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(163, 1, "KALMAN", "LESLIE", NULL, 
"CONTROLLER", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(163, 2, "FRASIER", "MATT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(165, 1, "CHIN", "SU-HIN", NULL, 
"SUPERVISOR, TREASURY OPERATION", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(166, 1, "AVAILABLE", "NOT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(167, 1, "SMITH", "MICHAEL", NULL, "VP & CFO", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(168, 1, "MARCHIGIANI", "BORIS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(168, 2, "SASHA", "A", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(168, 3, "SHASHA", "ANDREW", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(168, 4, "DOWING", "D", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(168, 5, "LAROCCA", "JOSE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(168, 6, "BENDER", "DAVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(169, 1, "CAPILBIO", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "8096581210", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(169, 2, "ALLUM", "KEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "8096581310", "8096581205", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(169, 3, "CALLENDER", "RICHARD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "8096581222", "8096581204", 
NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(169, 4, "NARINESINGH", "CAPILDIO", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(170, 1, "MILLER", "ALLEN", NULL, 
"CONTROLLER - FIM", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"402-595-4320", NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(170, 2, "ALTILIO", "JERRY", NULL, NULL, 
"ONE CONAGRA DRIVE", NULL, NULL, NULL, "OMAHA", "NE", "USA", "68102", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(171, 1, "GULSBY", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "713-973-6655", NULL, NULL, 
"7139736656", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(171, 2, "BEST", "JOHN", NULL, NULL, 
"952 ECHO LANE", "SUITE 460", NULL, NULL, "HOUSTON", "TX", "USA", "77024", NULL, 
NULL, NULL, NULL, "7139736656", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(171, 3, "RAZOOK", "SCOTT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2815658133", "7139736655", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(171, 4, "MOELLER", "GINA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(171, 5, "ROBBINS", "TRACEY", NULL, NULL, 
"952 ECHO LANE", "SUITE 460", NULL, NULL, "HOUSTON", "TX", "USA", "77024", NULL, 
"713-973-6655", NULL, NULL, "7139736656", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(172, 1, "POLLOCK", "PHIL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "071", NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(172, 2, "PROSDOCIMI", "BRIAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "171.499.0432", NULL, 
NULL, "1714995270", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(172, 3, "SERCOMBE", "PAUL", NULL, NULL, 
"COLLETTE HOUSE", "52-55 PICCADILLY", NULL, NULL, "LONDON W1V 9AA", "NA", "GB", 
NULL, NULL, NULL, NULL, "299686", "44 71 499 5270", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(172, 4, "JONES", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "441714990432", NULL, NULL, 
"441714995270", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(172, 5, "WATERS", "TIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "441714990432", NULL, NULL, 
"441714990432", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(172, 6, "TURNER", "ANN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(174, 1, "SMITH", "C.F.", NULL, 
"ASSISTANT MANAGER, DOC CREDITS", "71 QUEEN VICTORIA STREET", NULL, NULL, NULL, 
"LONDON EC4V 4DE", "NA", "GB", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(175, 1, "POLNER", "BEN", NULL, NULL, 
"C/O GENEVA BRANCH", "29 RUE DE LA ROTISSERIE", NULL, NULL, "CH-1204 GENEVE", 
"NA", "CH", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(175, 2, "WALKER", "ANDREW", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(177, 1, "BRENT", "PHIL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(178, 1, "BAINBRIDGE", "ROWAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 2, "A", 1)
go

insert into account_contact values(179, 1, "FIORE", "LAURA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "4169566938", NULL, NULL, 
"4169568212", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(179, 2, "FORGRAVE", "ROB", NULL, NULL, 
"HEAD OFFICE", "COMMERCE COURT WST", NULL, NULL, "TORONTO, ONTARIO", NULL, 
"CDN", NULL, NULL, NULL, NULL, "0210623094", "14169568212", NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(180, 19, "O'CONNOR", "JOHN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(180, 20, "IRELAND", "MARTIN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(180, 21, "RIMBEY", "T", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(180, 22, "SUE", "ARGUE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(180, 23, "MICHEAL", "NG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "546 2652", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(180, 24, "CROSLEY", "CHRISTINE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(180, 25, "ARGUE", "SUE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(180, 26, "CHIN", "EMILY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(180, 27, "MCBAIN", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(180, 28, "WATKINS", "CAROLINE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0171-546 2983", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(180, 29, "QUARTERMAIN", "MARK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0171-546 5669", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(180, 30, "MADDEN", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"44-171-546-7580", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(180, 31, "BAKER", "CHRIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "44 171 546 2119", NULL, NULL, 
"44 171 546 6610", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(181, 1, "UNKNOWN", "UNKNOWN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "B", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(182, 1, "WARD", "CAROLINE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "GB", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(182, 2, "YOUNG", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(183, 1, "WHILLOCK", "BRIAN", NULL, 
"GENERAL MANAGER", NULL, NULL, NULL, NULL, NULL, NULL, "SGP", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(183, 2, "TOH", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(184, 1, "JACOBSON", "LARS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "S", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(184, 2, "WESTERLIND", "JONAS", NULL, "MR", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(185, 2, "SEY", "AN", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(185, 6, "XIE", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(185, 7, "LI", "JU", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "653397037", NULL, 
NULL, 2, "A", 1)
go

insert into account_contact values(185, 8, "HUA", "NI", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0065 3345167", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(185, 9, "ZHONG", "LI", NULL, 
"OPERATION MANAGER", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"0065 3390110", NULL, NULL, "3397037", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(186, 2, "ALVEREZ", "LUIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(186, 3, "BEAR", "ALEX", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(186, 4, "ROHAM", "FERNANDEZ", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(186, 6, "RUNGE", "FRANK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(186, 7, "SHARNAN", "BRON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(186, 8, "MAIWICK", "ANDREW", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(187, 1, "WUERTZ", "HENRY", NULL, NULL, 
"2930 REVERE STE. 200", NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77098", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(187, 2, "FOULARD", "MIKE", NULL, NULL, 
"2930 REVERE STE. 200", NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77098", NULL, 
NULL, NULL, NULL, "713-527-0828", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(187, 3, "ROBBINS", "TRACY", NULL, NULL, 
"2930 REVERE STE. 200", NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77098", NULL, 
NULL, NULL, NULL, "713-527-0828", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(187, 4, "BUTLER", "JOHN", NULL, NULL, 
"2930 REVERE STE. 200", NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77098", NULL, 
"713-527-0019", NULL, NULL, "713-527-0828", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(187, 5, "CROW", "KEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7135278650", "7135278650", NULL, 
"650659177", "7135270828", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(188, 1, "WONG", "WAI HUNG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(188, 2, "HIANG", "LIM SWEE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "65-2298593", NULL, NULL, 
NULL, NULL, "FINANCE", 1, "A", 1)
go

insert into account_contact values(188, 3, "YAMAMOTO", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(188, 4, "YOE", "GERTRUDE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(189, 1, "WANG", "CHARLIE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "SGP", NULL, NULL, NULL, NULL, "RS35490 INTLIN", 
"(65) 2537596", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(190, 1, "SHEE", "SEE KUEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "SGP", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(191, 1, "WATSON", "DEXTER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(192, 1, "EAST", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2128412074", NULL, NULL, 
"2128412174", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(192, 2, "HAN", "YONG GUAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "654395028", NULL, NULL, NULL, 
NULL, NULL, 2, "A", 1)
go

insert into account_contact values(192, 3, "JORGE", "KIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2128412532", NULL, NULL, 
"2128412041", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(192, 4, "SORBA", "JEROME", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "901133142986851", NULL, NULL, 
"901133142980276", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(193, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(193, 2, "MORRELL", "JACKIE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(193, 3, "GLEAVE", "FRANK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(193, 4, "SAWJANI", "MITA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(193, 5, "VAN", "DIJKEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(193, 6, "TUNSTALL", "DUNCAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(193, 7, "VAN", "DIJKEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(193, 8, "VAN DIJKEN", "REGINA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(193, 9, "DEITHTON", "STEVE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(194, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(195, 1, "BERRETT", "TERRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2165865283", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(195, 2, "ACKLEY", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "984645BPNAPNY", 
"2033524599", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(195, 3, "BARNES", "ADAM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2033524504", NULL, NULL, 
"2033524599", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(195, 4, "VITALICE", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7135605594", NULL, NULL, 
"7135589927", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(195, 5, "VAUGHAN", "BERNIE", NULL, NULL, 
"200 PUBLIC SQUARE", "5TH FLOOR", NULL, NULL, "CLEVELAND", "OH", "USA", "44114", 
NULL, "216-586-6463", NULL, "62917760", "2165862403", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(195, 6, "PAGE", "ANDY", NULL, NULL, 
"200 PUBLIC SQUARE", "5TH FLOOR", NULL, NULL, "CLEVELAND", "OH", "USA", "44114", 
NULL, "216-586-5683", NULL, "62917760", "2165862403", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(195, 7, "DEMANSKY", "NICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(195, 8, "THOMASON", "MAX", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(196, 1, "ERRINGTON", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2033524501", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(197, 1, "MASSUM", "RICHARD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "786RS55788", 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(197, 2, "TAN C. K.", "JON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "786RS55788", 
"652737897", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(197, 3, "TSUEY FENG", "LEE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "011653718520", NULL, 
NULL, "011652737897", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(197, 4, "LAI  KHIN", "LEONG", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "011653718948", NULL, 
NULL, "011652737897", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(197, 5, "PARSON", "ANDY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(197, 6, "LONG", "SIMON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(198, 1, "CHAN", "RAYMOND", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "653909898", 
NULL, NULL, 2, "A", 1)
go

insert into account_contact values(198, 2, "SCHWEIGERT", "VERONIQUE", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "01141227032111", 
NULL, NULL, "01141227032122", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(198, 3, "TAN", "THERESA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "653909404", NULL, NULL, 
"653909698", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(198, 4, "TURNEY", "TIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(199, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(200, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(201, 1, "GEAGEA", "JOE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "266471", 
"441714878509", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(201, 2, "SULLIVAN", "CAROL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "470074", 
NULL, NULL, NULL, 2, "A", 1)
go

insert into account_contact values(201, 3, "ENDERSBY", "P.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "762799", 
"7137544597", NULL, NULL, 3, "A", 1)
go

insert into account_contact values(201, 4, "EMRICH", "J.C.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "4158945654", NULL, NULL, 
"4158949327", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(201, 5, "SKIPPINGS", "JAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(202, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(203, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(204, 1, "ISHII", "OSAMA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "85228216200", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(204, 2, "HAN", "NICHOLAS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "653296100", 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(205, 1, "HASUOKA", "S", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "441718220215", NULL, NULL, 
NULL, NULL, "CRUDE", 1, "A", 1)
go

insert into account_contact values(205, 2, "TAKEDA", "H", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "441718220285", NULL, NULL, 
NULL, NULL, "PRODUCT", 1, "A", 1)
go

insert into account_contact values(205, 3, "PAVITT", "DANNY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"441718220089", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(206, 1, "MAZAKI", "TAKAHIRO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"J33333 MCTOK A", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(206, 2, "KASAHARA", "YUTAKA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(207, 1, "CASEY", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "5369210", NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(207, 2, "KENNEDY", "PATRICK", NULL, NULL, 
"200 PEACH STREET", NULL, NULL, NULL, "EL DORADO", "AR", "USA", "71730", NULL, 
"870-864-6530", NULL, "5369210", "5018646373", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(207, 3, "WAKEFIELD", "JOHN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(207, 4, "WOOD", "GURVIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(208, 1, "CHIN C.N.", "CHARLES", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "652916686", NULL, 
"37103", "652991339", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(208, 2, "WONG", "RAYMOND", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 2, "A", 1)
go

insert into account_contact values(209, 1, "THOMAS", "JAMES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7137441790", NULL, NULL, 
"7137445364", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(209, 2, "HERBERT", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7137441772", NULL, NULL, 
"7137446207", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(209, 3, "PRICE", "LAURIE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7135076479", NULL, NULL, 
"7137441757", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(210, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "4024984490", NULL, NULL, 
"4024984543", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(211, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "5085241500", NULL, NULL, 
"5085241688", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(211, 2, "LISTOKIN", "J", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(212, 1, "TIERNEY", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "762972", 
"7137544597", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(212, 2, "LEE", "DAVID", NULL, NULL, 
"P.O. BOX 3976", "A DIVISION OF CHEVRON USA INC.", NULL, NULL, "HOUSTON", "TX", 
"USA", "77253-3976", NULL, NULL, NULL, "762972", "7137544597", NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(212, 3, "WITT", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-754-4912", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(212, 4, "ANDERSON", "BRUCE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(212, 5, "BLUME", "ROBERT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(213, 1, "GRIFFIN", "E.M.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "9719228415", NULL, "89101", 
"9719228414", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(213, 2, "GRIFFIN", "EDWIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "6503716890", 
"7704219653", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(214, 1, "LIM", "DENNIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "653388287", 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(214, 2, "NAKAMURA", "NOBUCHIKA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "653382000", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(214, 3, "HENDRY", "PETER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(214, 4, "COOPER", "SANDRA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(214, 5, "HENRY", "PETER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(214, 6, "LIM", "RONALD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(215, 1, "BANOS", "TOMAS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3831773671", 
"7135670118", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(215, 2, "NUNEZ", "DANIELLA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(216, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(217, 1, "HOWLETT", "GRAHAM", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "441815623695", NULL, 
"8813983", "441815622778", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(217, 2, "KHALDI", "JANICE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "011441815623741", NULL, NULL, 
"011441815622778", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(217, 3, "ACKERMAN", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(218, 1, "HOEVER", "THERESA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "4159274120", "4159563834", 
NULL, "210422", "4159561508", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(218, 2, "VAN VACAS", "CHAD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "4155220711", "4159563834", 
NULL, "210422", "4159561508", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(218, 3, "HAMILTON", "MICHAEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3105980340", "3104276611", 
NULL, "278210 RCA", "3104274621", NULL, NULL, 2, "A", 1)
go

insert into account_contact values(218, 4, "SAHASRAMAN", "PRIA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "4152682700 X 22", NULL, 
NULL, "4153623501", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(218, 5, "DEGMAN", "JAMES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(218, 6, "HEREIDA", "EMILIO", NULL, "TRADER", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"4152682701", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(219, 1, "GREEN", "LARRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7132608537", NULL, NULL, 
"7132601825", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(219, 2, "BACHMAN", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(220, 1, "KAPP", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7135482095", 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 1, "THOMPSON", "DAVID", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "888811", 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 2, "WARREN", "LISA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "888811", NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 3, "MILNES", "ANDY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "5796102", 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 4, "PARRACK", "GILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "011441714693582", NULL, NULL, 
"011441715796101", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 5, "STRATTON", "GILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "011441714962000", NULL, NULL, 
"011441715796101", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 6, "BEGGS", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "011441714963529", NULL, NULL, 
"011441714962854", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 7, "VAUGHN", "DAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(221, 8, "MASSAM", "RICHARD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(221, 9, "GIBSON", "COLIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(221, 10, "LONG", "SIMON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(221, 11, "BEAL", "N", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(221, 12, "THUEMMEL", "WOLFRAM", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(221, 13, "THUEWWELL", "WOLFRAM", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "I", 1)
go

insert into account_contact values(221, 14, "CLAIRE", "UDALL", NULL, NULL, 
"1 BROADGATE", NULL, NULL, NULL, "LONDON EC2M 2AP", NULL, "UK", NULL, NULL, 
NULL, NULL, "888811", "011441714962854", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 15, "DAN", "VAUGHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+44-171-5796788", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(221, 16, "BRIGGS", "R", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(221, 17, "RITCHIE", "DEREK", NULL, NULL, 
"1 BROADGATE", NULL, NULL, NULL, "LONDON EC2M 2AP", NULL, "UK", NULL, NULL, 
NULL, NULL, "888811", "011441714962854", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 18, "MOHAFSEL", "MAGD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(221, 19, "SCARLETT", "ANDY", NULL, NULL, 
"1 BROADGATE", NULL, NULL, NULL, "LONDON EC2M 2AP", NULL, "UK", NULL, NULL, 
NULL, NULL, "888811", "011441714962854", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 20, "MYERS", "ALISON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0171-579-6969", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(221, 21, "MCALEESE", "CHRIS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(221, 22, "DIXON", "STEVE", NULL, NULL, 
"1 BROADGATE", NULL, NULL, NULL, "LONDON EC2M 2AP", NULL, "UK", NULL, NULL, 
NULL, NULL, "888811", "011441714962854", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 23, "ROSS", "TOM", NULL, NULL, 
"1 BROADGATE", NULL, NULL, NULL, "LONDON EC2M 2AP", NULL, "UK", NULL, NULL, 
NULL, NULL, "888811", "011441714962854", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 24, "KITE", "AUDREY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "011441715796101", NULL, 
"011441715796101", "011441715796101", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 25, "STEFAN", "DIXON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0171-5796080", NULL, NULL, 
"0171-5796108", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(221, 26, "LINDARS", "PAUL", NULL, NULL, 
"1 BROADGATE", NULL, NULL, NULL, "LONDON EC2M 2AP", NULL, "UK", NULL, NULL, 
"0207 579 6073", NULL, "888811", "0207 579 6622", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(221, 27, "JEWELL", "MALCOLM", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7579 6557", NULL, NULL, 
"7579 6622", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(221, 28, "HARWOOD", "WILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7579 6459", NULL, NULL, 
"7579 6622", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(222, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "6103536169", NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(222, 2, "DOBECKA", "JONNY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(223, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3444818700", NULL, "31931NORPEE", 
"3444635966", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(223, 2, "AGUIRRE", "MARTA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+34 91 348 3001", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(223, 3, "BERNAR", "RAFAEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+34 91 348 3005", NULL, NULL, 
"+34 91 348 3067", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(223, 4, "TORIGANO", "ALFONSO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+34 91 348 3005", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(223, 5, "DEL MAR AMBRONA", "MA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "34 91 348 6138", NULL, 
NULL, "34 91 348 6220", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(224, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "652250939", NULL, "RS33191AMEPS", 
"652257370", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(225, 1, "SERMINSKI", "CHRISTINE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "3126637930", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(226, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "01712007000", NULL, "94015677", 
"01712007184", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(226, 2, "EASTMAN", "CARSTEN", NULL, NULL, 
"155 BISHOPSGATE", NULL, NULL, NULL, "LONDON EC2N3DA", NULL, "UK", NULL, NULL, 
NULL, NULL, "94015677", "01712007184", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(226, 3, "KLEIMAN", "MICHAEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(226, 4, "TOLLIDAY", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "200-7565", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(226, 5, "BETTERIDGE", "ROSANNA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(226, 6, "RAPP", "DAVE", NULL, NULL, 
"155 BISHOPSGATE", NULL, NULL, NULL, "LONDON EC2N3DA", NULL, "UK", NULL, NULL, 
NULL, NULL, "94015677", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(227, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "652241788", NULL, "20879", 
"652241098", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(228, 1, "DURELS", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2015673020", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(228, 2, "JANSEN", "GERT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(228, 3, "MISAK", "MARY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(228, 4, "GOWRIE", "DON", NULL, "OPERATIONS", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(229, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(229, 2, "DANIEL", "MORALES", NULL, NULL, 
"2000 WESTCHESTER AVE.", NULL, NULL, NULL, "WHITE PLAINS", "NY", "USA", 
"10650-000", NULL, "713-752-3274", NULL, NULL, NULL, NULL, NULL, 2, "A", 1)
go

insert into account_contact values(229, 3, "VAN ZANTEN", "CHRISTY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 3, "A", 1)
go

insert into account_contact values(229, 4, "DAVE", "JELLYMAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(230, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(231, 1, "KIM", "N.J.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "652201266", NULL, "RS 26495", 
"652211225", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(231, 2, "SOK-WON", "MR. SUH", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(232, 1, "MERISON", "GUY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "1", NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(232, 2, "EICHMAN", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(232, 3, "VOLKER", "HEIKO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(232, 4, "O'NEIL", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(232, 5, "DOCHERY", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(232, 6, "SILVAH", "ROB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(232, 7, "KINNEAR", "KIRK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(232, 8, "COPP", "BRIAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(232, 9, "SERIE", "SUE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(232, 10, "URQHART", "BRUCE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "212-536-8905", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(232, 11, "SCHMIDT", "KARL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+441712017158", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(233, 1, "XX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, "XXXX", NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(233, 2, "LEVY", "MICHAEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "570-0170", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(234, 1, "TAYLOR-SIMPSON", "CECILLE", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2126229773", NULL, 
NULL, "2126221836", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(234, 2, "FELSKE", "LARRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(234, 3, "JARRETT", "KEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(235, 1, "PEDERSEN", "MICHAEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "33634000", NULL, "16260", 
"33633878", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(235, 2, "HALD", "FLEMING", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0045-33 633 885", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(236, 1, "SINGH", "DONNA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "214-978-8812", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(237, 1, "KLOMP", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(237, 2, "KLOMP", "TON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(238, 1, "GEIGER", "TROY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "5015214494", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(239, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(239, 2, "BRADY", "JOE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(239, 3, "DANAHER", "PAT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(239, 4, "HANSON", "DENNIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "1", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(239, 5, "MALAZZO", "JOE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(240, 1, "CARRASCO", "RAMON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(240, 2, "GARCIA", "LALY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "34 91 337 6203", NULL, NULL, 
"34 91 337 6198", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(241, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(241, 2, "MR", "SAKAKIBARA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(242, 1, "TILL", "MARK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "(44.171)375.221", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(242, 2, "JENKINS", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "(44.171)375.221", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(242, 3, "RICHARD", "CHOYNOWSKI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "1", NULL, NULL, "1", 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(243, 1, "CHISMAR", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "658389014", NULL, NULL, 
"658389010", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(243, 2, "RACICOT", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "658389014", NULL, NULL, 
"658389010", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(243, 3, "SAWJANI", "MITA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "I", 1)
go

insert into account_contact values(243, 4, "GLEAVE", "FRANK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(243, 5, "ROSS", "KOHLER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0171 316 5427", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(244, 1, "ALFANI", "PAOLO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "39277371", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(244, 2, "BURRY", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(244, 3, "BARRY", "GROVES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0171-8022000", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(245, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(245, 2, "ROSE", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(246, 1, "JONES", "IAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "441714080589", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(246, 2, "CARTER", "SCOTT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "441442879355", "441714080589", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(246, 3, "FITCH", "HEIDI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "441714080589", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(247, 1, "MARTIN", "SHAMUS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(248, 1, "JOHNSON", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2813855004", "7138698700", NULL, 
"6868905", "7138698069", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(248, 2, "STANLEY", "ALAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2814820299", "7138698700", NULL, 
"6868905", "7138698069", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(249, 1, "LUBIN", "REGINA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2039786936", NULL, "6819522", 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(250, 1, "TURNER", "COLIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "31104033562", NULL, "23573", 
"31104033580", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(250, 2, "HAGOORT", "BEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "31 10 403 3302", NULL, NULL, 
"31 10 403 3483", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(251, 1, "ASSOULINE", "YAMINE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "41229092824", NULL, 
"412046", "41229092820", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(252, 1, "BERUBE", "NORMAND", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7138071511", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(253, 1, "TARASSOVSKIS", "NATALIA", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "003726503532", 
NULL, "173013", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(254, 1, "ACKLEY", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(254, 2, "GREBINSKY", "GENE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(254, 3, "DYER", "JAMES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(254, 4, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"A", 1)
go

insert into account_contact values(254, 5, "GUZIK", "KAREN", NULL, NULL, 
"200 PUBLIC SQUARE, 5W", NULL, NULL, NULL, "CLEVELAND", "OH", "USA", "44114", 
NULL, NULL, NULL, "62917760", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(254, 6, "JUNE", "ALLISON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(255, 1, "X", "XX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(255, 2, "KOHLER", "ROSS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(255, 3, "CLARKE", "NIAMH", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(255, 4, "HANSON", "ERIC", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(255, 5, "HORROWITZ", "MARK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(256, 1, "PRATT", "LIZ", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "8185052691", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(256, 2, "THOMAS", "RAY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(256, 3, "FOLEY", "PAT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(256, 4, "WELLER", "BRUCE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(256, 5, "MCNALLY", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(257, 1, "XX", "XX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(258, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(259, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(259, 2, "TAMBASCO", "MIKE", "ICE", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(260, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(261, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(262, 1, ".", "PETER", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(263, 1, "ANDREWS", "LES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "44 171 6293164", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(263, 2, "VEGARD", "ISAKSEN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0171-6293164", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(263, 3, "MIKE", "PHOENIX", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0171-6293164", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(263, 4, "EVERATT", "JULIA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "44 171 629 3164", NULL, NULL, 
"44 171 491 2284", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(264, 1, "VENTERA", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(265, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(266, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(267, 1, "IZUZKIZA", "NACHO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "+34 91 348 8178", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(268, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(268, 2, "JOE", "MALAZO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-507-6542", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(269, 1, "HANS", "VAN ROOIJEN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(270, 1, "VARIOUS", "VARIOUS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(271, 1, "DOE", "PHILLIP", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(272, 1, "X", "X", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(272, 2, "MALECKI", "ERIC", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "2038664600", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(273, 1, "DAN", "ENG", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, "65-839-4708", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(273, 2, "MELIA", "PAT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(274, 1, "EAKENS", "RANDY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-664-6017", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(275, 1, "DUMPLETON", "RICHARD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(275, 2, "DAVID", "SCOTT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(275, 3, "KOHN", "JERRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(275, 4, "COHEN", "JERRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(276, 1, "CORRIS", "DAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(277, 1, "VAN POECKE", "PAUL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "01646-691266", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(277, 2, "OLAF", "GRIFFIOEN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "01646-691201", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(278, 1, "LI", "BO", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, "861068568722", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(278, 2, "LI", "BO", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "8610-68568722", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(279, 1, "MULLER", "OLIVIER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(280, 1, "MILLER", "TRACEY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "0171-629-4500", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(280, 2, "HAWKINS", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "201-567-5300", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(280, 3, "ELLEN", "MARY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(280, 4, "GODSMARK", "PHILIP", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(281, 1, "X", "X", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(281, 2, "REDPATH", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "1", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(282, 1, "BROWN", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(283, 1, "KNOWN", "UN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(283, 2, "TOLLIDAY", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "44.207.200.7565", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(284, 1, "DEPARTMENT", "CONTRACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(285, 1, "MJAALAND", "DEBBIE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(286, 1, "DEPARTMENT", "CONTRACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(287, 1, "CONTACT", "CONTACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(287, 2, "SZABO", "LES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(288, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(288, 2, "SLEEPER", "MARK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-881-9677", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(288, 3, "LUPTON", "BRENT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-881-3677", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(289, 1, "STEWART", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(289, 2, "KEFFER", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(289, 3, "MORGAN", "CHERYL", NULL, NULL, 
"1600 SMITH STREET", "SUITE 1300", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
NULL, NULL, NULL, NULL, "713/652-2730", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(289, 4, "FEWOX", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(289, 5, "HOLMES", "NICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-646-4255", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(289, 6, "O'LIVIA", "CINDY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(290, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(291, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(292, 1, "RICH", "MARC", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(293, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(294, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(295, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(296, 1, "CONTACT", "CONTACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(296, 2, "KLAASEN", "BRENDA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+31 10 292 9933", NULL, 
NULL, "+31 10 482 9190", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(296, 3, "BRAND", "BERT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "31 10 292 9933", NULL, NULL, 
"31 10 482 9190", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(297, 1, "CONTACT", "CONTACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(297, 2, "BARBARA", "HAM", NULL, NULL, 
"DEFAULT ADDRESS", NULL, NULL, NULL, "DEFAULT CITY", NULL, "USA", NULL, NULL, 
"0031102888889", NULL, NULL, "0031102888899", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(298, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(298, 2, "ROTHWELL", "NEIL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(299, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(300, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(301, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(302, 1, "BAILEY", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(302, 2, "DUNLAP", "MARIA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(302, 3, "SCOTT", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(303, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(304, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(305, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(306, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(307, 1, "ADAMS", "C.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(308, 1, "OWEN", "FRED", NULL, 
"CRUDE OIL MGR", "1930 NEWPORT AVE.", NULL, NULL, NULL, "DALLAS", "TX", "USA", 
"75224", "214/333-8433", "972/450-4761", NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(308, 2, "KRUG", "KEN", NULL, NULL, 
"12790 MERIT DRIVE", "SUITE 800", NULL, NULL, "DALLAS", "TX", "USA", 
"75251-1270", NULL, NULL, NULL, NULL, "972/450-4740", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(309, 1, "FRANSSON", "FRANK", NULL, "MR", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(310, 1, "FRANKLIN", "SONDRA", NULL, 
"CONTRACT ADMINISTRATOR", "14819 BRISTOL HARBOR CIRCLE", NULL, NULL, NULL, 
"HOUSTON", "TX", NULL, "77084", "281/859-2851", "713.739-2235", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(310, 2, "GARCIA", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(311, 1, "WRAY", "DON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(311, 2, "TYLER", "KEVIN", NULL, NULL, 
"DEFAULT ADDRESS", NULL, NULL, NULL, "DEFAULT CITY", NULL, "USA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(311, 3, "KEFFER", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(312, 1, "BOREMASTER", "SCOTT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(313, 1, "MULLER", "RADI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(314, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(314, 2, "TUCKER", "ROY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "281-634-8400", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(315, 1, "DARROCH", "DOUG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(315, 2, "SPEER", "RHONDA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(315, 3, "WRAY", "DON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "281-287-5655", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(316, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(317, 1, "DEPT", "CONTRACT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(317, 2, "JALBERT", "KEITH", NULL, NULL, 
"1313 PINHOOK ROAD, SUITE 203B", NULL, NULL, NULL, "LAFAYETTE", "LA", "USA", 
"70503", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(317, 3, "VON", "BERG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-260-2616", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(317, 4, "VONBERG", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-260-2616", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(318, 1, "SCOTT", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(318, 2, "DODARO", "FRANK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(318, 3, "WILLIAMSON", "BRUCE", NULL, NULL, 
"5051 WESTHEIMER, SUITE 1400", NULL, NULL, NULL, "HOUSTON", "TX", "USA", 
"77056-2124", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(319, 1, "KIRISTO", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(319, 2, "WILSON", "CHARLIE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 2, "A", 1)
go

insert into account_contact values(320, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(320, 2, "MEE", "JONNEY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(320, 3, "VOSKO", "SPENCER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(321, 1, "VANGERVEN", "GERD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(322, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(322, 2, "CARPER", "KENT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(322, 3, "YONKO", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(322, 4, "SAWYER", "CINDY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(322, 5, "MENDEL", "DICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-296-2404", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(323, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(324, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(325, 1, "LEE", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(325, 2, "CENDERJAS", "PHILLIS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(325, 3, "MOLDEN", "CHRIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(325, 4, "HAMBURGER", "KENNY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(325, 5, "ANDERSON", "BRUCE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(325, 6, "WITT", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "(713) 754-4912", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(326, 1, "JONES", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(326, 2, "S", "HAROLD", NULL, NULL, 
"9 D13 ADAMS BUILDING", NULL, NULL, NULL, "BARTLESVILLE", "OK", "USA", "74004", 
NULL, NULL, NULL, "796289", "918/662-2112", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(327, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(327, 2, "RICH", "FREEDMAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713 655-1010", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(328, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(329, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(329, 2, "ROSE", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ".", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(329, 3, "WONG", "DALE", NULL, NULL, 
"DEFAULT ADDRESS", NULL, NULL, NULL, "DEFAULT CITY", NULL, "USA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(330, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(330, 2, "COPP", "BRIAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(330, 3, "GASSAWAY", "MARK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "(713) 609-4950", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(331, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(331, 2, "LEE", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(332, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(332, 2, "MUIR", "IAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(333, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(334, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(334, 2, "LASHELLE", "SCOTT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(335, 1, "WELTERS", "LUKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(335, 2, "MAXEL", "MARK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(336, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(336, 2, "JIM", "JIM", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "5015", NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(337, 1, "DEPARTMENT", "CONTRACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(337, 2, "KOURONEN", "PEKKA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "1", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(338, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(339, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(340, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(341, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(342, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(343, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(343, 2, "SPENSER", "VOSCOE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(344, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(345, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(346, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(347, 1, "NAME", "NO", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(348, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(348, 2, "COLLOSANTO", "LIVIO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+390685094706", NULL, 
NULL, "+390685094810", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(349, 1, "CONTRACTS", "DEPARTMENT", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(350, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(351, 1, "MARSDEN", "RYAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "44 20 7629-6668", NULL, NULL, 
"44 20 7693-4406", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(352, 1, "BROKER", "CONTACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(353, 1, "OWNER", "SHIP", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(354, 1, "CONTRACTS", "DEPARTMENT", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(355, 1, "CONTRACTS", "DEPARTMENT", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(356, 1, "QUINN", "SEAMUS", "OPS MGR", "MR.", 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, "+44 1504 352885", 
"+44 1504 865014", NULL, NULL, "+44 1504 861182", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(357, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(358, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(359, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(360, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(361, 1, "SINNETT", "JEFF", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(361, 2, "BOHNENBLUST", "DAVID", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "316-241-9159", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(362, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(363, 1, "KARNEI", "GLENN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(364, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(365, 1, "CHRICHLOW", "SHARON", NULL, 
"OPERATIONS", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(366, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(367, 1, "AHL", "THOMAS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0704 440 610", NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(368, 1, "MIKE", "CAVALIERE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(369, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(369, 2, "WOHL", "ERIC", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(370, 1, "PERSON", "CONTACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(371, 1, "PERSON", "CONTACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(372, 1, "PERSON", "CONTACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(373, 1, "UNKNOWN", "UNKNOWN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(374, 1, "UNKNOWN", "UNKNOWN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(375, 1, "BRASSER", "MARCEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "00 31 78 648 56", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(375, 2, "MEIJER", "NICKY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(375, 3, "ABRAHMSE", "ARIE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "00 31 78 648 56", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(376, 1, "DEPARTMENT", "CONTRACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(377, 1, "UNKNOWN", "UNKNOWN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(378, 1, "UNKNOWN", "UNKNOWN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(379, 1, "X", "X", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(380, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(381, 1, "CONTRACTS", "DEPARTMENT", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(381, 2, "MURRAY", "GLEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+33493323535", NULL, NULL, 
"+33493325275", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(382, 1, "X", "X", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(383, 1, "KARNIE", "GLENN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(384, 1, "CINELLI", "BIAGIO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(385, 1, "MACAVITY", "MALCOLM", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(385, 2, "X", "X", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(386, 1, "?", "?", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(387, 1, "MCGRANE", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(387, 2, "GARVIN", "BARRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(388, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(388, 2, "MR", "FRENZEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(389, 1, "CONTACT", "PERSON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(389, 2, "FRENCH", "ROBERT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(389, 3, "ALISTAIR", "GORDON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(390, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(391, 1, "STORAGE", "SPREAD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(392, 1, "SALAUN", "B.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(393, 1, "EGELAND", "FRODE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(393, 2, "URBAN", "BRAD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(393, 3, "DELVECCHIO", "CHRIS", NULL, NULL, 
"4111 E. 37TH STREET N.", "P.O. BOX 2256", NULL, NULL, "WICHITA", "KS", "USA", 
"67201-225", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(393, 4, "TURLEY", "DAN", NULL, NULL, 
"4111 E. 37TH STREET N.", "P.O. BOX 2256", NULL, NULL, "WICHITA", "KS", "USA", 
"67201-225", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(393, 5, "WALRATH", "JAY", NULL, NULL, 
"4111 E. 37TH STREET N.", "P.O. BOX 2256", NULL, NULL, "WICHITA", "KS", "USA", 
"67201-225", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(393, 6, "BATTEN", "TYLER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(393, 7, "WYMAN", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "(316) 828-6951", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(393, 8, "SMITH", "TRACEY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(394, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, "003574664930", NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(395, 1, "URQUHART", "BRUCE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(396, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, "01718394271", NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(397, 1, "KERKOF", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(398, 1, "?", "?", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(398, 2, "PERSE", "VEDRAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(399, 1, "CIRKVENI", "DR NEVIN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(400, 1, "?", "?", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, "?", NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(401, 1, "?", "?", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(402, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(402, 2, "ROHNER", "KURT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(403, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(404, 1, "TCT", '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(405, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(406, 1, "?", "CONTACT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(407, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(408, 1, "KOPECEK", "C", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, "862129", NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(409, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(410, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(411, 1, "PRUETT", "STEVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(412, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(413, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(414, 1, "BRADSHAW", "DAVID", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(414, 2, "WILSON", "LISA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(415, 1, "CONTRACT", "DEPARTMENT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(416, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(416, 2, "GARY", "GOODWIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(417, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(418, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(418, 2, "HAN", "JIN", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "A", 1)
go

insert into account_contact values(419, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(420, 1, "ABELS", "JAMES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(420, 2, "THOMEN", "MARTY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(421, 1, "PITCHER", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(422, 1, "HAMILTON", "DON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(423, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(424, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(425, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(426, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(427, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(428, 1, "MJAALAND", "DEBBIE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(428, 2, "BROWNE", "REX", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(429, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(430, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(431, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(432, 1, "KIVISTO", "TOM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(433, 1, "KLUKSDAHL", "D.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(434, 1, "MAAKE", "ROGER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(435, 1, "MIIRABAGHERI", "MIKE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(436, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(437, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(438, 1, "BREWER", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(439, 1, "1", "1", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(440, 1, "HO", "HO", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, "65239499259", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(441, 1, "DECLIN BLACK", "BLACKEY", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(441, 2, "BLACK", "DECLAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+35 31 676 5831", NULL, NULL, 
"+35 31 661 5430", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(441, 3, "FARRELL", "PHILLIP", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+35 31 676 5831", NULL, 
NULL, "+35 31 661 5430", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(442, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(443, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(444, 1, "BOURGEORS", "PHI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(444, 2, "BOURGOIS", "PHILLIP", NULL, NULL, 
"DEFAULT ADDRESS", NULL, NULL, NULL, "DEFAULT CITY", NULL, "USA", NULL, NULL, 
"+441714878223", NULL, NULL, "+441714878509", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(445, 1, "STROM", "LYLE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(446, 1, "DOBECKA", "JONNY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(446, 2, "WINCE", "BILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(447, 1, "RELIANT", "RELIANT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(448, 1, "SPROTT", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "011-41223629649", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(449, 1, "SOK-WON", "SUH", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "01719309866", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(450, 1, "1", "1", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(451, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(452, 1, "1", "1", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(453, 1, "PRATT", "RON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(454, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(455, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(455, 2, "TANK", "406", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "406", NULL, NULL, "406", NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(455, 3, "TANK", "1904", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "1", NULL, NULL, "1", NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(456, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(457, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(457, 2, "MARICK", "GREY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "44171579 6666", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(457, 3, "GRABINSKI", "GENE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(457, 4, "JAMES", "DYER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "630-836-6703", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(457, 5, "STEFAN", "DIXON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "5796000", NULL, NULL, "1", 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(458, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(458, 2, "HERNANDEZ", "JESSE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-993-5200", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(458, 3, "SANFORD", "ROBERT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-993-5200", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(458, 4, "LEE", "JIM", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "(713) 993-5200", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(458, 5, "PALMER", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(459, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(460, 1, "DEPARTMENT", "CONTRACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(461, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(461, 2, "SCOTT", "SPARROW", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "801-524-2855", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(461, 3, "SPARROW", "SCOTT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "801-524-2855", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(461, 4, "COKER", "ERNIE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(462, 1, "COOPER", "ROB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "312-606-4140", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(463, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(464, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(465, 1, "1", "1", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(466, 1, "XXXXXX", "XXXXX", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(467, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(468, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(468, 2, "STREEFKERK", "SJAAK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+31 10 217 1600", NULL, 
NULL, "+31 10 412 2464", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(469, 1, "CREAMER", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(470, 1, "PERSON", "CONTACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(471, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, "XXX", NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(471, 2, "MORRISON", "TONI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(472, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(472, 2, "GASLINI", "RENATA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+39 02 86453914", NULL, 
NULL, "+39 02 86455390", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(473, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(474, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(474, 2, "STEF", "SCHOONEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(475, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(476, 1, "XXX", "XXX", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, "XXX", NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(477, 1, "ROSS", "JERRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(478, 1, "LEWIS", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "011441714909615", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(479, 1, "INVENTORY ROLL", "ROLL INVENTORY", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(480, 1, "KARNEI", "GLEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(480, 2, "DURGAN", "CARMEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(481, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(482, 1, "OLSEN", "JACK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(483, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(484, 1, "KWAYTAAL", "JAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(484, 2, "(IN ACCOUNTS)", "MARCO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(485, 1, "CONTRACTS", "DEPARTMENT", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(486, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(486, 2, "GRABINSKI", "GENE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "630-836-6703", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(487, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(487, 2, "UMBELINA", "CARLOS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+35 11 352 5353", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(487, 3, "COSTA", "DUARTE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+35 11 352 5353", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(488, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(489, 1, "DE WILT", "ALEX", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(490, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(490, 2, "CARLA", "HOUTMAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0031104360533", NULL, NULL, 
"0031104360439", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(491, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(491, 2, "MEULDER", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+32 2 232 3910", NULL, NULL, 
"+32 3  232 5647", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(492, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(492, 2, "KU", "STEPHEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+852 2891 4882", NULL, NULL, 
"+852 2891 4882", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(493, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(494, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(495, 1, "CONTRACTS", "DEPARTMENT", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(496, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(497, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(498, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(499, 1, "PERSON", "CONTACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(500, 1, "PERSON", "CONTACT", "]", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(501, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(502, 1, "ZHAI", "BERNEY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "00852-25080228", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(503, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(504, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(505, 1, "CONTRACTS", "DEPARTMENT", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(506, 1, "BATTAGLIA", "KERRI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(507, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(507, 2, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"A", 1)
go

insert into account_contact values(508, 1, "Y.H.", "LEE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, 
"011-65-333-6123", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(509, 1, "BLELOCH", "CLAIRE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "171 499 8585", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(510, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(511, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(512, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(513, 1, "PENELLO", "WAYNE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(514, 1, "SWITZER", "DAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(515, 1, "DEPT", "CONTRACT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(516, 1, "BROUWERS", "LUC", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(517, 1, "SCHAFER", "KENDAL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(518, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(519, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(520, 1, "ALTEMARA", "DREW", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "205-391-3503", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(521, 1, "MUNSCH", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7135075703", NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(522, 1, "WILLINGHAM", "MIKE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(523, 1, "STRAND", "WAYDE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(524, 1, "CONTRACTS", "DEPARTMENT", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(525, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(525, 2, "CLIFF", "PAPISH", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(526, 1, "SAVAGE", "SANDY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, " 01252741421", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(527, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(528, 1, "MESSER", "NOEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(529, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(530, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(531, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(532, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(533, 1, "LAMONTAGNE", "GILLES", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(534, 1, "HARVEY", "TIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(535, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(536, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(536, 2, "PRESSLEY", "RICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(537, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(538, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(539, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(540, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(541, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(542, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(543, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(544, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(545, 1, "TEST", "TEST", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(546, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(547, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(548, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(549, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(550, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(551, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(552, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(553, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(554, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(555, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(556, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(557, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(558, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(559, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(560, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(561, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(562, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(563, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(564, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(565, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(566, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(567, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(568, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(569, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(570, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(571, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(572, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(573, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(574, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(575, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(576, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(577, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(578, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(579, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(580, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(581, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(582, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(583, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(584, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(585, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(586, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(587, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(588, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(589, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(590, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(591, 1, " B", " N", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(592, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(593, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(594, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(595, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(596, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(597, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(598, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(599, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(600, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(601, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(602, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(603, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(603, 2, "HAMMETT", "GARY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "555", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(604, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(605, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(606, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(607, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(608, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(609, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(610, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(611, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(612, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(613, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(614, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(615, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(616, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(617, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(618, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(619, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(620, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(621, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(622, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(623, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(624, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(625, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(626, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(627, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(628, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(629, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(630, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(631, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(632, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(633, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(634, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(635, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(636, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(637, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(638, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(639, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(640, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(641, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(642, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(643, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(644, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(645, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(645, 2, "MILLER", "MATT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(646, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(647, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(648, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(649, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(650, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(651, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(652, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(653, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(654, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(655, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(656, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(657, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(658, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(659, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(660, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(661, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(662, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(663, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(664, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(665, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(666, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(667, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(668, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(669, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(670, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(671, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(672, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(672, 2, "KARDUX", "JAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+31 181 602035", NULL, NULL, 
"+31 181 621347", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(673, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(674, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(675, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(676, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(677, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(678, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(679, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(680, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(681, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(682, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(683, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(684, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(685, 1, "STATEMAN", "MARIA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(686, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(687, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(688, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(689, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(690, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(691, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(692, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(693, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(694, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(695, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(696, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(697, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(698, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(699, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(700, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(701, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(702, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(703, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(704, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(705, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(707, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(708, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(709, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(710, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(711, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(712, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(713, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(714, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(715, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(716, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(717, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(718, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(719, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(719, 2, "MCCANN", "MICHAEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+35 361 392 488", NULL, 
NULL, "+35 361 604031", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(720, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(721, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(722, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(723, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(724, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(725, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(726, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(727, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(728, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(729, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(730, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(731, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(732, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(733, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(734, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(735, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(736, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(737, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(738, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(739, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(740, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(741, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(742, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(743, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(744, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(745, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(746, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(747, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(748, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(749, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(750, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(751, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(752, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(753, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(754, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(755, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(756, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(757, 1, '', '', "-", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(758, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(759, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(760, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(761, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(762, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(763, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(764, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(765, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(766, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(767, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(768, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(769, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(770, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(771, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(772, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(773, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(774, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(775, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(776, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(777, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(778, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(779, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(780, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(781, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(782, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(783, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(784, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(785, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(786, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(787, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(788, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(789, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(790, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(791, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(792, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(793, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(794, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(795, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(796, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(797, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(798, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(799, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(800, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(801, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(802, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(803, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(804, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(805, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(806, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(807, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(808, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(809, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(810, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(811, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(812, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(813, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(814, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(815, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(816, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(817, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(818, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(819, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(820, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(821, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(822, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(823, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(823, 2, "TSCHONIC", "KERRY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(823, 3, "DYKSTA", "LARRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "A", 1)
go

insert into account_contact values(824, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(825, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(826, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(827, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(828, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(829, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(830, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(831, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(832, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(833, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(834, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(835, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(836, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(837, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(838, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(839, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(840, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(841, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(842, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(843, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(844, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(845, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(846, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(847, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(848, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(849, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(850, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(851, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(852, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(853, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(854, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(855, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(856, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(857, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(858, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(859, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(860, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(861, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(862, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(863, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(864, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(865, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(866, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(867, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(868, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(869, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(870, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(871, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(872, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(873, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(874, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(875, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(876, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(877, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(878, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(879, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(880, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(881, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(882, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(883, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(884, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(885, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(886, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(887, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(888, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(889, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(890, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(891, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(892, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(893, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(894, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(895, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(896, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(897, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(898, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(899, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(900, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(901, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(902, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(903, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(904, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(905, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(906, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(907, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(908, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(909, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(910, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(911, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(912, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(913, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(914, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(915, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(916, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(917, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(918, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(919, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(920, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(921, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(922, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(923, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(924, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(925, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(926, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(927, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(928, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(929, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(930, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(931, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(932, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(933, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(934, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(935, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(936, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(937, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(938, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(939, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(940, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(941, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(942, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(943, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(944, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(945, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(946, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(947, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(948, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(949, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(950, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(951, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(952, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(953, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(954, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(955, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(956, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(957, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(958, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(959, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(960, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(961, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(962, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(963, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(964, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(965, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(966, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(967, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(968, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(969, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(970, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(971, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(972, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(973, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(974, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(975, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(976, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(977, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(978, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(979, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(980, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(981, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(982, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(983, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(984, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(985, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(986, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(987, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(988, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(989, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(990, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(991, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(992, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(993, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(994, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(995, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(996, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(997, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(998, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(999, 1, '', '', NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(1000, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1001, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1002, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1003, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1004, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1005, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1006, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1007, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1008, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1009, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1010, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1011, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1012, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1013, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1013, 2, "DENNIS", "CERNOSEK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "225-346-7499", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1014, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1015, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1016, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1017, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1018, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1019, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1020, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1021, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1022, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1023, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1024, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1025, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1026, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1027, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1028, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1029, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1030, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1031, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1032, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1033, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1034, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1035, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1036, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1037, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1038, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1039, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1040, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1041, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1042, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1043, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1044, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1045, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1046, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1047, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1048, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1049, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1050, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1051, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1052, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1053, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1054, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1055, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1056, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1057, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1058, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1059, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1060, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1061, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1062, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1063, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1064, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1065, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1066, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1067, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1068, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1069, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1070, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1071, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1072, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1073, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1074, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1075, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1076, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1077, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1078, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1079, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1080, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1081, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1082, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1083, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1084, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1085, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1086, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1087, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1088, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1089, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1090, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1091, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1092, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1093, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1094, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1095, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1096, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1097, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1098, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1099, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1100, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1101, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1102, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1103, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1104, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1105, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1106, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1107, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1108, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1109, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1110, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1111, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1112, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1113, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1114, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1115, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1116, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1117, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1118, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1119, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1120, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1121, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1122, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1123, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1124, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1125, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1126, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1127, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1128, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1129, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1130, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1131, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1132, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1133, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1134, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1135, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1136, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1137, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1138, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1139, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1140, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1141, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1142, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1143, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1144, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1145, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1146, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1147, 1, " Q", '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1148, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "Q", 1, 
"A", 1)
go

insert into account_contact values(1149, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1150, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1151, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1152, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1153, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1154, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1155, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1156, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1157, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1158, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1159, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1160, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1161, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1162, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1163, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1164, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1165, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1166, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1167, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1168, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1169, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1170, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1171, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1172, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1173, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1174, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1175, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1176, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1177, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1178, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1179, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1180, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1181, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1182, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1183, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1184, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1185, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1186, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1187, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1188, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1189, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1190, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1191, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1192, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1193, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1194, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1195, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1196, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1197, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1198, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1199, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1200, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1201, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1202, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1203, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1204, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1205, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1206, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1207, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1208, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1209, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1210, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1211, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1212, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1213, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1214, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1215, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1216, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1217, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1218, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1219, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1220, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1221, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1222, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1223, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1224, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1225, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1226, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1227, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1228, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1229, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1230, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1231, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1232, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1233, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1234, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1235, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1236, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1237, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1238, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1239, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1240, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1241, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1242, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1243, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1244, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1245, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1246, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1247, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1248, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1249, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1250, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1251, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1252, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1253, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1254, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1255, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1256, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1257, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1258, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1259, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1260, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1261, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1262, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1263, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1264, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1265, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1266, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1267, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1268, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1269, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1270, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1271, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1272, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1273, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1274, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1275, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1276, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1277, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1278, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1279, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1280, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1281, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1282, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1283, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1284, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1285, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1286, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1287, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1288, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1289, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1290, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1291, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1292, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1293, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1294, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1295, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1296, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1297, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1298, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1299, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1300, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1301, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1302, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1303, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1304, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "`", NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1305, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1305, 2, "SOCCIARELLO", "VANESSA", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "00390652088747", 
NULL, NULL, "00390652088724", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1306, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1307, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1308, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1309, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1310, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1311, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1312, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1313, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1314, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1315, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1316, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1317, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1318, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1319, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1320, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1321, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1322, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1323, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1324, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1325, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1326, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1327, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1328, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1329, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1330, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1331, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1332, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1333, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1334, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1335, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1336, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1337, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1338, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1339, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1340, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1341, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1342, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1343, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1344, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1345, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1346, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1347, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1348, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1349, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1350, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1351, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1352, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1353, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1354, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1355, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1356, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1357, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1358, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1359, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1360, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1361, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1362, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1363, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1364, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1365, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1366, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1367, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1368, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1369, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1370, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1371, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1372, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1373, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1374, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1375, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1376, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1377, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1378, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1379, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1380, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1381, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1382, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1383, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1384, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1385, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1386, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1387, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1388, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1389, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1390, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1391, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1392, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1393, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1394, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1395, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1396, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1397, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1398, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1399, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1400, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1401, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1402, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1403, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1404, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1405, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1406, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1407, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1408, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1409, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1410, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1411, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1412, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1413, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1414, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1415, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1416, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1417, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1418, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1419, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1420, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1421, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1422, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1423, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1424, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1425, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1426, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1427, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1428, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1429, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1430, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1431, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1432, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1433, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1434, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1435, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1436, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1437, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1438, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1439, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1440, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1441, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1442, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1443, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1444, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1445, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1446, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1447, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1448, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1449, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1450, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1451, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1452, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1453, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1454, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1455, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1456, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1457, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1458, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1459, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1460, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1461, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1461, 2, "MILTON", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "44 181 902 1378", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1462, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1463, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1464, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1465, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1466, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1467, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1468, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1469, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1470, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1471, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1472, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1473, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1474, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1475, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1476, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1477, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1478, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1479, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1480, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1481, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1482, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1483, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1484, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1485, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1486, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1487, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1488, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1489, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1490, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1491, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1492, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1493, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1494, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1495, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1496, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1497, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1498, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1499, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1500, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1501, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1502, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1503, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1504, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1505, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1506, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1507, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1508, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1509, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1510, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1511, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1512, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1513, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1514, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1515, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1516, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1517, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1518, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1519, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1520, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1521, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1522, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1523, 1, "COURTNEY", "RICHARD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1524, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1525, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1526, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1527, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1528, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1529, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1530, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1531, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1532, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1533, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1534, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1535, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1536, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1537, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1538, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1539, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1540, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1541, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1542, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1543, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1544, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1545, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1546, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1547, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1548, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1549, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1550, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1551, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1552, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1553, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1554, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1555, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1556, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1557, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1558, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1559, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1560, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1561, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1562, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1563, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1564, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1565, 1, '', ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1566, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1567, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1568, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1569, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1570, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1571, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1572, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1573, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1574, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1575, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1576, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1577, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1578, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1579, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1580, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1581, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1582, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1583, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1584, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1585, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1586, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1587, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1588, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1589, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1590, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1591, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1592, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1593, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1594, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1595, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1596, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1597, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1598, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1599, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1600, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1601, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1602, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1603, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1604, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1605, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1606, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1607, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1608, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1609, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1610, 1, "CONTRACTS", "DEPARTMENT", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1611, 1, "-", "-", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, "-", NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1612, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1613, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1614, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1615, 1, "VAN KLOPPEN", "PETRA", NULL, 
"OPERATIONS", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1615, 2, "TERHOEVEN", "INGRID", NULL, 
"OPERATIONS", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1615, 3, "OOSTHOEK", "RAOUL", NULL, "BROKER", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1615, 4, "JANSSEN", "GERDT", NULL, "BROKER", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1615, 5, "RIETBERGEN", "MIRELLE", NULL, 
"BROKER", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1616, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1617, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1618, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1619, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1620, 1, "UNKNOWN", "UNKNOWN", NULL, NULL, 
"MONTE DEI PASCHI DI SIENA SPA", "NAPLES BRANCH", "A/C # 60913", NULL, "NAPLES", 
NULL, "I", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1621, 1, "UNKNOWN", "UNKNOWN", NULL, NULL, 
"NATIONAL BANK OF GREECE", "BRANCH 196", "65, AKTI MIAOULI", "A/C # 502743/84", 
"PIRAEUS", NULL, "GR", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 
1)
go

insert into account_contact values(1622, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1623, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1624, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1625, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1626, 1, "`", '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1627, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1628, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1629, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1630, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1631, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1632, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1633, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1634, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1635, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1636, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1637, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1638, 1, "ESSE", "TODD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1639, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1640, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1641, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1642, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1643, 1, "FREIJA", "LIPPENS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1644, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1645, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1646, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1647, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1648, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1649, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1650, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1651, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1652, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1652, 2, "CHRIS", "DELVECHIO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "216-586-6131", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1653, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1654, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1655, 1, '', " V", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1656, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1657, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1658, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1659, 1, "HONG", "YAO", NULL, 
"CRUDE OIL DIVISION TRADING MGR", NULL, NULL, NULL, NULL, NULL, NULL, "USA", 
NULL, NULL, "86 10 64990321", NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1660, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1661, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1662, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1663, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1664, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1665, 1, "MALINOVSKAYA", "TATIANA", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1666, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1667, 1, "SORENSSEN", "NILS ERIC", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "45.98.127277", 
NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1667, 2, "WILMAR", "HELLE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "45 99 31 8372", NULL, NULL, 
"45 98 16 7277", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1668, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1669, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1670, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1671, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1672, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1673, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1674, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1675, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1676, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1677, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1678, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1679, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1680, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1681, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1682, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1683, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1684, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1685, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1686, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1687, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1688, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1689, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1690, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1691, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1692, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1693, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1694, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1695, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1696, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1697, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1698, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1699, 1, "YUNFEI", "AN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0065 2250290", NULL, NULL, NULL, 
"0065 3245166", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1700, 1, "A DIV OF BP OIL", '', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1701, 1, "CHEN", "JASON WEI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "+44 171 2903580", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1702, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1702, 2, "BLOMQVIST", "ROBERT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+44 171 5354100", NULL, 
NULL, "+44 171 535 410", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1702, 3, "DEVENISH", "SIMON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+44 171 5354100", NULL, 
NULL, "+44 171 535 410", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1702, 4, "BELLANTI", "PHILLIP", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "+44 171 5354100", NULL, 
NULL, "+44 171 5354101", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1703, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1703, 2, "LEE", "LILY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "65 284 9134", NULL, NULL, 
"65 284 2683", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1704, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1705, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1706, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1707, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1708, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1709, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1710, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1711, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1712, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1713, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1714, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1715, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1716, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1717, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1718, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1719, 1, "VAN EIJCK", "MICHIEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "+31 181 240235", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1720, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1721, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1722, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1723, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1724, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1725, 1, "0", "0", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, "0", NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1726, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1727, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1728, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1729, 1, "VAN EIJCK", "MICHIEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "+31 181 240210", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1730, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1731, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1732, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1733, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1734, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1735, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1736, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1737, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1738, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1739, 1, "POLLEE", "ANS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "31 10 2953 400", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1740, 1, "POLLEE", "ANS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1741, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1742, 1, "KINCAID", "ROBERT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1743, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1744, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1745, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1746, 1, "PRESLEY", "RICK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1747, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1748, 1, "MYSTRAS II -NOV99", '', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1749, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1750, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1751, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1751, 2, "VAN EIJK", "MICHIEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1752, 1, "VAN EIJK", "MICHIEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1753, 1, "PERSON", "CONTACT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1754, 1, "DEPARTMENT", "FUEL -", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1755, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1756, 1, "WISDOM", "MARTIN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1757, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1758, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1759, 1, "VAN AANEN", "GERT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1760, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1761, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1762, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1763, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1763, 2, "ANDREWS", "PHIL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "44 171 753 4806", NULL, NULL, 
"44 171 753 4792", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1764, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1765, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1766, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1767, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1768, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1769, 1, "GALVIN", "CHUCK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1770, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1771, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1772, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1773, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1774, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1775, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1776, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1777, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1778, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1779, 1, "EVANASKI", "DAVE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1780, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1781, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1782, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1783, 1, "O'TOOLE", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1784, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1785, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1786, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1787, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1788, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1789, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1790, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1791, 1, "SEVCIK", "MAGALI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1792, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1793, 1, "GARDNER", "KIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1794, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1795, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1796, 1, "STEFAN", "BRUNNER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "+41223105246", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1797, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1798, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1799, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1800, 1, "ROB", "GORSKI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "792-6400", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1801, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1802, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1803, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1804, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1805, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1806, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1807, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1808, 1, '', "BARBARA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1808, 2, "SCARAMELLI", "BARBARA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "41 22 310 5263", NULL, 
NULL, "41 22 310 4202", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1809, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1810, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1811, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1812, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1813, 1, '', "BARBARA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1814, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1815, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1816, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1817, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1818, 1, "MCCLURE", "MICHAEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "961-7204", NULL, NULL, NULL, 
"961-0845", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1819, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1820, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1821, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1822, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1823, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1824, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1825, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1826, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1827, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1828, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1829, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1830, 1, "VAN WYNGAARDEN", "HERBERT", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1831, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1832, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1833, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1834, 1, "MUELLER", "UWE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1835, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1836, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1837, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1838, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1839, 1, "MACLEOD", "COLONEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1840, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1841, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1842, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1843, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1844, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1845, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1846, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1847, 1, "MONDAY", "LARRY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "502 627 3368", NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1848, 1, "KNABL", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1849, 1, "STRUCK", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1850, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1850, 2, "CHATOR", "THIERRY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "33 1 43 69 2746", NULL, 
NULL, "33 1 43 69 2142", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1851, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1852, 1, "LANSTRIM", " TIM", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1853, 1, "BOBER", "ED", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "212 536 8473", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1854, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1855, 1, "DICKINSON", "CAROL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713 627 4705", NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1856, 1, "BENBRAHIM", "MR", NULL, 
"AAST COMMERCIAL DIRECTOR", NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, 
NULL, "X", NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1857, 1, "X", "X", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, "X", NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1857, 2, "SESTITO", "MARIA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "39 010 240 1350", NULL, 
NULL, "39 010 240 1285", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1858, 1, "X", "X", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, "X", NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1859, 1, "X", "X", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, "X", NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1860, 1, "LIEMEN", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "49 305150 4735", NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1861, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1862, 1, "GIBSON", "TODD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1863, 1, "SULLIVAN", "JOHN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1864, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1865, 1, "BELL", "SALLY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "804 273 4191", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1866, 1, "BALATSOS", "DIMITRIOS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1867, 1, "KOKOSSOULIS", "CPT J", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1868, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1869, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1870, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1871, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1872, 1, "FLETCHER", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1873, 1, "BRIANTI", "YVONNE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, "USA", NULL, NULL, "377 93 25 46 54", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1874, 1, "APERJIS", "DIMITRI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1875, 1, "THYGESEN", "MIKE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1876, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1877, 1, "ERICSON", "LARS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1878, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1879, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1880, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1881, 1, "MARGETTIS", "CAPT M", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1882, 1, '', "-", "-", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1883, 1, "SHCEID", "NANCY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1884, 1, "STELTER", "HERR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1885, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
1, "A", 1)
go

insert into account_contact values(1886, 1, '', "-", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1887, 1, "ESTEBO", "CAROL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1888, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1889, 1, "MCCABE", "DES", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "00 35 321 52430", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1890, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1891, 1, "CASAGRANDE", "GIANNI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1892, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1893, 1, "SCHWANEKAMP", "FRAU", "`", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1894, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1895, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1896, 1, "OGAN", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1897, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1898, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1899, 1, "GORKA", "MRS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1900, 1, "GROSS", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1901, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1902, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1903, 1, "HENDERSON", "MARTIIN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1904, 1, "SHUMWAY", "THAD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1905, 1, "WILGES", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1906, 1, "LUDWIG", "AMY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1907, 1, "PETER", "SCHAU", NULL, 
"OPERATIONS", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1908, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1909, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1910, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1911, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1912, 1, "MR.", "SCHLUNKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1913, 1, "JOESCHKE", "MICHAEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1914, 1, "MANDEL", "KLAUS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1915, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1916, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1917, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1918, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1919, 1, "LOVETT", "ANNE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1920, 1, "SCHMIDT", "HERR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1921, 1, "WAGNER", "BRYAN", NULL, 
"CREDIT RISK MANAGER", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1922, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1923, 1, '', '', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1924, 1, "SOTIROPOULOS", "VICTOR", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "42 92 262 / 66", NULL, 
NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1925, 1, "TSOU", "STEPHEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1926, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1927, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1928, 1, "DAVIES", "CHARLES", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "201 692-9292", NULL, 
NULL, "201 692-1954", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1929, 1, "NOCON", "HOLGER", NULL, 
"SETTLEMENTS", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"49 5706 929 720", NULL, NULL, "49 5706 929 722", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1930, 1, ".", " .", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1931, 1, "PUCCI", "SERGIO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0335 6999099", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1931, 2, "BARTOLI", "ROBERTO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "0335 6999101", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1932, 1, "BALMON", "JOSE", NULL, 
"OPERATIONS", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "04122-311-0204", 
NULL, NULL, NULL, "04122-311-0242", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1933, 1, "SCRATCH", "DAVE", NULL, 
"AGENT FOR SASK MINRL", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"403 266-1460", NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1934, 1, "LITGEN", "TODD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "402 552-5632", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1935, 1, "EVES", "ROBIN", "MR. EVES", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "203 363-0337", NULL, NULL, 
NULL, "203 363-0905", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1936, 1, "KELLEHER", "ARLYNN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "281 297-3582", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1937, 1, "CAMPAILLA", "A.", NULL, "DIRECTOR", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "39 010 6974990", NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1938, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1939, 1, "COOPER", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "561 625-7698", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1940, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1941, 1, "ASMAN", "KEVIN", NULL, 
"KEVINA@FCEC.COM", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"403 531-6536", NULL, NULL, "403 266-6329", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1942, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1943, 1, "KAHL", "ROD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "815 937-8190", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1944, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1945, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1946, 1, "JUMP", "PHILIP", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "65 225-3966", NULL, NULL, NULL, 
"65 225-7370", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1947, 1, "NIIMURA", "HIROMICHI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1948, 1, "TAN WEE HIONG", "KEVIN", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "65 339-9574", NULL, 
NULL, "65 339-9278", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1949, 1, "VAN WANROOIJ", "PETER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "65 535 5555", NULL, NULL, 
"65 538 8277", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1950, 1, "TAN LOU TUAN", "MACARI", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "65 536-1788", NULL, NULL, 
NULL, "65 536-2133", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1951, 1, "YOSHIDA", "MASAYUKI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "65 735-4044", NULL, NULL, 
"65 735-4944", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1951, 2, "LUA", "GENI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "7354144", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(1952, 1, "TAN", "RICHARD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "65 250-9977", NULL, NULL, NULL, 
"65 253-0561", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1953, 1, "G.E. YAP", "RICHARD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "65 221-9790", NULL, NULL, NULL, 
"65 226-2812", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1954, 1, "ROGERS", "PETER B.M.", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "65 372-0010", NULL, NULL, 
"65 224-3323", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1955, 1, "THAM", "LENNART", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "44 20 7823-5500", NULL, NULL, 
"44 20  7499-830", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1956, 1, "HAMILTON", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1957, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1958, 1, "EL GOHARY", "REFAAT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1959, 1, "EMWATANA", "PHICHET", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1960, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1961, 1, "MERRILLES", "DAVID", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1962, 1, "XIAO LI", "WNAG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1963, 1, "WEI LI", "GARY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1964, 1, "WANLIANG", "GAO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1965, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1966, 1, "PIN", "ZHOU", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1967, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1968, 1, "PESCHARD", "THIERRY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1969, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1970, 1, "THOMAS", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1971, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1972, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1973, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1974, 1, "TODE", "SHIGERU", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1975, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1976, 1, "HOBBS", "MIKE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1977, 1, ".", "TAKAHIASHI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1978, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1979, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1980, 1, "YUASA", "TOSHIO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1981, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1982, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1983, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1984, 1, "GOH", "PETER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1985, 1, "JITSUKATA", "Y.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1986, 1, "MACKENZIE", "SHAYNE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1987, 1, "NORTON", "RUSSELL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1988, 1, "MINEGISHI", "MINORU", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1989, 1, "TAKAYMAMA", "KAZUYOSHI", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1990, 1, "KATO", "HIROFUMI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1991, 1, "TOBIA", "MACHAEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1992, 1, "HOCK", "NG LOO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1993, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1994, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1995, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1996, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(1997, 1, "SEN", "D.D.", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(1998, 1, "FERNANDES", "SARAP", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(1999, 1, "YAMAMOTO", "KAZUNORI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2000, 1, "MASUKAWA", "TAKEAKI", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2001, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2002, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2003, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2004, 1, "KIM", "YOUNG-DAL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2005, 1, "OHM", "ICK JIN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2006, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2007, 1, "YIM", "SIMON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2008, 1, "NEWMAN", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2009, 1, "DUNCAN", "AMANDA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2010, 1, "LANDRY", "CHAD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713 956-3930", NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2011, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2012, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2013, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2014, 1, "HANSVIK", "METTE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "44 208 632 8003", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2015, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2016, 1, "KEEN", "DAVID", NULL, 
"PLANT MANAGER", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2017, 1, "JUERGENS", "DR. BERNARD", NULL, 
"B.JUERGENS@TRIANEL.COM", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"49 241 413 2014", NULL, "49 241 413 200", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2018, 1, "GLAESER", "SCOTT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "314 554-4271", NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2019, 1, "RAMALHETE", "PEDRO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2020, 1, "AVERSA", "DOMENICO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2021, 1, "RITTTERHOUSE", "ED", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "405 844 1577", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2022, 1, "MURRAY", "EDWARD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "46 873 96826", NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2023, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2024, 1, "FEDELE", "MR. Y", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2025, 1, "STESTAK", "KATHY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "312 240-4361", NULL, 
NULL, NULL, NULL, "CREDIT", 1, "A", 1)
go

insert into account_contact values(2026, 1, "HARVEY", "SIMON", NULL, "TRADER", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2027, 1, "HALL", "ROBERT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2028, 1, "KAMINSKI", "STEPHEN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2029, 1, "GEVAERTS", "OCKER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2030, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2031, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2032, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2033, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2034, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2035, 1, "FRAZIER", "MATT", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2036, 1, "KWASNIESKI", "JOHN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "X 249", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2037, 1, "KWASNIESKI", "JOHN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "EXT 249", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2038, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2039, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2040, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2041, 1, "LARA", "MARIO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2042, 1, "MEAUX", "PAM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "281 297-359", NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2043, 1, "PEI", "CHEN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "86 10 63547628", NULL, 
"86 10 63544039", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2044, 1, "SMITH", "ASHLEY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2045, 1, "MCLEOD", "LINDA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "281 759-0245", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2046, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2047, 1, "LARSEN", "JESSICA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "206 431-3718", NULL, NULL, 
"206 431-5007", NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2048, 1, "NOVI", "ANDREA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "390 10 54921", NULL, NULL, "270158", 
"390 10 543342", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2049, 1, "ZEYSSOLF", "OLIVIER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2050, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2051, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2052, 1, "STAIRS", "ROSS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2053, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2054, 1, ".", ".", NULL, NULL, 
"DEN DANSKE BANK A/S, 2-12 HOLMENS KANAL", NULL, NULL, NULL, "COPENHAGEN K", 
NULL, "DK", "DK-1092", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2055, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2056, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2057, 1, "STROMME", "JAN TORE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2057, 2, "ALHAUG", "GITTE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "47 22 477 830", NULL, NULL, 
"47 22 477 831", NULL, NULL, NULL, "A", 1)
go

insert into account_contact values(2058, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2059, 1, "AGERHOLM", "MICHAEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2060, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2061, 1, "GIAMBRA", "JOSEPH", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2062, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2063, 1, "GUTMAN", "SIMEON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "377 9777 8488", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2064, 1, "ORDONEZ SOLIS", "LORETO", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2065, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2066, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2067, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2068, 1, "CHARLESWORTH", "FINN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2069, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2070, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2071, 1, "CLEVELAND", "JAMIE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2072, 1, "SGOUROPOULOU", "RENA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2073, 1, "BAAZ", "MIKAEL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2074, 1, "PINTO", "PAM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2075, 1, "PINTO", "PAMELA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2076, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2077, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2078, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2079, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2080, 1, "KLEINMAN", "JOSEPH", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2081, 1, "KLEINMAN", "JOSEPH", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2082, 1, "CHEN", "MR. S C", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2083, 1, "DOWLING", "BERNADETTE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2084, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2085, 1, "DRYSDALE", "SANDY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2086, 1, "KRAUSE", "MANDY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2087, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2088, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2089, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2090, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2091, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2092, 1, "WOOD", "SIRI", NULL, 
"DOCUMENTATION (OPERATIONS)", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"44 247 547 0883", NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2093, 1, "BUCKLES", "MARIA", NULL, 
"TRANSMISSION PLANNING ENGINEER", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2094, 1, "ECKELS", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2095, 1, ".", ".", ".", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2096, 1, "JOERGENSEN", "A.G.", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2097, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2098, 1, "GABBARD", "BRAD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2099, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2100, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2101, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2102, 1, "STONE", "WILLIAM", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2103, 1, "HOWLAND", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "949 824-6956", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2104, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2105, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2106, 1, "TIFFIANY", "WEIR", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2107, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2108, 1, "ANGERS", "MAFFON", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2109, 1, "O'NEAL", "RYAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2110, 1, "ORARBACK", "CARINA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2111, 1, "CASSIDY", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2112, 1, "COLE", "CHRIS", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2113, 1, "PEREZ", "PEDRO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2114, 1, "DAUM", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2115, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2115, 2, "VORONIN", "ANDREI", NULL, NULL, 
"NEOCLEOUS HOUSE", "199 ARCH MAKARIOUS III AVENUE", NULL, NULL, "LIMASSOL", 
NULL, "CY", NULL, NULL, "358 9 435 5620", NULL, "124677", "358 9 455 3201", 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2116, 1, "MILES", "WILL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2117, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2118, 1, "BRESSETTE", "VICTOR", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2119, 1, "O'FARRELL", "BEAU", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2120, 1, ".", "MARJORIE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2121, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2122, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2123, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2124, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2125, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2126, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2127, 1, "PRATT", "SIMON", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2128, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2129, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2130, 1, "DELPRETE", "JOANNE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "516  545-6046", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2131, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2132, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2133, 1, "HWAN, LEE", "MR. SEUNG", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2134, 1, "GUSTAFSSON", "JONAS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2135, 1, "TAY", "PATRICIA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2136, 1, "THORNTON", "JACK", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2137, 1, "LOPES", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2138, 1, "WRIGHT", "DENNIS", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2139, 1, "LOPES", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2140, 1, "EDWARDS", "SCOTT", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2141, 1, "PORTER", "JEFF", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2142, 1, "GOBEN", "GEORGE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2143, 1, "POTTER", "JEFF", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2144, 1, "SHOLOEY", "JOHN", NULL, "A/P;A/R", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2145, 1, "GERKEN", "KATHY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2146, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2147, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2148, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2149, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2150, 1, "SEISTRUP", "BENTE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2151, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2152, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2153, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2154, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2155, 1, "KURVERS", "STIAN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2156, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2157, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2158, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2159, 1, "ANDERSON", "LINDSAY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2160, 1, "CHINAFAT", "KERWIN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2161, 1, "WRENCH", "PAUL", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2162, 1, "LEVINZON", "LILY", NULL, "AVP", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2162, 2, "MCARTHUR", "JOHN", NULL, "VP", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2163, 1, "SULLIVAN", "PETER", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2164, 1, "KOSSOLAPOV", "A", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2165, 1, "PERSON", "DUTY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2166, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2167, 1, "CHARLES", "CLENCY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2168, 1, "PARODI", "MARIO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2169, 1, "DULLAERS", "MARC", "MARIE", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "JEANNE LAURENT", 1, "A", 1)
go

insert into account_contact values(2170, 1, "DUPAIN", "JP", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2171, 1, "RICHARDS", "EMILY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2172, 1, "VITALE", "LOU", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2173, 1, " .", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2174, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2175, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2176, 1, "HERMANSEN", "HENRIK", "JOERGEN", 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "HERMANSEN", 1, "A", 1)
go

insert into account_contact values(2177, 1, "JITSUKATA", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"813-3282 7352", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2178, 1, "JONES", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2179, 1, "LARSSON", "YNGVE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2180, 1, "ODH", "RUNE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "46708145280", NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2181, 1, "MORALES", "ANGIE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2182, 1, "FULLER", "DAVE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2183, 1, "BISSOONDATT", "CARLYLE", NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2184, 1, "DEMANN", "BOB", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2185, 1, "RUSS", "J E", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2186, 1, "VOGT", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2187, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2188, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2189, 1, "TAN", "RICHARD", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2190, 1, "LAVELLE", "JAMES", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "GENERAL MANAGER", 1, "A", 1)
go

insert into account_contact values(2191, 1, "CZERMAK", "MARTIN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2192, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2193, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2194, 1, "RUNCIMAN", "DAVE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2195, 1, "CAMARATTA", "JANICE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2196, 1, "WEITER", "DAVID", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2197, 1, "HOON", "TAN LAY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2198, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2199, 1, "ERIKSEN", "MR", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2200, 1, "WIEDE", "OTTO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2201, 1, "MEDINA", "SAMUEL", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2202, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2203, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2204, 1, "MCQUARE", "JENNY", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2205, 1, "ZALA", "ADRIANO", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2206, 1, "AL-ESSA", "MR HAYTHEM", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2207, 1, "HAMILTON", "JIM", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "9056704440 X222", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2208, 1, "RAST", "MR. HAROLD", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2209, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2210, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2211, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2212, 1, "HARRIS", "JOHN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2213, 1, "BROLLY", "MARY", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "718-749-2518", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2214, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "32 3 221 42 87", NULL, NULL, 
"32 3 226 62 61", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2215, 1, "LABUZ", "PETER", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2216, 1, "VANDERPUIL", "ERICA", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2217, 1, "SMETS", "ERIK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "32 2 518 61 41", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2218, 1, "PARIKH", "SHAITO", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "888-478-3429 X8", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2219, 1, "TORRE", "JEAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "33 1 4710 6204", NULL, NULL, 
"33 1 4710 5336", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2220, 1, "BAHASA", "JALAN", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 1, "A", 1)
go

insert into account_contact values(2221, 1, "MOUGHALIAN", "JOHN", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "30 1 4287300-45", NULL, 
NULL, "30 1 4287334-5", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2222, 1, "CLARYSSE", "PHILIPPE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "33 608 06 70 40", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2222, 2, "DEVOS", "FRANCK", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "33 608 01 25 44", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2223, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2224, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2225, 1, "DEBE", "JORG", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "49 511 439 2700", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2226, 1, "ABELS", "ANDREA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "49 89 1254 3347", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2227, 1, "WILKINSON", "CRAIG", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-353-2700", NULL, 
NULL, "713-353-2793", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2228, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2229, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2230, 1, "TURKO", "SERGE", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "852 213 68300", NULL, 
"77581 RINEX HX", "852 213 68212", NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2231, 1, "HUDSON", "ROELINE", NULL, 
"MANAGER CREDIT & CONTACTS", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2232, 1, "JENSEN", "MR STINE", NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "00 45 7642 9696", NULL, 
NULL, NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2233, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2234, 1, "STEPAT", "PETRA", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, "49 40 51309232", NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

insert into account_contact values(2235, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2236, 1, ".", ".", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 
"A", 1)
go

insert into account_contact values(2237, 1, "CAPPS", "ED", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, "713-503-6110", NULL, NULL, NULL, 
NULL, NULL, NULL, 1, "A", 1)
go

