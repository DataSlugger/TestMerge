print 'Loading additional seed data into the account_address table ...'
go

insert into account_address values(2, 1, "PO BOX CB 12918", NULL, NULL, NULL, 
"NASSAU", NULL, "BS", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(3, 1, "VIA CARLO NAVONE 3/8", NULL, NULL, 
NULL, "16124  BUSALLA (GE), GENOA", NULL, "I", NULL, "39 10 96231", "271313", 
"39 10 932059", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(4, 1, "HYDROCARBONS SUPPLY DIVISION", 
"BACKTOBELSTRASSE 3", NULL, NULL, "CH-8810 HORGEN", NULL, "CH", NULL, NULL, 
"814316", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(5, 1, "10 COLLYER QUAY 23-05 TO 23-09", 
"OCEAN BUILDING", NULL, NULL, "SINGAPORE 0104", "NA", "SGP", NULL, NULL, 
"786-21309SUMIT", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(5, 2, "20 CECIL STREET", "# 24-01/08", 
"THE EXCHANGE", NULL, "SINGAPORE  049705", NULL, "SGP", NULL, "65 5389693", 
"RS 21309 SUMIT", "65 5386527", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(6, 1, "NOORDELAAN 98", "BUS 49", NULL, NULL, 
"2030 ANTWERP 3", NULL, "B", NULL, NULL, "73069", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(7, 1, "TOSHIBA BUILDING", 
"1-1 SHIBAURA 1-CHOME", NULL, NULL, "MINATO-KU, TOKYO 105", NULL, "J", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(7, 2, "16 RAFFLES QUAY", 
"HEX 33-03 HONG LEONG BUILDING", NULL, NULL, "SINGAPORE", NULL, "SGP", "0104", 
NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(8, 1, "133 FLEET STREET", 
"PETERBOROUGH COURT", NULL, NULL, "LONDON, ENGLAND", NULL, "GB", "EC4A 2BB", 
NULL, "9419011", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(9, 1, "16 RAFFLES QUAY, NO. 40-01A", 
"HONG KONG BUILDING", NULL, NULL, "SINAGPORE 0104", NULL, "SGP", NULL, NULL, 
"RS 21900", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(11, 1, "LA MOTTE CHAMBERS", 
"ST. HELIER JERSEY", NULL, NULL, "CHANNEL ISLAND, UK", "NA", "GB", NULL, NULL, 
NULL, NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(11, 3, "MONTE CARLO", NULL, NULL, NULL, 
"MONACO", "NA", "MC", NULL, NULL, "479649", NULL, NULL, NULL, "I", NULL, NULL, 
1)
go

insert into account_address values(11, 4, "VIA DEL SERAFICO 89/91", NULL, NULL, 
NULL, "000142 ROMA", NULL, "I", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(11, 5, "PIAZZALE ENRICO MATTEI, NO.1", NULL, 
NULL, NULL, "00144 ROME", NULL, "I", NULL, "390659827327", "620360", 
"390659827603", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(11, 6, "VIA LAURENTINA, 449", NULL, NULL, 
NULL, "00142 ROME", NULL, "I", NULL, NULL, "296673", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(12, 2, "TWO EXECUTIVE DRIVE", NULL, NULL, 
NULL, "FORT LEE", "NJ", "USA", "07024", "201 886-3400", " 33191", 
"201-886-3579", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(12, 3, "120 LEMAN ST.", NULL, NULL, NULL, 
"LONDON  E1 8EU", NULL, "GB", "E1 8EU", "011441714805181", "8811948", 
"011441714812009", "AIGTRA G", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(12, 5, '', "PRECIOUS METALS", NULL, NULL, '', 
"NA", "USA", NULL, NULL, NULL, NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(12, 72, "FORT LEE, NJ", NULL, NULL, NULL, 
"ROB GIBBENS", "NA", "USA", NULL, NULL, "TLX 170125", NULL, NULL, NULL, "I", 
NULL, NULL, 1)
go

insert into account_address values(12, 73, "ONE GREENWICH PLAZA", NULL, NULL, 
NULL, "GREENWICH", "CT", "USA", "06830", "2038613765", "170125", "2038613828", 
"AIG1", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(12, 74, "675 BERING DRIVE", "SUITE 700", 
NULL, NULL, "HOUSTON", "TX", "USA", "77057", "7137871100", NULL, "7137871109", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(13, 1, "PO BOX 299337", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77299-033", "NA", "NA", "NA", NULL, NULL, "I", NULL, 
NULL, 1)
go

insert into account_address values(13, 2, "1185 AVENUE OF THE AMERICAS", NULL, 
NULL, NULL, "NEW YORK", "NY", "USA", "10036", NULL, "126594", "2123020826", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(13, 3, "ONE ALLEN CENTER", 
"500 DALLAS STREET, LEVEL 2", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
"713 609-4910", NULL, "713 609-4948", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(13, 4, "500 DALLAS STREET, LEVEL 2", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77002", "713-609-4963", NULL, 
"713-609-4948", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(13, 5, "PO BOX 2040", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77252", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(13, 6, "1 HESS PLAZA", NULL, NULL, NULL, 
"WOODBRIDGE", "NJ", "USA", "07095-096", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(14, 1, "1185 AVE. OF THE AMERICAS", 
"ATTN:  CRUDE OIL ACCOUNTING", NULL, NULL, "NEW YORK", "NY", "USA", "10036", 
"212-536-8521", "(WILD)RRQFAX", "212-536-8396", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(14, 72, "NEW YORK ,NY", NULL, NULL, NULL, 
"CLAIR MARLIN", NULL, "USA", NULL, NULL, "TLX 825546", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(15, 2, "CENTER PORT V", 
"P.O. BOX 619616, MD 5662", NULL, NULL, "DFW INTERNATIONAL AIRPORT", "TX", 
"USA", "75261", "817/963-2033", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(15, 3, "4333 AMON CARTER BOULEVARD", 
"MAIL DROP 5662", NULL, NULL, "FORT WORTH", "TX", "USA", "76155", "8179631234", 
"730613", "8179634318", "AMAIRDFWDFWDAL", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(16, 1, "BAHNHOFSTRASSE 10", NULL, NULL, NULL, 
"CH-6300 ZUG", NULL, "CH", NULL, "901141417100422", "865428 AOT CH", 
"901141417266900", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(17, 1, "45 OLD BOND STREET", NULL, NULL, 
NULL, "LONDON  WIX 5AE", NULL, "GB", "WIX 5AE", "44 1714955717", "263821", 
"44 1714050355", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(17, 2, "10 STRATTON STREET", NULL, NULL, 
NULL, "LONDON WIX 6AP,  ENGLAND", NULL, "GB", "WIX 6AP", "011441714955717", 
"263831", "011441714950355", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(18, 1, "85 BROAD STREET", NULL, NULL, NULL, 
"NEW YORK", "NY", "USA", "10004", "2129028986", "6720148", "2123443457", 
"6720148GSPNY", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(18, 2, "85 BROAD STREET", 
"FLOOR 5 DEPT. 490", NULL, NULL, "NEW YORK", "NY", "USA", "10004", 
"212-902-9267", "6720148", "2123443457", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(18, 3, "50 RAFFLES PLACE HEX 29-01", 
"SHELL TOWER", NULL, NULL, "SINGAPORE 0104", NULL, "SGP", NULL, NULL, "23778", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(18, 4, "85 BROAD STREET", NULL, NULL, NULL, 
"NEW YORK", "NY", "USA", "10004", NULL, "FAX 212-357-681", "6720058", NULL, 
NULL, "I", NULL, NULL, 1)
go

insert into account_address values(18, 5, "PETERBOROUGH COURT", 
"133 FLEET STREET", NULL, NULL, "LONDON EC4A 2BB", NULL, "GB", NULL, 
"441717741966", "9419011", "441717742135", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(18, 6, "85 BROAD STREET", NULL, NULL, NULL, 
"NEW YORK", "NY", "USA", NULL, NULL, NULL, NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(18, 72, "NEW YORK, NY", NULL, NULL, NULL, 
"NICIE HOUSE", "NA", "USA", NULL, NULL, "TLX 301080", NULL, NULL, NULL, "I", 
NULL, NULL, 1)
go

insert into account_address values(19, 4, "BUCHANAN HOUSE", 
"3 ST. JAMES' SQUARE", NULL, NULL, "LONDON SW1Y 4JU", "NA", "GB", NULL, NULL, 
"918522 ATTOIL G", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(19, 5, "2 QUEEN ANNE'S GATE BUILDING", 
"DARTMOUTH STREET", NULL, NULL, "LONDON SW1H 9BP", NULL, "GB", NULL, 
"44 171 2221188", "976-8580", "44 171 99797685", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(19, 6, "TRAFALGAR PLACE B8(B)", 
"WEST BAY ROAD", "GEORGE TOWN", NULL, "GRAND CAYMAN, CAYMAN ISLANDS", NULL, 
"BWI", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(19, 7, "2 QUEEN ANNE'S GATE BUILDING", NULL, 
NULL, NULL, "LONDON SW1H9", NULL, "GB", NULL, NULL, "918522", "171-976 8580", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(20, 1, "440 S. LASALLE STREET", "SUITE 3300", 
NULL, NULL, "CHICAGO", "IL", "USA", "60605", "312-431-3010", NULL, "3122345601", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(20, 3, "233 SOUTH WACKER DRIVE", 
"SUITE 2800", NULL, NULL, "CHICAGO", "IL", "USA", "60606", "3122345422", 
"4330469", "3122345750", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(20, 72, "CHICAGO, IL", NULL, NULL, NULL, 
"HEIDI HOLT", "NA", "USA", NULL, NULL, "TLX 4330469", NULL, NULL, NULL, "I", 
NULL, NULL, 1)
go

insert into account_address values(20, 73, "(A SUBSIDIARY OF NATIONSBANK CORP)", 
"440 S. LASALLE STREET", NULL, NULL, "CHICAGO", "IL", "USA", "60605", NULL, 
"312 431 3160", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(20, 74, "100 N. TRYON STREET", 
"NCI-007-13-01", NULL, NULL, "CHARLOTTE", "NC", "USA", "28255", "7043864409", 
"669959", "7043864113", "NATIONSBANK CHA", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(21, 1, "83 CHUNG HWA RD, SEC 1", NULL, NULL, 
NULL, "TAIPEI   10031", NULL, "RC", NULL, "88623610221", "11215", "88623319645", 
"CHINOL", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(21, 2, "71   KUAN CHIEN ROAD", NULL, NULL, 
NULL, "TAIPEI", NULL, "RC", NULL, "88623819933", NULL, "88623612018", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(22, 4, "6100 SOUTH YALE", NULL, NULL, NULL, 
"TULSA", "OK", "USA", "74136", "918-495-4444", NULL, "918-495-5141", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(22, 5, "6100 SOUTH YALE", 
"ATTN: SALLY WILLSON", NULL, NULL, "TULSA", "OK", "USA", "74136", 
"918-495-4550", NULL, "918-495-5613", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(22, 6, "P.O. BOX 600", NULL, NULL, NULL, 
"LAKE CHARLES", "OK", "USA", "70602", NULL, "FAX: 318-491-80", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(22, 7, "1 WARREN PLACE, 6100 SOUTH YALE", 
"P.O. BOX 3758", NULL, NULL, "TULSA", "OK", "USA", "74102", NULL, "497470", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(22, 72, "TULSA, OK", NULL, NULL, NULL, 
"MARSHA BANKS", "OK", "USA", NULL, NULL, "TLX 497470", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(22, 73, "9802 FM 1960 BY-PASS", "SUITE 270", 
NULL, NULL, "HUMBLE", "TX", "USA", "77338", "713 548 0241", "910811525", 
"713-548-0201", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(22, 74, "P.O. BOX 3758", NULL, NULL, NULL, 
"TULSA", "OK", "USA", "74102", NULL, NULL, "9184955141", NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(23, 1, "THREE STAMFORD PLAZA", 
"301 TRESSER BLVD", NULL, NULL, "STAMFORD", "CT", "USA", "06901", 
"203-328-4900", "6819406", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(23, 3, "49 WIGMORE STREET", 
"LONDON, WHL 9LE", NULL, NULL, "LONDON", NULL, "GB", NULL, NULL, "295517", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(23, 4, "THREE STAMFORD PLAZA", 
"301 TRESSER BLVD", NULL, NULL, "STAMFORD", "CT", "USA", "06901-324", 
"(203)328-4900", "6819406", "FAX: (203)328-3", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(23, 72, "THREE STAMFORD PLAZA", 
"301 TRESSER BLVD", NULL, NULL, "STAMFORD", "CT", "USA", "06901", 
"203-328-4900", "TLX 177319", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(23, 73, "BAARERSTRASSE 37", "PO BOX 4116", 
NULL, NULL, "CH-6304 ZUG", NULL, "CH", NULL, NULL, "862323", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(23, 74, "100 FIRST STAMFORD PLACE", NULL, 
NULL, NULL, "STAMFORD", "CT", "USA", "06902", "203.328.3161", "6819406", 
"2033283177", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(24, 1, "8182 MARYLAND AVENUE", NULL, NULL, 
NULL, "CLAYTON", "MO", "USA", "63105-372", "314-854-9696", "434509", 
"713-873-1530", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(24, 72, "CLAYTON ,MO", NULL, NULL, NULL, 
"CLAYTON", "MO", "USA", "63105", "OIL STL", "TLX 434509", "OR 9107612105 C", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(24, 73, "C/O CREST TANKERS, INC.", 
"8182 MARYLAND AVENUE", NULL, NULL, "CLAYTON", "MO", "USA", "63105", 
"301 889 9610", "62933177", "314 854 8539", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(25, 4, "8182 MARYLAND AVENUE", "5TH FLOOR", 
NULL, NULL, "CLAYTON", "MO", "USA", "63105", NULL, " 62933177", "3148548539", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(25, 72, "ST. LOUIS, MO", NULL, NULL, NULL, 
"ST. LOUIS", "MO", "USA", NULL, NULL, "TLX 434509", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(26, 1, "48 CHURCH STREET", 
"4TH FLOOR SOFIA HOUSE", NULL, NULL, "HAMILTON, HM 12", NULL, "BER", NULL, 
"809-295-2278", "3249", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(27, 1, "NINE GREENWAY PLAZA", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77046", "713-877-1400", "166008", "7138776693", 
"COASTAL D HOU", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(27, 2, "180 EAST OCEAN BLVD SUITE 800", NULL, 
NULL, NULL, "LONG BEACH", "CA", "USA", "90802", NULL, "FAX: 213-499-44", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(27, 72, "HOUSTON, TX", NULL, NULL, NULL, 
"DARREN MINUS", "NA", "USA", NULL, NULL, "TLX 166008", "166228", NULL, NULL, 
"I", NULL, NULL, 1)
go

insert into account_address values(27, 73, "P.O. BOX. 730429", NULL, NULL, NULL, 
"DALLAS", "TX", "USA", "75379", "713-877-3194", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(28, 1, "LAGOWEG-ARUBA REFINERY", 
"P O BOX 2150", NULL, NULL, "SAN NICHOLAS", NULL, "ARU", NULL, "297898900", 
"3645238", "297894000", "COPET AW", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(29, 1, "P.O.BOX 730429", NULL, NULL, NULL, 
"UNKNOWN", "NA", "USA", NULL, "713-877-1400", "79-0186", "TWX:910-881-633", 
NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(29, 2, "NINE GREENWAY PLAZA", 
"HOUSTON, TX 77046", NULL, NULL, '', "NA", "USA", NULL, "713 877 1400", 
"79-0186", "TWX: 910 881 63", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(29, 3, "MARKETING/ACCOUNTING 10TH FLOOR", 
"P.O. BOX 4361", NULL, NULL, "HOUSTON", "TX", "USA", "77001-436", NULL, NULL, 
"7132971376", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(29, 4, "9 GREENWAY PLAZA", "COASTAL TOWER", 
NULL, NULL, "HOUSTON", "TX", "USA", "77046", NULL, "774254", "7138776752", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(29, 5, "PO BOX 025500", 
"ATTN:  MARINE SALES/MONA FOSTER", NULL, NULL, "MIAMI", "FL", "USA", 
"33102-550", "305-551-5318", "NA", "305-551-8436", NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(29, 6, "NINE GREENWAY PLAZA", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77046", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(30, 1, "P.O.BOX 65776", NULL, NULL, NULL, 
"CHARLOTTE", "NC", "USA", "28265", NULL, "522279", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(30, 2, "P. O. BOX 025500", NULL, 
"ATTN: MR. TYLER SHERMAN", NULL, "MIAMI", "FL", "USA", "33102", "800-327-2495", 
"522279", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(30, 3, "P.O. BOX 025500", 
"ATTN: MR. TYLER SHERMAN", NULL, NULL, "MIAMI", "FL", "USA", "33102", 
"800-327-2495", "522279", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(30, 4, "8700 WEST FLAGLER ST", NULL, NULL, 
NULL, "MIAMI", "FL", "USA", "33174", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(31, 1, "COASTAL TOWER", 
"NINE GREENWAY PLAZA", NULL, NULL, "HOUSTON", "TX", "USA", "77046", NULL, NULL, 
"7132971605", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(31, 2, "335 8TH AVENUE S.W.", "SUITE 1650", 
NULL, NULL, "CALGARY, ALBERTA", NULL, "CDN", "T2P 1CP", NULL, NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(31, 3, "500 RENAISSANCE CENTER", NULL, NULL, 
NULL, "DETROIT", "MI", "USA", "48243", "3134967159", NULL, "3134963696", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(31, 4, "460 MCLAWS CIRCLE", "SUITE 200", 
NULL, NULL, "WILLIAMSBURG", "VA", "USA", "23185", "8042530753", NULL, 
"8042530753", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(31, 5, "ONE HARBOUR PLACE", "SUITE 225", 
NULL, NULL, "PORTSMOUTH", "NH", "USA", "03801", "6034336175", NULL, 
"6034336179", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(32, 4, "600 NORTH DAIRY ASHFORD", 
"P.O. BOX 2197", NULL, NULL, "HOUSTON", "TX", "USA", "77252", NULL, "77-5347", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(32, 5, "80 MARINE PARADE ROAD", 
"NO. 17-01A PARKWAY PARADE", NULL, NULL, "SINGAPORE", NULL, "SGP", NULL, 
"653480771", NULL, "653450792", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(32, 6, "80 RAFFLES PLACE", 
"HEX #15-20 UOB PLAZA 2", NULL, NULL, "SINGAPORE 0104", NULL, "SGP", NULL, NULL, 
"RS50645CII", "655360012", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(33, 1, "FINNESTADVEIEN 28", "P.O. BOX 488", 
NULL, NULL, "4001 STRAVANGER", NULL, "N", NULL, NULL, "33145 CONOR N", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(34, 1, "PARK HOUSE", "116 PARK STREET", NULL, 
NULL, "LONDON,   ENGLAND", NULL, "GB", "WIY 4NN", "01144714086000", 
"8518811988", NULL, "CONOCO G", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(34, 2, "105 WIGMORE STREET", NULL, NULL, 
NULL, "LONDON,W1H OEL ENGLAND", NULL, "GB", "W1H OEL", NULL, "915211", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(34, 4, "HUMBER REFINERY", NULL, NULL, NULL, 
"SOUTH HUMBERSIDE DN36 5NX", NULL, "GB", NULL, NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(34, 5, "WARWICK TECHNOLOGICAL PARK", NULL, 
NULL, NULL, "WARWICK CV4 6DA", NULL, "GB", NULL, NULL, NULL, "011441926404234", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(35, 2, "P.O. BOX 2197", 
"600 NORTH DAIRY ASHFORD", NULL, NULL, "HOUSTON", "TX", "USA", "77252", 
"713 293 3760", "775347", "7132936592", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(35, 6, "600 NORTH DAIRY ASHFORD", 
"P.O. BOX 2197, MA 3051", NULL, NULL, "HOUSTON", "TX", "USA", "77252", 
"713 965-1000", "775347", "7132931211", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(35, 12, "P.O. BOX 2197", 
"600 NORTH DAIRY ASHFORD", NULL, NULL, "HOUSTON", "TX", "USA", "77079", 
"7132932009", "77-5347", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(35, 15, "FIVE GREENWAY PLAZA EAST", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77046", NULL, NULL, "775347", NULL, NULL, 
"I", NULL, NULL, 1)
go

insert into account_address values(35, 16, "390 SOUTH TOWER/PO BX 1267", NULL, 
NULL, NULL, "PONCA CITY", "OK", "USA", "74603", NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(35, 72, "HOUSTON, TX", NULL, NULL, NULL, 
"KIM GERARD", "NA", "USA", NULL, NULL, "TLX 775347", NULL, NULL, NULL, "I", 
NULL, NULL, 1)
go

insert into account_address values(35, 73, "HOUSTON, TX", NULL, NULL, NULL, 
"SCOTT PRUITT", "NA", "USA", NULL, NULL, "TLX 775347", NULL, NULL, NULL, "I", 
NULL, NULL, 1)
go

insert into account_address values(35, 74, "HOUSTON, TX", NULL, NULL, NULL, 
"KIM GERARD", "NA", "USA", NULL, NULL, "TLX 775347", NULL, NULL, NULL, "I", 
NULL, NULL, 1)
go

insert into account_address values(35, 75, "P.O. BOX 2197", 
"600 NORTH DAIRY ASHFORDA", NULL, NULL, "HOUSTON", "TX", "USA", "77079", 
"7132936513", "775347", "7132936592", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(35, 76, "P. O. BOX 1267", 
"ATTN:  DUPONT GAS ACCOUNTING", "380 NORTH TOWER", NULL, "PONCO CITY", "OK", 
"USA", "74603", "4057674364", NULL, "4057673705", NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(36, 1, "1301 AVENUE OF THE AMERICAS", 
"NEW YORK, NY    10019", NULL, NULL, "NY", "NY", "USA", NULL, "212-261 7996", 
"423493", "212-261 7969", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(37, 3, "A DIVISION OF CREDIT LYONNAIS S.A.", 
"P.O. BOX 81", "84-94 QUEEN VICTORIA STREET", NULL, "LONDON EC4P 4LX", NULL, 
"GB", NULL, "4471-634-8000", "885479", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(37, 4, "A DIVISION OF CREDIT LYONNAIS S.A.", 
"BROADWALK HOUSE", "5 APPOLO STREET", NULL, "LONDON EC2A 2DA", NULL, "GB", NULL, 
NULL, NULL, "0171 638 0387", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(38, 3, "1 NORTH CHARLES STREET", NULL, NULL, 
NULL, "BALTIMORE", "MD", "USA", "21201", NULL, "90-8032", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(38, 4, "4747 BELLAIRE BLVD.", NULL, NULL, 
NULL, "BELLAIRE", "TX", "USA", "77401", NULL, "509504", "713 660 4550", 
"CROWN CEN S T", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(38, 72, "BELLAIRE, TX", NULL, NULL, NULL, 
"BELLAIRE", "TX", "USA", NULL, NULL, "TLX 509504", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(38, 73, "4747 BELLAIRE BLVD.", NULL, NULL, 
NULL, "BELLAIRE", "TX", "USA", "77401", NULL, "509504", "713-660-4550", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(39, 1, "POSTFACH 5220", "KOELNER STRASSE 6", 
NULL, NULL, "65760 ESCHBORN/TS", NULL, "BRD", NULL, NULL, "8414072939", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(39, 2, "DEPT ROR", "UEBERSEERING 35", NULL, 
NULL, "2297 HAMBURG", NULL, "BRD", NULL, NULL, "2195741 SHH D", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(39, 3, "FRANKFURT", NULL, NULL, NULL, 
"GERMAN DEMOCRTIC REPUBLIC", NULL, "BRD", NULL, NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(39, 4, "UBERSEERING 35", "POSTFACH 60 05 20", 
NULL, NULL, "2000 HAMBURG 60,  GERMANY", NULL, "BRD", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(39, 5, "UMBERSEERING 35", NULL, NULL, NULL, 
"22297 HAMBURG,  GERMANY", NULL, "BRD", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(40, 2, "1990 POST OAK BLVD.", "SUITE 1370", 
NULL, NULL, "HOUSTON", "TX", "USA", "77056-3813", "713.850.1599", "792008", 
"7138507828", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(41, 1, "QUEENSBERRY HOUSE", 
"#3 OLD BURLINGTON STREET", NULL, NULL, "LONDON", "TX", "UK", "ILA", NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(41, 2, "PO BOX 810", "10 WESTPORT ROAD", 
NULL, NULL, "WILTON", "CT", "USA", "06897", "203-761-2320", "981937", 
"2037612321", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(41, 3, "10 WESTPORT ROAD", NULL, NULL, NULL, 
"WILTON", "CT", "USA", "06897", NULL, "981937", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(41, 4, "162 QUEEN VICTORIA STREET", NULL, 
NULL, NULL, "LONDON EC4V 4BS ENGLAND", NULL, "GB", "EC4V 4BS", NULL, 
"914570 LDE G", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(41, 5, "87 AVE DE LA GRANDE ARMEE", NULL, 
NULL, NULL, "75782 PARIS CDEX 16", NULL, "F", NULL, NULL, NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(41, 6, "8800 ROSWELL ROAD", "SUITE 200", 
NULL, NULL, "ATLANTA", "GA", "USA", "30350", "7705183771", "FAX 4045183654", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(41, 7, "P. O. BOX 76045", NULL, NULL, NULL, 
"ATLANTA", "GA", "USA", "30358-104", NULL, "FAX 4045183654", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(41, 72, "WILTON, CT", NULL, NULL, NULL, 
"SUSAN SCINTO", "CT", "USA", NULL, NULL, "TLX 981937", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(41, 73, "10 WESTPORT ROAD", NULL, NULL, NULL, 
"WILTON", "CT", "USA", "06807", NULL, NULL, NULL, NULL, NULL, "I", NULL, NULL, 
1)
go

insert into account_address values(42, 1, "P.O. BOX 4369", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77210", NULL, NULL, "7135102705", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(42, 2, "1000 LOUISIANA", "SUITE 1100", NULL, 
NULL, "HOUSTON", NULL, "USA", "77002", "7136506255", NULL, "7136592745", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(42, 3, "2500 CITY WEST BLVD", "SUITE 1400", 
NULL, NULL, "HOUSTON", "TX", "USA", "77042", "7135102500", NULL, "7135102878", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(42, 4, "1001 LOUSIANA ST.", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77002", "713-757-4557", NULL, "731-757-2180", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(43, 1, "SAN FELIPE PLAZA", 
"5847 SAN FELIPE, SUITE 2100", NULL, NULL, "HOUSTON", "TX", "USA", "77057", 
NULL, "166587", NULL, "ELF HOU", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(43, 3, "1100 MILAM, SUITE 3035", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77002", NULL, NULL, NULL, NULL, NULL, "I", NULL, 
NULL, 1)
go

insert into account_address values(43, 4, "FIRST INTERSTATE BANK PLAZA", 
"1000 LOUISIANA, SUITE 3800", NULL, NULL, "HOUSTON", "TX", "USA", "77002", NULL, 
NULL, NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(43, 5, "1000 LOUISIANA", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77002", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(43, 72, "HOUSTON, TX", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", NULL, NULL, "TLX 166587", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(44, 1, "WORLD TRADE CENTER", 
"CASE POSTALE 276", "10 ROUTE DE L' AEROPORT", NULL, "1215 GENEVA 15 AEROPORT", 
NULL, "CH", NULL, "41227101315", "415535", " 41227101850", "ETS CH", NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(45, 1, "5 THE STRAND", 
"LONDON, ENGLAND WC1 2M5HU", NULL, NULL, "LONDON", NULL, "GB", NULL, 
"071-930-1212", "8950611", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(45, 2, "5 THE STRAND", "LONDON WC1 2M5HU", 
NULL, NULL, "LONDON", NULL, "GB", NULL, "071-930-1212", "8950611", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(45, 3, "GRAND BUILDINGS", "TRAFALGAR SQUARE", 
NULL, NULL, "LONDON WC2N5EJ", NULL, "GB", NULL, "0719254000", "8950611", 
"0719254321", "EPRISE G", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(46, 2, "C/O EXXON INTERNATIONAL CORPORATION", 
"224 PARK AVENUE", NULL, NULL, "FLORHAM PARK, NJ 07932", "NA", "USA", "07932", 
NULL, NULL, NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(46, 3, "ESSO HOUSE,", 
"94-98 VICTORIA STREET,", NULL, NULL, "LONDON", NULL, "UK", "SW1E 5JW", NULL, 
"24942", NULL, "ESSOUK G", NULL, "I", NULL, NULL, 1)
go

insert into account_address values(46, 4, "ESSO HOUSE", "ERMYN WAY", 
"ATT:  NORTH KERR  / TED BURKE", NULL, "LEATHERHEAD, SURREY", NULL, "UK", 
"KT22 8UX", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(47, 1, "P.O. BOX 1", "4803 AA BREDA", NULL, 
NULL, "BREDA", NULL, "NL", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(47, 2, "PO BOX 1", "4803 AA BREDA", NULL, 
NULL, "BREDA", NULL, "NL", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(48, 2, "94 - 98 VICTORIA STREET", 
"LONDON, SW1 ENGLAND", NULL, NULL, "LONDON", NULL, "UK", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(48, 4, "SUPPLY & TRANSPORTATION DEPT.,", 
"MAIL POINT 12, ESSO HOUSE", NULL, NULL, "ERMYN WAY", NULL, "GB", NULL, 
"0372-222984", "FAX: 0372-22255", "FAX:     -22322", NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(48, 5, "ESSO HOUSE", "ERMYN WAY", 
"LEATHERHEAD", NULL, "SURREY KT22 8UX", NULL, "GB", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(49, 1, "2, RUE DES MARTINETS", NULL, NULL, 
NULL, "92569 RUEIL MALMAISON CEDEX", NULL, "F", NULL, "33 1 47106184", 
"610024F", "33 1 47105744", "ESSOCOM", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(50, 32, "800 BELL AVENUE", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77002", "7136563291", "7607600", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(50, 33, "800 BELL AVENUE", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77210", "7136563636", "762149", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(50, 34, "P.O. BOX 192", "180 PARK AVENUE", 
NULL, NULL, "FLORHAM PARK", "NJ", "USA", "07932", "201-765-7000", "132092", 
"713-579-3329", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(50, 35, "BUILDING 220-RM A370", 
"200 PARK AVENUE", NULL, NULL, "FLORHAM PARK", "NJ", "USA", "07932", 
"201-765 40 31", "132092", "FAX: 201-765-54", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(50, 72, "HOUSTON, TX", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", NULL, NULL, "TLX 762149", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(50, 74, "HOUSTON, TX", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", NULL, NULL, "TLX 762149", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(50, 75, "601 JEFFERSON", "NINTH FLOOR", NULL, 
NULL, "HOUSTON", "TX", "USA", "77002", "713-656-3636", "NA", "713-656-6372", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(51, 1, "P.O BOX 4799", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77210-4799", NULL, "FAX: 713-680-70", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(51, 2, "800 BELL STREET", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "770027426", "NA", "NA", "713-656-5550", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(51, 3, "P.O. BOX 4769", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77210-476", NULL, "7607600", "7136565550", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(51, 4, "P.O. BOX 2180", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77252-2180", "713-656-1532", "FAX:713-656-637", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(51, 72, "HOUSTON, TX", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", NULL, NULL, "TLX 762149", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(52, 1, "3315 NORTH OAK TRAFFICWAY", NULL, 
NULL, NULL, "KANSAS CITY", "MO", "USA", "64116", "8164596000", "981305", 
"8164595944", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(52, 5, "3315 NORTH OAK TRAFFICWAY", NULL, 
NULL, NULL, "KANSAS CITY", "MO", "USA", "64116", "8164596979", "42221", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(52, 6, "920 UNION CENTER BLDG.", NULL, NULL, 
NULL, "WICHITA", "KS", "USA", "67202", NULL, "42-221", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(52, 72, "KANSAS CITY, MO", NULL, NULL, NULL, 
"GLEN MILLS", "MO", "USA", NULL, NULL, "TLX 981305", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(53, 1, "A DIVISION OF FERRELLGAS, L.P", 
"16800 GREENSPOINT PARK DRIVE", "SUITE 225, SOUTH ATRIUM", NULL, 
"HOUSTON, TX 77060", "NA", "USA", NULL, "713-874-9494", "FAX: 713-874-95", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(54, 3, "6000 LEGACY DRIVE", NULL, NULL, NULL, 
"PLANO", "TX", "USA", "75024-3601", "214-890-2853", "163408", "2148901117", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(54, 72, "DALLAS, TX", NULL, NULL, NULL, 
"DALLAS", "TX", "USA", NULL, NULL, "TLX 163533", NULL, NULL, NULL, "I", NULL, 
NULL, 1)
go

insert into account_address values(54, 73, "8350 NORTH CENTRAL EXPRESSWAY", 
"FINA PLAZA", NULL, NULL, "DALLAS", "TX", "USA", "75206", "2147064236", 
"6736054", "2148901196", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(54, 74, "16630 IMPERIAL VALLEY DRIVE", 
"SUITE 244", NULL, NULL, "HOUSTON", "TX", "USA", "77060", NULL, NULL, NULL, 
NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(55, 1, "8350 NORTH CENTRAL EXPRESSWAY", NULL, 
NULL, NULL, "DALLAS", "TX", "USA", "75206", NULL, NULL, "2147504185", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(56, 1, "GALAXY MANAGEMENT SAM", 
"GILDO PASTOR CENTER", "7, RUE DU GABIAN", NULL, "MC 98000", NULL, "MC", NULL, 
"4122 9292000", "424072", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(56, 2, "P.O. BOX 3152", "ROAD TOWN", NULL, 
NULL, "TORTOLA", NULL, "VIU", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(56, 3, "GALAXY MANAGEMENT S.A.", 
"29, ROUTE DE PRE-BOIS", "P.O. BOX 347", NULL, "1215 GENEVA 15", NULL, "CH", 
NULL, " 41 22 92 92 00", " 424072 GMG CH", "9292092", NULL, NULL, "I", NULL, 
NULL, 1)
go

insert into account_address values(57, 1, "P.O. BOX 54", 
"RAW MAT. GROUP; PURCHASE & SUPPLY DP", NULL, NULL, "WILTON MIDDLEBOROUGH", 
NULL, "GB", NULL, NULL, "58522", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(57, 2, "P.O. BOX 90", "WILTON CENTRE", 
"MIDDLESBROUGH", NULL, "CLEVELAND, TS6 8JE", NULL, "GB", NULL, "441642454144", 
"587461", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(58, 1, "WARRINGTON PLACE", NULL, NULL, NULL, 
"DUBLIN 2, IRELAND", NULL, "IRL", NULL, NULL, "32694", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(59, 1, "9 RAFFLES PLACE, HEX 13-01", 
"#48-01 REPUBLIC PLAZA", NULL, NULL, "SINGAPORE-", NULL, "SGP", "048619", 
"2255555", "R521275/20401", "3218596", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(59, 2, "C/O ITOCHU INTL., INC.", 
"5847 SAN FELIPE SUITE 1100", NULL, NULL, "HOUSTON", "TX", "USA", "77057", 
"713-787-2657", "7651999", NULL, "7137872666", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(59, 3, "P.O. BOX 3454", NULL, NULL, NULL, 
"HONK KONG", NULL, "HK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(59, 4, "28TH FLOOR", NULL, NULL, NULL, 
"95 QUEENSWAY", NULL, "HK", NULL, " (852) 529-8300", NULL, "8528656464", NULL, 
"65216  ITCIP HX", "A", NULL, NULL, 1)
go

insert into account_address values(60, 1, "5-1, 2-CHOME KITA AOYAMA", NULL, 
NULL, NULL, "MINATO-KU, TOKYO, 100-91", NULL, "J", NULL, NULL, "J23111", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(60, 7, "16 RAFFLES QUAY", 
"13-01 HONG LEONG BUILDING", NULL, NULL, "SINGAPORE 0104", NULL, "SGP", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(60, 8, "5847 SAN FELIPE", "SUITE 1100", NULL, 
NULL, "HOUSTON", "TX", "USA", "77057", NULL, "713 787 2694", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(61, 3, "1001 FANNIN SUITE 2410", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77002", NULL, NULL, NULL, NULL, NULL, "I", NULL, 
NULL, 1)
go

insert into account_address values(61, 6, "28TH FLOOR", "UNITED CENTRE", NULL, 
NULL, "95 QUEENSWAY", NULL, "HK", NULL, NULL, "J23111 ITOHCHU", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(61, 72, "HOUSTON ,TEXAS", NULL, NULL, NULL, 
"DAN MARUYAMA", "NA", "USA", NULL, NULL, "TLX 765199", NULL, NULL, NULL, "I", 
NULL, NULL, 1)
go

insert into account_address values(62, 1, "4111 E. 37TH STREET NORTH", 
"PO BOX 2256", NULL, NULL, "WICHITA", "KS", "USA", "67201", NULL, "417376", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(62, 4, "PO BOX 2302", NULL, NULL, NULL, 
"WICHITA", "KS", "USA", "67201", NULL, "41-7376", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(62, 5, "333 CLAY STREET, #1300", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77002", "7136510304", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(62, 6, "A DIVISION OF KOCH FUELS, INC", 
"4111 E. 37TH STREET NORTH", "P.O BOX 2256", NULL, "WICHITA", "KS", "USA", 
"67220", "3168325858", "163451", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(62, 7, "A DIVISION OF KOCH FUELS, INC", 
"4111 E. 37TH ST. NORTH", NULL, NULL, "WICHITA", "KS", "USA", "67222", 
"713-651-0741", "163451", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(62, 8, "4111 E. 37TH STREET NORTH", NULL, 
NULL, NULL, "WICHITA", "KS", "USA", "67201", NULL, "417376", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(62, 72, "WITCHITA, KS", NULL, NULL, NULL, 
"DAN TURLEY", "KS", "USA", NULL, NULL, "TLX 417376", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(62, 73, "WITCHITA ,KS", NULL, NULL, NULL, 
"TIM PURCELL", "KS", "USA", NULL, NULL, "TLX 417376", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(62, 74, "WITCHITA,KS", NULL, NULL, NULL, 
"MIKE VOTH //OR// CINDY FISHER-LOTTEN", "KS", "USA", NULL, NULL, "TLX 417376", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(62, 75, "P.O. BOX 31", NULL, NULL, NULL, 
"GLOUCEESTER CITY", "NJ", "USA", "08030", "609-456-6673", NULL, "609-456-3331", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(62, 76, "2ND FLOOR, KIERRAN CROSS", 
"11 STRAND", NULL, NULL, "LONDON WC2N 5HR", NULL, "GB", NULL, "44 171 766 1300", 
"263173", "44 171 839 2086", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(62, 77, "600 TRAVIS STREET", "13TH FLOOR", 
NULL, NULL, "HOUSTON", "TX", "USA", "77002", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(62, 78, "EMPIRE HOUSE", 
"175 PICCADILLY, FOURTH FLOOR", NULL, NULL, "LONDON W1V 9DB", NULL, "GB", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(63, 1, "4111 EAST 37TH STREET NORTH", NULL, 
NULL, NULL, "WICHITA", "KS", "USA", "67201", "316.8283888", "417376", 
"3168327977", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(63, 3, "333 CLAY STREET", "SUITE 1300", NULL, 
NULL, "HOUSTON", "TX", "USA", "77002", "7132296136", "775216", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(63, 6, "201 ENERGY PARKWAY", "SUITE 202", 
NULL, NULL, "LAFAYETTE", "LA", "USA", "70508", NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(63, 72, "4111 EAST 37TH STREET NORTH", NULL, 
NULL, NULL, "WICHITA", "KS", "USA", "67220", NULL, "417376", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(64, 1, "200 CANTONMENT RD", 
"SOUTHPOINT HEX 15-00", NULL, NULL, "SINGAPORE 0208", NULL, "SGP", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(65, 2, "1800 S. BALTIMORE AVENUE", NULL, 
NULL, NULL, "TULSA", "OK", "USA", "74119", "9185811800", "275510", "9185609115", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(65, 4, "P.O. BOX 2930", NULL, NULL, NULL, 
"MEMPHIS", "TN", "USA", "38109", "9017743100", "TWX 8105911847", 
"FAX:9017755745", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(65, 7, "PO BOX 2930", NULL, NULL, NULL, 
"MEMPHIS", "TN", "USA", "38101", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(65, 72, "TULSA, OK", NULL, NULL, NULL, 
"TULSA", "OK", "USA", NULL, NULL, "TLX 275510", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(66, 1, "5555 SAN FELIPE", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77056", NULL, "792069", "4194257040", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(66, 2, "P.O. BOX 91", NULL, NULL, NULL, 
"FINDLAY", "OH", "USA", "45840", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(66, 3, "5555 SAN FELIPE", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77253", NULL, "FAX: 713-963-98", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(66, 4, "P.O. BOX AC    AIRLINE HIGHWAY", 
NULL, NULL, NULL, "GARYVILLE", "LA", "USA", "70051", "5045352154", "8109506585", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(66, 10, "539 SOUTH MAIN STREET", NULL, NULL, 
NULL, "FINDLAY", "OH", "USA", "45840", "4194222121", "196230", "4194257040", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(66, 11, "P.O. BOX 1191", NULL, NULL, NULL, 
"TEXAS CITY", "TX", "USA", "77592", "4099452331", "9108804100", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(66, 72, "FINDLAY, OH", NULL, NULL, NULL, 
"FINLAY", "OH", "USA", NULL, NULL, "TLX 196230", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(67, 7, "2 PERRY ROAD", 
"WITHAM ESSEX CM8 3TU", NULL, NULL, '', "NA", "GB", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(67, 8, "BOX 87689", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77287-768", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(68, 1, "CLARENDON HOUSE", "CHURCH STREET", 
NULL, NULL, "HAMILTON", NULL, "BER", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(68, 2, "C/O MIECO, INC.", 
"450 LEXINGTON AVENUE", NULL, NULL, "NEW YORK", "NY", "USA", "10017", 
"212-450-0650", "232185", "212-450-0764", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(69, 1, "CHAMERSTRASSE 50", NULL, NULL, NULL, 
"CH-6300  ZUG", NULL, "CH", NULL, NULL, "862379", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(70, 1, "TWO BROADWAY - 3RD FLOOR", NULL, 
NULL, NULL, "NEW YORK", "NY", "USA", NULL, NULL, "971354", NULL, NULL, NULL, 
"I", NULL, NULL, 1)
go

insert into account_address values(70, 2, "WORLD FINANCIAL CENTER", 
"NORTH TOWER, 16TH FLOOR", NULL, NULL, "NEW YORK,", "NY", "USA", "10281", 
"(212) 449-6177", NULL, "2124494309", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(70, 3, "WORLD FINANCIAL CENTER - SO TOWER", 
NULL, NULL, NULL, "NEW YORK", "NY", "USA", "10080", NULL, NULL, "2124494309", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(70, 4, "BOARD OF TRADE BUILDING", 
"P.O BOX 2585", NULL, NULL, "CHICAGO", "IL", "USA", "60690", "312-347-6200", 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(70, 5, "WORLD FINANCIAL CENTER", 
"NORTH TOWER", "250 VESSEY ST. - 22RD FL", NULL, "NEW YORK", "NY", "USA", 
"10281-1322", "2124490291", "6716341", "2124491788", "MLBSCTR", NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(71, 1, "SHORELINE SQUARE", 
"301 E. OCEAN BOULEVARD, STE. 410", NULL, NULL, "LONGBEACH", "CA", "USA", 
"90802", NULL, "194699 MIECO LG", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(71, 2, "363 NORTH BELT", "SUITE 1690", NULL, 
NULL, "HOUSTON", "TX", "USA", "77060", NULL, "76-5265", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(71, 72, "363 NORTH BELT", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", NULL, NULL, "TLX 765265", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(71, 73, "450 LEXINGTON AVE", NULL, NULL, 
NULL, "NEW YORK", "NY", "USA", "10017", NULL, "6733256", "212-450-0764", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(71, 74, "450 LEXINGTON AVE", NULL, NULL, 
NULL, "NEW YORK", "NY", "USA", "10017", "212 450 0650", "WU 1-2424", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(71, 75, "4 GREENSPOINT PLAZA", 
"16945 NORTHCHASE DRIVE, STE. 1640", NULL, NULL, "HOUSTON", "TX", "USA", 
"77060", "2817758900", "6734578", "2817758933", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(72, 2, "200 PARK AVE", NULL, NULL, NULL, 
"NEW YORK, N.Y.  10166", "NY", "USA", "10166", NULL, "232613", "12370", "MBKUR", 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(72, 3, "611 WEST 6TH STREET", "SUITE 2184", 
NULL, NULL, "LOS ANGELES", "CA", "USA", "90017", NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(72, 8, "1000 LOUISIANA, SUITE 5700", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77002", NULL, "25-5556", "77-5433", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(72, 9, "ALLIED BANK PLAZA", 
"SUITE 5700, 1000 LOUISIANA", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
"713-236-6245", "255554", "FAX: 713-236 62", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(72, 72, "NEW YORK, NY", NULL, NULL, NULL, 
"NEW YORK", "NY", "USA", NULL, NULL, "TLX 420153", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(73, 1, "MOBIL COURT", "3 CLEMENTS INN", NULL, 
NULL, "LONDON, ENGLAND", "NA", "GB", NULL, NULL, NULL, NULL, NULL, NULL, "I", 
NULL, NULL, 1)
go

insert into account_address values(74, 1, "GAS LIQUIDS DEPARTMENT", 
"500 DALLAS SUITE 900", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
"713-757-9504", NULL, "713-757-9549", NULL, "713-757-9582", "A", NULL, NULL, 1)
go

insert into account_address values(74, 2, "P.O.BOX 910485", NULL, NULL, NULL, 
'', "NA", "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(74, 3, "1 MAIN PLACE", "DALLAS, TX 75250", 
NULL, NULL, "DALLAS", "TX", "USA", "75250", NULL, "910240041", "DDD:9108614289", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(74, 4, "1010 MILAM", "HOUSTON, TX 77002", 
NULL, NULL, "HOUSTON", "TX", "USA", "77002", "7137572131", NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(74, 5, "3225 GALLOWS ROAD", NULL, NULL, NULL, 
"FAIRFAX", "VA", "USA", "22037-000", "7038463000", "232561", "7108330372", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(74, 6, "STOCK, TRANSPORTATION & TAX", 
"P.O. BOX 150", NULL, NULL, "DALLAS", "TX", "USA", "75221", "214/658-3113", 
"214-65855", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(74, 7, "100 OCEANGATE", "SUITE 1200", NULL, 
NULL, "LONG BEACH", "CA", "USA", "90802-432", NULL, "62-899620 ESL U", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(74, 8, "P.O. BOX 600", NULL, NULL, NULL, 
"KANSAS CITY", "MS", "USA", "64141", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(74, 9, "PO BOX 84010", NULL, NULL, NULL, 
"DALLAS", "TX", "USA", "75284", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(75, 1, "C/O MOBIL SALES AND SUPPLY", 
"3 CLEMENTS INN", NULL, NULL, "LONDON", NULL, "GB", "WC2A 2EB", NULL, "8812411", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(76, 2, "23 WALL STREET", NULL, NULL, NULL, 
"NEW YORK", "NY", "USA", NULL, "212-483-4386", "232-993 MGT GT", "212-648-5601", 
NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(76, 3, "60 WALL STREET", NULL, NULL, NULL, 
"NEW YORK", "NY", "USA", "10260", "2126482333", "WUD649216", NULL, "MGTUI", 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(76, 4, "9/43 EX. PL.", "60 WALL ST.", NULL, 
NULL, "NEW YORK", "NY", "USA", "10260", "212-648-2300", "FAX 212-837-593", 
"232993", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(76, 5, "60 VICTORIA EMBANKMENT", 
"P.O.BOX 161", "LONDON EC4Y OJP", NULL, "LONDON", NULL, "GB", NULL, NULL, 
"896631", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(76, 6, "30-01 DBS BUILDING", "6 SHENTON WAY", 
NULL, NULL, "SINGAPORE", NULL, "SGP", "0106", NULL, "FAX652289960", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(77, 1, "60 WALL STREET", NULL, NULL, NULL, 
"NEW YORK", "NY", "USA", "10260", NULL, "6734137", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(78, 3, "1221 AVENUE OF THE AMERICAS", 
"COMMODITIES DEPT - 5TH FLOOR", NULL, NULL, "NEW YORK", "NY", "USA", "10020", 
"2122962561/2577", "6801347", "2122962485/2487", "MSCOM", NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(78, 4, "1585 BROADWAY", 
"COMMODITIES 4TH FLOOR", NULL, NULL, "NEW YORK", "NY", "USA", "10036", NULL, 
NULL, "2127610292", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(78, 5, "MORGAN STANLEY INC CORP", 
"58-85 BROADWAY", "COMMODITIES DEPT., 4TH FLOOR", NULL, "NEW YORK", "NY", "USA", 
"10036", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(79, 1, "(SINGAPORE) PTE. LTD.", 
"GATEWAY EAST TOWER HEX 11-06/08", "152 BEACH ROAD", NULL, "SINGAPORE", NULL, 
"SGP", NULL, "2901800", "28299", "2961320", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(79, 2, "MORGAN STANLEY INTERNATIONAL
", NULL, 
NULL, NULL, "LONDON", NULL, "GB", NULL, NULL, NULL, "01144715137648", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(79, 3, "1585 BROADWAY", "4TH FLOOR", 
"COMM DEPT", NULL, "NEW YORK", "NY", "USA", "10036", NULL, NULL, "2122962487", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(79, 4, "80 RAFFLES PLACE", "UNIT NO. 42-01", 
"UOB PLAZA 1", NULL, "SINGAPORE", NULL, "SGP", "0104", "654396888", "RS28299", 
"654396968", "MSSING", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(80, 1, "PO BOX 1404", "1391 IRON HORSE ROAD", 
NULL, NULL, "MCPHERSON", "KS", "USA", "67460", "3162412340", "6736745", 
"7136213055", "NAS", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(80, 2, "2000 SOUTH MAIN", NULL, NULL, NULL, 
"MCPHERSON", "KS", "USA", "67460", NULL, "TWX 9107401318", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(81, 1, "KEILANIEMI", "P.O. BOX 20", NULL, 
NULL, "SF-02151 ESPOO", NULL, "SF", NULL, "35804501", "125867", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(81, 2, "TRADING AND SUPPLY", "KEILANIEMI", 
NULL, NULL, "SF - 02150 ESPOO  FINLAND", "NA", "SF", NULL, "358-450-4461", 
"124641", "FAX: 358-450-46", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(81, 3, "365 BLOOR STREET EAST", "SUITE 1910", 
NULL, NULL, "TORONTO, ONTARIO M5W 3L4", NULL, "CDN", NULL, NULL, "06-22021", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(81, 4, "P.O. BOX 20", "SF-02151 ESPOO", NULL, 
NULL, '', "NA", "SF", NULL, NULL, "FAX: 3580450444", NULL, NULL, NULL, "I", 
NULL, NULL, 1)
go

insert into account_address values(81, 5, "SINGAPORE BRANCH", "78 SHENTON WAY", 
"26TH STORY # 26-01", NULL, "SINGAPORE 0207", NULL, "SGP", NULL, "652231222", 
"RS78625771", "652233246", "NESPET", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(81, 72, "TORONTO, CANADA", NULL, NULL, NULL, 
"TORONTO", NULL, "CDN", NULL, NULL, "TLX 0622021", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(81, 73, "TORONTO, CANADA", NULL, NULL, NULL, 
"TORONTO", NULL, "CDN", NULL, NULL, "TLX 0622021", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(81, 74, "FIVE POST OAK PARK", "SUITE 1220", 
NULL, NULL, "HOUSTON", "TX", "USA", "77027", NULL, "3765325", "7134074480", 
"NESTE HOU", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(81, 75, "30 CHARLES 11 STREET", 
"ST. JAMES'S SQUARE", NULL, NULL, "LONDON", NULL, "UK", "SW1Y 4AE", NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(82, 1, "DRAMMENSVEIEN 264", NULL, NULL, NULL, 
"N-1321 STABEKK   NORWAY", "NA", "N", NULL, NULL, "76288  HYDRO N", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(83, 1, "4-5 AKASAKA 2-CHOME", "MINATO-KU", 
NULL, NULL, "TOKYO", NULL, "J", NULL, NULL, "78134228", "FAX011813350048", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(84, 1, "16 RAFFLES QUAY", 
"35-02 HONG LEONG BUILDING", NULL, NULL, "SINGAPORE 0104", NULL, "SGP", "10005", 
NULL, "21282", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(84, 2, "1211 AVENUE OF THE AMERICAS", NULL, 
NULL, NULL, "NEW YORK", "NY", "USA", "10036", "212-704-6788", "239161  NIPEC", 
"FAX 212-302-416", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(84, 72, "NEW YORK, NY", NULL, NULL, NULL, 
"NEW YORK", "NY", "USA", NULL, NULL, "TLX 239161", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(85, 1, "1400, 421-7TH AVENUE S.W.", NULL, 
NULL, NULL, "CALGARY, ALBERTA, T2P 4K9  CANADA", "NA", "CDN", "T2P 4K9", NULL, 
"03-825531", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(85, 2, "363 N.SAM HOUSTON PARKWAY E.", 
"STE.905", NULL, NULL, "HOUSTON", "TX", "USA", "77060", "713-999-8891", 
"FAX 7139998855", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(86, 1, "25 MELVILLE PARK ROAD", NULL, NULL, 
NULL, "MELVILLE", "NY", "USA", "11747", "516 293-4700", "6852316", "5162934780", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(86, 4, "P.O. BOX 2937", NULL, NULL, NULL, 
"MELVILLE", "NY", "USA", "11747", "5167520280", "961415", "5162934780", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(86, 5, "49B CHEMIN D'EYSINS", NULL, NULL, 
NULL, "CH-1260 NYON, VORD", NULL, "CH", NULL, "41 22 3629653", "419705", 
"41 22 3629656", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(87, 1, "C/O AVIN OIL ANSTALT", 
"12A IRODOU ATTIKOU STREET", "15124 MAROUSSI", NULL, "ATHENS", NULL, "GR", NULL, 
NULL, "219411", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(88, 1, "WARFVINGES VAG 25", NULL, NULL, NULL, 
"S-11291 STOCKHOLM", NULL, "S", NULL, "4684501300", "12892", "6609021", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(88, 2, "SANDHAMNSGATAN 51", 
"S-115 90 STOCKHOLM", NULL, NULL, "STOCKHOLM", NULL, "S", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(89, 1, "444 MARKET STREET, ROOM 5204", 
"SAN FRANCISCO, CA. 94111", NULL, NULL, '', "NA", "USA", NULL, "415-973-2257", 
"FAX: 415-973-92", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(90, 1, "33, RUE DE LA LOI", NULL, NULL, NULL, 
"BRUSSELS", NULL, "B", NULL, NULL, "21556", NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(90, 2, "52 RUE DE LINDUSTRIE", 
"1040 BRUSSELS", NULL, NULL, "BRUSSELS", NULL, "B", NULL, "011-3222339111", 
"8814221", "FAX: 011-322288", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(91, 1, "GEORGETOWN, CAYMAN ISLANDS", 
"C/O INTERMARITIME SERVICE CO., LTD", "5, QUAI DU MONT BLANC", NULL, 
"1211 GENEVA 11", NULL, "CH", NULL, NULL, "412197", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(91, 2, "CAYMAN ISLANDS", 
"C/O EPS SERVICES SA AS AGENTS", "3 QUAI DU MONT BLANC", "BP 1457", 
"1211 GENEVA,  SWITZERLAND", NULL, "CH", NULL, NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(92, 1, "611 ADAMS BUILDING", NULL, NULL, 
NULL, "BARTVILLE", "OK", "USA", "74004", NULL, "49-2455", "FAX: 918-661-08", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(92, 2, "STEENWEG OP BRSL 355", 
"1900 OVERIJSE", NULL, NULL, "BELGIUM", NULL, "B", NULL, NULL, NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(92, 3, "795 ADAMS BUILDING", NULL, NULL, 
NULL, "BARTLESVILLE", "OK", "USA", "74004", "918-661-6600", "FAX: 918-662-22", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(92, 4, "P.O. BOX 1967", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77251", NULL, "FAX: 713-669-73", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(92, 5, "SPUR 119 NORTH", "BORGER, TX.", NULL, 
NULL, "BORGER", "TX", "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(92, 6, "P.O. BOX 968", NULL, NULL, NULL, 
"BORGER", "TX", "USA", "790080968", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(92, 7, "P. O. BOX 271", "ATTN: MARY SLY", 
NULL, NULL, "BORGER", "TX", "USA", "790080271", "806 273 2831", NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(93, 1, "35 GUILDFORD ROAD", "WOKING SURREY", 
NULL, NULL, "GU22 7QT", NULL, "GB", NULL, "0483 756666", "859763", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(94, 1, "MANNING HOUSE", "22 CARLISLE PLACE", 
NULL, NULL, "LONDON  SW1P 1JA", NULL, "GB", NULL, "901144171233537", 
"918470 RO UK G", "901144171233674", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(95, 1, "BAARERMATTSTRASSE  3", "PO BOX 555", 
NULL, NULL, "CH-6341 BAAR", NULL, "CH", NULL, NULL, "845862323", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(95, 2, "49 WIGMORE STREET", NULL, NULL, NULL, 
"LONDON", NULL, "GB", "WHL 9LE", "441714123189", "85121223", "441714123189", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(96, 1, "VIKAN", NULL, NULL, NULL, 
"KRISTIANSUND N", NULL, "N", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(96, 2, "RADMANN HALMRASTS V 7", NULL, NULL, 
NULL, "SANDVIKA", NULL, "N", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(96, 3, "STAVANGER", "NORWAY", NULL, NULL, '', 
NULL, "N", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(96, 4, "3915 SAGA", "NORWAY", NULL, NULL, 
"STAVANGER", NULL, "N", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(97, 1, "ONE BROADGATE", NULL, NULL, NULL, 
"LONDON EC2M 7HA ENGLAND", NULL, "GB", NULL, "011441712602652", NULL, 
"011441712602933", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(97, 3, "AMERICAN EXPRESS TOWER", 
"WORLD FINANCIAL CENTER", "AMERICAN EXPRESS TOWER 7TH FLOOR", NULL, "NEW YORK", 
"NY", "USA", NULL, NULL, "3742037", "2125288014", NULL, NULL, "I", NULL, NULL, 
1)
go

insert into account_address values(97, 4, "101 HUDSON ST", NULL, NULL, NULL, 
"JERSEY CITY", "NJ", "USA", "07302", "2015245666", "3772418", "2015244905", 
NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(97, 5, "ONE BROAD GATE", NULL, NULL, NULL, 
"LONDON EC 2M 7HA ENGLAND", "NA", "GB", NULL, NULL, "888881", NULL, NULL, NULL, 
"I", NULL, NULL, 1)
go

insert into account_address values(97, 6, "388 GREENWICH STREET  20TH FLOOR", 
"SHEARSON LEHMAN HUTTON PLAZA", NULL, NULL, "NEW YORK", "NY", "USA", "10013", 
NULL, "3740244", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(97, 7, "36 MONUMENT STREET", 
"PENINSULAR HOUSE", NULL, NULL, "LONDON  EC3R BLJ ENGLAND", "NA", "GB", NULL, 
NULL, "8518950811", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(97, 8, "1 PACIFIC PLACE", "39TH FLOOR", NULL, 
NULL, "88 QUEENSWAY", NULL, "HK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(97, 72, "101 HUDSON STREET", "30TH FLOOR", 
NULL, NULL, "JERSEY CITY", "NJ", "USA", "07302-398", "201-524-5517", "3740237", 
"2015245520", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(97, 73, "AMERICAN EXPRESS TOWER", 
"3 WORLD FINANCIAL CENTER", "7TH FLOOR", NULL, "NEW YORK", "NY", "USA", "10285", 
"2125268781", NULL, "2125286865", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(97, 74, "200 VESEY STREET", "7TH FLOOR", 
NULL, NULL, "NEW YORK", "NY", "USA", "10285", "2125260538", NULL, "2125286865", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(98, 1, "SHELL-MEX HOUSE", "STRAND", NULL, 
NULL, "LONDON WC2R ODX", NULL, "UK", NULL, "44 171 5463000", "24661 SHELL G", 
"44 171 546 5666", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(99, 1, "P.O. BOX 4848", NULL, NULL, NULL, 
"ANAHEIM", "CA", "USA", "92803", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(99, 2, "ONE SHELL PLAZA", "910 LOUISIANA", 
NULL, NULL, "HOUSTON", "TX", "USA", "77002", "7132410004", "762248", 
"7132410004", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(99, 3, "TWO SHELL PLAZA", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77002", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(99, 4, "TWO SHELL PLAZA", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77002", NULL, "77-5815", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(99, 5, "ONE SHELL PLAZA", "P.O. BOX 2463", 
NULL, NULL, "HOUSTON", "TX", "USA", "77252", "713-241-5307", "775815", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(99, 6, "P.O. BOX 2463", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77252", NULL, "762248", "7132410004", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(100, 1, "C/O SOCIETE NATIONALE ELF", NULL, 
NULL, NULL, "AQUITAINE, TOUR ELF", NULL, "F", NULL, NULL, "615400", "615585", 
NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(100, 2, "UNKNOWN", NULL, "HAMILTON", NULL, 
"HAMILTON", "NA", "F", NULL, NULL, "615400 CODE 39A", NULL, NULL, NULL, "I", 
NULL, NULL, 1)
go

insert into account_address values(100, 3, "TOUR ELF", "CEDEX 45", NULL, NULL, 
"92078 PARIS LA DEFENSE", NULL, "F", NULL, "33147446674", "615585", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(100, 4, "2 PLACE DE LACOUPOLE", "PARIS", 
NULL, NULL, "LA DEFENSE", NULL, "F", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(101, 1, "59 RUE DE PROVENCE", NULL, NULL, 
NULL, "75009 PARIS", NULL, "F", NULL, "011 331 4463654", "842 281426", 
"FAX:011 331 446", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(101, 2, "105 CECIL STREET", 
"#24-01 THE OCTAGON", NULL, NULL, "THE OCTAGON", NULL, "SGP", "0106", NULL, 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(101, 3, "59 RUE DE PROVENCE", NULL, NULL, 
NULL, "PARIS 75009", NULL, "F", NULL, "33-1-44-637542", "FAX 33-1-44-636", 
"842283251", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(101, 4, "COMMODITY FINANCE DEPARTMENT", 
"10, PASSAGE DE L'ARCHE", NULL, NULL, "92034 PARIS LA DEFENSE CEDEX", NULL, "F", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(101, 5, "CAPITAL MARKETS DIVISION", 
"TOUR SOCIETE GENERALE", NULL, NULL, "92987 PARIS-LA DEFENSE CEDEX", NULL, "F", 
NULL, "33142137729", "280730", "33142136469", "SGMAR", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(101, 6, "1221 AVENUE OF THE AMERICAS", 
"11 FL. IBG/COMMODITIES", NULL, NULL, "NEW YORK", "NY", "USA", "10020", 
"2122786882", NULL, "2122787462", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(102, 1, "N-4035", NULL, NULL, NULL, 
"STAVANGER", NULL, "N", NULL, NULL, "73600", "51807042", NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(102, 2, "SWAN GARDENS", "10 PICCADILLY", 
NULL, NULL, "LONDON  W1V9LA", NULL, "GB", NULL, NULL, "8518953212", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(102, 3, "225 HIGHRIDGE RD", NULL, NULL, NULL, 
"STAMFORD", "CT", "USA", "06905", "203-978-6900", "4976310 STAP UI", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(102, 4, "P.O. BOX 300", "N-4001", NULL, NULL, 
"STAVANGER", NULL, "N", NULL, NULL, "73600", "51807042", NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(102, 72, "STAMFORD, CT", NULL, NULL, NULL, 
"STAMFORD", "CT", "USA", NULL, NULL, "TLX 4976310", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(103, 1, "200 SCHULZ DRIVE", NULL, NULL, NULL, 
"RED BANK", "NJ", "USA", "07701", NULL, "MCI 6858181 SIO", "RCA 238152 SIO", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(103, 2, "151 BODMAN PLACE", NULL, NULL, NULL, 
"RED BANK", "NJ", "USA", "07701", NULL, "RCA: 23-8152", NULL, NULL, NULL, "I", 
NULL, NULL, 1)
go

insert into account_address values(103, 4, "C/O STINNES HANDEL GMBH", 
"BALLINDAMM 17", NULL, NULL, "2000 HAMBURG 1", NULL, "BRD", NULL, NULL, 
"2117860", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(103, 72, " REDBANK, NJ", NULL, NULL, NULL, 
"REDBANK", "NJ", "USA", NULL, NULL, "TLX 238152", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(104, 1, "36 YORK MILLS ROAD", NULL, NULL, 
NULL, "NORTH YORK, ONTARIO", "NA", "CDN", " M2P 2C5", NULL, "06-217576", 
"FAX: 416-733-80", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(105, 1, "1801 MARKET STREET", 
"10 PENN CENTER, 25TH FLOOR", NULL, NULL, "PHILADELPHIA", "PA", "USA", "19103", 
"2155570685", "84-5230", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(105, 2, "200 W. LANCASTER AVE.", NULL, NULL, 
NULL, "WAYNE", "PA", "USA", "19087", "2159643600", "845230", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(105, 72, "PHILADELPHIA, PA", NULL, NULL, 
NULL, "PHILADELPHIA", "PA", "USA", NULL, NULL, "TLX 845230", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(106, 7, "1801 MARKET STREET - 5/10PC", 
"ATTN:  MARIA PEARSON", NULL, NULL, "PHILADELPHIA", "PA", "USA", "19103", NULL, 
"84-5230", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(106, 10, "1801 MARKET ST. 25TH FLOOR", 
"10 PENN CENTER", NULL, NULL, "PHILADELPHIA", "PA", "USA", "19103", 
"215-977 30 00", "173159", "21597773409", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(106, 11, "1801 MARKET ST.  23RD FLOOR", NULL, 
NULL, NULL, "PHILADELPHIA", "PA", "USA", "19103", "2155570685", "845259", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(106, 72, "PHILADELPHIA, PA", NULL, NULL, 
NULL, "PHILADELPHIA", "PA", "USA", NULL, NULL, "TLX 173109", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(107, 2, "1100 LOUISIANA, SUITE 4675", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77002", "7136551010", "6737244", 
"7136551626", "TCT HOU", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(108, 1, "1 WESTFERRY CIRCUS", NULL, NULL, 
NULL, "LONDON", NULL, "GB", "E14 4HA", NULL, "8956681", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(108, 2, "1 WESTFERRY CIRCUS", "CANARY WHARF", 
NULL, NULL, "LONDON", NULL, "UK", "E14 4HA", "441717193000", "8956681", 
"441717195159", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(108, 3, "2000 WESTCHESTER AVE.", NULL, NULL, 
NULL, "WHITE PLAINS", "NY", "USA", "10650-000", NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(109, 2, "P.O.BOX 845386", NULL, NULL, NULL, 
'', "NA", "USA", NULL, NULL, "FAX: 713-752-78", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(109, 20, "3336 RICHMOND AVENUE", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77098", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(109, 21, "4900 FOURNACE PLACE", NULL, NULL, 
NULL, "BELLAIRE", "TX", "USA", "77401", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(109, 72, "2000 WESTCHESTER AVE.", NULL, NULL, 
NULL, "WHITE PLAINS", "NY", "USA", "10650-0001", "9142534000", "TLX 175839", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(109, 73, "1111 BAGBY STREET", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77002", "713-752-7800", "713-752-4026", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(109, 74, "2000 WESTCHESTER AVE.", NULL, NULL, 
NULL, "WHITE PLAINS", "NY", "USA", "10650-0002", "9142534000", NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(110, 1, "2000 WESTCHESTER AVENUE", NULL, 
NULL, NULL, "WHITE PLAINS", "NY", "USA", "10650", NULL, NULL, "9142537111", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(110, 5, "150 ALHAMBRA CIRCLE", NULL, NULL, 
NULL, "CORAL GABLES", "FL", "USA", "33134", NULL, "275076", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(110, 6, "350 ORCHARD ROAD", 
"#11-07/10 SHAW HOUSE", NULL, NULL, "SINGAPORE 0923", NULL, "SGP", NULL, NULL, 
"RS 26396", NULL, "TXSING", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(110, 7, "1437 SOUTH BOULDER", NULL, NULL, 
NULL, "TULSA", "OK", "USA", "74119-360", "918-560-6481", "158187", 
"918-560-6419", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(111, 1, "P.O. BOX 4700", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77210", "713-752-7811", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(111, 2, "P.O. BOX 842306", NULL, NULL, NULL, 
"DALLAS", "TX", "USA", "75284", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(111, 3, "P.O. BOX 200778", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77216", "713-752-7609", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(111, 4, "1111 BAGBY STREET", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77002-254", NULL, NULL, "7137527896", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(112, 1, "2000 WESTCHESTER AVE", NULL, NULL, 
NULL, "WHITE PLAINS", "NY", "USA", "10650", "914-253-6282", "177440", 
"FAX: 914-253-60", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(112, 2, "2000 WESTCHESTER AVENUE", NULL, 
NULL, NULL, "WHITE PLAINS", "NY", "USA", "10650", NULL, "175839", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(112, 3, "FOR TEXACO FUEL & MARINE MARKETING", 
"PO BOX 1404", NULL, NULL, "HOUSTON", "TX", "USA", "772511404", "713-752-3272", 
"NA", "713-752-3284", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(112, 7, "1437 SOUTH BOULDER", NULL, NULL, 
NULL, "TULSA", "OK", "USA", "74119", NULL, "FAX:713-918-721", "158187 TRT", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(112, 8, "FOR TEXACO FUEL & MARINE MARKETING", 
"PO BOX 1404", NULL, NULL, "HOUSTON", "TX", "USA", "772511404", "713-752-3267", 
"NA", "713-752-3284", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(112, 9, "1111 RUSK", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77002", "7136505540", "15-8187", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(112, 10, "1437 SOUTH BOULDER", NULL, NULL, 
NULL, "TULSA", "OK", "USA", "74119", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(112, 11, "12700 NORTHBOROUGH DRIVE", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77067", "7138743891", "7138743909", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(112, 72, "WHITE PLAINS, NY //OR TULSA,OK", 
NULL, NULL, NULL, "WHITE PLAINS", "NY", "USA", "10650", NULL, "TLX 175839/OR/2", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(112, 73, 
"FOR TEXACO FUEL & MARINE MARKETING", "PO BOX 1404", NULL, NULL, "HOUSTON", 
"TX", "USA", "772511404", "713-752-3269", "NA", "713-752-3284", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(112, 74, "10 UNIVERSAL CITY PLAZA", NULL, 
NULL, NULL, "UNIVERSITY CITY", "CA", "USA", "91608-109", "818-505-2274", NULL, 
"8185054699", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(112, 75, 
"FOR TEXACO FUEL & MARINE MARKETING", "P.O. BOX 1404", NULL, NULL, "HOUSTON", 
"TX", "USA", "772511404", "713-752-3279", "N/A", "713-752-3284", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(112, 76, "1437 SOUTH BOULDER", 
"P.O. BOX 1650", NULL, NULL, "TULSA", "OK", "USA", "74119", NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(113, 2, "P.O. BOX 2736", NULL, NULL, NULL, 
"TULSA", "OK", "USA", "74101", NULL, "794336", "9185607626", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(113, 4, "2 GREENSPOINT PLAZA -SUITE 600", 
"16825 NORTH CHASE BLVD.", NULL, NULL, "HOUSTON", "TX", "USA", "77060", NULL, 
"794336", "910-881-1558", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(113, 5, "1670 BROADWAY", "SUITE 3500", NULL, 
NULL, "DENVER", "CO", "USA", "80202", NULL, NULL, "3038603210", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(113, 6, "TEXACO HERITAGE PLAZA", 
"1111 BAGBY STREET, 32ND FLOOR", NULL, NULL, "HOUSTON", "TX", "USA", 
"77002-254", "7137527999", NULL, "7137527225", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(113, 7, "1111 RUSK", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77002", NULL, NULL, NULL, NULL, NULL, "I", NULL, NULL, 
1)
go

insert into account_address values(113, 72, "DENVER, CO", NULL, NULL, NULL, 
"PAT FOLEY", "NA", "USA", NULL, NULL, "TLX 216183", NULL, NULL, NULL, "I", NULL, 
NULL, 1)
go

insert into account_address values(113, 73, "HOUSTON, TX", NULL, NULL, NULL, 
"PAT FOLEY", "NA", "USA", NULL, NULL, "TLX 794336", NULL, NULL, NULL, "I", NULL, 
NULL, 1)
go

insert into account_address values(113, 74, "DENVER, CO", NULL, NULL, NULL, 
"NORMAN KRUTSINGER", "NA", "USA", NULL, NULL, "TLX 216183", NULL, NULL, NULL, 
"I", NULL, NULL, 1)
go

insert into account_address values(113, 75, "333 NORTH GLENOAKS BUILDING", 
"SUITE 401", NULL, NULL, "BURBANK", "CA", "USA", "91502", NULL, "794336", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(113, 76, "1670 BROADWAY", NULL, NULL, NULL, 
"DENVER", "CO", "USA", "80122", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(113, 77, "1670 BROADWAY", "SUITE 2600", NULL, 
NULL, "DENVER", "CO", "USA", "80122", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(114, 1, "P.O. BOX 1650", NULL, NULL, NULL, 
"TULSA", "OK", "USA", "74102", "918-560 73 59", "FAX: 918-560-65", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(114, 2, "P.O. BOX 1404", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77251-140", NULL, "166751", "FAX: 713-752-40", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(114, 3, "1111 BAGBY STREET", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77002-254", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(114, 4, "1437 SOUTH BOULDER", NULL, NULL, 
NULL, "TULSA", "OK", "USA", "74119-360", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(115, 1, "PO BOX 52085", NULL, NULL, NULL, 
"PHOENIX", "AZ", "USA", "85072", "602-728-8948", NULL, "FAX: 602-728-71", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(116, 1, "CLARENDON HOUSE", 
"CHURCH STREET WEST", "P.O. BOX 488", NULL, "HAMILTON 5-31", NULL, "BER", NULL, 
NULL, "616370F", "77-4590", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(116, 2, "GROUPS TOTAL", "CEDEX 47", NULL, 
NULL, "92069 PARIS LA DEFENSE  FRANCE", NULL, "F", NULL, NULL, "616370F/616372", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(116, 3, "24 COUR MICHELET", "LA DEFENSE 10", 
NULL, NULL, "92800 PUTEAUX,  FRANCE", "NA", "F", NULL, NULL, "616374", NULL, 
NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(116, 4, 
"C/O SERVICE CENTRAL DU COURRIER DU GROUP", "CEDEX 47", NULL, NULL, 
"PARIS LA DEFENSE", NULL, "F", "92069", NULL, "616370", NULL, "TOTAL A 616370F", 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(116, 5, "THE PROMENADE HEX 06-10/11", 
"300 ORCHARD ROAD", NULL, NULL, "SINGAPORE", NULL, "SGP", "0923", NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(116, 6, "TOUR TOTAL", "24 COURS MICHELET", 
NULL, NULL, "92069 PARIS LA DEFENSE", NULL, "F", NULL, NULL, NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(117, 2, "TOTAL HOUSE", "4, LANCER SQUARE", 
NULL, NULL, "LONDON, ENGLAND", NULL, "GB", "W8 4EW", NULL, NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(118, 4, "TOTAL TOWER", "900 19TH STREET", 
NULL, NULL, "DENVER", "CO", "USA", "80202-252", NULL, "450508", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(118, 5, "P. O. BOX 500", NULL, NULL, NULL, 
"DENVER", "CO", "USA", "80201", NULL, "450-508", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(118, 7, "THE PROMENADE HEX 06-10/11", 
"300 ORCHARD ROAD", NULL, NULL, "SINGAPORE 0923", "NA", "SGP", NULL, NULL, NULL, 
NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(118, 72, "DENVER, CO", NULL, NULL, NULL, 
"DENVER", "CO", "USA", NULL, NULL, "TLX 450508", NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(118, 73, "SUITE 2201", "999 18TH STREET", 
NULL, NULL, "DENVER", "CO", "USA", "80202", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(119, 1, "133 CECIL STREET", 
"04-02 KECK SENG TOWER", NULL, NULL, "SINGAPORE", NULL, "SGP", NULL, NULL, 
"23933", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(120, 1, "1201 WEST FIFTH ST.", 
"LOS ANGELES, CA  90017", NULL, NULL, "LOS ANGELES", "CA", "USA", "90017", NULL, 
"188 393", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(121, 2, "1330 POST OAK BOULDVARD", 
"SUITE 2700", NULL, NULL, "HOUSTON", "TX", "USA", "77056", NULL, 
"TWX 9108813768", "7139935821", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(121, 3, "P.O. BOX 1188", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77251-118", NULL, "765443", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(121, 7, "300 OCEANGATE, SUITE 910", NULL, 
NULL, NULL, '', "NA", "USA", "90802", NULL, "9104902146", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(121, 9, "5805 HIGHWAY 80 EAST", NULL, NULL, 
NULL, "MIDLAND", "TX", "USA", "79701", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(121, 10, "P.O. BOX 1188, SUITE 1408", 
"RM 21, 1200 TRAVIS", NULL, NULL, "HOUSTON", "TX", "USA", "77251", "7134482860", 
NULL, "762459", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(121, 11, "P. O. BOX 20108", NULL, NULL, NULL, 
"SHREVEPORT", "LA", "USA", "71120", "7136546944", "762489", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(121, 12, "7600 E. ORCHARD ST., SUITE 301", 
NULL, NULL, NULL, "DENVER", "CO", "USA", "80111", "3037796800", "91093126", 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(121, 14, "P.O. BOX 1188", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77251-118", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(121, 72, "HOUSTON ., TX", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", NULL, NULL, "TLX 9108813768", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(121, 73, "HOUSTON, TX", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", NULL, NULL, "TLX 9108813768", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(121, 74, "HOUSTON, TX", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", NULL, NULL, "TLX 9108813768", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(122, 1, "THE HEEREN", 
"260 ORCHARD ROAD, HEX 07-01/05", NULL, NULL, "SINGAPORE 238855", NULL, "SGP", 
NULL, "65.737.9922", "78633473", "657370917", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(122, 2, "30 BIDEFORD ROAD", 
"03-01/02 THONGSIA BUILDING", NULL, NULL, "SINGAPORE 0922", NULL, "SGP", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(123, 1, "FOUR GREENSPOINT PLAZA", 
"SUITE 1940", "16945 NORTHCHASE DRIVE", NULL, "HOUSTON", "TX", "USA", "77060", 
"713 873-0080", "4620241", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(123, 2, "ROUTE DE MALAGNOU 40A", 
"P.O. BOX 325", NULL, NULL, "CH-1211 GENEVA 17", NULL, "CH", NULL, 
"011-41-22-786-5", "423421 VIT CH", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(123, 3, "TEXAS COMMERCE TOWER", "SUITE 7450", 
"600 TRAVIS STREET", NULL, "HOUSTON", "TX", "USA", "77002", "713 225-2500", 
"6718507", "7132252515", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(123, 5, "111 NORTH SEPULVEDA BLVD", 
"SUITE 200", NULL, NULL, "MANHATTAN BEACH", "CA", "USA", "90266", NULL, 
"21-5264", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(123, 6, "ROUTE DE MALAGNOU 40A", 
"P.O. BOX 325", NULL, NULL, "CH-1211 GENEVA 17", "NA", "CH", NULL, 
"011-41-22-786-5", "413158", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(123, 72, "HOUSTON, TX", NULL, NULL, NULL, 
"DARLINE SAMAYOA", "NA", "USA", NULL, NULL, "TLX 6718507", NULL, NULL, NULL, 
"I", NULL, NULL, 1)
go

insert into account_address values(123, 73, "600 TRAVIS STREET", "SUITE 7450", 
NULL, NULL, "HOUSTON", "TX", "USA", "77002", NULL, "203346", "7132252515", NULL, 
NULL, "I", NULL, NULL, 1)
go

insert into account_address values(123, 74, "1100 LOUISIANA,", "SUITE 5500", 
NULL, NULL, "HOUSTON", "TX", "USA", "77002-5255", NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(124, 4, "605 17TH STREET", NULL, NULL, NULL, 
"VERO BEACH", "FL", "USA", "32960-5518", "5617787100", "160008 GEORGE W", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(125, 1, "P.O. BOX 696000", NULL, NULL, NULL, 
"SAN ANTONIO", "TX", "USA", "78269", "5126418643", "0446153", "2106418493", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(125, 4, "2900 NORTH LOOP WEST", "SUITE 1400", 
NULL, NULL, "HOUSTON", "TX", "USA", "77092", NULL, "FAX: 713-684-11", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(125, 72, "SAN ANTONIO, TX", NULL, NULL, NULL, 
"SAN ANTONIO", "TX", "USA", "78230", NULL, "TLX 446153", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(126, 1, "25 COURS LANDRIVON", "P.O. BOX 6", 
"13 521  PORT DE BOUC", NULL, "CEDEX", "NA", "F", NULL, "33 42401515", 
"420 673", "42351539", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(126, 2, "1110 PARK ST.", "ATTN:  KEN SMITH", 
NULL, NULL, "BEAUMONT", "TX", "USA", "77701", "409-832-1262", "NA", 
"409-839-8505", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(126, 3, "SUITE 301  1629 THAMES STREET", 
NULL, NULL, NULL, "BALTIMORE", "MD", "USA", "21231", NULL, NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(127, 1, "55 WATER ST.", "47TH FLOOR", NULL, 
NULL, "NEW YORK", "NY", "USA", "10043", NULL, NULL, "212-291-3158", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(127, 2, "ONE COURT SQUARE", NULL, NULL, NULL, 
"LONG ISLAND CITY", "NY", "USA", "11120", "718-248-7089", NULL, NULL, 
"718-248-1405", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(127, 3, "399 PARK AVENUE", 
"7TH FLOOR, ZONE 2", NULL, NULL, "NEW YORK", "NY", "USA", "10043", NULL, 
"4945326", "2122913684", "INVEST", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(128, 1, "1100 LOUISIANA", "SUITE 4675", NULL, 
NULL, "HOUSTON", "TX", "USA", "77002", "7136555050", NULL, "7136551626", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(129, 1, "A.V. MARINA NACIONAL 329", NULL, 
NULL, NULL, "TORRE EJECUTIVA, PISO 20", NULL, "MEX", NULL, "5252270131", 
"3831773671", "5252270118", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(130, 1, "435 ORCHARD ROAD", 
"10 - 04/06 WISMA ATRIA", NULL, NULL, "SINGAPORE 238877", NULL, "SGP", NULL, 
"657361833", "39230", "657363611", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(130, 2, "STATOIL A/S
", NULL, NULL, NULL, 
"NORWAY
", NULL, "N", NULL, NULL, "73600", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(131, 1, "200 PARK AVENUE", NULL, NULL, NULL, 
"FLORHAM PARK", "NJ", "USA", "07932", "201 765 5444", "132092", "201 765 4983", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(132, 1, "10, RUE DE CASTIGLIONE", NULL, NULL, 
NULL, "75001 PARIS", NULL, "F", NULL, "33142961626", "212679", "33142619475", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(133, 1, "1185 AVENUE OF THE AMERICAS", NULL, 
NULL, NULL, "NEW YORK", "NY", "USA", "10036", "2125368116", "126594", 
"2123020826", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(134, 1, "P.O. BOX 4369", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77210", "713-650-6255", NULL, "7135102705", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(135, 1, "ONE WILLIAMS CENTER", NULL, NULL, 
NULL, "TULSA", "OK", "USA", "74172", "918 588 3900", NULL, "9185884074", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(136, 1, "500 NYALA FARMS", NULL, NULL, NULL, 
"WESTPORT", "CT", "USA", "06880", "2032216100", "141009", "2032216775", 
"PBENGYUI", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(137, 1, "WATERMILL CENTER", "P.O. BOX 9161", 
NULL, NULL, "WALTHAM", "MA", "USA", "02254", "617-894-8800", "261978", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(137, 2, "1200 SMITH ST", "SUITE 2915", NULL, 
NULL, "HOUSTON", "TX", "USA", "77002", "7136591226", NULL, "7136594747", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(137, 3, "800 SOUTH STREET", NULL, NULL, NULL, 
"WALTHAM", "MA", "USA", "02254", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(138, 1, "P.O. BOX 2340", NULL, NULL, NULL, 
"DALLAS", "TX", "USA", "75221", "214.880.2111", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(139, 1, "WESTBLAAK 163", NULL, NULL, NULL, 
"3012 KJ ROTTERDAM", NULL, "NL", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(139, 2, "MOBIL SALES & SUPPLY CORP", 
"AS AGENT FOR MOBIL TRADING BV", "3 CLEMENTS INN", NULL, "LONDON WC2A 2EB", 
NULL, "UK", NULL, NULL, "8812411", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(139, 3, "(SINGAPORE BRANCH)", 
"18 PIONEER ROAD", NULL, NULL, "SINGAPORE", NULL, "SGP", "2262", 
"010 65 660 6442", "21327", NULL, "RS21327 MOBOIL", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(139, 4, "150 EAST, 42 STREET", NULL, NULL, 
NULL, "NEW YORK", "NY", "USA", "10017", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(139, 5, "MOBIL COURT   3 CLEMENTS INN", NULL, 
NULL, NULL, "LONDON WC2A 2EB", NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(140, 1, "1200 SMITH STREET", "SUITE 900", 
NULL, NULL, "HOUSTON", "TX", "USA", "77002", "713-951-2000", "713-951-2252", 
"7139512233", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(141, 1, "P.O. BOX 219272", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77218", NULL, NULL, "7135843907", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(141, 2, "1601 BRYAN ST", "ROOM 37-038", NULL, 
NULL, "DALLAS", "TX", "USA", "75221", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(141, 3, "200 WESTLAKE PARK BOULEVARD", 
"SUITE 200", NULL, NULL, "HOUSTON", "TX", "USA", "77079", "7135843972", NULL, 
"7135843907", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(141, 4, "C/O VASTAR RESOURCES, INC.", 
"15375 MEMORIAL DRIVE", NULL, NULL, "HOUSTON", "TX", "USA", "77079", NULL, NULL, 
NULL, NULL, "7135846160", "A", NULL, NULL, 1)
go

insert into account_address values(142, 1, "P.O. BOX 3327", 
"600 TRAVIS, 12TH FLOOR", NULL, NULL, "HOUSTON", "TX", "USA", "77002", 
"316-832-7959", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(142, 2, "4111 EAST 37TH STREET NORTH", NULL, 
NULL, NULL, "WICHITA", "KS", "USA", "67220", "3168285966", "27326", 
"3168287977", "KOCH G", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(142, 3, "333 CLAY STREET", "SUITE 1300", 
NULL, NULL, "HOUSTON", "TX", "USA", "77002", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(143, 1, "85 BROAD STREET", NULL, NULL, NULL, 
"NEW YORK", "NY", "USA", "10004", "212-902-0776", "6720148", "2123443457", NULL, 
NULL, "I", NULL, NULL, 1)
go

insert into account_address values(143, 2, "133 FLEET STREET", 
"PETERBOROUGH COURT", NULL, NULL, "LONDON, EC4A 2BB", NULL, "UK", NULL, NULL, 
NULL, NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(143, 3, "50 RAFFLES PLACE HEX 29-01", 
"SHELL TOWER", NULL, NULL, "SINGAPORE 0104", NULL, "SGP", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(143, 4, "1 RAFFLES LINK", 
"#07-01 SOUTH LOBBY", NULL, NULL, "SINGAPORE 039393", NULL, "SGP", NULL, NULL, 
"23778", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(144, 1, "1801 MARKET STREET", "25TH FLOOR", 
NULL, NULL, "PHILADELPHIA", "PA", "USA", "19103-169", "215 977-3851", NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(145, 1, "1 CENTRAL PARK PLAZA", NULL, NULL, 
NULL, "OMAHA", "NE", "USA", "68102", "402-978-4000", NULL, "4025954759", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(145, 2, "5 SKIDAWAY VILLAGE WALK, SUITE 201", 
NULL, NULL, NULL, "SAVANNAH", "GA", "USA", "31411-290", "912-598-8392", NULL, 
"912-598-8692", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(145, 3, "(INTERNATIONAL) S.A. BERGERCO DIV.", 
"16,CHEMIN DE COQUELICOTS - AIR", NULL, NULL, "CENTER, CH 1214 VERNIER, GENEVE", 
NULL, "CH", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(145, 4, "9 CON AGRA DRIVE", NULL, NULL, NULL, 
"OMAHA", "NE", "USA", "68102-500", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(146, 1, "363 NORTH SAM HOUSTON  PKWY EAST", 
"SUITE 170", NULL, NULL, "HOUSTON", "TX", "USA", "77060", "2814478008", NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(147, 1, "225 HIGH RIDGE ROAD", NULL, NULL, 
NULL, "STAMFORD", "CT", "USA", "06905", "203 978 6908", "6819522", "2039786953", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(148, 1, "SUITE 2400", "855 2ND ST. S.W.", 
NULL, NULL, "CALGARY, ALBERTA T2P 4J9", NULL, "CDN", NULL, "403-237-1126", NULL, 
"403-237-1078", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(149, 1, "399 KNOLLWOOD ROAD", "SUITE 204", 
NULL, NULL, "WHITE PLAINS", "NY", "USA", "10603", "914.421.1700", NULL, 
"9144210421", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(150, 1, "P.O. BOX HM 2257", NULL, NULL, NULL, 
"HAMILTON  HMJX", NULL, "BER", NULL, "4412951432", "3736/3205SPCTBA", 
"4412950121", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(151, 1, "500 NYALA FARMS ROAD", NULL, NULL, 
NULL, "WESTPORT", "CT", "USA", "06092", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(151, 2, "5 WORLD TRADE CENTER", "4TH FLOOR", 
NULL, NULL, "NEW YORK", "NY", "USA", "10048", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(152, 1, "BROADWALK HOUSE", "5 APPOLD STREET", 
NULL, NULL, "LONDON  EC2A 2DA", NULL, "UK", NULL, "44 171 6380300", "8950831", 
"44 171 6380369", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(153, 1, "WORLD FINANCIAL CENTER", 
"SOUTH TOWER - 24TH FLOOR", NULL, NULL, "NEW  YORK", "NY", "USA", "10080", NULL, 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(154, 1, "RUE DES BAINS   33-35", 
"P.O. BOX 162", NULL, NULL, "1211 GENEVA 8", NULL, "CH", NULL, "41 22 3221111", 
"423421", "41 22 7816611", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(154, 2, "BOWATER HOUSE", "68 KNIGHTSBRIDGE", 
NULL, NULL, "LONDON", NULL, "GB", "SW1X7LT", NULL, "929101", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(154, 3, "ROUTE DE MALAGNOU 40A", 
"CASE POSTAL 325", NULL, NULL, "1211 GENEVA 17", NULL, "CH", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(155, 1, "111 FIFTH AVENUE S.W.", NULL, NULL, 
NULL, "CALGARY ALBERTA T2P 3Y6", NULL, "CDN", NULL, "403-267-8615", NULL, 
"4032694592", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(156, 1, "38-08 DBS BUILDING", "TOWER 2", 
NULL, NULL, "SINGAPORE 0106", NULL, "SGP", NULL, NULL, "78621430", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(156, 2, "6 SHENTON WAY", 
"HEX 42-01 DBS BUILDING", NULL, NULL, "SINGAPORE 0106", NULL, "SGP", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(157, 1, "FOUR GREENSPOINT PLAZA", 
"16945 NORTHCHASE DRIVE, SUITE 2300", NULL, NULL, "HOUSTON", "TX", "USA", 
"77060", "713 8762393", "77042", "7138762565", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(158, 1, "717 NORTH HARWOOD STREET", NULL, 
NULL, NULL, "DALLAS", "TX", "USA", NULL, "214-953-2000", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(159, 1, "2533 NORTH 117 AVENUE", NULL, NULL, 
NULL, "OMAHA", "NE", "USA", "68164", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(160, 1, "15375 MEMORIAL DRIVE", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77079", NULL, NULL, "7135843905", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(161, 1, "1200, EAU CLAIRE PLACE II", 
"521-3RD AVE.S.W.", NULL, NULL, "CALGARY, ALBERTA", NULL, "CDN", "T2P3T3", 
"403-265-4224", NULL, "403-265-4308", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(162, 1, "HUMBOLDTRING 15", 
"D-45472 MULHEIM AN DER RUHR", NULL, NULL, "N/A", NULL, "BRD", NULL, 
"(02 08)494-0", "8 56 200", "2A (02 08) 494-", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(163, 1, "1400, 421-7TH AVE. S.W.", NULL, 
NULL, NULL, "CALGARY, ALBERTA", NULL, "CDN", "T2P4K9", "403-262-6800", 
"03-825531", "403-264-3899", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(164, 1, "ONE GREENWICH PLAZA", NULL, NULL, 
NULL, "GREENWICH", "CT", "USA", "06830", "2038613600", "170129", "2038613827", 
"AIG1", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(164, 2, "120 LEMAN STREET", NULL, NULL, NULL, 
"LONDON  E1 8EU", NULL, "UK", NULL, "011441714805181", "8811948", 
"011441714812009", "AIGTRA G", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(165, 1, "1800,645 - 7TH AVENUE S.W.", 
"P.O. BOX 2670, STATION M", NULL, NULL, "CALGARY, ALBERTA", NULL, "CDN", 
"T2P3X9", "403-231-1885", NULL, "403-231-1969", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(166, 1, "1000 LOUSIANA, SUITE 4460", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77002", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(167, 1, "1221 LAMAR, SUITE 1600", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77010-303", "713-650-1246", NULL, "713-655-1866", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(168, 1, "4TH FLOOR, TOPPERSTRASSE 5", NULL, 
NULL, NULL, "6004 LUCERN, SWITZERLAND", NULL, "CH", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(169, 1, "POINTE-A-PIERRE", NULL, NULL, NULL, 
"TRINIDAD", NULL, "TT", NULL, " 8096581203", NULL, "8096581213", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(170, 1, "ONE CONAGRA DRIVE", NULL, NULL, 
NULL, "OMAHA", "NE", "USA", "68102", "402-595-4755", NULL, "402-595-4759", NULL, 
NULL, "I", NULL, NULL, 1)
go

insert into account_address values(171, 1, "952 ECHO LANE", "SUITE 460", NULL, 
NULL, "HOUSTON", "TX", "USA", "77024", "7139736655", NULL, "7139736656", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(172, 1, "COLLETTE HOUSE", "52-55 PICCADILLY", 
NULL, NULL, "LONDON", NULL, "GB", "9AA", "44 171 499 0432", "299686", 
"44 171 499 5270", "ASPEN G", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(173, 1, "ENERGIEWEG 1", "PO BOX 200", NULL, 
NULL, "3200 AE SPIJKENISSE", "NA", "NL", NULL, "31 1880 13144", "(44)29524", 
"31 1880 24400", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(173, 2, "JARMUIDEN 65", "PO BOX 90250", NULL, 
NULL, "1006 BG AMSTERDAM", "NA", "NL", NULL, "31 20 5060700", "(044)12901", 
"31 20 6149084", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(174, 1, "RBC CENTRE", 
"71 QUEEN VICTORIA STREET", NULL, NULL, "LONDON EC4V 4DE", "NA", "GB", NULL, 
"44 71 489 1188", "929111", "44 71 329 6144", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(175, 1, "29 RUE DE LA ROTISSERIE", NULL, 
NULL, NULL, "CH-1204 GENEVE", "NA", "CH", NULL, "41 22 310 3550", "(45)425051", 
"41 22 310 3533", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(176, 1, "INTERNATIONAL OPERATIONS 0742", 
"301 SOUTH TRYON STREET T-7", NULL, NULL, "CHARLOTTE", "NC", "USA", "28288", 
NULL, NULL, "1 704 374 2768", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(176, 2, "ONE FIRST UNION CENTER", 
"8TH FLOOR", NULL, NULL, "CHARLOTTE", "NC", "USA", "282880600", "704.374.3471", 
NULL, "704.383.0575", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(177, 1, "CALEB BRETT HOUSE", 
"734 LONDON ROAD", "WEST THURROCK", "GRAYS", "BRENTWOOD, ESSEX", NULL, "UK", 
"RM20 3NL", "44 1708 680 200", "928522 BRETT G", "44 1708 680 255", "ITSAP G", 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(178, 1, "MILLBANK TOWER", NULL, NULL, NULL, 
"MILLBANK, LONDON SW1P 4QP", NULL, "UK", "SW1P 4QP", "011144171269406", 
"922002", "011441712694030", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(178, 2, "HERON HOUSE", "322 HIGH HOLBORN", 
NULL, NULL, "LONDON WC 1V 7PW", NULL, "UK", NULL, "011441712694000", "922002", 
"011441712694030", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(179, 1, "HEAD OFFICE", "COMMERCE COURT WST", 
NULL, NULL, "TORONTO, ONTARIO", NULL, "CDN", NULL, "1 416 9802211", 
"0210623094", "14169568212", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(179, 2, "161 BAY STREET", "P.O. BOX 500", 
NULL, NULL, "TORONTO,  ON,  M5J2S8", NULL, "CDN", NULL, NULL, NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(179, 3, "2 MARKET STREET", "15TH FLOOR", 
NULL, NULL, "SYDNEY", NULL, "AUS", NULL, NULL, "071176888", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(180, 1, "FOR AND ON BEHALF OF", 
"SHELL TRADING INTERNATIONAL LIMITED", "LIMITED", "SHELL-MEX HOUSE, THE STRAND", 
"LONDON WC2R OZA", NULL, "UK", NULL, NULL, "919651", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(180, 2, 
"FOR/ON BEHALF OF SHELL INTL PETROLEU PCC", "SHELL-MEX HOUSE, STRAND", NULL, 
NULL, "LONDON WC2R OZA,  ENGLAND", NULL, "UK", NULL, NULL, "/A919651 -/", NULL, 
NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(181, 1, "POLDERDIJKWEG 16 (HAVEN 407)", NULL, 
NULL, NULL, "B-2030 ANTWERPEN", NULL, "B", NULL, "32 2 545 8411", "31603 DESTB", 
"32 3 545 8419", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(182, 1, "33 ATHOL STREET", "DOUGLAS", NULL, 
NULL, "ISLE OF MAN  IM1 1LB", NULL, "GB", NULL, "44 1624 672035", "621030", 
"44 1624 670986", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(182, 2, "13-15 HOPE STREET", "DOUGLAS", NULL, 
NULL, "ISLE OF MAN  1M1 1AQ", NULL, "GB", NULL, "011441624672085", "621030", 
"011441624670986", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(183, 1, "1 RAFFLES PLACE #54-00", 
"OUB CENTRE", NULL, NULL, "SINGAPORE 0104", NULL, "SGP", NULL, "65 5322533", 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(184, 1, "STIGBERGSLIDEN 5", NULL, NULL, NULL, 
"GOTHENBURG", NULL, "S", "414 63", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(185, 1, "PTE. LTD.", 
"4 SHENTON WAY 09-08/12", "SHING KWAN HOUSE", NULL, "SINGAPORE, 0106", NULL, 
"SGP", NULL, "652255188", "78625141", "652253878", "SMOILS", NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(185, 2, "9 TEMASEK BOULEVARD", 
"  18-01/02/03 SUNTEC TOWER TWO", NULL, NULL, "SINGAPORE", NULL, "SGP", NULL, 
NULL, "RS25141SMOILS", "653397037", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(186, 1, "C/O TRAFIGURA LTD.", 
"17 CONNAUGHT PLACE", NULL, NULL, "LONDON W2 2EL	", NULL, "GB", NULL, NULL, 
"868001", NULL, NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(186, 2, "LUCERNE BRANCH OFFICE", 
"4TH FLOOR, TOPFERSTRASSE 5,", NULL, NULL, "CH-6004 LUCERNE, SWITZERLAND", NULL, 
"CH", NULL, NULL, "045868001", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(187, 1, "2930 REVERE", "SUITE 200", NULL, 
NULL, "HOUSTON", "TX", "USA", "77098", "7135270019", "650659177", "7135270828", 
"MCIUM", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(188, 1, 
"OWNED BY SHELL EASTERN TRADING  (PTE) LT", "HEX 39-00 SHELL TOWER
", 
"50 RAFFLES PLACE
", NULL, "SINGAPORE  0104", NULL, "SGP", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(189, 1, "101 THOMSON ROAD
", 
"# 21-05/06 UNITED SQUARE
", NULL, NULL, "SINGAPORE 1130", NULL, "SGP", NULL, 
NULL, "78635490", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(190, 1, "400 ORCHARD ROAD", 
"HEX 13-05 ORCHARD TOWERS", NULL, NULL, "SINGAPORE 238875", NULL, "SGP", NULL, 
"65 235 2133", "RS23716 COSFE", "65 2351611", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(191, 1, "1 BROADGATE", NULL, NULL, NULL, 
"LONDON EC2M 2AP", NULL, "GB", NULL, "44-(0)171 496-4", "888811", 
"44-(0)171 579-6", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(191, 2, "BRITANNIC TOWER", "MOOR LANE", NULL, 
NULL, "LONDON  EC2Y 9BU", NULL, "GB", NULL, NULL, "888811", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(192, 1, "THE EQUITABLE TOWERS", 
"787 7TH AVENUE,  30TH FLOOR", NULL, NULL, "NEW YORK", "NY", "USA", "10019", 
"2128412074", "82982", "2128412174", "PARIBAS", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(192, 2, "80 RAFFLES PLACE", 
"#45-01 UOB PLAZA 1", NULL, NULL, "SINGAPORE 0104", NULL, "SGP", NULL, 
"654395000", NULL, "655384300", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(192, 3, "3, RUE D'ANTIN", NULL, NULL, NULL, 
"PARIS 75002", NULL, "F", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(193, 1, "6TH FLOOR", "MINSTER COURT 2", 
"MINCING LANE", NULL, "LONDON  EC3M 7BB", NULL, "GB", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(194, 1, "10 COLLYER QUAY", 
"#10-03/05 OCEAN BUILDING", NULL, NULL, "SINGAPORE 049315", NULL, "SGP", NULL, 
"655350622", "25582", "655343131", "PRISIN", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(195, 1, "200 PUBLIC SQUARE", "5TH FLOOR", 
NULL, NULL, "CLEVELAND", "OH", "USA", "44114", "2165864141", "62917760", 
"2165862403", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(195, 2, "200 WESTLAKE PARK BOULEVARD", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77079", "7135605594", "774362", 
"7135589927", "BPTEXAS HOU A", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(195, 3, "STAMFORD HARBOR PARK", 
"333 LUDLOW STREET", NULL, NULL, "STAMFORD", "CT", "USA", "06902", "2033524504", 
NULL, "2033524599", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(195, 4, "1 BROADGATE", NULL, NULL, NULL, 
"LONDON", NULL, "UK", "EC2M 2AP", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(196, 1, "STAMFORD HARBOR PARK", 
"333 LUDLOW STREET", NULL, NULL, "STAMFORD", "CT", "USA", "06902", "2033524500", 
"984645", "2033524599", "BPNAP NY", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(197, 1, "BP TOWER , 22ND STORY", 
"396 ALEXANDRA ROAD", NULL, NULL, "SINGAPORE 0511", NULL, "SGP", NULL, NULL, 
"786RS55788", "652737897", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(198, 1, "14 CHEMIN DE NORMANDIE", "CH-1211", 
NULL, NULL, "GENEVA 12", NULL, "CH", NULL, "01141227032111", "422893", 
"01141227032122", "TRX CH", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(198, 2, "300 BEACH ROAD HEX 23-01", 
"THE CONCOURSE", NULL, NULL, "SINGAPORE 0719", NULL, "SGP", NULL, "653909404", 
NULL, "653909698", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(199, 1, "72 CHERRY HILL DRIVE", NULL, NULL, 
NULL, "BEVERLY", "MA", "USA", "01915", "5085241500", "4750165", "5085241543", 
"TRDX UI", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(200, 1, "270 PARK AVENUE", NULL, NULL, NULL, 
"NEW YORK", "NY", "USA", "10017", "2122706000", "232337", "2122707468", 
"CBC UR", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(201, 1, "93 WIGMORE STREET", NULL, NULL, 
NULL, "LONDON W1H 9AA", NULL, "GB", NULL, "441714878100", "266471", 
"441714878509", "CHVLTC G", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(201, 2, "SAN FRANCISCO", NULL, NULL, NULL, 
"SAN FRANCISCO", "CA", "USA", NULL, "4158945654", "470074", "4158949327", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(201, 3, "P.O. BOX 3726", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77253-3726", NULL, "762799", "7137544597", 
"CHERVON GT HOU", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(202, 1, "575 LENNON LANE", "SUITE N2000", 
NULL, NULL, "WALNUT CREEK", "CA", "USA", "94598", "5109446200", "176967", 
"5109446269", "CHEVCORP SFO", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(202, 2, "1331 LAMAR", "7TH FLOOR", NULL, 
NULL, "HOUSTON", "TX", "USA", "77010", "7137542000", "76-2799", "7137544597", 
"CHEVRON GT HOU", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(202, 3, "P.O. BOX 7146", 
"DIVISION OF CHEVRON USA INC.", NULL, NULL, "SAN FRANCISCO", "CA", "USA", 
"94120-7146", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(203, 1, "UBERSEEING 40", "22297", NULL, NULL, 
"HAMBURG", NULL, "BRD", NULL, "494063750", "21151365", "494063753711", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(204, 1, "HOPEWELL CENTER, 55TH FLOOR", 
"183 QUEEN'S ROAD EAST", NULL, NULL, "HONG KONG", NULL, "HK", NULL, 
"85228216200", "73215", "85225270465", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(205, 1, "BOW BELL SOUTH", "BREAT STREET", 
"CHEAPSIDE", NULL, "LONDON EC4M 9BQ", NULL, "GB", NULL, "441718220022", 
"888251", "441718220089", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(206, 1, "6-3, MARUNOUCHI 2-CHOME", 
"CHIYODA-KU", NULL, NULL, "TOKYO 10086", NULL, "J", NULL, "81332102121", 
"J33333", "81332106064", "MCTOK A", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(207, 1, "200 PEACH STREET", NULL, NULL, NULL, 
"EL DORADO", "AR", "USA", "71730", "5018626411", "5369210", "5018646373", 
"MURPHYOIL ELDO", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(208, 1, "7500A BEACH ROAD", 
"#08-303/307 THE PLAZA", NULL, NULL, "SINGAPORE 0719", NULL, "SGP", NULL, 
"652916686", "37103", "652991339", "KQOPL", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(208, 2, "BRUMBY HOUSE, 1ST FLOOR", 
"JALAN BAHASA", "PO BOX 80148", NULL, "LABAUN F.T.", NULL, "MW", "87011", NULL, 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(209, 1, "13430 NORTHWEST FREEWAY, #1200", 
NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77040", "7137441790", NULL, 
"7137445364", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(210, 1, "C/O AQUILA RISK MANAGEMENT CORP", 
"2533 NORTH 117TH AVE. SUITE 200", NULL, NULL, "OMAHA", "NE", "USA", 
"68164-8618", "4024984490", NULL, "4024984543", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(211, 1, "72 CHERRY HILL DRIVE", NULL, NULL, 
NULL, "BEVERLY", "MA", "USA", "01915", "5085241500", NULL, "5085241688", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(212, 1, "P.O. BOX 3976", 
"A DIVISION OF CHEVRON USA INC.", NULL, NULL, "HOUSTON", "TX", "USA", 
"77253-3976", NULL, "762972", "7137544597", "CHEVSPLY HOU", NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(213, 1, "P.O. BOX 1164", NULL, NULL, NULL, 
"FUJAIRAH", NULL, "UAE", NULL, "9719228415", "89101", "9719228414", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(213, 2, "1850 PARKWAY PLACE", "SUITE 420", 
NULL, NULL, "ATLANTA", "GA", "USA", NULL, NULL, "6503716890", "7704219653", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(214, 1, "51 BRAS BASAH ROAD #06-02/03", 
"PLAZA BY THE PARK", NULL, NULL, "SINGAPORE 0718", NULL, "SGP", NULL, 
"653382000", "RS50118PDS", "653388287", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(215, 1, "AV MARINA NACIONAL 329", "PISO 22", 
NULL, NULL, "MEXICO CITY C.P. 11311", NULL, "MEX", NULL, "5252270126", 
"3831773671", "7135670118", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(216, 1, "5 PRINCE'S GATE", "KNIGHTSBRIDGE", 
NULL, NULL, "LONDON SW7 1PJ", NULL, "UK", NULL, NULL, "851916044", 
"441718237069", NULL, NULL, "I", NULL, NULL, 1)
go

insert into account_address values(216, 2, "80 AVE AHMED GHERMOUL", NULL, NULL, 
NULL, "ALGIERS", NULL, "DZ", NULL, "213 02711223", "55123-324-325", 
"213 02646047", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(217, 1, "COMET HOUSE (S37)", "P.O. BOX 10", 
"HOUNSLOW", NULL, "MIDDLESEX TW6 25A", NULL, "GB", NULL, "441815623695", 
"8813983", "441815622778", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(218, 1, "4 EMBARCADERO CENTER", "SUITE 1800", 
NULL, NULL, "SAN FRANCISCO", "CA", "USA", "94111", "4159563834", "210422", 
"4159561508", "CHEMOL UR", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(218, 2, "2365 EAST SEPULVEDA BOULEVARD", 
NULL, NULL, NULL, "CARSON", "CA", "USA", "90810", "3104276611", "278210", 
"3104274621", "RCA", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(219, 1, "10777 WESTHEIMER  SUITE 650", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77042", "7132608537", NULL, "7132601825", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(220, 1, "200 WESTLAKE PARK BLVD.", 
"SUITE 900", NULL, NULL, "HOUSTON", "TX", "USA", "77079", NULL, NULL, 
"7135482095", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(221, 1, "1 BROADGATE", NULL, NULL, NULL, 
"LONDON EC2M 2AP", NULL, "UK", NULL, "011441714693582", "888811", 
"011441714962854", "BPLDNX", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(221, 2, "BRITANNIC TOWER", "MOOR LANE", NULL, 
NULL, "LONDON EC2Y 9BU", NULL, "UK", NULL, "011441714693582", NULL, "5796102", 
NULL, "011441715676101", "A", NULL, NULL, 1)
go

insert into account_address values(222, 1, "123", NULL, NULL, NULL, 
"NEWTON SQUARE", "PA", "USA", NULL, NULL, NULL, "6103536169", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(223, 1, "AVDA, ZUGAZARTE, 29", "LAS ARENAS", 
NULL, NULL, "VIZCAYA", NULL, "E", NULL, "3444818700", "31931", "3444635966", 
"NORPEE", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(224, 1, "10 ANSON ROAD", 
"#20-04 INTERNATIONAL PLAZA", NULL, NULL, "SINGAPORE 079903", NULL, "SGP", NULL, 
"652250939", "RS33191", "652257370", "AMEPS", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(225, 1, "440 S. LASALLE STRRET", 
"20 TH FLOOR", NULL, NULL, "CHICAGO", "IL", "USA", "60605", "3126637930", NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(226, 1, "155 BISHOPSGATE", NULL, NULL, NULL, 
"LONDON EC2N3DA", NULL, "UK", NULL, "01712007000", "94015677", "01712007184", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(227, 1, "50 RAFFLES PLACE", 
"#39-00 SINGAPORE LAND TOWER", NULL, NULL, ".", NULL, "SGP", "048623", 
"652241788", "20879", "652241098", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(228, 1, "133 ENGLE STREET", NULL, NULL, NULL, 
"ENGLEWOOD", "NJ", "USA", "07631", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(229, 1, "1 WESTFERRY CIRCUS", 
" CANARY WHARF", NULL, NULL, "LONDON", NULL, "UK", NULL, "44 171 719 3000", 
"8956681", "44 171 719 5181", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(229, 2, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(229, 3, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, "0031 104033364", NULL, "0031 10 4033483", NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(230, 1, "TWO WORLD FINANCIAL CENTER", 
"27TH FLOOR, LIBERTY ST.", NULL, NULL, "NEW YORK", "NY", "USA", "10281", 
"2124327341", NULL, "2125669414", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(231, 1, "5 SHENTON WAY", 
"#34-04 UIC BUILDING", NULL, NULL, "SINGAPORE 068808", NULL, "SGP", NULL, 
"652201266", "RS 26495", "652211225", "YKSPOR", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(232, 1, "1185 AVENUE OF THE AMERICAS", NULL, 
NULL, NULL, "NEW YORK", "NY", "USA", "10036", "1", "175383", "212-536-8121", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(233, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "XXXX", NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(234, 1, "2 GRAND CENTRAL TOWER", 
"140 EAST 45TH STREET", NULL, NULL, "NEW YORK", "NY", "USA", "10017-3162", 
"2126229773", NULL, "2126221835", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(235, 1, "ESPLANADEN 50", NULL, NULL, NULL, 
"DK-1263 COPENHAGEN K", NULL, "DK", NULL, "33634000", "16260", "33633878", 
"MSKOL DK", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(236, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "214-978-8812", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(237, 1, "85 ST. JOHN STREET", NULL, NULL, 
NULL, "VALETTA", NULL, "M", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(238, 1, "P.O. BOX 1503", NULL, NULL, NULL, 
"FAYETTEVILLE", "AR", "USA", "72702", "5015214494", NULL, "5014436703", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(239, 1, "XXX", NULL, NULL, NULL, "XXX", NULL, 
"GB", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(240, 1, "AVENIDA DEL PARTENON 12", 
"CAMPO DE LAS NACIONES", "28042", NULL, "MADRID", NULL, "E", NULL, 
"(34.1)337.600.0", "47120", "(34.1)337.619.8", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(241, 1, "1001 ADMIRALTY CENTRE TOWER 118", 
"HARCOURT ROAD", NULL, NULL, "HONG KONG", NULL, "HK", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(242, 1, "EAST INDIA HOUSE", 
"109-117  MIDDLESEX STREET", NULL, NULL, "LONDON", NULL, "GB", "E1 7JF", 
"(44.171)375.221", "8812762", "(44.171)454.943", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(243, 1, "391B ORCHARD ROAD #10-03", 
"NGEE ANN CITY TOWER B", NULL, NULL, "SINGAPORE 238874", NULL, "SGP", NULL, 
"658389014", NULL, "658389010", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(244, 1, "8, GALLERIA DE CRISTOFORIS", NULL, 
NULL, NULL, "20122 MILAN", NULL, "I", NULL, "39277371", "311273", "39276020640", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(244, 2, "P.O. BOX 505", "SARROCH", NULL, 
NULL, "09018 CAGLIARI", NULL, "I", NULL, "397090911", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(245, 1, "XXX", NULL, NULL, NULL, "LONDON", 
NULL, "GB", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(246, 1, "19 BERKELEY STREET", NULL, NULL, 
NULL, "LONDON W1X 5AE", NULL, "GB", NULL, "441714080589", "28868", 
"441714938892", "TOSCO G.", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(247, 1, "11B-12B LEANSE PLACE", 
"50 TOWN RANGE", NULL, NULL, "GIBRALTER", NULL, "GBZ", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(248, 1, "55 WAUGH DRIVE", "SUITE 700", NULL, 
NULL, "HOUSTON", "TX", "USA", "77007", "7138698700", "6868905", "7138698069", 
"MCI", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(249, 1, "225 HIGH RIDGE ROAD", NULL, NULL, 
NULL, "STAMFORD", "CT", "USA", "06905", "2039786936", "6819522", NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(250, 1, "WEENA-ZUID 166", NULL, NULL, NULL, 
"3012 NC ROTTERDAM", NULL, "NL", NULL, "31104033400", "23573", "31104033580", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(251, 1, "29, QUAI DES BERGUES", NULL, NULL, 
NULL, "1201 GENEVA", NULL, "CH", NULL, "41229092828", "412046", "41229092820", 
"PRO CH", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(252, 1, "17314 WILLOWBROOK PLACE", 
"SUITE 242", NULL, NULL, "HOUSTON", "TX", "USA", "77064", "7138071511", NULL, 
"7138071406", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(253, 1, "PO BOX 146", "AS TARCONA", 
"MUSTAMEE TEE 59", "10619 TALLINN", "TORTOLA 2) ESTONIA", NULL, "VIU", NULL, 
"003726503532", "173013", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(253, 2, "59 MUSTAMAME", "EE0006", NULL, NULL, 
"TALLINN", NULL, "EST", NULL, "003726503532", "173013", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(254, 1, "200 PUBLIC SQUARE, 5W", NULL, NULL, 
NULL, "CLEVELAND", "OH", "USA", "44114", NULL, "62917760", "2165862403", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(255, 1, "FOUR MILLBANK", NULL, NULL, NULL, 
"LONDON SW1P 3ET", NULL, "GB", NULL, NULL, NULL, "441713165390", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(256, 1, "P.O. BOX 4604", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77210", "7132411563", NULL, "7132468620", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(257, 1, "20TH FLOOR", 
"MENARA DAYABMI KOMPLEKS", "JALAN SULTAN", NULL, "HISHAMUDDIN", NULL, "KL", 
NULL, NULL, "32285 OR 20343", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(258, 1, "XXX", NULL, NULL, NULL, "XXX", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(259, 1, "XXX", NULL, NULL, NULL, "NEW YORK", 
NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(260, 1, "XXX", NULL, NULL, NULL, "NEW YORK", 
NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(261, 1, "XXX", NULL, NULL, NULL, "NEW YORK", 
"NY", "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(262, 1, "CANNON BRIDGE, 25 DOORGATE HILL", 
NULL, NULL, NULL, "LONDON", NULL, "UK", "EC4R 2GN", NULL, NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(263, 1, "49 BERKELEY SQUARE", NULL, NULL, 
NULL, "LONDON", NULL, "USA", "5DB", "44 171 6293164", "915913", 
"44 171 491 2284", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(264, 1, "170 BROADWAY", "SUITE 1700", NULL, 
NULL, "NEW YORK", "NY", "USA", "10038", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(265, 1, "UNKNOWN", NULL, NULL, NULL, 
"LONDON", NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(266, 1, "2 PERRY ROAD", "WILTHAM", NULL, 
NULL, "ESSEX", NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(267, 1, "PASEO DE LA CASTELLANA, 278-280", 
NULL, NULL, NULL, "28046 MADRID", NULL, "E", NULL, "+34 91 348 8178", "44953", 
"313142821", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(268, 1, "1000 LOUISIANA STREET, SUITE 5800", 
NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77002", "713-507-6400", NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(269, 1, "BINNENBANN 33 RHOON", 
"P.O. BOX 1010", "3160 AE", NULL, "RHOON", NULL, "NL", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(270, 1, "VARIOUS", NULL, NULL, NULL, 
"VARIOUS", NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(271, 1, "XXX", NULL, NULL, NULL, "LONDON", 
NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(272, 1, "111 ROWAYTON AVENUE", NULL, NULL, 
NULL, "ROWAYTON", "CT", "USA", "06853", "203-866-4600", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(273, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "65-839-4708", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(274, 1, "4747 BELLAIRE BOULEVARD", NULL, 
NULL, NULL, "BELLAIRE", "TX", "USA", "77401", NULL, NULL, "713-660-4550", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(275, 1, "BAARERMATTSTRASSE 3", 
"P.O. BOX 666", NULL, NULL, "CH-6341 BAAR", NULL, "CH", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(276, 1, "20 LAYAYETTE STREET", NULL, NULL, 
NULL, "CARTERET", "NJ", "USA", "07008", "732-969-5504", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(277, 1, '', NULL, NULL, NULL, "DEFAULT CITY", 
NULL, "USA", NULL, "01646-691266", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(278, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "861068568722", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(279, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(280, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "0171-629-4500", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(281, 1, "9 QUAI PALL DOUMER", 
"92400 COURBEVOIE, LA DEFENCE", "CEDEX", NULL, "92920 PARIS", NULL, "F", NULL, 
NULL, NULL, "33141892979", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(282, 1, "200 SCHULTZ DRIVE", NULL, NULL, 
NULL, "RED BANK", "NJ", "USA", "07701-6745", "732-842-4200", NULL, 
"732-842-5825", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(283, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(284, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(285, 1, "13155 NOEL ROAD", NULL, NULL, NULL, 
"DALLAS", "TX", "USA", "75240-5067", NULL, "150240", "972-715-3184", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(286, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(287, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(288, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(289, 1, "1600 SMITH STREET", "SUITE 1300", 
NULL, NULL, "HOUSTON", "TX", "USA", "77002", "713/652-0716", NULL, 
"713/652-2730", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(290, 1, "6224 NORTHWESTERN", NULL, NULL, 
NULL, "OKLAHOMA CITY", "OK", "USA", "73116", "405/848-8000", NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(291, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(292, 1, "COMPASS HOUSE", "22 REDAN PLACE", 
NULL, NULL, "LONDON", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(293, 1, "140 GREENWICH AVE", NULL, NULL, 
NULL, "GREENWICH", "CT", "USA", "06830", "203/861-7809", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(294, 1, "1221 AVENUE OF THE AMERICAS", NULL, 
NULL, NULL, "NEW YORK", "NY", "USA", "10020", "212/278-5600", "6733817", 
"212/278-5699", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(295, 1, "195 HANOVER STREET", "SUITE 1", 
NULL, NULL, "PORTSMOUTH", "NH", "USA", "03801", "603/431-1000", NULL, 
"603/430-5332", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(296, 1, "DRIEMANSSTEEWEG 88", "3084 CB", 
NULL, NULL, "ROTTERDAM", NULL, "NL", NULL, "(31.10)292.9933", "20024", 
"(31.10)482.9190", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(297, 1, "RIVIUM 1E STRAAT NR. 64", 
"2909 LE CAPELLE A/D", NULL, NULL, "IJSSEL", NULL, "NL", "LE", 
"00 31 10 288 88", "28272", "00 31 10 288 88", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(298, 1, "BAHNHOFSTRASSE 45", NULL, NULL, 
NULL, "8021 ZURICH", NULL, "CH", NULL, "(41.1)234.560.0", NULL, 
"(41.1)234.331.1", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(299, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(300, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(301, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(302, 1, "2929 ALLEN PARKWAY", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77019-2119", "800/877-3636", NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(303, 1, "70 WEST RED OAK LANE", NULL, NULL, 
NULL, "WHITE PLAINS", "NY", "USA", "10604", "914/697-7577", NULL, 
"914/697-7588", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(304, 1, "610 REILLY AVENUE", NULL, NULL, 
NULL, "FARMINGTON", "NM", "USA", "87499", "505/327-9801", NULL, "505/326-5900", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(305, 1, "MOBIL COURT", "3 CLEMENTS INN", 
NULL, NULL, "LONDON", NULL, "UK", "WC2A 2EB", "(44.171)412.255", "8812411", 
"(44.171)412.255", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(306, 1, "18, PIONEER ROAD", NULL, NULL, NULL, 
"SINGAPORE", NULL, "SGP", "628498", "(65)264.335.5", NULL, "(65)264.102.6", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(307, 1, "3225 GALLOWS ROAD", NULL, NULL, 
NULL, "FAIRFAX", "VA", "USA", "22037", "703/846-3000", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(308, 1, "12790 MERIT DRIVE", "SUITE 800", 
NULL, NULL, "DALLAS", "TX", "USA", "75251-1270", "972/450-4761", NULL, 
"972/450-4740", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(309, 1, "BALDERSGATAN 4", NULL, NULL, NULL, 
"GOTHENBURG", NULL, "S", "S-411 02", "463 180 3950", "463  115 9000", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(310, 1, "1000 LOUISIANA", "SUITE 3800", NULL, 
NULL, "HOUSTON", "TX", "USA", "77002", "713/658-9811", NULL, "713/655-6441", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(311, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(312, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(313, 1, "ZUGERSTRASSE 77", "CH-6340", NULL, 
NULL, "BAAR", NULL, "CH", NULL, "(41.41)760.328.", "862125", "(41.41)760.018.", 
"ONYX CH", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(314, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(315, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(316, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(317, 1, "1313 PINHOOK ROAD, SUITE 203B", 
NULL, NULL, NULL, "LAFAYETTE", "LA", "USA", "70503", "318/237-6084", NULL, 
"318/237-3460", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(318, 1, "5051 WESTHEIMER, SUITE 1400", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77056-2124", "713/624-9000", NULL, 
"713/624-9603", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(319, 1, "OLD TOWN ROAD", NULL, NULL, NULL, 
"LAKE CHARLES", "LA", "USA", "70601", "318/436-1000", NULL, "318/436-9602", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(319, 2, "401 EAST DOUGLAS", "SUITE 402", 
NULL, NULL, "WITCHITA", "KS", "USA", "67202", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(320, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(321, 1, "GROENE TUIN 269", "3078 KG", NULL, 
NULL, "ROTTERDAM", NULL, "NL", NULL, "00 31 10 479 49", NULL, "00 31 10 482 00", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(322, 1, "DEFAULT", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(323, 1, "100 NORTH BROADWAY", 
"SUITE 2500 LIBERTY TOWER", NULL, NULL, "OKLAHOMA CITY", "OK", "USA", "73102", 
"405/239-7191", NULL, "405/232-1815", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(324, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(325, 1, "570 LENNON LANE", "SUITE N2000", 
NULL, NULL, "WALNUT CREEK", "CA", "USA", "94598", "510/944-8222", NULL, 
"510/944-8288", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(326, 1, "9 D13 ADAMS BUILDING", NULL, NULL, 
NULL, "BARTLESVILLE", "OK", "USA", "74004", "918/661-6600", "796289", 
"918/662-2112", "PHILLIPS BRV", "BORGER/SWEEENY", "A", NULL, NULL, 1)
go

insert into account_address values(327, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(328, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(329, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(330, 1, "1185 AVENUE OF THE AMERICAS", NULL, 
NULL, NULL, "NEW YORK", "NY", "USA", "10036", "212/997-8500", "82935", 
"212/536-8396", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(331, 1, "430 PARK AVENUE", "7TH FLOOR", NULL, 
NULL, "NEW YORK", "NY", "USA", "10022", "212/702-8602", NULL, "212/702-8633", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(332, 1, "THE EQUITABLE TOWERS", 
"787 7TH AVENUE, 30TH FLOOR", NULL, NULL, "NEW YORK", "NY", "USA", "10019", 
"212/841-2000", "82982", "212/8412041", "PARIBAS", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(333, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(334, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(335, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(336, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(337, 1, "11 MADISON AVENUE", NULL, NULL, 
NULL, "NEW YORK", "NY", "USA", "10010", "212/325-5900", NULL, "812/838-8196", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(338, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(339, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(340, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(341, 1, "COMPASS HOUSE", "22 REDAN PLACE", 
NULL, NULL, "LONDON", NULL, "UK", "4SA", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(342, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(343, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(344, 1, "6 BROADGATE", NULL, NULL, NULL, 
"LONDON", NULL, "GB", "ECM2 2AA", "(44.171)628.555", "8954381", 
"(44.171)782.914", "BISHFI G", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(345, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(346, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(347, 1, "NO ADDRESS", NULL, NULL, NULL, 
"NO CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(348, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(349, 1, "200 WESTLAKE PARK BOULEVARD", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77210-4518", "281/560-4250", "774362", 
"281/560-8825", "BP TEXAS HOU A", "REGIONAL MGR.", "A", NULL, NULL, 1)
go

insert into account_address values(350, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(351, 1, "NO., ONE, DOVER STREET", 
"CALDER HOUSE, 3RD FLOOR", NULL, NULL, "LONDON", NULL, "UK", "W1X 8HF", NULL, 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(352, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(353, 1, "UNKNOWN", NULL, NULL, NULL, 
"UNKNOWN", NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(354, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(355, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(356, 1, "2 ELECTRA ROAD", "MAYDOWN", NULL, 
NULL, "LONDONDERRY", NULL, "UK", "BT47 1UL", "+44 1504 860351", "NONE", 
"+44 1504 860745", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(357, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(358, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(359, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(360, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(361, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(362, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(363, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(364, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(365, 1, "LISCARTAN HOUSE", 
"127 SLOANE STREET", NULL, NULL, "LONDON", NULL, "UK", "SW1X 9BA", 
"0171 823 5500", "921441/2", "0171 823 5556", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(366, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(367, 1, "UNKNOWN", NULL, NULL, NULL, 
"GOTHENBURG", NULL, "S", NULL, NULL, "27808", NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(368, 1, "1 WORLD FINACIAL CTR", "TOWER A", 
"22ND FLOOR", "200 LIBERTY STREET", "NEW YORK", "NY", "USA", "10281", 
"(212)978-2325", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(369, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(370, 1, "ADDRESS", NULL, NULL, NULL, "CITY", 
NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(371, 1, "ADDRESS", NULL, NULL, NULL, "CITY", 
NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(372, 1, "ADDRESS", NULL, NULL, NULL, "CITY", 
NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(373, 1, "UNKNOWN", NULL, NULL, NULL, 
"UNKNOWN", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(374, 1, "UNKNOWN", NULL, NULL, NULL, 
"UNKNOWN", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(375, 1, "BUITENWALEVEST 4", "PO BOX 170", 
"3300 AD", NULL, "DORDRECHT", NULL, "NL", NULL, "00 31 78 648 56", NULL, 
"00 31 78 613 88", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(376, 1, "STATOIL HOUSE", "11 REGENT STREET", 
NULL, NULL, "LONDON", NULL, "UK", "SW1Y 4ST", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(377, 1, "UNKNOWN", NULL, NULL, NULL, 
"UNKNOWN", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(378, 1, "UNKNOWN", NULL, NULL, NULL, 
"UNKNOWN", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(379, 1, "X", "X", NULL, NULL, "X", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(380, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(381, 1, "6 DOM DU COLOMBIER", 
"ALLEE DES OLIVIERS", "06480 LA COLLE SUR LOUP", NULL, "DEFAULT CITY", NULL, 
"F", NULL, "33 493 323 535", "970119", "33 493 325 275", NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(382, 1, "X", NULL, NULL, NULL, "X", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(383, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(384, 1, "CLARENDON HOUSE", 
"CHURCH STREET WEST", NULL, NULL, "HAMILTON 5-31", NULL, "UK", NULL, NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(385, 1, "BAHNHOFSTRASSE 16", NULL, NULL, 
NULL, "ZUG", NULL, "CH", "CH-6300", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(386, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(387, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(388, 1, "ZANDERSTRASSE 5", NULL, NULL, NULL, 
"BONN", NULL, "BRD", "53177", "0049228844189", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(389, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(390, 1, "3197 KJ BOTLEK RT", "PO BOX 5010", 
"3197 XC BOTLEK RT", NULL, "DEFAULT CITY", NULL, "USA", NULL, "31 102 953 9400", 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(391, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(392, 1, "128, BOULEVARD HAUSMAN", NULL, NULL, 
NULL, "75008 PARIS", NULL, "F", NULL, "33 14 387 4314", NULL, "33 14 394 0281", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(393, 1, "4111 E. 37TH STREET N.", 
"P.O. BOX 2256", NULL, NULL, "WICHITA", "KS", "USA", "67201-225", NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(394, 1, "2 GREGORIS AFXENTIOU AV", 
"AKAMIA CENTER, OFFICE", NULL, NULL, "LARNACA", NULL, "CY", NULL, 
"003574664930", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(395, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(396, 1, "5-6 PALL MALL EAST", NULL, NULL, 
NULL, "LONDON", NULL, "UK", NULL, "01718394271", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(397, 1, "MAX EUWELAAN 51", "3062 MA", NULL, 
NULL, "ROTTERDAM", NULL, "NL", NULL, "31 10 453 2266", "21553", 
"31 10 452 8393", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(398, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(399, 1, "PETRINJSKA 2", "10000 ZAGREB", NULL, 
NULL, "X", NULL, "USA", NULL, "481", "1508", "481", NULL, "1509", "A", NULL, 
NULL, 1)
go

insert into account_address values(400, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "?", NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(401, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(402, 1, "KEILANIEMI", "P.O. BOX 20", NULL, 
NULL, "KEILANIEMI", NULL, "UK", "SF-02151 E", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(403, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(404, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(405, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(406, 1, "?", NULL, NULL, NULL, "?", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(407, 1, "FIRST FLOOR , 4 GROSVENOR PLACE", 
NULL, NULL, NULL, "LONDON", NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(408, 1, "BUNDESSTRASSE 5", NULL, NULL, NULL, 
"ZUG CH-6300", NULL, "CH", NULL, "042230855", NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(409, 1, '', NULL, NULL, NULL, '', NULL, "USA", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(410, 1, "1 BROADGATE", NULL, NULL, NULL, 
"LONDON", NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(411, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(412, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(413, 1, "123 ROBERT S. KERR AVENUE", NULL, 
NULL, NULL, "OKLAHOMA CITY", "OK", "USA", "73102", NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(414, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(415, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(416, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(417, 1, "17 CONNAUGHT PLACE", NULL, NULL, 
NULL, "LONDON W2  2EL", NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(418, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(419, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(420, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(421, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(422, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(423, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(424, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(425, 1, "POSTBUS 253", "3230 AG", NULL, NULL, 
"BRIELLE", NULL, "NL", NULL, "31181414000", "29925", "31181410411", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(426, 1, '', NULL, NULL, NULL, '', NULL, "USA", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(427, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(428, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(429, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(430, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(431, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(432, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(433, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(434, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(435, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(436, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(437, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(438, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(439, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(440, 1, "CALTEX HOUSE", "30 RAFFLES PLACE", 
"#25-30, SINGAPORE 046822", NULL, "DEFAULT CITY", NULL, "USA", NULL, 
"65239499259", "RS  21207", "65 439 1791", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(441, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(442, 1, '', NULL, NULL, NULL, '', NULL, "USA", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(443, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(444, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(445, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(446, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(447, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(448, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "011-41223629649", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(449, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "01719309866", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(450, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(451, 1, '', NULL, NULL, NULL, '', NULL, "USA", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(452, 1, "1608 CITICORP CENTRE", 
"18 WHITFIELD ROAD", "CAUSEWAY BAY", "HONG KONG", '', NULL, "HK", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(453, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(454, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(455, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(456, 1, '', NULL, NULL, NULL, " M", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(457, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(458, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(459, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(460, 1, "CONTRACTS", "DEPARTMENT", NULL, 
NULL, "GENEVA", NULL, "CH", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(461, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(462, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "312-606-4140", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(463, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(464, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(465, 1, "PO BOX 1188", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77251/1188", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(466, 1, "XXXXXX", NULL, NULL, NULL, "XXXXXX", 
NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(467, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(468, 1, "DE RUYTERSTRAAT 1-11", NULL, NULL, 
NULL, "ROTTERDAM", NULL, "NL", "PH", "31 10 217 1600", "28087", 
"31 10 412 2464", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(469, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(470, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(471, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "XXX", NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(472, 1, "VIA SANTA MARTA. 25 -20123", NULL, 
NULL, NULL, "MILANO", NULL, "I", NULL, "39 02 864 53914", "353084", 
"39 02 864 53909", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(473, 1, "TWO STAMFORD LANDING", NULL, NULL, 
NULL, "STAMFORD", "CT", "USA", "06902", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(474, 1, "HOFPLEIN 33", "9TH FLOOR", 
"3011 AJ", NULL, "ROTTERDAM", NULL, "NL", NULL, NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(475, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(476, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "XXX", NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(477, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(478, 1, """ROCKWOOD"" CROSSWAYS", 
"WEST CHILTINGTON", NULL, NULL, "WEST SUSSEX", NULL, "UK", "2QY", 
"011441714909615", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(479, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(480, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(481, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(482, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(483, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(484, 1, "ROEIERSPAD 6", "POSTBUS 639", 
"3195 ZG", NULL, "PERNIS", NULL, "NL", NULL, "00 31 10 416 43", NULL, 
"00 31 10 416 53", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(485, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(486, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(487, 1, "DIRECCAO DE COMBUSTIVEIS", 
"AV. BARBOSA DU BOCAGE, 45 - 3", "1000 - 071", NULL, "LISBON", NULL, "P", NULL, 
"00 351  1 352 5", "040462077", "00 351 1 799 24", NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(488, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(489, 1, "GLASHAVEN 49", "3011 XG", NULL, 
NULL, "ROTTERDAM", NULL, "NL", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(490, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(491, 1, "AMSTERDAMSTRAAT 30", NULL, NULL, 
NULL, "ANTWERP", NULL, "B", NULL, "32 3 232 3910", "32267", "32 3 232 5647", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(492, 1, "SUITE 801", 
"8TH FLOOR, CHINACHEM CENTURY TOWER", "178 GLOUCESTER ROAD", "WANCHAI", 
"HONG KONG", NULL, "USA", NULL, "852 2891 0882", "K24418", "852 2891 4882", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(493, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(494, 1, "DEFAULT", NULL, NULL, NULL, 
"NEW YORK", "NY", "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(495, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(496, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(497, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(498, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(499, 1, "ADDRESS", NULL, NULL, NULL, "CITY", 
NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(500, 1, "ADDRESS", NULL, NULL, NULL, "CITY", 
NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(501, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(502, 1, "1608 CITICORP CENTRE", 
"18 WHITFIELD ROAD", "CAUSEWAY BAY", NULL, "HONG KONG", NULL, "HK", NULL, 
"00852-25080228", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(503, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(504, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(505, 1, "2ND FLOOR,", 
"SIR WALTER RALEIGH HOUSE", "48-50 THE ESPLANADE,", NULL, "ST. HELIER", NULL, 
"GBJ", "JE2 3QB", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(506, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(507, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(508, 1, "8 TEMASEK BOULEVARD", 
"# 27-01  SUNTEC TOWER 3", NULL, NULL, "SINGAPORE", NULL, "SGP", "038988", 
"011-65-333-6233", NULL, "011-65-333-6123", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(509, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "171 499 8585", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(510, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(511, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(512, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(513, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(514, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(515, 1, "ADDRESS", NULL, NULL, NULL, "CITY", 
NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(516, 1, "BREDABAAN 103", "2930", NULL, NULL, 
"BRASSCHAAT", NULL, "B", NULL, "00 32 3 652 060", "34697", "00 32 3 652 142", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(517, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(518, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(519, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(520, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "205-391-3503", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(521, 1, "1616 SOUTH BOSS ROAD", "SUITE 555", 
NULL, NULL, "HOUSTON", "TX", "USA", "77057", "713-507-5703", NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(522, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(523, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(524, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(525, 1, "58 COMMERCE DRIVE", NULL, NULL, 
NULL, "STAMFORD", "CT", "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(526, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, " 01252741421", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(527, 1, '', NULL, NULL, NULL, '', NULL, "UK", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(528, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(529, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(530, 1, "FRANKRIJKLEI 37", "BUS 5", NULL, 
NULL, "ANTWERP", NULL, "B", NULL, "32 3 232 0218", NULL, "32 3 226 0075", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(531, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(532, 1, '', NULL, NULL, NULL, '', NULL, "USA", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(533, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(534, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(535, 1, '', NULL, NULL, NULL, '', NULL, "USA", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(536, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(537, 1, '', NULL, NULL, NULL, '', NULL, "USA", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(538, 1, "PO BOX 9 BISHOPS WALTHAM", NULL, 
NULL, NULL, "SOUTHAMPTON", NULL, "UK", "1ZR", "01489-86909", NULL, "94083116", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(539, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(540, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(541, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(542, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(543, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(544, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(545, 1, "TEST", NULL, NULL, NULL, "TEST", 
"CT", "USA", "06905", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(546, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(547, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(548, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(549, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(550, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(551, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(552, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(553, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(554, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(555, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(556, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(557, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(558, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(559, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(560, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(561, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(562, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(563, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(564, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(565, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(566, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(567, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(568, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(569, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(570, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(571, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(572, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(573, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(574, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(575, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(576, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(577, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(578, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(579, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(580, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(581, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(582, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(583, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(584, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(585, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(586, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(587, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(588, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(589, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(590, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(591, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(592, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(593, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(594, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(595, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(596, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(597, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(598, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(599, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(600, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(601, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, "USA", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(602, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(603, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(604, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(605, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(606, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(607, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(608, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(609, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(610, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(611, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(612, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(613, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(614, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(615, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(616, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(617, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(618, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(619, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(620, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(621, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(622, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(623, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(624, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(625, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(626, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(627, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(628, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(629, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(630, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(631, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(632, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(633, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(634, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(635, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(636, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(637, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(638, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(639, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(640, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(641, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(642, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(643, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(644, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(645, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(646, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(647, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(648, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(649, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(650, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(651, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(652, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(653, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(654, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(655, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(656, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(657, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(658, 1, "N", NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(659, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(660, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(661, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(662, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(663, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(664, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(665, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(666, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(667, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(668, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(669, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(670, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(671, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(672, 1, "BP MARINE", "HOOGWERFSINGEL 2", 
"6TH FLOOR", "PO BOX 13", "SPIJKENISSE", NULL, "NL", "AA", "31 181 60 2035", 
NULL, "31 181 62 1347", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(673, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(674, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(675, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(676, 1, '', NULL, NULL, NULL, '', NULL, "UK", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(677, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(678, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(679, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(680, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(681, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(682, 1, '', NULL, NULL, NULL, '', NULL, "UK", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(683, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(684, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(685, 1, "100 EAST OLD COUNTRY ROAD", NULL, 
NULL, NULL, "HICKSVILLE", "NY", "USA", "11801", "516 545 6068", NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(686, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(687, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(688, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(689, 1, '', NULL, NULL, NULL, '', NULL, "UK", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(690, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(691, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(692, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(693, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(694, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(695, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(696, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(697, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(698, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(699, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(700, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(701, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(702, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(703, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(704, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(705, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(706, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(707, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(708, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(709, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(710, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(711, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(712, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(713, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(714, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(715, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(716, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(717, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(718, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(719, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(720, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(721, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(722, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(723, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(724, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(725, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(726, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(727, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(728, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(729, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(730, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(731, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(732, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(733, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(734, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(735, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(736, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(737, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(738, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(739, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(740, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(741, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(742, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(743, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(744, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(745, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(746, 1, "B", NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(747, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(748, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(749, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(750, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(751, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(752, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(753, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(754, 1, '', NULL, NULL, " B", '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(755, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(756, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(757, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(758, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(759, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(760, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(761, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(762, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(763, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(764, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(765, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(766, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(767, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(768, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(769, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(770, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(771, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(772, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(773, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(774, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(775, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(776, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(777, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(778, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(779, 1, "-", NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(780, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(781, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(782, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(783, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(784, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(785, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(786, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(787, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(788, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(789, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(790, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(791, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(792, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(793, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(794, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(795, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(796, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(797, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(798, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(799, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(800, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(801, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(802, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(803, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(804, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(805, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(806, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(807, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(808, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(809, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(810, 1, "ATTN: MANAGER, LNG SERVICES", 
"5444 WESTHEIMER", NULL, NULL, "HOUSTON", "TX", "USA", "77056-5306", NULL, NULL, 
"713 989-1177", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(811, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(812, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(813, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(814, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(815, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(816, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(817, 1, " N", NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(818, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(819, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(820, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(821, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(822, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(823, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(824, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(825, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(826, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(827, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(828, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(829, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(830, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(831, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(832, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(833, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(834, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(835, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(836, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(837, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(838, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(839, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(840, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(841, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(842, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(843, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(844, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(845, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(846, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(847, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(848, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(849, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(850, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(851, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(852, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(853, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(854, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(855, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(856, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(857, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(858, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(859, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(860, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(861, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(862, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(863, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(864, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(865, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(866, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(867, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(868, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(869, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(870, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(871, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(872, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(873, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(874, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(875, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(876, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(877, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(878, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(879, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(880, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(881, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(882, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(883, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(884, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(885, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(886, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(887, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(888, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(889, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(890, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(891, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(892, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(893, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(894, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(895, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(896, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(897, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(898, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(899, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(900, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(901, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(902, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(903, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(904, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(905, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(906, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(907, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(908, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(909, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(910, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(911, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(912, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(913, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(914, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(915, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(916, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(917, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(918, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(919, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(920, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(921, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(922, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(923, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(924, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(925, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(926, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(927, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(928, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(929, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(930, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(931, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(932, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(933, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(934, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(935, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(936, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(937, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(938, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(939, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(940, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(941, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(942, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(943, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(944, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(945, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(946, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(947, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(948, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(949, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(950, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(951, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(952, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(953, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(954, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(955, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(956, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(957, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(958, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(959, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(960, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(961, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(962, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(963, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(964, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(965, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(966, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(967, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(968, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(969, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(970, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(971, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(972, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(973, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(974, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(975, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(976, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(977, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(978, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(979, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(980, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(981, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(982, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(983, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(984, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(985, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(986, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(987, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(988, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(989, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(990, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(991, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(992, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(993, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(994, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(995, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(996, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(997, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(998, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(999, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1000, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1001, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1002, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1003, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1004, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1005, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1006, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1007, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1008, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1009, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1010, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1011, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1012, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1013, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1014, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1015, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1016, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1017, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1018, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1019, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1020, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1021, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1022, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1023, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1024, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1025, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1026, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1027, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1028, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1029, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1030, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1031, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1032, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1033, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1034, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1035, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1036, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1037, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1038, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1039, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1040, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1041, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1042, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1043, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1044, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1045, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1046, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1047, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1048, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1049, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1050, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1051, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1052, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1053, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1054, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1055, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1056, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1057, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1058, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1059, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1060, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1061, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1062, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1063, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1064, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1065, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1066, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1067, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1068, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1069, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1070, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1071, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1072, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1073, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1074, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1075, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1076, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1077, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1078, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1079, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1080, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1081, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1082, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1083, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1084, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1085, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1086, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1087, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1088, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1089, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1090, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1091, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1092, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1093, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1094, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1095, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1096, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1097, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1098, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1099, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1100, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1101, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1102, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1103, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1104, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1105, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1106, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1107, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1108, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1109, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1110, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1111, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1112, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1113, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1114, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1115, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1116, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1117, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1118, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1119, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1120, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1121, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1122, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1123, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1124, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1125, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1126, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1127, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1128, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1129, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1130, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1131, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1132, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1133, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1134, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1135, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1136, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1137, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1138, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1139, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1140, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1141, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1142, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1143, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1144, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1145, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1146, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1147, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1148, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1149, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1150, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1151, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1152, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1153, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1154, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1155, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1156, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1157, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1158, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1159, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1160, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1161, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1162, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1163, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1164, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1165, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1166, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1167, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1168, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1169, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1170, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1171, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1172, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1173, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1174, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1175, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1176, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1177, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1178, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1179, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1180, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1181, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1182, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1183, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1184, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1185, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1186, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1187, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1188, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1189, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1190, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1191, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1192, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1193, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1194, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1195, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1196, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1197, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1198, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1199, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1200, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1201, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1202, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1203, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1204, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1205, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1206, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1207, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1208, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1209, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1210, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1211, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1212, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1213, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1214, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1215, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1216, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1217, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1218, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1219, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1220, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1221, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1222, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1223, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1224, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1225, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1226, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1227, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1228, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1229, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1230, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1231, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1232, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1233, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1234, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1235, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1236, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1237, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1238, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1239, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1240, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1241, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1242, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1243, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1244, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1245, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1246, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1247, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1248, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1249, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1250, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1251, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1252, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1253, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1254, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1255, 1, "28 GLATEGNY ESPLANADE", 
"ST PETER PORT GUERNSEY, CH ISLANDS", NULL, NULL, "GENEVA", NULL, "CH", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1256, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1257, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1258, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1259, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1260, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1261, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1262, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1263, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1264, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1265, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1266, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1267, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1268, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1269, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1270, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1271, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1272, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1273, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1274, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1275, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, "Q", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1276, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1277, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1278, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1279, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1280, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1281, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1282, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1283, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1284, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1285, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1286, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1287, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1288, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1289, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1290, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1291, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1292, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1293, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1294, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1295, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1296, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1297, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1298, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1299, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1300, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1301, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1302, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1303, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1304, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1305, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1306, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1307, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1308, 1, '', NULL, NULL, NULL, " N", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1309, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1310, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1311, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1312, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1313, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1314, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1315, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1316, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1317, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1318, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1319, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1320, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1321, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1322, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1323, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1324, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1325, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1326, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1327, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1328, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1329, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1330, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1331, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1332, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1333, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1334, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1335, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1336, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1337, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1338, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1339, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1340, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1341, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1342, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1343, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1344, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1345, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1346, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1347, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1348, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1349, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1350, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1351, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1352, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1353, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1354, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1355, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1356, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1357, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1358, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1359, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1360, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1361, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1362, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1363, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1364, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1365, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1366, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1367, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1368, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1369, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1370, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1371, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1372, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1373, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1374, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1375, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1376, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1377, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1378, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1379, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1380, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1381, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1382, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1383, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1384, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1385, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1386, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1387, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1388, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1389, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1390, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", "USA", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1391, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1392, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1393, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1394, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1395, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1396, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1397, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1398, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1399, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1400, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1401, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1402, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1403, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1404, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1405, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1406, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1407, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1408, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1409, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1410, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1411, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1412, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1413, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1414, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1415, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1416, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1417, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1418, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1419, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1420, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1421, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1422, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1423, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1424, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1425, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1426, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1427, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1428, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1429, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1430, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1431, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1432, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1433, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1434, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1435, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1436, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1437, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1438, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1439, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1440, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1441, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1442, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1443, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1444, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1445, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1446, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1447, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1448, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1449, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1450, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1451, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1452, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1453, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1454, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1455, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1456, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1457, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1458, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1459, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1460, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1461, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1462, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1463, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1464, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1465, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1466, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1467, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1468, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1469, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1470, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1471, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1472, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1473, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1474, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1475, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1476, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1477, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1478, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1479, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1480, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1481, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1482, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1483, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1484, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1485, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1486, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1487, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1488, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1489, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1490, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1491, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1492, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1493, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1494, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1495, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1496, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1497, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1498, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1499, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1500, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1501, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1502, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1503, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1504, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1505, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1506, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1507, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1508, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1509, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1510, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1511, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1512, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1513, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1514, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1515, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1516, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1517, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1518, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1519, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1520, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1521, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1522, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1523, 1, "321 ST. CHARLES AVENUE", NULL, 
NULL, NULL, "NEW ORLEANS", "LA", "USA", "70130", "5045868300", NULL, 
"5045259537", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1524, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1525, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1526, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1527, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1528, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1529, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1530, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1531, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1532, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1533, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1534, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1535, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1536, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1537, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1538, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1539, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1540, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1541, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1542, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1543, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1544, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1545, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1546, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1547, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1548, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1549, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1550, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1551, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1552, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1553, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1554, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1555, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1556, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1557, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1558, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1559, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1560, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1561, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1562, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1563, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1564, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1565, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1566, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1567, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1568, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1569, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1570, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1571, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1572, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1573, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1574, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1575, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1576, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1577, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1578, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1579, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1580, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1581, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1582, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1583, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1584, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1585, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1586, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1587, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1588, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1589, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1590, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1591, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1592, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1593, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1594, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1595, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1596, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1597, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1598, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1599, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1600, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1601, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1602, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1603, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1604, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1605, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1606, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1607, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1608, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1609, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1610, 1, "DEUTSCHE CARGILL GMBH", 
"RUEDEKEB STRASSE", "51/AM HAFEN", NULL, "SALZIGTTER BEDDINGEN", NULL, "BRD", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1611, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "-", NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(1612, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1613, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1614, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1615, 1, "WESTERKADE 22", NULL, NULL, NULL, 
"ROTTERDAM", NULL, "NL", "3016", "+31104369600", "26445", "+314369444", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1616, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1617, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1618, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1619, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1620, 1, "UNKNOWN", "UNKNOWN", "UNKNOWN", 
NULL, "NAPLES", NULL, "I", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(1621, 1, "UNKNOWN", "UNKNOWN", "UNKNOWN", 
NULL, "VALETTA", NULL, "M", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(1622, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1623, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1624, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1625, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1626, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1627, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1628, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1629, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1630, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1631, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1632, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1633, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1634, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1635, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1636, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1637, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1638, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1639, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1640, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1641, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1642, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1643, 1, "PLANTINKAAI 13", "2000 ANTWERP", 
NULL, NULL, '', NULL, "B", NULL, "32 3232 5234", "71409", "32 3233 6745", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1644, 1, "WEENA-ZUID 166", "PO BOX 735", 
"3000 AS ROTTERDAM", NULL, "ROTTERDAM", NULL, "NL", NULL, "31 10 40 33 500", 
NULL, "31 10 40 33 483", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1645, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1646, 1, "RIJSDIJK 13", "3161 KH RHOON", 
"PO BOX 803", "3160 AA RHOON", '', NULL, "NL", NULL, "31 10 501 8955", NULL, 
"31 10 501 3400", NULL, "31 10 501 2800", "A", NULL, NULL, 1)
go

insert into account_address values(1647, 1, "2ND FLOOR", "SOUTHERN HOUSE", 
"FLAMBARD WAY", "GODALMING", "SURREY", NULL, "UK", "1HH", "44 148 386 0900", 
"858003", "44 148 342 2066", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1648, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1649, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1650, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1651, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1652, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1653, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1654, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1655, 1, "WILLIS COROON MARINE", 
"NORTH AMERICA", "7 HANOVER SQUARE", NULL, "NEW YORK", "NY", "USA", "10042594", 
"212-820-7518", NULL, "212-635-3626", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1656, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1657, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1658, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1659, 1, "6-A HUIXIN EAST STREET", 
"CHAOYAND DIRTRICT", NULL, NULL, "BEJING", NULL, "PRC", "100029", NULL, NULL, 
"86 106522-3817", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1660, 1, "NIJVERHEIDSTRAAT 16-20", 
"3071 GD ROTTERDAM", NULL, NULL, "POSTBUS", NULL, "NL", NULL, "31 10 485 0350", 
NULL, "31 10 485 8935", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1661, 1, "IMMINGHAM DOCK", "IMMINGHAM", 
"NE LINCOLNSHIRE", NULL, '', NULL, "UK", "2NU", "44 1469 571387", "52186", 
"4 1469 571023", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1662, 1, "PLASA SMEETS 6", 
"NETHERLANDS ANTILLES", NULL, NULL, '', NULL, "NL", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1663, 1, "THE WHITE HOUSE", 
"S-167 51 BROMMA", NULL, NULL, '', NULL, "S", NULL, "46 8 704 7000", 
"113 50 NAVITA S", "46 8 704 7010", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1664, 1, "LUISENSTRASSE 5", 
"26382 WILHELSHAVEN", NULL, NULL, '', NULL, "S", NULL, NULL, "25 33 25 AGENT", 
"49 442 120 1062", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1665, 1, "1 UL SVOBODY NOVOROSSIYSK", 
"353900 RUSSIAN FEDERATION", "NOVOSHIP SWEDEN AB", "POSITIONEN 137", 
"STOCKHOLM", NULL, "S", "74", "7 8617 291664", "279113", "7 8617 291993", 
"279133", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1666, 1, "DEPT 0777", "PO BOX 12001", NULL, 
NULL, "DALLAS, TX", NULL, "USA", "0777", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1667, 1, "GASVAERKSVEJ 48", 
"DK-9000 AALBORG", NULL, NULL, "DEFAULT CITY", NULL, "DK", NULL, "45.98.127277", 
"69851 OWOIL DK", "45 98 16 7277", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1668, 1, "RUA GUSTAVO MATOS SEQUEIRA", 
"NO 58-1 DTO", "1250 LISBOA", NULL, "LISBON", NULL, "P", NULL, "351 1 396 7321", 
"14789 EMPOS P", "351 1 396 1699", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1669, 1, "OUDE LEEUWEN RUI 23", 
"2000 ANTWERPEN", NULL, NULL, '', NULL, "B", NULL, "32 3 544 8417", NULL, 
"32 3 544 8418", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1670, 1, "PLASA SMEETS 6", "WILLEMSTAD", 
NULL, NULL, "CURACAO", NULL, "NL", NULL, "599 9 869 2312", "384 1068", 
"599 9 869 7885", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1671, 1, "3RD FLOOR PU OK BUILDING", 
"648-18 YOKSAM-DONG", "KANGNAM-GU", NULL, "SEOUL", NULL, "KOR", NULL, 
"82 2 565 8981", "K24418", "82 2 565 8988", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1672, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1673, 1, '', NULL, NULL, NULL, "MARIHAMN", 
NULL, "SF", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1674, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1675, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1676, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1677, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1678, 1, " RM 502 5/F NEWS BUILDING", 
"189-200 GLOUCESTER ROAD", "-", NULL, "WINCHAI", NULL, "HK", NULL, "2520-1680", 
"87786 GAX HX", "2804-1879", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1679, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1680, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1681, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1682, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1683, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1684, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1685, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1686, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1687, 1, "AUSIN FRIARS HOUSE", 
"2-6 AUSIN FRIARS", NULL, NULL, "LONDON", NULL, "UK", "2HD", NULL, NULL, 
"0171 638 4019", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1688, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1689, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1690, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1691, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1692, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1693, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1694, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1695, 1, '', NULL, NULL, NULL, '', NULL, 
"UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1696, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1697, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1698, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1699, 1, "10 ANSON ROAD", 
"#14-01 INTERNATIONAL PLAZA", NULL, NULL, "SINGAPORE", NULL, "SGP", "079903", 
"0065 2250290", "20104 CAESPL", "0065 3245166", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1700, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1701, 1, "1ST FLOOR", "6 DEANERY STREET", 
NULL, NULL, "LONDON", NULL, "UK", "5LH", "+44 171 2903580", "925055", 
"44 171 499 2912", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1702, 1, "5 ALDFORD STREET", NULL, NULL, 
NULL, "LONDON", NULL, "UK", "5PS", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1703, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1704, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1705, 1, 
"111 SP. ARAOUZOU STR., PO BOX 50127", NULL, NULL, NULL, "LIMASSOL", NULL, "GR", 
NULL, NULL, "1261711", "126712", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1706, 1, '', NULL, NULL, NULL, '', NULL, 
"HK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1707, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1708, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1709, 1, "C/O MIDLAND BANK", 
"PO BOX 80461, GR-18538", "93 AKTI MIAOULI", NULL, "PIRAEUS", NULL, "GR", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1710, 1, "STORA BADHUSGATAN 18-20", NULL, 
NULL, NULL, "GOTHENBURG", NULL, "S", NULL, "46 31 102330", "46 31 102339", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1711, 1, "C/O NORDBANKEN GOTHENBURG", NULL, 
NULL, NULL, "GOTHENBURG", NULL, "S", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1712, 1, "WIELDRECHTSEWEG 50", "PO BOX 150", 
NULL, NULL, "DORDRECHT", NULL, "NL", NULL, "31 78 652 8500", "28726", 
"31 78 618 0660", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1713, 1, "OSTERGADE 60, 4", NULL, NULL, NULL, 
'', NULL, "DK", NULL, "45 331 53600", NULL, "45 331 53648", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1714, 1, " NOORDZEE 2C", NULL, NULL, NULL, 
"MAASLUIS ROTTERDAM", NULL, "NL", NULL, "31 10 592 8200", NULL, 
"31 10 592 8310", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1715, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1716, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1717, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1718, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1719, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "+31 181 240235", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1720, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1721, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1722, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1723, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1724, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1725, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "0", NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(1726, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1727, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1728, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1729, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "+31 181 240210", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1730, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1731, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1732, 1, "3700 BUFFALO SPEEDWAY, SUITE 1000", 
NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77098-3705", "713-871-2200", NULL, 
"713-235 1992", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1733, 1, "6TH FLOOR", "35/38 PORTMAN SQUARE", 
NULL, NULL, "LONDON", NULL, "UK", "9FH", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1734, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1735, 1, "COURTRIGHT PLANT", 
"MOORE-SOMBRA TOWN LINE", "PO BOX 1900", "COURTRIGHT", "ONTARIO", NULL, "CDN", 
NULL, "519-867-2739X13", NULL, "519-867-3128", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1736, 1, "101 NORTH LATHROP AVENUE", NULL, 
NULL, NULL, "SAVANNAH", "GA", "USA", "31415", "912-236-1331", NULL, 
"912-235-3881", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1737, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1738, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1739, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "31 10 2953 400", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1740, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1741, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1742, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1743, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1744, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1745, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1746, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1747, 1, "PO BOX 1173", NULL, NULL, NULL, 
"TWINSBURG", "OH", "USA", "44087", "888 427-2661", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1748, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1749, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1750, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1751, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1752, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1753, 1, "ADDRESS", NULL, NULL, NULL, "CITY", 
NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1754, 1, 
"C/O/ ORION POWER MARKETING AND SUPPLY IN", "7 EAST REDWOOD STREET 10TH FLOOR", 
NULL, NULL, "BALTIMORE", "MD", "USA", "21202", NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1755, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1756, 1, "14/15 PHILPOT LANE", NULL, NULL, 
NULL, "LONDON", NULL, "UK", "8AJ", "44 171 929 6060", "8811698", 
"44 171 929 3748", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1757, 1, "VIKTORIAPLATZ 2", "3000 BERN 25", 
NULL, NULL, '', NULL, "CH", NULL, "41 31 332 5422", NULL, "41 31 330 5635", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1758, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1759, 1, "SPUI 8", NULL, NULL, NULL, "RHOON", 
NULL, "NL", "ED", "31 10 501 9162", "20161", "31 10 501 9980", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1760, 1, "47 OVERGANG", NULL, NULL, NULL, 
"BRIXHAM", NULL, "UK", "TQ5 8AR", "44 1803 882214", "42737", "44 1803 882579", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1761, 1, "STREVELSWEG 700/601-605", NULL, 
NULL, NULL, "ROTTERDAM", NULL, "NL", NULL, "31 10 293 8600", "28314", 
"31 10 293 8611", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1762, 1, "FAIRHAM HOUSE", "GREEN LANE", NULL, 
NULL, "CLIFTON", NULL, "UK", "NG119LN", "44 115 977 6000", NULL, 
"44 115 945 6944", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1763, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1764, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1765, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1766, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1767, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1768, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1769, 1, "1717 STEPHENSON  HIGHWAY", NULL, 
NULL, NULL, "TROY", "MI", "USA", "48083", "248 740 2622", NULL, "248 740 2626", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1770, 1, "7 PLACE DE MOLARD", NULL, NULL, 
NULL, "1204 GENEVA", NULL, "CH", NULL, "01141228190850", NULL, "01141223110400", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1771, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1772, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1773, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1774, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1775, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1776, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1777, 1, "TOWER 42", NULL, NULL, NULL, 
"LONDON", NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1778, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1779, 1, "3890 CARMAN ROAD", NULL, NULL, 
NULL, "SCHENECTADY", "NY", "USA", "12303", "518 356 6031", NULL, "518 356 6146", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1780, 1, "ONE SULLIVAN ROAD", NULL, NULL, 
NULL, "HOLYOKE", "MA", "USA", "01040", "413 540 4220", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1781, 1, "PO BOX 730284", NULL, NULL, NULL, 
"DALLAS", "TX", "USA", "75073-0284", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1782, 1, "CROSSWAYS", "WEST CHILTINGTON", 
NULL, NULL, "WEST SUSSEX", NULL, "UK", "RH20 2QY", "011 02 35 38 27", "190 725", 
"011 02 35 39 74", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1783, 1, "1 SHELL PLAZA SUITE 1960", 
"910 LOUISIANA ST", NULL, NULL, "HOUSTON", "TX", "USA", "77002", "713 241 0864", 
NULL, "713 241 6418", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1784, 1, "TRAMPING DEPARTMENT", 
"QUAI DE SEINE", "PORT-JEROME", "76 330 NOTR-DAME DE GRAVENCHON", '', NULL, "F", 
NULL, "02 35 38 27 54", "190 725", "02 35 39 74 37", NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1785, 1, "171 OLD BAKERY STREET", NULL, NULL, 
NULL, "VALLETTA", NULL, "M", NULL, "46 8 660 1700", "11520", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1786, 1, "80 BROAD STREET", NULL, NULL, NULL, 
"MONROVIA", NULL, "LB", NULL, "41 10 5125", NULL, "41 10 516", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1786, 2, "C/O ESTORIL NAVIGATION LTD", 
"9, AGIOU SPYRIDONOS & BOUBOULINAS STR", "185 35 PIRAEUS", NULL, '', NULL, "GR", 
NULL, "30 1 411 0512", "241412/213980", "30 1 411 0516", NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1787, 1, "118 KOLOKOTRONI", "PIRAEUS 185 35", 
NULL, NULL, '', NULL, "GR", NULL, "301 428 2300", "213124/5", "301 428 2320", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1788, 1, "VIA CASTELLI", NULL, NULL, NULL, 
"LIVORNO", NULL, "I", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1789, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1790, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1791, 1, "TOUR SG", "17 COURS VALMY", 
"92987 PARIS LA DEFENSE", NULL, "PARIS", NULL, "F", NULL, "33 142 133 212", 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1792, 1, "RUA CINTURA DO PRTO", 
"CAIS DO BEATO", "ANEXO ARMAZEM", "20 APL", "LISBON", NULL, "P", "1900", 
"35 121 861 0910", "13471", "35 121 861 0912", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1793, 1, "SUITE 306", "513 EAST RICH STREET", 
NULL, NULL, "COLUMBUS", "OH", "USA", "43215", "614 221 5004", NULL, 
"614 220 4020", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1794, 1, "PIAZZA DELLA VITTORIA 10-9", NULL, 
NULL, NULL, "GENOVA", NULL, "I", "16121", "011 10 860 6200", "270578", NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1795, 1, '', NULL, NULL, NULL, "MONROVIA", 
NULL, "LB", NULL, "301 428 2300", "2131124", "301 428 2320", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1796, 1, "FOSDYKE SA", 
"AKARA BLDG, 24, DE CASTRO STR", "WICKHAMS CAY I", "ROAD TOWN", "TORTOLA", NULL, 
"USA", NULL, "+41223105246", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1797, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1798, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1799, 1, "HARBOUR OFFICE", "THE DOCKS", NULL, 
NULL, '', NULL, "IRL", NULL, "353 61 413606", NULL, "353 61 410262", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1800, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "792-6400", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1801, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1802, 1, "HANDELSSTRAAT 93", "B-1040", NULL, 
NULL, '', NULL, "B", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1803, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1804, 1, '', NULL, NULL, NULL, "MERITA", 
NULL, "SF", "FIN-00020", "358 9 16552605", "358 9 16556163", NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1805, 1, '', NULL, NULL, NULL, '', NULL, 
"HK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1806, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1807, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1808, 1, "AKARA BLDG., 24 DE CASTRO STREET", 
"WICKHAMS CAY I", NULL, NULL, "ROAD TOWN- TORTOLA", NULL, "VIU", NULL, NULL, 
"045421002", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1809, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1810, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1811, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1812, 1, " VIA LUDOVICO DI BREME, 26", NULL, 
NULL, NULL, "20156 MILANO", NULL, "I", NULL, "02 38 00 09 32", "02 38 00 53 75", 
NULL, "352106 INSPMI", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1813, 1, "AKARA BLDG., 24 DE CASTRO STREET", 
"WICKHAMS CAY I", NULL, NULL, "ROAD TOWN-TORTOLA", NULL, "VIU", NULL, NULL, 
"045421002", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1814, 1, '', NULL, NULL, NULL, '', NULL, 
"UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1815, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1816, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1817, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1818, 1, "STAMFORD HARBOR PARK", 
"333 LUDLOW STREET", NULL, NULL, "STAMFORD", "CT", "USA", "06902-0913", 
"961-0800", "RCA 238853", "961-0650", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1819, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1820, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, "49 40 360 04 66", NULL, "49 40 360 04 76", NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1821, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1822, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1823, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1824, 1, "C/O LANDSTONE MARITIME MGT LTD", 
"SUITE 1302 GREATEGLE CENTRE 23", "HARBOUR RD", NULL, "WANCHAI", NULL, "HK", 
NULL, "8621 68769288", "33696", "8621 68757944", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1825, 1, "VIA A SANGIORGIO, 12", NULL, NULL, 
NULL, "MILANO", NULL, "I", "20145", "02 33104823", "341065 LANMARI", 
"02 315165", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1826, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1827, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1828, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1829, 1, "SEA MEADOW HOUSE", 
"BLACK BURNE HWY", "PO BOX 116", "ROAD TOWN", "TORTOLA", NULL, "VIU", NULL, 
"85 2891-0691", NULL, "85 2575-6928", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1829, 2, 
"SUITE 801 8TH FLOOR CHINACHEM CENTURY TO", "178 GLOUCESTER ROAD", NULL, NULL, 
"WANCHAI", NULL, "HK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1830, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, "203 226 7882", NULL, "203 226 2328", NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(1831, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1832, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1833, 1, '', NULL, NULL, NULL, '', NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1834, 1, "BUERO BERLIN", 
"LANDSBERGER STRASSE 259", "D-12623", NULL, "BERLIN", NULL, "BRD", NULL, 
"49 30 565 026 3", NULL, "49 30 56 026 31", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1835, 1, "17-19 SIR JOHN ROGERSON'S QUAY", 
NULL, NULL, NULL, "DUBLIN 2", NULL, "IRL", NULL, " 353 1 679 8660", 
"353 86 807 0196", "353 1 679 8078", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1836, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1837, 1, "C/O MARE MARITIME CO SA", 
"75 POSEIDONS AVENUE", "17455 ALIMOS", NULL, "ATHENS", NULL, "GR", NULL, 
"30 19852900", "214271", "30 129852777", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1838, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1839, 1, "SUITE 1600", "1801 HOLLIS STREET", 
NULL, NULL, "HALIFAX", NULL, "CDN", "B3J 3N4", NULL, NULL, "902 420 0253", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1840, 1, "C/O M&N MANAGEMENT COMPANY", 
"1284 SOLDIERS FIELD ROAD", NULL, NULL, "BOSTON", "MA", "USA", "02135", 
"617 560 1352", NULL, "617 560 1552", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1841, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1842, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1843, 1, "BURGEMEESTER MOLLAAN 80", 
"PO BOX 51", "5580 AB WAALRE", NULL, '', NULL, "NL", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1844, 1, 
"INTERCAPITAL COMMODITY SWAPS LTD, LONDON", "PARK HOUSE", "16 FINSBURY CIRCUS", 
NULL, '', NULL, "UK", "EC2M 7UR", "44 171 588 2722", NULL, "44 171 920 9665", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1845, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1846, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1847, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, "502 627 3668", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1848, 1, "AM HOF 6A", "A-", "1010 WIEN", 
NULL, '', NULL, "A", NULL, "43 531 13 53020", NULL, "43 531 13 53009", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1849, 1, "PARKGUERTEL 24", 
"50823 KOELN (EHRENFELD", NULL, NULL, '', NULL, "BRD", NULL, "49 221 178 3046", 
NULL, "49 221 178 2361", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1850, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1851, 1, '', "Q", NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1852, 1, "600 NORTH BUFFALO GROVE ROAD", 
"SUITE 300", NULL, NULL, "BUFFALO GROVE", "IL", "USA", "60089", "847 520 3212", 
NULL, "847 520 9883", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1853, 1, " KINGS HILL", "PO BOX 127", "-", 
NULL, "ST CROIX", NULL, "VUS", "00851-0127", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1853, 2, "C/O AMERADA HESS CORP", 
"1185 AVENUE OF THE AMERICAS", NULL, NULL, "NEW YORK", "NY", "USA", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1854, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, "34 91 566 8657", NULL, "34 91 590 8395", NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1855, 1, "PO BOX 201203", NULL, NULL, NULL, 
"HOUSTON", "TX", "USA", "77216-1203", "713 627 4705", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1856, 1, "BP 46 ZARSOUNA", NULL, NULL, NULL, 
"BIZERTE", NULL, "TN", NULL, "-216 2 592 044", NULL, "216 2 590 457", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1857, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "X", NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(1858, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "X", NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(1859, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "X", NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(1860, 1, '', NULL, NULL, NULL, '', NULL, 
"BRD", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1861, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1862, 1, "510 BERING DRIVE", "SUITE 341", 
NULL, NULL, "HOUSTON", "TX", "USA", "77057", "713 974 9394", NULL, 
"713 974 9395", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1863, 1, "9151 RUMSEY RD", "SUITE 2000", 
NULL, NULL, "COLUMBIA", "MD", "USA", "21045", "410 995 4909", NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1864, 1, "TORRE WTC", "VIA DE MARINI, 1", 
"161149 GENOVA", NULL, '', NULL, "USA", NULL, "010 24011", NULL, "010 240 1533", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1865, 1, "5000 DOMINION BLVD", NULL, NULL, 
NULL, "GLEN ALLEN", "VA", "USA", "23060-6711", "804 273 4427", NULL, 
"804 273 4450", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1866, 1, "ARAN SHIPPING", NULL, NULL, NULL, 
'', NULL, "GR", NULL, "301 428 3900/9", NULL, NULL, "301-428-2177/8", NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1867, 1, "80 BROAD STREET", NULL, NULL, NULL, 
'', NULL, "LB", NULL, "30 1 459 1000", NULL, "30 1 459 1919", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1868, 1, "PO BOX 845 3000 AV ROTTERDAM", 
"WESTERLAAN 10 3016 CK ROTTERDAM", NULL, NULL, '', NULL, "UK", NULL, 
"31  10 464 2005", "21489 VO ITS", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1869, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1870, 1, "35/39 AKTI-MIAOLU", NULL, NULL, 
NULL, '', NULL, "GR", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1871, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1872, 1, "BENOR TANKERS LTD", 
"CHAUSSEE DE LA HULPF 150, BOX 2", NULL, NULL, '', NULL, "B", "1170", 
"32 2 6720200", "65155/ 65156", "32 2 6602805", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1873, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, "377 93 25 46 54", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1874, 1, "DEVONSHIRE HOUSE", 
"MAYFAIR PLACE, PICADILLY", NULL, NULL, '', NULL, "UK", "W1X 5FH", 
"44 171 493 7272", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1875, 1, "MOLLEGARDSVEJ 1", 
"DK - 8240 RISSKOV", NULL, NULL, '', NULL, "BRD", "2003", "45 87 426262", NULL, 
"45 87 42 6263", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1876, 1, "TRESCHKOWSTRASSE 5", NULL, NULL, 
NULL, '', NULL, "BRD", "30457", NULL, "49 511 439 04", NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1877, 1, "6-8 OLD BOND STREET", NULL, NULL, 
NULL, "LONDON", NULL, "UK", "W1X 3TA", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1878, 1, "2, ALLEE THOMAS EDISON", 
"13501 MARTIGUES CEDEX", NULL, NULL, '', NULL, "F", NULL, "33 44 235 4700", 
"401305", "33 44 281 1491", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1879, 1, "WILLOW HOUSE", 
"17-23 WILLOW PLACE", NULL, NULL, '', NULL, "UK", "SW1P1JH", "44 171 526 6666", 
"918488", "44 171 828 3587", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1880, 1, "171 OLD BAKERY STREET", NULL, NULL, 
NULL, '', NULL, "M", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1881, 1, 
"C/O UNIVERSE MARITIME LTD (MANAGERS)", "215 KIFISSIAS AVENUE", "151-24 MAOUSI", 
NULL, '', NULL, "GR", NULL, "00 301 61 23 40", "216225 AB UNIVE", 
"00 301 61 26 20", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1882, 1, " PO BOX 6457", NULL, NULL, NULL, 
"PHOENIX", "AZ", "USA", "85005-6457", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1883, 1, "1800 S RIO GRANDE AVE", NULL, NULL, 
NULL, "MONTROSE", "CO", "USA", "81401", "970 240 6221", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1884, 1, "AN DER ALTEN ALLEE 7", 
"D-55017 MAINZ", NULL, NULL, '', NULL, "UK", NULL, "49 6131 921 500", NULL, 
"49 6131 927 502", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1885, 1, "DEFAULT ADDRESS", NULL, NULL, NULL, 
"DEFAULT CITY", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1886, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1887, 1, "PO BOX 790", NULL, NULL, NULL, 
"WATERTOWN", "SD", "USA", "57201", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1888, 1, "C/C SUNOCO INC (R AND M)", NULL, 
NULL, NULL, "PHILADELPHIA", "PA", "USA", "19103", NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1889, 1, "PO BOX 51", "INCHERA", 
"LITTLE ISAND", "CO. CORK", '', NULL, "IRL", NULL, NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1890, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1891, 1, 
"C/O INTERENATIONAL ANDROMEDA MANAGEMENT=", "GILDO PASTOR CENTER", 
"7, RUE DU GABIAN", NULL, '', NULL, "VIU", "MC 98000", "377 93 100150", 
"479305 ANDMC", "377 93 100351", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1892, 1, "WITHAM HOUSE", "45 SPYVEE STREET", 
"HULL", "HU8 7JR", '', NULL, "UK", NULL, "44 148 221 4020", "592513 (MARIT G", 
"44 148 221 0719", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1893, 1, "BARTHELS HOF", "HAINSTRASSE", NULL, 
NULL, "LEIPZIG", NULL, "B", "04109", "49 341 71008 11", NULL, "49 341 71008 15", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1894, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1895, 1, "VIA TRIGESTE 143", "RAVENNA 49100", 
NULL, NULL, '', NULL, "I", NULL, "054 442 0430", NULL, "054 442 0364", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1896, 1, "2761 SALT SRPINGS RD", NULL, NULL, 
NULL, "YOUNGSTOWN", "OH", "USA", "44509", "330 792 9524", NULL, "330 792 9584", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1897, 1, '', NULL, NULL, NULL, '', NULL, 
"VIU", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1898, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1899, 1, "MOERSER STRASSE 149", 
"47198 DUISBURG", NULL, NULL, '', NULL, "BRD", NULL, "49 2066 20 19 1", NULL, 
"49 2066 20 19 9", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1900, 1, "POSTFACH 4165", "58041 HAGEN", 
NULL, NULL, '', NULL, "DK", NULL, "49 23014", NULL, "49 2304 930 230", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1901, 1, "HAVEN 643", "SCHELDELAAN 470", 
"2040 ANTWERP", NULL, '', NULL, "B", NULL, "03 569 95 00", "32857", 
"03 569 97 25", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1902, 1, "414 HUNTER ST", NULL, NULL, NULL, 
"MAMARONECK", "NY", "USA", "10543", "914 777 7587", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1903, 1, "CARLIOL HOUSE", "MARKET STREET", 
"NEW CASTLE", "UPONTYNE", '', NULL, "UK", NULL, "44 191 210 2976", NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1904, 1, "13709 SOUTHWEST BAYSHORE DRIVE", 
NULL, NULL, NULL, "TRAVERSE CITY", "MI", "USA", "49696", "231 995 9256", NULL, 
"231 995 9259", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1905, 1, "LUISENSTRASSE 105", 
"40215 DUSSELDORF", NULL, NULL, '', NULL, "BRD", NULL, "49 21 1 821 237", NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1906, 1, "1001 LOUISIANNA STREET 25TH FLOOR", 
NULL, NULL, NULL, "HOUSTON", "TX", "USA", "77002", "713 420 5000", NULL, 
"713 420 6082", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1907, 1, "C/O TRANSMARINE MANAGEMENT APS", 
"HOLBHERGSGADE 26.1", NULL, NULL, "COPENHAGEN K", NULL, "DK", "DK-1057", 
"45 33 932525", "454 33 938981", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1908, 1, "C/O DYNEGY UK LTD", "1ST FLOOR", 
"4 GROSVENOR PLACE", NULL, "LONDON", NULL, "UK", "SW1 X7HJ", NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1909, 1, '', NULL, NULL, NULL, '', NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1910, 1, "STRAWINSKYLAAN 743", "1077 XX", 
NULL, NULL, "AMSTERDAM", NULL, "NL", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1911, 1, "JUNGFERSTIEG 38", NULL, NULL, NULL, 
"HAMBURG", NULL, "BRD", "20354", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(1912, 1, "CAUSSEESTRASSE 23", NULL, NULL, 
NULL, "BERLIN", NULL, "BRD", "10115", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1913, 1, "BLUMENSTRASSE 19", NULL, NULL, 
NULL, "80287 MUCHEN", NULL, "BRD", NULL, "498923614555", "498923614556", 
"498923613064", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1914, 1, "LAUTENSCHLAGERSTRASSE 21", NULL, 
NULL, NULL, "D-70173 STUTTGART", NULL, "BRD", NULL, "4971128953692", NULL, 
"4971128956372", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1915, 1, "29 GUBERNSKIY STREET", NULL, NULL, 
NULL, "NOVOROSSISK 353915", NULL, "RUS", NULL, "00786172611141", "379108", 
"00786172610778", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1916, 1, " DEFAULT", NULL, NULL, NULL, 
"DEFAULT", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1917, 1, "BAYERNWERKSTR 39E", NULL, NULL, 
NULL, "85757 KARLSFELD", NULL, "BRD", NULL, "498912542231/22", NULL, 
"498912542166", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1918, 1, "OHMSTRASSE 4", NULL, NULL, NULL, 
"73240 WENTLINGEN", NULL, "BRD", NULL, "497024442225", NULL, "497024442492", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1919, 1, "2 NORTH NINTH ST", NULL, NULL, 
NULL, "ALLENTOWN", "PA", "USA", "18101", "610-774-4716", NULL, "610-774-6523", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1920, 1, "VON WERTHSTRASSE 274", NULL, NULL, 
NULL, "50259 PULHEIM", NULL, "BRD", NULL, "492234852378", NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1921, 1, "800 CABIN HILL DR", NULL, NULL, 
NULL, "GREENSBURG", "PA", "USA", "15601", "724-838-6314", NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1922, 1, "THEODOR-ALTHOFF-STR. 39", NULL, 
NULL, NULL, "ESSEN", NULL, "BRD", "D-45133", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1923, 1, "STADTTOR 1 (16. ETAGE)", NULL, 
NULL, NULL, "DUSSELDORF", NULL, "BRD", "40219", "00 49 201 1893", 
"00 49 201 1893", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1924, 1, 
"C/O NEREUS SHIPPING S.A EL098015298", "AKTI MIAOULI 35/39", NULL, NULL, 
"PIRAEUS", NULL, "GR", "185 35", "42 92 262 / 66", "211451 - 212245", 
"42 92 466 /42 9", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1925, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", ".", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1926, 1, "MARSTON HOUSE", "FROME", NULL, 
NULL, "SOMERSET", NULL, "UK", "BA11 5DU", "44 1373 451001", NULL, 
"44 1373 836501", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1927, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1928, 1, "TRANS- TEC SERVICES INC.", 
"GLENPOINTE CENTRE WEST", "500 FRANK W/ BURR ROAD", NULL, "TEANECK", "NJ", "USA", 
"07666", "201 692-9292", "201 692-1954", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1929, 1, "LASTLEITSTELLE DER INTERARGEM", 
"RAVENSBERGER STRASSE 28", NULL, NULL, "PORTA WESTFALICA", NULL, "BRD", "32457", 
"49 5706 929 720", NULL, "49 5706 929 722", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1930, 1, "VIA ROMA, 121", NULL, NULL, NULL, 
"CAGLIARI", NULL, "I", "I - 09124", "39 70 668208", "790012 PLT CA I", 
"39 70 659924", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1931, 1, "SCALI DEGLI ISOLOTTI, 11/12", NULL, 
NULL, NULL, "LIVORNO", NULL, "I", "57123", "0586 274411", NULL, "0586 274460", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1932, 1, "15 RUE DE LA CONFEDERATION", 
"PO BOX 5727", NULL, NULL, "GENEVA", NULL, "CH", "1211", "04122-311-0204/", 
"425087", "04122-311-0242", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1933, 1, "P.O. BOX 120", NULL, NULL, NULL, 
"CHAPLIN", NULL, "CDN", "S0H 0V0", "306 395-2561", NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1934, 1, "444 SOUTH 16TH STREET MALL", NULL, 
NULL, "68102-2247", "OMAHA", "NE", "USA", "681002", NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1935, 1, "15 RALSEY ROAD SOUTH", NULL, NULL, 
NULL, "STAMFORD", "CT", "USA", "06902", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1936, 1, "PO BOX 61000", NULL, NULL, NULL, 
"NEW ORLEANS", "LA", "USA", "70161", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1937, 1, "LUNGOMARE DI PEGLI, 24/4", NULL, 
NULL, NULL, "GENOVA", NULL, "I", "I-16155", "39 010-6974990", "43 273894 INTME", 
"39 010 6980175", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1938, 1, ".", NULL, NULL, NULL, ".", NULL, 
"CI", ".", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1939, 1, "700 UNIVERSE BLVD", NULL, NULL, 
NULL, "JUNO BEACH", "FL", "USA", "33408-0420", "561 625-7698", NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1940, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", ".", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1941, 1, "2300, 300  - 5TH AVENUE S.W.", 
NULL, NULL, NULL, "CALGARY", NULL, "CDN", "T2P 1C9", NULL, NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1942, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1943, 1, "885 N. KINZIE AVENUE", NULL, NULL, 
NULL, "BRADLEY", "IL", "USA", "60915", "815 937-8164", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(1944, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", ".", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1945, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", ".", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1946, 1, "10 ANSON ROAD", 
"#20 - 04 INTERNATIONAL PLAZA", NULL, NULL, ".", NULL, "SGP", "079903", 
"65 225 3966", NULL, "65 225 7370", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1947, 1, "300 BEACH ROAD", 
"#13-07 THE CONCOURSE", NULL, NULL, ".", NULL, "SGP", "199555", "65 292-8484", 
NULL, "65 292-9638", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1948, 1, "NO. 7 TEMASEK BOULEVARD", "#03-00", 
NULL, NULL, ".", NULL, "SGP", "038987", "65 339-9574", NULL, "65 339-9278", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1949, 1, "25/26 CIRCULAR ROAD", 
"#30-00 SINGAPORE LAND TOWER", NULL, NULL, ".", NULL, "SGP", "049381", 
"65 535 5555", NULL, "65 5358 8277", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1950, 1, "138 CECIL STREET", 
"#12-01 CECIL COURT", NULL, NULL, ".", NULL, "SGP", "069538", NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1951, 1, "51 CUPPAGE ROAD", 
"#10-02 STARHUB CENTRE", NULL, NULL, ".", NULL, "SGP", "229469", NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1952, 1, "101 THOMSON ROAD", 
"#23-04/05 UNITED SQUARE", NULL, NULL, ".", NULL, "SGP", "307951", NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1953, 1, "3 WHENTON WAY", 
"#23-02 SHENTON HOUSE", NULL, NULL, ".", NULL, "SGP", "068805", NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1954, 1, "10 ANSON ROAD", 
"#16M-14 INTERNATIONAL PLAZA", NULL, NULL, ".", NULL, "USA", "079903", NULL, 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1955, 1, "LISCARTAN HOUSE", 
"127 SLOANE STREET", NULL, NULL, "LONDON", NULL, "UK", "SW1X 9BA", NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1956, 1, "WILLOW HOUSE, 17-23 WILLOW PLACE", 
NULL, NULL, NULL, "LONDON", NULL, "UK", "SW1P 1JH", "44 20 7526-6666", NULL, 
"44 20 7828-3587", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1957, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", ".", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1958, 1, "80 RAFFLES PLACE", 
"#26-03 UOB PLAZA", NULL, NULL, ".", NULL, "SGP", "048624", "65 557-0777", NULL, 
"65 438-6988", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1959, 1, "210 SUKHUMVIT 64", NULL, NULL, 
NULL, "BANKKOK", NULL, "T", "10260", "66 2331-0047", NULL, "66 2745-4079", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1960, 1, "ARK MORE BUILDING 33F", 
"1012032 AKASAKA", "MINATO-KU", NULL, "TOKYO", NULL, "SGP", "119954", NULL, 
NULL, "81 35562-3951", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1961, 1, "300 BEACH ROAD", 
"#23-01 THE CONCOURSE", NULL, NULL, ".", NULL, "SGP", "199555", 
"41 22 703-2111", NULL, "41 22 703-2122", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1962, 1, "13 CHARLES II STREET", "5TH FLOOR", 
NULL, NULL, "LONDON", NULL, "UK", "SW1 4QT", "44 171 930-8888", NULL, 
"44 171 930-8666", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1963, 1, "1 HARBOUR ROAD", 
"12TH FL, OFFICE TOWER, CONVENTION PLAZA", NULL, NULL, "WANCHAI", NULL, "HK", 
".", "852 2824-2638", NULL, "852 2824-3669", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1964, 1, "20 CECIL STREET", 
"#14-05 THE EXCHANGE BUILDING", NULL, NULL, ".", NULL, "SGP", "01004", 
"65 535-6995", NULL, "65 535-2976", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1965, 1, "22/F, BUILDING A", 
"WANTONE NEW WORLD PLAZA 2 FUWAI STREET", NULL, NULL, "BEJING", NULL, "USA", 
"100037", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1966, 1, "17F, CHINA RESOURCES BUILDING", 
"26 HARBOUR ROAD", NULL, NULL, "WANCHAI", NULL, "HK", NULL, NULL, NULL, 
"852 2827 5560", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1967, 1, "5 GREENWAY PLAZA, STE 2400", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77046", "713 840-2870", NULL, 
"713 215-7484", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1968, 1, "101 THOMSON ROAD", 
"#11-01/02 UNITED SQUARE", NULL, NULL, ".", NULL, "SGP", "307591", 
"65 849-4242", NULL, "65 736-3611", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1969, 1, ".", NULL, NULL, NULL, ".", NULL, 
"ZA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1970, 1, "391B ORCHARD ROAD", 
"#10-33 NGEE ANN CITY TOWER B", NULL, NULL, ".", NULL, "SGP", "238874", 
"65 838-9010", NULL, "65 734-2868", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1971, 1, ".", NULL, NULL, NULL, ".", NULL, 
"RC", ".", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1972, 1, ".", NULL, NULL, NULL, ".", NULL, 
"SGP", ".", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1973, 1, ".", NULL, NULL, NULL, ".", NULL, 
"J", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1974, 1, ".", NULL, NULL, NULL, ".", NULL, 
"J", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1975, 1, ".", NULL, NULL, NULL, ".", NULL, 
"SGP", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1976, 1, "49 WIGMORE STREET", NULL, NULL, 
NULL, "LONDON", NULL, "USA", "W1H 9LE", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(1977, 1, ".", NULL, NULL, NULL, ".", NULL, 
"UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1978, 1, ".", NULL, NULL, NULL, "NEW DELHI", 
NULL, "IND", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1979, 1, ".L", NULL, NULL, NULL, ".", NULL, 
"J", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1980, 1, ".", NULL, NULL, NULL, "TOKYO", 
NULL, "J", "102", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1981, 1, ".", NULL, NULL, NULL, ".", NULL, 
"SGP", "079117", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1982, 1, ".", NULL, NULL, NULL, "TOKYO", 
NULL, "J", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1983, 1, ".", NULL, NULL, NULL, "KYUNGKI-DO", 
NULL, "KOR", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1984, 1, ".", NULL, NULL, NULL, ".", NULL, 
"SGP", "038988", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1985, 1, ".", NULL, NULL, NULL, "HAMILTON", 
NULL, "BER", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1986, 1, ".", NULL, NULL, NULL, ".", NULL, 
"UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1987, 1, ".", NULL, NULL, NULL, ".", NULL, 
"SGP", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1988, 1, ".", NULL, NULL, NULL, "TOKYO", 
NULL, "J", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1989, 1, ".", NULL, NULL, NULL, ".", NULL, 
"SGP", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1990, 1, ".", NULL, NULL, NULL, "HONG KONG", 
NULL, "J", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1991, 1, ".", NULL, NULL, NULL, ".", NULL, 
"SGP", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1992, 1, ".", NULL, NULL, NULL, ".", NULL, 
"SGP", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1993, 1, ".", NULL, NULL, NULL, ".", NULL, 
"SGP", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1994, 1, ".", NULL, NULL, NULL, ".", NULL, 
"SGP", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1995, 1, ".", NULL, NULL, NULL, "BANGKOK", 
NULL, "T", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1996, 1, ".", NULL, NULL, NULL, 
"KUALA LUMPUR, MALAYSIA", NULL, "SGP", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(1997, 1, 
"MAKER CHAMERS IV, 9TH FLOOR WEST WING", "222 NARIMAN POINT", "MUMBAI 400 21", 
NULL, ".", NULL, "SGP", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1998, 1, "20TH FLOOR, INT'L FINANCE CTR", 
"25 OIL BROAD STREET", NULL, NULL, "LONDON", NULL, "UK", "EC2N 1HQ", NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(1999, 1, ".", NULL, NULL, NULL, "TOKYO", 
NULL, "J", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2000, 1, ".", NULL, NULL, NULL, "TOKYO", 
NULL, "J", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2001, 1, "HUI BIN OFFICE BLD", 
"NO. 8 BEICHENDONG STREET", "(RM418/4F)", NULL, "HONG KONG", NULL, "J", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2002, 1, 
"16 RAFFLES QUAY, #39-01 HONG LEONG BLD", NULL, NULL, NULL, ".", NULL, "SGP", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2003, 1, "23TH FL OFFC TWR, CONVENTION PLZA", 
"1 HARBOUR ROAD", NULL, NULL, "WANCHAI", NULL, "HK", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2004, 1, ".", NULL, NULL, NULL, "SEOUL", 
NULL, "KOR", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2005, 1, "5 SHENTON WAY", 
"#34-08/12 UIC BLDG", NULL, NULL, ".", NULL, "SGP", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2006, 1, "105 CECIL STREET, #08-01 OCTAGON", 
NULL, NULL, NULL, ".", NULL, "SGP", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2007, 1, "51 GOLDHILL PLAZA", "#12-06", NULL, 
NULL, ".", NULL, "SGP", "1130", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(2008, 1, "6 BROADGATE", NULL, NULL, NULL, 
"LONDON", NULL, "UK", "EC2M 2AA", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(2009, 1, ".", NULL, NULL, NULL, ".", NULL, 
"CH", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2010, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2011, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2012, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2013, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2014, 1, "ONE THE EXCHANGE", 
"BRENT CROSS GARDENS", NULL, NULL, "LONDON", NULL, "UK", "NW4 3RJ", 
"44 207 499 8100", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2015, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2016, 1, "WEYERHAEUSER SASKATCHEWAN LTD.", 
"PRINCE ALBERT PULP AND PAPER", "P.O. BOX 3001", NULL, 
"PRINCE ALBERT, SASKATCHEWAN", NULL, "CDN", NULL, "306 953 5160", NULL, 
"306 764 8886", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2017, 1, "WISPIENSTRASSE 8-10", NULL, NULL, 
NULL, "AACHEN", NULL, "BRD", "52062", "49 241 412 2014", NULL, "49 241 413 200", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2018, 1, "ONE AMEREN PLAZA", 
"1901 CHOUTEAU AVE", NULL, NULL, "ST. LOUIS", "MO", "USA", "63103", 
"314 554-4271", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2019, 1, "47 RUA BERNARDINO COSTA", 
"PO BOX 2122", NULL, NULL, "LISBON", NULL, "P", "12341", "351 1 347 0231", NULL, 
"351 1 346 3832", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2020, 1, "18 KING STREET, EAST, STE 902", 
NULL, NULL, NULL, "TORONTO, ONTARIO", NULL, "CDN", "M5C 1C4", "416 862 7600", 
NULL, "416 862 5453", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2021, 1, "PO BOX 1275", NULL, NULL, NULL, 
"EDMUND", "OK", "USA", "73083", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2022, 1, "SE 16287", 
"JAMTLANDSGATAN 99, RACKSTA", NULL, NULL, "STOCKHOLM", NULL, "S", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2023, 1, 
"INTERTEK TESTING SERVICES SRL./CALEB BRE", "CORSO BUENOS AYRES 7-13", 
"16129 GENOVA 1", NULL, ".", NULL, "I", "16129", NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2024, 1, "ELF TRADING AND MARKETING B.V.", 
"WORLD TRADE CENTER", "P.O. BOX 276", "CH-1215", "GENEVA", NULL, "CH", "15", 
NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2025, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, "312 240-4361", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2026, 1, ".", NULL, NULL, NULL, ".", NULL, 
"UAE", NULL, "9714 305-8844", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2027, 1, "EDIFICIO BETA - LER PISO", 
"VIA ESPANA 120", NULL, NULL, "PANAMA 1", NULL, "PA", NULL, "507 263-6311", 
NULL, "507 269-6638", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2028, 1, "579 TENNEY MOUNTAIN HIGHWAY", NULL, 
NULL, NULL, "PLYMOUTH", "NH", "USA", "03264-3154", "603 536-8655", NULL, 
"603 536-8682", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2029, 1, "PLAZA SOTOMAYOR 50", NULL, NULL, 
NULL, "VALPARISO", NULL, "RCH", "2360171", "011 56 32 203 1", NULL, 
"011 56 32 203 9", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2030, 1, "20-22 BEDFORD ROW", NULL, NULL, 
NULL, "LONDON", NULL, "UK", "WC1R RJS", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2031, 1, "8 GRANDE-RUE", NULL, NULL, NULL, 
"GENEVA", NULL, "CH", "1204", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2032, 1, ".", NULL, NULL, NULL, ".", NULL, 
"UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2033, 1, "CHURCH WHARF", "P.O. BOX 6 HAMRUN", 
NULL, NULL, "MARSA", NULL, "M", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2034, 1, ".", NULL, NULL, NULL, ".", NULL, 
"UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2035, 1, "10777 WESTHEIMER SUITE 650", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77042", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2036, 1, "1575 SHERMAN FARM ROAD", NULL, 
NULL, NULL, "HARRISVILLE", "RI", "USA", "02830-1124", "401 568-9550", NULL, 
"401 568-1999", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2037, 1, "1575 SHERMAN FARM ROAD", NULL, 
NULL, NULL, "HARRISVILLE", "RI", "USA", "02830-1124", "401 568-9550", NULL, 
"401 568-1999", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2038, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2039, 1, "INONU CAD CAMLIK PARK SOK NO 8", 
NULL, NULL, NULL, "SAHRAYICEDID", NULL, "MAL", "81080", "216 302 0129", NULL, 
"216 302 0128", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2040, 1, ".", NULL, NULL, NULL, ".", NULL, 
"UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2041, 1, "TRANSMISSION, TRANFORMATIONA", 
"DN CONTROL SUBDIRECTION", "PMB-42-023 120-A ROCKWOOD AVENUE", NULL, "CALEXICO", 
"CA", "USA", "92231-2748", "526 558 1514", NULL, "526 558 1562", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2042, 1, "PARKWOOD II BUILDINGS, STE 300", 
"10055 GROGANS MILL ROAD", NULL, NULL, "THE WOODLANDS", "TX", "USA", "77380", 
"281 297-359", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2043, 1, "12 A GUANG AN MEN", 
"NAN JIE BEIGING, CHINA", "P.O. BOX 2932", NULL, "BEIJING", NULL, "T", "100053", 
NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2044, 1, "301 E. OCEAN BLVD #570", NULL, 
NULL, NULL, "LONG BEACH", "CA", "USA", "?", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2045, 1, "12012 WICKCHESTER, STE 350", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77079", "281 759-0245", NULL, 
"281 759-0244", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2046, 1, "X", NULL, NULL, NULL, "X", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2047, 1, ".", NULL, NULL, NULL, "SEATTLE", 
"WA", "USA", ".", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2048, 1, "VIA DOMENTICO FIASELLA 4/14", NULL, 
NULL, NULL, "GENOA", NULL, "I", "16121", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2049, 1, "OUEENBERY HOUSE #3", 
"OLD BURLINGTON STREET", NULL, NULL, "LONDON", NULL, "UK", "W1X 1LA", 
"207 851 5097", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2050, 1, "310-2- KA TAEPOYONG- RO", 
"CHUNG-KU", "TAEPYONG-RO BUILDING", NULL, "SEOUL", NULL, "KOR", NULL, 
"822 3706 1372", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2051, 1, "1 WILLIAMS CENTER", 
"P.O. BOX 2848", NULL, NULL, "TULSA", "OK", "USA", "7410-9567", "918 573-5613", 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2052, 1, "515 KING STREET", "P.O. BOX 2000", 
NULL, NULL, "FREDERICTON", NULL, "CDN", "NB E3B 4X1", "506 458-4618", NULL, 
"506 458-4642", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2053, 1, ".", NULL, NULL, NULL, "LAUFENBURG", 
NULL, "CH", "CH-5080", "4162 869 6287", NULL, "4162 869 6680", NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2054, 1, "DOKHAVNSVEG 3, POSTBOKS 67", NULL, 
NULL, NULL, "KALUNDBORG", NULL, "DK", "DK-4400", "45 59 51 3223", NULL, 
"45 59 51 3551", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2055, 1, "PO BOX 182", "1000 AMSTERDAM", 
NULL, NULL, "AMSTERDAM", NULL, "NL", NULL, "31 20 587 5870", NULL, 
"31 20 613 1871", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2056, 1, "CINERGY HOUSE, RYON HILL PARK", 
"WARWICK ROAD, STRATFORD-UPON-AVON", NULL, NULL, "WARWICKSHIRE", NULL, "UK", 
"CV37 0UU", "44 1789 200167", NULL, "44 1789 200101", NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2057, 1, "PRIME ENERGY AS", "TORGGATA 15", 
NULL, NULL, "SKIEN", NULL, "N", "3717", "0047 3591 3710", NULL, 
"0047 3591 3719", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2058, 1, ".", NULL, NULL, NULL, ".", NULL, 
"PRC", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2059, 1, "MARINA PARK", "SUNDKROGSGADE 10", 
NULL, NULL, "COPENHAGEN", NULL, "DK", "DK-2100", "45 39 17 92 00", 
"22315 TORM DK", "45 39 17 92 95", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2060, 1, "9IEME ETAGE", 
"TOUR EST COMLPLEXE DESJARDINS", NULL, NULL, "MONTREAL", NULL, "CDN", "H5B-1H7", 
"514 289-2211", NULL, "514 289-4688", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2061, 1, "CITY HALL", "RM 502", NULL, NULL, 
"BUFFALO", "NY", "USA", "14202", "716 851 5636", NULL, "716 851 4080", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2062, 1, "AVENIDA AMERICA, 38", NULL, NULL, 
NULL, "MADRID", NULL, "E", "28028", "34 91 5893232", NULL, "34 91 3563502", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2063, 1, "105 INDUSTRIESTRASSE", 
"9491 RUGGELL FL", NULL, NULL, "LEICHTENSTEIN", NULL, "BRD", NULL, 
"377 9777 8488", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2064, 1, "C/O GASNATURAL SDG.", 
"AVENIDA AMERICA, 38", NULL, NULL, "MADRID", NULL, "E", "28028", 
"34 91 5893232", NULL, "34 91 3563502", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2065, 1, ".", NULL, NULL, NULL, ".", NULL, 
"UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2066, 1, "CARACAS BAY", NULL, NULL, NULL, 
"CURACAO", NULL, "NA", "WEG 201", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(2067, 1, "P.O. BOX 418679", NULL, NULL, NULL, 
"KANSAS CITY", "MO", "USA", "64141-9679", "816 556-2200", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2068, 1, "10/11 GROSVENOR PLACE", NULL, NULL, 
NULL, "LONDON", NULL, "UK", "SW1X 7JG", "0207 903 2600", NULL, "0207 903 2606", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2069, 1, ".", NULL, NULL, NULL, ".", NULL, 
"UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2070, 1, "ASHTON HOUSE", "SILNURY BOULEVARD", 
"CENTRAL MILTON KEYNES", NULL, "LONDON", NULL, "UK", "MK9 2HG", 
"44 1908 848339", NULL, "44 1908 678941", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2071, 1, "200 GREENWICH AVENUE", NULL, NULL, 
NULL, "GREENWICH", "CT", "USA", "06730", "203 552-4027", "49619146", 
"203 552-4070", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2072, 1, "59 DILIGIANNI STREET", NULL, NULL, 
NULL, "KIFISSIA", NULL, "GR", "14562", "30 1 628 2232", "216125 / 215394", 
"30 1 628 2601", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2073, 1, "MARINE BLDG BROFJORDAN HARBOUR", 
NULL, NULL, NULL, "LYSEKIL", NULL, "S", "SE-453", "0046 523 660455", NULL, 
"0046 523 660396", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2074, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2075, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2076, 1, ".", NULL, NULL, NULL, "NEW YORK", 
"NY", "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2077, 1, "LA RUE DE LA SENTE", NULL, NULL, 
NULL, "GROUVILLE", NULL, "GBJ", "JE3 9UD", "372 646 3157", NULL, "372 646 3162", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2078, 1, "18/2 SOUTH STREET", NULL, NULL, 
NULL, "VALLETTA", NULL, "M", "VLT 11", "356 236206", NULL, "356 240321", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2079, 1, "147/1 ST. LUCIA STR", NULL, NULL, 
NULL, "VALLETTA", NULL, "M", NULL, "9604667", "210767", "9604430", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2080, 1, "C/O AIG INT'L MGMT. COMPANY, INC.", 
"1281 EAST MAIN STREET", NULL, NULL, "STAMFORD", "CT", "USA", "06902", 
"203 324 8400", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2081, 1, "C/O AIG INT'L MGMT COMPANY, INC.", 
"1281 EAST MAIN STREET", NULL, NULL, "STAMFORD", "CT", "USA", "06902", 
"203 324 8400", NULL, "203 324 3317", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2082, 1, "3 RAFFLES PLACE", 
"#09-01 BHARAT BUILDING", NULL, NULL, "SINGAPORE", NULL, "SGP", "048617", NULL, 
NULL, "65-2783376", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2083, 1, "ATTN: BERNADETTE DOWLING", 
"P.O. BOX 6066", NULL, NULL, "NEWARK", "DE", "USA", "19714-6066", "302 452-6150", 
NULL, "302 452-6364", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2084, 1, "53RD STREET", 
"URBANIZACION OBORRIO TORRE", "SWISS BANK 16TH FLOOR", NULL, "PANAMA", NULL, 
"PA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2085, 1, ".", NULL, NULL, NULL, "ONTARIO", 
NULL, "CDN", NULL, "416 592-8361", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2086, 1, "STUBBENHUK 7", NULL, NULL, NULL, 
"HAMBURG", NULL, "DDR", "20549", "49 40 3703 54 5", NULL, "49 40 3703 54 5", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2087, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2088, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2089, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2090, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2091, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2092, 1, "1251 AVENUE OF THE AMERICAS", 
"26TH FLOOR", "ATTN: COMMODITY OPERATIONS", NULL, "NEW YORK", "NY", "USA", 
"10020", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2093, 1, "1470 RIVEREGDGE PARKWAY, NW", NULL, 
NULL, NULL, "ATLANTA", "GA", "USA", "30328", "770 563-8194", NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2094, 1, "3515 WASHINGTON RD., STE 14 - B", 
NULL, NULL, NULL, "MCMURRAY", "PA", "USA", "15317", "724 969-1685", NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2095, 1, "810-B PRINCETON PARKWAY", NULL, 
NULL, NULL, "OWENSBORO", "KY", "USA", "42301", "270 691-0049", NULL, 
"270 691-9343", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2096, 1, "ESPLANADEN 50 1098 KBH K", NULL, 
NULL, NULL, ".", NULL, "NL", NULL, "45 33633363", "19632", "45 33634878", 
"//CPHTANKOPS", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2097, 1, "VIA A. DEPRETIS, 102", NULL, NULL, 
NULL, "NAPLES", NULL, "I", "80133", "39 0544 598611", NULL, "39 0544 420372", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2098, 1, ".", NULL, NULL, NULL, ".", NULL, 
"UK", NULL, "303 592-5557", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2099, 1, "30 C STREET NW", NULL, NULL, NULL, 
"EPHRATA", "WA", "USA", "98823", "509 754-3541", NULL, "509 754-5292", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2100, 1, "900 EAST FIRST STREET", NULL, NULL, 
NULL, "SOUTH BOSTON", "MA", "USA", "02127-1706", "617 269-4610", "928060", 
"617 269-5275", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2101, 1, 
"80 BROAD STREET, MONROVIA, LIBERIA", "C/O MARINTER NAVIGATION SA (MANAGERS)", 
"180, SYNGROU AVENUE", NULL, "ATHENS", NULL, "GR", "17671", "0030 1 9577770", 
"00601 215732 MA", "0030 1 9577776", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2102, 1, "1221 NICOLLET MALL", "SUITE 700", 
NULL, NULL, "MINNEAPOLIS", "MN", "USA", "55403-2445", "612 373-8687", NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2103, 1, "125 INTERIM OFFICE BUILDING", NULL, 
NULL, NULL, "IRVINE", "CA", "USA", "92697-5444", "949 824-6956", NULL, 
"949 824-2962", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2104, 1, "101 THE CITY DRIVE", NULL, NULL, 
NULL, "ORANGE", "CA", "USA", "92868-6421", "714 456-6421", NULL, "714 456-6320", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2105, 1, "CHAUSSE DE LA HULPP # 181-11", 
NULL, NULL, NULL, "BRUSSELS", NULL, "B", "1170", "322-1900", NULL, "675-4999", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2106, 1, "N16 W23217 STONE RIDGE DR", 
"SUITE 100", NULL, NULL, "WAUKESHA", "WI", "USA", "53188", "4142256140", NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2107, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2108, 1, "2 MONTREAL RD. W", "MAFFON ANGERS", 
NULL, NULL, "QUEBEC", NULL, "CDN", "J8M 1K6", "819 986-4607", NULL, 
"816 776-7229", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2109, 1, "101 ASH STREET", NULL, NULL, NULL, 
"SAN DIEGO", "CA", "USA", "92101-3017", "619 696-4585", NULL, "619 696-2770", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2110, 1, "STORA BADHUSGATAN 18", NULL, NULL, 
NULL, "GOTEBORG", NULL, "S", "S-411 21", "46 31 176020", "27286", 
"46 31 7113454", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2111, 1, "2039 SOUTH 6TH STREET", NULL, NULL, 
NULL, "INDIANA", "PA", "USA", "15701", "724 349-7620", NULL, "724 349-5323", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2112, 1, ".", NULL, NULL, NULL, ".", "VT", 
"USA", NULL, "802 244 7678", NULL, "802 244-6889", NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(2113, 1, "SERRANO, 71", NULL, NULL, NULL, 
"MADRID", NULL, "E", "28006", "34 91 781 9333", NULL, "34 91 781 9359", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2114, 1, ".", NULL, NULL, NULL, ".", NULL, 
"BRD", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2115, 1, "NEOCLEOUS HOUSE", 
"199 ARCH MAKARIOUS III AVENUE", NULL, NULL, "LIMASSOL", NULL, "CY", NULL, 
"0035 894 355 62", "124677", "0035 894 553 20", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2116, 1, "CABLE HOUSE", 
"54-62 NEW BROAD STREET", NULL, NULL, "LONDON", NULL, "UK", "EC2N 1JJ", 
"207 827 2940", NULL, "207 827 2987", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2117, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2118, 1, "PO BOX 2010", NULL, NULL, NULL, 
"GRETNA", "LA", "USA", "70054-1210", "504 366-3401", "RCA 240804", 
"504-361-1200", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2119, 1, "14 RYDER STREET", "5TH FLOOR", 
NULL, NULL, "LONDON", NULL, "UK", "SW1Y 6QB", "207 7451 2300", NULL, 
"207 7451 2336", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2120, 1, "1100 LOUISIANA STREET", "STE 5151", 
NULL, NULL, "HOUSTON", "TX", "USA", "77002", "630 627-3698", NULL, 
"713 651-0928", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2121, 1, "NIJMEGENSTRAAT 42", 
"3087 CD ROTTERDAM", "P.O. BOX 966", NULL, "3160 AD RHOON, HOLLAND", NULL, "NL", 
NULL, "31 10 472 0422", "62419", "31 10 472 3033", NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(2122, 1, "C/O EA GIBSON SHIPBROKERS LTD.", 
"P.O. BOX 278", "AUDREY HOUSE", "16-21 ELY PLACE", "LONDON", NULL, "UK", 
"EC1P 1HP", "207 667 1000", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2123, 1, ".", NULL, NULL, NULL, "NEW YORK", 
"NY", "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2124, 1, "C/O INTESTRA CO SA", 
"10-12 KIFSSIAS AVENUE", NULL, "15125 AMAROUSSION", "ATHENS", NULL, "GR", NULL, 
"301 683 4875", "224365 ASCR GR", "301 684 7248", NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(2125, 1, ".", NULL, NULL, NULL, ".", NULL, 
"UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2126, 1, "12A IRODOU ATTIKOU STREET", 
"GR-151 24 MAROUSI", NULL, NULL, ".", NULL, "GR", NULL, "301 80 94 00", 
"2182 45 MOTO GR", "301 80 94 44", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2127, 1, "THE GRANARY OFFICE", 
"BARTON FARM, ANDOVER ROAD", NULL, NULL, "WINCHESTER, HAMSHIRE", NULL, "UK", 
"SO22 6AX", "44 196 288 1133", "47137 SPPOIL", "44 196 288 3800", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2128, 1, "16 RAFFLES QUAY, #20-", 
"04/05 HONG LEONG BUILDING", NULL, NULL, ".", NULL, "SGP", "048581", 
"65 226 5725", NULL, "65 226 5726", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2129, 1, ".", NULL, NULL, NULL, ".", NULL, 
"M", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2130, 1, "100 EAST OLD COUNTRY ROAD", NULL, 
NULL, NULL, "HICKSVILLE", "NY", "USA", "11801", "516 545-5400", NULL, 
"516 545-5466", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2131, 1, "8401 W. MONROE ROAD", NULL, NULL, 
NULL, "HOUSTON", "TX", "USA", "77061", "713 943 5000", NULL, "713 943 5050", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2132, 1, "P.O. BOX 4097", 
"109 ALDENE RD., BLDG 3", NULL, NULL, "ROSELLE PARK", "NJ", "USA", "07204", 
"908 245-9330", "130056", NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2133, 1, "360 ORCHARD RD", 
"HEX 10-01 INTERNATIONAL BLDG", NULL, NULL, "SINGAPORE 238869", NULL, "SGP", 
NULL, "735 5172", NULL, "735 4036", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2134, 1, "EKTANK AB", "BOX 2521", NULL, NULL, 
"403 17 GOTHENBURG", NULL, "S", NULL, "46 31 60 92 50", "27236", 
"46 31 711 48 57", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2135, 1, "25 RAFFLES PLACE", 
"HEX 17-01 CLIFFORD CENTRE", NULL, NULL, "SINGAPORE 048621", NULL, "SGP", NULL, 
"5361986", "RS 24662 GLORY", "5361987", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2136, 1, "5718 WESTHEIMER STE 1806", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77057", "713 977-5718", NULL, 
"713 975-5423", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2137, 1, "100 FOXBOROUGH BLVD, STE 110", 
NULL, NULL, NULL, "FOXBOROUGH", "MA", "USA", "02035", "508 698-0014", NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2138, 1, "2814 SOUTH GOLDEN", NULL, NULL, 
NULL, "SPRINGFIELD", "MO", "USA", "65807", "417 885-9268", NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2139, 1, "100 FOXBOROUGH BLVD. STE 110", 
NULL, NULL, NULL, "FOXBOROUGH", "MA", "USA", "02035", "508 698-0014", NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2140, 1, "39 AYER ROAD", NULL, NULL, NULL, 
"LITTLETON", "MA", "USA", "01640", "978 486-8188", NULL, "978 486-8549", NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2141, 1, "ONE UTAH CENTER, STE 2100", NULL, 
NULL, NULL, "SALT LAKE CITY", "UT", "USA", "84140-0021", NULL, NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2142, 1, "9951 SE ANDENY", NULL, NULL, NULL, 
"PORTLAND", "OR", "USA", "97216", NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(2143, 1, "OUC 2000", NULL, NULL, NULL, ".", 
NULL, "USA", NULL, "801 220-4071", NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2144, 1, "303 NORTH BROADWAY, STE 400", NULL, 
NULL, NULL, "BILLINGS", "MT", "USA", "59101", "406 869-5100", NULL, 
"403 869-5149", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2145, 1, "12700 WHITEWATER DRIVE", NULL, 
NULL, NULL, "MINNETONKA", "MN", "USA", "55343-9497", "612 984-3787", NULL, 
"612 984-3976", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2146, 1, "110 GATEWAY BLVD.", NULL, NULL, 
NULL, "COLUMBIA", "SC", "USA", "29203", "803 217-1400", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2147, 1, "110 GATEWAY BLVD.", NULL, NULL, 
NULL, "COLUMBIA", "SC", "USA", "29203", "803 217-1400", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2148, 1, "VIA S. CECCARINI", NULL, NULL, 
NULL, "36 - 61032 FANO (PS)", NULL, "I", NULL, "39 0721 8801", NULL, 
"39 0721 826793", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2149, 1, "6797 NORTH HIGH STREET, STE 314", 
NULL, NULL, NULL, "WORTHINGTON", "OH", "USA", "43085", "614 846-7888", NULL, 
"614 846-7833", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2150, 1, "ESPLANADEN 50", NULL, NULL, NULL, 
"1098 COPENHAGEN", NULL, "DK", NULL, "45 33634855", "DK 19632", "45 33634878", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2151, 1, "CAMPO DE LAS NACIONES", 
"AVDA. DEL PARTENON, 12", NULL, NULL, "28042 MADRID", NULL, "E", NULL, 
"91 337 6229", "44877 / 47120", "91 337 6198", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2152, 1, "707 8TH AVE, STE 600", NULL, NULL, 
NULL, "CALGARY", NULL, "CDN", "T2P 3V3", "403 218-1034", NULL, "403 218-1500", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2153, 1, "800, 919-11 AVE SW", NULL, NULL, 
NULL, "CALGARY", NULL, "CDN", "T2R 1P3", "403 209-6900", NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2154, 1, "AGENCY DEPARTMENT", NULL, NULL, 
NULL, ".", NULL, "SGP", NULL, "65 536 1986", "RS24662 GLORY", "65 536 1987", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2155, 1, "KEULSEKADE 189", NULL, NULL, NULL, 
"3534C UTRECHT", NULL, "NL", NULL, "31 30 247 2522", NULL, "31 30 247 2946", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2156, 1, ".", NULL, NULL, NULL, "NEW YORK", 
"NY", "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2157, 1, ".", NULL, NULL, NULL, "NEW YORK", 
"NY", "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2158, 1, ".", NULL, NULL, NULL, "NEW YORK", 
"NY", "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2159, 1, "18101 VON KARMAN AVE", "STE 1700", 
NULL, NULL, "IRVINE", "CA", "USA", "92612-1046", "949 752-5588", NULL, 
"949 752-7425", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2160, 1, "TAROUBA RD.", NULL, NULL, NULL, 
"MARABELLA", NULL, "TT", NULL, "868 658-1564", NULL, "868 658-1568", NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2161, 1, "SKM DEUTSCHLAND GMBH", 
"ROHMERPLATZ 33-27", NULL, NULL, "D-60846 FRANKFURT", NULL, "DDR", NULL, 
"49 69 97 159-50", NULL, "49 69 97 159-11", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2162, 1, "7 WORLD TRADE CENTER", NULL, NULL, 
NULL, "NEW YORK", "NY", "USA", "10048-2627", "212 667-0248", NULL, 
"212 667-0593", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2163, 1, "13, BARRIERA WHARF", NULL, NULL, 
NULL, "VALLETTA", NULL, "M", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2164, 1, "50 TOWN RANGE", NULL, NULL, NULL, 
".", NULL, "GBZ", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2165, 1, 
"CO/ TORM WATERFRONT TANKERS (TIME CHARTE", NULL, NULL, NULL, ".", NULL, "DK", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2166, 1, "CENTERHAVN 23 POB 209", NULL, NULL, 
NULL, "FREDERICIA 7000", NULL, "DK", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2167, 1, "C/O AIC SERVICES  74 BLVD ITALY", 
NULL, NULL, NULL, "MC98000", NULL, "MC", NULL, NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2168, 1, "701 S.E. 24TH STREET", NULL, NULL, 
NULL, "FORT LAUDERDALE", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2169, 1, "AMSTERDAMSTRAAT 14  POSTBOX H", 
NULL, NULL, NULL, "B- 2000 ANTWERPEN", NULL, "BRD", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2170, 1, "20 COURS LANDRIVON  BP 63", NULL, 
NULL, NULL, "13522 PORT DE BOUC CEDEX", NULL, "F", NULL, NULL, NULL, NULL, NULL, 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2171, 1, "20 EAST GREENWAY PLAZA", NULL, 
NULL, NULL, "HOUSTON", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2172, 1, "2800 EISENHOWER AVENUE", NULL, 
NULL, NULL, "ALEXANDRIA", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2173, 1, "PO BOX 151", NULL, NULL, NULL, 
"3000 AD ROTTERDAM", NULL, "NL", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2174, 1, "4 BLOOMFIELD CRESCENT", NULL, NULL, 
NULL, "BATH BA2 2BE", NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2175, 1, "LEERLOOIERSTRAAT 135", NULL, NULL, 
NULL, "3194 AB HOOGVLIET (RT)", NULL, "NL", NULL, NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2176, 1, "HAMNKONTORET, OESTRA KAJEN", NULL, 
NULL, NULL, "S-37 435 KARLSHAMN", NULL, "S", NULL, NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2177, 1, 
"C/O MARUBENI CORP TOKYO  1-4-2 OTEMACHI,", NULL, NULL, NULL, "TOKYO", NULL, 
"J", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2178, 1, 
"2000 CANTERRA TOWER  400 3RD AVENUE SW", NULL, NULL, NULL, 
"CALGARY ALBERTA, T2P5A6", NULL, "CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2179, 1, "SE 403 30", NULL, NULL, NULL, 
"GOTHENBURG", NULL, "S", NULL, "4631616030", "5421060", "4631616036", 
"BROTANK S", NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2180, 1, "POB 47", "S-430 82", NULL, NULL, 
"DONSO", NULL, "S", NULL, "4631145080", "20019", "4631423105", "RAMONIA S+", 
NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2181, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2182, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2183, 1, "DR WILLEM DREESWEG 2", NULL, NULL, 
NULL, "1185 VB AMSTELVEEN", NULL, "NL", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2184, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2185, 1, "15901 RED HILL AVE., SUITE 100", 
NULL, NULL, NULL, "TUSTIN", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2186, 1, "PARKSTRASSE 23", NULL, NULL, NULL, 
"CH-5401 BADEN", NULL, "CH", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2187, 1, ".", NULL, NULL, NULL, ".", NULL, 
"F", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2188, 1, ".", NULL, NULL, NULL, ".", NULL, 
"SGP", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2189, 1, "101 THOMSON ROAD", 
"#23-04/05 UNITED SQUARE", NULL, NULL, ".", NULL, "SGP", "307591", NULL, NULL, 
NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2190, 1, "99 SUFFOLK STREET", NULL, NULL, 
NULL, "HOLYOKE", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2191, 1, "WIENERBERGSTRASSE 3", NULL, NULL, 
NULL, "A-1100 VIENNA", NULL, "A", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2192, 1, "MOERVAARTKAAI 12", NULL, NULL, 
NULL, "B-9042 GENT", NULL, "B", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2193, 1, ".", ".", NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2194, 1, "QUEENS DOCK MARINE TERMINAL", NULL, 
NULL, NULL, "SWANSEA SA1 8QR", NULL, "UK", NULL, NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2195, 1, "10777 WESTHEIMER, SUITE 955", NULL, 
NULL, NULL, "HOUSTON", NULL, "USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2196, 1, ".", NULL, NULL, NULL, ".", NULL, 
"IL", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2197, 1, 
"101 THOMSON ROAD  #21-05/06 UNITED SQUAR", NULL, NULL, NULL, "307591", NULL, 
"SGP", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2198, 1, "130 EAST RANDOLPH DR  22ND FLOOR", 
NULL, NULL, NULL, "CHICAGO", "IL", "USA", "60601", NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2199, 1, "OVERGADE 45", NULL, NULL, NULL, 
"DK 7000 FREDERICIA", NULL, "DK", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2200, 1, "166 HAWTHORNE AVE", NULL, NULL, 
NULL, "GLEN RIDGE", NULL, "USA", "07028", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2201, 1, 
"SUBDIRECCCION DE GAS NATURAL  AV. MARINA", NULL, NULL, NULL, 
"COL. HUASTECA 11311", NULL, "MEX", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2202, 1, ".", NULL, NULL, NULL, ".", NULL, 
"BRD", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2203, 1, "C/O ITOCHU CORPORATION", 
"5-1 KITA-AOYAMA 2-CHOME", "MINATO-KU", NULL, "TOKYO  107-8077", NULL, "J", 
NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2204, 1, "BAHNHOFSTRASSE 30", "POSTFACH", 
NULL, NULL, "ZUG CH-6307", NULL, "CH", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2205, 1, ".", NULL, NULL, NULL, 
"CH-7742 POSCHIAVO", NULL, "CH", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2206, 1, "PO BOX 24027", NULL, NULL, NULL, 
"KUWAIT, SAFAT 13101", NULL, "KWT", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2207, 1, "6345 DIXIE RD", "SUITE 40", NULL, 
NULL, "MISSISSOUGA", NULL, "CDN", "L5T 2E6", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2208, 1, "ELBEHARBOUR", NULL, NULL, NULL, 
"25541 BRUNSBUETTEL", NULL, "BRD", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2209, 1, "PO BOX 99", NULL, NULL, NULL, 
"WESTWEGO", "LA", "USA", "70096-0099", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2210, 1, ".", NULL, NULL, NULL, ".", NULL, 
"CDN", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2211, 1, "22 RUE MUSTEL", "PO BOX 4013", 
NULL, NULL, "76021 ROUEN CEDEX", NULL, "F", NULL, NULL, NULL, NULL, NULL, NULL, 
"A", NULL, NULL, 1)
go

insert into account_address values(2212, 1, "WINDMILL HILL BUSINESS PARK", 
"WHITEHILL WAY", "SWINDON", NULL, "WILTSHIRE SN5 6PB", NULL, "UK", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2213, 1, "14-04 111TH STREET", NULL, NULL, 
NULL, "COLLEGE POINT", "NY", "USA", "11356", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2214, 1, "ST. PAULUSSTRAAT 42", NULL, NULL, 
NULL, "2000 ANTWERP", NULL, "B", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2215, 1, "VESTKE HAVNEPLADS 5 B", NULL, NULL, 
NULL, "DK-4400 KALUNDBORG", NULL, "DK", NULL, "45 59562116", NULL, 
"45 30633117", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2216, 1, "555 17TH STREET", "SUITE 1950", 
NULL, NULL, "DENVER", "CO", "USA", "80202", NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2217, 1, "STORTORGET 8", NULL, NULL, NULL, 
"21134 MALMO", NULL, "S", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 
1)
go

insert into account_address values(2218, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2219, 1, "92569 RUEIL MALMAISON", NULL, NULL, 
NULL, ".", NULL, "F", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2220, 1, "BRUMBY HOUSE, 1ST FLOOR", 
"JALAN BAHASA", "PO BOX 80184", NULL, "87011 LABUAN F.T. MALAYSIA", NULL, "MAL", 
NULL, "(60-87) 427768", "MA85047", "(60-87) 426768", NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2221, 1, "C/P MANAGERS ADDRESS", 
"AKTI THEMISTOKLEOUS & IGIAS 1-3", NULL, NULL, "PIRAEUS", NULL, "GR", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2222, 1, "32 QUAI DES AMERICAINS", NULL, 
NULL, NULL, "F-56140 DUNKERQUE", NULL, "F", NULL, "33 328 63 51 85", "132429", 
"33 328 65 17 05", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2223, 1, "C/O TRANSPETROL", 
"CHAUSSEE DE LA HULPE", NULL, NULL, "150 1170 BRUSSELS", NULL, "B", NULL, 
"32 2 672 02 00", "20020", "32 2 675 52 57", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2224, 1, "3 TEMASEK AVENUE, #31-02", 
"CENTENNIAL TOWER", NULL, NULL, "039190", NULL, "SGP", NULL, "65-333 1488", 
"RS 36390 BB ASI", "65-333 1477", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2225, 1, "BEREICH HANDEL", 
"TRESCKOWSTRASSE 5", NULL, NULL, "30457 HANNOVER", NULL, "BRD", NULL, NULL, 
NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2226, 1, "BEREICH HANDEL", 
"NYMPHENBURGER STRASSE 39", NULL, NULL, "80355 MUNCHEN", NULL, "BRD", NULL, 
NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2227, 1, "7660 WOODWAY", "SUITE 250", NULL, 
NULL, "HOUSTON", "TX", "USA", "77063", NULL, NULL, NULL, NULL, NULL, "A", NULL, 
NULL, 1)
go

insert into account_address values(2228, 1, ".", NULL, NULL, NULL, ".", NULL, 
"IRL", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2229, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2230, 1, "THE LAKE BUILDING", "SUITE 120", 
"WICKHAMS CAY 1", "ROAD TOWN", "TORTOLA", NULL, "VIU", NULL, NULL, NULL, NULL, 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2231, 1, "1221 LAMAR, SUITE 1600", NULL, 
NULL, NULL, "HOUSTON", "TX", "USA", "77010-3039", "713-756-1837", NULL, 
"713-756-1842", NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2232, 1, "DAEMNINGEN 28", "PO BOX 55", NULL, 
NULL, "DK 7100 VEJLE", NULL, "DK", NULL, NULL, NULL, NULL, NULL, NULL, "A", 
NULL, NULL, 1)
go

insert into account_address values(2233, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2234, 1, "SPORTALLEE 6", NULL, NULL, NULL, 
"D-22335 HAMBURG", NULL, "BRD", NULL, "49 40 51430394", NULL, "49 40 51430395", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2235, 1, "1500 OXFORD DRIVE", NULL, NULL, 
NULL, "BETHEL PARK", NULL, "USA", "15102", "412 851 0200", NULL, "412 851 1441", 
NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2236, 1, ".", NULL, NULL, NULL, ".", NULL, 
"USA", NULL, NULL, NULL, NULL, NULL, NULL, "A", NULL, NULL, 1)
go

insert into account_address values(2237, 1, "9337-B KATY FREEWAY", "SUITE 285", 
NULL, NULL, "HOUSTON", "TX", "USA", "77024", "713-827-8778", NULL, 
"713-827-8178", NULL, NULL, "A", NULL, NULL, 1)
go

