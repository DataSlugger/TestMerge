print 'Loading additional seed data into the account_credit_info table ...'
go

/*
 account_credit_info 
    acct_num               int             NOT NULL,
    cr_status              char(1)         NOT NULL,
    dflt_cr_anly_init      char(3)         NOT NULL,
    primary_sic_num        smallint        NULL,
    acct_bus_desc          varchar(40)     NULL,

    first_trade_date       datetime        NULL,
    doing_bus_since_date   datetime        NULL,
    acct_cr_info_source    varchar(40)     NULL,
    fiscal_year_end_date   datetime        NULL,

    last_fin_doc_date      datetime        NULL,
    acct_fin_rep_freq      char(1)         NULL,
    confident_ind          char(1)         NULL,
    confident_sign_name    varchar(40)     NULL,
    acct_audit_code        varchar(100)    NULL,

    invoice_freq           char(1)         NULL,
    invoice_date           datetime        NULL,
    invoice_formula        varchar(40)     NULL,
    dflt_telex_hold_ind    char(1)         NOT NULL,

    bus_restriction_type   char(1)         NOT NULL,
    dflt_cr_term_code      char(8)         NOT NULL,
    country_code           char(8)         NOT NULL,
    pvt_ind_code           char(8)         NULL,
    bank_telex_cap_ind     char(1)         NULL,
    pei_guarantee_ind      char(1)         NULL,
    broker_pns_type        char(1)         NULL,
    cmnt_num               int             NULL,
    exposure_priority_code char(1)         NOT NULL,
    prim_cr_term_code      char(8)         NULL,
    sec_cr_term_code       char(8)         NULL,
    credit_agency_acct_num int             NULL,
    credit_rating          char(10)        NULL,

    trans_id               int             NOT NULL,
    country_risk           char(8)         NULL,
    pvt_public_desc        varchar(255)    NULL,
    use_dflt_cr_info       char(1)         NULL,
    sector_code	           char(4)         NULL,
    acct_bus_desc1	       varchar(80)     NULL,
    acct_bus_desc2	       varchar(80)     NULL
    margin_doc_email	     varchar(40)	   NULL,
    minimum_transfer_amt	 numeric(20, 8)  NULL
*/

insert into dbo.account_credit_info values(3, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'I', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(4, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'CH', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(5, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'SGP', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(6, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'B', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(7, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'J', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(8, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(9, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'SGP', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(11, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'I', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(12, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(13, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(14, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(15, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(16, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'CH', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(17, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(18, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(19, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'BS', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(20, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(21, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'RC', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(22, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(23, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(24, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(25, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(26, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'BER', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(27, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(28, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'NL', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(29, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(30, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(31, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(32, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(33, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'N', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(34, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(35, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(36, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(37, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(38, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(39, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'BRD', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(40, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(41, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(42, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(43, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(44, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'CH', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(45, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(46, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(47, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'NL', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(48, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(49, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'F', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(50, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(51, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(52, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(53, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(54, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(55, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(56, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'VIU', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(57, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(58, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'IRL', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(59, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'SGP', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(60, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'J', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(61, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'HK', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(62, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(63, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(64, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'SGP', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(65, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(66, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(67, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(68, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'J', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(69, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(70, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(71, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(72, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(73, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(74, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(75, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(76, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(77, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(78, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(79, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'SGP', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(80, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(81, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'SF', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(82, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'N', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(83, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'J', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(84, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'J', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(85, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'CDN', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(86, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(87, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GR', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(88, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'S', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(89, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(90, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'B', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(91, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GC', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(92, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(93, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(94, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(95, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(96, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'N', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(97, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(98, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(99, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(100, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'F', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(101, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'F', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(102, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'N', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(103, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(104, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'CDN', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(105, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(106, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(107, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(108, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(109, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(110, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(111, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(112, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(113, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(114, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(115, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(116, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'BER', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(117, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(118, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(119, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'SGP', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(120, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(121, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(122, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'SGP', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(123, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(124, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(125, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(126, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(127, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(128, '~', 'ICU', NULL, 'DFLT', NULL, 
'Jul 31 2037 12:00:00', NULL, 'Jul 31 2037 12:00:00', 'Jul 31 2037 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 'SEE CRDT', 'USA', NULL, 
'~', '~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(129, '~', 'ICU', NULL, 'DFLT', NULL, 
'Aug 31 2037 12:00:00', NULL, 'Aug 31 2037 12:00:00', 'Aug 31 2037 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 'SEE CRDT', 'MEX', NULL, 
'~', '~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(130, '~', 'ICU', NULL, 'DFLT', NULL, 
'Nov  4 2037 12:00:00', NULL, 'Nov  4 2037 12:00:00', 'Nov  4 2037 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 'SEE CRDT', 'SGP', NULL, 
'~', '~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(131, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(132, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(133, '~', 'ICU', NULL, 'DFLT', NULL, 
'Dec 31 1969 12:00:00', NULL, 'Dec 31 1969 12:00:00', 'Dec 31 1969 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, 
'~', '~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(134, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(135, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(136, '~', 'ICU', NULL, 'DFLT', NULL, 
'Dec 31 1969 12:00:00', NULL, 'Dec 31 1969 12:00:00', 'Dec 31 1969 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 'SEE CRDT', 'USA', NULL, 
'~', '~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(137, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(138, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(139, '~', 'ICU', NULL, 'DFLT', NULL, 
'Dec 31 1969 12:00:00', NULL, 'Dec 31 1969 12:00:00', 'Dec 31 1969 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 'SEE CRDT', 'NL', NULL, '~', 
'~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(140, '~', 'ICU', NULL, 'DFLT', NULL, 
'Dec 31 1969 12:00:00', NULL, 'Dec 31 1969 12:00:00', 'Dec 31 1969 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 'SEE CRDT', 'USA', NULL, 
'~', '~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(141, '~', 'ICU', NULL, 'DFLT', NULL, 
'Dec 31 1969 12:00:00', NULL, 'Dec 31 1969 12:00:00', 'Dec 31 1969 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 'SEE CRDT', 'USA', NULL, 
'~', '~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(142, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(143, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(144, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(145, '~', 'ICU', NULL, 'DFLT', NULL, 
'Dec 31 1969 12:00:00', NULL, 'Dec 31 1969 12:00:00', 'Dec 31 1969 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, 
'~', '~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(146, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(147, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(148, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(149, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(150, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(151, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(152, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(153, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(154, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'CH', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(155, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(156, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(157, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(158, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(159, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(160, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(161, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(162, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(163, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(164, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(165, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(166, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(167, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(168, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'CH', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(169, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(170, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(171, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(172, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'NONE-SRV', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(173, '~', 'ICU', NULL, 'DFLT', NULL, 
'Dec 31 1969 12:00:00', NULL, 'Dec 31 1969 12:00:00', 'Dec 31 1969 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 'SEE CRDT', 'NL', NULL, '~', 
'~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(174, '~', 'ICU', NULL, 'DFLT', NULL, 
'Dec 31 1969 12:00:00', NULL, 'Dec 31 1969 12:00:00', 'Dec 31 1969 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 'SEE CRDT', 'GB', NULL, '~', 
'~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(175, '~', 'ICU', NULL, 'DFLT', NULL, 
'Dec 31 1969 12:00:00', NULL, 'Dec 31 1969 12:00:00', 'Dec 31 1969 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 'SEE CRDT', 'VIU', NULL, 
'~', '~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(176, '~', 'ICU', NULL, 'DFLT', NULL, 
'Dec 31 1969 12:00:00', NULL, 'Dec 31 1969 12:00:00', 'Dec 31 1969 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 'SEE CRDT', 'USA', NULL, 
'~', '~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(177, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'NONE-SRV', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(178, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'UK', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(179, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'CDN', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(180, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'UK', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(181, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'B', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(182, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'GB', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(183, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'SGP', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(184, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'S', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(185, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'SGP', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(186, '~', 'ICU', NULL, 'DFLT', NULL, 
'Dec 31 1969 12:00:00', NULL, 'Dec 31 1969 12:00:00', 'Dec 31 1969 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 'SEE CRDT', 'NL', NULL, '~', 
'~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(187, '~', 'ICU', NULL, 'DFLT', NULL, 
'Dec 31 1969 12:00:00', NULL, 'Dec 31 1969 12:00:00', 'Dec 31 1969 12:00:00', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, 
'~', '~', NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(188, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(189, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'SGP', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(190, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'SGP', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(191, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(192, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(193, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(194, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(195, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(196, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(197, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(198, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(199, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(200, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(201, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(202, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(203, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(204, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(205, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(206, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(207, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(208, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(209, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(210, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(211, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(212, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(213, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(214, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(215, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(216, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(217, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(218, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(219, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(220, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(221, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, 
NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(222, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(223, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(224, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(225, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(226, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(227, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(228, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(229, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(230, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(231, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(232, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(233, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(234, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(235, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(236, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(237, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(238, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(239, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(240, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(241, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(242, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(243, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(244, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(245, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(246, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(247, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(248, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(249, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(250, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(251, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(252, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(253, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'IFRLC', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, 
NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(254, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(255, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(256, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(257, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(258, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(259, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(260, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(261, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(262, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(263, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(264, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(265, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(266, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(267, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(268, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(269, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(270, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(271, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(272, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(273, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(274, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(275, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(276, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(277, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(278, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(279, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(280, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(281, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(282, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(283, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(284, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(285, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(286, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(287, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(288, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(289, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(290, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(291, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(292, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(293, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(294, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(295, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(296, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SBLC', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(297, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(298, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(299, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(300, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(301, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(302, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(303, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(304, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(305, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(306, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(307, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(308, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(309, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'S', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, 
NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(310, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(311, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(312, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(313, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(314, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(315, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(316, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(317, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(318, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(319, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(320, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(321, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(322, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(323, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(324, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(325, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(326, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(327, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(328, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(329, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(330, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(331, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(332, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(333, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(334, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(335, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(336, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(337, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(338, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(339, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(340, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(341, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(342, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(343, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(344, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(345, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(346, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(347, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(348, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(349, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(350, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(351, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(352, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(353, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'UK', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, 
NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(354, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(355, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(356, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'SEE CRDT', 'UK', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(357, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(358, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(359, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(360, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(361, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(362, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(363, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(364, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(365, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'UK', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, 
NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(366, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(367, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'S', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, 
NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(368, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(369, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(370, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(371, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(372, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(373, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(374, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(375, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(376, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'UK', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, 
NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(377, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(378, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(379, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(380, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(381, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(382, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(383, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(384, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(385, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'CH', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, 
NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(386, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(387, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(388, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(389, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(390, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(391, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(392, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(393, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(394, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(395, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(396, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(397, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SBLC', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(398, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(399, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(400, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(401, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(402, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(403, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(404, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(405, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(406, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(407, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(408, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(409, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(410, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(411, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(412, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(413, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(414, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(415, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(416, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(417, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(418, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(419, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(420, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(421, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(422, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(423, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(424, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(425, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(426, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(427, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(428, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(429, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(430, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(431, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(432, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(433, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(434, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(435, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(436, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(437, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(438, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(439, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(440, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(441, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(442, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(443, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(444, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(445, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(446, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(447, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(448, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(449, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(450, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(451, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(452, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(453, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(454, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(455, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(456, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(457, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(458, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(459, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(460, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(461, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(462, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(463, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(464, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(465, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(466, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(467, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(468, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(469, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(470, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(471, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(472, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(473, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(474, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(475, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(476, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(477, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(478, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(479, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(480, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(481, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(482, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(483, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(484, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(485, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(486, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(487, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(488, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(489, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(490, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(491, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(492, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(493, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(494, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(495, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(496, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(497, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(498, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(499, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(500, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(501, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(502, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(503, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(504, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(505, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(506, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(507, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(508, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(509, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(510, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(511, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(512, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(513, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(514, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(515, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(516, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(517, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(518, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(519, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(520, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(521, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(522, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(523, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(524, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(525, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(526, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(527, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(528, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(529, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(530, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(531, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(532, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(533, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(534, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(535, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(536, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(537, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(538, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(539, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(540, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(541, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(542, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(543, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(544, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(545, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(546, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(547, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(548, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(549, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(550, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(551, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(552, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(553, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(554, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(555, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(556, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(557, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(558, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(559, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(560, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(561, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(562, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(563, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(564, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(565, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(566, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(567, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(568, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(569, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(570, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(571, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(572, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(573, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(574, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(575, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(576, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(577, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(578, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(579, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(580, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(581, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(582, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(583, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(584, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(585, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(586, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(587, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(588, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(589, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(590, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(591, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(592, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(593, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(594, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(595, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(596, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(597, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(598, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(599, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(600, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(601, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(602, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(603, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(604, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(605, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(606, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(607, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(608, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(609, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(610, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(611, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(612, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(613, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(614, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(615, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(616, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(617, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(618, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(619, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(620, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(621, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(622, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(623, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(624, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(625, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(626, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(627, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(628, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(629, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(630, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(631, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(632, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(633, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(634, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(635, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(636, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(637, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(638, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(639, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(640, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(641, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(642, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(643, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(644, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(645, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(646, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(647, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(648, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(649, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(650, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(651, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(652, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(653, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(654, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(655, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(656, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(657, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(658, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(659, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(660, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(661, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(662, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(663, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(664, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(665, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(666, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(667, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(668, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(669, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(670, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(671, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(672, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(673, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(674, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(675, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(676, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(677, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(678, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(679, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(680, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(681, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(682, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(683, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(684, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(685, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(686, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(687, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(688, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(689, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(690, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(691, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(692, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(693, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(694, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(695, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(696, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(697, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(698, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(699, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(700, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(701, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(702, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(703, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(704, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(705, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(707, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(708, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(709, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(710, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(711, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(712, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(713, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(714, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(715, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(716, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(717, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(718, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(719, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(720, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(721, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(722, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(723, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(724, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(725, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(726, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(727, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(728, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(729, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(730, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(731, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(732, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(733, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(734, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(735, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(736, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(737, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(738, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(739, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(740, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(741, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(742, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(743, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(744, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(745, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(746, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(747, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(748, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(749, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(750, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(751, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(752, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(753, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(754, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(755, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(756, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(757, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(758, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(759, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(760, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(761, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(762, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(763, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(764, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(765, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(766, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(767, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(768, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(769, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(770, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(771, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(772, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(773, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(774, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(775, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(776, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(777, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(778, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(779, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(780, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(781, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(782, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(783, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(784, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(785, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(786, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(787, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(788, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(789, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(790, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(791, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(792, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(793, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(794, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(795, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(796, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(797, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(798, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(799, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(800, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(801, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(802, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(803, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(804, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(805, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(806, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(807, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(808, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(809, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(810, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(811, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(812, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(813, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(814, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(815, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(816, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(817, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(818, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(819, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(820, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(821, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(822, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(823, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(824, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(825, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(826, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(827, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(828, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(829, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(830, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(831, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(832, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(833, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(834, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(835, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(836, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(837, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(838, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(839, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(840, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(841, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(842, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(843, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(844, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(845, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(846, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(847, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(848, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(849, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(850, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(851, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(852, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(853, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(854, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(855, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(856, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(857, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(858, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(859, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(860, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(861, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(862, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(863, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(864, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(865, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(866, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(867, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(868, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(869, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(870, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(871, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(872, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(873, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(874, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(875, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(876, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(877, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(878, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(879, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(880, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(881, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(882, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(883, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(884, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(885, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(886, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(887, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(888, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(889, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(890, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(891, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(892, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(893, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(894, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(895, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(896, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(897, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(898, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(899, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(900, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(901, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(902, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(903, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(904, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(905, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(906, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(907, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(908, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(909, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(910, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(911, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(912, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(913, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(914, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(915, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(916, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(917, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(918, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(919, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(920, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(921, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(922, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(923, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(924, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(925, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(926, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(927, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(928, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(929, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(930, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(931, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(932, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(933, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(934, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(935, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(936, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(937, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(938, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(939, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(940, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(941, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(942, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(943, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(944, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(945, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(946, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(947, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(948, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(949, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(950, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(951, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(952, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(953, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(954, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(955, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(956, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(957, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(958, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(959, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(960, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(961, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(962, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(963, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(964, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(965, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(966, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(967, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(968, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(969, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(970, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(971, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(972, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(973, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(974, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(975, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(976, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(977, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(978, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(979, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(980, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(981, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(982, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(983, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(984, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(985, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(986, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(987, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(988, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(989, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(990, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(991, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(992, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(993, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(994, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(995, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(996, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(997, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(998, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(999, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1000, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1001, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1002, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1003, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1004, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1005, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1006, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1007, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1008, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1009, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1010, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1011, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1012, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1013, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1014, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1015, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1016, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1017, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1018, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1019, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1020, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1021, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1022, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1023, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1024, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1025, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1026, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1027, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1028, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1029, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1030, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1031, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1032, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1033, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1034, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1035, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1036, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1037, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1038, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1039, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1040, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1041, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1042, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1043, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1044, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1045, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1046, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1047, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1048, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1049, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1050, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1051, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1052, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1053, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1054, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1055, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1056, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1057, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1058, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1059, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1060, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1061, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1062, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1063, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1064, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1065, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1066, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1067, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1068, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1069, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1070, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1071, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1072, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1073, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1074, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1075, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1076, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1077, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1078, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1079, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1080, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1081, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1082, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1083, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1084, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1085, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1086, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1087, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1088, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1089, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1090, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1091, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1092, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1093, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1094, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1095, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1096, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1097, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1098, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1099, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1100, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1101, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1102, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1103, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1104, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1105, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1106, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1107, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1108, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1109, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1110, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1111, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1112, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1113, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1114, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1115, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1116, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1117, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1118, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1119, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1120, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1121, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1122, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1123, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1124, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1125, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1126, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1127, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1128, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1129, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1130, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1131, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1132, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1133, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1134, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1135, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1136, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1137, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1138, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1139, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1140, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1141, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1142, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1143, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1144, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1145, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1146, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1147, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1148, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1149, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1150, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1151, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1152, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1153, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1154, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1155, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1156, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1157, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1158, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1159, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1160, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1161, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1162, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1163, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1164, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1165, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1166, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1167, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1168, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1169, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1170, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1171, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1172, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1173, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1174, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1175, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1176, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1177, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1178, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1179, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1180, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1181, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1182, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1183, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1184, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1185, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1186, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1187, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1188, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1189, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1190, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1191, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1192, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1193, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1194, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1195, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1196, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1197, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1198, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1199, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1200, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1201, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1202, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1203, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1204, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1205, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1206, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1207, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1208, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1209, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1210, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1211, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1212, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1213, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1214, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1215, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1216, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1217, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1218, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1219, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1220, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1221, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1222, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1223, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1224, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1225, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1226, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1227, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1228, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1229, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1230, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1231, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1232, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1233, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1234, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1235, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1236, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1237, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1238, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1239, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1240, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1241, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1242, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1243, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1244, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1245, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1246, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1247, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1248, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1249, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1250, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1251, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1252, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1253, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1254, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1255, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SBLC', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, 
NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1256, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1257, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1258, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1259, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1260, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1261, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1262, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1263, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1264, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1265, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1266, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1267, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1268, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1269, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1270, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1271, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1272, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1273, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1274, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1275, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1276, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1277, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1278, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1279, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1280, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1281, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1282, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1283, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1284, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1285, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1286, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1287, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1288, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1289, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1290, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1291, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1292, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1293, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1294, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1295, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1296, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1297, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1298, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1299, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1300, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1301, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1302, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1303, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1304, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1305, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1306, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1307, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1308, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1309, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1310, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1311, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1312, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1313, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1314, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1315, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1316, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1317, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1318, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1319, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1320, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1321, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1322, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1323, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1324, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1325, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1326, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1327, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1328, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1329, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1330, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1331, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1332, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1333, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1334, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1335, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1336, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1337, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1338, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1339, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1340, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1341, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1342, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1343, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1344, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1345, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1346, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1347, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1348, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1349, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1350, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1351, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1352, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1353, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1354, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1355, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1356, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1357, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1358, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1359, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1360, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1361, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1362, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1363, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1364, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1365, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1366, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1367, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1368, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1369, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1370, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1371, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1372, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1373, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1374, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1375, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1376, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1377, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1378, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1379, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1380, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1381, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1382, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1383, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1384, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1385, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1386, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1387, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1388, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1389, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1390, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1391, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1392, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1393, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1394, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1395, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1396, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1397, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1398, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1399, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1400, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1401, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1402, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1403, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1404, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1405, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1406, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1407, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1408, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1409, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1410, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1411, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1412, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1413, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1414, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1415, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1416, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1417, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1418, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1419, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1420, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1421, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1422, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1423, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1424, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1425, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1426, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1427, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1428, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1429, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1430, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1431, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1432, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1433, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1434, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1435, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1436, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1437, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1438, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1439, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1440, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1441, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1442, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1443, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1444, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1445, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1446, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1447, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1448, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1449, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1450, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1451, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1452, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1453, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1454, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1455, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1456, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1457, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1458, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1459, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1460, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1461, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1462, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1463, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1464, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1465, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1466, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1467, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1468, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1469, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1470, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1471, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1472, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1473, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1474, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1475, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1476, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1477, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1478, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1479, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1480, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1481, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1482, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1483, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1484, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1485, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1486, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1487, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1488, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1489, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1490, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1491, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1492, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1493, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1494, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1495, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1496, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1497, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1498, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1499, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1500, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1501, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1502, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1503, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1504, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1505, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1506, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1507, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1508, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1509, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1510, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1511, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1512, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1513, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1514, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1515, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1516, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1517, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1518, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1519, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1520, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1521, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1522, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1523, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1524, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1525, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1526, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1527, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1528, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1529, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1530, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1531, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1532, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1533, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1534, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1535, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1536, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1537, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1538, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1539, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1540, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1541, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1542, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1543, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1544, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1545, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1546, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1547, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1548, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1549, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1550, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1551, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1552, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1553, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1554, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1555, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1556, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1557, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1558, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1559, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1560, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1561, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1562, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1563, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1564, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1565, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1566, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1567, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1568, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1569, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1570, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1571, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1572, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1573, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1574, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1575, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1576, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1577, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1578, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1579, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1580, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1581, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1582, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1583, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1584, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1585, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1586, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1587, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1588, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1589, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1590, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1591, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1592, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1593, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1594, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1595, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1596, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1597, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1598, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1599, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1600, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1601, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1602, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1603, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1604, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1605, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1606, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1607, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1608, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1609, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1610, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1611, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1612, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1613, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1614, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1615, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1616, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1617, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1618, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1619, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1620, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1621, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1622, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1623, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1624, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1625, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1626, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1627, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1628, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1629, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1630, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1631, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1632, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1633, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1634, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1635, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1636, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1637, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1638, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1639, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1640, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1641, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1642, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1643, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1644, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1645, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1646, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1647, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1648, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1649, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1650, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1651, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1652, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1653, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1654, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1655, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1656, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1657, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1658, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1659, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1660, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1661, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1662, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1663, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1664, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1665, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1666, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1667, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1668, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1669, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1670, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1671, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1672, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1673, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1674, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1675, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1676, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1677, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1678, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1679, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1680, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1681, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1682, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1683, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1684, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1685, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1686, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1687, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1688, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1689, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1690, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1691, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1692, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1693, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1694, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1695, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1696, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1697, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1698, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1699, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'LC', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, 
NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1700, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1701, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1702, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1703, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1704, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1705, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1706, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1707, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1708, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1709, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1710, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1711, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1712, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1713, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1714, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1715, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1716, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1717, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1718, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1719, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1720, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1721, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1722, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1723, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1724, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1725, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1726, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1727, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1728, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1729, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1730, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1731, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1732, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1733, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1734, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1735, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1736, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1737, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1738, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1739, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1740, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1741, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1742, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1743, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1744, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1745, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1746, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1747, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'OPENLCPP', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1748, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1749, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1750, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1751, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1752, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1753, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1754, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1755, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1756, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1757, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1758, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1759, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1760, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1761, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1762, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1763, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1764, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1765, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1766, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1767, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1768, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1769, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'PPSBLC', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, 
NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1770, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1771, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1772, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1773, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1774, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1775, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1776, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1777, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1778, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1779, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1780, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1781, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1782, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1783, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1784, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1785, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1786, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1787, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1788, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1789, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1790, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1791, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1792, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1793, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1794, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1795, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1796, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1797, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1798, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1799, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1800, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1801, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1802, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1803, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1804, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1805, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1806, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1807, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1808, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1809, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1810, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1811, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1812, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1813, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1814, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1815, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1816, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1817, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1818, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1819, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1820, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1821, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1822, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1823, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1824, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1825, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1826, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1827, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1828, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1829, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1830, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1831, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1832, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1833, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1834, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1835, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1836, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1837, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1838, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1839, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1840, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1841, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1842, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1843, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1844, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1845, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1846, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1847, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1848, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1849, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1850, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1851, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1852, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1853, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1854, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1855, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1856, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1857, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1858, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1859, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1860, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1861, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1862, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1863, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1864, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1865, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1866, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1867, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1868, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1869, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1870, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1871, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1872, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1873, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1874, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1875, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1876, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1877, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1878, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1879, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1880, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1881, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1882, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1883, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1884, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1885, 'A', 'ICA', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'OPEN', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1886, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1887, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1888, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1889, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1890, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1891, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1892, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1893, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1894, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1895, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1896, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1897, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1898, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1899, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1900, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1901, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1902, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1903, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1904, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1905, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1906, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1907, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1908, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1909, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1910, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1911, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1912, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1913, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1914, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1915, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1916, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1917, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1918, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1919, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1920, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1921, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1922, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1923, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1924, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1925, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1926, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1927, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1928, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1929, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1930, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1931, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1932, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1933, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1934, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1935, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1936, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1937, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1938, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1939, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1940, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1941, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1942, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1943, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1944, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1945, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1946, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1947, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1948, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1949, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1950, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1951, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1952, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1953, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1954, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1955, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1956, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1957, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1958, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1959, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1960, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1961, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1962, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1963, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1964, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1965, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1966, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1967, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1968, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1969, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1970, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1971, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1972, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1973, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1974, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1975, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1976, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1977, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1978, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1979, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1980, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1981, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1982, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1983, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1984, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1985, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1986, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1987, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1988, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1989, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1990, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1991, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1992, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1993, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1994, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1995, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1996, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1997, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1998, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(1999, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2000, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2001, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2002, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2003, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2004, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2005, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2006, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2007, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2008, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2009, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2010, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2011, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2012, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2013, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2014, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2015, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2016, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2017, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2018, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2019, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2020, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2021, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2022, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2023, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2024, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2025, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2026, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2027, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2028, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2029, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2030, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2031, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2032, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2033, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2034, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2035, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2036, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2037, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2038, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2039, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2040, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2041, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2042, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2043, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2044, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2045, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2046, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2047, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2048, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2049, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2050, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2051, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2052, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2053, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2054, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2055, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2056, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2057, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2058, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2059, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2060, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2061, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2062, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2063, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2064, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2065, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2066, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2067, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2068, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2069, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2070, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2071, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2072, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2073, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2074, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2075, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2076, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2077, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2078, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2079, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2080, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2081, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2082, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2083, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2084, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2085, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2086, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2087, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2088, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2089, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2090, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2091, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2092, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2093, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2094, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2095, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2096, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2097, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2098, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2099, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2100, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2101, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2102, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2103, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2104, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2105, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2106, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2107, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2108, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2109, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2110, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2111, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2112, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2113, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2114, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2115, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2116, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2117, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2118, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2119, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2120, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2121, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2122, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2123, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2124, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2125, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2126, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2127, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2128, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2129, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2130, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2131, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2132, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2133, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2134, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2135, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2136, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2137, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2138, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2139, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2140, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2141, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2142, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2143, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2144, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2145, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2146, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2147, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2148, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2149, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2150, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2151, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2152, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2153, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2154, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2155, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2156, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2157, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2158, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2159, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2160, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2161, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2162, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2163, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2164, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2165, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2166, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2167, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2168, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2169, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2170, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2171, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2172, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2173, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2174, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2175, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2176, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2177, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2178, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2179, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2180, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2181, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2182, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2183, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2184, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2185, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2186, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2187, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2188, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2189, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2190, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2191, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2192, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2193, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2194, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2195, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2196, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2197, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2198, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2199, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2200, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2201, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2202, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2203, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2204, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2205, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2206, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2207, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2208, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2209, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2210, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2211, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2212, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2213, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2214, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2215, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2216, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2217, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2218, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2219, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2220, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2221, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2222, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2223, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2224, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2225, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2226, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2227, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2228, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2229, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2230, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2231, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2232, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2233, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2234, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2235, 'A', 'ICU', NULL, 'DFLT', 
'Jan  1 1900 12:00:00', 'Jan  1 1900 12:00:00', NULL, 'Jan  1 1900 12:00:00', 
'Jan  1 1900 12:00:00', NULL, NULL, NULL, NULL, NULL, 'Jan  1 1900 12:00:00', 
NULL, 'Y', 'U', 'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, 
NULL, NULL, NULL, 1, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2236, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y', 'U', 
'SEE CRDT', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

insert into dbo.account_credit_info values(2237, 'A', 'ICU', NULL, 'DFLT', NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'U', 
'NONE-SRV', 'USA', NULL, NULL, NULL, NULL, NULL, 'R', NULL, NULL, NULL, NULL, 1, 
NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL)
go

