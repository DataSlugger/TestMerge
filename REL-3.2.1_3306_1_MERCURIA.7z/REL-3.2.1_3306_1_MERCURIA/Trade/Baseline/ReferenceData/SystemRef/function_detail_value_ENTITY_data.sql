set nocount on

set QUOTED_IDENTIFIER ON
go

print ' '
print 'Adding new function_detail_value records for the function ''EDIT'' (EntityTagEditor) ...'
go

declare @entity_tag_name    varchar(16),
        @function_num       int,
        @fd_id              int,
	      @fdv_id             int,
	      @rows_affected      int,
	      @total_rows_added   int,
        @smsg               varchar(255),
        @errcode            int

select @errcode = 0,
       @total_rows_added = 0
select @function_num = function_num
from dbo.icts_function
where app_name = 'EntityTagEditor' and
      function_name = 'EDIT'

if @function_num is null
begin
   select @errcode = 1
   print '=> Could not find the icts_function record for the apps ''EntityTagEditor'' and the function ''EDIT''!'
   goto endofscript
end

select @fd_id = fd_id
from dbo.function_detail
where function_num = @function_num and
      entity_name = 'EntityTagDefinition' and 
      attr_name = 'entityTagName' and
      operation = '='

if @fd_id is null
begin
   select @errcode = 1
   print '=> Could not find the function_detail record for the entity ''EntityTagDefinition'' and the attr ''entityTagName''!'
   goto endofscript
end

select @entity_tag_name = min(entity_tag_name)
from dbo.entity_tag_definition

while @entity_tag_name is not null
begin
   select @smsg = '=> Adding a function_detail_value record for the tag ''' + @entity_tag_name + ''' if NOT EXISTS ...'
   print @smsg
   select @fdv_id = null
   select @fdv_id = fdv_id
   from dbo.function_detail_value
   where fd_id = @fd_id and
         data_type = 'S' and
         attr_value = @entity_tag_name
         
   if @fdv_id is not null
   begin
      print '==> The record has already existed'
      goto nexttag
   end
     
   begin tran
   select @fdv_id = isnull(max(fdv_id), 0) + 1
   from dbo.function_detail_value
   
   begin try
     insert into dbo.function_detail_value
         (fdv_id, fd_id, data_type, attr_value, trans_id)
        values(@fdv_id, @fd_id, 'S', @entity_tag_name, 1)        
     select @rows_affected = @@rowcount
     commit tran
   end try
   begin catch
     print ERROR_MESSAGE()
     if @@trancount > 0
        rollback tran
     select @smsg = '==> Failed to insert a new record into the function_detail_value table for the tag ''' + @entity_tag_name + '''!'
     print @smsg
     goto endofscript
   end catch
   if @rows_affected > 0
   begin
      select @total_rows_added = @total_rows_added + @rows_affected
      select @smsg = '==> A record was added successfully' 
      print @smsg
   end

nexttag:     
   select @entity_tag_name = min(entity_tag_name)
   from dbo.entity_tag_definition
   where entity_tag_name > @entity_tag_name        
end
endofscript:
print ' '
if @errcode = 0 and @total_rows_added > 0
begin
   select @smsg = 'function_detail_value (ENTITY ): ' + cast(@total_rows_added as varchar) + ' were successfully added'
   print @smsg
end
go

                                                                                     
exec dbo.refresh_a_last_num 'function_detail_value', 'fdv_id'
go
