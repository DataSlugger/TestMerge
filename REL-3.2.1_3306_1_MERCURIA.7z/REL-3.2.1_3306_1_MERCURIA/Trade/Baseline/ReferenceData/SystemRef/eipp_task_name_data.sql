set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the eipp_task_name table ...'
go

if not exists (select 1 from dbo.eipp_task_name
               where oid = 1 and task_name = 'DueDateChange')
begin
   INSERT dbo.eipp_task_name (oid, task_name, direction, trans_id) 
   VALUES (1, 'DueDateChange', 'I', 1)
end
go

if not exists (select 1 from dbo.eipp_task_name
               where oid = 2 and task_name = 'InvoiceAssignment')
begin
   INSERT dbo.eipp_task_name (oid, task_name, direction, trans_id) 
   VALUES (2, 'InvoiceAssignment', 'I', 1)
end
go

if not exists (select 1 from dbo.eipp_task_name
               where oid = 3 and task_name = 'Settlement')
begin
   INSERT dbo.eipp_task_name (oid, task_name, direction, trans_id) 
   VALUES (3, 'Settlement', 'O', 1)
end
go

if not exists (select 1 from dbo.eipp_task_name
               where oid = 4 and task_name = 'Cancellation')
begin
   INSERT dbo.eipp_task_name (oid, task_name, direction, trans_id) 
   VALUES (4, 'Cancellation', 'O', 1)
end
go

if not exists (select 1 from dbo.eipp_task_name
               where oid = 5 and task_name = 'Correction')
begin
   INSERT dbo.eipp_task_name (oid, task_name, direction, trans_id) 
   VALUES (5, 'Correction', 'O', 1)
end
go

if not exists (select 1 from dbo.eipp_task_name
               where oid = 6 and task_name = 'CreateFixedCost')
begin
   INSERT dbo.eipp_task_name (oid, task_name, direction, trans_id) 
   VALUES (6, 'CreateFixedCost', 'I', 1)
end
go
