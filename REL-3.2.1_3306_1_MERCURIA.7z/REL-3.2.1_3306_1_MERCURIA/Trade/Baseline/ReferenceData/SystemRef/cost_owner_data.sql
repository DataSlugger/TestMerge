set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table cost_owner
go

print 'Loading system reference data into the cost_owner table ...'
go

insert into cost_owner values('A', 'A', 'Allocation', 'Allocation', 
'Allocation', 'allocNum', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into cost_owner values('AA', 'AIA', 'AIEstActual', NULL, 'AiEstActual', 
'allocNum', 'allocItemNum', 'aiEstActualNum', NULL, 'creditShiftExpAcctNum', 
'tradeNum', 'orderNum', 'itemNum', 1)
go

insert into cost_owner values('AC', 'AC', 'Accumulation', 'Accumulation', 
'Accumulation', 'tradeNum', 'orderNum', 'itemNum', 'accumNum', NULL, 'tradeNum', 
'orderNum', 'itemNum', 1)
go

insert into cost_owner values('AI', 'AI', 'AllocationItem', NULL, 
'AllocationItem', 'allocNum', 'allocItemNum', NULL, NULL, 
'creditShiftExpAcctNum', 'tradeNum', 'orderNum', 'itemNum', 1)
go

insert into cost_owner values('CO', 'CO', 'Cost', 'Cost', 'Cost', 'costNum', 
NULL, NULL, NULL, 'creditShiftExpAcctNum', 'tradeNum', 'orderNum', 'itemNum', 1)
go

insert into cost_owner values('I', 'I', 'Inventory', 'Inventory', 'Inventory', 
'invNum', NULL, NULL, NULL, NULL, 'tradeNum', 'orderNum', 'itemNum', 1)
go

insert into cost_owner values('P', 'P', 'Portfolio', 'Portfolio', 'Portfolio', 
'portNum', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into cost_owner values('PA', 'PA', 'Paper Allocation', 
'Paper Allocation', 'PaperAllocation', 'paperAllocNum', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into cost_owner values('PG', 'PG', 'PositionGroup', 'PositionGroup', 
'PositionGroup', 'posGroupNum', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into cost_owner values('TI', 'TI', 'TradeItem', 'TradeItem', 'TradeItem', 
'tradeNum', 'orderNum', 'itemNum', NULL, NULL, 'tradeNum', 'orderNum', 
'itemNum', 1)
go

insert into cost_owner values('TO', 'TO', 'TradeOrder', 'TradeOrder', 
'TradeOrder', 'tradeNum', 'orderNum', NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into cost_owner values('TR', 'TR', 'Trade', 'Trade', 'Trade', 'tradeNum', 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into cost_owner values('V', 'V', 'Voucher', 'Voucher', 'Voucher', 
'voucherNum', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

if not exists (select 1
               from dbo.cost_owner
               where cost_owner_code = 'PC')
begin
   insert into dbo.cost_owner
         (cost_owner_code, bc_owner_code, bc_owner_full_name, bc_owner_desc,
          cost_owner_table_name, cost_owner_key1_name, cost_owner_key2_name,
          cost_owner_key3_name, cost_owner_key4_name, cost_owner_key5_name,
          cost_owner_key6_name, cost_owner_key7_name, cost_owner_key8_name, trans_id)
     values('PC', 'PC', 'Parcel', 'Parcel', 'Parcel', 'oid', NULL, NULL, NULL,
            NULL, NULL, NULL, NULL, 1)
end
go
