set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the confirm_method table ...'
go

create table #confirm_method
(
   oid                   numeric(18, 0) IDENTITY primary key,
   confirm_method_name   varchar(50) not null,
)
go  
       
insert into #confirm_method (confirm_method_name)
select 'STORE IN SAFE'
union all
select 'PRINT'
go





declare @oid                   numeric(18, 0),
        @newoid                int,
        @confirm_method_name   varchar(50),
        @errcode               int,
        @row_affected          int,
        @smsg                  varchar(255)

   select @errcode = 0

   select @oid = min(oid)
   from #confirm_method

   while @oid is not null
   begin
      select @confirm_method_name = confirm_method_name
      from #confirm_method
      where oid = @oid

      if not exists (select 1
                     from dbo.confirm_method
                     where confirm_method_name = @confirm_method_name)
      begin
         begin tran
         select @newoid = isnull(max(oid), 0) + 1
         from dbo.confirm_method
   
         begin try
           insert into dbo.confirm_method
               (oid, confirm_method_name,trans_id)
             values(@newoid, @confirm_method_name, 1)
           select @row_affected = @@rowcount
         end try
         begin catch
           if @@trancount > 0
              rollback tran
           print '=> Failed to add an confirm_method record for ''' + @confirm_method_name + ''' due to the error:'
           print '==> ERROR: ' + ERROR_MESSAGE()
           select @errcode = ERROR_NUMBER()
           goto nextoid
         end catch
         commit tran
         select @smsg = '=> Added ''' + @confirm_method_name + ''' into the ''confirm_method'' table successfully!' 
         print @smsg
      end

nextoid:   
      select @oid = min(oid)
      from #confirm_method
      where oid > @oid        
   end
endofscript:
go

if object_id('tempdb..#confirm_method', 'U') is not null
   exec('drop table #confirm_method')
go
                                 
exec dbo.refresh_a_last_num 'confirm_method', 'oid'
go