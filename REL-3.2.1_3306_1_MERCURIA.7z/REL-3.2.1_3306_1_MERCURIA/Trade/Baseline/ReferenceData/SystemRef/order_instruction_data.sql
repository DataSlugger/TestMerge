set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table order_instruction
go

print 'Loading system reference data into the order_instruction table ...'
go

insert into dbo.order_instruction 
   values('GTC', 'Good till Cancel', 1)
go

