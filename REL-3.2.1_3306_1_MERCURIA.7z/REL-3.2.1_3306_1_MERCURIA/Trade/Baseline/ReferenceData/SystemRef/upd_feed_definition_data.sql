set nocount on

set QUOTED_IDENTIFIER ON
go


print ' '
print 'Changing feed_definition.mapping_xml_id column value NULL to ''oid'' '
print 'of feed_xsd_xml_text table for NAVITA_MTM_INTERFACE xml ...'
go

IF EXISTS (select * from dbo.feed_definition
           where feed_name = 'NAVITA_MTM_INTERFACE' and 
                 mapping_xml_id is NULL)
begin
   if object_id('dbo.feed_definition_updtrg') is not null
      exec('ALTER TABLE dbo.feed_definition DISABLE TRIGGER feed_definition_updtrg')
   
   update dbo.feed_definition
   set mapping_xml_id = (select new_oid from dbo.xx434717_keymap where oid = 1)
   where feed_name = 'NAVITA_MTM_INTERFACE' and
         mapping_xml_id is NULL
   
   if object_id('dbo.feed_definition_updtrg') is not null
      exec('ALTER TABLE dbo.feed_definition ENABLE TRIGGER feed_definition_updtrg')
End

if object_id('dbo.xx434717_keymap') is not null
   exec('drop table dbo.xx434717_keymap')
go
