set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table order_type
go

print 'Loading system reference data into the order_type table ...'
go

insert into dbo.order_type values('BARGE', 'Barge Transport', 1)
go

insert into dbo.order_type values('EFPEXCH', 'EFP Exchange', 1)
go

insert into dbo.order_type values('EXCHGOPT', 'Exchange Traded Option Order', 1)
go

insert into dbo.order_type values('FUTURE', 'Futures Order', 1)
go

insert into dbo.order_type values('OTCAPO', 'Cash-Settled Average-Price OTC Option', 
1)
go

insert into dbo.order_type values('OTCCASH', 'American/Euro Cash-Settled OTC Option', 1)
go

insert into dbo.order_type values('OTCPHYS', 'American/Euro Phys.-Settled OTC Option', 1)
go

insert into dbo.order_type values('PARTIAL', 'Partial', 1)
go

insert into dbo.order_type values('PHYSBYSL', 'Physical Buy-Sell', 1)
go

insert into dbo.order_type values('PHYSEXCH', 'Physical Exchange', 1)
go

insert into dbo.order_type values('PHYSICAL', 'A Physical Purchase/Sale', 1)
go

insert into dbo.order_type values('PIPELINE', 'Pipeline Transport', 1)
go

insert into dbo.order_type values('PROCESS', 'Processing Agreement', 1)
go

insert into dbo.order_type values('RACKBYSL', 'A Rack Buy - Sell', 1)
go

insert into dbo.order_type values('RACKEXCH', 'A Rack Exchange', 1)
go

insert into dbo.order_type values('RACKPHYS', 'A Rack Physical Purchase or Sale', 1)
go

insert into dbo.order_type values('RAILCAR', 'Railcar Transport', 1)
go

insert into dbo.order_type values('STORAGE', 'Storage Agreement', 1)
go

insert into dbo.order_type values('SWAP', 'Fixed vs. Float Swap', 1)
go

insert into dbo.order_type values('SWAPFLT', 'Float vs. Float Swap', 1)
go

insert into dbo.order_type values('TRANSPRT', 'Chartering', 1)
go

insert into dbo.order_type values('TRUCK', 'Truck Transport', 1)
go

insert into dbo.order_type values('VLCC', 'Very Large Cargo Carriers Transport', 1)
go

insert into dbo.order_type values('BUNKER', 'Bunker', 1)
go

insert into dbo.order_type values('CURRENCY', 'Currency Exchange', 1)
go

insert into dbo.order_type values('DERIVATI', 'Derivative Trades', 1)
go

insert into dbo.order_type values('PHYTRUCK', 'Physical Truck Transport', 1)
go

insert into dbo.order_type values('PHYSCONC', 'Dry Physical', 1)
go

/*
  The PHYB2BC order type (Physical back to back contract) was to 
  be used along with Truckcapture application which would allow 
  user to enter lifting information based off of the b2b contract.

  But since then, Mercuria�s Poland business disintegrated, Truckcapture 
  app was discontinued, we don�t have a working rack solution.
  
  Mano
*/
if not exists (select 1
               from dbo.order_type
               where order_type_code = 'PHYSB2BC' and
                     order_type_desc = 'Physical B2B Purchase Contract')
   insert into dbo.order_type 
         (order_type_code, order_type_desc, trans_id)
     values('PHYSB2BC', 'Physical B2B Purchase Contract', 1)
go

if not exists (select 1
               from dbo.order_type
               where order_type_code = 'PHYSRIN')
   insert into dbo.order_type 
         (order_type_code, order_type_desc, trans_id)
     values('PHYSRIN', 'Physical RINs', 1)
go

if not exists (select 1
               from dbo.order_type
               where order_type_code = 'PHYSBUNK')
   insert into dbo.order_type 
         (order_type_code, order_type_desc, trans_id)
     values('PHYSBUNK', 'Physical Bunker', 1)
go
