set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the resource_type table ...'
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'INFO')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('INFO','Multi-lingual Information message used by application',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'WARNING')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('WARNING','Multi-lingual Warning message used by application',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'ERROR')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('ERROR','Multi-lingual Error message used by application',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'HELPURL')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('HELPURL','Help url - hyper link to a help section within the CHM help file',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'QUERY')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('QUERY','Fetch query/criteria',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'SCREEN_LAYOUT')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('SCREEN_LAYOUT','Screen layout',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'PANEL_LAYOUT')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('PANEL_LAYOUT','Panel layout',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'USER_PREFERENCE' and
  	       description = 'User Preferences')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('USER_PREFERENCE','User Preferences',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'REF_PREFERENCE' and
  	       description = 'Reference data preference (Narrowed down reference data based setup by user)')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('REF_PREFERENCE','Reference data preference (Narrowed down reference data based setup by user)',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'SEARCH_ATTRS_BASIC' and
  	       description = 'Search attributes selected for basic search')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('SEARCH_ATTRS_BASIC','Search attributes selected for basic search',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'SEARCH_ATTRS_FAV' and
  	       description = 'Search attributes in favorites list')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('SEARCH_ATTRS_FAV','Search attributes in favorites list',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'LAYOUT_ATTRS' and
  	       description = 'Layout attributes selected')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('LAYOUT_ATTRS','Layout attributes selected',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'LAYOUT_ATTR_FAV' and
  	       description = 'Layout attributes in favorites list')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('LAYOUT_ATTR_FAV','Layout attributes in favorites list',1)
go


if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'AUTO_SAVED_QUERY' and
  	       description = 'Recent Searches not yet named')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('AUTO_SAVED_QUERY','Recent Searches not yet named',1)
go

if NOT EXISTS (select 1
               from dbo.resource_type
               where res_type = 'PANEL_PREFERENCES' and
  	       description = 'This is used related to storing panel level preferences.')
   insert into dbo.resource_type (res_type, description, trans_id)
      values ('PANEL_PREFERENCES','This is used related to storing panel level preferences.',1)
go

if not exists (select 1
               from dbo.resource_type
               where res_type = 'SEARCH_ATTR')
   insert into dbo.resource_type
       (res_type, description, trans_id)
      values('SEARCH_ATTR', 'Default Search Attributes/Columns for all users - Client Specific', 1)   
go

if not exists (select 1
               from dbo.resource_type
               where res_type = 'TC_PREFERENCES')
   insert into dbo.resource_type
       (res_type, description, trans_id)
      values('TC_PREFERENCES', 'Saves Preferences set in dotNet TradeCapture', 1)   
go

if not exists (select 1
               from dbo.resource_type
               where res_type = 'RECENT_TRADES')
   insert into dbo.resource_type
       (res_type, description, trans_id)
      values('RECENT_TRADES', 'Contains the details of recent 10 trades inserted/updated by user', 1)   
go

if not exists (select 1
               from dbo.resource_type
               where res_type = 'CA_PREFERENCES')
   insert into dbo.resource_type
       (res_type, description, trans_id)
      values('CA_PREFERENCES', 'Saves Preferences set in dotNet CommAccount', 1)
go
