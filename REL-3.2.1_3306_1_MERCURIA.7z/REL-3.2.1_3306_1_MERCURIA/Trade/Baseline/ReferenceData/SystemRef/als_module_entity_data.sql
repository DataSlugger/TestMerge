set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table als_module_entity
go

print 'Loading system reference data into the als_module_entity table ...'
go

/* operation_type_mask
         Bit 0 - 1 for INSERT
         Bit 1 - 2 for UPDATE
         Bit 2 - 4 for DELETE
*/

if object_id('dbo.xx1019entities') is not null
   drop table dbo.xx1019entities
go

create table dbo.xx1019entities
(
   oid                   numeric(18, 0) IDENTITY,
   als_module_group_name varchar(30) not null,
   entity_name           varchar(30) not null,
   operation_type_mask   int null
)

/* MainALS */
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'Accumulation', 3)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'AiEstActual', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'AiEstActualSpec', 3)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'Allocation', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'AllocationItem', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'AllocationItemTransport', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'Cost', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'Formula', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'FxHedgeRate', 3)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'Inventory', 3)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'InventoryBuildDraw', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'MarketPricingCondition', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'Trade', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeItem', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeItemBunker', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeItemCashPhy', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeItemDist', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeItemExchOpt', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeItemFut', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeItemOtcOpt', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeItemRin', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeItemSpec', 3)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeItemStorage', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeItemTransport', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeItemWetPhy', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'TradeOrderBunker', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('MainALS', 'Voucher', 1)
go

/* ExtendedALS */
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('ExtendedALS', 'AllocationItem', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('ExtendedALS', 'Cost', 3)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('ExtendedALS', 'Inventory', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('ExtendedALS', 'Trade', 3)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('ExtendedALS', 'TradeItem', 7)
go

/* AutoConfirm */
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('AutoConfirm', 'Trade', 7)
go

/* AutoRepricing */
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('AutoRepricing', 'RepriceEventDetail', 1)
go

/* CriticalALS */
/*
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('CriticalALS', 'AiEstActual', 7)
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('CriticalALS', 'Event', 1)

insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('CriticalALS', 'Inventory', 6)
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('CriticalALS', 'TradeItem', 2)
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('CriticalALS', 'TradeItemDist', 6)
*/


/* EODALS */
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('EODALS', 'Event', 1)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('EODALS', 'TradeItemDist', 7)
go

/* Exposure */
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Exposure', 'AccountGroup', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Exposure', 'Accumulation', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Exposure', 'AllocationItem', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Exposure', 'AssignTrade', 5)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Exposure', 'Cost', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Exposure', 'CreditLimit', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Exposure', 'Event', 1)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Exposure', 'Lc', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Exposure', 'Trade', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Exposure', 'TradeItemOtcOpt', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Exposure', 'TradeItemWetPhy', 2)
go

/* PASSUtility */
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('PASSUtility', 'Event', 1)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('PASSUtility', 'JobSchedule', 7)
go

/* Reprice */
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Reprice', 'Accumulation', 4)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Reprice', 'CalendarDetail', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Reprice', 'CommodityMarketSource', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Reprice', 'Price', 2)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('Reprice', 'TradingPeriod', 2)
go

/* SharePoint */
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('SharePoint', 'Trade', 7)
go

/* UICReportHistory */
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values ('UICReportHistory', 'Allocation', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values ('UICReportHistory', 'AllocationItem', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values ('UICReportHistory', 'AllocationItemTransport', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values ('UICReportHistory', 'Cost', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values('UICReportHistory', 'CostExtInfo', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values ('UICReportHistory', 'Parcel', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values ('UICReportHistory', 'Shipment', 7)
go   
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values ('UICReportHistory', 'Trade', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values ('UICReportHistory', 'TradeItem', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values ('UICReportHistory', 'TradeItemWetPhy', 7)
go
insert into dbo.xx1019entities
     (als_module_group_name, entity_name, operation_type_mask)
   values ('UICReportHistory', 'Voucher', 7)
go




/* *************************************************************** */
/* Logic to load data into the als_module_entity table starts here */

declare @als_module_group_id     int,
        @als_module_group_name   varchar(30),
        @als_module_name         varchar(30),
        @oid                     numeric(18, 0),
        @smsg                    varchar(255),
        @entity_name             varchar(30),
        @operation_type_mask     int,
        @rows_affected           int,
        @errcode                 int,
        @is_new_group            bit

select @als_module_name = null,
       @errcode = 0,
       @is_new_group = 0

select @oid = min(oid)
from dbo.xx1019entities

while @oid is not null
begin
   select @als_module_group_name = als_module_group_name,
          @entity_name = entity_name,
          @operation_type_mask = operation_type_mask
   from dbo.xx1019entities
   where oid = @oid

   if @als_module_name is null
   begin
      select @is_new_group = 1
   end
   else
   begin   
      if @als_module_name <> @als_module_group_name
         select @is_new_group = 1
   end
            
   if @is_new_group = 1
   begin
      select @is_new_group = 0  
      select @als_module_name = @als_module_group_name
      select @als_module_group_id = als_module_group_id
      from dbo.server_config
      where als_module_group_desc = @als_module_group_name
      select @errcode = @@error
      if @errcode > 0
         break
      if @als_module_group_id is null
      begin
         select @smsg = 'Failed to find an ID for the ALS module group ''' + @als_module_group_name + '''!'
         print @smsg
         break
      end
   end

   if not exists (select 1
                  from dbo.als_module_entity
                  where als_module_group_id = @als_module_group_id and
                        entity_name = @entity_name)
   begin
      insert into dbo.als_module_entity
           (als_module_group_id, entity_name, trans_id, operation_type_mask)
         values(@als_module_group_id, @entity_name, 1, @operation_type_mask)
      select @rows_affected = @@rowcount,
             @errcode = @@error
      if @errcode > 0
         break
      if @rows_affected > 0
      begin
         -- DEBUG
         select @smsg = convert(char(35), @als_module_group_name + ' (' + convert(varchar, @als_module_group_id) + ') ') + ' :  Added entity ''' + @entity_name + ''''
         print @smsg
      end
   end
   
   select @oid = min(oid)
   from dbo.xx1019entities
   where oid > @oid
end
go

if object_id('dbo.xx1019entities') is not null
   drop table dbo.xx1019entities
go
