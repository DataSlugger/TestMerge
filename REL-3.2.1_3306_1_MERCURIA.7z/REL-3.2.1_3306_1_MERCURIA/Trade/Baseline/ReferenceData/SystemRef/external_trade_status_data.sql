set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the external_trade_status table ...'
go

if not exists (select 1
               from external_trade_status
               where external_trade_status_name = 'Pending')
   INSERT external_trade_status 
     (oid, external_trade_status_name, trans_id) 
      VALUES (1, 'Pending', 1)
go

if not exists (select 1
               from external_trade_status
               where external_trade_status_name = 'Completed')
   INSERT external_trade_status 
     (oid, external_trade_status_name, trans_id) 
      VALUES (2, 'Completed', 1)
go

if not exists (select 1
               from external_trade_status
               where external_trade_status_name = 'Failed')
   INSERT external_trade_status 
     (oid, external_trade_status_name, trans_id) 
      VALUES (3, 'Failed', 1)
go

if not exists (select 1
               from external_trade_status
               where external_trade_status_name = 'Skipped')
   INSERT external_trade_status 
     (oid, external_trade_status_name, trans_id) 
      VALUES (4, 'Skipped', 1)
go
