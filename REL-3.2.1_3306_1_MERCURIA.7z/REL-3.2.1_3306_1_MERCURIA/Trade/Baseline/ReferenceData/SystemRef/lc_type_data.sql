set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Adding system reference data into the lc_type table ...'
go

if NOT EXISTS (select *
               from dbo.lc_type
               where lc_type_code = 'PCG')
   insert into dbo.lc_type
        (lc_type_code, lc_type_short_name, lc_type_desc, lc_type_num, trans_id)
      values ('PCG', 'P C Guarantee', 'PCG for Subsidiary', 9, 1)
go

IF NOT EXISTS (select * 
               from dbo.lc_type
               where lc_type_code = 'COLLATER')                
   insert into dbo.lc_type
        (lc_type_code, lc_type_short_name, lc_type_desc, lc_type_num, trans_id)
      values ('COLLATER', 'COLLATERAL', 'CREDIT COLLATERAL', 10, 1)
go

IF NOT EXISTS (select * from dbo.lc_type
               where lc_type_code = 'NETTING')                
   INSERT INTO dbo.lc_type
       (lc_type_code, lc_type_short_name, lc_type_desc, lc_type_num, trans_id)
   VALUES('NETTING', 'NETTING', 'NETTING', 11, 1)
go   
