set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bus_cost_leaf
go

print 'Loading system reference data into the bus_cost_leaf table ...'
go

insert into dbo.bus_cost_leaf 
   values('NOT_PARENT', 'LEAF COST NODE', 'LEAF COST NODE', 1)
go

insert into dbo.bus_cost_leaf 
   values('PARENT', 'PARENT COST NODE', 'PARENT COST NODE', 1)
go

