set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table cost_status
go

print 'Loading system reference data into the cost_status table ...'
go

insert into dbo.cost_status
   values('CLOSED', 'CLOSED', 1)
go

insert into dbo.cost_status
   values('HELD', 'HELD', 1)
go

insert into dbo.cost_status
   values('OPEN', 'OPEN', 1)
go

insert into dbo.cost_status
   values('PAID', 'PAID', 1)
go

insert into dbo.cost_status
   values('POSTED', 'POSTED', 1)
go

insert into dbo.cost_status
   values('VOUCHED', 'VOUCHED', 1)
go

