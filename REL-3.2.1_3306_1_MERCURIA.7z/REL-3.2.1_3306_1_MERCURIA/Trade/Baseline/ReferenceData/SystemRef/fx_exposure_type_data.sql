set nocount on

set QUOTED_IDENTIFIER ON
go

print ' '
print 'Loading system reference data into the fx_exposure_type table ...'
go

if not exists (select 1
               from dbo.fx_exposure_type 
               where exposure_type_code = 'P')
   insert into dbo.fx_exposure_type (exposure_type_code, exposure_type_desc, trans_id)
      values ('P', 'PRIMARY', 1)
go

if not exists (select 1
               from dbo.fx_exposure_type 
               where exposure_type_code = 'C')
   insert into dbo.fx_exposure_type (exposure_type_code, exposure_type_desc, trans_id)
      values ('C', 'FOREX', 1)
go

if not exists (select 1
               from dbo.fx_exposure_type 
               where exposure_type_code = 'S')
   insert into dbo.fx_exposure_type (exposure_type_code, exposure_type_desc, trans_id)
      values ('S', 'OTHER', 1)
go

if not exists (select 1
               from dbo.fx_exposure_type 
               where exposure_type_code = 'F')
   insert into dbo.fx_exposure_type (exposure_type_code, exposure_type_desc, trans_id)
      values ('F', 'FUTURES', 1)
go

if not exists (select 1
               from dbo.fx_exposure_type 
               where exposure_type_code = 'FD')
   insert into dbo.fx_exposure_type (exposure_type_code, exposure_type_desc, trans_id)
      values ('FD', 'FORMULA DIFF', 1)
go

if not exists (select 1
               from dbo.fx_exposure_type 
               where exposure_type_code = 'PP')
   insert into dbo.fx_exposure_type (exposure_type_code, exposure_type_desc, trans_id)
      values ('PP', 'PHYSPRICING', 1)
go

if not exists (select 1
               from dbo.fx_exposure_type 
               where exposure_type_code = 'PR')
   insert into dbo.fx_exposure_type (exposure_type_code, exposure_type_desc, trans_id)
      values ('PR', 'PREMIUM', 1)
go

if not exists (select 1
               from dbo.fx_exposure_type 
               where exposure_type_code = 'SW')
   insert into dbo.fx_exposure_type (exposure_type_code, exposure_type_desc, trans_id)
      values ('SW', 'SWAPS', 1)
go