set nocount on

create table #temp
(
   oid                   int IDENTITY primary key,
   conversion_name       varchar(50) NULL,
   start_index           int NULL,
   end_index             int NULL,
   field_name            varchar(50) NULL,
   field_number          int NULL,
   field_numbers         varchar(20) NULL,
   line_number           int NULL,
   parser_format         varchar(100) NULL,
   parser_name           varchar(100) NOT NULL,
   regex                 varchar(50) NULL,
   result_concatenator   varchar(10) NULL,
   static_field_value    varchar(50) NULL,
   parser_id             int null
)
go

insert into #temp
    (conversion_name,
     start_index,
     end_index,
     field_name,
     field_number,
     field_numbers,
     line_number,
     parser_format,
     parser_name,
     regex,
     result_concatenator,
     static_field_value)
   values(NULL,         NULL, NULL, 'Period Year',	              3, NULL, NULL,         NULL, 'Nymex Future', NULL, NULL,   NULL),
         ('Parse Date', NULL, NULL, 'Settlement Date',	         20, NULL, NULL, 'MM/dd/yyyy', 'Nymex Future', NULL, NULL,   NULL),
         (NULL,         NULL, NULL, 'Period Month',		            2, NULL, NULL,         NULL, 'Nymex Future', NULL, NULL,   NULL),
         (NULL,         NULL, NULL, 'Market Value',              14, NULL, NULL,         NULL, 'Nymex Future', NULL, NULL,   NULL),
         ('Value Map', 	NULL,	NULL, 'Market Data Supplier',	      1, NULL, NULL,         NULL, 'Nymex Future', NULL, NULL,   NULL),
         (NULL,         NULL, NULL,	'Period Day',	                4, NULL, NULL,         NULL, 'Nymex Future', NULL, NULL,   NULL),
         (NULL,         NULL, NULL,	'Create Period',           NULL, NULL, NULL,         NULL, 'Nymex Future', NULL, NULL, 'true'),
         ('Parse Date', NULL, NULL,	'Settlement Date',	          1, NULL, NULL, 'MM/dd/yyyy',  'ICE Cleared', NULL, NULL,   NULL),
         ('Parse Date', NULL, NULL,	'Period Date',	              4, NULL, NULL, 'MM/dd/yyyy',  'ICE Cleared', NULL, NULL,   NULL),
         (NULL,         NULL, NULL,	'Create Period',	         NULL, NULL, NULL,         NULL,  'ICE Cleared', NULL, NULL, 'true'),
         (NULL,         NULL, NULL,	'Symbol Based Period Day',	  5, NULL, NULL,         NULL,  'ICE Cleared', NULL, NULL,   NULL),
         ('Value Map', 	NULL,	NULL,	'Market Data Supplier',	      5, NULL, NULL,         NULL,  'ICE Cleared', NULL, NULL,   NULL),
         (NULL,         NULL, NULL,	'Market Value',	              8, NULL, NULL,         NULL,  'ICE Cleared', NULL, NULL,   NULL)
go



/* ************************************************************** */
update t
set parser_id = p.id
from #temp t
        join dbo.parser p
           on t.parser_name = p.name
go

if exists (select 1
           from #temp
           where parser_id is null)
begin
   RAISERROR('=> The following parser_name(s) are not defined in the parser table:', 0, 1) with nowait
   select distinct parser_name
   from #temp
   where parser_id is null
   order by parser_name
   goto endofscript
end


declare @last_field_id     int,
        @trans_id          int,
        @rows_affected     int,
        @errcode           int,
        @smsg              varchar(max)

set @trans_id = 1
begin tran
select @last_field_id = isnull(max(id), 0)
from dbo.parser_field

begin try
   insert into dbo.parser_field
   	 (id,
   	  conversion_name,
          start_index,
          end_index,
          field_name,
          field_number,
          field_numbers,
          line_number,
          parser_format,
          parser_id,
          regex,
          result_concatenator,
          static_field_value,
          trans_id)
   select 
      @last_field_id + oid,
      conversion_name,
      start_index,
      end_index,
      field_name,
      field_number,
      field_numbers,
      line_number,
      parser_format,
      parser_id,
      regex,
      result_concatenator,
      static_field_value,
      @trans_id
   from #temp t
   where not exists (select 1 
                     from dbo.parser_field 
                     where isnull(conversion_name,'XYZ') = isnull(t.conversion_name,'XYZ') and 
                           isnull(start_index, 123) = isnull(t.start_index, 123) and 
                           isnull(end_index, 123) = isnull(t.end_index, 123) and 
                           isnull(field_name,'XYZ') = isnull(t.field_name,'XYZ') and 
                           isnull(field_number, 123) = isnull(t.field_number, 123) and 
                           isnull(field_numbers, 'XYZ') = isnull(t.field_numbers, 'XYZ') and 
                           isnull(line_number, 123) = isnull(t.line_number, 123) and 
                           isnull(parser_format,'XYZ') = isnull(t.parser_format,'XYZ') and 
                           isnull(parser_id, 123) = isnull(t.parser_id, 123) and 
                           isnull(regex, 'XYZ') = isnull(t.regex, 'XYZ') and 
                           isnull(result_concatenator, 'XYZ') = isnull(t.result_concatenator, 'XYZ') and 
                           isnull(static_field_value, 'XYZ') = isnull(t.static_field_value, 'XYZ'))
   set @rows_affected = @@rowcount   
end try
begin catch
  set @errcode = ERROR_NUMBER()
  set @smsg = ERROR_MESSAGE()
  if @@trancount > 0
     rollback tran
  RAISERROR('=> Failed to load data into the parser_field table due to the error:', 0, 1) with nowait
  RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
  goto endofscript
end catch 
commit tran
RAISERROR('%d records were loaded into the parser_field table!', 0, 1, @rows_affected) with nowait

endofscript:
drop table #temp
go

exec dbo.refresh_a_last_num 'parser_field', 'id'
go


