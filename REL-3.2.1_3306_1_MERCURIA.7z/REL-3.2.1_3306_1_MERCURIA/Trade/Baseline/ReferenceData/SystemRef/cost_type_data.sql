set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the cost_type table ...'
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'ACC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('ACC', 'Accrual', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'ADJ')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('ADJ', 'Adjustment', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'BC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('BC', 'Brokerage', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'BO')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('BO', 'BookOut Principal Primary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'DPP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('DPP', 'Dry Principal Primary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'FBC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('FBC', 'Futures/Listed Brokerage Cost', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'MEMO')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('MEMO', 'Memo', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'MFT')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('MFT', 'Motor Fuel Tax', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'NF')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('NF', 'Notional Finance', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'NO')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('NO', 'Netout', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'OAP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('OAP', 'Option Additional Primary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'OBC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('OBC', 'OTC Brokerage', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'OPP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('OPP', 'OTC Option Principal Primary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'OS')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('OS', 'OTC Option Addition Cost', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'OTC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('OTC', 'OTC Settlement Cost', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'PAC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('PAC', 'Paper Allocation', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'PDO')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('PDO', 'Lease - Division Order', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'PL')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('PL', 'Profit/Loss Entry', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'PO')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('PO', 'Preliminary Offset', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'POC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('POC', 'Lease - Contract', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'PR')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('PR', 'Preliminary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'PS')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('PS', 'Portfolio Secondary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'R')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('R', 'Reserve', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'RB')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('RB', 'Rebook', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'RC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('RC', 'Reverse', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'RD')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('RD', 'Remainder', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'RN')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('RN', 'Ralph/Nolan Cost', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'RPP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('RPP', 'Rack Principal Primary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'SAC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('SAC', 'Storage Actual', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'SALESTAX')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('SALESTAX', 'Sales Tax', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'SMC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('SMC', 'Storage Movement', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'SPP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('SPP', 'Storage Principal Primary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'STC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('STC', 'Storage Trade', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'SWAP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('SWAP', 'Swap Accumulation Cost', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'SWBC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('SWBC', 'Swap Brokerage Cost', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'SWPR')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('SWPR', 'Swap Premium', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'TAC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('TAC', 'Transportation Actual', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'TAX')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('TAX', 'Tax', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'TMC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('TMC', 'Transportation Movement', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'TPP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('TPP', 'Transportation Principal Primary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'TTC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('TTC', 'Transportation Trade', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'TVM')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('TVM', 'TVM', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'VA')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('VA', 'Value', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'WAP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('WAP', 'Wet Actual Cost', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'WO')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('WO', 'Write-Off', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'WPP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('WPP', 'Wet Principal Primary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'WS')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('WS', 'Wet Secondary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'ADDLA')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('ADDLA','CA_CREATED_A_ADDL_COST',1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'ADDLAA')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('ADDLAA','CA_CREATED_AA_ADDL_COST',1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'ADDLAI')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('ADDLAI','CA_CREATED_AI_ADDL_COST',1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'ADDLP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('ADDLP','CA_CREATED_P_ADDL_COST',1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'ADDLPG')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('ADDLPG','CA_CREATED_PG_ADDL_COST',1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'ADDLTI')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('ADDLTI','CA_CREATED_TI_ADDL_COST',1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'JV')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('JV','Joint Venture Cost',1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'JVO')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('JVO','Joint Venture Offset Cost',1)
go

/* cost types for BUNKER */
if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'BBC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('BBC', 'Bunker Brokerage', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'BAP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('BAP', 'Bunker Additional Primary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'BPP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('BPP', 'Bunker Principal Primary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'BS')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('BS', 'Bunker Secondary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'BTL')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('BTL', 'Bunker Transport Lumpsum', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'BTU')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('BTU', 'Bunker Transport Unit Price', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'WLDSCL')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('WLDSCL', 'World Scale', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'ADDLSWAP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('ADDLSWAP', 'Swap additional cost', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'INVROLL')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('INVROLL', 'Allocation Inventory Roll', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'DFB')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('DFB', 'Futures/Listed Opt Daily Fifo Brokerage', 1) 
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'MFB')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('MFB', 'Futures/Listed Opt Interday Fifo Brokerg', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'TFB')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('TFB', 'Futures/Listed Opt Flat Brokerage', 1) 
go

/* added by Peter Lo    9/20/2004  issue #10805 */
if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'BOAI')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('BOAI', 'AI owned cost for Bookout Allocation', 1)
go

/* added by Peter Lo    10/05/2004  issue #10924 */
if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'CPP')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('CPP', 'Currency Principal Receivable', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'CPR')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('CPR', 'Currency Principal Payable', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'CBC')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('CBC', 'Currency Brokerage Cost', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'PTS')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('PTS', 'Portfolio Transportation Secondary', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'IMP-DUTY')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('IMP-DUTY','Import Duty Tax',1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'TI-EXCH')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('TI-EXCH',  'Trading Integration Exchange Adjustment', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'TI-TERM')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('TI-TERM', 'Trading Integration Term Adjustment', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'TI-REF')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('TI-REF', 'Trading Integration Ref Price Adjustment', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'TI-OTHER')
   insert into dbo.cost_type
        (cost_type_code, cost_type_desc, trans_id)
      values('TI-OTHER', 'Trading integration Others Adjustment', 1)
go

/* added by Peter Lo    03/10/2008  issue #17665 */

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'PEXCHIMB')
   insert into dbo.cost_type (cost_type_code, cost_type_desc, trans_id)
      values ('PEXCHIMB', 'Physical Exchange Imbalances', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'POMAXFIN')
   insert into dbo.cost_type
      (cost_type_code, cost_type_desc, trans_id)
     values ('POMAXFIN', 'Pomax financial costs', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'POMAXPHY')
   insert into dbo.cost_type 
      (cost_type_code, cost_type_desc, trans_id)
     values ('POMAXPHY', 'Pomax physical costs', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'POMAXSEC')
   insert into dbo.cost_type
      (cost_type_code, cost_type_desc, trans_id)
     values ('POMAXSEC', 'Pomax secondary cost', 1)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'CSTTMPLT')
begin
   insert into dbo.cost_type
      (cost_type_code, cost_type_desc, trans_id)
     values ('CSTTMPLT', 'Cost Template', 1)
end
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'RINPP')
begin
  insert into dbo.cost_type
       (cost_type_code, cost_type_desc, trans_id, is_prin_prim_ind)
     values('RINPP', 'RIN Principal Primary', 1, 'Y')   
end
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'RINAP')
begin
  insert into dbo.cost_type
       (cost_type_code, cost_type_desc, trans_id, is_prin_prim_ind)
     values('RINAP', 'RIN Additional Primary', 1, 'N')   
end
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'ICO')
   insert dbo.cost_type (cost_type_code, cost_type_desc, trans_id, is_prin_prim_ind) 
      values ('ICO', 'Internal Cost Offset', 1, 'N')
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'INSURFLT')
   insert dbo.cost_type (cost_type_code, cost_type_desc, trans_id, is_prin_prim_ind) 
   values('INSURFLT', 'Insurance Flat Cost', 1, NULL)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'FIFOADJ')
   insert into dbo.cost_type (cost_type_code, cost_type_desc,trans_id,is_prin_prim_ind)
   values ('FIFOADJ', 'Write Off Cost for Inv Adjustments', 1, NULL)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'FIFOADJ')
   insert into dbo.cost_type (cost_type_code, cost_type_desc,trans_id,is_prin_prim_ind)
   values ('PRF', 'Prefinal', 1, NULL)
go

if not exists (select 1
               from dbo.cost_type
               where cost_type_code = 'FIFOADJ')
   insert into dbo.cost_type (cost_type_code, cost_type_desc,trans_id,is_prin_prim_ind)
   values ('PFO', 'Prefinal Offset', 1, NULL)
go

	  