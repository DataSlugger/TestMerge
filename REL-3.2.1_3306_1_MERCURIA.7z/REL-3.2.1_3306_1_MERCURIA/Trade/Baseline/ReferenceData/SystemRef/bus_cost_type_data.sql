set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bus_cost_type
go

print 'Loading system reference data into the bus_cost_type table ...'
go

insert into dbo.bus_cost_type 
   values(1, 'WetPhysTIPrinPrim', 'WetPhysTIPrinPrim', 
'WetPhysTIPrinPrim', 'WetPhysAIPrinPrim', 'ONE_OR_MORE', 'ALLOCATE', NULL, 
'NO_PROCESS', 'TI', 'WPP', 'PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(2, 'WetPhysTIAddlPrim', 'WetPhysTIAddlPrim', 
'WetPhysTIAddlPrim', 'WetPhysAIAddlPrim', NULL, 'ALLOCATE', NULL, 'NO_PROCESS', 
'TI', 'WAP', 'PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(3, 'WetPhysTISec', 'WetPhysTISec', 
'WetPhysTISec', 'WetPhysAISec', 'ONE_OR_MORE', 'ALLOCATE', NULL, 'NO_PROCESS', 
'TI', 'WS', 'PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(5, 'OTCOptTIPrinPrim', 'OTCOptTIPrinPrim', 
'OTCOptTIPrinPrim', NULL, NULL, NULL, NULL, 'AUTODD-2', 'TI', 'OPP', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(6, 'StorageTIPrinPrim', 'StorageTIPrinPrim', 
'StorageTIPrinPrim', NULL, NULL, NULL, NULL, 'MANUAL', 'TI', 'SPP', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(7, 'BrokerageTI', 'BrokerageTI', 'BrokerageTI', 
NULL, NULL, NULL, NULL, 'MANUAL', 'TI', 'BC', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(8, 'WetPhysAIPrinPrim', 'WetPhysAIPrinPrim', 
'WetPhysAIPrinPrim', 'WetPhysAIAPrinPrim', 'ONE_OR_MORE', 'EST_ACTUAL', 
'WetPhysTIPrinPrim', 'NO_PROCESS', 'AI', 'WPP', 'PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(9, 'WetPhysAIAddlPrim', 'WetPhysAIAddlPrim', 
'WetPhysAIAddlPrim', 'WetPhysAIAAddlPrim', 'ONE_OR_MORE', 'EST_ACTUAL', 
'WetPhysTIAddlPrim', 'NO_PROCESS', 'AI', 'WAP', 'PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(10, 'WetPhysAISec', 'WetPhysAISec', 
'WetPhysAISec', NULL, NULL, NULL, 'WetPhysAISec', 'MANUAL', 'AI', 'WS', 
'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(11, 'WetPhysAICASec', 'WetPhysAICASec', 
'WetPhysAICASec', NULL, NULL, NULL, NULL, 'MANUAL', 'AIA', 'WS', 'NOT_PARENT', 
'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(12, 'BrokerageAI', 'BrokerageAI', 
'BrokerageAI', NULL, NULL, NULL, 'BrokerageTI', 'MANUAL', 'AI', 'BC', 
'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(13, 'WetPhysAIAPrinPrim', 'WetPhysAIAPrinPrim', 
'WetPhysAIAPrinPrim', NULL, NULL, NULL, 'WetPhysAIPrinPrim', 'MANUAL', 'AIA', 
'WPP', 'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(14, 'WetPhysAIAAddlPrim', 'WetPhysAIAAddlPrim', 
'WetPhysAIAAddlPrim', NULL, NULL, NULL, 'WetPhysAIAddlPrim', 'MANUAL', 'AIA', 
'WAP', 'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(15, 'ALLOC', 'ALLOCATION', 'Allocation', NULL, 
NULL, NULL, NULL, 'MANUAL', 'A', 'WS', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(31, 'VALUE', 'VALUE', 'Value', NULL, NULL, 
NULL, NULL, 'BOOK_ONLY_REV', 'I', 'VA', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(32, 'WRITE-OFF', 'WRITE-OFF', 'Write-off', 
NULL, NULL, NULL, NULL, 'MANUAL', 'V', 'WO', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(33, 'PORTMEMO', 'PORTMEMO', 'Portfolio-Memo', 
NULL, NULL, NULL, NULL, 'MANUAL', 'P', 'MEMO', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(34, 'PORTPL', 'PORTPL', 'Portfolio-PL', NULL, 
NULL, NULL, NULL, 'MANUAL', 'P', 'PL', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(35, 'PORTRES', 'PORTRES', 'Portfolio-Reserve', 
NULL, NULL, NULL, NULL, 'MANUAL', 'P', 'R', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(36, 'PORT2ND', 'PORT2ND', 
'Portfolio-Secondary', NULL, NULL, NULL, NULL, 'MANUAL', 'P', 'PS', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(37, 'PORTACC', 'PORTACC', 'Portfolio-Accrual', 
NULL, NULL, NULL, NULL, 'BOOK_ONLY_REV', 'P', 'ACC', 'NOT_PARENT', 'MATRIARC', 
1)
go

insert into dbo.bus_cost_type 
   values(38, 'PORTADJ', 'PORTADJ', 
'Portfolio-Adjustment', NULL, NULL, NULL, NULL, 'BOOK_ONLY', 'P', 'ADJ', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(39, 'PORTTVM', 'PORTTVM', 'Portfolio-TVM', 
NULL, NULL, NULL, NULL, 'MANUAL', 'P', 'TVM', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(40, 'PORTNF', 'PORTNF', 
'Portfolio-Notional Finance', NULL, NULL, NULL, NULL, 'MANUAL', 'P', 'NF', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(41, 'PGMEMO', 'PGMEMO', 'Position Group-Memo', 
NULL, NULL, NULL, NULL, 'MANUAL', 'PG', 'MEMO', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(42, 'PGPL', 'PGPL', 'Position Group-PL', NULL, 
NULL, NULL, NULL, 'MANUAL', 'PG', 'PL', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(43, 'PGRES', 'PGRES', 'Position Group-Reserve', 
NULL, NULL, NULL, NULL, 'MANUAL', 'PG', 'R', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(44, 'PG2ND', 'PG2ND', 
'Position Group-Secondary', NULL, NULL, NULL, NULL, 'MANUAL', 'PG', 'PS', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(45, 'PGACC', 'PGACC', 'Position Group-Accrual', 
NULL, NULL, NULL, NULL, 'BOOK_ONLY_REV', 'PG', 'ACC', 'NOT_PARENT', 'MATRIARC', 
1)
go

insert into dbo.bus_cost_type 
   values(46, 'PGADJ', 'PGADJ', 
'Position Group-Adjustment', NULL, NULL, NULL, NULL, 'BOOK_ONLY', 'PG', 'ADJ', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(47, 'PGTVM', 'PGTVM', 'Position Group-TVM', 
NULL, NULL, NULL, NULL, 'MANUAL', 'PG', 'TVM', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(48, 'PGNF', 'PGNF', 
'Position Group-Notional Finance', NULL, NULL, NULL, NULL, 'MANUAL', 'PG', 'NF', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(49, 'REVERSAL', 'REVERSAL', 'Reversal', NULL, 
NULL, NULL, NULL, 'MANUAL', 'CO', 'RC', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(50, 'REBOOK', 'REBOOK', 'Rebook', NULL, NULL, 
NULL, NULL, 'MANUAL', 'CO', 'RB', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(51, 'NETOUT', 'NETOUT', 'Netout', NULL, NULL, 
NULL, NULL, 'MANUAL', 'A', 'NO', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(52, 'OTCOptTIAddlPrim', 'OTCOptTIAddlPrim', 
'OTCOptTIAddlPrim', NULL, NULL, NULL, NULL, 'AUTODD-2', 'TI', 'OAP', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(53, 'OTCOptTISec', 'OTCOptTISec', 
'OTCOptTISec', NULL, NULL, NULL, NULL, 'AUTODD-2', 'TI', 'OS', 'NOT_PARENT', 
'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(55, 'TaxCost', 'TaxCost', 'TaxCost', NULL, 
NULL, NULL, NULL, 'AUTOIMMED', 'CO', 'TAX', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(56, 'REMAINDER', 'REMAINDER', 
'Remainder Amount Left on a paid Voucher', NULL, NULL, NULL, NULL, 'MANUAL', 
'V', 'RD', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(57, 'PRELIMINARY', 'PRELIMINARY', 
'Preliminary cost before cost is final vouchered', 'PRELIMOFFSET', 
'ONE_OR_MORE', 'PRELIMOFFSET', NULL, 'MANUAL', 'CO', 'PR', 'PARENT', 'MATRIARC', 
1)
go

insert into dbo.bus_cost_type 
   values(58, 'PRELIMOFFSET', 'PRELIMINARY_OFFSET', 
'Offset to the preliminary cost', NULL, NULL, NULL, 'PRELIMINARY', 'MANUAL', 
'CO', 'PO', 'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(59, 'RackExchangeTI', 'RackExchangeTI', 
'RackExchangeAI', 'ONE_OR_MORE', NULL, 'ALLOCATE', NULL, 
'NO_PROCESS', 'TI', 'RPP', 'PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(60, 'RackExchangeAI', 'RackExchangeAI', 
'Represents Allocation item owned by a Rack Trade Item.', 'RackExchangeAIA', 
'ONE_OR_MORE', 'EST_ACTUAL', 'RackExchangeTI', 'NO_PROCESS', 'AI', 'RPP', 
'PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(61, 'RackExchangeAIA', 'RackExchangeAIA', 
'Represents Allocation Actual owned by a Allocation Item owned by a Rack Trade Item.', 
NULL, NULL, NULL, 'RackExchangeAI', 'AUTOIMMED', 'AIA', 'RPP', 'NOT_PARENT', 
'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(63, 'SwapTradeCosts', 'SwapTradeCosts', 
'SwapTradeCosts', NULL, NULL, NULL, NULL, 'MANUAL', 'TI', 'SWPR', 'NOT_PARENT', 
'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(65, 'LeaseDivOrderAI', 'LeaseDivOrderAI', 
'Lease Paid On Division Order AI', 'LeaseDivOrderAIA', 'ONE_OR_MORE', 
'EST_ACTUAL', 'LeaseDivOrderTI', 'BOOK_ONLY', 'AI', 'PDO', 'PARENT', 
'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(66, 'LeaseDivOrderAIA', 'LeaseDivOrderAIA', 
'Lease Paid On Division Order AIA', NULL, NULL, NULL, 'LeaseDivOrderAI', 
'BOOK_ONLY', 'AIA', 'PDO', 'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(67, 'LeaseContractTI', 'LeaseContractTI', 
'Lease Paid On Contract  TI', 'LeaseContractAI', 'ONE_OR_MORE', 'ALLOCATE', 
NULL, 'ITEM_TYPE', 'TI', 'POC', 'PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(68, 'LeaseContractAI', 'LeaseContractAI', 
'Lease Paid On Contract AI', 'LeaseContractAIA', 'ONE_OR_MORE', 'EST_ACTUAL', 
'LeaseContractTI', 'ITEM_TYPE', 'AI', 'POC', 'PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(69, 'LeaseContractAIA', 'LeaseContractAIA', 
'Lease Paid On Contract AIA', NULL, NULL, NULL, 'LeaseContractAI', 'ITEM_TYPE', 
'AIA', 'POC', 'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(70, 'LeaseDivOrderTI', 'LeaseDivOrderTI', 
'Lease Paid On Division Order TI', 'LeaseDivOrderAI', 'ONE_OR_MORE', 'ALLOCATE', 
NULL, 'BOOK_ONLY', 'TI', 'PDO', 'PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(75, 'TIAccrual', 'TIAccrual', 
'Trade Item GL Accrual', NULL, NULL, NULL, NULL, 'BOOK_ONLY_REV', 'TI', 'ACC', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(76, 'TIAdjustment', 'TIAdjustment', 
'Trade Item GL Adjustment', NULL, NULL, NULL, NULL, 'BOOK_ONLY', 'TI', 'ADJ', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(77, 'AIAccrual', 'AIAccrual', 
'Allocation Item GL Accrual', NULL, NULL, NULL, NULL, 'BOOK_ONLY_REV', 'AI', 
'ACC', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(78, 'AIAdjustment', 'AIAdjustment', 
'Allocation Item GL Adjustment', NULL, NULL, NULL, NULL, 'BOOK_ONLY', 'AI', 
'ADJ', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(79, 'SwapAccumCost', 'SwapAccumCost', 
'Accumulation Swap', NULL, NULL, NULL, NULL, 'SWAPS', 'AC', 'SWAP', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(80, 'InventoryAdjustment', 
'InventoryAdjustment', 'Inventory Actual GL Adjustment', NULL, NULL, NULL, NULL, 
'BOOK_ONLY', 'AIA', 'ADJ', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(81, 'OTCSettlement', 'OTCSettlement', 
'OTC Cash Settlment', NULL, NULL, NULL, NULL, 'SWAPS', 'TI', 'OTC', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(86, 'TranportPrinPrim', 'TranportPrinPrim', 
'Tranportation Principle Primary', NULL, NULL, NULL, NULL, 'MANUAL', 'TI', 
'TPP', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(87, 'TIMEMO', 'TIMEMO', 'TI-Memo', NULL, NULL, 
NULL, NULL, 'MANUAL', 'TI', 'MEMO', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(88, 'AIMEMO', 'AIMEMO', 'AI-Memo', NULL, NULL, 
NULL, NULL, 'MANUAL', 'AI', 'MEMO', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(89, 'VMEMO', 'VMEMO', 'Voucher-Memo', NULL, 
NULL, NULL, NULL, 'MANUAL', 'V', 'MEMO', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(90, 'SwapBrokerageCost', 'SwapBrokerageCost', 
'SwapBrokerageCost', NULL, NULL, NULL, NULL, 'SWAPS', 'TI', 'SWBC', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(91, 'FutureBrokerageCost', 
'FutureBrokerageCost', 'FutureBrokerageCost', NULL, NULL, NULL, NULL, 'MANUAL', 
'TI', 'FBC', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(92, 'OptionsBrokerageCost', 
'OptionsBrokerageCost', 'OptionsBrokerageCost', NULL, NULL, NULL, NULL, 
'MANUAL', 'TI', 'OBC', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(93, 'PaperAllocation', 'PaperAllocation', 
'PaperAllocation', NULL, NULL, NULL, NULL, 'BOOK_ONLY', 'PA', 'PAC', 
'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(94, 'StorageTrade', 'StorageTrade', 
'StorageTrade', NULL, NULL, NULL, NULL, 'MANUAL', 'TI', 'STC', 'NOT_PARENT', 
'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(95, 'StorageMovementTI', 'StorageMovementTI', 
'StorageMovementTI', 'StorageMovementAI', 'ONE_OR_MORE', 'ALLOCATE', NULL, 
'NO_PROCESS', 'TI', 'SMC', 'PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(96, 'StorageMovementAI', 'StorageMovementAI', 
'StorageMovementAI', NULL, NULL, NULL, 'StorageMovementTI', 'MANUAL', 'AI', 
'SMC', 'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(97, 'StorageActualTI', 'StorageActualTI', 
'StorageActualTI', 'StorageActualAI', 'ONE_OR_MORE', 'ALLOCATE', NULL, 
'NO_PROCESS', 'TI', 'SAC', 'PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(98, 'StorageActualAI', 'StorageActualAI', 
'StorageActualAI', 'StorageActualAIA', 'ONE_OR_MORE', 'EST_ACTUAL', 
'StorageActualTI', 'NO_PROCESS', 'AI', 'SAC', 'PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(99, 'StorageActualAIA', 'StorageActualAIA', 
'StorageActualAIA', NULL, NULL, NULL, 'StorageActualAI', 'MANUAL', 'AIA', 'SAC', 
'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(100, 'TransportTrade', 'TransportTrade', 
'TransportTrade', NULL, NULL, NULL, NULL, 'MANUAL', 'TI', 'TTC', 'NOT_PARENT', 
'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(101, 'TransportMovementTI', 
'TransportMovementTI', 'TransportMovementTI', 'TransportMovementAI', 
'ONE_OR_MORE', 'ALLOCATE', NULL, 'NO_PROCESS', 'TI', 'TMC', 'PARENT', 
'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(102, 'TransportMovementAI', 
'TransportMovementAI', 'TransportMovementAI', NULL, NULL, NULL, 
'TransportMovementTI', 'MANUAL', 'AI', 'TMC', 'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(103, 'TransportActualTI', 'TransportActualTI', 
'TransportActualTI', 'TransportActualAI', 'ONE_OR_MORE', 'ALLOCATE', NULL, 
'NO_PROCESS', 'TI', 'TAC', 'PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(104, 'TransportActualAI', 'TransportActualAI', 
'TransportActualAI', 'TransportActualAIA', 'ONE_OR_MORE', 'EST_ACTUAL', 
'TransportActualTI', 'NO_PROCESS', 'AI', 'TAC', 'PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(105, 'TransportActualAIA', 
'TransportActualAIA', 'TransportActualAIA', NULL, NULL, NULL, 
'TransportActualAI', 'MANUAL', 'AIA', 'TAC', 'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(106, 'BookOutTI', 'BookOutTI', 
'Represents a BookOut owned by Trade Item', 'BookOutAI', 'ONE_OR_MORE', 
'ALLOCATE', 'NULL', 'NO_PROCESS', 'TI', 'BO', 'PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values(107, 'BookOutAI', 'BookOutAI', 
'Represents a BookOut owned by Allocation Item', 'BookOutAIA', 'ONE_OR_MORE', 
'EST_ACTUAL', 'BookOutTI', 'NO_PROCESS', 'AI', 'BO', 'PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(108, 'BookOutAIA', 'BookOutAIA', 
'Represents a BookOut owned by Allocation Item Actual', NULL, NULL, NULL, 
'BookOutAI', 'MANUAL', 'AIA', 'BO', 'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
   values(109, 'RNInterfaceCost', 
'Ralph&Nolan Interface Cost', 'Ralph&Nolan Interface Cost', NULL, NULL, NULL, 
NULL, 'BOOK_ONLY', 'P', 'RN', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type(bc_type_num,bc_type_code,bc_type_full_name,
             bc_type_desc,bc_children_type_code,bc_num_children_code,
             bc_child_gen_code,bc_parent_type_code,bc_init_fate_code,
             bc_owner_code,bc_sub_owner_code,bc_init_leaf_code,
             bc_matriarch_code,trans_id)
   values(110,'InsuranceFlatCost','InsuranceFlatCost','InsuranceFlatCost',
            NULL,NULL,NULL,NULL,'MANUAL','TI','INSURFLT','NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type (bc_type_num,bc_type_code,bc_type_full_name,bc_type_desc,
             bc_init_fate_code,bc_owner_code,bc_sub_owner_code,bc_init_leaf_code,
             bc_matriarch_code,trans_id) 
values (111,'BOOKOUT','BOOKOUT','Bookout','MANUAL','A','BO','NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type (bc_type_num,bc_type_code,bc_type_full_name,bc_type_desc,
      bc_init_fate_code,bc_owner_code,bc_sub_owner_code,bc_init_leaf_code,bc_matriarch_code,trans_id) 
values (112,'CAAdditionalTI','CAAdditionalTI','CAAdditionalTI','MANUAL','TI',
'ADDLTI','NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type (bc_type_num,bc_type_code,bc_type_full_name,bc_type_desc,
      bc_init_fate_code,bc_owner_code,bc_sub_owner_code,bc_init_leaf_code,
      bc_matriarch_code,trans_id) 
values (113,'CAAdditionalA','CAAdditionalA','CAAdditionalA','MANUAL','A',
        'ADDLA','NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type (bc_type_num,bc_type_code,bc_type_full_name,bc_type_desc,
      bc_init_fate_code,bc_owner_code,bc_sub_owner_code,bc_init_leaf_code,
      bc_matriarch_code,trans_id) 
values (114,'CAAdditionalAI','CAAdditionalAI','CAAdditionalAI','MANUAL','AI',
        'ADDLAI','NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type (bc_type_num,bc_type_code,bc_type_full_name,bc_type_desc,
      bc_init_fate_code,bc_owner_code,bc_sub_owner_code,bc_init_leaf_code,
      bc_matriarch_code,trans_id) 
values (115,'CAAdditionalAA','CAAdditionalAA','CAAdditionalAA','MANUAL','AIA',
        'ADDLAA','NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type (bc_type_num,bc_type_code,bc_type_full_name,bc_type_desc,
      bc_init_fate_code,bc_owner_code,bc_sub_owner_code,bc_init_leaf_code,
      bc_matriarch_code,trans_id) 
values (116,'CAAdditionalP','CAAdditionalP','CAAdditionalP','MANUAL','P','ADDLP',
        'NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type (bc_type_num,bc_type_code,bc_type_full_name,bc_type_desc,
     bc_init_fate_code,bc_owner_code,bc_sub_owner_code,bc_init_leaf_code,
     bc_matriarch_code,trans_id) 
values (117,'CAAdditionalPG','CAAdditionalPG','CAAdditionalPG','MANUAL','PG',
        'ADDLPG','NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type (bc_type_num,bc_type_code,bc_type_full_name,bc_type_desc,
     bc_init_fate_code,bc_owner_code,bc_sub_owner_code,bc_init_leaf_code,
     bc_matriarch_code,trans_id) 
values (118,'INVROLL','INVROLL','INVROLL',
            'BOOK_ONLY_REV','I','INVROLL','NOT_PARENT',
            'MATRIARC',1)
go


/* bus_cost_types for BUNKER */
insert into dbo.bus_cost_type 
  values (121, 'BunkerTIPrinPrim', 'BunkerTIPrinPrim', 'BunkerTIPrinPrim', 'BunkerAIPrinPrim', 
             'ONE_OR_MORE', 'ALLOCATE',  NULL, 'NO_PROCESS', 'TI', 'BPP', 'PARENT', 'MATRIARC',  1)
go

insert into dbo.bus_cost_type 
  values (122, 'BunkerTOAddlPrim', 'BunkerTOAddlPrim', 'BunkerTOAddlPrim', 'BunkerAIAddlPrim', 
             NULL, 'ALLOCATE', NULL, 'NO_PROCESS', 'TO', 'BAP', 'PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
  values (123, 'BunkerTOSec', 'BunkerTOSec', 'BunkerTOSec', 
             NULL, NULL, NULL, NULL, 'NO_PROCESS', 'TO', 'BS', 'NOT_PARENT', 'MATRIARC', 1 )
go

insert into dbo.bus_cost_type 
  values (124, 'BunkerAIAAddlPrim', 'BunkerAIAAddlPrim', 'BunkerAIAAddlPrim', NULL, NULL, NULL, 
               'BunkerAIAddlPrim', 'MANUAL', 'AIA', 'BAP', 'NOT_PARENT', 'DEPENDNT', 1) 
go

insert into dbo.bus_cost_type 
  values (127, 'BrokerageTO', 'BrokerageTO', 'BrokerageTO', NULL,NULL,NULL,NULL, 'MANUAL', 
               'TO', 'BBC', 'NOT_PARENT', 'MATRIARC', 1) 
go

insert into dbo.bus_cost_type 
  values (128, 'BunkerAIPrinPrim', 'BunkerAIPrinPrim', 'BunkerAIPrinPrim', 'BunkerAIAPrinPrim', 
               'ONE_OR_MORE', 'EST_ACTUAL', 'BunkerTIPrinPrim', 'NO_PROCESS', 'AI', 'BPP', 
               'PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
  values (129, 'BunkerAIAddlPrim', 'BunkerAIAddlPrim', 'BunkerAIAddlPrim', 'BunkerAIAAddlPrim', 
               'ONE_OR_MORE', 'EST_ACTUAL', 'BunkerTOAddlPrim', 'NO_PROCESS', 'AI', 'BAP', 
               'PARENT', 'DEPENDNT', 1) 
go

insert into dbo.bus_cost_type 
  values (133, 'BunkerAIAPrinPrim', 'BunkerAIAPrinPrim', 'BunkerAIAPrinPrim', NULL, NULL, 
               NULL, 'BunkerAIPrinPrim', 'MANUAL', 'AIA', 'BPP', 'NOT_PARENT', 'DEPENDNT', 1) 
go

insert into dbo.bus_cost_type 
  values (136, 'BunkerTransLump', 'BunkerTransLump', 'BunkerTransLump', NULL,NULL,NULL,
                NULL, 'NO_PROCESS', 'TO', 'BTL', 'NOT_PARENT', 'MATRIARC', 1 )
go

insert into dbo.bus_cost_type 
  values (137, 'BunkerTITransUnit', 'BunkerTITransUnit', 'BunkerTITransUnit', 'BunkerAITransUnit', 
               'ONE_OR_MORE', 'ALLOCATE', NULL, 'NO_PROCESS', 'TI', 'BTU', 'PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
  values (138, 'BunkerAITransUnit', 'BunkerAITransUnit', 'BunkerAITransUnit', 'BunkerAATransUnit', 
               'ONE_OR_MORE', 'EST_ACTUAL', 'BunkerTITransUnit', 'NO_PROCESS', 'AI', 'BTU', 
               'PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
  values (139, 'BunkerAATransUnit', 'BunkerAATransUnit', 'BunkerAATransUnit', NULL,NULL,NULL, 
               'BunkerAITransUnit', 'MANUAL', 'AIA', 'BTU', 'NOT_PARENT', 'DEPENDNT', 1)
go

insert into dbo.bus_cost_type 
  values (140, 'WORLDSCALE', 'WORLDSCALE', 'WORLD SCALE', NULL, NULL, NULL, 
               NULL, 'MANUAL', 'A', 'WLDSCL', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
  values (141, 'SwapAdditional', 'SwapAdditional', 'SwapAdditional', NULL, NULL, NULL, 
               NULL, 'MANUAL', 'TI', 'ADDLSWAP', 'NOT_PARENT', 'MATRIARC', 1)
go

insert into dbo.bus_cost_type 
   values (142, 'DailyFifoBrokerag', 'DailyFifoBrokerag', 'DailyFifoBrokerag', 
            NULL,NULL,NULL,NULL, 'MANUAL', 'FI', 'DFB', 'NOT_PARENT', 
            'MATRIARC', 1) 
go

insert into dbo.bus_cost_type 
   values (143, 'InterdayFifoBrokerag', 'InterdayFifoBrokerage', 'InterdayFifoBrokerage', 
            NULL,NULL,NULL,NULL, 'MANUAL', 'FI', 'MFB', 'NOT_PARENT', 'MATRIARC', 1) 
go

insert into dbo.bus_cost_type 
   values (144, 'TradeFutureBrokerage', 'TradeFutureBrokerage', 'TradeFutureBrokerage', 
            NULL,NULL,NULL,NULL, 'MANUAL', 'TI', 'TFB', 'NOT_PARENT', 'MATRIARC', 1) 
go

/* added by Peter Lo    8/9/2004  issue #10533 */
insert into dbo.bus_cost_type 
   values (145,'JVP','Joint Venture Portfolio cost','Joint Venture Portfolio Cost', 
            NULL,NULL,NULL,NULL,'MANUAL','P','JV','NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type 
   values (146,'JVOP','Joint Venture Portfolio Offset cost','Joint Venture Portfolio Offset Cost', 
            NULL,NULL,NULL,NULL,'MANUAL','P','JVO','NOT_PARENT','MATRIARC',1)
go

/* added by Peter Lo    9/20/2004  issue #10805 */
insert into dbo.bus_cost_type 
  (bc_type_num, bc_type_code, bc_type_full_name,
   bc_type_desc, bc_children_type_code, bc_num_children_code,
   bc_child_gen_code, bc_parent_type_code, bc_init_fate_code,
   bc_owner_code, bc_sub_owner_code, bc_init_leaf_code,
   bc_matriarch_code, trans_id)
   values (147,'BOAllocItem','BOAllocItem','AI owned cost for Bookout', 
            NULL,NULL,NULL,NULL,'MANUAL','AI','BOAI','NOT_PARENT','MATRIARC',1)
go

/* added by Peter Lo    10/05/2004  issue #10924 */
insert into dbo.bus_cost_type 
  (bc_type_num, bc_type_code, bc_type_full_name,
   bc_type_desc, bc_children_type_code, bc_num_children_code,
   bc_child_gen_code, bc_parent_type_code, bc_init_fate_code,
   bc_owner_code, bc_sub_owner_code, bc_init_leaf_code,
   bc_matriarch_code, trans_id)
   values (148,'CurrPrinPrimRec','CurrPrinPrimRec','CurrPrinPrimRec', 
            NULL,NULL,NULL,NULL,'MANUAL','TI','CPR','NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type 
  (bc_type_num, bc_type_code, bc_type_full_name,
   bc_type_desc, bc_children_type_code, bc_num_children_code,
   bc_child_gen_code, bc_parent_type_code, bc_init_fate_code,
   bc_owner_code, bc_sub_owner_code, bc_init_leaf_code,
   bc_matriarch_code, trans_id)
   values (149,'CurrPrinPrimPay','CurrPrinPrimPay','CurrPrinPrimPay', 
            NULL,NULL,NULL,NULL,'MANUAL','TI','CPP','NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type 
  (bc_type_num, bc_type_code, bc_type_full_name,
   bc_type_desc, bc_children_type_code, bc_num_children_code,
   bc_child_gen_code, bc_parent_type_code, bc_init_fate_code,
   bc_owner_code, bc_sub_owner_code, bc_init_leaf_code,
   bc_matriarch_code, trans_id)
   values (150,'CurrBrokerageCost','CurrBrokerageCost','CurrBrokerageCost', 
            NULL,NULL,NULL,NULL,'MANUAL','TI','CBC','NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type 
  (bc_type_num, bc_type_code, bc_type_full_name,
   bc_type_desc, bc_children_type_code, bc_num_children_code,
   bc_child_gen_code, bc_parent_type_code, bc_init_fate_code,
   bc_owner_code, bc_sub_owner_code, bc_init_leaf_code,
   bc_matriarch_code, trans_id)
   values (151,'TAX','TAX','TAX',NULL,NULL,NULL,NULL,
           'BOOK_ONLY_REV','I','TAX','NOT_PARENT','MATRIARC',1)
go

insert into dbo.bus_cost_type
   (bc_type_num, bc_type_code, bc_type_full_name, bc_type_desc,
    bc_children_type_code, bc_num_children_code, bc_child_gen_code,
    bc_parent_type_code, bc_init_fate_code, bc_owner_code,
    bc_sub_owner_code, bc_init_leaf_code, bc_matriarch_code, trans_id)
    values(152, 'RINPrinPrim', 'RINPrinPrim', 'RINPrinPrim',
            NULL, NULL, NULL, NULL,'MANUAL','TI','RINPP','NOT_PARENT',
            'MATRIARC', 1)   
go

insert into dbo.bus_cost_type
  (bc_type_num, bc_type_code, bc_type_full_name, bc_type_desc,
   bc_children_type_code, bc_num_children_code, bc_child_gen_code,
   bc_parent_type_code, bc_init_fate_code, bc_owner_code,
   bc_sub_owner_code, bc_init_leaf_code, bc_matriarch_code, trans_id)
   values(153, 'RINAddPrim', 'RINAddPrim', 'RINAddPrim',
            NULL,NULL,NULL,NULL,'MANUAL','TI','RINAP',
            'NOT_PARENT','MATRIARC',1)   
go


set nocount on

declare @oid                   smallint,
        @bc_type_num           int,
        @bc_type_code          varchar(20),
        @bc_type_full_name     varchar(40),
        @bc_type_desc          varchar(255),
        @bc_children_type_code varchar(20),
        @bc_num_children_code  varchar(20),
        @bc_child_gen_code     varchar(20),
        @bc_parent_type_code   varchar(20),
        @bc_init_fate_code     varchar(20),
        @bc_owner_code         varchar(20),
        @bc_sub_owner_code     varchar(20),
        @bc_init_leaf_code     varchar(20),
        @bc_matriarch_code     varchar(20),
        @smsg                  varchar(255),
        @rows_affected         int,
        @errcode               int
        
select @errcode = 0

CREATE TABLE #bus_cost_type 
(
    oid                   smallint     PRIMARY KEY,
    bc_type_code          varchar(20)  NOT NULL,
    bc_type_full_name     varchar(40)  NOT NULL,
    bc_type_desc          varchar(255) NULL,
    bc_children_type_code varchar(20)  NULL,
    bc_num_children_code  varchar(20)  NULL,
    bc_child_gen_code     varchar(20)  NULL,
    bc_parent_type_code   varchar(20)  NULL,
    bc_init_fate_code     varchar(20)  NULL,
    bc_owner_code         varchar(20)  NULL,
    bc_sub_owner_code     varchar(20)  NULL,
    bc_init_leaf_code     varchar(20)  NULL,
    bc_matriarch_code     varchar(20)  NULL
)

insert into #bus_cost_type 
   values (1,'WetPhyTIExchAdj','WetPhyTIExchAdj','WetPhyTIExchAdj',NULL,NULL,NULL,NULL,'NO_PROCESS','TI','TI-EXCH','PARENT','MATRIARC')
insert into #bus_cost_type 
   values (2,'WetPhyTITermAdj','WetPhyTITermAdj','WetPhyTITermAdj',NULL,NULL,NULL,NULL,'NO_PROCESS','TI','TI-TERM','PARENT','MATRIARC')
insert into #bus_cost_type 
   values (3,'WetPhyTIRefAdj','WetPhyTIRefAdj','WetPhyTIRefAdj',NULL,NULL,NULL,NULL,'NO_PROCESS','TI','TI-REF','PARENT','MATRIARC')
insert into #bus_cost_type 
   values (4,'WetPhyTIOtherAdj','WetPhyTIOtherAdj','WetPhyTIOtherAdj',NULL,NULL,NULL,NULL,'NO_PROCESS','TI','TI-OTHER','PARENT','MATRIARC')
insert into #bus_cost_type 
   values (5, 'POMAXFINCOST', 'Pomax financial cost', 'Pomax financial cost',
           NULL,NULL,NULL,NULL,'BOOK_ONLY','P','POMAXFIN','NOT_PARENT','MATRIARC')
insert into #bus_cost_type 
   values (6, 'POMAXPHYCOST', 'Pomax physical cost', 'Pomax physical cost',
           NULL,NULL,NULL,NULL,'BOOK_ONLY','P','POMAXPHY','NOT_PARENT','MATRIARC')
insert into #bus_cost_type
   values (7, 'POMAXSECCOCOST', 'Pomax secondary CO cost', 'Pomax secondary CO cost',
           NULL,NULL,NULL,NULL,'BOOK_ONLY','CO','POMAXSEC','NOT_PARENT','MATRIARC')
insert into #bus_cost_type
   values (8, 'InternalOffset', 'Internal_Offset', 'Internal Offset Cost',
           NULL,NULL,NULL,NULL,'MANUAL','CO','ICO','NOT_PARENT','MATRIARC')
insert into #bus_cost_type
   values (9, 'PREFINAL', 'PREFINAL', 'Prefinal cost for a principal primary when its preliminary cost is vouchered', 
           'PRELIMOFFSET', 'ONE_OR_MORE', 'PRELIMOFFSET', null, 'MANUAL', 'CO', 'PRF', 'PARENT', 'MATRIARC')
insert into #bus_cost_type
   values (10, 'PREFINALOFFSET', 'PREFINAL_OFFSET', 'Offset to the Prefinal cost for a principal primary when its preliminary cost is vouchered',
           'PRELIMOFFSET', null, null, 'PREFINAL', 'MANUAL', 'CO', 'PFO', 'NOT_PARENT', 'DEPENDNT')



select @oid = min(oid)
from #bus_cost_type

while @oid is not null
begin
   select 
       @bc_type_code = bc_type_code,
       @bc_type_full_name = bc_type_full_name,
       @bc_type_desc = bc_type_desc,
       @bc_children_type_code = bc_children_type_code,
       @bc_num_children_code = bc_num_children_code,
       @bc_child_gen_code = bc_child_gen_code,
       @bc_parent_type_code = bc_parent_type_code,
       @bc_init_fate_code = bc_init_fate_code,
       @bc_owner_code = bc_owner_code,
       @bc_sub_owner_code = bc_sub_owner_code,
       @bc_init_leaf_code = bc_init_leaf_code,
       @bc_matriarch_code = bc_matriarch_code
   from #bus_cost_type
   where oid = @oid

   select @smsg = '=> Adding the bc_type_code ''' + @bc_type_code + ''' ...'
   print @smsg   
   if not exists (select 1
                  from dbo.bus_cost_type
                  where bc_type_code = @bc_type_code)
   begin
      select @bc_type_num = null
      select @bc_type_num = isnull(max(bc_type_num), 0) + 1
      from dbo.bus_cost_type
      select @errcode = @@error
      if @errcode > 0 or @bc_type_num is null
      begin
         print '==> Failed to obtain a new bc_type_num!'
         goto endofscript
      end

      begin tran
      insert into dbo.bus_cost_type
        values(@bc_type_num, 
               @bc_type_code,
               @bc_type_full_name,
               @bc_type_desc,
               @bc_children_type_code,
               @bc_num_children_code,
               @bc_child_gen_code,
               @bc_parent_type_code,
               @bc_init_fate_code,
               @bc_owner_code,
               @bc_sub_owner_code,
               @bc_init_leaf_code,
               @bc_matriarch_code,
               1)
      select @rows_affected = @@rowcount,
             @errcode = @@error
      if @errcode > 0
      begin
         if @@trancount > 0
            rollback tran
         print '==> Failed to add the new bus_cost_type!'
         goto endofscript
      end
      commit tran
      if @rows_affected > 0
      begin
         select @smsg = '==> Added OK (bc_type_num #' + convert(varchar, @bc_type_num) + ')'
         print @smsg
      end
      else
         print '==> Not Added'
   end
   else
      print '==> Existed Already'
      
   select @oid = min(oid)
   from #bus_cost_type
   where oid > @oid    
end
endofscript:
drop table #bus_cost_type
go


