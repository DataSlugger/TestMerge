set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bus_cost_fate_group
go

print 'Loading system reference data into the bus_cost_fate_group table ...'
go

insert into dbo.bus_cost_fate_group 
   values('CON', 'Contract', 'Group By Contract (Trade) Number', 1)
go

insert into dbo.bus_cost_fate_group 
   values('ITEM', 'Item', 'Group By Trade Item Type', 1)
go

insert into dbo.bus_cost_fate_group 
   values('LOC', 'Location', 'Group By Location', 1)
go

insert into dbo.bus_cost_fate_group 
   values('OWN', 'Owner', 'Group by Owner Code', 1)
go

insert into dbo.bus_cost_fate_group 
   values('PARE', 'Payable/Receivable', 'Group By Payable vs Receivable Indicator', 1)
go

insert into dbo.bus_cost_fate_group 
   values('PCPD', 'Period Indicator', 'Group By Prior vs. Current Period Indicator', 1)
go

insert into dbo.bus_cost_fate_group 
   values('SINGLE', 'SINGLE', 'Vouched By Itself', 1)
go

