set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the als_run_status table ...'
go

if not exists (select 1
               from als_run_status
               where als_run_status_desc = 'PENDING')
   insert into als_run_status
      (als_run_status_id, als_run_status_desc, trans_id)
     values(0, 'PENDING', 1)
go

if not exists (select 1
               from als_run_status
               where als_run_status_desc = 'WORKING')
   insert into als_run_status
      (als_run_status_id, als_run_status_desc, trans_id)
     values(1, 'WORKING', 1)
go

if not exists (select 1
               from als_run_status
               where als_run_status_desc = 'COMPLETED')
   insert into als_run_status
      (als_run_status_id, als_run_status_desc, trans_id)
     values(2, 'COMPLETED', 1)
go

if not exists (select 1
               from als_run_status
               where als_run_status_desc = 'FAILED')
   insert into als_run_status
      (als_run_status_id, als_run_status_desc, trans_id)
     values(3, 'FAILED', 1)
go

if not exists (select 1
               from als_run_status
               where als_run_status_desc = 'DBSAVEFAILED')
   insert into als_run_status
      (als_run_status_id, als_run_status_desc, trans_id)
     values(4, 'DBSAVEFAILED', 1)
go

if not exists (select 1
               from als_run_status
               where als_run_status_desc = 'UNNEEDED')
   insert into als_run_status
      (als_run_status_id, als_run_status_desc, trans_id)
     values(5, 'UNNEEDED', 1)
go

/* MISSINGDATA 
      This status occurs when we encounter missing reference data 
      exception in ALS.  When this status is set, ALS will restart 
      once, and if again encounters a missing data exception for 
      the same sequence, it will go to sleep. This will cause backup.  
      The users will have to add the missing data (known from the 
      emails which go out and ALS logs), and manually restart the ALS. 
*/

if not exists (select 1
               from als_run_status
               where als_run_status_desc = 'MISSINGDATA')
   insert into als_run_status
      (als_run_status_id, als_run_status_desc, trans_id)
     values(6, 'MISSINGDATA', 1)
go

/*
   CRASHED 
      This status occurs when we encounter a fatal error (i.e. unknown 
      selector etc.).  When this status is set, ALS will restart once, 
      and if again encounters a fatal error for the same sequence, it 
      will skip the sequence.
*/

if not exists (select 1
               from als_run_status
               where als_run_status_desc = 'CRASHED')
   insert into als_run_status
      (als_run_status_id, als_run_status_desc, trans_id)
     values(7, 'CRASHED', 1)
go


