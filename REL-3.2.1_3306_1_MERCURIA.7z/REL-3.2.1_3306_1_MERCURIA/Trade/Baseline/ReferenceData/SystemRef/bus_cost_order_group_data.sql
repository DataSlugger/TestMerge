set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the bus_cost_order_group table ...'
go

truncate table bus_cost_order_group
go

INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(1,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(2,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(3,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(5,'OPTION  ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(6,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(7,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(8,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(9,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(10,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(11,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(12,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(13,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(14,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(15,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(31,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(32,'OTHER   ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(33,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(34,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(35,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(36,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(37,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(38,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(39,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(40,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(41,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(42,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(43,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(44,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(45,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(46,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(47,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(48,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(49,'OTHER   ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(50,'OTHER   ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(51,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(52,'OPTION  ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(53,'OPTION  ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(55,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(56,'OTHER   ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(57,'OTHER   ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(58,'OTHER   ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(59,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(60,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(61,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(63,'DERIV   ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(65,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(66,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(67,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(68,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(69,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(70,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(75,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(76,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(77,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(78,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(79,'DERIV   ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(80,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(81,'OPTION  ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(86,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(87,'OTHER   ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(88,'OTHER   ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(89,'OTHER   ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(90,'DERIV   ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(91,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(92,'OPTION  ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(93,'NA      ',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(94,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(95,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(96,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(97,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(98,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(99,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(100,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(101,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(102,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(103,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(104,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(105,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(106,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(107,'PHYSICAL',1)
go
INSERT INTO dbo.bus_cost_order_group(bc_type_num,order_type_group,trans_id)
                         VALUES(108,'PHYSICAL',1)
go

