set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the location_type table ...'
go

if not exists (select 1
               from dbo.location_type
               where loc_type_code = 'DEL')
   insert into dbo.location_type 
        (loc_type_code, loc_type_desc, trans_id) 
      values('DEL', 'Delivery', 1)
go

if not exists (select 1
               from dbo.location_type
               where loc_type_code = 'EXCL VOT')
   insert into dbo.location_type 
        (loc_type_code, loc_type_desc, trans_id) 
      values('EXCL VOT', 'EXCLUDING VOTT', 1)
go

if not exists (select 1
               from dbo.location_type
               where loc_type_code = 'OFF')
   insert into dbo.location_type 
        (loc_type_code, loc_type_desc, trans_id) 
      values('OFF', 'Office location', 1)
go

if not exists (select 1
               from dbo.location_type
               where loc_type_code = 'RAC')
   insert into dbo.location_type 
        (loc_type_code, loc_type_desc, trans_id) 
      values('RAC', 'Rack location', 1)
go

if not exists (select 1
               from dbo.location_type
               where loc_type_code = 'RCP')
   insert into dbo.location_type 
        (loc_type_code, loc_type_desc, trans_id) 
      values('RCP', 'Recap location', 1)
go

if not exists (select 1
               from dbo.location_type
               where loc_type_code = 'TAX')
   insert into dbo.location_type 
        (loc_type_code, loc_type_desc, trans_id) 
      values('TAX', 'Tax location', 1)
go

if not exists (select 1
               from dbo.location_type
               where loc_type_code = 'TRANSP')
   insert into dbo.location_type 
        (loc_type_code, loc_type_desc, trans_id) 
      values('TRANSP', 'Transportation location', 1)
go

if not exists (select 1
               from dbo.location_type
               where loc_type_code = 'STOR')
   insert into dbo.location_type 
        (loc_type_code, loc_type_desc, trans_id) 
      values('STOR', 'Storage Location', 1)
go

if not exists (select 1
               from dbo.location_type
               where loc_type_code = 'INVOPLIM')
   insert into dbo.location_type 
        (loc_type_code, loc_type_desc, trans_id) 
      values ('INVOPLIM','Inventory Operating Limits',1)
go

if not exists (select 1
               from dbo.location_type
               where loc_type_code = 'CVXRS')
   insert into dbo.location_type 
        (loc_type_code, loc_type_desc, trans_id) 
      values('CVXRS', 'CVX RefiningSupply', 1)
go

if not exists (select 1
               from dbo.location_type
               where loc_type_code = 'CVXMS')
   insert into dbo.location_type 
        (loc_type_code, loc_type_desc, trans_id) 
      values('CVXMS', 'CVX MarketingSupply', 1)
go

-- This new type will be use to distinguish inventory currently in transit. 
if not exists (select 1
               from dbo.location_type
               where loc_type_code = 'CVXIT')
   INSERT dbo.location_type (loc_type_code, loc_type_desc, trans_id) 
       VALUES ('CVXIT', 'CVX In-Transit', 1)
go
