set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the icts_trans_sequence table ...'
go

IF NOT EXISTS (select * 
               from dbo.icts_trans_sequence
               where oid = 1)
   INSERT INTO dbo.icts_trans_sequence(oid, last_num)
      VALUES(1, 0)
go

