set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the parcel_status table ...' 
go

create table #status
(
   oid					        tinyint		  not null,
   status_description	  varchar(32)	not null,
   status_ind			      tinyint		  not null,
   status_workflow_rank tinyint	    not null,
   enable_profit_loss   char(1)     not null
)

insert into #status 
    (oid, status_description, status_ind, status_workflow_rank, enable_profit_loss)
   values(1, 'Planned', 2, 1, 'N')	
insert into #status 
    (oid, status_description, status_ind, status_workflow_rank, enable_profit_loss)
   values(2, 'Submitted', 0, 2, 'N')	
insert into #status 
    (oid, status_description, status_ind, status_workflow_rank, enable_profit_loss)
   values(3, 'Rejected', 0, 3, 'N')	
insert into #status 
    (oid, status_description, status_ind, status_workflow_rank, enable_profit_loss)
   values(4, 'Deleted', 1, 4, 'N')	
insert into #status 
    (oid, status_description, status_ind, status_workflow_rank, enable_profit_loss)
   values(5, 'Pre-Allocated', 1, 5, 'N')	
insert into #status 
    (oid, status_description, status_ind, status_workflow_rank, enable_profit_loss)
   values(6, 'Allocated', 2, 6, 'Y')	
insert into #status 
    (oid, status_description, status_ind, status_workflow_rank, enable_profit_loss)
   values(7, 'Nominated', 0, 7, 'Y')	
insert into #status 
    (oid, status_description, status_ind, status_workflow_rank, enable_profit_loss)
   values(8, 'Confirmed', 0, 8, 'Y')	
insert into #status 
    (oid, status_description, status_ind, status_workflow_rank, enable_profit_loss)
   values(9, 'Scheduled', 2, 9, 'Y')	
insert into #status 
    (oid, status_description, status_ind, status_workflow_rank, enable_profit_loss)
   values(10, 'Partially Actualized', 1, 10, 'Y')	
insert into #status 
    (oid, status_description, status_ind, status_workflow_rank, enable_profit_loss)
   values(11, 'Fully Actualized', 2, 11, 'Y')	



/* Code starts here */
declare @oid                  tinyint,
        @newoid               tinyint,
        @status_description	  varchar(32),
        @status_ind			      tinyint,
        @status_workflow_rank tinyint,
        @enable_profit_loss   char(1),
        @errcode              int,
        @rows_affected        int,
        @smsg                 varchar(255)

select @errcode = 0

select @oid = min(oid)
from #status

while @oid is not null
begin
   select @status_description	= status_description,
          @status_ind	= status_ind,
          @status_workflow_rank = status_workflow_rank,
          @enable_profit_loss = enable_profit_loss
   from #status
   where oid = @oid
   
   if not exists (select 1
                  from dbo.parcel_status
                  where status_description = @status_description)
   begin
      begin tran
      select @newoid = isnull(max(oid), 0) + 1
      from dbo.parcel_status
      
      insert into dbo.parcel_status
           (oid, status_description, status_ind, status_workflow_rank, enable_profit_loss, trans_id)
         values(@newoid, @status_description, @status_ind, @status_workflow_rank, @enable_profit_loss, 1)
      select @rows_affected = @@rowcount,
             @errcode = @@error
      if @errcode > 0
      begin
         if @@trancount > 0
            rollback tran
         select @smsg = '=> Failed to add the parcel status ''' + @status_description + '''!'
         print @smsg
         goto endofscript
      end
      commit tran
      if @rows_affected > 0
      begin
         select @smsg = '=> Added the parcel status ''' + @status_description + '''!'
         print @smsg
      end      
   end

   select @oid = min(oid)
   from #status
   where oid > @oid
end
endofscript:
drop table #status
go

