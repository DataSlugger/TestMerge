set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table mot_type
go

print 'Loading system reference data into the mot_type table ...'
go

insert into mot_type values('P', 'PIPELINE', 1)
go

insert into mot_type values('R', 'RAILCAR', 1)
go

insert into mot_type values('S', 'STORAGE', 1)
go

insert into mot_type values('T', 'TRUCK', 1)
go

-- removed 8-04-2001  requested by Zimin
-- insert into mot_type values('W', 'WATERBORNE', 1)

insert into mot_type values('B', 'BARGE', 1)
go

insert into mot_type values('V', 'VESSEL', 1)
go

-- added for Sempra
insert into mot_type values('G', 'TBN', 1)
go

-- added for Mercuria
if not exists (select 1
               from dbo.mot_type            
               where mot_type_code = 'H' and
                     mot_type_short_name = 'HUB')
   insert into dbo.mot_type values('H', 'HUB', 1)
go

-- added for Mercuria
if not exists (select 1
               from dbo.mot_type
               where mot_type_code = 'F' and
                     mot_type_short_name = 'FLANGE')
   insert into dbo.mot_type values('F', 'FLANGE', 1)
go

if not exists (select 1 
               from dbo.mot_type 
               where mot_type_code = 'C' and 
                     mot_type_short_name = 'CANCEL_FOR_FEE')
   insert into dbo.mot_type
      values ('C', 'CANCEL_FOR_FEE', 1)
go

if not exists (select 1 
               from dbo.mot_type 
               where mot_type_code = 'N' and 
                     mot_type_short_name = 'NETOUT')
   insert into dbo.mot_type
      values ('N', 'NETOUT',1)
go

if not exists (select 1 
               from dbo.mot_type 
               where mot_type_code = 'O' and 
                     mot_type_short_name = 'BOOKOUT')
   insert into dbo.mot_type
      values ('O', 'BOOKOUT', 1)
go

if not exists (select 1 
               from dbo.mot_type 
               where mot_type_code = 'L' and 
                     mot_type_short_name = 'BLENDING')
   insert into dbo.mot_type
      values ('L', 'BLENDING', 1)
go


