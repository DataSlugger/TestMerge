/* ****************************************************************
    This db script populates the data for each function in the
    icts_function table into the new tables:

             function_detail,
             function_detail_value

    For each function_num, a following function_detail record will 
    be added 
          fd_id        : <a new fd_id which can be obtained from
                            new_num table>
          function_num : <a function_num from icts_function table>
          entity_name  : 'LEVEL'

    and the following 3 function_detail_value records will be added 

      record #1
          fdv_id       : <a new fdv_id which can be obtained from
                            new_num table>
          fd_id        : <from the record just added into function_detail
                              table>
          data_type    : 'S'
          attr_value   : 'OWN'

      record #2
          fdv_id       : <a new fdv_id which can be obtained from
                            new_num table>
          fd_id        : <from the record just added into function_detail
                              table>
          data_type    : 'S'
          attr_value   : 'DEPT'

      record #3
          fdv_id       : <a new fdv_id which can be obtained from
                            new_num table>
          fd_id        : <from the record just added into function_detail
                              table>
          data_type    : 'S'
          attr_value   : 'ANY'
          
      NOTE: The code below also appears in SystemSeed\portfolio_tag_definition_data.sql

    Author     : Peter Lo
    Date       : 12/21/2012
    Database   : MS SQL Server 2000 or later
    Company    : Amphora, Inc
   **************************************************************** */

set nocount on

set QUOTED_IDENTIFIER ON
go

declare @fd_id        int,
        @fdv_id       int,
        @smsg         varchar(255),
        @function_num int,
        @errcode      int

select @smsg = 'Adding function_detail/function_detail_value records if needed for function(s) in icts_function table ...'
print ' '
print @smsg
print ' '

select @function_num = min(function_num)
from dbo.icts_function
where function_num not in (6000)

while @function_num is not null
begin
   if not exists (select 1
                  from dbo.function_detail
                  where function_num = @function_num and
                        entity_name = 'LEVEL')
   begin
      select @smsg = '=> function_detail (LEVEL): function #' + convert(varchar, @function_num) + ' ...'
      print @smsg
      begin tran
      select @fd_id = isnull(max(fd_id), 0) + 1
      from function_detail
      insert into function_detail
        (fd_id,function_num,entity_name,attr_name,operation,entity_ind,trans_id)
        values(@fd_id, @function_num, 'LEVEL', NULL, NULL, 0, 1)
      select @errcode = @@error
      if @errcode > 0
      begin
         rollback tran
         break
      end

      select @fdv_id = isnull(max(fdv_id), 0) + 1
      from dbo.function_detail_value
      insert into dbo.function_detail_value
         (fdv_id,fd_id,data_type,attr_value,trans_id)
        values(@fdv_id, @fd_id, 'S', 'OWN', 1)
      select @errcode = @@error
      if @errcode > 0
      begin
         rollback tran
         break
      end

      select @fdv_id = @fdv_id + 1
      insert into dbo.function_detail_value
         (fdv_id,fd_id,data_type,attr_value,trans_id)
        values(@fdv_id, @fd_id, 'S', 'DEPT', 1)
      select @errcode = @@error
      if @errcode > 0
      begin
         rollback tran
         break
      end

      select @fdv_id = @fdv_id + 1
      insert into dbo.function_detail_value
         (fdv_id,fd_id,data_type,attr_value,trans_id)
        values(@fdv_id, @fd_id, 'S', 'ANY', 1)
      select @errcode = @@error
      if @errcode > 0
      begin
         rollback tran
         break
      end
      commit tran
   end

   select @function_num = min(function_num)
   from dbo.icts_function
   where function_num not in (6000) and
         function_num > @function_num   
end
go

exec dbo.refresh_a_last_num 'function_detail', 'fd_id'
go

exec dbo.refresh_a_last_num 'function_detail_value', 'fdv_id'
go

