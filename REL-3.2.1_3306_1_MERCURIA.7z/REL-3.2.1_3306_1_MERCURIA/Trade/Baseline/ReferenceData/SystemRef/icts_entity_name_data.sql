set nocount on

set QUOTED_IDENTIFIER ON
go

/* --------------------------------------------------------
    Every entity_name appeared in the entity_key_name table 
    should have an entry in the icts_entity_name table.
    
    But, it is possible that a new entry which does not 
    exist in the entity_key_name table can be added into
    the icts_entity_name table.
*/

print ' '
print 'Making sure that the icts_entity_name table has all entity names'
print 'appearing in the entity_key_name table ...'
go

declare @entity_name   varchar(30),
        @oid           int,
        @smsg          varchar(255)

select @entity_name = min(entity_name)
from dbo.entity_key_name

while @entity_name is not null
begin
   if not exists (select 1
                  from dbo.icts_entity_name
                  where entity_name = @entity_name)
   begin
      select @smsg = '=> icts_entity_name: Added the entity name ''' + @entity_name + ''''
      print @smsg
      begin tran
      select @oid = isnull(max(oid), 0) + 1
      from dbo.icts_entity_name
      
      insert into dbo.icts_entity_name
         (oid, entity_name, entity_status, trans_id)
        values(@oid, @entity_name, 'A', 1) 
      commit tran
   end

   select @entity_name = min(entity_name)
   from dbo.entity_key_name
   where entity_name > @entity_name
end
go

exec dbo.refresh_a_last_num 'icts_entity_name', 'oid'
go

/* ************************************************************ */
if object_id('tempdb..#icts_entity_name') is not null
   exec('drop table #icts_entity_name')
go

create table #icts_entity_name 
(
   id              int identity(1, 1),
   entity_name     varchar(30),
   entity_status   char(1)
)
go

insert into #icts_entity_name
select 'AiEstActualSpec', 'A'	
union all
select 'FormulaBodyTrigger', 'A' 
union all
select 'TradeItemSpec', 'A'		
union all
select 'FormulaComponent', 'A'
go

declare @oid           int,
	    @rows_affected int,
	    @errcode       int,
	    @trans_id      int

set @trans_id = 1
if not exists (select 1 
               from #icts_entity_name tien 
			           inner join dbo.icts_entity_name ien
			              on ien.entity_name = tien.entity_name) 
begin
   begin tran
   begin try
     insert into dbo.icts_entity_name 
	      (oid, entity_name, entity_status, trans_id)
     select id + @oid, entity_name, entity_status, @trans_id 
	 from #icts_entity_name temp
     where not exists (select 1 
	                   from dbo.icts_entity_name 
					   where entity_name = temp.entity_name)
     set @rows_affected = @@rowcount
   end try
   begin catch
     if @@trancount > 0
        rollback tran
     print '=> Failed to add the new entity_name into ''icts_entity_name'' table!'
     print ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
      print '=> The new entity_name is added into ''icts_entity_name'' table successfully!'
end
else
   print '=> These entity_names are already existed in ''icts_entity_name'' table. '
   
endofscript:
go

exec dbo.refresh_a_last_num 'icts_entity_name',	'oid'
go
