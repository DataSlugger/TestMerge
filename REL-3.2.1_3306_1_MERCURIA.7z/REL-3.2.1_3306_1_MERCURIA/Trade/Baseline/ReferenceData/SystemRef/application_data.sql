set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the application table ...'
go

IF NOT EXISTS (select *
               from application
               where app_name = 'AccountMaintenance')
   insert into dbo.application values('AccountMaintenance', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'AccountViewer')
   insert into dbo.application values('AccountViewer', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'Allocation')
   insert into dbo.application values('Allocation', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'AutoVoucher')
   insert into dbo.application values('AutoVoucher', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'AutopoolCriteria')
   insert into dbo.application values('AutopoolCriteria', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'BBTrades')
   insert into dbo.application values('BBTrades', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'CommAccount')
   insert into dbo.application values('CommAccount', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'ContractEditor')
   insert into dbo.application values('ContractEditor', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'CountryViewer')
   insert into dbo.application values('CountryViewer', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'CreditViewer')
   insert into dbo.application values('CreditViewer', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'DocumentEditor')
   insert into dbo.application values('DocumentEditor', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'FistHeadlines')
   insert into dbo.application values('FistHeadlines', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'FuturesCapture')
   insert into dbo.application values('FuturesCapture', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'ICTSControl')
   insert into dbo.application values('ICTSControl', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'LC')
   insert into dbo.application values('LC', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'LCViewer')
   insert into dbo.application values('LCViewer', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'LivePrices')
   insert into dbo.application values('LivePrices', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'LivePriceLoad')
   insert into dbo.application values('LivePriceLoad', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'MarketInfo')
   insert into dbo.application values('MarketInfo', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'MasterCollateral')
   insert into dbo.application values('MasterCollateral', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'News')
   insert into dbo.application values('News', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'PASSApp')
   insert into dbo.application values('PASSApp', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'PGViewer')
   insert into dbo.application values('PGViewer', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'PLManager')
   insert into dbo.application values('PLManager', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'ParentGuarantee')
   insert into dbo.application values('ParentGuarantee', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'Petroex')
   insert into dbo.application values('Petroex', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'PortfolioManager')
   insert into dbo.application values('PortfolioManager', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'PostedPriceMaint')
   insert into dbo.application values('PostedPriceMaint', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'PriceManager')
   insert into dbo.application values('PriceManager', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'PricingApp')
   insert into dbo.application values('PricingApp', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'TradeCapture')
   insert into dbo.application values('TradeCapture', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'LocationManager')
   insert into dbo.application values('LocationManager', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'CalendarMaintenance')
   insert into dbo.application values('CalendarMaintenance', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'UserMaintenance')
   insert into dbo.application values('UserMaintenance', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'CrudeProfile')
   insert into dbo.application values('CrudeProfile', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'CrudeEntry')
   insert into dbo.application values('CrudeEntry', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'AGIP01')
   insert into dbo.application values('AGIP01', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'CargoTracking')
   insert into dbo.application values('CargoTracking', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'AGIPNews')
   insert into dbo.application values('AGIPNews', 1)
go

/* QUICKFILL */
IF NOT EXISTS (select *
               from application
               where app_name = 'QuickFill')
   insert into dbo.application values('QuickFill', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'Inhouse')
   insert into dbo.application values('Inhouse', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'CommodityRollup')
   insert into dbo.application values('CommodityRollup', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'ReportExtractor')
   insert into dbo.application values('ReportExtractor', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'Repricing')
   insert into dbo.application values('Repricing', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'Bunkers')
   insert into dbo.application values('Bunkers', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'CAMaint')
   insert into dbo.application values('CAMaint', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'ENELSAPInterface')
   insert into dbo.application values('ENELSAPInterface', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'TaxMaintenance')
   insert into dbo.application values('TaxMaintenance', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'CAInterface')
   insert into dbo.application values('CAInterface', 1)
go

/* CVX/FAMM-specific applications     9/29/2004   requested by Frank Festini
IF NOT EXISTS (select *
               from application
               where app_name = '4GenInterface')
   insert into dbo.application values('4GenInterface', 1)
*/

IF NOT EXISTS (select *
               from application
               where app_name = 'ICTSAdmin')
   insert into dbo.application values('ICTSAdmin', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'ReportGenerator')
   insert into dbo.application values('ReportGenerator', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'SAPSelect')
   insert into dbo.application values('SAPSelect', 1)
go

IF NOT EXISTS (select *
               from application
               where app_name = 'TraderDashboard')
   insert into dbo.application values('TraderDashboard', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'TruckCapture')
   insert into dbo.application values('TruckCapture', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'ProcessTicket')
   insert into dbo.application values('ProcessTicket', 1)
go

/* CVX */
IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'CVXWebService')
   insert into dbo.application values('CVXWebService', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'RMSInterface')
   insert into dbo.application values('RMSInterface', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'ExchangeMonitor')
   insert into dbo.application values('ExchangeMonitor', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'GatewayInboundWS')
   insert into dbo.application (app_name, trans_id) 
      values('GatewayInboundWS', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'GatewayOutboundWS')
   insert into dbo.application (app_name, trans_id) 
      values('GatewayOutboundWS', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'GatewayServiceEngine')
   insert into dbo.application (app_name, trans_id) 
      values('GatewayServiceEngine', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'TradeSearch')
   insert into dbo.application (app_name, trans_id) 
      values ('TradeSearch', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'Logistics')
   insert into dbo.application (app_name, trans_id) 
      values('Logistics', 1)
go

-- Added by issue #1333692
IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'RC')
   insert into dbo.application (app_name, trans_id) 
       values ('RC', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'EntityTagEditor')
   insert into dbo.application (app_name, trans_id) 
      values ('EntityTagEditor', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'TicketActuals')
   insert into dbo.application (app_name, trans_id) 
      values ('TicketActuals', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'TicketActuals')
   insert into dbo.application (app_name, trans_id) 
      values ('TicketActuals', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'RiskManager')
   insert into dbo.application (app_name, trans_id) 
      values ('RiskManager', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'ReferenceData')
   insert into dbo.application (app_name, trans_id) 
      values ('ReferenceData', 1)
go

IF NOT EXISTS (select *
               from dbo.application
               where app_name = 'OpsManager')
   insert into dbo.application (app_name, trans_id) 
      values ('OpsManager', 1)
go
