set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table market_pricing_term
go

print 'Loading system reference data into the market_pricing_term table ...'
go

insert into market_pricing_term 
  (mpt_num, mkt_pricing_term_name, mkt_pricing_term_period_ind, 
    mkt_pricing_method_ind, trans_id)
values(1, 'Averaging over trading period', 'T', 'A', 1)
go

insert into market_pricing_term 
  (mpt_num, mkt_pricing_term_name, mkt_pricing_term_period_ind, 
    mkt_pricing_method_ind, trans_id)
values(2, 'Realizable pricing', 'T', 'R', 1)
go

