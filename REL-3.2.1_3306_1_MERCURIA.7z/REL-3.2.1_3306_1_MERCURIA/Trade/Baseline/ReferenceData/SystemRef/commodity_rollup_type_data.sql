set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the commodity_rollup_type table ...'
go

if not exists (select 1
               from dbo.commodity_rollup_type
               where rollup_type_code = 'FIN')
   insert into dbo.commodity_rollup_type 
       (rollup_type_code, rollup_type_desc, trans_id)
     values ('FIN', 'FINAL COMMODITY HIERARCHY', 1)
go

if not exists (select 1
               from dbo.commodity_rollup_type
               where rollup_type_code = 'VAR')
   insert into dbo.commodity_rollup_type 
       (rollup_type_code, rollup_type_desc, trans_id)
      values ('VAR', 'VAR Non Oil Commodity', 1)
go

if not exists (select 1
               from dbo.commodity_rollup_type
               where rollup_type_code = 'INV')
   insert into dbo.commodity_rollup_type 
       (rollup_type_code, rollup_type_desc, trans_id)
      values ('INV', 'Inventory Operating Limits', 1)
go

