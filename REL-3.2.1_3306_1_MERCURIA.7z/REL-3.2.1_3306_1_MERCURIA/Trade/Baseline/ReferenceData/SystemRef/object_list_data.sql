set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table object_list
go

print 'Loading system reference data into the object_list table ...'
go

INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AIEstActual','ai_est_actual','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AIEstActualCharSpec','ai_est_actual_char_spec','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AIEstActualSpec','ai_est_actual_spec','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Account','account','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountAddress','account_address','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountAddressCombo','acct_addr_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountAlias','account_alias','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountContact','account_contact','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountCountryBus','account_country_bus','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountCreditAlarmLog','account_credit_alarm_log','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountCreditCombo',' ','C','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountCreditInfo','account_credit_info','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountCreditLimit','account_credit_limit','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountCreditRating','account_credit_rating','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountExposure','account_exposure','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountGroup','account_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountGroupType','account_group_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountInst','account_instruction','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountName',' ','C','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountNetOut','account_net_out','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountPetroex','account_petroex','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AccountType','account_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Accumulation','accumulation','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ActualCharSpec','actual_char_spec','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ActualDetail','actual_detail','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AliasFormat','alias_format','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AliasSource','alias_source','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocDetailTransport','alloc_detail_transport','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Allocation','allocation','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationActualCostCombo','aa_cost_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationChain','allocation_chain','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationCostCombo','Allocation_CostCombo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationCriteria','allocation_criteria','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationDetail','allocation_detail','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationInsp','allocation_insp','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationItem','allocation_item','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationItemActual','allocation_item_actual','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationItemCostCombo','ai_cost_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationItemInsp','allocation_item_insp','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationItemSpec','allocation_item_spec','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationItemTransport','allocation_item_transport','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationPl','allocation_pl','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AllocationType','allocation_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Applications','application','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AssignTrade','assign_trade','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AutoVoucherCost','auto_voucher_cost','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AutopoolCriteria','autopool_criteria','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('AvgBuySellPriceTerm','avg_buy_sell_price_term','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BankCreditAlarmLog','bank_credit_alarm_log','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BankExposure','bank_exposure','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BankExposureSummary','bank_exposure_summary','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BcMailCriteria','bc_mail_criteria','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BcMailCriteriaTime','bc_mail_criteria_time','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BookingCompanyInfo','booking_company_info','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BookingPeriod','booking_period','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BrokerCommissionDefault','broker_commission_default','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BrokerInfo','broker_info','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostChildGen','bus_cost_child_gen','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostFate','bus_cost_fate','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostFateDate','bus_cost_fate_date','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostFateGroup','bus_cost_fate_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostLeaf','bus_cost_leaf','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostMail','bus_cost_mail','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostMailList','bus_cost_mail_list','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostMailTime','bus_cost_mail_time','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostMatriarch','bus_cost_matriarch','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostNumChildren','bus_cost_num_children','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostOrderGroup','bus_cost_order_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostState','bus_cost_state','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostSubOwner','bus_cost_sub_owner','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostTrade','bus_cost_trade','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('BusCostType','bus_cost_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Calendar','calendar','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CalendarDetail','calendar_detail','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CashCollateral','cash_collateral','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CashExposure','cash_exposure','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CashForecastFile','cash_forecast_file','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CashSettleDate','cash_settle_date','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CmdtyLocGroupCombo','cmdty_loc_group_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CmdtyMkt','commodity_market','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CollateralParty','collateral_party','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CollateralPledged','collateral_pledged','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommktFutureAttr','commkt_future_attr','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommktOptionAttr','commkt_option_attr','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommktPhysicalAttr','commkt_physical_attr','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommktSourceAlias','commkt_source_alias','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Commodity','commodity','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityAlias','commodity_alias','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityCharSpec','commodity_char_spec','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityDesc','commodity_desc','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityGroup','commodity_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityGroupType','commodity_group_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityLocation','commodity_location','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityMarketAlias','commodity_market_alias','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityMarketFormula','commodity_market_formula','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityMktSource','commodity_market_source','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityRollupHierarchy','commodity_rollup_hierarchy','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityRollupType','commodity_rollup_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommoditySpecification','commodity_specification','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityType','commodity_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommodityUom','commodity_uom','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CommoditysAttached','commoditys_attached','V','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Constants','constants','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Contract','contract','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ContractMessageList','contract_message_list','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ContractSkeleton','contract_skeleton','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ContractStatus','contract_status','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Cost','cost','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CostApproval','cost_approval','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CostComposite','cost_composite','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CostDistribution','cost_distribution','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CostOwner','cost_owner','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CostReportSnapshot','cost_report_snapshot','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CostSearch','cost_search_view','V','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CostStatus','cost_status','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CostType','cost_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Country','country','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CountryCreditAlarmLog','country_credit_alarm_log','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CountryExposure','country_exposure','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CreditAlarm','credit_alarm','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CreditAlarmComment','credit_alarm_comment','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CreditAlarmLog','credit_alarm_log','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CreditAlarmLogComment','credit_alarm_log_comment','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CreditGroup','credit_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CreditLimit','credit_limit','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CreditLimitAlarmCombo','credit_limit','C','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CreditLimitBasedOn','credit_limit_based_on','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CreditLimitComment','credit_limit_comment','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CreditTerm','credit_term','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CrlimitApplytoAccount','crlimit_applyto_account','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CrlimitApplytoBank','crlimit_applyto_bank','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CrlimitApplytoCountry','crlimit_applyto_country','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CurrencyExposure','currency_exposure','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CurrentMtmPrice','current_mtm_price','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('DeliveryTerm','delivery_term','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Department','department','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Desk','desk','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('DeskLocation','desk_location','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Document','document','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('DocumentMessage','document_message','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('DocumentType','document_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('EOMPostingBatch','eom_posting_batch','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('EventPriceTerm','event_price_term','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Exposure','exposure','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Formula','formula','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('FormulaBody','formula_body','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('FormulaCompPriceTerm','formula_comp_price_term','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('FormulaComponent','formula_component','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('FormulaComponentExt','formula_component_ext','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('FormulaCondition','formula_condition','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('FormulaEstimatedVar','formula_estimated_var','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Function','function','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('GLFileBH','glfile_bh','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('GLFileFH','glfile_fh','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('GLFileTD','glfile_td','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('GLFileTH','glfile_th','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('GlAccountBalance','gl_account_balance','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('GlAccountValidity','gl_account_validity','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('GravityAdj','gravity_adj','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('GravityTableName','gravity_table_name','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Gtc','gtc','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('IctsTransaction','icts_transaction','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('IctsUser','icts_user','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('IdmsBoardMapping','idms_board_mapping','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('IdmsDepartmentMapping','idms_department_mapping','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('IdmsLocationMapping','idms_location_mapping','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('InvBuildDrawSpec','inv_build_draw_spec','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Inventory','inventory','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('InventoryBalance','inventory_balance','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('InventoryBuildDraw','inventory_build_draw','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('InventoryCombo','inventory_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('InventoryCostCombo','inventory_cost_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('JmsClassification','jms_classification','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('JmsDepartment','jms_department','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('JmsDesk','jms_desk','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('JmsDivision','jms_division','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('JmsGroups','jms_groups','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('JmsLegalEntity','jms_legal_entity','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('JmsLocation','jms_location','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('JmsProfitCenter','jms_profit_center','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('JmsReports','jms_reports','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('JmsStrategy','jms_strategy','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('JmsTrader','jms_trader','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('JobRequest','job_request','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Lc','lc','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcAccount','lc_account','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcAccountUsage','lc_account_usage','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcAllocation','lc_allocation','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcAllocationCombo',' ','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcComment','lc_comment','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcDocType','lc_doc_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcDocument','lc_document','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcDraw','lc_draw','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcHeadlineComment','lc_headline_comment','V','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcItem','lc_item','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcItemDocument','lc_item_document','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcStatus','lc_status','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcStatusHistory','lc_status_history','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcType','lc_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LcUsage','lc_usage','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseActual','lease_actual','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseApprovalStatus','lease_approval_status','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseClearance','lease_clearance','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseComment','lease_comment','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseContractCombo','lease_contract_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseContractDetail','lease_contract_detail','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseCounties','lease_counties','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseDestError','lease_dest_error','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseDestination','lease_destination','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseDestinationCombo','lease_destination_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseDoType','lease_do_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseFieldOffice','lease_field_office','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseGeCode','lease_ge_code','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseHead','lease_head','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseHeadError','lease_head_error','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseHierarchy','lease_hierarchy','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseHierarchySub','lease_hierarchy_sub','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseOperator','lease_operator','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeasePricingError','lease_pricing_error','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseSearchCombo','lease_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseSearchView','lease_search_view','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseStatusCode','lease_status_code','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseTicketError','lease_ticket_error','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseTransporter','lease_transporter','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LeaseVersion','lease_version','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LicTaxImplication','lic_tax_implication','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Licence','licence','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LicenceCovers','licence_covers','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('License','license','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LicenseCovers','license_covers','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LimitType','limit_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LocGroupCombo','loc_group_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LocTypeByOrder','loc_type_by_order','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Location','location','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LocationAlias','location_alias','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LocationByType','location_by_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LocationExtInfo','location_ext_info','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LocationGroup','location_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LocationGroupType','location_group_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LocationType','location_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LseDestinContractCombo','lease_destination_contract','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('LseDestinLocationCombo','lease_dest_location','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('MarginCall','margin_call','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Market','market','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('MarketAlias','market_alias','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('MarketFormula','market_formula','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('MarketableSecurity','marketable_security','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('MarketsAttached','markets_attached','V','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('MasterCollAgreement','master_coll_agreement','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('MaterialAdvChgClause','material_adv_chg_clause','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('McaAccount','mca_account','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('McaComment','mca_comment','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('McaInvoiceTerms','mca_invoice_terms','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('McaMatAdvChgClause','mca_mat_adv_chg_clause','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('McaPaymentMethod','mca_payment_method','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('McaPaymentTerm','mca_payment_term','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('McaTradeItem','mca_trade_item','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Mot','mot','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('MotLocation','mot_location','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('MotType','mot_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('MtmExposure','mtm_exposure','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('NewNum','new_num','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('OTCOption','otc_option','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('OTCOptionValue','otc_option_value','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('OptionPrice','option_price','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('OptionStrike','option_strike','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('OptionStrikeAlias','option_strike_alias','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('OrderInstruction','order_instruction','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('OrderTermEvergreen','order_term_evergreen','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('OrderType','order_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('OrderTypeGroup','order_type_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('OrderTypeGrpDesc','order_type_grp_desc','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PaperAllocation','paper_allocation','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PaperAllocationItem','paper_allocation_item','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ParentGuarSubsCovered','parent_guar_subs_covered','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ParentGuarantee','parent_guarantee','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ParentGuaranteeComment','parent_guarantee_comment','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PassControl','pass_control','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PaymentMethod','payment_method','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PaymentTerm','payment_term','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PeiComment','comment','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PipelineCycle','pipeline_cycle','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Portfolio','portfolio','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PortfolioAlias','portfolio_alias','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PortfolioBookPl','portfolio_book_pl','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PortfolioCostCombo','portfolio_cost_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PortfolioEod','portfolio_eod','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PortfolioGroup','portfolio_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PortfolioGroupEod','portfolio_group_eod','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PortfolioProfitLoss','portfolio_profit_loss','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Position','position','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PositionEod','position_eod','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PositionGroup','position_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PositionGroupEod','position_group_eod','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PositionMarkToMarket','position_mark_to_market','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PostedPriceDetail','posted_price_detail','V','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PostingAccount','posting_account','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PostingBulletin','posting_bulletin','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PostingSearchPrec','posting_search_prec','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PriceChange','price_change','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PriceGravityAdj','price_gravity_adj','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PriceSource','price_source','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('PriceTable','price','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ProductUsage','product_usage','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('QuotePrice','quote_price','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('QuotePriceTerm','quote_price_term','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('QuotePricingPeriod','quote_pricing_period','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('RailcarIdentifierInfo','railcar_identifier_info','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('RailcarPtpRate','railcar_ptp_rate','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('RecapItem','recap_item','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('RecapItemCombo',' ','C','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ReferenceTabList','reference_tab_list','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Report','report','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ReportCompanyInfo','report_company_info','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ReportGroup','report_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ReportParameter','report_parameter','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ReportRunMessage','report_run_message','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ReportRunRequest','report_run_request','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('ReportSystypes','report_systypes','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('RepricedTradeItems','repriced_trade_items','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('RtVolExposure','rt_vol_exposure','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('RunStmtCC','run_stmt_cc','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('SimpleFormula','simple_formula','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('SnapperDirective','snapper_directive','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('SpecTest','spec_test','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Specification','specification','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('SpreadTemplate','spread_template','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('State','state','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('StateClearanceCode','state_clearance_code','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('StatesNeedClearance','states_need_clearance','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TIAccumCostCombo','ti_accum_cost_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TICashPhyCostCombo','ti_cash_phy_cost_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TICostCombo','TI_CostCombo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TIExchOptCostCombo','ti_exch_opt_cost_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TIFutureCostCombo','ti_future_cost_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TIOtcOptCostCombo','TI_OtcOpt_CostCombo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TIStorageCombo','ti_storage_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TIStorageCostCombo','TI_Storage_CostCombo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TITransportCombo','ti_transport_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TITransportCostCombo','TI_Transport_CostCombo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TIWPLsePurchCombo','lease_purchase_trades','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TIWetPhyCombo','ti_wet_phy_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TIWetPhyCostCombo','TI_WetPhy_CostCombo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TVACombo','temp_value_adjust_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Tax','tax','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TaxAddtlCosts','tax_addtl_costs','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TaxLicenseCombo','tax_license_view','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TaxLocation','tax_location','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TaxLocationLocCombo',' tax_location_loc_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TaxRate','tax_rate','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TempLeaseDestination','temp_lease_destination','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TempValueAdjust','temp_value_adjust','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TempValueAdjustDetail','temp_value_adjust_detail','V','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TimeZone','time_zone','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Trade','trade','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeCombo',' ','C','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeComment','trade_comment','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeDefault','trade_default','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeFormula','trade_formula','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeHeadlineComment','trade_headline_comment','V','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItem','trade_item','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemCashPhy','trade_item_cash_phy','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemComposite','trade_item_composite','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemDist','trade_item_dist','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemExchOpt','trade_item_exch_opt','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemExercise','trade_item_exercise','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemFill','trade_item_fill','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemFut','trade_item_fut','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemOtcOpt','trade_item_otc_opt','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemSpec','trade_item_spec','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemStorage','trade_item_storage','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemSubStorage','trade_item_sub_storage','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemTransport','trade_item_transport','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeItemWetPhy','trade_item_wet_phy','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeOrder','trade_order','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeOrderBal','trade_order_bal','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeOrderOnExch','trade_order_on_exch','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeOrderPosEffect','trade_order_pos_effect','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeOrderRailcar','trade_order_railcar','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradePM','trade','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeStatus','trade_status','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradeSync','trade_sync','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradesForSch','trades_for_sch','V','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradingPeriod','trading_period','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('TradingPeriodAlias','trading_period_alias','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Uom','uom','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('UomConversion','uom_conversion','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('UomTest','uom_test','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('User','user','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('UserGroup','user_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('UserGroupPermission','user_group_permission','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('UserJobTitle','user_job_title','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('UserPermission','user_permission','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('UserReport','user_report','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('UserReportGroup','user_report_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('UserReportParameter','user_report_parameter','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('UserUserGroup','user_user_group','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('Voucher','voucher','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('VoucherAlias','voucher_alias','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('VoucherApproval','voucher_approval','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('VoucherCategory','voucher_category','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('VoucherCost','voucher_cost','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('VoucherCostCombo','voucher_cost_combo','C','Y')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('VoucherDuedate','voucher_duedate','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('VoucherPayment','voucher_payment','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('VoucherRelation','voucher_relation','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('VoucherType','voucher_type','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('_PeiCommentComment','pei_comment_cmnt','B','N')
go
INSERT INTO dbo.object_list(object_class,table_view_name,object_type,reference_default)
                VALUES('CostExtInfo','cost_ext_info','B','N')
go

SETUSER
go
