set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the TI_feed_definition table ...'
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'TSW_schedule_feed')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(1, 'TSW_schedule_feed', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'PlantStockMovementVolume')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(2, 'PlantStockMovementVolume', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'PlannedExchangeObjectiveFeed')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(3, 'PlannedExchangeObjectiveFeed', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'DemandForecast')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(4, 'DemandForecast', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'RefineryProductionPlanSOP')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(5, 'RefineryProductionPlanSOP', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'RefineryProductionPlanRS')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(6, 'RefineryProductionPlanRS', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'SOPTradePlan')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(7, 'SOPTradePlan', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'RefineryActual')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(8, 'RefineryActual', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'TSWSchedule')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(9, 'TSWSchedule', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'PSMVolume')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(10, 'PSMVolume', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'RateTable')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(11, 'RateTable', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'ExchangeBalance')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(12, 'ExchangeBalance', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'ExchangePlan')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(13, 'ExchangePlan', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'BookInv')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(14, 'BookInv', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'PSMValue')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(15, 'PSMValue', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'FinancialResults')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(16, 'FinancialResults', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'CashInbound')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(17, 'CashInbound', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'VouchersInbound')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(18, 'VouchersInbound', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'ActualsInbound')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(19, 'ActualsInbound', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'ActualsInboundGrangemouth')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(20, 'ActualsInboundGrangemouth', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'ActualsInboundGoodsReceived')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(21, 'ActualsInboundGoodsReceived', getdate())
go

if not exists (select 1
               from dbo.TI_feed_definition
               where feed_name = 'CostInbound')
   insert into dbo.TI_feed_definition 
      (oid, feed_name, etl_timestamp)
     values(22, 'CostInbound', getdate())
go

exec dbo.refresh_a_last_num 'TI_feed_definition', 'oid'
go