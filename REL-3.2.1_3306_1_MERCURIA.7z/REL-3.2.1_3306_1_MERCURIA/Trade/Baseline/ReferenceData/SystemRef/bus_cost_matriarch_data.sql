set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bus_cost_matriarch
go

print 'Loading system reference data into the bus_cost_matriarch table ...'
go

insert into dbo.bus_cost_matriarch 
   values('DEPENDNT', 'Dependent', 'Dependent', 1)
go

insert into dbo.bus_cost_matriarch 
   values('MATRIARC', 'MATRIARCH', 'Matriarch', 1)
go

