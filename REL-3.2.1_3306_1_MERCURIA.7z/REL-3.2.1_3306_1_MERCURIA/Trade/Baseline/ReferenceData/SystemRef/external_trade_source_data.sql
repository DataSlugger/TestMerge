set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the external_trade_source table ...'
go

if not exists (select 1
               from external_trade_source
               where external_trade_src_name = 'NYMEX')
   INSERT external_trade_source 
     (oid, external_trade_src_name, external_trade_system_oid, alias_source_code, trans_id) 
      VALUES (1, 'NYMEX', 1, NULL, 1)
go

if not exists (select 1
               from external_trade_source
               where external_trade_src_name = 'IPE')
   INSERT external_trade_source 
     (oid, external_trade_src_name, external_trade_system_oid, alias_source_code, trans_id) 
      VALUES (2, 'IPE', 1, NULL, 1)
go

if not exists (select 1
               from external_trade_source
               where external_trade_src_name = 'ICE')
   INSERT external_trade_source 
     (oid, external_trade_src_name, external_trade_system_oid, alias_source_code, trans_id) 
      VALUES (3, 'ICE', 1, NULL, 1)
go


/* NOTE by Peter Lo 2007/01/12

    UBS has used oid #4 for 'Exchange Tools'
*/

/*
     If you want to use TradeLoader or Exchange Monitor to load files 
     via Excel, you have to have that space between Exchange and Tools 
     (Exchange Tools) in the external_trade_system table. 
     
     If you want to use TradeLoader or Exchange Monitor to bring in 
     trades from an external source like OTC or NYMEX, you have to 
     take out the space between ExchangeTools. 
*/

if not exists (select 1
               from dbo.external_trade_source
               where external_trade_src_name = 'ExchangeTools')
   INSERT dbo.external_trade_source 
     (oid, external_trade_src_name, external_trade_system_oid, alias_source_code, trans_id) 
      VALUES (4, 'ExchangeTools', 1, NULL, 1)
go

if not exists (select 1
               from external_trade_source
               where external_trade_src_name = 'DashBoard')
   INSERT external_trade_source 
     (oid, external_trade_src_name, external_trade_system_oid, alias_source_code, trans_id) 
      VALUES (5, 'DashBoard', 1, NULL, 1)
go

if not exists (select 1
               from external_trade_source
               where external_trade_src_name = 'Excel')
   INSERT external_trade_source 
     (oid, external_trade_src_name, external_trade_system_oid, alias_source_code, trans_id) 
      VALUES (6, 'Excel', 1, NULL, 1)
go

if not exists (select 1
               from external_trade_source
               where external_trade_src_name = 'DME')
   INSERT external_trade_source 
     (oid, external_trade_src_name, external_trade_system_oid, alias_source_code, trans_id) 
      VALUES (7, 'DME', 1, NULL, 1)
go

if not exists (select 1
               from external_trade_source
               where external_trade_src_name = 'NonDefined')
begin
   INSERT external_trade_source 
     (oid, external_trade_src_name, external_trade_system_oid, alias_source_code, trans_id) 
      VALUES (8, 'NonDefined', 1, NULL, 1)
end
go