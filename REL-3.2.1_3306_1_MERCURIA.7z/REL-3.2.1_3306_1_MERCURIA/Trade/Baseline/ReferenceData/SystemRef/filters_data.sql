set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table filters
go

print 'Loading system reference data into the filters table ...'
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'acct_num', 'Accounts', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'ai_est_actual_date', 'Actual Date', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'ai_est_actual_gross_qty', 'Actual Gross Quantity', NULL, 109, 8, 1, 
         'NumericFilter')
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'ai_est_actual_ind', 'Actual Type', 1, 39, 1, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'alloc_num', 'Allocation Number', NULL, 38, 4, 1, 'IntegerFilter')
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'alloc_type_code', 'Allocation Type', NULL, 39, 15, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'bol_code', 'BOL Code', NULL, 39, 20, NULL, 'SingleStringFilter')
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'cmdty_code', 'Commodity', 1, 39, 8, 1, 'ManyToOneFKFilter')
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'dest_trade_num', 'Destination Trade', NULL, 56, 4, NULL, 'IntegerFilter')
go

/* Table has been removed
insert into dbo.filters 
  values('Allocation', 'actual_detail', 'lease_num', 'Lease Number', NULL, 56, 4, NULL, 'IntegerFilter')
*/
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'mot_code', 'Method of Transportation', 1, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'ticket_num', 'Document Id', NULL, 39, 20, NULL, 'SingleStringFilter')
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'trade_num', 'Trade Number', NULL, 38, 8, 1, 'IntegerFilter')
go

insert into dbo.filters 
  values('Allocation', 'actual_detail', 'transporter_code', 'Transporter Code', NULL, 39, 20, NULL, 'SingleStringFilter')
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'acct_short_name', 'Trade Account  Name', NULL, 39, 15, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'alloc_item_status', 'Item Status', NULL, 39, 1, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'alloc_item_type', 'Item Type', NULL, 39, 1, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'alloc_status', 'Allocation Status', NULL, 39, 1, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'alloc_type_code', 'Allocation Type', NULL, 39, 1, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'cmdty_code', 'Commodity', NULL, 47, 8, NULL, 'ManyToOneFKFilter')
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'creation_date', 'Creation Date', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'credit_term_code', 'Credit  Terms', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'final_dest_loc_code', 'Final Destination', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'fully_actualized', 'Fully Actualized', NULL, 39, 1, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'inv_num', 'Inventory Number', NULL, 38, 8, 1, 'IntegerFilter')
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'mot_code', 'Mode of Transportation', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'nomin_date_from', 'Nomin Date From', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'nomin_date_to', 'Nomin Date To', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'nomin_qty_max', 'Max  Nomin Qty', NULL, 38, 8, 1, 'NumericFilter')
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'nomin_qty_min', 'Min Nomin Qty', NULL, 38, 8, 1, 'NumericFilter')
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'origin_loc_code', 'Origin', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'parcel_num', 'Parcel Number', NULL, 39, 15, 1, 'SingleStringFilter')
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'pay_term_code', 'Payment Terms', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'sch_init', 'Scheduler', NULL, 39, 3, 1, 'UserFilter')
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'sch_qty', 'Scheduled Qty', NULL, 38, 8, 1, 'NumericFilter')
go

insert into dbo.filters 
  values('Allocation', 'allocation_detail', 'title_tran_loc_code', 'Title Transfer Location', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'acct_num', 'All Accounts', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'bal_ind', 'Balance Indicator', NULL, 39, 1, 1, 'YesNoFilter')
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'booking_comp_num', 'Booking Company', NULL, 39, 4, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'cmdty_code', 'Trade Commodity', 1, 39, 8, 1, 'ManyToOneFKFilter')
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'contr_qty', 'Contract Quantity', NULL, 109, 8, 1, 'NumericFilter')
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'creation_date', 'Creation Date', NULL, 111, 8, 1, 'DateTimeRangeFilter')
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'credit_term_code', 'Credit Terms', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'del_date_from', 'Delivery Date', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'del_loc_code', 'Delivery Location', 1, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'del_term_code', 'Delivery Terms', 1, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'mot_code', 'Method of Transportation', 1, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'open_qty', 'Open Quantity', NULL, 109, 8, 1, 'NumericFilter')
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'order_type_code', 'Trade Order Type', 1, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'p_s_ind', 'Purchase - Sale Indicator', NULL, 39, 1, 1, 'PurchaseSellFilter')
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'parcel_num', 'Parcel Number', NULL, 39, 15, 1, 'SingleStringFilter')
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'pay_term_code', 'Payment Terms', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'real_port_num', 'Portfolio Number', NULL, 39, 8, 1, 'ManyToOneFKFilter')
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'risk_mkt_code', 'Risk Market', 1, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'title_mkt_code', 'Title Market', 1, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'total_priced_qty', 'Priced Quantity', NULL, 38, 8, NULL, 'NumericFilter')
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'total_sch_qty', 'Sch Qty', NULL, 38, 8, 1, 'NumericFilter')
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'trader_init', 'Trader ID', 1, 39, 3, 1, NULL)
go

insert into dbo.filters 
  values('Allocation', 'trades_for_sch', 'vessel_name', 'Vessel', 1, 39, 40, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost', 'acct_num', 'CounterParty', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost', 'cost_amt', 'Cost Amount', NULL, 38, 8, 1, 'NumericFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost', 'cost_book_comp_num', 'Booking Company', NULL, 39, 4, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost', 'cost_book_prd', 'Booking Period', NULL, 39, 8, 1, 'NumericStringFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost', 'cost_code', 'Cost Code', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost', 'cost_due_date', 'Due Date', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost', 'cost_eff_date', 'Effective Date', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost', 'cost_qty', 'Cost Qty', NULL, 38, 8, 1, 'NumericFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost', 'cost_status', 'Cost Status', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost', 'cost_type_code', 'Cost Type', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost', 'creation_date', 'Creation Date', NULL, 111, 8, 1, 'DateTimeRangeFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost', 'creator_init', 'Creator', NULL, 39, 3, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'acct_num', 'CounterParty', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'ai_est_actual_date', 'Actual Date', NULL, 111, 8, 1, 'DateRangeFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'alloc_item_num', 'Allocation Item Number', NULL, 56, 4, NULL, 'IntegerFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'alloc_num', 'Allocation Number', NULL, 56, 4, NULL, 'IntegerFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'bol_code', 'BOL Code', NULL, 39, 20, NULL, 'SingleStringFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_amt', 'Cost Amount', NULL, 38, 8, 1, 'NumericFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_book_comp_num', 'Booking Company', NULL, 39, 4, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_book_prd', 'Booking Period', NULL, 39, 8, 1, 'NumericStringFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_book_prd_date', 'Booking Period', NULL, 111, 8, 1, 'DateRangeFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_code', 'Cost Code', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_due_date', 'Due Date', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_eff_date', 'Effective Date', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_gl_acct_cr_code', 'GL Credit Code', NULL, 39, 45, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_gl_acct_dr_code', 'GL Debit Code', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_owner_code', 'Cost Owner Code', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_pay_rec_ind', 'Payable/Receivable', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_price_est_actual_ind', 'Cost Price Est Actual', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_qty', 'Cost Qty', NULL, 38, 8, 1, 'NumericFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_qty_est_actual_ind', 'Cost Qty Est Actual', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_status', 'Cost Status', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'cost_type_code', 'Cost Type', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'creation_date', 'Creation Date', NULL, 111, 8, 1, 'DateTimeRangeFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'creator_init', 'Creator', NULL, 39, 3, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'first_accrued_date', 'First Accrued Date', NULL, 111, 8, 1, 'DateRangeFilter')
go

/* View has been removed
insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'lease_num', 'Lease Number', NULL, 56, 4, NULL, 'IntegerFilter')
*/
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'loc_name', 'Location Name', 1, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'mot_code', 'Method of Transportation', 1, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'movement_date', 'Movement Date', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'option_exercise_date', 'Option Exercise Date', NULL, 56, 4, NULL, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'option_expiration_date', 'Option Expiration Date', NULL, 56, 4, NULL, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'port_num', 'Portfolio Number', NULL, 111, 8, 1, 'IntegerFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'state_code', 'State Code', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'ticket_num', 'Ticket Num', NULL, 39, 15, 1, 'SingleStringFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'trade_num', 'Trade Number', NULL, 56, 4, NULL, 'IntegerFilter')
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'trader_init', 'Trader ID', 1, 39, 3, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'cost_search_view', 'transporter_code', 'Transporter Code', NULL, 39, 20, NULL, 
         'SingleStringFilter')
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'Voucher_book_prd', 'Voucher Booking Period', NULL, 111, 8, 1, 'DateRangeFilter')
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'acct_num', 'Counter Party', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'credit_term_code', 'Credit Terms', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'pay_term_code', 'Payment Terms', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_auth_date', 'Authorization Date', NULL, 111, 8, 1, 'DateRangeFilter')
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_auth_init', 'Authorization Initials', NULL, 39, 3, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_book_comp_num', 'Booking Company', NULL, 39, 4, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_creation_date', 'Creation Date', NULL, 39, 3, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_cust_ref_num', 'Ref #', NULL, 39, 15, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_due_date', 'Voucher Due Date', NULL, 111, 8, 1, 'DateRangeFilter')
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_eff_date', 'Voucher Effective Date', NULL, 111, 8, 1, 'DateRangeFilter')
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_mod_init', 'Last Modified By', NULL, 39, 3, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_paid_date', 'Paid Date', NULL, 39, 3, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_pay_method', 'Payment Method', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_status', 'Status', NULL, 39, 1, 1, NULL)
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_tot_amt', 'Voucher Amount', NULL, 38, 8, 1, 'NumericFilter')
go

insert into dbo.filters 
  values('CommAccount', 'voucher', 'voucher_type_code', 'Voucher Type', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('FuturesCapture', 'non_exch_trade', 'brkr_num', 'Floor Broker', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('FuturesCapture', 'non_exch_trade', 'cmdty_code', 'Commodity', NULL, 39, 8, 1, 'ManyToOneFKFilter')
go

insert into dbo.filters 
  values('FuturesCapture', 'non_exch_trade', 'contr_date', 'Trade Date', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('FuturesCapture', 'non_exch_trade', 'contr_qty', 'Trade Status', NULL, 109, 8, 1, 'TradeStatusFilter')
go

insert into dbo.filters 
  values('FuturesCapture', 'non_exch_trade', 'creation_date', 'Creation Date', NULL, 61, 8, NULL, 'DateTimeRangeFilter')
go

insert into dbo.filters 
  values('FuturesCapture', 'non_exch_trade', 'order_type_code', 'Order Type', NULL, 39, 8, 1, 'OrderTypeFilter')
go

insert into dbo.filters 
  values('FuturesCapture', 'non_exch_trade', 'p_s_ind', 'Purchase/Sale', NULL, 39, 1, 1, 'PurchaseSellFilter')
go

insert into dbo.filters 
  values('FuturesCapture', 'non_exch_trade', 'real_port_num', 'Portfolio', NULL, 39, 8, 1, 'ManyToOneFKFilter')
go

insert into dbo.filters 
  values('FuturesCapture', 'non_exch_trade', 'title_mkt_code', 'Exchange Market', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('FuturesCapture', 'non_exch_trade', 'trader_init', 'Traders', NULL, 39, 3, 1, 'UserFilter')
go

insert into dbo.filters 
  values('FuturesCapture', 'non_exch_trade', 'trading_prd', 'Trading Period', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('LCSearch', 'lc', 'lc_exp_date', 'Expiration Date', NULL, 61, 8, NULL, NULL)
go

insert into dbo.filters 
  values('LCSearch', 'lc', 'lc_issue_date', 'Issue Date', NULL, 61, 8, NULL, NULL)
go

insert into dbo.filters 
  values('LCSearch', 'lc', 'lc_issuing_bank', 'Issuing Bank', NULL, 39, 15, 1, NULL)
go

insert into dbo.filters 
  values('LCSearch', 'lc', 'lc_request_date', 'Request Date', NULL, 61, 8, NULL, NULL)
go

insert into dbo.filters 
  values('LCSearch', 'lc', 'lc_status_code', 'LC Status', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('LCSearch', 'lc', 'lc_type_code', 'LC Type', NULL, 39, 15, 1, NULL)
go

insert into dbo.filters 
  values('PGSearch', 'parent_guarantee', 'pg_beneficiary', 'Beneficiary', NULL, 39, 15, 1, NULL)
go

insert into dbo.filters 
  values('PGSearch', 'parent_guarantee', 'pg_bus_covered_code', 'Bus Covered Code', NULL, 39, 1, 1, NULL)
go

insert into dbo.filters 
  values('PGSearch', 'parent_guarantee', 'pg_expiration_date', 'Expiration Date', NULL, 61, 8, NULL, NULL)
go

insert into dbo.filters 
  values('PGSearch', 'parent_guarantee', 'pg_guarantor', 'Guarantor', NULL, 39, 15, 1, NULL)
go

insert into dbo.filters 
  values('PGSearch', 'parent_guarantee', 'pg_in_out_ind', 'Incoming/Outgoing', NULL, 39, 1, 1, NULL)
go

insert into dbo.filters 
  values('PGSearch', 'parent_guarantee', 'pg_issue_date', 'Issue Date', NULL, 61, 8, NULL, NULL)
go

insert into dbo.filters 
  values('PostedPriceMaint', 'posted_price_detail', 'commodity', 'Commodity', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('PostedPriceMaint', 'posted_price_detail', 'effect_date', 'EffectDate', NULL, 111, 8, NULL, 'DateRangeFilter')
go

insert into dbo.filters 
  values('PostedPriceMaint', 'posted_price_detail', 'market', 'Market', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('PostedPriceMaint', 'posted_price_detail', 'source', 'Source', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('PostedPriceMaint', 'temp_value_adjust_detail', 'cmdty_code', 'Commodity', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('PostedPriceMaint', 'temp_value_adjust_detail', 'date_from', 'Begin Date', NULL, 111, 8, NULL, 'DateRangeFilter')
go

insert into dbo.filters 
  values('PostedPriceMaint', 'temp_value_adjust_detail', 'date_to', 'End Date', NULL, 111, 8, NULL, 'DateRangeFilter')
go

insert into dbo.filters 
  values('PostedPriceMaint', 'temp_value_adjust_detail', 'loc_code', 'Location', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Recap', 'allocation_detail', 'mot_code', 'Carriers', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Recap', 'allocation_detail', 'nomin_date_to', 'Inventory Period', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('Recap', 'allocation_detail', 'sch_init', 'Scheduler', NULL, 39, 3, 1, NULL)
go

insert into dbo.filters 
  values('Recap', 'recap_item', 'cmdty_code', 'Commodity', NULL, 30, 8, 1, NULL)
go

insert into dbo.filters 
  values('Recap', 'recap_item', 'is_inv_ind', 'Inventory Type', NULL, 39, 1, NULL, 'YesNoFilter')
go

insert into dbo.filters 
  values('Recap', 'recap_item', 'loc_code', 'Location', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Recap', 'recap_item', 'mot_code', 'Carrier', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Recap', 'recap_item', 'trader_id', 'Trader', NULL, 39, 3, 1, NULL)
go

insert into dbo.filters 
  values('Recap', 'recap_item', 'trading_prd', 'Delivery Period', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Recap', 'trades_for_sch', 'del_date_from', 'Delivery Date', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('Recap', 'trades_for_sch', 'order_type_code', 'Trade Order Type', 1, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('Recap', 'trades_for_sch', 'trader_init', 'Traders', NULL, 39, 3, 1, NULL)
go

insert into dbo.filters 
  values('TaxMaint', 'license', 'acct_num', 'Issued To', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('TaxMaint', 'license', 'issuing_tax_authority_num', 'Issued By', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('TaxMaint', 'tax', 'cmdty_code', 'Commodity Code', NULL, 47, 8, NULL, 'ColumnItemsFilter')
go

insert into dbo.filters 
  values('TaxMaint', 'tax', 'tax_authority_num', 'Tax Authority', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('TaxMaint', 'tax', 'tax_code', 'Tax Code', NULL, 47, 8, NULL, 'ColumnItemsFilter')
go

insert into dbo.filters 
  values('TaxMaint', 'tax', 'tax_eff_date', 'Effective Date', NULL, 111, 8, 1, 'CADateRangeFilter')
go

insert into dbo.filters 
  values('TaxMaint', 'tax_license_view', 'acct_num', 'Issued To', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('TaxMaint', 'tax_license_view', 'cmdty_code', 'Commodity Code', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('TaxMaint', 'tax_license_view', 'issuing_tax_authority_num', 'Issued By', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('TaxMaint', 'tax_license_view', 'tax_code', 'Tax Code', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('TradeSearch', 'credit_term', 'credit_term_code', 'Credit Term', NULL, 39, 8, 1, 'CreditTermFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'acct_num', 'Counter Party', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'acct_ref_num', 'Custom Contract #', NULL, 38, 4, 1, NULL)
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'booking_comp_num', 'Booking Company', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'brkr_num', 'Broker', NULL, 38, 4, 1, 'AccountFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'cmdty_code', 'Commodity', NULL, 39, 8, 1, 'ManyToOneFKFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'conclusion_type', 'Conclusion Type', NULL, 39, 1, 1, 'ConclusionTypeFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'contr_anly_init', 'Contract Analysts', NULL, 39, 3, 1, 'UserFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'contr_date', 'Contract Date', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'contr_qty', 'Trade Status', NULL, 109, 8, 1, 'TradeStatusFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'contr_status_code', 'Contract Status', NULL, 39, 8, 1, 'ManyToOneFKFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'contr_volume', 'Delivery Start Date', NULL, 111, 8, 1, 'DeliveryDateRangeFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'creation_date', 'Creation Date', NULL, 61, 8, NULL, 'DateTimeRangeFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'creator_init', 'Created By', NULL, 47, 3, NULL, 'UserFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'credit_res_exp_date', 'Credit Res. Exp. Date', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'credit_status', 'Credit Status', NULL, 39, 1, 1, 'CreditStatusFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'formula_ind', 'Formula Indicator', NULL, 39, 1, 1, 'YesNoFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'inhouse_ind', 'Inhouse Indicator', NULL, 39, 1, 1, 'YesNoFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'order_status_code', 'Schedule Status', NULL, 109, 8, 1, 'ScheduleStatusFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'order_type_code', 'Order Type', NULL, 39, 8, 1, 'ManyToOneFKFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'p_s_ind', 'Purchase/Sale', NULL, 39, 1, 1, 'PurchaseSellFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'parent_order_num', 'Modified Status', NULL, 39, 4, 1, 'ModifiedStatusFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'real_port_num', 'Portfolio', NULL, 39, 8, 1, 'ManyToOneFKFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'risk_mkt_code', 'Risk Market', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'term_evergreen_ind', 'Order Group', NULL, 39, 1, 1, 'PartOfFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'title_mkt_code', 'Title Market', NULL, 39, 8, 1, NULL)
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'total_priced_qty', 'Priced Quantity', NULL, 38, 8, 1, 'NumericFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'trade_mod_date', 'Last Modified On', NULL, 111, 8, 1, NULL)
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'trade_mod_init', 'Last Modified By', NULL, 39, 3, 1, 'UserFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'trade_num', 'Triggers', NULL, 56, 4, NULL, 'TriggerFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'trade_status_code', 'Confirmation Status', NULL, 39, 1, 1, 'ConfirmedStatusFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'trader_init', 'Traders', NULL, 39, 3, 1, 'UserFilter')
go

insert into dbo.filters 
  values('TradeSearch', 'non_exch_trade', 'trading_prd', 'Trading Period', NULL, 39, 8, 1, 'OneToManyFKFilter')
go

