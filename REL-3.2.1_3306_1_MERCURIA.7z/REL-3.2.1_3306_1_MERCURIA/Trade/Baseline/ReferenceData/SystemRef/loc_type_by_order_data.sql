set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table loc_type_by_order
go

print 'Loading system reference data into the loc_type_by_order table ...'
go

insert into dbo.loc_type_by_order 
   values('EFPEXCH', 'DEL', 1)
go

insert into dbo.loc_type_by_order 
   values('PHYSBYSL', 'DEL', 1)
go

insert into dbo.loc_type_by_order 
   values('PHYSEXCH', 'DEL', 1)
go

insert into dbo.loc_type_by_order 
   values('PHYSICAL', 'DEL', 1)
go

insert into dbo.loc_type_by_order 
   values('PROCESS', 'DEL', 1)
go

insert into dbo.loc_type_by_order 
   values('RACKBYSL', 'DEL', 1)
go

insert into dbo.loc_type_by_order 
   values('RACKBYSL', 'RAC', 1)
go

insert into dbo.loc_type_by_order 
   values('RACKEXCH', 'DEL', 1)
go

insert into dbo.loc_type_by_order 
   values('RACKEXCH', 'RAC', 1)
go

insert into dbo.loc_type_by_order 
   values('RACKPHYS', 'DEL', 1)
go

insert into dbo.loc_type_by_order 
   values('RACKPHYS', 'RAC', 1)
go

insert into dbo.loc_type_by_order 
   values('STORAGE', 'DEL', 1)
go

