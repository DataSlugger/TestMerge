set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bus_cost_fate
go

print 'Loading system reference data into the bus_cost_fate table ...'
go

insert into dbo.bus_cost_fate 
   values(1, 'MANUAL', 'Manual', 'Cost Not Processed', NULL, NULL, 'A', NULL, 'G', 1)
go

insert into dbo.bus_cost_fate 
   values(2, 'NO_PROCESS', 'NoProcess', 'Cost Not Processed', 'DD', 'SINGLE', 'A', NULL, 'S', 1)
go

insert into dbo.bus_cost_fate 
   values(3, 'VOUCHER', 'Voucher', 'Standard Voucher Process', 'DD', NULL, 'A', NULL, 'G', 1)
go

insert into dbo.bus_cost_fate 
   values(4, 'VOUCHSIN', 'Single Voucher', 'Standard Voucher Process', 'DD', 'SINGLE', 'A', NULL, 'G', 1)
go

insert into dbo.bus_cost_fate 
   values(5, 'AUTODD-2', 'Auto Due Day -2', 'Auto Due Day -2', 'DD', 'SINGLE', 'A', -2, 'G', 1)
go

insert into dbo.bus_cost_fate 
   values(6, 'AUTOIMMED', 'Autovoucher Immediately', 'Autovoucher Immediately', 'IMMED', 'CON', 'A', NULL, 'G', 1)
go

insert into dbo.bus_cost_fate 
   values(7, 'AUTOIMSIN', 'Autovoucher Immediately', 'Autovoucher Immediately', 'IMMED', 'SINGLE', 'A', NULL, 'G', 1)
go

insert into dbo.bus_cost_fate 
   values(8, 'BOOK_ONLY', 'Book Only', NULL, NULL, NULL, 'M', NULL, 'G', 1)
go

insert into dbo.bus_cost_fate 
   values(9, 'ITEM_TYPE', 'Item Type', NULL, 'DD', 'PCPD, ITEM', 'A', 2, 'G', 1)
go

insert into dbo.bus_cost_fate 
   values(10, 'BOOK_ONLY_REV', 'Book Only Rev', NULL, NULL, NULL, 'M', NULL, 'G', 1)
go

insert into dbo.bus_cost_fate 
   values(11, 'SWAPS', 'SWAP invoices', NULL, NULL, 'CON', 'A', NULL, 'G', 1)
go

