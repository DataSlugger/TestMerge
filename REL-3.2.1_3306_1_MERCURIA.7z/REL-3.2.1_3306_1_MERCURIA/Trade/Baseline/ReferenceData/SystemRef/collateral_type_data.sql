set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the collateral_type table ...'
go

if NOT EXISTS (select 1
               from dbo.collateral_type
               where collateral_type_code = 'CASH')
   insert into dbo.collateral_type 
       (collateral_type_code, collateral_type_desc, trans_id) 
      values ('CASH', 'Cash', 1)
go

if NOT EXISTS (select 1
               from dbo.collateral_type
               where collateral_type_code = 'NONCASH')
   insert into dbo.collateral_type 
       (collateral_type_code, collateral_type_desc, trans_id) 
      values ('NONCASH', 'Non-Cash', 1)
go
