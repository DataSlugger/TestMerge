set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the feed_status table ...'
go

IF NOT EXISTS (select * from dbo.feed_status where status = 'PENDING')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('PENDING','Feed yet to be processed')
go

IF NOT EXISTS (select * from dbo.feed_status where status = 'XSD_FAILED')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('XSD_FAILED','XSD validation failed')
go

IF NOT EXISTS (select * from dbo.feed_status where status = 'VAL_FAILED')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('VAL_FAILED','Reference data validation failed')
go

IF NOT EXISTS (select * from dbo.feed_status where status = 'PROC_SCHLD')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('PROC_SCHLD','Feed scheduled for processing')
go

IF NOT EXISTS (select * from dbo.feed_status where status = 'SUSPENDED')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('SUSPENDED','Requires manual intervention')
go

IF NOT EXISTS (select * from dbo.feed_status where status = 'OUTBOUND_SCHLD')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('OUTBOUND_SCHLD','Ready to send response')
go

IF NOT EXISTS (select * from dbo.feed_status where status = 'PROCESSING')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('PROCESSING','In progress')
go

IF NOT EXISTS (select * from dbo.feed_status where status = 'COMPLETED')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('COMPLETED','Processing completed')
go

IF NOT EXISTS (select * from dbo.feed_status where status = 'DELETED')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('DELETED','Soft delete by user')
go

IF NOT EXISTS (select * from dbo.feed_status where status = 'FAILED')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('FAILED','System failure due to unhandled exceptions')
go

IF NOT EXISTS (select * from dbo.feed_status where status = 'COMPLETED_MANUALLY')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('COMPLETED_MANUALLY','User done job by hand')
go

IF NOT EXISTS (select * from dbo.feed_status where status = 'MANUAL_PROCESSING')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('MANUAL_PROCESSING','The request is under manual processing')
go

IF NOT EXISTS (select 1 from dbo.feed_status where status = 'OB_PROCESSING')
   INSERT INTO dbo.feed_status(status, status_description)
   VALUES('OB_PROCESSING','Outbound processing the feed')
go