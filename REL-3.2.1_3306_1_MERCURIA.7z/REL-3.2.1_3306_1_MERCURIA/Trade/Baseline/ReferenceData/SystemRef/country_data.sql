set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the country table ...'
go

print '=> Adding calendar_code ''USA'' if NOT EXISTS ..'
go

if not exists (select 1
               from dbo.calendar
               where calendar_code = 'USA')
   insert into dbo.calendar 
        (calendar_code, calendar_name, calendar_type,
         calendar_desc, calendar_date_mask, calendar_status,
         trans_id)
     values('USA', 'United States Calendar', 'N', 
             'United States Calendar', 'YYYYYNN', 'A', 1)
go

if not exists (select 1
               from dbo.country
               where country_code = 'USA')
   insert into dbo.country 
       (country_code,
        country_name,
        no_bus_ind,
        country_num,
        country_status,
        calendar_code,
        int_curr_code,
        ext_curr_code,
        country_limit_amt,
        country_limit_util_amt,
        cmnt_num,
        exposure_priority_code,
        trans_id,
        iso_country_code)
      values('USA', 'USA', 'Y', 4, 'A', 'USA', 'USD', 'USD', 0.0, 
                   NULL, NULL, 'R', 1, NULL)
go
