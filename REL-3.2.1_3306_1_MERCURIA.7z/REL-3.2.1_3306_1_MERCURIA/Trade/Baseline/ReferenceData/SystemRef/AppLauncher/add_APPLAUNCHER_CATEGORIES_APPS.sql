set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the APPLAUNCHER_CATEGORIES_APPS table ..'
go

if object_id('tempdb..#applauncher_categories_apps', 'U') is not null
   exec('drop table #applauncher_categories_apps')
go

create table #applauncher_categories_apps
(
    oid              int IDENTITY primary key,
    product          nvarchar(50)      NOT NULL,
    category_uid     uniqueidentifier  NULL,
    app_uid          uniqueidentifier  NULL,
    tile_group       nvarchar(50)      NULL,
    [position]       int               NOT NULL,
	category_title   nvarchar(50)      NULL,
	app_title        nvarchar(50)      NULL
)
go

INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('Freight', 'Operations', 'Bunker', NULL, 31),
         ('Freight', 'Operations', 'Demurrage', NULL, 33),
         ('Freight', 'Operations', 'Off Hire', NULL, 30),
         ('Freight', 'Operations', 'Vessels Position', NULL, 34),
         ('Freight', 'Operations', 'Voyage', NULL, 32)
go

INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('Freight', 'Root', 'Freight Planner', NULL, 10)
go

INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('Freight', 'Reports', 'Dashboards', NULL, 41),
         ('Freight', 'Reports', 'Reports', NULL, 40)      
go

INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('Freight', 'Link to Oil', 'Commercial Accounting', NULL, 52),
         ('Freight', 'Link to Oil', 'Oil Dashboard', NULL, 53),
		 ('Freight', 'Link to Oil', 'Ops Workbench', NULL, 50)
go

INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('Freight', 'Chartering', 'COA', NULL, 23),
         ('Freight', 'Chartering', 'Contract Template', NULL, 24),
         ('Freight', 'Chartering', 'P/L Analyzer', NULL, 20),
         ('Freight', 'Chartering', 'Spot', NULL, 21),
         ('Freight', 'Chartering', 'Time Charter', NULL, 22)
go

INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('Freight', 'Mark to Market', 'Freight trade position', NULL, 2),
         ('Freight', 'Mark to Market', 'Freight Trades', NULL, 0),         
         ('Freight', 'Mark to Market', 'Time Charter position', NULL, 3),
         ('Freight', 'Mark to Market', 'Trade allocations', NULL, 1)         
go

INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('Freight', 'Tools', 'Broker Rate', 'Configuration', 62),
         ('Freight', 'Tools', 'Cargo', 'Configuration', 65),
         ('Freight', 'Tools', 'Port Charges Rules', 'Configuration', 63),
         ('Freight', 'Tools', 'Ports', 'Reference Data', 61),
         ('Freight', 'Tools', 'Report Engine', 'Configuration', 66),         
		 ('Freight', 'Tools', 'Users and Permissions', 'Administration', 60),
         ('Freight', 'Tools', 'Vessels', 'Reference Data', 64)
go
		 
INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES ('OIL', 'Reports', 'Reporting Dashboard', NULL, 580),
          ('OIL', 'Reports', 'What''s Chg Dashboard', NULL, 590),
          ('OIL', 'Reports', 'Portfolio Report', NULL, 600),
		  ('OIL', 'Reports', 'Unlimited Hedge', NULL, 610),
          ('OIL', 'Reports', 'DocGen SSRS', NULL, 620),
          ('OIL', 'Reports', 'Report Generator', NULL, 630),
          ('OIL', 'Reports', 'Quick Fill', NULL, 640),
		  ('OIL', 'Reports', 'Inventory', NULL, 650),
          ('OIL', 'Reports', 'Missing Prices', NULL, 660),
		  ('OIL', 'Reports', 'PL Attribution', NULL, 670),
          ('OIL', 'Reports', 'Borrowing Base', NULL, 680),          
          ('OIL', 'Reports', 'AATD', NULL, 690),
          ('OIL', 'Reports', 'Accounting', NULL, 700), 
          ('OIL', 'Reports', 'Cash Forecast', NULL, 710),
		  ('OIL', 'Reports', 'Price', NULL, 720),          
		  ('OIL', 'Reports', 'Options', NULL, 730),
          ('OIL', 'Reports', 'SAP', NULL, 740),
          ('OIL', 'Reports', 'Report Builder', NULL, 750),
		  ('OIL', 'Reports', 'Price Variation', NULL, 760)
go


INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('OIL', 'Operations', 'Allocation and Scheduling', NULL, 210),
         ('OIL', 'Operations', 'Commercial Accounting', NULL, 170),
         ('OIL', 'Operations', 'Deal Viewer', NULL, 200),
		 ('OIL', 'Operations', 'DocGen SSRS', NULL, 180),
         ('OIL', 'Operations', 'Gateway Data Uploader', NULL, 160),
		 ('OIL', 'Operations', 'Metals Dashboard', NULL, 190), 
         ('OIL', 'Operations', 'Ops WorkBench', NULL, 140), 
         ('OIL', 'Operations', 'Symphony Freight', NULL, 150) 
go


INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('OIL', 'Credit', 'Bank Position', NULL, 240),
         ('OIL', 'Credit', 'Collateral', NULL, 280),
         ('OIL', 'Credit', 'Credit Checker', NULL, 250),
         ('OIL', 'Credit', 'Credit Viewer', NULL, 270),
         ('OIL', 'Credit', 'Credit Wrkfl Dashboard', NULL, 260),
         ('OIL', 'Credit', 'Letter of Credit', NULL, 220),     
         ('OIL', 'Credit', 'Ops WorkBench', NULL, 230)
go


INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('OIL', 'Front Office', 'Bunkers', NULL, 10),
         ('OIL', 'Front Office', 'Deal Viewer', NULL, 90),
         ('OIL', 'Front Office', 'Exchange Monitor', NULL, 30),
         ('OIL', 'Front Office', 'Reporting Dashboard', NULL, 40),      
         ('OIL', 'Front Office', 'OC Trade Capture', NULL, 130),
		 ('OIL', 'Front Office', 'PASS', NULL, 100),
         ('OIL', 'Front Office', 'Portfolio Manager', NULL, 110),
         ('OIL', 'Front Office', 'Portfolio Report', NULL, 120),
		 ('OIL', 'Front Office', 'Price Manager', NULL, 60),
         ('OIL', 'Front Office', 'Pricing Application', NULL, 70),
         ('OIL', 'Front Office', 'Risk Manager', NULL, 20),
         ('OIL', 'Front Office', 'Trade Capture', NULL, 0),
         ('OIL', 'Front Office', 'Trade Insert', NULL, 80),
         ('OIL', 'Front Office', 'What''s Chg Dashboard', NULL, 50)
go

INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('OIL', 'Accounting', 'CA Interface', NULL, 410),
         ('OIL', 'Accounting', 'Cash Forecast', NULL, 440),
         ('OIL', 'Accounting', 'Commercial Accounting', NULL, 380),
		 ('OIL', 'Accounting', 'DocGen SSRS', NULL, 420),
         ('OIL', 'Accounting', 'OC Commercial Accounting', NULL, 450),
         ('OIL', 'Accounting', 'Ops WorkBench', NULL, 390),
		 ('OIL', 'Accounting', 'Price Manager', NULL, 430),
         ('OIL', 'Accounting', 'Pricing Application', NULL, 400)      
go


INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('OIL', 'Pricing and Risk', 'Correlation Volatility', NULL, 320),
         ('OIL', 'Pricing and Risk', 'Reporting Dashboard', NULL, 300),
		 ('OIL', 'Pricing and Risk', 'Options Eval Tool', NULL, 360),
         ('OIL', 'Pricing and Risk', 'Price Manager', NULL, 290),
		 ('OIL', 'Pricing and Risk', 'PriceLoad', NULL, 370),
		 ('OIL', 'Pricing and Risk', 'Pricing Application', NULL, 350),
         ('OIL', 'Pricing and Risk', 'Repricing', NULL, 340),   
         ('OIL', 'Pricing and Risk', 'VAR', NULL, 310),
         ('OIL', 'Pricing and Risk', 'Volatility Skew', NULL, 330)
go

INSERT INTO #applauncher_categories_apps
      (product, category_title, app_title, tile_group, [position])
   VALUES('OIL', 'Tools', 'Derived Data Generator', 'Admin', 560),
         ('OIL', 'Tools', 'Exchange Monitor', 'Admin', 500),
		 ('OIL', 'Tools', 'Gateway Data Uploader', NULL, 510),
         ('OIL', 'Tools', 'Gateway Map Generator', 'Admin', 570),
         ('OIL', 'Tools', 'ICTS Administration', 'Reference Data', 460),
         ('OIL', 'Tools', 'Missing Prices', NULL, 530),
         ('OIL', 'Tools', 'PASS', 'Admin', 480), 
         ('OIL', 'Tools', 'Price Manager', 'Admin', 520),
         ('OIL', 'Tools', 'PriceLoad', 'Admin', 490),
         ('OIL', 'Tools', 'Ref Data Manager', 'Reference Data', 470),
         ('OIL', 'Tools', 'Repricing', 'MISC', 540),
         ('OIL', 'Tools', 'Server Manager', 'Admin', 550),
         ('OIL', 'Tools', 'Upload Data', 'Admin', 572)
go   

--INSERT INTO #applauncher_categories_apps
--      (product, category_title, app_title, tile_group, [position])
--   VALUES('OIL', 'All', 'Quote', NULL, 10)
go


/* **************************************************************** */

update a
set category_uid = b.category_uid
from #applauncher_categories_apps a
        JOIN dbo.APPLAUNCHER_CATEGORIES b
		   on a.category_title = b.category_title and
              a.product = b.product
go

update a
set app_uid = b.app_uid
from #applauncher_categories_apps a
        JOIN dbo.APPLAUNCHER_APPS b
		   on a.product = b.product and
		      a.app_title = b.app_title
go

/* Validate data */
if exists (select 1
           from #applauncher_categories_apps
		   where category_uid is null)
begin
   RAISERROR('', 0, 1) with nowait
   RAISERROR('=> The following category_title(s) do not exist in the APPLAUNCHER_CATEGORIES table:', 0, 1) with nowait
   select distinct category_title
   from #applauncher_categories_apps
   where category_uid is null
   order by category_title
   RAISERROR('', 0, 1) with nowait
end
go

if exists (select 1
           from #applauncher_categories_apps
		   where app_uid is null)
begin
   RAISERROR('', 0, 1) with nowait
   RAISERROR('=> The following app_title(s) do not exist in the APPLAUNCHER_APPS table:', 0, 1) with nowait
   select distinct app_title
   from #applauncher_categories_apps
   where app_uid is null
   order by app_title
   RAISERROR('', 0, 1) with nowait
end
go

/* *********************************************************************** */
/* Moving GOOD data in temp table to the APPLAUNCHER_CATEGORIES_APPS table */

declare @rows_added       int,
        @rows_in_temp     int,
		@errcode          int,
		@smsg             varchar(max)
		
set @rows_in_temp = (select count(*)
                     from #applauncher_categories_apps)
					 
begin tran
begin try
  insert into dbo.APPLAUNCHER_CATEGORIES_APPS
      (product,
	   category_uid,
	   app_uid,
	   tile_group,
	   [position])
  select product, 
         category_uid, 
         app_uid, 
         tile_group, 
         [position] 
  from #applauncher_categories_apps a
  where not exists (select 1
                    from dbo.APPLAUNCHER_CATEGORIES_APPS b
				    where a.product = b.product and
				          a.category_uid = b.category_uid and
						  a.app_uid = b.app_uid)
  set @rows_added = @@rowcount
end try
begin catch
  set @errcode = ERROR_NUMBER()
  set @smsg = ERROR_MESSAGE()
  if @@trancount > 0
     rollback tran
  RAISERROR('=> Failed to move data in temp table to to the APPLAUNCHER_CATEGORIES_APPS table due to the error:', 0, 1) with nowait
  RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
  goto endofscript
end catch
commit tran

if @rows_added = @rows_in_temp
   RAISERROR('=> All rows (%d) in temp table were successfully copied into the APPLAUNCHER_CATEGORIES_APPS table', 0, 1, @rows_added) with nowait
else
   RAISERROR('=> No all rows (%d) in temp table were copied into the APPLAUNCHER_CATEGORIES_APPS table (%d)', 0, 1, @rows_in_temp, @rows_added) with nowait

endofscript:   
go

if object_id('tempdb..#applauncher_categories_apps', 'U') is not null
   exec('drop table #applauncher_categories_apps')
go


/* ********************************************************************* */
/* ********************************************************************* */

if object_id('tempdb..#appLan', 'U') is not null
   exec('drop table #appLan')
go
   
create table #appLan
(
   position           int identity(1100, 10),
   category_title     nvarchar(100),
   app_title          nvarchar(100),
   category_uid       uniqueidentifier,
   app_uid            uniqueidentifier
)
go

insert into #appLan
     (category_title, app_title)
  values('All', '21 Day BFO'),
        ('All', 'Account'),
        ('All', 'Accounting'),
        ('All', 'Ageing'),
        ('All', 'Allocation Change'),
        ('All', 'Audit Trail'),
        ('All', 'Borrowing Base'),
        ('All', 'Brent by Counter Party'),
        ('All', 'Credit'),
        ('All', 'In-Transit P/L'),
        ('All', 'Inventory'),
        ('All', 'Inventory by Location'),
        ('All', 'Liquidation'),
        ('All', 'Missing Prices'),
        ('All', 'Options'),
        ('All', 'PL Attribution'),
        ('All', 'Price'),
        ('All', 'Pricing Today'),
        ('All', 'Report Builder'),
        ('All', 'SAP'),
        ('All', 'Back Office Dashboard')
go

update temp
set temp.category_uid = ac.category_uid
from dbo.APPLAUNCHER_CATEGORIES ac 
       join #appLan temp
          on ac.category_title = temp.category_title
where ac.product = 'OIL'
go

update temp
set temp.app_uid = aa.app_uid
from dbo.APPLAUNCHER_APPS aa 
        join #appLan temp
           on aa.app_title = temp.app_title
where aa.product = 'OIL'
go

IF EXISTS (SELECT 1 
           FROM #appLan 
		   WHERE app_uid IS NULL)
BEGIN
   IF EXISTS (SELECT 1 
              FROM #appLan 
              WHERE app_title = 'Back Office Dashboard' AND 
                    app_uid IS NULL)
   BEGIN
      INSERT INTO dbo.APPLAUNCHER_APPS
		   (product, app_uid, app_title, tile_size, tile_icon,
		    link_type, link_path, link_invoke, autorun_order,
			search_enabled, search_default, roles, enabled)
		VALUES('OIL',NEWID(),'Back Office Dashboard','W',NULL,
		         'PathSingle', 'C:\tc\icts\jms\Reports\ICTSReports\GenericDXReport_BackOffice.exe',
				 NULL,NULL,0,0,NULL,1)
   END
END
go

/* Retrieving APP_UID from APPLAUNCHER_APPS table*/

UPDATE temp
SET temp.app_uid = aa.app_uid
FROM APPLAUNCHER_APPS aa 
       join #appLan temp
          ON aa.app_title = temp.app_title
WHERE aa.product = 'OIL'
go

declare @rows_affected	int,
		@errcode		int,
		@smsg			varchar(max)

if exists (select 1 
           from #appLan 
		   where category_uid is null or 
		         app_uid is null)
begin
   RAISERROR('=> category_uid/app_uid cann''t be null. Please check Null Values.', 0, 1) with nowait
   goto endofscript
end	

IF EXISTS (SELECT 1 
           from #appLan t 
		   where not exists (select 1 
		                     from APPLAUNCHER_CATEGORIES_APPS app 
							 where app.product = 'OIL' and 
							       t.category_uid = app.category_uid and 
								   t.app_uid = app.app_uid))
BEGIN
   BEGIN TRAN
   BEGIN TRY
     insert into APPLAUNCHER_CATEGORIES_APPS
	      (product, category_uid, app_uid, position)
       select 'OIL', category_uid, app_uid, position 
	   from #appLan
     set @rows_affected = @@rowcount
   END TRY
   BEGIN CATCH
     if @@trancount > 0
	    rollback tran
     set @errcode = ERROR_NUMBER()
     set @smsg = ERROR_MESSAGE()
     RAISERROR('=> Failed to insert APPLAUNCHER_CATEGORIES_APPS records due to the below error:',0,1)with nowait
     RAISERROR('=> ERROR %d: %s',0,1,@errcode,@smsg)with nowait
     goto endofscript
   END CATCH
   COMMIT TRAN
   IF @rows_affected > 0
      RAISERROR('=> Inserted %d APPLAUNCHER_CATEGORIES_APPS records Sucessfully...', 0, 1, @rows_affected) with nowait
END
ELSE
   RAISERROR('=> Records alredy exist in APPLAUNCHER_CATEGORIES_APPS table.', 0, 1) with nowait
   
endofscript:
go
if object_id('tempdb..#appLan') is not null
   exec('drop table #appLan')
go

/* ********************************************************************* */
/* ********************************************************************* */
if object_id('tempdb..#appLan', 'U') is not null
   exec('drop table #appLan')
go
		
create table #appLan
(
   position 		     int,
   category_title        nvarchar(100),
   app_title             nvarchar(100),
   category_uid          uniqueidentifier,
   app_uid               uniqueidentifier
)
go

insert into #appLan 
   (position, category_title, app_title)
select isnull(max(position), 0) + 10, 'Pricing and Risk', 'Quote'
from dbo.APPLAUNCHER_CATEGORIES_APPS 
WHERE category_uid in (select category_uid 
                       from dbo.APPLAUNCHER_CATEGORIES 
					   where category_title = 'Pricing and Risk') and 
      product = 'OIL'
go

update temp
set temp.category_uid = ac.category_uid
from dbo.APPLAUNCHER_CATEGORIES ac 
        join #appLan temp
           on ac.category_title = temp.category_title
where ac.product = 'OIL'
go

update temp
set temp.app_uid = aa.app_uid
from dbo.APPLAUNCHER_APPS aa 
        join #appLan temp
           on aa.app_title = temp.app_title
where aa.product = 'OIL'
go

declare @rows_affected 	int,
		@errcode		int,
		@smsg			varchar(max)

if exists (select 1 
           from #appLan 
		   where category_uid is null or 
		         app_uid is null)
begin
   RAISERROR('=> category_uid/app_uid cann''t be null. Please check Null Values.', 0, 1) with nowait
	goto endofscript
end	

IF EXISTS (select 1 
           from #appLan t 
		   where not exists (select 1 
		                     from dbo.APPLAUNCHER_CATEGORIES_APPS app 
							 where app.product = 'OIL' and 
							       t.category_uid = app.category_uid AND 
								   t.app_uid = app.app_uid))
BEGIN
   BEGIN TRAN
   BEGIN TRY
     insert into dbo.APPLAUNCHER_CATEGORIES_APPS
	     (product, category_uid, app_uid, position)
       select 'OIL', category_uid, app_uid, position 
       from #appLan
     set @rows_affected = @@rowcount
   END TRY
   BEGIN CATCH
     if @@trancount > 0
	    rollback tran
     set @errcode = ERROR_NUMBER()
     set @smsg = ERROR_MESSAGE()
     RAISERROR('=> Failed to insert the APPLAUNCHER_CATEGORIES_APPS records due to the below error:', 0, 1) with nowait
     RAISERROR('=> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
     goto endofscript
   END CATCH
   COMMIT TRAN
   IF @rows_affected > 0
      RAISERROR('=> Inserted %d APPLAUNCHER_CATEGORIES_APPS records Sucessfully...', 0, 1, @rows_affected) with nowait
END
ELSE
	RAISERROR('=> Records alredy exist in APPLAUNCHER_CATEGORIES_APPS table.', 0, 1) with nowait
endofscript:
go

if object_id('tempdb..#appLan') is not null
   exec('drop table #appLan')
go

/* ********************************************************************* */
/* ********************************************************************* */
