set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into APPLAUNCHER_APPS table ..'
go

if object_id('tempdb..#applauncher_apps', 'U') is not null
   exec('drop table #applauncher_apps')
go

create table #applauncher_apps
(
    product        nvarchar(50)      NOT NULL,
    app_uid        uniqueidentifier  NOT NULL,
    app_title      nvarchar(50)      NULL,
    tile_size      nvarchar(2)       NULL,
    tile_icon      int               NULL,
    link_type      nvarchar(15)      NULL,
    link_path      nvarchar(300)     NULL,
    link_invoke    nvarchar(50)      NULL,
    autorun_order  int               NULL,
    search_enabled bit               NOT NULL,
    search_default bit               NOT NULL,
    roles          nvarchar(300)     NULL,
    enabled        bit               NOT NULL
)
go

INSERT INTO #applauncher_apps 
      (product, app_uid, app_title, tile_size, tile_icon, link_type, link_path, 
	   link_invoke, autorun_order, search_enabled, search_default, roles, enabled) 
   VALUES('Freight', NEWID(), 'Users and Permissions',   'W', NULL, 'Module', '@FLEETIMESECURITYCONFIGURATION', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Reports',                 'W', NULL, 'Module', '@REPORTENGINE', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Cargo',                   'W', NULL, 'SFCOM',  'SymphonyFreight.FreightApplication', 'CargoConfiguration', NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'P/L Analyzer',            'W', NULL, 'Module', '@PLANALYZER', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Trade allocations',       'W', NULL, 'SFCOM',  'SymphonyFreight.FreightApplication', 'TradeAllocations', NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Vessels Position',        'W', NULL, 'Module', '@VESSELSPOSITION', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Voyage',                  'W', NULL, 'SFCOM',  'SymphonyFreight.FreightApplication', 'Spot', NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Spot',                    'W', NULL, 'SFCOM',  'SymphonyFreight.FreightApplication', 'Spot', NULL, 1, 1, NULL, 1), 
         ('Freight', NEWID(), 'Time Charter',            'W', NULL, 'Module', '@TIMECHARTERMANAGEMENT', NULL, NULL, 1, 0, NULL, 1), 
         ('Freight', NEWID(), 'Off Hire',                'W', NULL, 'Module', '@OFFHIREMANAGEMENT', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Bunker',                  'W', NULL, 'Module', '@BUNKERMANAGEMENT', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'COA',                     'W', NULL, 'SFCOM',  'SymphonyFreight.FreightApplication', 'CoA', NULL, 1, 0, NULL, 1), 
         ('Freight', NEWID(), 'Freight trade position',  'W', NULL, 'SFCOM',  'SymphonyFreight.FreightApplication', 'MTMEnableCargo', NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Contract Template',       'W', NULL, 'SFCOM',  'SymphonyFreight.FreightApplication', 'ContractTemplate', NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Port Charges Rules',      'W', NULL, 'SFCOM',  'SymphonyFreight.FreightApplication', 'FLocationData', NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Charterparties',          'W', 0,    'Module', NULL, NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Ops Workbench',           'W', NULL, 'Path',   'C:\tc\icts\Fleetime\StartLogistics.cmd', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Demurrage',               'W', NULL, 'Module', '@VOYAGEMANAGEMENT', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Time Charter position',   'W', NULL, 'Module', '@POSITIONADJUSTMENT', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Freight Planner',         'W', 5,    'Module', '@WORKFLOW', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Freight Trades',          'W', NULL, 'SFCOM',  'SymphonyFreight.FreightApplication', 'FreightTrades', NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Vessels',                 'W', NULL, 'Module', '@VESSELMANAGEMENT', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Commercial Accounting',   'W', NULL, 'Path',   'C:\TC\ICTS\jms\Apps\commAccount.service\CommAccount.exe', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Report Engine',           'W', NULL, 'Module', '@REPORTENGINEADMIN', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Dashboards',              'W', NULL, 'Module', '@DASHBOARD', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Ports',                   'W', NULL, 'Module', '@PORTMANAGEMENT', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Broker Rate',             'W', NULL, 'Module', '@BROKERMANAGEMENT', NULL, NULL, 0, 0, NULL, 1), 
         ('Freight', NEWID(), 'Oil Dashboard',           'W', NULL, 'Path',   'C:\tc\icts\jms\Reports\ICTSReports\GenericPivotReport.exe', NULL, NULL, 0, 0, NULL, 1) 
go

INSERT INTO #applauncher_apps 
      (product, app_uid, app_title, tile_size, tile_icon, link_type, link_path, 
	   link_invoke, autorun_order, search_enabled, search_default, roles, enabled) 
   VALUES('OIL', NEWID(), 'Headlines',                 'W',  NULL, 'Path', 'C:\TC\ICTS\ICTSCLIENT\HEADLINESCLIENT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'PL Attribution',            'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\ICTSREPORTS\PLATTRIBUTIONREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Liquidation',               'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\LIQUIDATION.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Pricing Today',             'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\PRICINGTODAY.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Price Manager',             'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REFDATAAPPS\PRICEMANAGER.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Price Variation',           'W',  NULL, 'Path', 'C:\tc\icts\jms\Reports\ICTSReports\PriceVariationReport.exe', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'PriceLoad',                 'W',  NULL, 'Path', 'C:\TC\ICTS\jms\AdminApps\PriceLoad.exe', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Ageing',                    'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\AGEINGREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Formula Editor',            'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\FORMULAEDIT.APP\FORMULAEDIT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Cargoes',                   'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\CARGOES.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Portfolio Position',        'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\PORTFOLIOPOSITION.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Ref Data Manager',          'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REFDATAAPPS\ICTSLAUNCHAPPS.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Price',                     'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\PRICEREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Report Builder',            'W',  NULL, 'Path', 'C:\PROGRAM FILES (X86)\MICROSOFT SQL SERVER\REPORT BUILDER 3.0\MSREPORTBUILDER.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'PL by Division',            'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\PROFITLOSSBYDIV.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'New Trade Search',          'W',  NULL, 'Path', 'C:\TC\ICTS\LOGISTICS\APPLICATIONS\LOGISTICS\LOGISTICSSHELL.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Excel Position',            'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\EXCELPOSITIONREPORT\POSITIONREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Exchange Monitor',          'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\EXCHANGEMONITOR\EXCHANGE MONITOR.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Volatility Skew',           'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\VOLATILITYSKEW.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Credit Checker',            'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\CREDITLIMITCHECKER.APP\CREDITLIMITCHECKER.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'OC Trade Capture',          'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\TRADECAPTURE.SERVICE\TRADECAPTURE.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Trade Insert',              'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\TRADEINSERT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Commercial Accounting',     'W',  NULL, 'Path', 'C:\TC\ICTS\LOGISTICS\APPLICATIONS\COMMACCOUNT\COMMACCOUNT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Movements',                 'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\MOVEMENTS.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Profit Loss Booked',        'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\PROFITLOSSBOOKED.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Missing Prices',            'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\MISINGPR.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Reporting Dashboard',       'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\ICTSREPORTS\GENERICPIVOTREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Audit',                     'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\AUDIT.EXE', NULL, NULL, 0, 0, NULL, 1) 
go

INSERT INTO #applauncher_apps 
      (product, app_uid, app_title, tile_size, tile_icon, link_type, link_path, 
	   link_invoke, autorun_order, search_enabled, search_default, roles, enabled) 
   VALUES('OIL', NEWID(), 'Inventory by Location',     'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\INVENTORYBYLOC.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Borrowing Base',            'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\ICTSREPORTS\BORROWINGBASEREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Report Generator',          'W',  NULL, 'Path', 'C:\TC\ICTS\ICTSCLIENT\REPORTGENERATORCLIENT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Open Cost',                 'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\OPENCOSTREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Document Generator',        'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\TEXTDOCGENERATOR.APP\TEXTDOCGENERATOR.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'PL Manager',                'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\PLMANAGER.APP\PLMANAGER.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Unlimited Hedge',           'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\HEDGEREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Book Futures',              'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\BOOKFUTURES.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Credit Viewer',             'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\CREDITVIEWER.APP\CREDITVIEWER.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'WindowServer',              NULL, NULL, 'AutorunSingle', 'C:\Apple\Library\System\WindowServer.exe', NULL, 0, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Inventory Rack',            'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\INVENTORYRACK.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'What''s Chg Dashboard',     'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\ICTSREPORTS\GENERICDXREPORT_WHATSCHANGED.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Timely Allocations',        'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\TIMELYALLOCATIONS.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'SAP',                       'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\SAPREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Portfolio Report',          'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\PORTFOLIOREPORT.APP\PORTFOLIOREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), '21 Day BFO',                'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\BFO21DAYSDATED.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Control Monitor',           'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\CONTROLMONITOR.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Bank Position',             'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\BANKPOSITIONREPORT\BANKPOSITIONREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Trader Counter Listing',    'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\TRADERCOUNTERLISTING.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Audit Trail',               'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\USERCHANGESREPORT\USERCHANGESREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'PriceLoad',                 'W',  NULL, 'Path', 'C:\TC\ICTS\jms\AdminApps\PriceLoad.exe', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'MVT by Portfolio',          'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\MOVEMENTBYPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Deal Viewer',               'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\DEALVIEWER.SERVICE\DEALVIEWER.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Five Days',                 'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\FIVEDAYS.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Portfolio Maintenance',     'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\ADMINAPPS\PORTFOLIOMAINT.APP\PORTFOLIOMAINT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Account',                   'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\ACCOUNTREPORT\ACCOUNTREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Search Dashboard',          'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\ICTSREPORTS\GENERICDXREPORT_SEARCH.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'AATD',                      'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\AATDREPORT\AATDREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'PBS',                       NULL, NULL, 'AutorunSingle', 'C:\Apple\Library\Frameworks\AppKit.framework\Resources\pbs.exe', NULL, 0, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Graphs',                    'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\GRAPHS.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Daily Positions',           'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\DAILYPOSITIONS.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Text Document Generator',   'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\TEXTDOCGENERATOR.APP\TEXTDOCGENERATOR.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Gateway Map Generator',     'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\TOOLS\ACTUALUPLOADERTOOLS\EXCELMAPGENERATOR\EXCELMAPGENERATOR.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Quote',                     'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\QUOTE.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'OC Commercial Accounting',  'W',  NULL, 'Path', 'C:\TC\ICTS\jms\Apps\commAccount.service\CommAccount.exe', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'In-Transit P/L',            'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\TRANSITVARIATIONS.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Allocation Change',         'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\ALLOCATIONCHANGEREPORT\ALLOCATIONCHANGEREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Partial Futures',           'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\PARTIALFUT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Allocation with Multiples', 'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\ALLOCWITHMULTIPLESQTY.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Trade Search',              'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\TRADESEARCH.APP\TRADESEARCH.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Portfolio Analysis',        'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\PORTFOLIOANALYSIS.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Trade Capture',             'W',  NULL, 'Path', 'C:\TC\ICTS\LOGISTICS\APPLICATIONS\TRADECAPTURE\TRADECAPTURE.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Cost Override',             'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\COSTOVERRIDE.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'ICTS Administration',       'W',  NULL, 'Path', 'C:\TC\ICTS\ICTSCLIENT\ICTSADMINCLIENT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'M.O. Dashboard Plus',       'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\ICTSREPORTS\GENERICPIVOTREPORT_MOPLUS.EXE', NULL, NULL, 0, 0, NULL, 1) 
go

INSERT INTO #applauncher_apps 
      (product, app_uid, app_title, tile_size, tile_icon, link_type, link_path, 
	   link_invoke, autorun_order, search_enabled, search_default, roles, enabled) 
   VALUES('OIL', NEWID(), 'GT Securitization',         'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\GTSECURITIZATION.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Price Variation',           'W',  NULL, 'Path', 'C:\tc\icts\jms\Reports\ICTSReports\PriceVariationReport.exe', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Symphony Freight',          'W',  NULL, 'Path', 'C:\TC\ICTS\FLEETIME\AppLauncher.exe', 'Freight', NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Brent by Counter Party',    'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\BRENTBYCOUNTERP.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Operations Dashboard',      'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\ICTSREPORTS\GENERICDXREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Derived Data Generator',    'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\DERIVEDDATAGEN.APP\DERIVEDDATAGEN.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Accounting',                'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\ACCOUNTING.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Credit Wrkfl Dashboard',    'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\ICTSREPORTS\CREDITWORKFLOW.EXE', NULL, NULL, 0, 0, NULL, 0), 
         ('OIL', NEWID(), 'Cash Forecast',             'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\CASHFORECASTREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Repricing',                 'W',  NULL, 'Path', 'C:\tc\icts\jms\Apps\Repricing.app\Repricing.exe', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Quick Fill',                'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\QUICKFILL.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'PRT1A',                     'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\PRT1A.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'PASS',                      'W',  NULL, 'Path', 'C:\TC\ICTS\jms\AdminApps\Pass.app\Pass.exe', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Ops WorkBench',             'W',  NULL, 'Path', 'C:\TC\ICTS\LOGISTICS\APPLICATIONS\LOGISTICS\LOGISTICSSHELL.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Pricing Application',       'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\PRICINGAPP.APP\PRICINGAPP.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Credit',                    'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\CREDITREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'VAR',                       'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\VAR.APP\VAR.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Partial Physical',          'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\PARTIALPHYSICAL.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Correlation Volatility',    'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\ADMINAPPS\CORRVOL.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'PL Booked Volume',          'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\PROFITLOSSBOOKEDVOLUME.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Trade',                     'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\TRADEREPORT.APP\TRADEREPORT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Options',                   'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\OPTIONS.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'COSL',                      'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\COSL.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Collateral',                'W',  NULL, 'Path', 'C:\TC\ICTS\LOGISTICS\APPLICATIONS\COLLATERAL\COLLATERAL.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Interpolate',               'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\ADMINAPPS\INTERPOLATE.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Allocation and Scheduling', 'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\ALLOCATION.APP\ALLOCATION.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Server Manager',            'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\ADMINAPPS\SERVERMANAGER.APP\SERVERMANAGER.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Open EFP',                  'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\OPENEFPS.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'PL History Search',         'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\PLHISTORYSEARCH.APP\PLHISTORYSEARCH.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Portfolio Manager',         'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\APPS\PORTFOLIOMANAGER.APP\PORTFOLIOMANAGER.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'CA Interface',              'W',  NULL, 'Path', 'C:\TC\ICTS\ICTSCLIENT\CAINTERFACECLIENT.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Price Variation',           'W',  NULL, 'Path', 'C:\tc\icts\jms\Reports\ICTSReports\PriceVariationReport.exe', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Gateway Data Uploader',     'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\TOOLS\ACTUALUPLOADERTOOLS\EXCELTODATABASEUPLOADER\EXCELTODATABASEUPLOADER.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Letter of Credit',          'W',  NULL, 'Path', 'C:\TC\ICTS\LOGISTICS\APPLICATIONS\LOGISTICS\LOGISTICSSHELL.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Profit and Loss',           'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\PROFITLOSS.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'Inventory',                 'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\INVENTORY.EXE', NULL, NULL, 0, 0, NULL, 1), 
         ('OIL', NEWID(), 'SEC',                       'W',  NULL, 'Path', 'C:\TC\ICTS\JMS\REPORTS\SECREPORTS.EXE', NULL, NULL, 0, 0, NULL, 1),
         ('OIL', NEWID(), 'Risk Manager',              'W',  NULL, 'Path', 'C:\TC\ICTS\LOGISTICS\APPLICATIONS\RiskManager\RiskManager.exe',NULL,NULL, 0, 0, NULL, 1)
go

INSERT INTO #applauncher_apps 
      (product, app_uid, app_title, tile_size, tile_icon, link_type, link_path, 
	   link_invoke, autorun_order, search_enabled, search_default, roles, enabled) 
   VALUES('OIL', NEWID(), 'Bunkers',                   'W',  NULL, 'PathSingle', 'C:\TC\ICTS\JMS\APPS\BUNKERS.SERVICE\BUNKERS.EXE', NULL, NULL, 0, 0, NULL, 1),
         ('OIL', NEWID(), 'DocGen SSRS',               'W',  NULL, 'Path',       'C:\TC\ICTS\LOGISTICS\APPLICATIONS\DOCUMENTGENERATOR\DOCUMENTGENERATOR.EXE', NULL, NULL, 0, 0, NULL, 1),
		 ('OIL', NEWID(), 'Metals Dashboard',          'W',  NULL, 'PathSingle', 'C:\tc\icts\jms\Reports\ICTSReports\GenericDXReport_Metals.exe', NULL, NULL, 0, 0, NULL, 1),
		 ('OIL', NEWID(), 'Options Eval Tool',         'W',  NULL, 'Path',       'C:\tc\icts\jms\Apps\OptionEvaluationTool\OptionsEvaluationTool.exe', NULL, NULL, 0, 0, NULL, 1),
		 ('OIL', NEWID(), 'Upload Data',               'W',  NULL, 'Path',       'C:\TC\ICTS\JMS\ADMINAPPS\UPLOADDATA.EXE', NULL, NULL, 0, 0, NULL, 1)
go






/* *********************************************************************** */
/* Moving GOOD data in temp table to the APPLAUNCHER_APPS table */

declare @rows_added       int,
        @rows_in_temp     int,
		@errcode          int,
		@smsg             varchar(max)

set @rows_in_temp = (select count(*)
                     from #applauncher_apps)
					 
begin tran
begin try
  insert into dbo.APPLAUNCHER_APPS
     (product, 
      app_uid, 
      app_title, 
      tile_size, 
      tile_icon, 
      link_type, 
      link_path, 
      link_invoke, 
      autorun_order, 
      search_enabled, 
      search_default, 
      roles, 
      enabled)
  select product, 
         app_uid, 
         app_title, 
         tile_size, 
         tile_icon, 
         link_type, 
         link_path, 
         link_invoke, 
         autorun_order, 
         search_enabled, 
         search_default, 
         roles, 
         enabled 
  from #applauncher_apps a
  where not exists (select 1 
                    from dbo.APPLAUNCHER_APPS b
					where a.product = b.product and
					      a.app_uid = b.app_uid)
  set @rows_added = @@rowcount
end try
begin catch
  set @errcode = ERROR_NUMBER()
  set @smsg = ERROR_MESSAGE()
  if @@trancount > 0
     rollback tran
  RAISERROR('=> Failed to move data in temp table to to the APPLAUNCHER_APPS table due to the error:', 0, 1) with nowait
  RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
  goto endofscript
end catch
commit tran

if @rows_added = @rows_in_temp
   RAISERROR('=> All rows (%d) in temp table were successfully copied into the APPLAUNCHER_APPS table', 0, 1, @rows_added) with nowait
else
   RAISERROR('=> No all rows (%d) in temp table were copied into the APPLAUNCHER_APPS table (%d)', 0, 1, @rows_in_temp, @rows_added) with nowait

endofscript:   
go

if object_id('tempdb..#applauncher_apps', 'U') is not null
   exec('drop table #applauncher_apps')
go

