set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the APPLAUNCHER_USER_LAYOUT table ...'
go

if object_id('tempdb..#applauncher_user_layout', 'U') is not null
   exec('drop table #applauncher_user_layout')
go

create table #applauncher_user_layout
(
    product   nvarchar(50)  NOT NULL,
    user_init char(3)       NOT NULL,
    layout    int           NOT NULL
)
go

INSERT INTO #applauncher_user_layout(product, user_init, layout) 
	VALUES('FREIGHT', '---', 4), 
	      ('FREIGHT', 'ICU', 5),
	      ('OIL', '---', 1), 
          ('OIL', 'ICT', 4),  
          ('OIL', 'ICU', 2)  

go

delete #applauncher_user_layout
where user_init <> '---' and
      user_init not in (select user_init
                        from dbo.icts_user)
go

/* *********************************************************************** */
/* Moving GOOD data in temp table to the APPLAUNCHER_USER_LAYOUT table */

declare @rows_added       int,
        @rows_in_temp     int,
		@errcode          int,
		@smsg             varchar(max)

set @rows_in_temp = (select count(*)
                     from #applauncher_user_layout)
					 
begin tran
begin try
  insert into dbo.APPLAUNCHER_USER_LAYOUT
       (product, user_init, layout)
  select product, user_init, layout
  from #applauncher_user_layout a
  where not exists (select 1 
                    from dbo.APPLAUNCHER_USER_LAYOUT b
                    where a.product = b.product and
                          a.user_init = b.user_init)
  set @rows_added = @@rowcount
end try
begin catch
  set @errcode = ERROR_NUMBER()
  set @smsg = ERROR_MESSAGE()
  if @@trancount > 0
     rollback tran
  RAISERROR('=> Failed to move data in temp table to to the APPLAUNCHER_USER_LAYOUT table due to the error:', 0, 1) with nowait
  RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
  goto endofscript
end catch
commit tran

if @rows_added = @rows_in_temp
   RAISERROR('=> All rows (%d) in temp table were successfully copied into the APPLAUNCHER_USER_LAYOUT table', 0, 1, @rows_added) with nowait
else
   RAISERROR('=> No all rows (%d) in temp table were copied into the APPLAUNCHER_USER_LAYOUT table (%d)', 0, 1, @rows_in_temp, @rows_added) with nowait

endofscript:   
go

if object_id('tempdb..#applauncher_user_layout', 'U') is not null
   exec('drop table #applauncher_user_layout')
go


