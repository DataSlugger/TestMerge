set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into QUERIES table ..'
go

if object_id('tempdb..#queries', 'U') is not null
   exec('drop table #queries')
go

create table #queries
(
    fldchrQueryName varchar(100)  NOT NULL,
    fldtxtQuery     text          NOT NULL,
    category        varchar(50)   NULL    
)
go

insert into #queries(fldchrQueryName, fldtxtQuery, category)
select '@DOCSTORE_PATH', 'c:\tc\icts\fleetime\docstore', 'EXTERNAL_MODULES'  
union all
select'@TRUSTED_CONNECTION', 'True', 'CORE_CONFIG'
union all
select '@APPLAUNCHER\WIREFRAME_CLOSEAPP_CONFIRMATION_ENABLED', 'True', 'WIREFRAME'  
union all
select '@APPLAUNCHER\WIREFRAME_CLOSEAPP_CONFIRMATION_MESSAGE', 'Are you sure you want to close the application?', 'WIREFRAME'  
union all
select '@APPLAUNCHER\WIREFRAME_ENSURE_SINGLEINSTANCE', 'True', 'WIREFRAME'  
union all
select '@APPLAUNCHER_AUTORUN_DELAY', '2000', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_ENV_CLASSPATH', '%CLASSPATH%;C:\Apple\Library\JDK\lib\swingall.jar', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_ENV_EXCHANGE_TOOLS_CLASSPATH', '%EXCHANGE_TOOLS_HOME%\exchange_tools_client.jar;%EXCHANGE_TOOLS_HOME%\ThirdPartyJars\jconn2.jar;%EXCHANGE_TOOLS_HOME%\ThirdPartyJars\SignedJCalendar.jar;%EXCHANGE_TOOLS_HOME%\ThirdPartyJars\activation.jar;%EXCHANGE_TOOLS_HOME%\ThirdPartyJars\mail.jar;%EXCHANGE_TOOLS_HOME%\ThirdPartyJars\smartgrid.jar;%EXCHANGE_TOOLS_HOME%\ThirdPartyJars\xerces.jar;%EXCHANGE_TOOLS_HOME%\ThirdPartyJars\PCISEmbedder.zip', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_ENV_EXCHANGE_TOOLS_HOME', 'C:\ExchangeTools\3.0.6_6', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_ENV_JAVA_HOME', 'C:\Progra~1\Java\jre1.5.0_04', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_ENV_LIB', 'C:\Apple\Developer\Libraries;C:\sybase\lib', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_ENV_NEXT_ROOT', 'C:/Apple', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_ENV_NSSESSIONNAME', '%SESSIONNAME%', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_FREIGHT_BAR_FORECOLOR', '255,255,255', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_FREIGHT_BAR_TILEWIDTH_CHILD', '110', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_FREIGHT_BAR_TILEWIDTH_ROOT', '140', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_FREIGHT_DASHBOARD_PATH', 'C:\tc\icts\fleetime\.NETModules\AppLauncherDashboard', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_FREIGHT_SIZE', '1064, 800', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_OIL_BAR_FORECOLOR', '255,255,255', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_OIL_BAR_TILEWIDTH_CHILD', '110', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_OIL_BAR_TILEWIDTH_ROOT', '150', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_OIL_DASHBOARD_PATH', 'C:\tc\icts\jms\Tools\Applauncher\.NETModules\AppLauncherDashboard', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_OIL_SIZE', '1132, 800', 'APPLAUNCHER'  
union all
select '@APPLAUNCHER_OIL_LOGO_PATH', 'C:\tc\icts\jms\Tools\Applauncher\SymphonyLogo.png', 'APPLAUNCHER' 
union all
select '@APPLAUNCHER_OIL_TITLE_TAG',' ','APPLAUNCHER' 
go


insert into dbo.QUERIES
select fldchrQueryName, fldtxtQuery, category 
from #queries 
where fldchrQueryName not in (select fldchrQueryName from dbo.QUERIES)
go