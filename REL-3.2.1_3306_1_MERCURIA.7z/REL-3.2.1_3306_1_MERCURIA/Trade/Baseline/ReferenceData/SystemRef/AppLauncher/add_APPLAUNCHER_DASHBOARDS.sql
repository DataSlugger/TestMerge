set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the APPLAUNCHER_DASHBOARDS table ...'
go

if object_id('tempdb..#applauncher_dashboards', 'U') is not null
   exec('drop table #applauncher_dashboards')
go

create table #applauncher_dashboards
(
    filename       nvarchar(50)      NOT NULL,
    title          nvarchar(50)      NULL,
    description    nvarchar(255)     NULL,
    app_uid        uniqueidentifier  NULL,
	product        nvarchar(50)      NULL,
	app_title      nvarchar(50)      NULL,
    app_keycolumns nvarchar(50)      NULL,
    enabled        bit               DEFAULT 1 NOT NULL
)
go


insert into #applauncher_dashboards
      (filename, title, description, product, app_title, app_keycolumns, enabled) 
   values('BunkerSummary.xml',         'Bunker Summary',       'Top 5 Bunkers Counterparties by Bunker Quantity or Bunker Total Cost.', NULL,      NULL,   NULL,          1), 
         ('Last100Trades.req',          NULL,                  NULL,                                                                    NULL,      NULL,   NULL,          1),
         ('Last20Spot.req',             NULL,                  NULL,                                                                    'Freight', 'Spot', 'ContractKey', 0),
         ('MapByLoadingPort.xml',       'Map by Loading Port', NULL,                                                                    NULL,      NULL,   NULL,          1),
         ('Spot.req',                   NULL,                  NULL,                                                                    'Freight', 'Spot', 'ContractKey', 0), 
         ('TimeCharterPerformance.xml', NULL,                 'Vessels Performance Chart by Ifo or Mdo.',                               NULL,      NULL,   NULL,          1)
go

insert into #applauncher_dashboards
      (filename, enabled) 
   values('CostsByPortfolio.xml', 0),
         ('CostsByPortfolioGrid.xml', 0),
         ('CostsByPortfolioGridOld.xml', 0),
         ('CostsByPortfolioNew.xml', 0),
         ('CostsPortfolio.xml', 0),
         ('PLComparison.xml', 0),
         ('User Permissions.xml', 0)
go

	
update a
set app_uid = b.app_uid
from #applauncher_dashboards a
        JOIN dbo.APPLAUNCHER_APPS b
		   on isnull(a.product, '@@@') = b.product and
		      a.app_title = b.app_title
go


/* *********************************************************************** */
/* Moving GOOD data in temp table to the APPLAUNCHER_DASHBOARDS table */

declare @rows_added       int,
        @rows_in_temp     int,
		@errcode          int,
		@smsg             varchar(max)
		
set @rows_in_temp = (select count(*)
                     from #applauncher_dashboards)
					 
begin tran
begin try
  insert into dbo.APPLAUNCHER_DASHBOARDS
      (filename, title, description, app_uid, app_keycolumns, enabled)
  select filename, 
         title, 
		 description, 
		 app_uid, 
		 app_keycolumns, 
		 enabled 
  from #applauncher_dashboards 
  where filename not in (select filename 
                         from dbo.APPLAUNCHER_DASHBOARDS)
  set @rows_added = @@rowcount
end try
begin catch
  set @errcode = ERROR_NUMBER()
  set @smsg = ERROR_MESSAGE()
  if @@trancount > 0
     rollback tran
  RAISERROR('=> Failed to move data in temp table to to the APPLAUNCHER_DASHBOARDS table due to the error:', 0, 1) with nowait
  RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
  goto endofscript
end catch
commit tran

if @rows_added = @rows_in_temp
   RAISERROR('=> All rows (%d) in temp table were successfully copied into the APPLAUNCHER_DASHBOARDS table', 0, 1, @rows_added) with nowait
else
   RAISERROR('=> No all rows (%d) in temp table were copied into the APPLAUNCHER_DASHBOARDS table (%d)', 0, 1, @rows_in_temp, @rows_added) with nowait

endofscript:   
go

if object_id('tempdb..#applauncher_dashboards', 'U') is not null
   exec('drop table #applauncher_dashboards')
go


