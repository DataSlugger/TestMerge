set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into APPLAUNCHER_USER_FAVORITES table ..'
go

if object_id('tempdb..#applauncher_user_favorites', 'U') is not null
   exec('drop table #applauncher_user_favorites')
go

create table #applauncher_user_favorites
(
    product         nvarchar(50)      NOT NULL,
    user_init       char(3)           NOT NULL,
    app_uid         uniqueidentifier  NULL,
	app_title       nvarchar(50)      NULL,
    [position]      int               NOT NULL,
    category_uid    uniqueidentifier  NULL,
	category_title  nvarchar(50)      NULL
)
go

INSERT INTO #applauncher_user_favorites
     (product, user_init, app_title, [position], category_title) 
   VALUES('Freight', '---', 'Vessels Position',      2, 'Operations'), 
         ('Freight', '---', 'COA',                   1, 'Chartering'), 
         ('Freight', '---', 'Ops Workbench',         3, 'Link to Oil'), 
         ('Freight', '---', 'Freight Planner',       0, 'Root'), 
         ('OIL',     '---', 'Commercial Accounting', 2, 'Accounting'), 
         ('OIL',     '---', 'Trade Capture',         0, 'Front Office'), 
         ('OIL',     '---', 'Ops WorkBench',         1, 'Operations'), 
         ('OIL',     '---', 'Portfolio Manager',     3, 'Front Office')
go

update a
set category_uid = b.category_uid
from #applauncher_user_favorites a
        JOIN dbo.APPLAUNCHER_CATEGORIES b
		   on a.product = b.product and
		      a.category_title = b.category_title
go

update a
set app_uid = b.app_uid
from #applauncher_user_favorites a
        JOIN dbo.APPLAUNCHER_APPS b
		   on a.product = b.product and
		      a.app_title = b.app_title
go


/* *********************************************************************** */
/* Moving GOOD data in temp table to the APPLAUNCHER_USER_FAVORITES table */

declare @rows_added       int,
        @rows_in_temp     int,
		@errcode          int,
		@smsg             varchar(max)

set @rows_in_temp = (select count(*)
                     from #applauncher_user_favorites)
					 
begin tran
begin try
  insert into dbo.APPLAUNCHER_USER_FAVORITES
  select product, user_init, app_uid, [position], category_uid
  from #applauncher_user_favorites a
  where not exists (select 1 
                    from dbo.APPLAUNCHER_USER_FAVORITES b
				    where a.product = b.product and
				          a.user_init = b.user_init and
						  a.app_uid = b.app_uid and
						  a.category_uid = b.category_uid)
  set @rows_added = @@rowcount
end try
begin catch
  set @errcode = ERROR_NUMBER()
  set @smsg = ERROR_MESSAGE()
  if @@trancount > 0
     rollback tran
  RAISERROR('=> Failed to move data in temp table to to the APPLAUNCHER_USER_FAVORITES table due to the error:', 0, 1) with nowait
  RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
  goto endofscript
end catch
commit tran

if @rows_added = @rows_in_temp
   RAISERROR('=> All rows (%d) in temp table were successfully copied into the APPLAUNCHER_USER_FAVORITES table', 0, 1, @rows_added) with nowait
else
   RAISERROR('=> No all rows (%d) in temp table were copied into the APPLAUNCHER_USER_FAVORITES table (%d)', 0, 1, @rows_in_temp, @rows_added) with nowait

endofscript:   
go

if object_id('tempdb..#applauncher_user_favorites', 'U') is not null
   exec('drop table #applauncher_user_favorites')
go


