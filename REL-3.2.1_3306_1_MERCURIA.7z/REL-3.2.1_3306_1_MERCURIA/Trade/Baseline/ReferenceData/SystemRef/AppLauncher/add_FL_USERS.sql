set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the FL_USERS table ...'
go

if object_id('tempdb..#fl_users', 'U') is not null
   exec('drop table #fl_users')
go

create table #fl_users
(
   user_init     char(3)  NOT NULL,
   user_calendar char(8)  NULL
)
go

insert into #fl_users (user_init, user_calendar) 
   values('SVR', 'NULL')
go



/* *********************************************************************** */
/* Moving GOOD data in temp table to the FL_USERS table */

declare @rows_added       int,
        @rows_in_temp     int,
		@errcode          int,
		@smsg             varchar(max)

set @rows_in_temp = (select count(*)
                     from #fl_users)
					 
begin tran
begin try
  insert into dbo.FL_USERS
       (user_init, user_calendar)
  select user_init, user_calendar 
  from #fl_users 
  where user_init not in (select user_init from dbo.FL_USERS)
  set @rows_added = @@rowcount
end try
begin catch
  set @errcode = ERROR_NUMBER()
  set @smsg = ERROR_MESSAGE()
  if @@trancount > 0
     rollback tran
  RAISERROR('=> Failed to move data in temp table to to the FL_USERS table due to the error:', 0, 1) with nowait
  RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
  goto endofscript
end catch
commit tran

if @rows_added = @rows_in_temp
   RAISERROR('=> All rows (%d) in temp table were successfully copied into the FL_USERS table', 0, 1, @rows_added) with nowait
else
   RAISERROR('=> No all rows (%d) in temp table were copied into the FL_USERS table (%d)', 0, 1, @rows_in_temp, @rows_added) with nowait

endofscript:   
go

if object_id('tempdb..#fl_users', 'U') is not null
   exec('drop table #fl_users')
go


