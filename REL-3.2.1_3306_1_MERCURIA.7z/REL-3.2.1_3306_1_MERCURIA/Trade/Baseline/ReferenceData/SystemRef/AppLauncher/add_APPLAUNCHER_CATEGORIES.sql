set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the APPLAUNCHER_CATEGORIES table ..'
go

if object_id('tempdb..#applauncher_categories', 'U') is not null
   exec('drop table #applauncher_categories')
go

create table #applauncher_categories
(
    product               nvarchar(50)      NOT NULL,
    category_uid          uniqueidentifier  NOT NULL,
    category_title        nvarchar(50)      NULL,
    category_parent       uniqueidentifier  NULL,
    category_title_parent nvarchar(50)      NULL,
    tile_color            nvarchar(12)      NULL,
    tile_icon             int               NULL,
    type                  nvarchar(12)      NOT NULL,
    linkspanel_itemswidth int               NULL,
    linkspanel_rows       int               NULL,
    [position]            int               NULL,
    enabled               bit               DEFAULT 1 NOT NULL
)
go

INSERT INTO #applauncher_categories
       (product, category_uid, category_title, category_title_parent, tile_color, 
	      tile_icon, type, linkspanel_itemswidth, linkspanel_rows, [position], enabled) 
   VALUES('Freight', NEWID(), 'Operations',     'Root', '62, 112, 56', 2,    'TileBar', NULL, NULL, 0, 1), 
         ('Freight', NEWID(), 'Root',           NULL,   '0, 135, 156', NULL, 'TileBar', NULL, NULL, 0, 1), 
         ('Freight', NEWID(), 'Reports',        'Root', '192, 0, 0',   1,    'TileBar', NULL, NULL, 0, 1), 
         ('Freight', NEWID(), 'Link to Oil',    'Root', '4,0,111',     6,    'TileBar', NULL, NULL, 0, 1), 
         ('Freight', NEWID(), 'Chartering',     'Root', '204, 109, 0', 3,    'TileBar', NULL, NULL, 0, 1), 
         ('Freight', NEWID(), 'Mark to Market', 'Root', '0, 135, 156', 4,    'TileBar', NULL, NULL, 0, 1), 
         ('Freight', NEWID(), 'Tools',          'Root', '163,101,67',  0,    'TileBar', NULL, NULL, 0, 1) 
go

INSERT INTO #applauncher_categories
       (product, category_uid, category_title, category_title_parent, tile_color, 
	      tile_icon, type, linkspanel_itemswidth, linkspanel_rows, [position], enabled) 
   VALUES('OIL', NEWID(), 'Reports',          'Root',    '192,0,0',     1,    'TileBar',    NULL, NULL, 0, 1), 
         ('OIL', NEWID(), 'Operations',       'Root',    '62, 112, 56', 2,    'TileBar',    NULL, NULL, 0, 1), 
         ('OIL', NEWID(), 'Credit',           'Root',    '0, 114, 198', 8,    'TileBar',    NULL, NULL, 0, 1), 
         ('OIL', NEWID(), 'Front Office',     'Root',    '0, 135, 156', 5,    'TileBar',    NULL, NULL, 0, 1), 
         ('OIL', NEWID(), 'Accounting',       'Root',    '204, 109, 0', 3,    'TileBar',    NULL, NULL, 0, 1), 
         ('OIL', NEWID(), 'Pricing and Risk', 'Root',    '4, 0, 111',   4,    'TileBar',    NULL, NULL, 0, 1), 
         ('OIL', NEWID(), 'All',              'Reports', '160,0,0',     1,    'LinksPanel', 120,  7,    0, 1), 
         ('OIL', NEWID(), 'Tools',            'Root',    '163,101,67',  0,    'TileBar',    NULL, NULL, 0, 1), 
         ('OIL', NEWID(), 'Root',             NULL,      '0, 135, 156', NULL, 'TileBar',    NULL, NULL, 0, 1),  
         ('OIL', NEWID(), 'Front Office',     'Root',    '0,135,156',   5,    'TileBar',    NULL, NULL, 0, 1)
go 

update a
set category_parent = b.category_uid
from #applauncher_categories a
        JOIN dbo.APPLAUNCHER_CATEGORIES b
		   on a.product = b.product and
		      a.category_title_parent = b.category_title
go



/* *********************************************************************** */
/* Moving GOOD data in temp table to the APPLAUNCHER_CATEGORIES table */

declare @rows_added       int,
        @rows_in_temp     int,
		@errcode          int,
		@smsg             varchar(max)

set @rows_in_temp = (select count(*)
                     from #applauncher_categories)
					 
begin tran
begin try
  insert into dbo.APPLAUNCHER_CATEGORIES
      ([product],
	   [category_uid],
	   [category_title],
	   [category_parent],
	   [tile_color],
	   [tile_icon],
	   [type],
	   [linkspanel_itemswidth],
	   [linkspanel_rows],
	   [position],
	   [enabled])
  select product, 
         category_uid, 
         category_title, 
         category_parent, 
         tile_color, 
         tile_icon, 
         type, 
         linkspanel_itemswidth, 
         linkspanel_rows, 
         [position], 
         enabled 
  from #applauncher_categories a
  where not exists (select 1 
                    from dbo.APPLAUNCHER_CATEGORIES b
					where a.product = b.product and
					      a.category_uid = b.category_uid)
  set @rows_added = @@rowcount
end try
begin catch
  set @errcode = ERROR_NUMBER()
  set @smsg = ERROR_MESSAGE()
  if @@trancount > 0
     rollback tran
  RAISERROR('=> Failed to move data in temp table to to the APPLAUNCHER_CATEGORIES table due to the error:', 0, 1) with nowait
  RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
  goto endofscript
end catch
commit tran

if @rows_added = @rows_in_temp
   RAISERROR('=> All rows (%d) in temp table were successfully copied into the APPLAUNCHER_CATEGORIES table', 0, 1, @rows_added) with nowait
else
   RAISERROR('=> No all rows (%d) in temp table were copied into the APPLAUNCHER_CATEGORIES table (%d)', 0, 1, @rows_in_temp, @rows_added) with nowait

endofscript:   
go

if object_id('tempdb..#applauncher_categories', 'U') is not null
   exec('drop table #applauncher_categories')
go


