set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into APPLAUNCHER_USER_DASHBOARDS table ..'
go

if object_id('tempdb..#applauncher_user_dashboards', 'U') is not null
   exec('drop table #applauncher_user_dashboards')
go

create table #applauncher_user_dashboards
(
    product    nvarchar(50)  NOT NULL,
    user_init  char(3)       NOT NULL,
    filename   nvarchar(50)  NOT NULL,
    [position] int           NULL,
    enabled    bit           DEFAULT 1 NOT NULL
)
go

insert into #applauncher_user_dashboards
     (product, user_init, filename, [position], enabled) 
   values('FREIGHT', '---', 'BunkerSummary.xml',    3, 1), 
         ('FREIGHT', '---', 'Last20Spot.req',       1, 1),
         ('FREIGHT', '---', 'MapByLoadingPort.xml', 4, 1),
         ('FREIGHT', 'ICU', 'BunkerSummary.xml',    3, 1),  
         ('FREIGHT', 'ICU', 'Last20Spot.req',       2, 1),  
         ('FREIGHT', 'ICU', 'MapByLoadingPort.xml', 4, 1), 
         ('FREIGHT', 'ICU', 'Spot.req',             1, 1),  
         ('OIL',     '---', 'Last100Trades.req',    1, 1),
         ('OIL',     'ICT', 'Last100Trades.req',    1, 1),  
         ('OIL',     'ICT', 'Spot.req',             2, 1),  
         ('OIL',     'ICU', 'Last100Trades.req',    1, 1),  
         ('OIL',     'ICU', 'Spot.req',             2, 1)  
go 


delete #applauncher_user_dashboards
where user_init <> '---' and
      user_init not in (select user_init
                        from dbo.icts_user)
go

/* *********************************************************************** */
/* Moving GOOD data in temp table to the APPLAUNCHER_USER_DASHBOARDS table */

declare @rows_added       int,
        @rows_in_temp     int,
		@errcode          int,
		@smsg             varchar(max)

set @rows_in_temp = (select count(*)
                     from #applauncher_user_dashboards)
					 
begin tran
begin try
  insert into dbo.APPLAUNCHER_USER_DASHBOARDS
        (product, user_init, filename, [position], enabled)
  select product, 
         user_init, 
		 filename, 
		 [position], 
		 enabled 
  from #applauncher_user_dashboards a
  where not exists (select 1 
                    from dbo.APPLAUNCHER_USER_DASHBOARDS b
				    where a.product = b.product and
				          a.user_init = b.user_init and
						  a.filename = b.filename)
  set @rows_added = @@rowcount
end try
begin catch
  set @errcode = ERROR_NUMBER()
  set @smsg = ERROR_MESSAGE()
  if @@trancount > 0
     rollback tran
  RAISERROR('=> Failed to move data in temp table to to the APPLAUNCHER_USER_DASHBOARDS table due to the error:', 0, 1) with nowait
  RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
  goto endofscript
end catch
commit tran

if @rows_added = @rows_in_temp
   RAISERROR('=> All rows (%d) in temp table were successfully copied into the APPLAUNCHER_USER_DASHBOARDS table', 0, 1, @rows_added) with nowait
else
   RAISERROR('=> No all rows (%d) in temp table were copied into the APPLAUNCHER_USER_DASHBOARDS table (%d)', 0, 1, @rows_in_temp, @rows_added) with nowait

endofscript:   
go


if object_id('tempdb..#applauncher_user_dashboards', 'U') is not null
   exec('drop table #applauncher_user_dashboards')
go

