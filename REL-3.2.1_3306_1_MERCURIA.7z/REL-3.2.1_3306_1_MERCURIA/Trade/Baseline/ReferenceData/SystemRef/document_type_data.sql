set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table document_type
go

print 'Loading system reference data into the document_type table ...'
go

insert into dbo.document_type 
   values('B', 'Booking Slip', 'CommAccount', 1)
go

insert into dbo.document_type 
   values('I', 'Invoice', 'CommAccount', 1)
go

insert into dbo.document_type 
   values('L', 'Letter of Credit', 'LC', 1)
go

insert into dbo.document_type 
   values('P', 'Pipeline Statement', 'Allocation', 1)
go

insert into dbo.document_type 
   values('c', 'JM Cash Settled', 'CommAccount', 1)
go

insert into dbo.document_type 
   values('d', 'JM Delivery Order', 'Allocation', 1)
go

insert into dbo.document_type 
   values('e', 'JM Exchange Invoices', 'CommAccount', 1)
go

insert into dbo.document_type 
   values('n', 'Nomination Letter', 'Allocation', 1)
go

insert into dbo.document_type 
   values('p', 'JM Phys Invoices', 'CommAccount', 1)
go

insert into dbo.document_type 
   values('s', 'JM Swap Invoices', 'CommAccount', 1)
go

