set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bus_cost_num_children
go

print 'Loading system reference data into the bus_cost_num_children table ...'
go

insert into dbo.bus_cost_num_children 
   values('ONE_OR_MORE', 'One or more', NULL, 1)
go

