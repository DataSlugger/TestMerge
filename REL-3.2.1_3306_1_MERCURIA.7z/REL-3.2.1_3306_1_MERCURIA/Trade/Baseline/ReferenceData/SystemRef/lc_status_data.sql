set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the lc_status table ...'
go

IF NOT EXISTS (select * from dbo.lc_status
               where lc_status_code = 'ASSIGNED')                
   INSERT INTO dbo.lc_status(lc_status_code , lc_status_short_name , lc_status_desc , trans_id)
   VALUES('ASSIGNED', 'Assigned', 'Assigned', 1)
go