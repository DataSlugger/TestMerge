set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bus_cost_sub_owner
go

print 'Loading system reference data into the bus_cost_sub_owner table ...'
go

insert into dbo.bus_cost_sub_owner 
   values('ACC', 'Accrual', 'Accrual Portfolio PosGroup', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('ADJ', 'Adjustment', 'Adjustment Portfolio PosGroup', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('BROK', 'Brokerage Fee', 'Brokerage Fee', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('CAS', 'Wet Phys Sec CA', 'Wet Phys Sec CA Type', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('DPP', 'Dry Phy Principal Primary', 'Dry Phy Principal Primary', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('JE', 'Journal Entry', 'Journal Entry', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('M', 'Memo', 'Memo Portfolio PosGroup', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('NF', 'Portfolio', 'Notional Finance Portfolio PosGroup', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('OPP', 'OTC Option PP', 'Wet OTC Option Principal Primary', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('PDO', 'Lease Division Order', 'Lease Division Order', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('PL', 'PL Entry', 'PL Entry Portfolio PosGroup', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('PO', 'Preliminary Offset', 'Offset to the preliminary cost', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('POC', 'Lease Paid On Contract', 'Lease Paid On Contract', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('PR', 'Preliminary', 'Preliminary cost before cost is final vouchered', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('PS', 'Portfolio', 'Secondary Portfolio PosGroup', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('R', 'Reserve', 'Reserve Portfolio PosGroup', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('RB', 'Rebook', 'Rebook Type', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('RV', 'Reversal', 'Revarsal Type', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('RWPP', 'Rack Wet Phy Primary', 'Rack Wet Phy Primary', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('S', 'Storage', 'Storage Trade Item Type', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('SPP', 'Storage PP', 'Storage Principal Primary', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('SWAP', 'Swap Trades', 'Swap Trades', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('T', 'Transportation', 'Transportation Trade Item Type', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('TVM', 'TVM', 'TVM Portfolio PosGroup', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('V', 'Value', 'Value Inventory Type', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('WAP', 'Wet Phy Add Primary', 'Wet Phy Additional Primary', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('WO', 'Write-off', 'Write-off Type', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('WPP', 'Wet Phy Principal Primary', 'Wet Phy Principal Primary', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('WS', 'Wet Phys Sec', 'Wet Phys Sec Type', 1)
go

insert into dbo.bus_cost_sub_owner 
   values('TAX','Tax','Import Duty Tax',1)
go

insert into dbo.bus_cost_sub_owner 
     (bc_sub_owner_code, bc_sub_owner_full_name,bc_sub_owner_desc,trans_id)
SELECT 'PRF', 'Prefinal', 'Prefinal cost for a principal primary when its preliminary cost is vouchered', 1
UNION ALL
SELECT 'PFO', 'Prefinal Offset', 'Offset to the Prefinal cost for a principal primary when its preliminary cost is vouchered', 1
go

