set nocount on

set QUOTED_IDENTIFIER ON
go

print ' '
print 'Loading system reference data into the defaults_domain table ...'
go

if not exists (select 1
               from dbo.defaults_domain
               where name = 'Global')
   insert into dbo.defaults_domain (oid, name, parent_id, trans_id)
      values (1, 'Global', null, 1)
go

create table #defaults_domain
(
   oid                 int primary key,
   name                varchar(50) not null,
   parent_name         varchar(50) null
)

declare @oid           int,
        @newoid        int,
        @parent_id     int,
        @name          varchar(50),
        @parent_name   varchar(50),    
        @errcode       int,
        @rows_affected int,
        @smsg          varchar(255)

select @errcode = 0

insert into #defaults_domain values(1, 'ICTSAdmin', 'Global')
insert into #defaults_domain values(2, 'FuturesCapture', 'Global')
insert into #defaults_domain values(3, 'TraderDashboard', 'Global')
insert into #defaults_domain values(4, 'PassLogViewer', 'Global')
insert into #defaults_domain values(5, 'SymphonyPortal', 'Global')
insert into #defaults_domain values(6, 'LivePrices', 'Global')
insert into #defaults_domain values(7, 'LivePriceLoad', 'Global')
insert into #defaults_domain values(8, 'Headlines', 'Global')
insert into #defaults_domain values(9, 'Nomination', 'Global')
insert into #defaults_domain values(10, 'LQS', 'Global')
insert into #defaults_domain values(11, 'PASS', 'Global')
insert into #defaults_domain values(12, 'JavaALServer', 'Global')
insert into #defaults_domain values(13, 'ALServer', 'Global')
insert into #defaults_domain values(14, 'ReportGenerator', 'Global')
insert into #defaults_domain values(15, 'ExcelPositionReport', 'Global')
insert into #defaults_domain values(16, 'TruckCapture', 'Global')
insert into #defaults_domain values(17, 'ProcessTicket', 'Global')
insert into #defaults_domain values(18, 'PriceManager', 'Global')
insert into #defaults_domain values(19, 'CVXWebService', 'Global')
insert into #defaults_domain values(20, 'CVXTestWebservice', 'Global')
insert into #defaults_domain values(21, 'RMSInterface', 'Global')
insert into #defaults_domain values(22, 'GatewayInboundWS', 'Global')
insert into #defaults_domain values(23, 'GatewayOutboundWS', 'Global')
insert into #defaults_domain values(24, 'GatewayServiceEngine', 'Global')
insert into #defaults_domain values(25, 'Logistics', 'Global')
insert into #defaults_domain values(26, 'CAInterface', 'Global')
insert into #defaults_domain values(27, 'TradeCapture', 'Global')
insert into #defaults_domain values(28, 'Collateral', 'Global')
insert into #defaults_domain values(29, 'CommAccount', 'Global')


select @oid = min(oid)
from #defaults_domain

while @oid is not null
begin
   select @name = name,
          @parent_name = parent_name
   from #defaults_domain
   where oid = @oid

   if not exists (select 1
                  from dbo.defaults_domain
                  where name = @name)
   begin
      select @smsg = '=> Adding the defaults_domain entry ''' + @name + ''' ...'
      print @smsg
      
      select @parent_id = oid
      from dbo.defaults_domain
      where name = @parent_name
      
      select @newoid = 0
      select @newoid = isnull(max(oid), 0) + 1
      from dbo.defaults_domain
      select @errcode = @@error
      if @errcode > 0 or @newoid = 0
      begin
         print '=> Failed to obtain an ID for new defaults_domain entry!'
         goto endofscript
      end
   
      begin tran
      insert into dbo.defaults_domain (oid, name, parent_id, trans_id)
          values (@newoid, @name, @parent_id, 1)
      select @rows_affected = @@rowcount,
             @errcode = @@error
      if @errcode > 0
      begin
         if @@trancount > 0
            rollback tran
         print '==> Failed to add the new defaults_domain entry!'
         goto endofscript
      end
      commit tran
      if @rows_affected > 0
      begin
         select @smsg = '==> The new defaults_domain entry #' + convert(varchar, @oid) + ' was added successfully!'
         print @smsg
      end
      else
         print '==> No defaults_domain record was added ???'
   end
   else
      print '==> The entry has existed in the defaults_domain table already!'

   select @oid = min(oid)
   from #defaults_domain
   where oid > @oid
end
endofscript:
drop table #defaults_domain
go