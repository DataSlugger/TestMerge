set nocount on

set QUOTED_IDENTIFIER ON
go

print ' '
print 'Loading system reference data into the entity_key_name table ...'
go

CREATE TABLE #entity_keys 
(
    oid           int IDENTITY primary key,
    entity_name   varchar(30) NOT NULL,
    key_num       int         NOT NULL,
    key_name      varchar(30) NOT NULL,
    key_data_type varchar(15) NOT NULL
)
go

insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Account', 1, 'acctNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AccountAddress', 1, 'acctNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AccountAddress', 2, 'acctAddrNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AccountContact', 1, 'acctNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AccountContact', 2, 'acctContNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AccountGroup', 1, 'relatedAcctNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AccountGroup', 2, 'acctNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AccountGroup', 3, 'acctGroupTypeCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AccountInstruction', 1, 'acctNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AccountInstruction', 2, 'acctInstrNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AcctVatNumber', 1, 'acctVatNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Accumulation', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Accumulation', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Accumulation', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Accumulation', 4, 'accumNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AiEstActual', 1, 'allocNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AiEstActual', 2, 'allocItemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AiEstActual', 3, 'aiEstActualNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AiEstActualAirline', 1, 'allocNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AiEstActualAirline', 2, 'allocItemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AiEstActualAirline', 3, 'aiEstActualNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AiEstActualSpec', 1, 'allocNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AiEstActualSpec', 2, 'allocItemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AiEstActualSpec', 3, 'aiEstActualNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AiEstActualSpec', 4, 'specCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Allocation', 1, 'allocNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AllocationItem', 1, 'allocNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AllocationItem', 2, 'allocItemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AllocationItemTransport', 1, 'allocNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AllocationItemTransport', 2, 'allocItemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AllocationItemVat', 1, 'allocNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AllocationItemVat', 2, 'allocItemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AssignTrade', 1, 'assignNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CalendarDetail', 1, 'calendarCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CalendarDetail', 2, 'calendarDate', 'datetime')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CashSettleDate', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CashSettleDate', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CashSettleDate', 3, 'cashSettleNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Commodity', 1, 'cmdtyCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CommodityLocation', 1, 'cmdtyCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CommodityLocation', 2, 'locCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CommodityMarket', 1, 'commktKey', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CommodityMarketSource', 1, 'commktKey', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CommodityMarketSource', 2, 'priceSourceCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Cost', 1, 'costNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CostCenter', 1, 'costCenterCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CostCode', 1, 'costCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CostEqualizationRate', 1, 'costNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CostEqualizationRate', 2, 'specCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CostEqualizationRate', 3, 'effectiveDate', 'datetime')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CostExtInfo', 1, 'costNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CostInterfaceInfo', 1, 'costNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CostRate', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CostTemplateItem', 1, 'costTemplateOid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CostTemplateItem', 2, 'costNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Country', 1, 'countryCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CreditLimit', 1, 'creditLimitNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CreditTerm', 1, 'creditTermCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CustomVoucherRange', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('EIPPTask', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('EntityTag', 1, 'entityTagKey', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Event', 1, 'eventNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('ExposureDetail', 1, 'costNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('ExposureDetail', 2, 'exposureNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('ExternalTrade', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FbEventPriceTerm', 1, 'formulaNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FbEventPriceTerm', 2, 'formulaBodyNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FbModularInfo', 1, 'formulaNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FbModularInfo', 2, 'formulaBodyNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('ForecastValue', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Formula', 1, 'formulaNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FormulaBody', 1, 'formulaNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FormulaBody', 2, 'formulaBodyNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FormulaBodyTrigger', 1, 'formulaNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FormulaBodyTrigger', 2, 'formulaBodyNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FormulaBodyTrigger', 3, 'triggerNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FormulaComponent', 1, 'formulaNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FormulaComponent', 2, 'formulaBodyNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FormulaComponent', 3, 'formulaCompNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxHedgeRate', 1, 'fxHedgeRateNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxCostDrawDownHist', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxExposure', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxExposureCurrency', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxExposureDist', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxExposurePl', 1, 'plAsofDate', 'datetime')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxExposurePl', 2, 'expKeyType', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxExposurePl', 3, 'expKeyNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxLinkedCosts', 1, 'fxLinkOid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxLinkedCosts', 2, 'costNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxLinking', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxRateHistory', 1, 'costNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxRateHistory', 2, 'fxAsofDate', 'datetime')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxRateHistory', 3, 'realPortNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FxRateHistory', 4, 'fxExpNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('IctsMessage', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('IctsMessageDetail', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('IctsUser', 1, 'userInit', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Inventory', 1, 'invNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('InventoryBuildDraw', 1, 'invNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('InventoryBuildDraw', 2, 'invBDNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('JobSchedule', 1, 'jobScheduleNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Lc', 1, 'lcNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('LcAllocation', 1, 'lcNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('LcAllocation', 2, 'lcAllocNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Location', 1, 'locCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('LocationTankInfo', 1, 'tankNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Market', 1, 'mktCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('MarketPricingCondition', 1, 'cmfNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('MarketPricingCondition', 2, 'mktPricingCondNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('MarketPriceQuoteDates', 1, 'cmfNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('MarketPriceQuoteDates', 2, 'calendarDate', 'datetime')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Mot', 1, 'motCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('OptionStrike', 1, 'commktKey', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('OptionStrike', 2, 'tradingPrd', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('OptionStrike', 3, 'optStrikePrice', 'double')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('OptionStrike', 4, 'putCallInd', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Parcel', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('ParcelQualitySlate', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PaymentTerm', 1, 'payTermCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PlHistory', 1, 'plAsofDate', 'datetime')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PlHistory', 2, 'plRecordKey', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PlHistory', 3, 'plOwnerCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PlHistory', 4, 'plType', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Portfolio', 1, 'portNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PortfolioGroup', 1, 'parentPortNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PortfolioGroup', 2, 'portNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PortfolioProfitLoss',1,'portNum','int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PortfolioProfitLoss',2,'plAsofDate','datetime')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Position',1,'posNum','int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PositionMarkToMarket',1,'posNum','int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PositionMarkToMarket',2,'mtmAsofDate','datetime')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Price', 1, 'commktKey', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Price', 2, 'priceSourceCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Price', 3, 'tradingPrd', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Price', 4, 'priceQuoteDate', 'datetime')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PriceSource', 1, 'priceSourceCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('QuotePricingPeriod', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('QuotePricingPeriod', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('QuotePricingPeriod', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('QuotePricingPeriod', 4, 'accumNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('QuotePricingPeriod', 5, 'qppNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('RepriceEventDetail', 1, 'repriceEventOid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('RepriceEventDetail', 2, 'repriceEventDetailNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Shipment', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('ShipmentMot', 1, 'shipmentNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('ShipmentMot', 2, 'motCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('ShipmentPath', 1, 'shipmentOid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Specification', 1, 'specCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Trade', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeFormula', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeFormula', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeFormula', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeFormula', 4, 'formulaNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItem', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItem', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItem', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemBunker', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemBunker', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemBunker', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemCashPhy', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemCashPhy', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemCashPhy', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemCurr', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemCurr', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemCurr', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemDist', 1, 'distNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemExchOpt', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemExchOpt', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemExchOpt', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemExtInfo', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemExtInfo', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemExtInfo', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemFill', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemFill', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemFill', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemFill', 4, 'itemFillNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemFut', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemFut', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemFut', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemOtcOpt', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemOtcOpt', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemOtcOpt', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemRin', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemRin', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemRin', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemSpec', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemSpec', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemSpec', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemSpec', 4, 'specCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemStorage', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemStorage', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemStorage', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemTransport', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemTransport', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemTransport', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemWetPhy', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemWetPhy', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemWetPhy', 3, 'itemNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeOrder', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeOrder', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeOrderBunker', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeOrderBunker', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeTermInfo', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradingPeriod', 1, 'commktKey', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradingPeriod', 2, 'tradingPrd', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Uom', 1, 'uomCode', 'char')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('VesselDist', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Voucher', 1, 'voucherNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('VoucherCost', 1, 'voucherNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('VoucherCost', 2, 'costNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('VoucherPayment', 1, 'voucherNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CostTemplateItem', 1, 'costTemplateOid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('CostTemplateItem', 2, 'costNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FeedDetailData', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('PmTypeBRecord', 1, 'fddId', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('Scenario', 1, 'oid', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('AvgBuySellPriceTerm', 1, 'formulaNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('EventPriceTerm', 1, 'formulaNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('EventPriceTerm', 2, 'priceTermNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FormulaCondition', 1, 'formulaNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('FormulaCondition', 2, 'formulaCondNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemDryPhy', 1, 'tradeNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemDryPhy', 2, 'orderNum', 'int')
go
insert into #entity_keys (entity_name, key_num, key_name, key_data_type) values('TradeItemDryPhy', 3, 'itemNum', 'int')
go

/* DO NOT NEED TO CHANGE CODE BELOW */
declare @entity_name   varchar(30),
        @key_num       int,
        @key_name      varchar(30),
        @key_data_type varchar(15),
		@rows_affected int,
        @oid           int	
		
select @oid = min(oid)
from #entity_keys

while @oid is not null
begin
   select @entity_name = entity_name,
          @key_num = key_num,
          @key_name = key_name,
          @key_data_type = key_data_type
   from #entity_keys
   where oid = @oid
   
   IF NOT EXISTS (select * from dbo.entity_key_name
                  where entity_name = @entity_name and
                        key_name = @key_name)
   begin
      begin tran
      begin try
        insert into dbo.entity_key_name (entity_name, key_num, key_name, key_data_type) 
	         values(@entity_name, @key_num, @key_name, @key_data_type)
        set @rows_affected = @@rowcount
	  end try
	  begin catch
	    print '=> Failed to add recoord with (entity_name = ''' + @entity_name + ''', @key_num  = ' + cast(@key_num as varchar) + ')!'
		print '==> ERROR: ' + ERROR_MESSAGE()
		if @@trancount > 0
		   rollback tran
        goto nextrec		
	  end catch
	  commit tran
	  if @rows_affected > 0
	     print '=> A new entity_key_name recoord with (entity_name = ''' + @entity_name + ''', @key_num  = ' + cast(@key_num as varchar) + ') was added successfully!'
   end
   else
	  print '=> The entoty_key_name recoord with (entity_name = ''' + @entity_name + ''', @key_num  = ' + cast(@key_num as varchar) + ') exists!'
   
nextrec:
   select @oid = min(oid)
   from #entity_keys
   where oid > @oid
end
drop table #entity_keys
go

print ' '
print 'REMINDER: Please run the db script ''icts_entity_name_data.sql'' to load'
print '          new entities into the icts_entity_name table!'
go