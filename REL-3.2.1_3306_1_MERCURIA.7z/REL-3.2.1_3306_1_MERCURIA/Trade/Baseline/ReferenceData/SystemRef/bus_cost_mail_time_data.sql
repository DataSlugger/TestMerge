set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bus_cost_mail_time
go

print 'Loading system reference data into the bus_cost_mail_time table ...'
go

insert into dbo.bus_cost_mail_time 
   values('IMMEDIAT', 'IMMEDIATE', 1)
go

