set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the uic_status table ...'
go

create table #uic_status
(
   oid              numeric(18, 0) IDENTITY PRIMARY KEY,
   entity_name      varchar(30) not null,
   status_selector  varchar(250)
)

insert into #uic_status (entity_name, status_selector)
   values('Allocation', 'isConfirmed')
insert into #uic_status (entity_name, status_selector)
   values('AllocationItem', 'allocation.isConfirmed')
insert into #uic_status (entity_name, status_selector)
   values('AllocationItemTransport', 'allocationItem.allocation.isConfirmed')
insert into #uic_status (entity_name, status_selector)
   values('Cost', 'isOpen')
insert into #uic_status (entity_name, status_selector)
   values('Parcel', 'shouldTrackChanges')
insert into #uic_status (entity_name, status_selector)
   values('Shipment', 'shouldTrackChanges')
insert into #uic_status (entity_name, status_selector)
   values('Trade', 'isConcluded')
insert into #uic_status (entity_name, status_selector)
   values('TradeItem', 'tradeOrder.trade.isConcluded')
insert into #uic_status (entity_name, status_selector)
   values('Voucher', 'isPosted')
insert into #uic_status (entity_name, status_selector)
   values('TradeItemWetPhy', 'tradeItem.tradeOrder.trade.isConcluded')
go

insert into #uic_status (entity_name, status_selector)
select 'AiEstActualSpec', 'shouldTrackChanges' 
union all
select 'FormulaBodyTrigger', 'shouldTrackChanges' 
union all
select 'TradeItemSpec', 'shouldTrackChanges' 
union all
select 'FormulaComponent', 'shouldTrackChanges' 
go



/* ********************************************************************* */
/* The below is engine to add records into the uic_status table          */
/* ********************************************************************* */

declare @oid              numeric(18, 0),
        @entity_id        int,
        @status_selector  varchar(250),
        @entity_name      varchar(30),
        @smsg             varchar(255),
        @rows_affected    int,
        @errcode          int

select @errcode = 0

select @oid = min(oid)
from #uic_status

while @oid is not null
begin
   select @entity_name = entity_name,
          @status_selector = status_selector
   from #uic_status
   where oid = @oid
          
   select @entity_id = oid 
   from dbo.icts_entity_name
   where entity_name = @entity_name

   if @entity_id is not null
   begin
      if not exists (select 1
                     from dbo.uic_status
                     where entity_id = @entity_id)
      begin
         begin tran
         insert into dbo.uic_status 
              (entity_id, status_selector, trans_id)
             values(@entity_id, @status_selector, 1)
         select @rows_affected = @@rowcount,
                @errcode = @@error
         if @errcode > 0
         begin
            if @@trancount > 0
               rollback tran
            print '=> Failed to add a new uic_status record!'
            goto endofscript
         end
         commit tran
         --if @rows_affected > 0
         --   print '=> A new uic_status record was added!'            
      end
   end
   else
   begin   
      select @smsg = 'Could not find entity ''' + @entity_name + ''' in the icts_entity_name table!'
      print @smsg
   end

   select @oid = min(oid)
   from #uic_status
   where oid > @oid   
end
endofscript:
drop table #uic_status
go
