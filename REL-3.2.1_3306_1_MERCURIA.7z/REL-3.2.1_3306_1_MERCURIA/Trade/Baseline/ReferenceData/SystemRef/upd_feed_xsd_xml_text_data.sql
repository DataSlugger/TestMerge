set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Updating XML stream for the interface "NAVITA_DEAL_INTERFACE" ...'
go

if object_id('dbo.feed_xsd_xml_text_updtrg') is not null
   exec('alter table dbo.feed_xsd_xml_text disable trigger feed_xsd_xml_text_updtrg')
go

declare @oid            int,
        @rows_affected  int,
        @errcode        int
        
select @errcode = 0

select @oid = mapping_xml_id
from dbo.feed_definition
where feed_name like '%NAVITA_DEAL_INTERFACE%'

if @oid is not null
begin
   begin tran
   update dbo.feed_xsd_xml_text
   set doc_text = '<?xml version="1.0" encoding="UTF-8"?>
<SymphonyWSGatewayRefDataMapDocument>
	<WebService name="DealEntry" interfaceName="NAVITA_DEAL_INTERFACE">
		<qualifiedClassName>com.tradecapture.icts.webservices.dealentryws.control.common.DealEntryDisplayData</qualifiedClassName>
		<ExtMonitorFeedData xpath="/" displayName="">
			<ExtTable xpath="Contract/" displayName="">
				<ExtColumn displayName="Document ID"  editable="N"  path="DocumentHead/DocumentID"/>
				<ExtColumn displayName="Feed Source"  editable="N"  path="DocumentHead/SenderID"/>
				<ExtColumn displayName="Ext Contract #"  editable="N"  path="ContractData/ContractCode/InternalName"/>
				<ExtColumn displayName="Status"  editable="N"  path="ContractData/ContractStatus/InternalName"/>
				<ExtColumn displayName="Buy/Sell"  editable="N"  path="ContractData/ContractType/InternalName"/>
				<ExtColumn displayName="Contract Type"  editable="N"  path="ContractData/DealType"/>
				<ExtColumn displayName="Date Entered"  editable="N"  path="ContractData/DateEntered"/>
				<ExtColumn displayName="Traded Date"  editable="N"  path="ContractData/TradedDate"/>
				<ExtColumn displayName="End Date"  editable="N"  path="ContractData/EndDate"/>
				<ExtColumn displayName="Due Date"  editable="N"  path="ContractData/DueDate"/>
				<ExtColumn displayName="Cancel Date"  editable="N"  path="ContractData/CancelDate"/>
				<ExtColumn displayName="Booking Comp Num"  editable="N"  path="ContractData/OperatingCompany/PartyId"/>
				<ExtColumn displayName="Booking Period"  editable="N"  path="ContractData/OperatingCompany/FiscalPeriod"/>
				<ExtColumn displayName="Buyer"  editable="N"  path="ContractData/Buyer/PartyId"/>
				<ExtColumn displayName="Supplier"  editable="N"  path="ContractData/Supplier/PartyId"/>
				<ExtColumn displayName="Commodity"  editable="N"  path="ContractData/Commodity/InternalName"/>
				<ExtColumn displayName="Currency"  editable="N"  path="ContractData/CurrencyUnitRef/InternalName"/>
				<ExtColumn displayName="Uom"  editable="N"  path="ContractData/QtyTypeUnitRef/InternalName"/>
				<ExtColumn displayName="Price"  editable="N"  path="ContractData/UnitPrice"/>
				<ExtColumn displayName="Profit Center"  editable="N"  path="ContractData/ProfitCenter"/>
			</ExtTable>
		</ExtMonitorFeedData>
		<DataMappingElements source="POMAX">
			<DataMappingElement entityName="Commodity">
				<Key1>Contract/ContractData/Commodity/InternalName</Key1>
				<Key2/>
				<Key3/>
				<ErrorMessage>Unable to find commodity mapping for commodity #:</ErrorMessage>
			</DataMappingElement>
			<DataMappingElement entityName="Account">
				<Key1>Contract/ContractData/OperatingCompany/PartyId</Key1>
				<Key2/>
				<Key3/>
				<ErrorMessage>Unable to find mapping info for operating company #:</ErrorMessage>
				<EntityValidations key="Contract/ContractData/ContractType/InternalName">
					<Condition criteria="Buy" validationKey="=" validationValue="Contract/ContractData/Buyer/PartyId" message="Operating company and Buyer are not matching #:"/>
					<Condition criteria="Sell" validationKey="=" validationValue="Contract/ContractData/Supplier/PartyId" message="Operating company and Supplier are not matching #:"/>
				</EntityValidations>
			</DataMappingElement>
			<DataMappingElement entityName="Account">
				<Key1>Contract/ContractData/Buyer/PartyId</Key1>
				<Key2/>
				<Key3/>
				<ErrorMessage>Unable to find mapping info for buyer #:</ErrorMessage>
				<EntityValidations key="Contract/ContractData/ContractType/InternalName">
					<Condition criteria="Buy" validationKey="accountType.acctTypeCode" validationValue="PEICOMP" message="Invalid Mapping : Buyer is not mapped to a valid booking company. Please check the mapping for Account #:"/>
					<Condition criteria="Sell" validationKey="accountType.acctTypeCode" validationValue="CUSTOMER,PEICOMP" message="Invalid Mapping : Buyer is not mapped to a valid counterparty. Please check the mapping for Account #:"/>
				</EntityValidations>
			</DataMappingElement>
			<DataMappingElement entityName="Account">
				<Key1>Contract/ContractData/Supplier/PartyId</Key1>
				<Key2/>
				<Key3/>
				<ErrorMessage>Unable to find mapping info for supplier #:</ErrorMessage>
				<EntityValidations key="Contract/ContractData/ContractType/InternalName">
					<Condition criteria="Sell" validationKey="accountType.acctTypeCode" validationValue="PEICOMP" message="Invalid Mapping : Supplier is not mapped to a valid booking company. Please check the mapping for Account #:"/>
					<Condition criteria="Buy" validationKey="accountType.acctTypeCode" validationValue="CUSTOMER,PEICOMP" message="Invalid Mapping : Supplier is not mapped to a valid counterparty. Please check the mapping for Account #:"/>
				</EntityValidations>
			</DataMappingElement>
			<DataMappingElement entityName="Commodity">
				<Key1>Contract/ContractData/CurrencyUnitRef/InternalName</Key1>
				<Key2/>
				<Key3/>
				<ErrorMessage>Unable to find mapping info for currency unit #:</ErrorMessage>
			</DataMappingElement>
			<DataMappingElement entityName="Uom">
				<Key1>Contract/ContractData/QtyTypeUnitRef/InternalName</Key1>
				<Key2/>
				<Key3/>
				<ErrorMessage>Unable to find mapping info for quantity unit #:</ErrorMessage>
			</DataMappingElement>
		</DataMappingElements>
	</WebService>
</SymphonyWSGatewayRefDataMapDocument>'
   where oid = @oid
   select @rows_affected = @@rowcount,
          @errcode = @@error
   if @errcode > 0
   begin
      if @@trancount > 0
         rollback tran
   end
   else
   begin
      commit tran
      if @rows_affected > 0
         print '=> The XML stream ("NAVITA_DEAL_INTERFACE") was updated!'
   end
end

print ' '
print 'Updating XML stream for the interface "NAVITA_INVOICE_INTERFACE" ...'
go

declare @oid            int,
        @rows_affected  int,
        @errcode        int
        
select @errcode = 0

select @oid = mapping_xml_id
from dbo.feed_definition
where feed_name like '%NAVITA_INVOICE_INTERFACE%'

if @oid is not null
begin
   if not exists (select 1
                  from dbo.feed_xsd_xml_text
                  where doc_text like '%validationKey="accountType.acctTypeCode" validationValue="CUSTOMER,PEICOMP,BROKER,%')
   begin
      begin tran
      update dbo.feed_xsd_xml_text
      set doc_text = '<?xml version="1.0" encoding="UTF-8"?>
<SymphonyWSGatewayRefDataMapDocument>
	<WebService name="Invoice" interfaceName="NAVITA_INVOICE_INTERFACE">
		<qualifiedClassName>com.tradecapture.icts.webservices.invoicews.control.common.InvoiceDisplayData</qualifiedClassName>
		<ExtMonitorFeedData xpath="/" displayName="">
			<ExtTable xpath="Invoice/" displayName="">
				<ExtColumn displayName="Document ID"  editable="N"  path="DocumentHead/DocumentID"/>
				<ExtColumn displayName="Feed Source"  editable="N"  path="DocumentHead/SenderID"/>
				<ExtColumn displayName="Invoice #"  editable="N"  path="InvoiceHead/InvoiceNumber"/>
				<ExtColumn displayName="Direction"  editable="N"  path="InvoiceHead/Direction"/>
				<ExtColumn displayName="Type"  editable="N"  path="InvoiceHead/InvoiceType"/>
				<ExtColumn displayName="Invoice Date"  editable="N"  path="InvoiceHead/InvoiceDate"/>
				<ExtColumn displayName="Start Date"  editable="N"  path="InvoiceHead/StartDate"/>
				<ExtColumn displayName="End Date"  editable="N"  path="InvoiceHead/EndDate"/>
				<ExtColumn displayName="Supplier"  editable="N"  path="InvoiceHead/Supplier/PartyId"/>
				<ExtColumn displayName="Buyer"  editable="N"  path="InvoiceHead/Buyer/PartyId"/>
				<ExtColumn displayName="TaxTreatment"  editable="N"  path="InvoiceHead/TaxTreatment"/>
				<ExtColumn displayName="Invoice Gross Amount"  editable="N"  path="InvoiceSummary/InvoiceTotals/GrossAmount"/>
				<ExtColumn displayName="Invoice Net Amount"  editable="N"  path="InvoiceSummary/InvoiceTotals/NetAmount"/>
				<ExtTable xpath="InvoiceLines/">
					<ExtColumn displayName="LineItemNum"  editable="N"  path="LineItemNum"/>
					<ExtColumn displayName="Contract #"  editable="N"  path="Contract/ContractNumber"/>
					<ExtColumn displayName="Contract Code"  editable="N"  path="Contract/ContractCode"/>
					<ExtColumn displayName="Start Date"  editable="N"  path="StartDate"/>
					<ExtColumn displayName="End Date"  editable="N"  path="EndDate"/>
					<ExtColumn displayName="Quantity Invoiced"  editable="N"  path="QuantityInvoiced"/>
					<ExtColumn displayName="Quantity Unit"  editable="N"  path="QuantityUnit"/>
					<ExtColumn displayName="Price"  editable="N"  path="Price"/>
					<ExtColumn displayName="PriceCurrCode"  editable="N"  path="PriceUnit/Currency"/>
					<ExtColumn displayName="PriceUomCode"  editable="N"  path="PriceUnit/QuantityUnit"/>
					<ExtColumn displayName="Line Item Amount"  editable="N"  path="LineItemAmount"/>
					<ExtColumn displayName="Vat Amount"  editable="N"  path="VatInfo/VatAmount"/>
				</ExtTable>
			</ExtTable>
		</ExtMonitorFeedData>
		<DataMappingElements source="POMAX">
			<DataMappingElement entityName="Account">
				<Key1>Invoice/InvoiceHead/Buyer/PartyId</Key1>
				<Key2/>
				<Key3/>
				<ErrorMessage>Unable to find mapping info for buyer #:</ErrorMessage>
				<EntityValidations key="Invoice/InvoiceHead/Direction">
					<Condition criteria="Incoming" validationKey="accountType.acctTypeCode" validationValue="PEICOMP" message="Invalid Mapping : Buyer is not mapped to a valid booking company. Please check the mapping for Account #:"/>
					<Condition criteria="Outgoing" validationKey="accountType.acctTypeCode" validationValue="CUSTOMER,PEICOMP,BROKER,EXCHBRKR,NOTRADE,PEBANK,SRVENDOR,TAXAUTH,WAREHSRE" message="Invalid Mapping : Buyer is not mapped to a valid Account type(CUSTOMER,PEICOMP,BROKER,EXCHBRKR,NOTRADE,PEBANK,SRVENDOR,TAXAUTH,WAREHSRE) . Please check the mapping for Account #:"/>
				</EntityValidations>
			</DataMappingElement>
			<DataMappingElement entityName="Account">
				<Key1>Invoice/InvoiceHead/Supplier/PartyId</Key1>
				<Key2/>
				<Key3/>
				<ErrorMessage>Unable to find mapping info for supplier #:</ErrorMessage>
				<EntityValidations key="Invoice/InvoiceHead/Direction">
					<Condition criteria="Outgoing" validationKey="accountType.acctTypeCode" validationValue="PEICOMP" message="Invalid Mapping : Supplier is not mapped to a valid booking company. Please check the mapping for Account #:"/>
					<Condition criteria="Incoming" validationKey="accountType.acctTypeCode" validationValue="CUSTOMER,PEICOMP,BROKER,EXCHBRKR,NOTRADE,PEBANK,SRVENDOR,TAXAUTH,WAREHSRE" message="Invalid Mapping : Supplier is not mapped to a valid Account type(CUSTOMER,PEICOMP,BROKER,EXCHBRKR,NOTRADE,PEBANK,SRVENDOR,TAXAUTH,WAREHSRE). Please check the mapping for Account #:"/>
				</EntityValidations>
			</DataMappingElement>
		</DataMappingElements>
	</WebService>
</SymphonyWSGatewayRefDataMapDocument>'
      where oid = @oid
      select @rows_affected = @@rowcount,
             @errcode = @@error
      if @errcode > 0
      begin
         if @@trancount > 0
            rollback tran
      end
      else
      begin
         commit tran
         if @rows_affected > 0
            print '=> The XML stream ("NAVITA_INVOICE_INTERFACE") was updated!'
      end
   end
end
go

if object_id('dbo.feed_xsd_xml_text_updtrg') is not null
   exec('alter table dbo.feed_xsd_xml_text enable trigger feed_xsd_xml_text_updtrg')
go
