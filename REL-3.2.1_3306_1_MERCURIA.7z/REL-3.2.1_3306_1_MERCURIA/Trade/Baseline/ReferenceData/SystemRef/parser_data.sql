set nocount on

create table #temp
(
   oid                   int IDENTITY primary key,
   delimiter             varchar(10) NULL,
   lines_per_record      int NULL,
   name                  varchar(100) NOT NULL,
   parser_type_name      varchar(50) NULL
)
go

insert into #temp
     (delimiter, lines_per_record, name, parser_type_name)
   values(',', 1, 'Nymex Future', 'Market Data'),
         (',', 1, 'ICE Cleared', 'Market Data')
go



/* ************************************************************** */

declare @last_id           int,
        @trans_id          int,
        @rows_affected     int,
        @errcode           int,
        @smsg              varchar(max)

set @trans_id = 1
begin tran
select @last_id = isnull(max(id), 0)
from dbo.parser

begin try
   insert into dbo.parser
   	 (id, delimiter, lines_per_record, name, parser_type_name, trans_id)
   select 
      @last_id + oid,
      delimiter,
      lines_per_record,
      name,
      parser_type_name,
      @trans_id
   from #temp t
   where not exists (select 1 
                     from dbo.parser 
                     where delimiter = t.delimiter and 
                           lines_per_record = t.lines_per_record and 
                           name = t.name and 
                           parser_type_name = t.parser_type_name)
   set @rows_affected = @@rowcount   
end try
begin catch
  set @errcode = ERROR_NUMBER()
  set @smsg = ERROR_MESSAGE()
  if @@trancount > 0
     rollback tran
  RAISERROR('=> Failed to load data into the parser table due to the error:', 0, 1) with nowait
  RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
  goto endofscript
end catch 
commit tran
RAISERROR('%d records were loaded into the parser table!', 0, 1, @rows_affected) with nowait

endofscript:
drop table #temp
go

exec dbo.refresh_a_last_num 'parser', 'id'
go


