set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table order_type_group
go

print 'Loading system reference data into the order_type_group table ...'
go

insert into order_type_group values('OPTION', 'OTCAPO', 1)
go

insert into order_type_group values('OPTION', 'OTCCASH', 1)
go

insert into order_type_group values('OPTION', 'OTCPHYS', 1)
go

insert into order_type_group values('PHYSICAL', 'EFPEXCH', 1)
go

insert into order_type_group values('PHYSICAL', 'PARTIAL', 1)
go

insert into order_type_group values('PHYSICAL', 'PHYSBYSL', 1)
go

insert into order_type_group values('PHYSICAL', 'PHYSEXCH', 1)
go

insert into order_type_group values('PHYSICAL', 'PHYSICAL', 1)
go

insert into order_type_group values('PHYSICAL', 'RACKBYSL', 1)
go

insert into order_type_group values('PHYSICAL', 'RACKEXCH', 1)
go

insert into order_type_group values('PHYSICAL', 'RACKPHYS', 1)
go

insert into order_type_group values('STORAGE', 'STORAGE', 1)
go

insert into order_type_group values('SWAP', 'SWAP', 1)
go

insert into order_type_group values('SWAP', 'SWAPFLT', 1)
go

insert into order_type_group values('TRANSP', 'BARGE', 1)
go

insert into order_type_group values('TRANSP', 'PIPELINE', 1)
go

insert into order_type_group values('TRANSP', 'RAILCAR', 1)
go

insert into order_type_group values('TRANSP', 'TRANSPRT', 1)
go

insert into order_type_group values('TRANSP', 'TRUCK', 1)
go

insert into order_type_group values('TRANSP', 'VLCC', 1)
go

/* Added for Rack functionality for Mercuria */
if not exists (select 1
               from dbo.order_type_group 
               where order_type_group = 'PHYSICAL' and               
                     order_type_code = 'PHYSB2BC')                     
   insert into order_type_group 
        (order_type_group, order_type_code, trans_id)
      values('PHYSICAL', 'PHYSB2BC', 1)
go

