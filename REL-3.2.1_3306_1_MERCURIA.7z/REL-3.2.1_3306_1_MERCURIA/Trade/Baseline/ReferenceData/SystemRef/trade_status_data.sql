set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table trade_status
go

print 'Loading system reference data into the trade_status table ...'
go

insert into dbo.trade_status 
   values('A', 'Active', 1)
go

insert into dbo.trade_status 
   values('DELETE', 'TRADE DELETED', 1)
go

insert into dbo.trade_status 
   values('UNALLOC', 'UNALLOCATED', 1)
go

insert into dbo.trade_status 
   values ('CONFIRM', 'CONFIRMED', 1)
go

insert into dbo.trade_status 
   values ('FUTV', 'FUTV', 1)
go

insert into dbo.trade_status 
   values ('FUTNV', 'FUTNV', 1)
go
