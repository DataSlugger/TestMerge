set nocount on

print ''
print 'Adding a new feed name ''BTT_NOMINATION_ACK'' into feed_definition table and'
print 'its corresponding entry into feed_xsd_xml_text table IF NOT EXIST ... '
print ''
go

if not exists (select 1 from dbo.feed_definition 
               where feed_name = 'BTT_NOMINATION_ACK')
begin
declare @oid                 int,
        @request_xsd_id      int,
        @response_xsd_id     int,
        @mapping_xml_id      int,
        @transId             int,
        @newoid              int,
        @doc_text            nvarchar(max),
        @rows_affected       int

select @request_xsd_id = NULL,
       @response_xsd_id = NULL,
       @mapping_xml_id = NULL

   select @transId = 1
   select @rows_affected = 0

   select @newoid = isnull(max(oid), 0) + 1
   from dbo.feed_definition_xsd_xml

   begin tran
   begin try
     insert into dbo.feed_definition_xsd_xml(oid,trans_id, doc_text)
       values(@newoid, @transId, '<xs:schema
        attributeFormDefault = "unqualified"
        elementFormDefault = "qualified"
        targetNamespace = "http://www.amphorainc.com/Symphony/ActualsGateWay/bttqino/nominationack"
        xmlns:xs = "http://www.w3.org/2001/XMLSchema">
        <xs:element name = "NominationAck">
                <xs:complexType>
                        <xs:sequence>
                                <xs:element name = "DocumentHead">
                                        <xs:complexType>
                                                <xs:sequence>
                                                        <xs:element name = "FeedName" type = "xs:string"/>
                                                        <xs:element name = "SenderID" type = "xs:string"/>
                                                        <xs:element name = "ReceiverID" type = "xs:string"/>
                                                        <xs:element name = "TransmittalType" type = "xs:string"/>
                                                        <xs:element name = "ReferenceID" type = "xs:string"/>
                                                        <xs:element name = "QinoFeedID" type = "xs:unsignedInt"/>
                                                        <xs:element name = "SymphonyFeedID" type = "xs:unsignedInt"/>
                                                </xs:sequence>
                                        </xs:complexType>
                                </xs:element>
                                <xs:element name = "NominationAckDetails">
                                        <xs:complexType>
                                                <xs:sequence>
                                                        <xs:element maxOccurs = "unbounded" name = "NominationAckLineItem">
                                                                <xs:complexType>
                                                                        <xs:sequence>
                                                                                <xs:element name = "LineItemNumber" type = "xs:unsignedByte"/>
                                                                                <xs:element name = "ParcelNumber" type = "xs:unsignedInt"/>
                                                                                <xs:element name = "StatusData">
                                                                                        <xs:complexType>
                                                                                                <xs:sequence>
                                                                                                        <xs:element name = "Status" type = "xs:string"/>
                                                                                                        <xs:element name = "FailDescription" type = "xs:string"/>
                                                                                                </xs:sequence>
                                                                                        </xs:complexType>
                                                                                </xs:element>
                                                                        </xs:sequence>
                                                                </xs:complexType>
                                                        </xs:element>
                                                </xs:sequence>
                                        </xs:complexType>
                                </xs:element>
                                <xs:element name = "NominationAckSummary">
                                        <xs:complexType>
                                                <xs:sequence>
                                                        <xs:element name = "TotalLineItems" type = "xs:unsignedByte"/>
                                                </xs:sequence>
                                        </xs:complexType>
                                </xs:element>
                        </xs:sequence>
                </xs:complexType>
        </xs:element>
</xs:schema>')
     select @rows_affected = @@rowcount
   end try
   begin catch
     if @@trancount > 0
	      rollback tran
     print '=> Failed to insert new xml into feed_xsd_xml_text table due to below error:'
     print '==> ERROR: ' + ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
   begin
       print '=> Added a new xml into feed_xsd_xml_text successfully!'
       select @request_xsd_id = @newoid    	
   end

   select @newoid = isnull(max(oid), 0) + 1
   from dbo.feed_definition

   begin tran
   begin try
     insert into dbo.feed_definition
           (oid, feed_name, request_xsd_id, response_xsd_id, mapping_xml_id, active_ind, trans_id, display_name, interface)
        values (@newoid, 'BTT_NOMINATION_ACK', @request_xsd_id, @response_xsd_id, @mapping_xml_id, 1, @transId, 'Nomination Ack', 'BTT')
     select @rows_affected = @@rowcount
   end try
   begin catch
     if @@trancount > 0
        rollback tran
     print '=> Failed to add a feed_definition record for BTT_NOMINATION_ACK due to below error:'
     print '==> ERROR: ' + ERROR_MESSAGE()
     goto endofscript 
   end catch
   commit tran
   if @rows_affected > 0
      print '=> A new feed_definition record was added for BTT_NOMINATION_ACK successfully!'
end
else
   print '=> The feed BTT_NOMINATION_ACK has already existed in the ''feed_definition'' table!'

endofscript:
go

print ' '
go
exec dbo.refresh_a_last_num 'feed_definition_xsd_xml', 'oid'
go
exec dbo.refresh_a_last_num 'feed_definition', 'oid'
go
