set nocount on

print ''
print 'Adding a new feed name ''EConfirmTradeQueryInterface'' into feed_definition table and'
print 'its corresponding entries into feed_definition_xsd_xml table IF NOT EXIST ... '
print ''
go

if not exists (select 1 from dbo.feed_definition 
               where feed_name = 'EConfirmTradeQueryInterface')
begin
declare @oid                 int,
        @request_xsd_id      int,
        @response_xsd_id     int,
        @mapping_xml_id      int,
        @transId            int,
        @newoid              int,
        @doc_text            nvarchar(max),
        @rows_affected       int

   select @transId = 1
   select @rows_affected = 0

   select @newoid = isnull(max(oid), 0) + 1
   from dbo.feed_definition_xsd_xml

   begin tran
   begin try
     insert into dbo.feed_definition_xsd_xml(oid,doc_text,trans_id)
        values(@newoid,'<?xml version="1.0" encoding="utf-8"?>
<xs:schema xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" attributeFormDefault="unqualified" elementFormDefault="qualified" xmlns:xs="http://www.w3.org/2001/XMLSchema">
  <xs:element name="EConfirmQueryRequest">
    <xs:complexType>
      <xs:sequence>
        <xs:element name="Ids">
          <xs:complexType>
            <xs:sequence>
              <xs:element name="SenderTradeRefId" type="xs:string" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>', @transId )
     select @rows_affected = @@rowcount
   end try
   begin catch
     if @@trancount > 0
	      rollback tran
     print '=> Failed to insert ''XML string for request_xsd_id'' into feed_definition_xsd_xml table due to below error:'
     print '==> ERROR: ' + ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
   begin
      print '=> XML string for request_xsd_id has been inserted into feed_definition_xsd_xml successfully!'
      select @request_xsd_id = @newoid	
   end

   select @rows_affected = 0

  select @newoid = isnull(max(oid), 0) + 1
  from dbo.feed_definition_xsd_xml

  begin tran
  begin try
    insert into dbo.feed_definition_xsd_xml(oid,doc_text,trans_id)
        values(@newoid,'<?xml version="1.0" encoding="utf-8"?>
<xs:schema xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" attributeFormDefault="unqualified" elementFormDefault="qualified" xmlns:xs="http://www.w3.org/2001/XMLSchema">
  <xs:element name="EConfirmQueryResponse">
    <xs:complexType>
      <xs:sequence>
        <xs:element name="EConfirmTradeInfo">
          <xs:complexType>
            <xs:sequence>
              <xs:element maxOccurs="unbounded" name="EConfirmSimpleResponse">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name="SenderTradeRefId" type="xs:string" />
                    <xs:element name="ClientVersionId" type="xs:unsignedByte" />
                    <xs:element name="TraceId" type="xs:unsignedShort" />
                    <xs:element name="Status" type="xs:string" />
                    <xs:element name="Buyer" type="xs:string" />
                    <xs:element name="Seller" type="xs:string" />
                    <xs:element name="SubmissionCompany" type="xs:string" />
                    <xs:element name="StatusDate" type="xs:date" />
                    <xs:element name="TradeDate" type="xs:date" />
                    <xs:element name="CounterPartyInfo">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element name="Trade">
                            <xs:complexType>
                              <xs:sequence>
                                <xs:element name="CounterParty" type="xs:string" />
                                <xs:element name="SenderTradeRefId" type="xs:string" />
                                <xs:element name="Status" type="xs:string" />
                              </xs:sequence>
                            </xs:complexType>
                          </xs:element>
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name="EConfirmMessageLogInfo">
          <xs:complexType>
            <xs:sequence>
              <xs:element maxOccurs="unbounded" name="EConfirmSimpleResponse">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name="SenderTradeRefId" type="xs:string" />
                    <xs:element minOccurs="0" name="ClientVersionId" type="xs:unsignedByte" />
                    <xs:element name="TraceId" type="xs:unsignedShort" />
                    <xs:element name="Message">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element name="Code" type="xs:unsignedShort" />
                          <xs:element name="Type" type="xs:string" />
                          <xs:element name="Description" type="xs:string" />
                          <xs:element name="StatusDate" type="xs:string" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>', @transId)
     select @rows_affected = @@rowcount
   end try
   begin catch
     if @@trancount > 0
	      rollback tran
     print '=> Failed to insert ''XML string for response_xsd_id'' into feed_definition_xsd_xml table due to below error:'
     print '==> ERROR: ' + ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
   begin
      print '=> XML string for response_xsd_id has been inserted into feed_definition_xsd_xml successfully!'
      select @response_xsd_id = @newoid
   end
    
   select @rows_affected = 0

   select @newoid = isnull(max(oid), 0) + 1
   from dbo.feed_definition_xsd_xml

   begin tran
   begin try
     insert into dbo.feed_definition_xsd_xml(oid,doc_text,trans_id)
         values(@newoid,'EConfirm_TradeQuery_Interface_Map', @transId )
     select @rows_affected = @@rowcount
   end try
   begin catch
     if @@trancount > 0
	      rollback tran
     print '=> Failed to insert '' string for @mapping_xml_id '' into feed_definition_xsd_xml table due to below error'
     print '==> ERROR: ' + ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
   begin
      print '=> string for @mapping_xml_id has been inserted into feed_definition_xsd_xml successfully!'
      select @mapping_xml_id = @newoid
   end

   select @rows_affected = 0

   select @newoid = isnull(max(oid), 0) + 1
   from dbo.feed_definition

   begin tran
   begin try
     insert into dbo.feed_definition
         (oid, feed_name, request_xsd_id, response_xsd_id, mapping_xml_id, 
          active_ind, trans_id,display_name,interface)
       values (@newoid, 'EConfirmTradeQueryInterface', @request_xsd_id, @response_xsd_id, 
               @mapping_xml_id, 1, @transId,'EConfirm Trade Query','EConfirm')
     select @rows_affected = @@rowcount
   end try
   begin catch
     if @@trancount > 0
        rollback tran
     print '=> Failed to add a feed_definition record for EConfirmTradeQueryInterface due to the error:'
     print '==> ERROR: ' + ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
      print '=> A new feed_definition record was added for EConfirmTradeQueryInterface!'

end
else
   print 'The new feed EConfirmTradeQueryInterface already exist in feed_definition table!'

endofscript:
go

print ' '
go
exec dbo.refresh_a_last_num 'feed_definition_xsd_xml', 'oid'
go
exec dbo.refresh_a_last_num 'feed_definition', 'oid'
go