set nocount on

print ' '
print 'Adding new feed_name ''CKIDealsOutbound'' into the feed_definition table IF NOT EXISTS ...'
go

if exists (select 1 
           from dbo.feed_definition 
           where feed_name = 'CKIDealsOutbound')
begin
   print '=> The feed name ''CKIDealsOutbound'' in feed_definition table already exists...!'
   goto endofscript
end

declare	@trans_id		                int,
		    @rows_affected		          int,
		    @errcode                    int,
		    @smsg                       varchar(max),
		    @feed_definition_xsd_xml_id int, 
		    @feed_definition_id	        int

	 exec dbo.gen_new_transaction_NOI @app_name = 'DbIssue_ADSO-7377'
	 select @trans_id = null
	 select @trans_id = last_num   
   from dbo.icts_trans_sequence   
	 where oid = 1

   select @feed_definition_id = isnull(max(oid), 0) + 1
   from dbo.feed_definition

   select @feed_definition_xsd_xml_id = isnull(max(oid), 0) + 1
   from dbo.feed_definition_xsd_xml		
		
		
	 begin tran
   begin try
     insert into dbo.feed_definition_xsd_xml(oid,doc_text,trans_id)
			values(@feed_definition_xsd_xml_id,
					'<?xml version="1.0" encoding="utf-8"?>
						<xs:schema attributeFormDefault="unqualified" elementFormDefault="qualified" xmlns:xs="http://www.w3.org/2001/XMLSchema">
						  <xs:element name="DATA">
							<xs:complexType>
							  <xs:sequence>
								<xs:element maxOccurs="unbounded" name="Parcel">
								  <xs:complexType>
									<xs:sequence>
									  <xs:element name="mode" type="xs:string"/>     <!-- Char(1) -->
									  <xs:element name="fdd_id" type="xs:string"/>     <!-- Char(20) Symphony side staging table unique record id-->
									  <xs:element name="buy_or_sell" type="xs:string" />  <!-- Char(1) -->
									  <xs:element name="company" type="xs:string" />  <!-- Char(30) -->
									  <xs:element name="delivery_term" type="xs:string" /> <!-- Char(8) -->
									  <xs:element name="counterparty" type="xs:string" /> <!-- Char(30) -->
									  <xs:element name="trade_num" type="xs:int" /> <!-- Integer --> 
									  <xs:element name="order_num" type="xs:int" />  <!-- Integer --> 
									  <xs:element name="item_num" type="xs:int" /> <!-- Integer --> 
									  <xs:element name="document_number" type="xs:int" /> <!-- Integer --> 
									  <xs:element name="bussiness_unit" type="xs:string" /> <!-- Char(15) -->
									  <xs:element name="order_date" type="xs:string" /> <!-- Date as string in format YYYYMMDD -->
									  <xs:element name="delivery_date" type="xs:string" /> <!-- Date as string in format YYYYMMDD -->
									  <xs:element name="volume" type="xs:decimal" /> <!-- float value up to 4 decimals -->
									  <xs:element name="uom" type="xs:string" /> <!-- Char(4) -->
									  <xs:element name="item_number" type="xs:string" /> <!-- Char(8) -->
									  <xs:element name="price" type="xs:decimal" /> <!-- float value up to 4 decimals -->
									  <xs:element name="price_uom" type="xs:string" /> <!-- Char(4) -->
									  <xs:element name="payment_term" type="xs:string" /> <!-- Char(40) -->
									  <xs:element name="currency" type="xs:string" />  <!-- Char(8) -->        
									</xs:sequence>
								  </xs:complexType>
								</xs:element>
							  </xs:sequence>
							</xs:complexType>
						  </xs:element>
						</xs:schema>',
					@trans_id)
			set @rows_affected = @@rowcount
   end try
   begin catch
   	 set @errcode = ERROR_NUMBER()
   	 set @smsg = ERROR_MESSAGE()
		 if @@trancount > 0
			  rollback tran
     RAISERROR('=> Failed to add a new feed_definition_xsd_xml record due to below error:', 0, 1) with nowait
		 RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
     goto endofscript
   end catch
	 commit tran
	 if @rows_affected > 0
		  RAISERROR('=> A new feed_definition_xsd_xml record was added successfully!', 0, 1) with nowait
	
	 set @rows_affected = 0;
   begin tran
   begin try
     insert into dbo.feed_definition
          (oid, feed_name, request_xsd_id, response_xsd_id, mapping_xml_id, 
           active_ind, trans_id, display_name, interface)
			values(@feed_definition_id, 'CKIDealsOutbound', @feed_definition_xsd_xml_id, @feed_definition_xsd_xml_id, null, 1, @trans_id, 'CKIDealsOutbound', 'CKI') 
     set @rows_affected = @@rowcount
   end try
   begin catch
   	 set @errcode = ERROR_NUMBER()
   	 set @smsg = ERROR_MESSAGE()
		 if @@trancount > 0
			  rollback tran
     RAISERROR('=> Failed to add new feed name into feed_definition table due to below error:', 0, 1) with nowait
		 RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
     goto endofscript
   end catch
	 commit tran
	 if @rows_affected > 0
		  RAISERROR('=> The feed_definition record with the feed_name ''CKIDealsOutbound'' was added successfully!', 0, 1) with nowait

endofscript:
print ' '
exec dbo.refresh_a_last_num 'feed_definition_xsd_xml', 'oid'
exec dbo.refresh_a_last_num 'feed_definition', 'oid'
go

