set nocount on

print ''
print 'Adding a new feed name ''TICKET_UPLOAD_INTERFACE'' into feed_definition table '
print ''
go

if not exists ( select 1 from dbo.feed_definition 
                         where feed_name = 'TICKET_UPLOAD_INTERFACE' )
begin

declare @oid                 int,
        @request_xsd_id      int,
        @response_xsd_id     int,
        @mapping_xml_id      int,
        @transId             int,
        @newoid              int,
        @doc_text            nvarchar(max),
	@errcode	     int,
        @rows_affected       int

select @request_xsd_id = NULL,
       @response_xsd_id = NULL,
       @mapping_xml_id = NULL

select @rows_affected = 0

/* Begin - new trans_id script */
        
	begin tran
	begin try
	       exec dbo.gen_new_transaction_NOI @app_name = 'DBscript_1371607'
	end try
        begin catch
        if @@trancount > 0
             rollback tran
             print '=> Error occurred while executing the ''gen_new_transaction_NOI'' stored procedure!'    
	     print '==> ERROR: ' + ERROR_MESSAGE()
	     select @errcode = ERROR_NUMBER()
	     goto endofscript
	end catch
        commit tran

        select @transId = null
 
        select @transId = last_num 
        from dbo.icts_trans_sequence 
        where oid = 1

        if @transId is null
        begin
	      print '=> Failed to obtain a new trans_id for insert!'
	      goto endofscript
        end

/* End - new trans_id script */


select @newoid = isnull(max(oid), 0) + 1
from dbo.feed_definition

begin tran
begin try
  insert into dbo.feed_definition
  (oid, feed_name, request_xsd_id, response_xsd_id, mapping_xml_id, active_ind, trans_id, display_name, interface)
   values (@newoid, 'TICKET_UPLOAD_INTERFACE', @request_xsd_id, @response_xsd_id, @mapping_xml_id, 1, @transId, 'Ticket Upload Interface', 'Ticket')
   select @rows_affected = @@rowcount
end try
begin catch
  if @@trancount > 0
      rollback tran
  print '=> Failed to add a feed_definition record for TICKET_UPLOAD_INTERFACE due to below error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  select @errcode = ERROR_NUMBER()
  goto endofscript 
end catch
commit tran
if @rows_affected > 0
   print '=> A new feed_definition record was added for TICKET_UPLOAD_INTERFACE successfully!'
endofscript:
print ' '
exec dbo.refresh_a_last_num 'feed_definition_xsd_xml', 'oid'
exec dbo.refresh_a_last_num 'feed_definition', 'oid'
end
else
   print '=> The new feed TICKET_UPLOAD_INTERFACE already exist in feed_definition table !'
go