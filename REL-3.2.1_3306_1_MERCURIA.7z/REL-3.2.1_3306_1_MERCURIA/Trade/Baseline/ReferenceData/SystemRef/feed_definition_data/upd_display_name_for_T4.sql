set nocount on

print 'Updating the value of the ''display_name'' column in the ''feed_definition'' table IF NOT CORRECT ... '
print ' '

create table #fdt
(
   feed_name varchar(50),
   display_name varchar(64)
)
go

insert #fdt(feed_name,display_name)
select 'T4_NOMINATION_CREATE_INTERFACE', 'Nomination Create'
union all
select 'T4_NOMINATION_CHANGE_INTERFACE', 'Nomination Change'
union all
select 'T4_PIPELINE_SCHEDULE_INTERFACE', 'Schedule'
union all
select 'T4_CUSTODY_TICKET_INTERFACE', 'Custody Ticket'
go

declare @rows_affected	int,
	       @transId		    int

if exists(select 1 
          from dbo.feed_definition fd 
                  INNER JOIN #fdt fdtemp
                     on fd.feed_name = fdtemp.feed_name and 
                        fd.display_name <> fdtemp.display_name) 
begin        
   begin tran
   begin try
       exec dbo.gen_new_transaction_NOI @app_name = 'DbIssue_1362390'
   end try
   begin catch
     if @@trancount > 0
        rollback tran
     print '=> Failed to execute the ''gen_new_transaction_NOI'' stored procedure due to the error:'    
     print '==> ERROR: ' + ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran

   select @transId = null
   select @transId = last_num 
   from dbo.icts_trans_sequence 
   where oid = 1

   if @transId is null
   begin
      print '=> Failed to obtain the new trans_id for newly created icts_transaction record!'
      goto endofscript
   end

   begin tran
   begin try
	   update  fd 
     set fd.display_name = fdtemp.display_name,
	       fd.trans_id = @transId 
	   from dbo.feed_definition fd 
	           INNER JOIN #fdt fdtemp
                on fd.feed_name = fdtemp.feed_name and 
                   fd.display_name<>fdtemp.display_name
     select @rows_affected = @@rowcount
   end try
   begin catch
     if @@trancount > 0
        rollback tran
     print '=> Failed to update the feed_definition records for T4 feed_names due to the error:'
     print '==> ERROR: ' + ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
      print '=> ' + cast(@rows_affected as varchar) + ' feed_definition records were updated successfully '
   end
   else
      print '=> No feed_definition record(s) were updated ' 

endofscript:
go

if object_id('tempdb..#fdt', 'U') is not null
   exec('drop table #fdt')
go

