set nocount on

print ' '
print 'Adding new entry into feed_definition_xsd_xml and feed_definition table IF NOT EXISTS ...'
go

if exists ( select 1 from dbo.feed_definition where feed_name = 'CKISettlementsOutbound' )
begin
     print '=> The feed ''CKISettlementsOutbound'' in feed_definition table already exists...!'
     goto endofscript
end

declare	@transId		     int,
		@rows_affected		 int,
		@feed_definition_xsd_xml_id int, 
		@feed_definition_id	     int

		exec dbo.gen_new_transaction_NOI @app_name = 'DbIssue_ADSO-7412'
		select @transId = null
		select @transId = last_num   from dbo.icts_trans_sequence   where oid = 1

		exec dbo.get_new_num_NOI @key_name = 'feed_definition_xsd_xml_oid'
		select @feed_definition_xsd_xml_id = last_num from dbo.new_num where owner_table = 'feed_definition_xsd_xml'

		exec dbo.get_new_num_NOI @key_name = 'feed_definition_oid'
		select @feed_definition_id = last_num from dbo.new_num where owner_table = 'feed_definition'
		
		
	begin tran
		begin try
			insert into dbo.feed_definition_xsd_xml(oid,doc_text,trans_id)
			values(@feed_definition_xsd_xml_id,
					'<?xml version="1.0" encoding="utf-8"?>
					<xs:schema attributeFormDefault="unqualified" elementFormDefault="qualified" xmlns:xs="http://www.w3.org/2001/XMLSchema">
					<xs:element name="DATA">
					<xs:complexType>
					<xs:sequence>
					<xs:element maxOccurs="unbounded" name="Voucher">
					<xs:complexType>
					<xs:sequence>
					<xs:element name="doc_type" type="xs:string"/>     <!-- Char(8) -->
					<xs:element name="fdd_id" type="xs:string"/>  <!-- Char(20) Symphony side staging table unique record id-->
					<xs:element name="doc_number" type="xs:int" />  <!-- Integer -->
					<xs:element name="payee" type="xs:string" />  <!-- Char(30) -->
					<xs:element name="company_code" type="xs:string" /> <!-- Char(30) -->
					<xs:element name="pay_or_receive" type="xs:string" /> <!-- Char(1) -->
					<xs:element name="physical_or_financial" type="xs:string" /> <!-- Char(1) --> 
					<xs:element name="invoice_date" type="xs:string" />  <!-- Date as string in format YYYYMMDD --> 
					<xs:element name="payment_term" type="xs:string" /> <!-- Char(8) --> 
					<xs:element name="payment_date" type="xs:string" /> <!-- Date as string in format YYYYMMDD --> 
					<xs:element name="payment_reference" type="xs:string" /> <!-- Char(15) -->
					<xs:element name="gl_date" type="xs:string" /> <!-- Date as string in format YYYYMMDD -->
					<xs:element name="voucher_amt" type="xs:decimal" /> <!-- float value up to 4 decimals  -->
					<xs:element name="currency" type="xs:string" /> <!-- Char(8) -->
					<xs:element name="bussiness_unit" type="xs:string" /> <!-- Char(15) -->
					<xs:element name="tax_code" type="xs:string" /> <!-- Char(8) -->     
					</xs:sequence>
					</xs:complexType>
					</xs:element>
					</xs:sequence>
					</xs:complexType>
					</xs:element>
					</xs:schema>',
					@transId)
			select @rows_affected = @@rowcount
		end try
		begin catch
			 if @@trancount > 0
				 rollback tran
			 print '=> Failed to insert new feed into feed_definition_xsd_xml table due to below error '
			 print ERROR_MESSAGE()
			 goto endofscript
		end catch
	commit tran
	if @rows_affected > 0
		 print '=> Added '+convert(varchar,@rows_affected)+' new entry(s) into feed_definition_xsd_xml table successfully !'
	
	select @rows_affected=0;
	begin tran
		begin try
			insert into dbo.feed_definition(oid,feed_name,request_xsd_id,response_xsd_id,mapping_xml_id,active_ind,trans_id,display_name,interface)
			values(@feed_definition_id, 'CKISettlementsOutbound', @feed_definition_xsd_xml_id, @feed_definition_xsd_xml_id, null, 1, @transId, 'CKISettlementsOutbound', 'CKI') 
			select @rows_affected = @@rowcount
		end try
		begin catch
			 if @@trancount > 0
				 rollback tran
			 print '=> Failed to insert new feed into feed_definition table due to below error '
			 print ERROR_MESSAGE()
			 goto endofscript
		end catch
	commit tran
	if @rows_affected > 0
		 print '=> Added '+convert(varchar,@rows_affected)+' new entry(s) into feed_definition table successfully !'
endofscript:
go
