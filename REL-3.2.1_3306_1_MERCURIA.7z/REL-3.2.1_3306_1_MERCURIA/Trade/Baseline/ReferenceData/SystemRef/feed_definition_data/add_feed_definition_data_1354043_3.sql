set nocount on

print ''
print 'Adding a new feed name ''BTT_ORDER_TICKET'' into feed_definition table and'
print 'its corresponding entry into feed_xsd_xml_text table IF NOT EXIST ... '
print ''
go

if not exists (select 1 from dbo.feed_definition 
               where feed_name = 'BTT_ORDER_TICKET')
begin

declare @oid                 int,
        @request_xsd_id      int,
        @response_xsd_id     int,
        @mapping_xml_id      int,
        @transId             int,
        @newoid              int,
        @doc_text            nvarchar(max),
        @rows_affected       int

select @request_xsd_id = NULL,
       @response_xsd_id = NULL,
       @mapping_xml_id = NULL

   select @transId = 1
   select @rows_affected = 0

   select @newoid = isnull(max(oid), 0) + 1
   from dbo.feed_definition_xsd_xml

   begin tran
   begin try
     insert into dbo.feed_definition_xsd_xml(oid,trans_id,doc_text)
         values(@newoid, @transId, '<xs:schema attributeFormDefault="unqualified" elementFormDefault="qualified" targetNamespace="http://www.amphorainc.com/Symphony/ActualsGateWay/bttqino/OrderTicket" xmlns:xs="http://www.w3.org/2001/XMLSchema">
  <xs:element name="OrderTicket">
    <xs:complexType>
      <xs:sequence>
        <xs:element name="DocumentHead">
          <xs:complexType>
            <xs:sequence>
              <xs:element name="FeedName" type="xs:string" />
              <xs:element name="SenderID" type="xs:string" />
              <xs:element name="ReceiverID" type="xs:string" />
              <xs:element name="TransmittalType" type="xs:string" />
              <xs:element name="ReferenceID" type="xs:string" />
              <xs:element name="QinoFeedID" type="xs:unsignedInt" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name="Details">
          <xs:complexType>
            <xs:sequence>
              <xs:element maxOccurs="unbounded" name="TicketLineItem">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name="LineItemNumber" type="xs:unsignedByte" />
                    <xs:element name="ParcelNumber" type="xs:unsignedShort" />
                    <xs:element name="EventType" type="xs:string" />
                    <xs:element name="Party">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element name="PartyType" type="xs:string" />
                          <xs:element name="PartyId" type="xs:unsignedShort" />
                          <xs:element name="PartyName" type="xs:string" />
                          <xs:element name="Address" type="xs:string" />
                          <xs:element name="ExciseLicenseNumber" type="xs:unsignedInt" />
                          <xs:element name="VATNumber" type="xs:unsignedShort" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element name="Mot">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element name="Type" type="xs:string" />
                          <xs:element name="MotName" type="xs:string" />
                          <xs:element name="ShippingCompanyName" type="xs:string" />
                          <xs:element name="ShipRegistry" type="xs:string" />
                          <xs:element name="IMONumber" type="xs:unsignedInt" />
                          <xs:element name="Inspector" type="xs:string" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element name="Location">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element minOccurs="0" name="DischargePort" type="xs:string" />
                          <xs:element minOccurs="0" name="LoadPort" type="xs:string" />
                          <xs:element name="Origin" type="xs:string" />
                          <xs:element name="WarehouseNumber" type="xs:string" />
                          <xs:element name="TerminalAddress" type="xs:string" />
                          <xs:element minOccurs="0" name="ReceivingTerminal" type="xs:string" />
                          <xs:element minOccurs="0" name="ReceivingTerminalPlace" type="xs:string" />
                          <xs:element minOccurs="0" name="ReceivingTerminalCountry" type="xs:string" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element name="ProductCustomCodes">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element name="ProductCode" type="xs:string" />
                          <xs:element name="GNTaricCode" type="xs:string" />
                          <xs:element name="CustomStatus" type="xs:string" />
                          <xs:element name="ExciseStatus" type="xs:string" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element name="Quantities">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element name="GrossQty" type="xs:unsignedShort" />
                          <xs:element name="GrossUOMCode" type="xs:string" />
                          <xs:element name="NetQty" type="xs:unsignedShort" />
                          <xs:element name="NetUOMCode" type="xs:string" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element name="ActualSpecs">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element maxOccurs="unbounded" name="Specification">
                            <xs:complexType>
                              <xs:sequence>
                                <xs:element name="Code" type="xs:string" />
                                <xs:element name="Value" type="xs:unsignedByte" />
                              </xs:sequence>
                            </xs:complexType>
                          </xs:element>
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element name="EventDates">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element name="SchFromDate" type="xs:string" />
                          <xs:element name="SchToDate" type="xs:string" />
                          <xs:element name="EstimatedDateOfArrival" type="xs:string" />
                          <xs:element name="NoticeOfReadiness" type="xs:string" />
                          <xs:element name="LoadComplDate" type="xs:string" />
                          <xs:element name="DischargeComplDate" type="xs:string" />
                          <xs:element name="HoseOnDate" type="xs:string" />
                          <xs:element name="HoseOffDate" type="xs:string" />
                          <xs:element name="BLDate" type="xs:string" />
                          <xs:element name="VesselDeparted" type="xs:string" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                    <xs:element name="Others">
                      <xs:complexType>
                        <xs:sequence>
                          <xs:element name="IsFullyActualized" type="xs:string" />
                          <xs:element name="TicketNum" type="xs:unsignedInt" />
                          <xs:element name="DeliveryTerms" type="xs:string" />
                        </xs:sequence>
                      </xs:complexType>
                    </xs:element>
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name="Summary">
          <xs:complexType>
            <xs:sequence>
              <xs:element name="TotalLineItems" type="xs:unsignedByte" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>')
     select @rows_affected = @@rowcount
   end try
   begin catch
     if @@trancount > 0
	      rollback tran
     print '=> Failed to insert new xml into feed_xsd_xml_text table due to below error:'
     print '==> ERROR: ' + ERROR_MESSAGE()
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
   begin
      print '=> Added a new xml into feed_xsd_xml_text successfully!'
      select @request_xsd_id = @newoid    	
   end

   select @newoid = isnull(max(oid), 0) + 1
   from dbo.feed_definition

   begin tran
   begin try
     insert into dbo.feed_definition
         (oid, feed_name, request_xsd_id, response_xsd_id, mapping_xml_id, 
          active_ind, trans_id, display_name, interface)
        values (@newoid, 'BTT_ORDER_TICKET', @request_xsd_id, @response_xsd_id, 
                @mapping_xml_id, 1, @transId, 'Order Ticket', 'BTT')
     select @rows_affected = @@rowcount
   end try
   begin catch
     if @@trancount > 0
        rollback tran
     print '=> Failed to add a feed_definition record for BTT_ORDER_TICKET due to below error:'
     print '==> ERROR: ' + ERROR_MESSAGE()
     goto endofscript 
   end catch
   commit tran
   if @rows_affected > 0
      print '=> A new feed_definition record was added for BTT_ORDER_TICKET successfully!'
end
else
   print '=> The new feed BTT_ORDER_TICKET already exist in feed_definition table!'

endofscript:
go

print ' '
go
exec dbo.refresh_a_last_num 'feed_definition_xsd_xml', 'oid'
go
exec dbo.refresh_a_last_num 'feed_definition', 'oid'
go
