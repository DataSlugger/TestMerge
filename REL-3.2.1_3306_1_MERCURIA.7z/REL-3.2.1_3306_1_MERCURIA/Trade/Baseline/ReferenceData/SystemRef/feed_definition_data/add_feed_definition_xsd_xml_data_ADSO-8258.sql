set nocount on

print ''
print 'Adding ref data into feed_definition_xsd_xml and feed_definition tables ...'
print ''
go

if EXISTS (select 1 
           from dbo.feed_definition_xsd_xml 
           where doc_text = 'SymphonyTableName=ag_truck_actual_details,DataFileFormat=CSV,JDETagInternalExternalBased=False,MappingFilePath=Map_CKI_Receipt_Actuals.xlsx')
begin
   RAISERROR('Ref data was already loaded into feed_definition_xsd_xml and feed_definition tables', 0, 1) with nowait
   goto endofscript
end

declare @transId		     		int,
		@feed_definition_xsd_xml_id int, 
		@feed_definition_id	     	int,
		@rows_affected		     	int,
		@errcode                    int,
		@smsg                       varchar(max)

   /* Begin - new trans_id script */     
   begin tran
   begin try
	 exec dbo.gen_new_transaction_NOI @app_name = 'DbIssue_ADSO-8258'
   end try
   begin catch
     set @errcode = ERROR_NUMBER()
	 set @smsg = ERROR_MESSAGE()
	 if @@trancount > 0
		rollback tran
	 RAISERROR('=> Failed to execute the ''gen_new_transaction_NOI'' procedure due to the error below:', 0, 1) with nowait
	 RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
	 goto endofscript
   end catch
   commit tran

   select @transId = null
 
   select @transId = last_num 
   from dbo.icts_trans_sequence 
   where oid = 1

   if @transId is null
   begin
	  RAISERROR('=> Failed to obtain a new trans_id for insert!', 0, 1) with nowait
	 goto endofscript
   end

   /* End - new trans_id script */

   -- Record #1
   select @feed_definition_xsd_xml_id = isnull(max(oid), 0) + 1
   from dbo.feed_definition_xsd_xml
   
   select @feed_definition_id = isnull(max(oid), 0) + 1
   from dbo.feed_definition
   
   set @rows_affected = 0
   begin tran
   begin try
     insert into dbo.feed_definition_xsd_xml
	      (oid,doc_text,trans_id)
        values(@feed_definition_xsd_xml_id, 
		       'SymphonyTableName=ag_truck_actual_details,DataFileFormat=CSV,JDETagInternalExternalBased=False,MappingFilePath=Map_CKI_Receipt_Actuals.xlsx', 
		       @transId)
     set @rows_affected = @@rowcount
   end try
   begin catch
     set @errcode = ERROR_NUMBER()
	 set @smsg = ERROR_MESSAGE()
	 if @@trancount > 0
		rollback tran
	 RAISERROR('=> Failed to add a new feed_definition_xsd_xml record (1) due to the error below:', 0, 1) with nowait
	 RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
	 goto endofscript
   end catch
   if @rows_affected > 0
	 RAISERROR('=> %d feed_definition_xsd_xml records (1) were added!', 0, 1, @rows_affected) with nowait

   set @rows_affected = 0
   begin try
     insert into feed_definition
	      (oid,feed_name, request_xsd_id, response_xsd_id, mapping_xml_id,
		   active_ind, trans_id, display_name, interface)
       values(@feed_definition_id, 'TICKET_UPLOAD_INTERFACE', NULL, NULL, 
	          @feed_definition_xsd_xml_id, 1, @transId, 'CKI_Receipt_Actuals', 'Ticket') 
     set @rows_affected = @@rowcount  
   end try
   begin catch
     set @errcode = ERROR_NUMBER()
	 set @smsg = ERROR_MESSAGE()
	 if @@trancount > 0
		rollback tran
	 RAISERROR('=> Failed to add a new feed_definition record (1) due to the error below:', 0, 1) with nowait
	 RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
	 goto endofscript
   end catch
   if @rows_affected > 0
	 RAISERROR('=> %d feed_definition record (1) were added!', 0, 1, @rows_affected) with nowait
	 
   -- Record #2
   set @feed_definition_xsd_xml_id = @feed_definition_xsd_xml_id + 1
   set @feed_definition_id = @feed_definition_id + 1

   set @rows_affected = 0
   begin tran
   begin try
     insert into dbo.feed_definition_xsd_xml
	      (oid, doc_text, trans_id)
       values(@feed_definition_xsd_xml_id, 
	          'SymphonyTableName=ag_truck_actual_details,DataFileFormat=CSV,JDETagInternalExternalBased=True,MappingFilePath=map_CKI_Liftings_Actuals.xlsx', 
		      @transId)
     set @rows_affected = @@rowcount
     set @rows_affected = @@rowcount
   end try
   begin catch
     set @errcode = ERROR_NUMBER()
	 set @smsg = ERROR_MESSAGE()
	 if @@trancount > 0
		rollback tran
	 RAISERROR('=> Failed to add a new feed_definition_xsd_xml record (2) due to the error below:', 0, 1) with nowait
	 RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
	 goto endofscript
   end catch
   if @rows_affected > 0
	 RAISERROR('=> %d feed_definition_xsd_xml records (2) were added!', 0, 1, @rows_affected) with nowait

   set @rows_affected = 0
   begin try
     insert into dbo.feed_definition
	      (oid,feed_name, request_xsd_id, response_xsd_id, mapping_xml_id,
		   active_ind, trans_id, display_name, interface)
        values(@feed_definition_id, 'TICKET_UPLOAD_INTERFACE', NULL, NULL, 
	           @feed_definition_xsd_xml_id, 1, @transId, 'CKI_Liftings_Actuals', 'Ticket') 
     set @rows_affected = @@rowcount  
   end try
   begin catch
     set @errcode = ERROR_NUMBER()
	 set @smsg = ERROR_MESSAGE()
	 if @@trancount > 0
		rollback tran
	 RAISERROR('=> Failed to add a new feed_definition record (2) due to the error below:', 0, 1) with nowait
	 RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
	 goto endofscript
   end catch
   if @rows_affected > 0
	 RAISERROR('=> %d feed_definition record (2) were added!', 0, 1, @rows_affected) with nowait

endofscript:
update dbo.new_num
set last_num = (select max(oid) from dbo.feed_definition_xsd_xml)
where owner_table = 'feed_definition_xsd_xml' and
      owner_column = 'oid' and
	  loc_num = 0

update dbo.new_num
set last_num = (select max(oid) from dbo.feed_definition)
where owner_table = 'feed_definition' and
      owner_column = 'oid' and
	  loc_num = 0	  	  
go