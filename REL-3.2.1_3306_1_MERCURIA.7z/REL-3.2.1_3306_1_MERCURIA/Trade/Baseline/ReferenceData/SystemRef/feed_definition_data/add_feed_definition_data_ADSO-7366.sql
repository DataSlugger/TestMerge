set nocount on

print ' '
print 'Adding new feed_name ''CKIAccrualsOutbound'' into the feed_definition table IF NOT EXISTS ...'
go

if exists (select 1 
           from dbo.feed_definition 
           where feed_name = 'CKIAccrualsOutbound')
begin
   print '=> The feed name ''CKIAccrualsOutbound'' in feed_definition table already exists...!'
   goto endofscript
end

declare	@trans_id		                int,
		    @rows_affected		          int,
		    @errcode                    int,
		    @smsg                       varchar(max),
		    @feed_definition_xsd_xml_id int, 
		    @feed_definition_id	        int

	 exec dbo.gen_new_transaction_NOI @app_name = 'DbIssue_ADSO-7366'
	 select @trans_id = null
	 select @trans_id = last_num   
   from dbo.icts_trans_sequence   
	 where oid = 1

   select @feed_definition_id = isnull(max(oid), 0) + 1
   from dbo.feed_definition

   select @feed_definition_xsd_xml_id = isnull(max(oid), 0) + 1
   from dbo.feed_definition_xsd_xml		
		
	 begin tran
   begin try
     insert into dbo.feed_definition_xsd_xml(oid,doc_text,trans_id)
			 values(@feed_definition_xsd_xml_id,
					'<?xml version="1.0" encoding="utf-8"?>
					<xs:schema attributeFormDefault="unqualified" elementFormDefault="qualified" xmlns:xs="http://www.w3.org/2001/XMLSchema">
					  <xs:element name="DATA">
						<xs:complexType>
						  <xs:sequence>
							<xs:element maxOccurs="unbounded" name="Cost">
							  <xs:complexType>
								<xs:sequence>
								  <xs:element name="doc_type" type="xs:string"/>  <!-- Char(8) -->
								  <xs:element name="fdd_id" type="xs:string"/>  <!-- Char(20) Symphony side staging table unique record id-->
								  <xs:element name="company_code" type="xs:string" />  <!-- Char(9) -->
								  <xs:element name="terminal" type="xs:string" /> <!-- Char(15) -->
								  <xs:element name="reference1" type="xs:int" /> <!-- Integer -->
								  <xs:element name="reference2" type="xs:string" /> <!-- Char(40) -->
								  <xs:element name="trans_date" type="xs:string" />  <!-- Date as string in format YYYYMMDD -->
								  <xs:element name="gl_date" type="xs:string" />  <!-- Date as string in format YYYYMMDD -->
								  <xs:element name="physical_or_financial" type="xs:string" /> <!-- Char(1) -->
								  <xs:element name="pay_or_receive" type="xs:string" /> <!-- Char(1) -->
								  <xs:element name="accrual" type="xs:string" minOccurs="0"/> <!-- Char(1) -->
								  <xs:element name="cost_amt" type="xs:decimal" /> <!-- Float up to 4 Decimals -->
								  <xs:element name="currency" type="xs:string" /> <!-- Char(8) -->
								  <xs:element name="product" type="xs:string" /> <!-- Char(8) -->
								  <xs:element name="value_chain" type="xs:string" /> <!-- Char(8) -->
								  <xs:element name="product_category" type="xs:string" /> <!-- Char(8) -->
								  <xs:element name="product_group" type="xs:string" /> <!-- Char(8) -->
								  <xs:element name="account" type="xs:string" /> <!-- Char(??) -->
								  <xs:element name="sub_ledger" type="xs:string" /> <!-- Char(??) -->
								  <xs:element name="counterparty" type="xs:string" /> <!-- Char(9) -->
								</xs:sequence>
							  </xs:complexType>
							</xs:element>
						  </xs:sequence>
						</xs:complexType>
					  </xs:element>
					</xs:schema>', 
					@trans_id)
			set @rows_affected = @@rowcount
   end try
   begin catch
   	 set @errcode = ERROR_NUMBER()
   	 set @smsg = ERROR_MESSAGE()
		 if @@trancount > 0
			  rollback tran
     RAISERROR('=> Failed to add a new feed_definition_xsd_xml record due to below error:', 0, 1) with nowait
		 RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
     goto endofscript
   end catch
	 commit tran
	 if @rows_affected > 0
		  RAISERROR('=> A new feed_definition_xsd_xml record was added successfully!', 0, 1) with nowait
	
	 set @rows_affected = 0;
   begin tran
   begin try
     insert into dbo.feed_definition
          (oid, feed_name, request_xsd_id, response_xsd_id, mapping_xml_id, 
           active_ind, trans_id, display_name, interface)
			values(@feed_definition_id, 'CKIAccrualsOutbound', @feed_definition_xsd_xml_id, 
			       @feed_definition_xsd_xml_id, null, 1, @trans_id, 'CKIAccrualsOutbound', 'CKI') 
     set @rows_affected = @@rowcount
   end try
   begin catch
   	 set @errcode = ERROR_NUMBER()
   	 set @smsg = ERROR_MESSAGE()
		 if @@trancount > 0
			  rollback tran
     RAISERROR('=> Failed to add new feed name into feed_definition table due to below error:', 0, 1) with nowait
		 RAISERROR('==> ERROR %d: %s', 0, 1, @errcode, @smsg) with nowait
     goto endofscript
   end catch
	 commit tran
	 if @rows_affected > 0
		  RAISERROR('=> The feed_definition record with the feed_name ''CKIAccrualsOutbound'' was added successfully!', 0, 1) with nowait

endofscript:
print ' '
exec dbo.refresh_a_last_num 'feed_definition_xsd_xml', 'oid'
exec dbo.refresh_a_last_num 'feed_definition', 'oid'
go

