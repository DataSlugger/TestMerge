set nocount on

insert into dbo.icts_timezones
     (tz_name, tz_utc_offset_hr, tz_utc_offset_mm, trans_id, tz_abbvr)
	values('Greenwich Mean Time', 0, 0, 1, 'GMT')
go