/*

05/12/2005

BUNDLE NAME                     ALS BUNDLE GROUP NAME   ENTITY                  TRANS TYPE
=============================== ======================= ======================  ===========
AccumulationUpdateForFormula	  ALS			                Formula			            U,S
AllocUpdateForAllocation	      ALS			                Allocation		          U,S
AutoAllocationForBunker		      ALS			                Trade			              U,S
BrokerCostForExchangeTradeItem	ALS			                TradeItem		            U,S
BrokerCostForExchangeTradeItem	ALS			                TradeItemFut		        U,S
BrokerCostForExchangeTradeItem	ALS			                TradeItemExchOpt	      U,S
CostUpdateForAccum		          ALS			                Accumulation		        U,S
CostUpdateForBunkerOrder	      ALS			                TradeOrderBunker	      U,S
PrelimCosts			                ALS			                Cost			              U,S
PrelimCosts			                ALS			                TradeItemWetPhy		      U,S
ProratePOForCost		            ALS			                Cost			              U,S
UpdateCostForActual		          ALS			                AiEstActual		          U,S
UpdateCostForVoyage		          ALS			                Cost			              U,S
UpdateCostsForTradeItemOpt	    ALS			                TradeItemOtcOpt		      U,S
UpdateCostsForTradeItemOpt	    ALS			                TradeItemStorage	      U,S
UpdateCostsForTradeItemOpt	    ALS			                TradeItemTransport	    U,S
UpdateCostsForTradeItemOpt	    ALS			                TradeItemWetPhy		      U,S
UpdateCostsForTradeItemOpt	    ALS			                TradeItemBunker		      U,S
UpdateCostsForTradeItemOpt	    ALS			                TradeItemCashPhy	      U,S
UpdateForCustomContractNum	    ALS			                Trade			              U,S
UpdateForFxHedgeRate		        ALS			                FxHedgeRate		          U,S
UpdateForMktPriceConditions	    ALS			                MarketPricingCondition	U,S
UpdateFormulaInfo		            ALS			                Formula			            U,S
UpdateForSpecifications		      ALS			                TradeItemSpec		        U,S
UpdateForSpecifications		      ALS			                AiEstActualSpec		      U,S
UpdateForTIDSplitMove		        ALS			                TradeItemDist		        U,S
UpdateForTradeItem		          ALS			                TradeItem		            U,S
UpdateInvLoopNum		            ALS			                InventoryBuildDraw	    U,S
UpdateInvLoopNum		            ALS			                AllocationItem		      U,S
UpdatePosFieldsForCost		      ALS			                Cost			              U,S
UpdatePosFieldsForCost		      ALS			                TradeItem		            U,S
UpdatePosFieldsForCost		      ALS			                TradeItemDist		        U,S
UpdatePosNumForTid		          ALS			                TradeItemDist		        U,S
UpdatePosNumForTid		          ALS			                TradeItem		            U,S
UpdateUnderlyingEquiv		        ALS			                TradeItemDist		        U,S

AllocUpdateForInventory		      ALS			                Inventory		            U
AutoAllocationForTradeItem	    ALS			                TradeItem		            U
CostUpdateForAdditional		      ALS			                Cost			              U
UpdateContractStatus		        ALS			                Trade			              U
UpdateForAllocationItem		      ALS			                AllocationItem	      	U
UpdateForTrade		       	      ALS			                Trade			              U


UpdatePosNumForInv		          ALS			                Inventory		            U,S,E,P
UpdatePosNumForInv		          ALS			                TradeItem		            U,S,E,P
--------------------------------------------------------------------------------------------
CreateCostInterfaceInfo		      ALS2			              Cost			              U,S
RNFileGen			                  ALS2			              Trade			              U,S
UpdateVoucherForCustVouchRng	  ALS2			              Voucher			            U,S

PostHeadlineForTrade		        ALS2			              Trade			              U
--------------------------------------------------------------------------------------------
AutoConfirm			                AutoConfirm		          Trade			              U,S
--------------------------------------------------------------------------------------------
AutoRepricing			              AutoRepricing		        RepriceEventDetail	    U,S
--------------------------------------------------------------------------------------------
AllocUpdateForActual		        CriticalALS		          AiEstActual		          U
UpdatePosQtyForTid		          CriticalALS		          TradeItemDist		        U,S
UpdatePosQtyForTid		          CriticalALS		          TradeItem		            U,S

UpdatePosQtyForInv		          CriticalALS		          Inventory		            U,S,E,P
--------------------------------------------------------------------------------------------
EODUpdatePosQtyForTid		        EODALS			            TradeItemDist		        U,S,P
--------------------------------------------------------------------------------------------
NotifyEvent			                Exposure		            Event			              U,S
UpdateExposureDetail		        Exposure		            Cost			              U,S
UpdateExposureDetail		        Exposure		            AssignTrade	          	U,S
UpdateExposureDetail		        Exposure		            Lc			                U,S
UpdateExposureDetail		        Exposure		            TradeItemWetPhy		      U,S
UpdateExposureDetail		        Exposure		            TradeItemOtcOpt		      U,S
UpdateExposureDetail		        Exposure		            Trade			              U,S
UpdateExposureDetail		        Exposure		            Accumulation		        U,S
UpdateExposureDetail		        Exposure		            AllocationItem		      U,S
UpdateExposureDetail		        Exposure		            AccountGroup			      U,S
UpdateExposureDetail		        Exposure		            CreditLimit 			      U,S
--------------------------------------------------------------------------------------------
AutoExposureGenerator		        ExposureGenerator	      Event			              U,S (dropped)
--------------------------------------------------------------------------------------------
PassScheduleUpdate		          PASSUtility		          JobSchedule		          U,S
PassScheduleUpdate		          PASSUtility		          Event			              U,S
--------------------------------------------------------------------------------------------
UpdateRepriceEvent		          Reprice			            CalendarDetail		      U,S
UpdateRepriceEvent		          Reprice			            TradingPeriod		        U,S
UpdateRepriceEvent		          Reprice			            CommodityMarketSource	  U,S
UpdateRepriceEvent		          Reprice			            Price			              U,S
UpdateRepriceEvent		          Reprice			            Accumulation		        U,S
--------------------------------------------------------------------------------------------
DealSheetExportToSharePoint	    SharePoint		          Trade			              U,S
--------------------------------------------------------------------------------------------
UpdatePosNumForVesselDist		    TMALS			              VesselDist		          U,S
UpdatePosQtyForVesselDist		    CriticalTMALS	          VesselDist		          U,S

*/

/* ------------------------------------------------
     trans_type_mask
        1  - E
        2  - U
        4  - S
        8  - P
       16  - I
       32  - A
    ----------------------------------------------- */
set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the server_config table ...' 
go

if object_id('dbo.xx1019alsservers') is not null
   drop table dbo.xx1019alsservers
go

create table dbo.xx1019alsservers
(
   oid                     numeric(18, 0) IDENTITY,
   als_module_group_desc   varchar(40) not null,
   multi_instances_ind     bit default 0 not null,
   critical_ind            bit default 0 not null,
   trans_type_mask         int default 0 not null
)

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'MainALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('MainALS', 1, 0, 2 + 4)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'ExtendedALS')
   insert into dbo.xx1019alsservers 
       (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('ExtendedALS', 1, 0, 2)
go 

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'AutoConfirm')
   insert into dbo.xx1019alsservers 
       (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('AutoConfirm', 1, 0, 2 + 4)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'AutoRepricing')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('AutoRepricing', 1, 0, 2 + 4)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'CriticalALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('CriticalALS', 1, 0, 6)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'EODALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('EODALS', 1, 0, 8)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'Exposure')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('Exposure', 1, 0, 2 + 4)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'ExposureGenerator')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('ExposureGenerator', 1, 0, 2 + 4)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'PASSUtility')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('PASSUtility', 1, 0, 2 + 4)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'Reprice')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('Reprice', 1, 0, 2 + 4)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'SharePoint')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('SharePoint', 1, 0, 2 + 4)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'TMALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('TMALS', 1, 0, 2 + 4)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'CriticalTMALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('CriticalTMALS', 1, 0, 2 + 4)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'JavaALServer')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('JavaALServer', 1, 0, 2 + 4)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'RVHistory')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('RVHistory', 1, 0, 1 + 2 + 4 + 8)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'RNFileALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('RNFileALS', 1, 0, 2 + 4 + 16)
go

-- No longer used in CS - issue #1331616
if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'ExternalTrade')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('ExternalTrade', 1, 0, 0)
go

-- No longer used in CS - issue #1331616
if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'ExternalTradeDD')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('ExternalTradeDD', 1, 0, 0)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'TimerALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('TimerALS', 1, 0, 0)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'UICReportHistory')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('UICReportHistory', 1, 0, 18)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'AllocCriticalALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('AllocCriticalALS', 1, 0, 0)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'CriticalALSUpdatePosQtyForInv')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('CriticalALSUpdatePosQtyForInv', 1, 0, 0)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'CriticalALSUpdatePosQtyForTid')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('CriticalALSUpdatePosQtyForTid', 1, 0, 0)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'LeaseCaptureALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('LeaseCaptureALS', 1, 0, 2)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'ZytaxALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('ZytaxALS', 1, 0, 6)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'ForexMainALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('ForexMainALS', 1, 0, 38)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'ForexCriticalALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('ForexCriticalALS', 1, 0, 38)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'CriticalRinALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('CriticalRinALS', 1, 0, 6)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'SymphonyOutboundDataALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('SymphonyOutboundDataALS', 1, 0, 2)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'OpsMgrIntegration')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('OpsMgrIntegration', 1, 1, 0)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'EIPP')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('EIPP', 1, 0, 6)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'MsiOutboundDataALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('MsiOutboundDataALS', 1, 0, 3)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'AllocationTransferALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('AllocationTransferALS', 1, 0, 6)
go

if not exists (select 1
               from dbo.server_config
               where als_module_group_desc = 'CKIOutboundDataALS')
   insert into dbo.xx1019alsservers 
        (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
      values('CKIOutboundDataALS', 1, 0, 7)
go

/* These were added for SEMPRA */
/*
insert into dbo.xx1019alsservers 
    (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
    values('EIPP', 1, 0, 2 + 4 + 8)

insert into dbo.xx1019alsservers 
    (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
    values('SempraDealSheetExport', 1, 0, 2 + 4 + 8)
*/
go

/* These were added for ENI */
/*
insert into dbo.xx1019alsservers 
    (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
    values('AGIP', 1, 0, 2 + 4)

insert into dbo.xx1019alsservers 
    (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
    values('OldTibco', 1, 0, 2 + 4)

insert into dbo.xx1019alsservers 
    (als_module_group_desc, multi_instances_ind, critical_ind, trans_type_mask)
    values('Tibco', 1, 0, 2 + 4)
*/
go


/* dropped  07/21/2006  (issue #14064) */
if exists (select 1
           from dbo.xx1019alsservers
           where als_module_group_desc = 'ExposureGenerator')
begin
   delete dbo.xx1019alsservers
   where als_module_group_desc = 'ExposureGenerator'
end
go



/* Here starts with the logic of loading records into the server_config table */

if (select count(*) from dbo.xx1019alsservers) = 0
   goto endofscript
   
declare @als_module_group_id     int

select @als_module_group_id = isnull(max(als_module_group_id), 0)
from dbo.server_config
   
insert into dbo.server_config
     (als_module_group_id, als_module_group_desc, multi_instances_ind, 
      critical_ind, trans_type_mask, trans_id)
select @als_module_group_id + oid, 
       als_module_group_desc, 
       multi_instances_ind, 
       critical_ind, 
       trans_type_mask,
       1
from dbo.xx1019alsservers   

endofscript:      
go

if object_id('dbo.xx1019alsservers') is not null
   drop table dbo.xx1019alsservers
go

exec refresh_a_last_num 'server_config', 'als_module_group_id'
go

