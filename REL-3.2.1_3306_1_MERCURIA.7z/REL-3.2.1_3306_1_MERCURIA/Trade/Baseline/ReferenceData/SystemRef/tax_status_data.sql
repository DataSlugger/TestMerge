set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the tax_status table ...'
go

if not exists (select 1
               from dbo.tax_status
               where tax_status_code = 'OPEN')
   insert into dbo.tax_status
       (tax_status_code, tax_status_desc, trans_id)
     values('OPEN', 'Need to calculate tax cost', 1)
go

if not exists (select 1
               from dbo.tax_status
               where tax_status_code = 'ERROR')
   insert into dbo.tax_status
       (tax_status_code, tax_status_desc, trans_id)
     values('ERROR', 'Error in processing tax cost', 1)
go

if not exists (select 1
               from dbo.tax_status
               where tax_status_code = 'COMPLETE')
   insert into dbo.tax_status
       (tax_status_code, tax_status_desc, trans_id)
     values('COMPLETE', 'Tax cost was created or updated', 1)
go
