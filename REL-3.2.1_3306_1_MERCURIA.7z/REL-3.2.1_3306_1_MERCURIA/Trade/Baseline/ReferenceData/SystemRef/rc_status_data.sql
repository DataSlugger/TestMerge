set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the rc_status table ...'
go

if NOT EXISTS (select *
               from dbo.rc_status
               where rc_status_code = 'ASSIGNED')
   insert into dbo.rc_status(rc_status_code,rc_status_short_name,rc_status_desc,trans_id)
   values('ASSIGNED', 'ASSIGNED', 'ASSIGNED', 1)
go

if NOT EXISTS (select *
               from dbo.rc_status
               where rc_status_code = 'EXPIRED')
   insert into dbo.rc_status(rc_status_code,rc_status_short_name,rc_status_desc,trans_id)
   values('EXPIRED', 'EXPIRED', 'EXPIRED', 1)
go

if NOT EXISTS (select *
               from dbo.rc_status
               where rc_status_code = 'INVOKED')
   insert into dbo.rc_status(rc_status_code,rc_status_short_name,rc_status_desc,trans_id)
   values('INVOKED', 'INVOKED', 'INVOKED', 1)
go

if NOT EXISTS (select *
               from dbo.rc_status
               where rc_status_code = 'CANCELED')
   insert into dbo.rc_status(rc_status_code,rc_status_short_name,rc_status_desc,trans_id)
   values('CANCELED', 'CANCELED', 'CANCELED', 1)
go