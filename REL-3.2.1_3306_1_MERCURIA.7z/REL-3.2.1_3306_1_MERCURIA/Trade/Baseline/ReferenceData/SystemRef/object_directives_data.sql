set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table object_directives
go

print 'Loading system reference data into the object_directives table ...'
go

INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AIEstActual','COMBINED_COLUMN','quantity,aiEstActualNetQty,ai_est_actual_net_qty,ai_net_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AIEstActual','COMBINED_COLUMN','quantity,aiEstActualGrossQty,ai_est_actual_gross_qty,ai_gross_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Account','DEFAULT_SORT','acct_short_name')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Account','SECONDARY_KEY','acct_short_name,acct_type_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountAddressCombo','BASE_CLASSES','Account,AccountAddress')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountAddressCombo','FRONT_LOAD','Account,AccountAddress')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountAddressCombo','JOIN','account.acct_num=account_address.acct_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountAddressCombo','PRIMARY_KEY','acct_num,acct_addr_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountCreditCombo','BASE_CLASSES','Account,AccountCreditInfo')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountCreditCombo','DEFAULT_SORT','account.acct_short_name')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountCreditCombo','FRONT_LOAD','Account,AccountCreditInfo')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountCreditCombo','JOIN','account.acct_num=account_credit_info.acct_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountCreditCombo','PRIMARY_KEY','acct_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountInst','SECONDARY_KEY','acct_num,cmdty_code,del_term_code,mot_code,acct_instr_type_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountName','BASE_CLASSES','Account,AccountContact')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountName','FRONT_LOAD','Account,AccountContact')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountName','JOIN','account.acct_num=account_contact.acct_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AccountName','PRIMARY_KEY','acct_num,acct_cont_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('ActualDetail','BASE_CLASSES','Allocation,AllocationItem,AIEstActual')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('ActualDetail','FRONT_LOAD',' Allocation,AllocationItem,AIEstActual')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('ActualDetail','JOIN','allocation.alloc_num=allocation_item.alloc_num and allocation_item.alloc_num = ai_est_actual.alloc_num and allocation_item.alloc_item_num=ai_est_actual.alloc_item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('ActualDetail','PRIMARY_KEY','alloc_num,alloc_item_num,ai_est_actual_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocDetailTransport','BASE_CLASSES','Allocation,AllocationItem,AllocationItemTransport')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocDetailTransport','FRONT_LOAD','Allocation,AllocationItem,AllocationItemTransport')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocDetailTransport','JOIN','allocation.alloc_num=allocation_item.alloc_num and allocation_item.alloc_num = allocation_item_transport.alloc_num and allocation_item.alloc_item_num = allocation_item_transport.alloc_item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocDetailTransport','PRIMARY_KEY','alloc_num,alloc_item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Allocation','COMBINED_COLUMN','quantity,netoutNetQty,netout_net_qty,netout_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Allocation','COMBINED_COLUMN','quantity,netoutGrossQty,netout_gross_qty,netout_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationChain','DATABASE_KEY','alloc_chain_num,alloc_chain_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationDetail','BASE_CLASSES','Allocation,AllocationItem,AllocationItemTransport')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationDetail','FRONT_LOAD','Allocation,AllocationItem,AllocationItemTransport')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationDetail','JOIN','allocation.alloc_num=allocation_item.alloc_num and allocation_item.alloc_num *= allocation_item_transport.alloc_num and allocation_item.alloc_item_num *= allocation_item_transport.alloc_item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationDetail','PRIMARY_KEY','alloc_num,alloc_item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationInsp','COMBINED_COLUMN','price,inspFeeAmt,insp_fee_amt,insp_fee_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItem','COMBINED_COLUMN','quantity,schQty,sch_qty,sch_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItem','COMBINED_COLUMN','quantity,nominQtyMax,nomin_qty_max,nomin_qty_max_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItem','COMBINED_COLUMN','quantity,nominQtyMin,nomin_qty_min,nomin_qty_min_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItem','COMBINED_COLUMN','quantity,actualGrossQty,actual_gross_qty,actual_gross_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemActual','COMBINED_COLUMN','quantity,aiActualNetQty,ai_actual_net_qty,ai_net_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemActual','COMBINED_COLUMN','quantity,aiActualGrossQty,ai_actual_gross_qty,ai_gross_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemInsp','COMBINED_COLUMN','price,inspFeeAmt,insp_fee_amt,insp_fee_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemTransport','COMBINED_COLUMN','quantity,blQty,bl_qty,bl_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemTransport','COMBINED_COLUMN','quantity,loadQty,load_qty,load_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemTransport','COMBINED_COLUMN','quantity,dischQty,disch_qty,disch_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationPl','COMBINED_COLUMN','price,allocPlSalesAmt,alloc_pl_sales_amt,alloc_pl_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationPl','COMBINED_COLUMN','price,allocPlPurchaseAmt,alloc_pl_purchase_amt,alloc_pl_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationPl','COMBINED_COLUMN','price,allocPlSecCostsAmt,alloc_pl_sec_costs_amt,alloc_pl_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AutoVoucherCost','DATABASE_KEY','cost_num, cost_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AutoVoucherCost','DEFAULT_SORT','cost_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('BusCostFate','DATABASE_KEY','bc_fate_num, bc_fate_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('BusCostMailList','DATABASE_KEY','bc_mail_list_num,bc_mail_list_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('BusCostState','DATABASE_KEY','bc_state_num, bc_state_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('BusCostType','DATABASE_KEY','bc_type_num, bc_type_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CmdtyLocGroupCombo','BASE_CLASSES','Location,LocationGroup,CommodityLocation')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CmdtyLocGroupCombo','FRONT_LOAD','Location,LocationGroup,CommodityLocation')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CmdtyLocGroupCombo','JOIN','location.loc_code=location_group.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CmdtyLocGroupCombo','JOIN','location.loc_code=commodity_location.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CmdtyLocGroupCombo','PRIMARY_KEY','loc_code,cmdty_code,loc_type_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CmdtyMkt','DATABASE_KEY','commkt_key,commkty_key')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CmdtyMkt','SECONDARY_KEY','mkt_code,cmdty_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CommktFutureAttr','COMBINED_COLUMN','quantity,commktLotSize,commkt_lot_size,commkt_lot_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CommktFutureAttr','COMBINED_COLUMN','quantity,commktFwdMthQty,commkt_fwd_mth_qty,commkt_lot_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CommktFutureAttr','COMBINED_COLUMN','quantity,commktSpotMthQty,commkt_spot_mth_qty,commkt_lot_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CommktFutureAttr','COMBINED_COLUMN','quantity,commktTotalOpenQty,commkt_total_open_qty,commkt_lot_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CommktOptionAttr','COMBINED_COLUMN','quantity,commktLotSize,commkt_lot_size,commkt_lot_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CommktOptionAttr','COMBINED_COLUMN','quantity,commktFwdMthQty,commkt_fwd_mth_qty,commkt_lot_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CommktOptionAttr','COMBINED_COLUMN','quantity,commktSpotMthQty,commkt_spot_mth_qty,commkt_lot_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CommktOptionAttr','COMBINED_COLUMN','quantity,commktTotalOpenQty,commkt_total_open_qty,commkt_lot_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CommktPhysicalAttr','COMBINED_COLUMN','quantity,commktDfltQty,commkt_dflt_qty,commkt_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Commodity','DEFAULT_SORT','cmdty_short_name')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Commodity','SECONDARY_KEY','cmdty_short_name')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Cost','DATABASE_KEY','cost_num,cost_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Cost','DEFAULT_SORT','cost_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CostSearch','PRIMARY_KEY','cost_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CreditAlarmLog','DATABASE_KEY','credit_alarm_log_num,credit_alarm_log_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CreditAlarmLogComment','DATABASE_KEY','alarm_log_cmnt_num,alarm_log_cmnt_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CreditLimitComment','DATABASE_KEY','limit_cmnt_num,limit_cmnt_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('DeskLocation','SECONDARY_KEY','desk_loc_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Document','DATABASE_KEY','doc_num,doc_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('EOMPostingBatch','DATABASE_KEY','eom_pb_process_num,eom_pb_process_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Exposure','DATABASE_KEY','exposure_num,exposure_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Formula','DEFAULT_SORT','formula_name')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Function','PRIMARY_KEY','function_num, function_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Function','SECONDARY_KEY','app_name,function_name')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Inventory','COMBINED_COLUMN','quantity,invAdjQty,inv_adj_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Inventory','COMBINED_COLUMN','quantity,lineFillQty,line_fill_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Inventory','COMBINED_COLUMN','quantity,invCurrProjQty,inv_curr_proj_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Inventory','COMBINED_COLUMN','quantity,invRcptProjQty,inv_rcpt_proj_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Inventory','COMBINED_COLUMN','quantity,invDlvryProjQty,inv_dlvry_proj_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Inventory','COMBINED_COLUMN','quantity,invCurrActualQty,inv_curr_actual_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Inventory','COMBINED_COLUMN','quantity,invRcptActualQty,inv_rcpt_actual_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Inventory','COMBINED_COLUMN','quantity,invDlvryActualQty,inv_dlvry_actual_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Inventory','COMBINED_COLUMN','quantity,invOpenPrdProjQty,inv_open_prd_proj_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Inventory','COMBINED_COLUMN','quantity,invOpenPrdActualQty,inv_open_prd_actual_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Inventory','DATABASE_KEY','inv_num,inv_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Inventory','SECONDARY_KEY','trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryBalance','COMBINED_COLUMN','quantity,invAdjQty,inv_adj_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryBalance','COMBINED_COLUMN','quantity,invOpenPrdProjQty,inv_open_prd_proj_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryBalance','COMBINED_COLUMN','quantity,invClosePrdProjQty,inv_close_prd_proj_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryBalance','COMBINED_COLUMN','quantity,invOpenPrdActualQty,inv_open_prd_actual_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryBalance','COMBINED_COLUMN','quantity,invClosePrdActualQty,inv_close_prd_actual_qty,inv_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryBuildDraw','COMBINED_COLUMN','quantity,adjQty,adj_qty,adj_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryBuildDraw','COMBINED_COLUMN','quantity,invBDQty,inv_b_d_qty,adj_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryBuildDraw','COMBINED_COLUMN','price,bdCost,inv_b_d_cost,inv_b_d_cost_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryBuildDraw','COMBINED_COLUMN','quantity,invBDActualQty,inv_b_d_actual_qty,adj_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryBuildDraw','DATABASE_KEY','inv_b_d_num,inv_b_d_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryBuildDraw','PRIMARY_KEY','inv_num,inv_b_d_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryBuildDraw','SECONDARY_KEY','alloc_num,alloc_item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCombo','BASE_CLASSES','Trade,TradeOrder,TradeItem,Inventory')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCombo','FRONT_LOAD','Trade,TradeOrder,TradeItem,Inventory')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCombo','JOIN','trade_order.order_num=trade_item.order_num and trade_item.order_num=inventory.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCombo','JOIN','trade_item.item_num=inventory.item_num and trade.conclusion_type=''C'' and trade.inhouse_ind=''N''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCombo','JOIN','trade_order.order_type_code in (''STORAGE'', ''TRANSPRT'') and trade_order.strip_summary_ind != ''Y''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCombo','JOIN','trade.trade_num=trade_order.trade_num and trade_order.trade_num=trade_item.trade_num and trade_item.trade_num=inventory.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCombo','PRIMARY_KEY','trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','BASE_CLASSES','Cost,Trade,TradeOrder,TradeItem,Inventory,Location,LocationExtInfo')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','FRONT_LOAD','Cost,Trade,TradeOrder,TradeItem,Inventory,Location,LocationExtInfo')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','JOIN','cost.cost_owner_code=''I''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','JOIN','trade_order.trade_num=trade.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','JOIN','cost.cost_owner_key1=inventory.inv_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','JOIN','inventory.item_num=trade_item.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','JOIN','inventory.order_num=trade_item.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','JOIN','inventory.trade_num=trade_item.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','JOIN','inventory.del_loc_code = location.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','JOIN','trade_item.order_num=trade_order.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','JOIN','trade_item.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','JOIN','inventory.del_loc_code = location_ext_info.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('InventoryCostCombo','PRIMARY_KEY','cost_num,trade_num,order_num,item_num,loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('JobRequest','DATABASE_KEY','job_request_num,job_request_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseContractCombo','BASE_CLASSES','LeaseHead,LeaseVersion,LeaseContractDetail,LeaseOperator')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseContractCombo','FRONT_LOAD','LeaseHead,LeaseVersion,LeaseContractDetail,LeaseOperator')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseContractCombo','JOIN','(lease_operator.party_uid = lease_contract_detail.lease_oper_acct_num and  lease_contract_detail.lease_oper_addr_num = lease_operator.site_sequence)')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseContractCombo','JOIN','((lease_head.lease_num = lease_contract_detail.lease_num) and  (lease_head.lease_num = lease_version.lease_num) and (lease_version.ver_num = lease_contract_detail.ver_num and  lease_version.lease_num = lease_contract_detail.lease_num))')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseContractCombo','PRIMARY_KEY','lease_num,ver_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseDestError','DATABASE_KEY','ld_err_num,ld_err_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseDestinationCombo','BASE_CLASSES','LeaseHead,LeaseDestination')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseDestinationCombo','JOIN','lease_head.lease_num=lease_destination.lease_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseDestinationCombo','PRIMARY_KEY','lease_num,dest_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseHeadError','DATABASE_KEY','lh_err_num,lh_err_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeasePricingError','DATABASE_KEY','lp_err_num,lp_err_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseSearchCombo','BASE_CLASSES','LeaseHead,LeaseVersion,LeaseContractDetail,LeaseDestination')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseSearchCombo','FRONT_LOAD','LeaseHead,LeaseVersion,LeaseContractDetail,LeaseDestination')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseSearchCombo','JOIN','lease_head.lease_num=lease_version.lease_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseSearchCombo','JOIN','lease_version.ver_num*=lease_destination.ver_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseSearchCombo','JOIN','lease_version.lease_num*=lease_destination.lease_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseSearchCombo','JOIN','lease_version.ver_num*=lease_contract_detail.ver_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseSearchCombo','JOIN','lease_version.lease_num*=lease_contract_detail.lease_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseSearchCombo','PRIMARY_KEY','lease_num,ver_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LeaseTicketError','DATABASE_KEY','lt_err_num,lt_err_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Licence','DATABASE_KEY','licence_num,licence_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('License','DATABASE_KEY','license_num,license_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LocGroupCombo','BASE_CLASSES','Location,LocationGroup')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LocGroupCombo','FRONT_LOAD','Location,LocationGroup,')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LocGroupCombo','JOIN','location.loc_code=location_group.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LocGroupCombo','PRIMARY_KEY','loc_code,loc_type_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LseDestinContractCombo','BASE_CLASSES','TradeOrder,TradeItem')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LseDestinContractCombo','FRONT_LOAD','TradeOrder,TradeItem')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LseDestinContractCombo','JOIN','trade_item.p_s_ind=''S''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LseDestinContractCombo','JOIN','trade_item.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LseDestinContractCombo','JOIN','trade_item.item_type in (''W'', ''S'', ''R'', ''T'' )')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LseDestinContractCombo','JOIN','trade_order.order_type_code in (''EFPEXCH'', ''LSEBYSL'', ''LSEEXCH'', ''LSFRACEX'', ''LSFRACPS'', ''LSHLERPS'', ''LSPRCHSL'', ''OTCPHYS'', ''PARTIAL'', ''PHYSBYSL'', ''PHYSEXCH'', ''PHYSICAL'', ''PROCESS'', ''STORAGE'', ''TRANSPRT'')')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LseDestinContractCombo','PRIMARY_KEY','trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LseDestinLocationCombo','BASE_CLASSES','TradeItem,LeaseDestination,LeaseVersion')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LseDestinLocationCombo','FRONT_LOAD','TradeItem,LeaseDestination,LeaseVersion')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LseDestinLocationCombo','JOIN','trade_item.trade_num=lease_destination.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LseDestinLocationCombo','PRIMARY_KEY','trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('OrderTermEvergreen','COMBINED_COLUMN','quantity,contrQty,contr_qty,contr_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PaperAllocation','DATABASE_KEY','paper_alloc_num,paper_alloc_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PassControl','DATABASE_KEY','pass_control_num,pass_control_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PeiComment','DATABASE_KEY','cmnt_num,cmnt_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PortfolioCostCombo','BASE_CLASSES','Cost,Portfolio')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PortfolioCostCombo','FRONT_LOAD','Cost,Portfolio')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PortfolioCostCombo','JOIN','cost.cost_owner_code=''P''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PortfolioCostCombo','JOIN','cost.cost_owner_key1=portfolio.port_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PortfolioCostCombo','PRIMARY_KEY','cost_num,port_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PostingAccount','DATABASE_KEY','posting_account_num, posting_account_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PostingSearchPrec','DEFAULT_SORT','search_precedence')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PriceChange','DATABASE_KEY','price_change_num,price_change_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('RecapItemCombo','BASE_CLASSES','Trade,TradeOrder,TradeItem,TradeItemWetPhy')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('RecapItemCombo','FRONT_LOAD','Trade,TradeOrder,TradeItem,TradeItemWetPhy')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('RecapItemCombo','JOIN','trade.trade_num=trade_item.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('RecapItemCombo','JOIN','trade.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('RecapItemCombo','JOIN','trade_order.order_num=trade_item.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('RecapItemCombo','JOIN','trade.trade_num=trade_item_wet_phy.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('RecapItemCombo','JOIN','trade_item.item_num=trade_item_wet_phy.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('RecapItemCombo','JOIN','trade_order.order_num=trade_item_wet_phy.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('RecapItemCombo','PRIMARY_KEY','trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Report','DATABASE_KEY','rep_num,rep_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('RepricedTradeItems','DATABASE_KEY','repriced_num,repriced_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','BASE_CLASSES','Cost,Trade,TradeOrder,TradeItem,Accumulation')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','FRONT_LOAD','Cost,Trade,TradeOrder,TradeItem,Accumulation')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','JOIN','cost.cost_owner_code=''AC''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','JOIN','trade_order.trade_num=trade.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','JOIN','accumulation.item_num=trade_item.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','JOIN','cost.cost_owner_key3=accumulation.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','JOIN','trade_item.order_num=trade_order.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','JOIN','trade_item.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','JOIN','accumulation.order_num=trade_item.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','JOIN','accumulation.trade_num=trade_item.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','JOIN','cost.cost_owner_key1=accumulation.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','JOIN','cost.cost_owner_key2=accumulation.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','JOIN','cost.cost_owner_key4=accumulation.accum_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','JOIN','trade_order.order_type_code in (''SWAP'', ''SWAPFLT'')')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIAccumCostCombo','PRIMARY_KEY','cost_num,trade_num,order_num,item_num,accum_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','BASE_CLASSES','Cost,Trade,TradeOrder,TradeItem,TradeItemCashPhy')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','FRONT_LOAD','Cost,Trade,TradeOrder,TradeItem,TradeItemCashPhy')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','JOIN','cost.cost_owner_code=''TI''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','JOIN','trade_order.strip_summary_ind!=''Y''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','JOIN','trade_order.trade_num=trade.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','JOIN','trade_item.order_num=trade_order.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','JOIN','trade_item.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','JOIN','trade_item_cash_phy.item_num=trade_item.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','JOIN','cost.cost_owner_key3=trade_item_cash_phy.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','JOIN','cost.cost_owner_key1=trade_item_cash_phy.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','JOIN','cost.cost_owner_key2=trade_item_cash_phy.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','JOIN','trade_item_cash_phy.order_num=trade_item.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','JOIN','trade_item_cash_phy.trade_num=trade_item.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','JOIN','trade_order.order_type_code in (''SWAP'', ''SWAPFLT'')')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICashPhyCostCombo','PRIMARY_KEY','cost_num,trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','BASE_CLASSES','Cost,Trade,TradeOrder,TradeItem,TradeItemExchOpt')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','FRONT_LOAD','Cost,Trade,TradeOrder,TradeItem,TradeItemExchOpt')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','JOIN','cost.cost_owner_code=''TI''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','JOIN','trade_order.strip_summary_ind!=''Y''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','JOIN','trade_order.trade_num=trade.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','JOIN','trade_order.order_type_code = ''EXCHGOPT''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','JOIN','trade_item.order_num=trade_order.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','JOIN','trade_item.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','JOIN','trade_item_exch_opt.item_num=trade_item.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','JOIN','cost.cost_owner_key3=trade_item_exch_opt.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','JOIN','cost.cost_owner_key1=trade_item_exch_opt.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','JOIN','cost.cost_owner_key2=trade_item_exch_opt.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','JOIN','trade_item_exch_opt.order_num=trade_item.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','JOIN','trade_item_exch_opt.trade_num=trade_item.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIExchOptCostCombo','PRIMARY_KEY','cost_num,trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','BASE_CLASSES','Cost,Trade,TradeOrder,TradeItem,TradeItemFut')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','FRONT_LOAD','Cost,Trade,TradeOrder,TradeItem,TradeItemFut')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','JOIN','cost.cost_owner_code=''TI''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','JOIN','trade_order.strip_summary_ind!=''Y''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','JOIN','trade_order.trade_num=trade.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','JOIN','trade_item.order_num=trade_order.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','JOIN','trade_item.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','JOIN','trade_item_fut.item_num=trade_item.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','JOIN','cost.cost_owner_key3=trade_item_fut.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','JOIN','cost.cost_owner_key1=trade_item_fut.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','JOIN','cost.cost_owner_key2=trade_item_fut.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','JOIN','trade_item_fut.order_num=trade_item.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','JOIN','trade_item_fut.trade_num=trade_item.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','JOIN','trade_order.order_type_code in (''FUTURE'',''EFPEXCH'')')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIFutureCostCombo','PRIMARY_KEY','cost_num,trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','BASE_CLASSES','Cost,Trade,TradeOrder,TradeItem,TradeItemOtcOpt')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','FRONT_LOAD','Cost,Trade,TradeOrder,TradeItem,TradeItemOtcOpt')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','cost.cost_owner_code=''TI''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','trade_order.strip_summary_ind!=''Y''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','trade_order.trade_num=trade.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','trade_item.order_num=trade_order.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','trade_item.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','trade_item_otc_opt.item_num=trade_item.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','cost.cost_owner_key3=trade_item_otc_opt.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','cost.cost_owner_key1=trade_item_otc_opt.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','cost.cost_owner_key2=trade_item_otc_opt.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','trade_item_otc_opt.order_num=trade_item.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','trade_item_otc_opt.trade_num=trade_item.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','trade.conclusion_type=''C'' and trade.inhouse_ind=''N''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','JOIN','trade_order.order_type_code in (''OTCAPO'', ''OTCCASH'', ''OTCPHYS'')')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIOtcOptCostCombo','PRIMARY_KEY','cost_num, trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCombo','BASE_CLASSES','Trade,TradeOrder,TradeItem,TradeItemStorage')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCombo','FRONT_LOAD','Trade,TradeOrder,TradeItem,TradeItemStorage')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCombo','JOIN','trade_item.item_type in (''S'')')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCombo','JOIN','trade_order.strip_summary_ind != ''Y'' and (trade_item.item_type != ''R'')')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCombo','JOIN','trade_order.order_num=trade_item.order_num and trade_item.order_num=trade_item_storage.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCombo','JOIN','trade_item.item_num=trade_item_storage.item_num and trade.conclusion_type=''C'' and trade.inhouse_ind=''N''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCombo','JOIN','trade.trade_num=trade_order.trade_num and trade_order.trade_num=trade_item.trade_num and trade_item.trade_num=trade_item_storage.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCombo','PRIMARY_KEY','trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','BASE_CLASSES','Cost,Trade,TradeOrder,TradeItem,TradeItemStorage,Location,LocationExtInfo')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','FRONT_LOAD','Cost,Trade,TradeOrder,TradeItem,TradeItemStorage,Location,LocationExtInfo')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','cost.cost_owner_code=''TI''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','trade_order.trade_num=trade.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','trade_item.order_num=trade_order.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','trade_item.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','trade_order.order_type_code in (''STORAGE'')')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','trade_item_storage.item_num=trade_item.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','cost.cost_owner_key3=trade_item_storage.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','cost.cost_owner_key1=trade_item_storage.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','cost.cost_owner_key2=trade_item_storage.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','trade_item_storage.order_num=trade_item.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','trade_item_storage.trade_num=trade_item.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','trade.conclusion_type=''C'' and trade.inhouse_ind=''N''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','trade_item_storage.storage_loc_code=location.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','trade_item_storage.storage_loc_code=location_ext_info.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','JOIN','trade_order.strip_summary_ind!=''Y'' and (trade_item.item_type!=''R'')')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIStorageCostCombo','PRIMARY_KEY','cost_num,trade_num,order_num,item_num,loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCombo','BASE_CLASSES','Trade,TradeOrder,TradeItem,TradeItemTransport')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCombo','FRONT_LOAD','Trade,TradeOrder,TradeItem,TradeItemTransport')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCombo','JOIN','trade_item.item_type in (''T'') and trade_order.strip_summary_ind != ''Y''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCombo','JOIN','trade_order.order_num=trade_item.order_num and trade_item.order_num=trade_item_transport.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCombo','JOIN','trade_item.item_num=trade_item_transport.item_num and trade.conclusion_type=''C'' and trade.inhouse_ind=''N''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCombo','JOIN','trade.trade_num=trade_order.trade_num and trade_order.trade_num=trade_item.trade_num and trade_item.trade_num=trade_item_transport.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCombo','PRIMARY_KEY','trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','BASE_CLASSES','Cost,Trade,TradeOrder,TradeItem,TradeItemTransport,Location,LocationExtInfo')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','FRONT_LOAD','Cost,Trade,TradeOrder,TradeItem,TradeItemTransport,Location,LocationExtInfo')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','cost.cost_owner_code=''TI''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','trade_order.strip_summary_ind!=''Y''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','trade_order.trade_num=trade.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','trade_item.order_num=trade_order.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','trade_item.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','trade_item_transport.item_num=trade_item.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','cost.cost_owner_key3=trade_item_transport.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','cost.cost_owner_key1=trade_item_transport.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','cost.cost_owner_key2=trade_item_transport.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','trade.conclusion_type=''C'' and trade.inhouse_ind=''N''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','trade_item_transport.order_num=trade_item.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','trade_item_transport.trade_num=trade_item.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','trade_item_transport.load_loc_code=location.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','trade_item_transport.load_loc_code=location_ext_info.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','JOIN','trade_order.order_type_code in (''TRANSPRT'',''PIPELINE'',''TRUCK'',''BARGE'',''RAILCAR'',''VLCC'')')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TITransportCostCombo','PRIMARY_KEY','cost_num,trade_num,order_num,item_num,loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWPLeaseDestinationCombo','FRONT_LOAD','LeaseHead,LeaseDestination')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWPLsePurchCombo','BASE_CLASSES','TradeOrder,TradeItem,TradeItemWetPhy')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWPLsePurchCombo','FRONT_LOAD','TradeOrder,TradeItem,TradeItemWetPhy')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWPLsePurchCombo','JOIN','trade_item.p_s_ind=''P''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWPLsePurchCombo','JOIN','trade_item_wet_phy.del_loc_type=''LES''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWPLsePurchCombo','JOIN','trade_item.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWPLsePurchCombo','JOIN','trade_item_wet_phy.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWPLsePurchCombo','JOIN','trade_order.order_type_code in (''LSEBYSL'', ''LSEEXCH'', ''LSFRACEX'', ''LSFRACPS'', ''LSHLERPS'', ''LSPRCHSL'', ''GNLSPRCH'')')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWPLsePurchCombo','PRIMARY_KEY','trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCombo','BASE_CLASSES','Trade,TradeOrder,TradeItem,TradeItemWetPhy')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCombo','FRONT_LOAD','Trade,TradeOrder,TradeItem,TradeItemWetPhy')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCombo','JOIN','trade_item.item_type in (''W'', ''A'') and trade_order.strip_summary_ind != ''Y''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCombo','JOIN','trade_order.order_num=trade_item.order_num and trade_item.order_num=trade_item_wet_phy.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCombo','JOIN','trade_item.item_num=trade_item_wet_phy.item_num and trade.conclusion_type=''C'' and trade.inhouse_ind=''N''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCombo','JOIN','trade.trade_num=trade_order.trade_num and trade_order.trade_num=trade_item.trade_num and trade_item.trade_num=trade_item_wet_phy.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCombo','PRIMARY_KEY','trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','BASE_CLASSES','Cost,Trade,TradeOrder,TradeItem,TradeItemWetPhy,Location,LocationExtInfo')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','FRONT_LOAD','Cost,Trade,TradeOrder,TradeItem,TradeItemWetPhy,Location,LocationExtInfo')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','trade.inhouse_ind=''N''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','cost.cost_owner_code=''TI''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','trade_order.strip_summary_ind!=''Y''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','trade_item.order_num=trade_order.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','trade_item.trade_num=trade_order.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','trade_item_wet_phy.item_num=trade_item.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','cost.cost_owner_key3=trade_item_wet_phy.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','cost.cost_owner_key1=trade_item_wet_phy.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','cost.cost_owner_key2=trade_item_wet_phy.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','trade_item_wet_phy.del_loc_code=location.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','trade_item_wet_phy.order_num=trade_item.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','trade_item_wet_phy.trade_num=trade_item.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','trade_item_wet_phy.del_loc_code=location_ext_info.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','trade_order.trade_num=trade.trade_num and trade.conclusion_type=''C''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','JOIN','trade_order.order_type_code in (''PHYSICAL'', ''PHYSEXCH'', ''OTCPHYS'', ''PARTIAL'',''RACKBYSL'',''RACKEXCH'', ''RACKPHYS'', ''LSEBYSL'', ''LSEEXCH'',
''LSFRACEX'', ''LSFRACPS'', ''LSHLERPS'', ''LSPRCHSL'', ''GNLSPRCH'', ''PHYSBYSL'')')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TIWetPhyCostCombo','PRIMARY_KEY','cost_num,trade_num,order_num,item_num,loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TVACombo','BASE_CLASSES','TempValueAdjust,Account,LocationGroup,Commodity')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TVACombo','FRONT_LOAD','TempValueAdjust,Account,LocationGroup,Commodity')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TVACombo','JOIN','temp_value_adjust.acct_num=account.acct_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TVACombo','JOIN','temp_value_adjust.cmdty_code=commodity.cmdty_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TVACombo','JOIN','temp_value_adjust.loc_code=location_group.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TVACombo','PRIMARY_KEY','TempValueAdjust,Account,LocationGroup,Commodity')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Tax','DATABASE_KEY','tax_num,tax_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TaxLicenseCombo','BASE_CLASSES','License,LicenseCovers,LicTaxImplication')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TaxLicenseCombo','FRONT_LOAD','License,LicenseCovers,LicTaxImplication')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TaxLicenseCombo','JOIN','license.license_num=license_covers.license_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TaxLicenseCombo','JOIN','license_covers.license_num*=lic_tax_implication.license_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TaxLicenseCombo','JOIN','license_covers.license_covers_num*=lic_tax_implication.license_covers_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TaxLicenseCombo','PRIMARY_KEY','license_num,license_covers_num,tax_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TaxLocationLocCombo','BASE_CLASSES','Location,TaxLocation')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TaxLocationLocCombo','FRONT_LOAD','Location,TaxLocation')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TaxLocationLocCombo','JOIN','location.loc_code=tax_location.loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TaxLocationLocCombo','PRIMARY_KEY','loc_code,tax_auth_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TaxRate','DATABASE_KEY','tax_rate_num,tax_rate_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TempValueAdjustDetail','PRIMARY_KEY','acct_num,loc_code,cmdty_code,date_from,date_to')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeCombo','BASE_CLASSES','Trade,TradeOrder,TradeItem')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeCombo','DEFAULT_SORT','trade.trade_num, trade_order.order_num,trade_item.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeCombo','FRONT_LOAD','Trade,TradeOrder,TradeItem')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeCombo','JOIN','trade.trade_num=trade_order.trade_num and trade_item.trade_num=trade.trade_num and trade_order.order_num = trade_item.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeCombo','PRIMARY_KEY','trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeDefault','COMBINED_COLUMN','quantity,maxQty,max_qty,max_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeDefault','COMBINED_COLUMN','quantity,minQty,min_qty,min_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeDefault','COMBINED_COLUMN','quantity,tolQty,tol_qty,tol_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeDefault','COMBINED_COLUMN','quantity,contrQty,contr_qty,contr_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeDefault','SECONDARY_KEY','acct_num,cmdty_code,del_loc_code,order_type_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItem','COMBINED_COLUMN','price,unitPrice,avg_price,price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItem','COMBINED_COLUMN','quantity,openQty,open_qty,open_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItem','COMBINED_COLUMN','quantity,contrQty,contr_qty,contr_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItem','COMBINED_COLUMN','price,brkrCommAmt,brkr_comm_amt,brkr_comm_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItem','COMBINED_COLUMN','quantity,totalSchQty,total_sch_qty,sch_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItem','COMBINED_COLUMN','quantity,pricedQuantity,total_priced_qty,priced_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemCashPhy','COMBINED_COLUMN','quantity,maxQty,max_qty,max_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemCashPhy','COMBINED_COLUMN','quantity,minQty,min_qty,min_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemCashPhy','COMBINED_COLUMN','quantity,totalSettledQty,total_settled_qty,settled_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemDist','DATABASE_KEY','dist_num,dist_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemExchOpt','COMBINED_COLUMN','price,premium,premium,premium_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemExchOpt','COMBINED_COLUMN','price,strikePrice,strike_price,strike_price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemExchOpt','COMBINED_COLUMN','quantity,totalFillQty,total_fill_qty,fill_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemFill','COMBINED_COLUMN','quantity,fillQty,fill_qty,fill_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemFill','COMBINED_COLUMN','price,fillPrice,fill_price,fill_price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemFut','COMBINED_COLUMN','price,futPrice,fut_price,fut_price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemFut','COMBINED_COLUMN','quantity,totalFillQty,total_fill_qty,fill_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemOtcOpt','COMBINED_COLUMN','price,premium,premium,premium_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemOtcOpt','COMBINED_COLUMN','price,strikePrice,strike_price,strike_price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemStorage','COMBINED_COLUMN','quantity,shrinkageQty,shrinkage_qty,shrinkage_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemStorage','COMBINED_COLUMN','quantity,lossAllowanceQty,loss_allowance_qty,loss_allowance_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemStorage','COMBINED_COLUMN','quantity,minOperatingQty,min_operating_qty,min_operating_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemSubStorage','COMBINED_COLUMN','quantity,storageQty,storage_qty,storage_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemTransport','COMBINED_COLUMN','quantity,maxQty,max_qty,max_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemTransport','COMBINED_COLUMN','quantity,minQty,min_qty,min_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemTransport','COMBINED_COLUMN','quantity,tolQty,tol_qty,tol_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemTransport','COMBINED_COLUMN','price,overrunPrice,overrun_price,overrun_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemTransport','COMBINED_COLUMN','price,dispatchPrice,dispatch_price,dispatch_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemTransport','COMBINED_COLUMN','quantity,minShipQty,min_ship_qty,min_ship_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemTransport','COMBINED_COLUMN','quantity,shrinkageQty,shrinkage_qty,shrinkage_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemTransport','COMBINED_COLUMN','price,demurragePrice,demurrage_price,demurrage_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemTransport','COMBINED_COLUMN','quantity,pumpRateQty,pump_rate_qty,pump_rate_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemTransport','COMBINED_COLUMN','quantity,lossAllowanceQty,loss_allowance_qty,loss_allowance_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemWetPhy','COMBINED_COLUMN','quantity,maxQty,max_qty,max_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemWetPhy','COMBINED_COLUMN','quantity,minQty,min_qty,min_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemWetPhy','COMBINED_COLUMN','quantity,tolQty,tol_qty,tol_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeItemWetPhy','COMBINED_COLUMN','quantity,minShipQty,min_ship_qty,min_ship_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeOrder','COMBINED_COLUMN','price,marginAmt,margin_amt,margin_amt_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeOrderBal','COMBINED_COLUMN','price,balPrice,bal_price,bal_price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeOrderBal','COMBINED_COLUMN','quantity,balMinQty,bal_min_qty,bal_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeOrderOnExch','COMBINED_COLUMN','price,orderPrice,order_price,order_price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradePM','DATABASE_KEY','trade_num,trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradesForSch','COMBINED_COLUMN','quantity,maxQty,max_qty,max_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradesForSch','COMBINED_COLUMN','quantity,minQty,min_qty,min_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradesForSch','COMBINED_COLUMN','quantity,tolQty,tol_qty,tol_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradesForSch','COMBINED_COLUMN','price,unitPrice,avg_price,price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradesForSch','COMBINED_COLUMN','quantity,openQty,open_qty,open_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradesForSch','COMBINED_COLUMN','quantity,contrQty,contr_qty,contr_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradesForSch','COMBINED_COLUMN','price,brkrCommAmt,brkr_comm_amt,brkr_comm_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradesForSch','COMBINED_COLUMN','quantity,minShipQty,min_ship_qty,min_ship_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradesForSch','COMBINED_COLUMN','quantity,totalSchQty,total_sch_qty,total_sch_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradesForSch','COMBINED_COLUMN','quantity,pricedQuantity,total_priced_qty,priced_qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradesForSch','PRIMARY_KEY','trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradingPeriod','DEFAULT_SORT','commkt_key,trading_prd')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('UomConversion','SECONDARY_KEY','uom_code_conv_from,uom_code_conv_to,cmdty_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('UomTest','DEFAULT_SORT','uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('User','SECONDARY_KEY','user_logon_id')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('UserReportGroup','DATABASE_KEY','user_report_group_num,user_report_group_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Voucher','DATABASE_KEY','voucher_num,voucher_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Voucher','DEFAULT_SORT','voucher_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('VoucherApproval','DATABASE_KEY','voucher_approval_num,voucher_approval_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('VoucherCostCombo','BASE_CLASSES','Cost,Voucher')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('VoucherCostCombo','FRONT_LOAD','Cost,Voucher')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('VoucherCostCombo','JOIN','cost.cost_owner_code=''V''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('VoucherCostCombo','JOIN','cost.cost_owner_key1=voucher.voucher_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('VoucherCostCombo','PRIMARY_KEY','cost_num,voucher_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationCostCombo','BASE_CLASSES','Cost,Allocation,Location,LocationExtInfo')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationCostCombo','FRONT_LOAD','Cost,Allocation')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationCostCombo','JOIN','allocation.alloc_num=cost.cost_owner_key1 and cost.cost_owner_code =''A''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationCostCombo','PRIMARY_KEY','cost_num,alloc_num,loc_code,loc_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationActualCostCombo','BASE_CLASSES','Cost,Allocation,AllocationItem,AIEstActual,Trade')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationActualCostCombo','FRONT_LOAD','Cost,Allocation,AllocationItem,AIEstActual,Trade')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationActualCostCombo','JOIN','cost.cost_owner_code=''AA''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationActualCostCombo','JOIN','allocation_item.trade_num=trade.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationActualCostCombo','JOIN','allocation.alloc_num=allocation_item.alloc_num and allocation_item.alloc_num=ai_est_actual.alloc_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationActualCostCombo','JOIN','ai_est_actual.alloc_item_num=cost.cost_owner_key2 and ai_est_actual.ai_est_actual_num=cost.cost_owner_key3')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationActualCostCombo','PRIMARY_KEY','cost_num,alloc_num,alloc_item_num,ai_est_actual_num,trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemCostCombo','BASE_CLASSES','Cost,Allocation,AllocationItem,Trade')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemCostCombo','FRONT_LOAD','Cost,Allocation,AllocationItem,Trade')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemCostCombo','JOIN','cost.cost_owner_code=''AI''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemCostCombo','JOIN','allocation_item.trade_num=trade.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemCostCombo','JOIN','allocation_item.alloc_item_num=cost.cost_owner_key2')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemCostCombo','JOIN','allocation.alloc_num=allocation_item.alloc_num and allocation_item.alloc_num=cost.cost_owner_key1')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('AllocationItemCostCombo','PRIMARY_KEY','cost_num,alloc_num,alloc_item_num,trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CostApproval','DATABASE_KEY','cost_approval_num,cost_approval_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CreditLimitAlarmCombo','BASE_CLASSES','CreditLimit,CreditAlarm')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CreditLimitAlarmCombo','FRONT_LOAD','CreditLimit,CreditAlarm')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CreditLimitAlarmCombo','JOIN','credit_limit.credit_limit_num=credit_alarm.credit_limit_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CreditLimitAlarmCombo','PRIMARY_KEY','credit_limit_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CreditGroup','DATABASE_KEY','group_num,group_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('SimpleFormula','DATABASE_KEY','simple_formula_num,simple_formula_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('ParentGuarantee','DATABASE_KEY','pg_num,pg_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PortfolioBookPl','DATABASE_KEY','book_pl_num,book_pl_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CreditAlarmComment','DATABASE_KEY','alarm_cmnt_num,alarm_cmnt_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CreditLimit','DATABASE_KEY','credit_limit_num,credit_limit_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PostedPriceDetail','PRIMARY_KEY','cmdty_code,price_source_code,mkt_code,price_effect_date')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LcHeadlineComment','DEFAULT_SORT','lc_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LcHeadlineComment','PRIMARY_KEY','lc_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeHeadlineComment','DEFAULT_SORT','trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TradeHeadlineComment','PRIMARY_KEY','trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICostCombo','BASE_CLASSES','Cost,Trade,TradeItem')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICostCombo','FRONT_LOAD','Cost,Trade,TradeItem')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICostCombo','JOIN','trade.trade_num=trade_item.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICostCombo','JOIN','cost.cost_owner_key1=trade_item.trade_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICostCombo','JOIN','cost.cost_owner_key2=trade_item.order_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICostCombo','JOIN','cost.cost_owner_key3=trade_item.item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICostCombo','JOIN','cost.cost_owner_code=''TI''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICostCombo','JOIN','trade.conclusion_type=''C''')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICostCombo','JOIN','cost.cost_credit_ind in (''C'',''N'',''S'',NULL)')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('TICostCombo','PRIMARY_KEY','cost_num,trade_num,order_num,item_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LcAllocationCombo','BASE_CLASSES','Lc,LcAllocation')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LcAllocationCombo','FRONT_LOAD','Lc,LcAllocation')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LcAllocationCombo','PRIMARY_KEY','lc_num,lc_alloc_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('LcAllocationCombo','JOIN','lc.lc_num=lc_allocation.lc_num')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('IctsUser','SECONDARY_KEY','user_logon_id')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Position','COMBINED_COLUMN','price,avgPurchPrice,avg_purch_price,price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Position','COMBINED_COLUMN','price,avgSalePrice,avg_sale_price,price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Position','COMBINED_COLUMN','price,rtAvgSalePrice,rt_avg_sale_price,price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Position','COMBINED_COLUMN','price,rtAvgPurchPrice,rt_avg_purch_price,price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Position','COMBINED_COLUMN','quantity,shortQty,short_qty,qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Position','COMBINED_COLUMN','quantity,priceQty,priced_qty,qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('Position','COMBINED_COLUMN','quantity,longQty,long_qty,qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PositionEod','COMBINED_COLUMN','price,avgPurchPrice,avg_purch_price,price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PositionEod','COMBINED_COLUMN','price,avgSalePrice,avg_sale_price,price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PositionEod','COMBINED_COLUMN','price,rtAvgPurchPrice,rt_avg_purch_price,price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PositionEod','COMBINED_COLUMN','price,rtAvgSalePrice,rt_avg_sale_price,price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PositionEod','COMBINED_COLUMN','quantity,longQty,long_qty,qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PositionEod','COMBINED_COLUMN','quantity,priceQty,priced_qty,qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PositionEod','COMBINED_COLUMN','quantity,shortQty,short_qty,qty_uom_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('PositionMarkToMarket','COMBINED_COLUMN','price,mtmMktPrice,mtm_mkt_price,mtm_mkt_price_curr_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('MarketsAttached','PRIMARY_KEY','mkt_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CommoditysAttached','PRIMARY_KEY','cmdty_code')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('IctsTransaction','DROP_COLUMN','sequence')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('OTCOptionValue','SECONDARY_KEY','otc_opt_code,otc_opt_quote_date')
go
INSERT INTO dbo.object_directives(object_class,directive,data)
                      VALUES('CostExtInfo','DATABASE_KEY','cost_num,cost_num')
go

SETUSER
go
