set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table order_type_grp_desc
go

print 'Loading system reference data into the order_type_grp_desc table ...'
go

insert into dbo.order_type_grp_desc 
   values('DERIV', 'Derivative Trades (Currently only SWAPS)', 1)
go

insert into dbo.order_type_grp_desc 
   values('NA', 'Not applicable (for credit)', 1)
go

insert into dbo.order_type_grp_desc 
   values('OPTION', 'Option Trades', 1)
go

insert into dbo.order_type_grp_desc 
   values('OTHER', 'Other Unclassifiable Trades', 1)
go

insert into dbo.order_type_grp_desc 
   values('PHYSICAL', 'Physical Trades', 1)
go

insert into dbo.order_type_grp_desc 
   values('RACK', 'Rack Orders', 1)
go

insert into dbo.order_type_grp_desc 
   values('STORAGE', 'Storage Trades', 1)
go

insert into dbo.order_type_grp_desc 
   values('SWAP', 'Swap Trades', 1)
go

insert into dbo.order_type_grp_desc 
   values('TRANSP', 'Transportation Trades', 1)
go

