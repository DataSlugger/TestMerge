set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table alias
go

print 'Loading system reference data into the alias table ...'
go

insert into dbo.alias 
   values('account', 'acct_num', 'acct_short_name', 'Account Name', NULL, 1)
go

insert into dbo.alias 
   values('account_and_group', 'acct_num', 'acct_short_name', 'Account Name', NULL, 1)
go

insert into dbo.alias 
   values('account_and_group', 'related_acct_num', 'acct_short_name', 'Account Group', NULL, 1)
go

insert into dbo.alias 
   values('account_for_broker', 'acct_num', 'acct_short_name', 'Broker', NULL, 1)
go

insert into dbo.alias 
   values('account_for_tax_authority', 'acct_num', 'acct_short_name', 'Issued By', NULL, 1)
go

insert into dbo.alias 
   values('account_with_tax_license', 'acct_num', 'acct_short_name', 'Issued To', NULL, 1)
go

insert into dbo.alias 
   values('actual_detail', 'transporter_code', 'transporter_code', 'Transporter Code', NULL, 1)
go

insert into dbo.alias 
   values('allocation_type', 'alloc_type_code', 'alloc_type_desc', 'alloc_type_desc', NULL, 1)
go

insert into dbo.alias 
   values('commodity', 'cmdty_code', 'cmdty_short_name', 'Commodity', NULL, 1)
go

insert into dbo.alias 
   values('commodity', 'prim_curr_code', NULL, 'Currency', NULL, 1)
go

insert into dbo.alias 
   values('commodity_and_group', 'cmdty_code', 'cmdty_short_name', 'Commodity', NULL, 1)
go

insert into dbo.alias 
   values('commodity_and_group', 'parent_cmdty_code', 'cmdty_full_name', 'Commodity Group', NULL, 1)
go

insert into dbo.alias 
   values('commodity_and_group', 'prim_curr_code', NULL, 'Currency', NULL, 1)
go

insert into dbo.alias 
   values('contract_status', 'contr_status_code', 'contr_status_desc', 'Contract Status', NULL, 1)
go

insert into dbo.alias 
   values('cost_book_comp_view', 'acct_num', 'acct_short_name', 'Booking Company', NULL, 1)
go

insert into dbo.alias 
   values('cost_code_search_view', 'cmdty_code', 'cmdty_code', 'Cost Code', NULL, 1)
go

insert into dbo.alias 
   values('cost_counterparty_view', 'acct_num', 'acct_short_name', 'CounterParty', NULL, 1)
go

insert into dbo.alias 
   values('cost_cur_code_search_view', 'cmdty_code', 'cmdty_short_name', 'Currency Code', NULL, 1)
go

insert into dbo.alias 
   values('cost_owner', 'cost_owner_code', 'cost_owner_code', 'Cost Owner Code', NULL, 1)
go

insert into dbo.alias 
   values('cost_owner_search_view', 'cost_owner_code', 'bc_owner_full_name', 'Cost Owner Code', NULL, 1)
go

insert into dbo.alias 
   values('cost_pay_rec_view', 'cost_pay_rec_ind', 'cost_pay_rec_ind', 'Payable/Receivable', NULL, 1)
go

insert into dbo.alias 
   values('cost_price_est_actual_view', 'cost_price_est_actual_ind', 'cost_price_est_actual_ind', 
          'Cost Price Est Actual', NULL, 1)
go

insert into dbo.alias 
   values('cost_qty_est_actual_view', 'cost_qty_est_actual_ind', 
          'cost_qty_est_actual_ind', 'Cost Qty Est Actual', NULL, 1)
go

insert into dbo.alias 
   values('cost_status', 'cost_status_code', 'cost_status_code', 'Cost Status', NULL, 1)
go

insert into dbo.alias 
   values('cost_type', 'cost_type_code', 'cost_type_code', 'Cost Type', NULL, 1)
go

insert into dbo.alias 
   values('cost_type_search_view', 'cost_type_code', 'cost_type_desc', 'Cost Type', NULL, 1)
go

insert into dbo.alias 
   values('country', 'country_code', 'country_name', 'Country', NULL, 1)
go

insert into dbo.alias 
   values('credit_term', 'credit_term_code', 'credit_term_code', 'Credit Terms', NULL, 1)
go

insert into dbo.alias 
   values('delivery_term', 'del_term_code', 'del_term_code', 'Delivery Terms', NULL, 1)
go

insert into dbo.alias 
   values('department', 'dept_code', 'dept_name', 'Department', NULL, 1)
go

insert into dbo.alias 
   values('desk', 'desk_code', 'desk_name', 'Desk', NULL, 1)
go

insert into dbo.alias 
   values('gl_account_validity', 'acct_code', 'acct_descr', 'GL Account Codes', NULL, 1)
go

insert into dbo.alias 
   values('icts_user', 'desk_code', 'desk_code', 'DESK', NULL, 1)
go

insert into dbo.alias 
   values('icts_user', 'loc_code', 'loc_code', 'LOCATION', NULL, 1)
go

insert into dbo.alias 
   values('icts_user', 'mngr_init', 'user_last_name', 'Manager ID', NULL, 1)
go

insert into dbo.alias 
   values('icts_user', 'user_init', 'user_last_name', 'User ID', 'user_last_name + '', '' + user_first_name', 1)
go

insert into dbo.alias 
   values('lc_status', 'lc_status_code', 'lc_status_short_name', 'LC Status', NULL, 1)
go

insert into dbo.alias 
   values('lc_type', 'lc_type_code', 'lc_type_short_name', 'LC Type', NULL, 1)
go

insert into dbo.alias 
   values('location', 'loc_code', 'loc_name', 'Location', NULL, 1)
go

insert into dbo.alias 
   values('location_name_view', 'loc_name', 'loc_name', 'Location Name', NULL, 1)
go

insert into dbo.alias 
   values('market', 'mkt_code', 'mkt_short_name', 'Market', NULL, 1)
go

insert into dbo.alias 
   values('mot', 'mot_code', 'mot_short_name', 'Method of Transport', NULL, 1)
go

insert into dbo.alias 
   values('order_type', 'order_type_code', 'order_type_desc', 'Order Type', NULL, 1)
go

insert into dbo.alias 
   values('payment_term', 'pay_term_code', 'pay_term_code', 'Payment Terms', NULL, 1)
go

insert into dbo.alias 
   values('portfolio', 'port_num', 'port_alias_name', 'TPS Acct - Port Num', 
          'port_alias_name + ''--'' + convert(varchar(12), portfolio.port_num)', 1)
go

insert into dbo.alias 
   values('state', 'state_code', 'state_code', 'State Code', NULL, 1)
go

insert into dbo.alias 
   values('tax_authority', 'acct_num', 'acct_short_name', 'Tax Authority', NULL, 1)
go

insert into dbo.alias 
   values('tax_code', 'tax_code', 'tax_code', 'TAX TYPE', 'tax_code_desc', 1)
go

insert into dbo.alias 
   values('tax_license_view', 'acct_num', 'acct_num', 'Issued To', NULL, 1)
go

insert into dbo.alias 
   values('tax_license_view', 'issuing_tax_authority_num', 'issuing_tax_authority_num', 'Issued By', NULL, 1)
go

insert into dbo.alias 
   values('trade_book_comp_view', 'acct_num', 'acct_short_name', 'Booking Company', NULL, 1)
go

insert into dbo.alias 
   values('trade_item_wet_phy', 'trade_num', 'trade_num', 'Trade Number', NULL, 1)
go

insert into dbo.alias 
   values('trade_port_view', 'real_port_num', 'real_port_num', 'Portfolio Number', NULL, 1)
go

