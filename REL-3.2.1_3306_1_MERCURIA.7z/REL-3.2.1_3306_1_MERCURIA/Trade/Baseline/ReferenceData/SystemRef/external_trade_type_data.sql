set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the external_trade_type table ...'
go

create table dbo.#external_trade_type
(
   oid                        int identity not null ,
   external_trade_source_oid 	int	not null,
   trade_type_code		        varchar(25)  not null,
   trade_type_name		        varchar(150) not null
)
go

declare @external_trade_source_oid	int,
        @trade_type_code		        varchar(25),
        @trade_type_name		        varchar(150),
        @oid				                int,
        @newoid				              int,
        @trans_id                   int,
        @rows_affected              int,
        @total_rows_added           int,
        @errcode                    int

   select @external_trade_source_oid = oid 
   from dbo.external_trade_source 
   where external_trade_src_name = 'NYMEX'

   if @external_trade_source_oid is not null
	 begin
		  insert into dbo.#external_trade_type 
		       (external_trade_source_oid, trade_type_code, trade_type_name)
		   values(@external_trade_source_oid, '0', 'CME-Regular Trade'),
		         (@external_trade_source_oid, '1', 'CME-Block Trade'),
		         (@external_trade_source_oid, '2', 'CME-EFP Trade'),
		         (@external_trade_source_oid, '3', 'CME-Transfer'),
		         (@external_trade_source_oid, '11', 'CME-EFR Trade'),
		         (@external_trade_source_oid, '12', 'CME-EFS Trade'),
		         (@external_trade_source_oid, '22', 'CME-OTC Privately Negotiated Trades'),
		         (@external_trade_source_oid, '23', 'CME-Substitution of Futures for Forwards'),
		         (@external_trade_source_oid, '48', 'CME-Non-standard settlement'),
				 (@external_trade_source_oid, 'EFP', 'CME-EFP Trade');
   end
   else
	 begin
		  print 'There exists No ''NYMEX'' source name in external_trade_source table'
	 end

   set @external_trade_source_oid = NULL

   select @external_trade_source_oid = oid 
   from dbo.external_trade_source 
   where external_trade_src_name = 'ICE'
   if @external_trade_source_oid is not null
	 begin
		  insert into dbo.#external_trade_type 
		      (external_trade_source_oid, trade_type_code, trade_type_name)
		   values(@external_trade_source_oid, '0', 'ICE-Regular Trade'),
		         (@external_trade_source_oid, 'K', 'ICE-Block Trade'),
		         (@external_trade_source_oid, 'E', 'ICE-EFP Trade'),
		         (@external_trade_source_oid, 'J', 'ICE-EFR Trade'),
		         (@external_trade_source_oid, 'S', 'ICE-EFS Trade'),
		         (@external_trade_source_oid, 'V', 'ICE-Bilateral Off-Exchange Trade'),
		         (@external_trade_source_oid, 'O', 'ICE-NG EFP/EFS Trade'),
		         (@external_trade_source_oid, '9', 'ICE-CCX EFP Trade'),
		         (@external_trade_source_oid, 'T', 'ICE-Contra Trade'),
		         (@external_trade_source_oid, 'Y', 'ICE-Cross Contra Trade'),
		         (@external_trade_source_oid, 'F', 'ICE-EFS/EFP Contra Trade'),
		         (@external_trade_source_oid, 'Q', 'ICE-Exchange Of Options'),
		         (@external_trade_source_oid, 'I', 'ICE-Exchange of Futures for (Related) Market'),
		         (@external_trade_source_oid, 'A', 'ICE-Other Clearing Venue');
   end
   else
   begin
      print 'There exists No ''ICE'' source name in external_trade_source table'
   end
	
   set @external_trade_source_oid = NULL

   select @external_trade_source_oid = oid 
   from dbo.external_trade_source 
   where external_trade_src_name = 'Excel'
   if @external_trade_source_oid is not null
	 begin
		  insert into dbo.#external_trade_type 
		     (external_trade_source_oid, trade_type_code, trade_type_name)
		   values(@external_trade_source_oid,'EF','Exchange Future'),
		         (@external_trade_source_oid,'EO','Exchange Option'),
		         (@external_trade_source_oid,'OP','OTC Physical'),
		         (@external_trade_source_oid,'OPF','PTC Physical Formula'),
		         (@external_trade_source_oid,'OSF','OTC Fixed Swap'),
		         (@external_trade_source_oid,'OSL','OTC Float Swap'),
		         (@external_trade_source_oid,'OE','OTC European Swap'),
		         (@external_trade_source_oid,'OA','OTC American Swap'),
		         (@external_trade_source_oid,'OS','OTC Asian Swap');
   end
   else
   begin
      print 'There exists No ''Excel'' source name in external_trade_source table'
   end

   print 'Adding ref data into the external_trade_type table ...'





/* The code below is used to add records into the external_trade_type table */

set @total_rows_added = 0
set @errcode = 0
set @rows_affected = 0

set @trans_id = null
begin try
  exec dbo.gen_new_transaction_NOI @app_name = 'issue_1374445'
end try
begin catch
  print '=> Failed to execuate the stored procedure ''gen_new_transaction_NOI'' to add an incts_transaction record due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  set @errcode = ERROR_NUMBER()
  goto endofscript
end catch

select @trans_id = last_num
from dbo.icts_trans_sequence
where oid = 1

if @trans_id is null
begin
   print '=> Unable to obtain a valid trans_id for the insert operation!'
   set @errcode = 1
   goto endofscript
end

select @oid = min(oid)
from #external_trade_type

select  @newoid = isnull(max(oid), 0)
from external_trade_type

while @oid is not null
begin
   select @external_trade_source_oid = external_trade_source_oid,
          @trade_type_code = trade_type_code,
          @trade_type_name = trade_type_name 
   from dbo.#external_trade_type 
   where oid = @oid

   if not exists (select 1
                  from dbo.external_trade_type
                  where external_trade_source_oid = @external_trade_source_oid and
                        trade_type_code = @trade_type_code and
                        trade_type_name = @trade_type_name)
   begin
      begin try
        insert into dbo.external_trade_type 
               (oid,external_trade_source_oid,trade_type_code,trade_type_name, trans_id)
           values(@newoid+@oid, @external_trade_source_oid, @trade_type_code, @trade_type_name, @trans_id)
        set @rows_affected = @@rowcount 
      end try
      begin catch
        print '=> Failed to add a new external_trade_type due to the error:'
        print '==> ERROR: ' + ERROR_MESSAGE()
        set @errcode = ERROR_NUMBER()
        goto endofscript
      end catch
      print '=> The new trade type name ''' + @trade_type_name + ''' was added successfully!'
      select @total_rows_added = @total_rows_added + @rows_affected
   end 
   else
   begin
      print '=> The trade type name ''' + @trade_type_name + ''' has existed in table already!'  
   end
   
   select @oid = min(oid)
   from dbo.#external_trade_type
   where oid > @oid
end

endofscript:
if @errcode = 0
begin
   if @total_rows_added > 0
      print '=> There are ' + cast(@total_rows_added as varchar) + ' records added into the external_trade_type table.'
   else
      print '=> No records were added into the external_trade_type table.'   
end

drop table dbo.#external_trade_type
go

exec dbo.refresh_a_last_num 'external_trade_type', 'oid'
go