set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table contract_status
go

print 'Loading system reference data into the contract_status table ...'
go

insert into dbo.contract_status 
   values('CONF', 'Telex receipt confirmed by counterparty', 1)
go

insert into dbo.contract_status 
   values('DELETED', 'Deleted', 1)
go

insert into dbo.contract_status 
   values('FAX', 'Sent Via Other Fax', 1)
go

insert into dbo.contract_status 
   values('HARDCOPY', 'Sent Via Other Hardcopy', 1)
go

insert into dbo.contract_status 
   values('HOLD', 'Contract is on telex hold', 1)
go

insert into dbo.contract_status 
   values('IFAX', 'Sent Via ICTS Fax', 1)
go

insert into dbo.contract_status 
   values('IHARDCPY', 'Sent Via ICTS Hardcopy', 1)
go

insert into dbo.contract_status 
   values('INACTIVE', 'Inactive', 1)
go

insert into dbo.contract_status 
   values('ITELEX', 'Sent Via ICTS Telex', 1)
go

insert into dbo.contract_status 
   values('IWIRE', 'Sent Via ICTS Wire', 1)
go

insert into dbo.contract_status 
   values('NEW', 'New', 1)
go

insert into dbo.contract_status 
   values('RESENT', 'To Be Resent', 1)
go

insert into dbo.contract_status 
   values('REVIEW', 'Please Review', 1)
go

insert into dbo.contract_status 
   values('TELEX', 'Sent Via Other Telex', 1)
go

insert into dbo.contract_status 
   values('TRADEMOD', 'Trade Modified', 1)
go

insert into dbo.contract_status 
   values('UNCONF', 'Telex receipt unconfirmed by counterpart', 1)
go

insert into dbo.contract_status 
   values('UNSENT', 'Unsent', 1)
go

insert into dbo.contract_status 
   values('WIRE', 'Sent Via Other Wire', 1)
go

insert into dbo.contract_status 
   values('CRREVIEW', 'Review Credit Term', 1)
go

insert into dbo.contract_status 
   values('eConPend', 'Trade sent to ICE via K3', 1)
go

insert into dbo.contract_status 
   values('eConfirm', 'eConfirm Trade', 1)
go

insert into dbo.contract_status 
   values('CP-EMAIL', 'CONFIRM HAS BEEN GENERATE/SENT VIA EMAIL', 1)
go

insert into dbo.contract_status 
   values('CP-FAX', 'CONFIRM HAS BEEN GENERATE/SENT VIA FAX', 1)
go

insert into dbo.contract_status 
   values('EXECUTED', 'EXECUTED', 1)
go

insert into dbo.contract_status 
   values('RVWDOPS', 'RVWDOPS', 1)
go

insert into dbo.contract_status 
   values('I-MATCH', 'I-MATCH', 1)
go