set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table lc_usage
go

print 'Loading system reference data into the lc_usage table ...'
go

insert into dbo.lc_usage 
     (lc_usage_code, lc_usage_short_name, lc_usage_desc, trans_id)
   values('NONE', 'NONE', 'NONE', 1)
go

insert into dbo.lc_usage 
     (lc_usage_code, lc_usage_short_name, lc_usage_desc, trans_id)
   values('FLDERIV', 'First Line Deri', 'First Line Derivative', 1)
go

insert into dbo.lc_usage 
     (lc_usage_code, lc_usage_short_name, lc_usage_desc, trans_id)
   values('FLPHYS', 'First Line Phys', 'First Line Physical', 1)
go

insert into dbo.lc_usage 
     (lc_usage_code, lc_usage_short_name, lc_usage_desc, trans_id)
   values('SLPHYS', 'Sec Line Phys', 'Second Line Physical', 1)
go
