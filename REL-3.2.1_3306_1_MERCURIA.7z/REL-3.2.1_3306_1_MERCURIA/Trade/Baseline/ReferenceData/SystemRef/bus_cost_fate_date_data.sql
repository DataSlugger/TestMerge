set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bus_cost_fate_date
go

print 'Loading system reference data into the bus_cost_fate_date table ...'
go

insert into dbo.bus_cost_fate_date 
   values('DD', 'DUE_DATE', 'DUE DATE', 1)
go

insert into dbo.bus_cost_fate_date 
   values('EOD', 'END OF DAY', 'END OF DAY', 1)
go

insert into dbo.bus_cost_fate_date 
   values('EOM', 'END OF MONTH', 'END OF MONTH', 1)
go

insert into dbo.bus_cost_fate_date 
   values('EOY', 'END OF YEAR', 'END OF YEAR', 1)
go

insert into dbo.bus_cost_fate_date 
   values('IMMED', 'IMMEDIATE', 'IMMEDIATE', 1)
go

