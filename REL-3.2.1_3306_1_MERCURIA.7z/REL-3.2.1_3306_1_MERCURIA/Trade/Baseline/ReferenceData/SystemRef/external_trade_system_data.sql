set nocount on

set QUOTED_IDENTIFIER ON
go

print ' '
print 'Loading system reference data into the external_trade_system table ...'
go

create table #exttradesystem
(
   external_trade_system_name varchar(40) not null primary key,
   oid                        int null
)
go

insert into #exttradesystem values('Exchange Tools', 0)
insert into #exttradesystem values('ExchangeTools', 0)
insert into #exttradesystem values('Other', 0)
go

print '=> Saving the existing oid ...'
go

if (select count(*) from dbo.external_trade_system) > 0
begin
   update #exttradesystem
   set oid = (select isnull(oid, 0)
              from dbo.external_trade_system a
              where #exttradesystem.external_trade_system_name = a.external_trade_system_name)
              
   update #exttradesystem
   set oid = 0
   where oid is null  
end
go

print '=> Adding new entries ...'
go

declare @rows_affected              int,
        @newoid                     int,
        @external_trade_system_name varchar(40)
        
select @external_trade_system_name = min(external_trade_system_name)
from #exttradesystem
where oid = 0

while @external_trade_system_name is not null
begin
	 begin tran
	 select @newoid = isnull(max(oid), 0) + 1
	 from dbo.external_trade_system
	 
	 print '=> Adding the external_trade_system_name ''' + @external_trade_system_name + ''' ...'
   begin try
	   insert into dbo.external_trade_system 
	        (oid, external_trade_system_name, trans_id)
	      values(@newoid, @external_trade_system_name, 1)
	   select @rows_affected = @@rowcount
	 end try
	 begin catch
	 	  print '==> Failed to add a new external_trade_system record due to the error:'
	 	  print '===> ERROR: ' + ERROR_MESSAGE()
	 	  if @@trancount > 0
	 	     rollback tran
	 	  goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
      print '=> A new external_trade_system record was added successfully'

   select @external_trade_system_name = min(external_trade_system_name)
   from #exttradesystem
   where oid = 0 and
         external_trade_system_name > @external_trade_system_name
end
endofscript:
drop table #exttradesystem
go


