set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into umpire_rule table .. '
go

create table #umpire_rule
(
   
   short_desc	varchar(50),
   long_desc  varchar(250)
)

insert into #umpire_rule
select null,'Umpire between= Mean of umpire + nearer, Umpire outside = middle of 3'
union all
select null,'Umpire between = mean of umpire + nearer, umpire outside = umpire result'
union all
select null,'Umpire between = mean of umpire + nearer, umpire outside = mean of three'
union all
select null,'Umpire Between = umpinre is final, umpire outside = mean umpire + nearer'
union all
select null,'Umpire between = umpire is final, umpire outside = nearest to umpire' 
union all
select null,'Umpire between = umpire is final, umpire outside = mean of exchanged and received assays' 
union all
select null,'Umpire between = mean of umpire + nearest, Umpire =exact mean of exchanged assays = umpire, umpire outside = middle of three' 
union all
select null,'Umpire is mean of exchanged assays umpire is final otherwise use nearest to umpire' 
union all
select null,'Mean of umpire and nearer' 
union all
select null,'Middle of 3' 
union all
select null,'Mean of three' 
union all
select null,'Umpire'

declare @transId int,
        @rows_affected int

exec gen_new_transaction_NOI @app_name = 'DBIsuue #ADSO-938'
select @transId = last_num from icts_trans_sequence

begin tran
begin try
	insert into dbo.umpire_rule(short_desc,long_desc,trans_id)
	select short_desc, long_desc, @transId 
	from #umpire_rule 
	where long_desc not in ( select long_desc from umpire_rule )
	select @rows_affected = @@rowcount
end try
begin catch
	if @@trancount > 0
		rollback tran 
	print '==> Failed to insert records into umpire_rule table'
	print ERROR_MESSAGE()
	goto endofscript
end catch
commit tran
if @rows_affected > 0
	print '==> ' + convert(varchar(10),@rows_affected) + ' Records added into umpire_rule table successfully !'

endofscript:
drop table #umpire_rule
go