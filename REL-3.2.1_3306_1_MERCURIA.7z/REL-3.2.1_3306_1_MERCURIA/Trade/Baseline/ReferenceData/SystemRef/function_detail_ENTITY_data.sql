/* ****************************************************************
    function_detail_ENTITY_data.sql

    This db script populates the ENTITY data for some functions 
    which requires ENTITY data setup into the 'function_detail'
    table: 


    For each of the following function_nums

       function_num   app_name            function_name
       ------------   ------------------  --------------
                606   Allocation          APPROVE_COST
                607   Allocation          ADD_COST
                608   Allocation          UPDATE_COST
                609   Allocation          DELETE_COST
                255   CommAccount         APPROVE_COST 
                256   CommAccount         ADD_ADDLAX_COST
                257   CommAccount         UPDATE_ADDLAX_COST
                258   CommAccount         DELETE_ADDLAX_COST

    add 2 records into the function_detail table:
       record #1
          fd_id        : <new fd_id obtained from new_num table>
          function_num : in (255, 256, 257, 258, 606, 607, 608, 609)
          entity_name  : Cost
          attr_name    : costBookCompNum
          operation    : '='
          entity_ind   : 1

       record #2
          fd_id        : <new fd_id obtained from new_num table>
          function_num : in (255, 256, 257, 258, 606, 607, 608, 609)
          entity_name  : Cost
          attr_name    : costCode
          operation    : '='
          entity_ind   : 1

    Author     : Peter Lo
    Date       : 09/04/2007
    Database   : MS SQL Server 2000 or later
    Company    : Amphora, Inc
   **************************************************************** */

set nocount on

set QUOTED_IDENTIFIER ON
go

print ' '
print 'Adding function_detail (ENTITY) records for following function(s) ...'
print '  APPROVE_COST (Allocation),'
print '  ADD_COST (Allocation),'
print '  UPDATE_COST (Allocation),'
print '  DELETE_COST (Allocation),'
print '  APPROVE_COST (CommAccount),'
print '  ADD_ADDLAX_COST (CommAccount),'
print '  UPDATE_ADDLAX_COST (CommAccount),' 
print '  DELETE_ADDLAX_COST (CommAccount)'
print ' '
go

create table #functions
(  
   function_num     int
)
go

insert into #functions (function_num)
select distinct function_num
from dbo.icts_function
where app_name = 'Allocation' and
      function_name in ('APPROVE_COST', 'ADD_COST', 'UPDATE_COST', 'DELETE_COST')
go

insert into #functions (function_num)
select distinct function_num
from dbo.icts_function
where app_name = 'CommAccount' and
      function_name in ('APPROVE_COST', 'ADD_ADDLAX_COST', 'UPDATE_ADDLAX_COST', 'DELETE_ADDLAX_COST')
 

if (select count(*) from #functions) <> 8
begin
   print 'ERROR: Missing the following function(s) in icts_function table:'
   print '  APPROVE_COST (Allocation),'
   print '  ADD_COST (Allocation),'
   print '  UPDATE_COST (Allocation),'
   print '  DELETE_COST (Allocation),'
   print '  APPROVE_COST (CommAccount),'
   print '  ADD_ADDLAX_COST (CommAccount),'
   print '  UPDATE_ADDLAX_COST (CommAccount),' 
   print '  DELETE_ADDLAX_COST (CommAccount)'
   goto exitscript
end

declare @function_num      int,
        @fd_id             int,
        @total_rows_added  int,
        @rows_added        int,
        @errcode           int,
        @smsg              varchar(255)

select @errcode = 0

select @function_num = min(function_num)
from #functions

while @function_num is not null
begin
   select @smsg = '=> function_detail (ENTITY): function_num #' + convert(varchar, @function_num) + ' ...'
   print @smsg

   select @total_rows_added = 0,
          @rows_added = 0
   begin tran
   if not exists (select 1
                  from dbo.function_detail
                  where function_num = @function_num and
                        entity_name = 'Cost' and
                        attr_name = 'costBookCompNum' and
                        operation = '=')
   begin
      select @fd_id = isnull(max(fd_id), 0) + 1
      from dbo.function_detail
      insert into dbo.function_detail
        (fd_id,function_num,entity_name,attr_name,operation,entity_ind,trans_id)
       values(@fd_id, @function_num, 'Cost', 'costBookCompNum', '=', 1, 1)
      select @rows_added = @@rowcount,
             @errcode = @@error
      if @errcode > 0
      begin
         rollback tran
         break
      end
      if @rows_added > 0
      begin
          select @smsg = '=> function_detail (Cost - costBookCompNum): added fd_id #' + convert(varchar, @fd_id)
          print @smsg
      end
   end

   select @total_rows_added = @total_rows_added + @rows_added
   if not exists (select 1
                  from dbo.function_detail
                  where function_num = @function_num and
                        entity_name = 'Cost' and
                        attr_name = 'costCode' and
                        operation = '=')
   begin
      select @fd_id = isnull(max(fd_id), 0) + 1
      from dbo.function_detail
      insert into dbo.function_detail
        (fd_id,function_num,entity_name,attr_name,operation,entity_ind,trans_id)
       values(@fd_id, @function_num, 'Cost', 'costCode', '=', 1, 1)
       select @rows_added = @@rowcount,
              @errcode = @@error
       if @errcode > 0
       begin
          rollback tran
          break
      end
       if @rows_added > 0
       begin
          select @smsg = '=> function_detail (Cost - costCode): added fd_id #' + convert(varchar, @fd_id)
          print @smsg
      end
   end
   select @total_rows_added = @total_rows_added + @rows_added
   if @total_rows_added > 0
      commit tran
   else
      rollback tran

   select @function_num = min(function_num)
   from #functions
   where function_num > @function_num
end /* while */
endofscript:
if @errcode = 0 and @total_rows_added > 0
   print 'ENTITY (Allocation, CommAccount) records were successfully added into function_detail table!'
exitscript:
go

if object_id('tempdb..#functions', 'U') is not null
   exec('drop table #functions')
go

/* ------------------------------------------------------------------------
    For each of the following function_nums

       function_num   app_name            function_name
       ------------   ------------------  --------------
               3000   SAPSelect           ARCHIVE
               3001   SAPSelect           HIDE
               3002   SAPSelect           DELETE
               3003   SAPSelect           MARK  
               3004   SAPSelect           VIEW

    add 5 records into the function_detail table:
       record #1
          fd_id        : <new fd_id obtained from new_num table>
          function_num : 3000, 3001, 3002, 3003, 3004
          entity_name  : 'send_to_SAP'
          attr_name    : 'interface'
          operation    : '='
          entity_ind   : 1
   ------------------------------------------------------------------------ */

print ' '
print 'Adding 5 function_detail (ENTITY) records for following functions ...'
print '  ARCHIVE (SAPSelect),'
print '  HIDE (SAPSelect),'
print '  DELETE (SAPSelect),'
print '  MARK (SAPSelect),'
print '  VIEW (SAPSelect)'
print ' '
go

create table #functions
(  
   function_num     int
)
go

insert into #functions (function_num)
select distinct function_num
from dbo.icts_function
where app_name = 'SAPSelect' and
      function_name in ('ARCHIVE', 'HIDE', 'DELETE', 'MARK', 'VIEW')
go

if (select count(*) from #functions) <> 5
begin
   print 'ERROR: Missing the following function(s) in icts_function table:'
   print '  ARCHIVE (SAPSelect),'
   print '  HIDE (SAPSelect),'
   print '  DELETE (SAPSelect),'
   print '  MARK (SAPSelect),'
   print '  VIEW (SAPSelect)'
   goto exitscript
end

declare @function_num      int,
        @fd_id             int,
        @total_rows_added  int,
        @rows_added        int,
        @errcode           int,
        @smsg              varchar(255)

select @errcode = 0,
       @total_rows_added = 0

select @function_num = min(function_num)
from #functions

while @function_num is not null
begin
   select @smsg = '=> function_detail (ENTITY): function_num #' + convert(varchar, @function_num) + ' ...'
   print @smsg

   select @rows_added = 0
   if not exists (select 1
                  from dbo.function_detail
                  where function_num = @function_num and
                        entity_name = 'send_to_SAP' and
                        attr_name = 'interface' and
                        operation = '=')
   begin
      begin tran
      select @fd_id = isnull(max(fd_id), 0) + 1
      from dbo.function_detail

      insert into dbo.function_detail
        (fd_id,function_num,entity_name,attr_name,operation,entity_ind,trans_id)
       values(@fd_id, @function_num, 'send_to_SAP', 'interface', '=', 1, 1)
      select @rows_added = @@rowcount,
             @errcode = @@error
      if @errcode > 0 or @rows_added = 0
      begin
         rollback tran
         if @errcode > 0
            break
      end
      else
      begin
         commit tran
         select @total_rows_added = @total_rows_added + @rows_added
         select @smsg = '=> function_detail (send_to_SAP - interface): added fd_id #' + convert(varchar, @fd_id)
         print @smsg
      end
   end

   select @function_num = min(function_num)
   from #functions
   where function_num > @function_num
end /* while */
endofscript:
if @errcode = 0 and @total_rows_added > 0
   print 'ENTITY (send_to_SAP) record was successfully added into the function_detail table!'
exitscript:
go

if object_id('tempdb..#functions', 'U') is not null
   exec('drop table #functions')
go

/* ****************************************************************
    For each of the following function_nums

       function_num   app_name            function_name
       ------------   ------------------  ---------------------------
               6000   ExchangeMonitor     LOADING_SCHEDULE_BY_ACCT

    add 1 record into the function_detail table:
       record #1
          fd_id        : <new fd_id obtained from new_num table>
          function_num : in (6000)
          entity_name  : ExtTradeLoadingSched
          attr_name    : account
          operation    : '='
          entity_ind   : 1
   **************************************************************** */

set nocount on

print ' '
print 'Adding function_detail (ENTITY) records for following function(s) ...'
print '  LOADING_SCHEDULE_BY_ACCT (ExchangeMonitor)'
print ' '
go

create table #functions
(  
   function_num     int
)
go

insert into #functions (function_num)
select distinct function_num
from dbo.icts_function
where app_name = 'ExchangeMonitor' and
      function_name in ('LOADING_SCHEDULE_BY_ACCT')
go

if (select count(*) from #functions) <> 1
begin
   print 'ERROR: Missing the following function(s) in icts_function table:'
   print '  LOADING_SCHEDULE_BY_ACCT (ExchangeMonitor)'
   goto exitscript
end

declare @function_num      int,
        @fd_id             int,
        @total_rows_added  int,
        @rows_added        int,
        @errcode           int,
        @smsg              varchar(255)

select @errcode = 0

select @function_num = min(function_num)
from #functions

while @function_num is not null
begin
   select @smsg = '=> function_detail (ENTITY): function_num #' + convert(varchar, @function_num) + ' ...'
   print @smsg

   select @total_rows_added = 0,
          @rows_added = 0
   if not exists (select 1
                  from dbo.function_detail
                  where function_num = @function_num and
                        entity_name = 'ExtTradeLoadingSched' and
                        attr_name = 'account' and
                        operation = '=')
   begin
      begin tran
      select @fd_id = isnull(max(fd_id), 0) + 1
      from dbo.function_detail
      insert into dbo.function_detail
        (fd_id,function_num,entity_name,attr_name,operation,entity_ind,trans_id)
       values(@fd_id, @function_num, 'ExtTradeLoadingSched', 'account', '=', 1, 1)
      select @rows_added = @@rowcount,
             @errcode = @@error
      if @errcode > 0
      begin
         rollback tran
         break
      end
      commit tran
      if @rows_added > 0
      begin
          select @total_rows_added = @total_rows_added + @rows_added
          select @smsg = '=> function_detail (ExtTradeLoadingSched - account): added fd_id #' + convert(varchar, @fd_id)
          print @smsg
      end
   end

   select @function_num = min(function_num)
   from #functions
   where function_num > @function_num
end /* while */
endofscript:
if @errcode = 0 and @total_rows_added > 0
   print 'ENTITY (ExchangeMonitor) record was successfully added into the function_detail table!'
exitscript:
go

if object_id('tempdb..#functions', 'U') is not null
   exec('drop table #functions')
go

/* ------------------------------------------------------------------------
    For each of the following function_nums

       function_num   app_name            function_name
       ------------   ------------------  --------------------
                214  CommAccount         WRITEOFF_OVERRIDE

    add 5 records into the function_detail table:
       record #1
          fd_id        : <new fd_id obtained from new_num table>
          function_num : 214
          entity_name  : 'AMT_LIMIT' and
          attr_name    : 'amtLimitInUSD'
          operation    : '='
          entity_ind   : 1
   ------------------------------------------------------------------------ */
   
print ' '
print 'Adding a new function_detail ENTITY record for the function #214 (CommAccount/WRITEOFF_OVERRIDE) ...'
go

print ' '
print 'Adding function_detail (ENTITY) records for following function ...'
print '  WRITEOFF_OVERRIDE (CommAccount)'
print ' '
go

declare @function_num           int,
        @rows_affected          int,
        @fd_id                  int
        
select @function_num = function_num
from dbo.icts_function
where app_name = 'CommAccount' and
      function_name = 'WRITEOFF_OVERRIDE'

if @function_num is null
begin
   print 'ERROR: Missing the following function in icts_function table:'
   print '  WRITEOFF_OVERRIDE (CommAccount)'
   goto endofscript
end

if not exists (select 1
               from dbo.function_detail
               where function_num = @function_num and
                     entity_name = 'AMT_LIMIT' and
                     attr_name = 'amtLimitInUSD')
begin
   begin tran   
   select @fd_id = isnull(max(fd_id), 0) + 1
   from dbo.function_detail
   
   begin try
     insert into dbo.function_detail 
         (fd_id, function_num, entity_name, attr_name,
          operation, entity_ind, trans_id)
       values (@fd_id, @function_num, 'AMT_LIMIT', 'amtLimitInUSD', '=', 1, 1)
     select @rows_affected = @@rowcount
   end try
   begin catch
     print '=> Failed to add a new function_detail ENTITY record due to the error:'
     print '==> ERROR: ' + ERROR_MESSAGE()
     if @@trancount > 0
        rollback tran
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
     print '=> A new function_detail record was added successfully!'
   else
     print '=> A function_detail record was not added. Something is wrong ?????'
end

endofscript:
go

/* ------------------------------------------------------------------------
    For each of the following function_nums

       function_num   app_name            function_name
       ------------   ------------------  --------------------
               7000   EntityTagEditor     EDIT

    add 5 records into the function_detail table:
       record #1
          fd_id        : <new fd_id obtained from new_num table>
          function_num : 7000
          entity_name  : 'EntityTagDefinition' and
          attr_name    : 'entityTagName'
          operation    : '='
          entity_ind   : 1
   ------------------------------------------------------------------------ */
   
print ' '
print 'Adding a new function_detail ENTITY record for the function #7000 (EntityTagEditor/EDIT) ...'
go

print ' '
print 'Adding function_detail (ENTITY) records for following function ...'
print '  EDIT (EntityTagEditor)'
print ' '
go

declare @function_num           int,
        @rows_affected          int,
        @fd_id                  int
        
select @function_num = function_num
from dbo.icts_function
where app_name = 'EntityTagEditor' and
      function_name = 'EDIT'

if @function_num is null
begin
   print 'ERROR: Missing the following function in icts_function table:'
   print '  EDIT (EntityTagEditor)'
   goto endofscript
end

if not exists (select 1
               from dbo.function_detail
               where function_num = @function_num and
                     entity_name = 'EntityTagDefinition' and
                     attr_name = 'entityTagName')
begin
   begin tran   
   select @fd_id = isnull(max(fd_id), 0) + 1
   from dbo.function_detail
   
   begin try
     insert into dbo.function_detail 
         (fd_id, function_num, entity_name, attr_name,
          operation, entity_ind, trans_id)
       values (@fd_id, @function_num, 'EntityTagDefinition', 'entityTagName', '=', 1, 1)
     select @rows_affected = @@rowcount
   end try
   begin catch
     print '=> Failed to add a new function_detail ENTITY record due to the error:'
     print '==> ERROR: ' + ERROR_MESSAGE()
     if @@trancount > 0
        rollback tran
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
     print '=> A new function_detail record was added successfully!'
   else
     print '=> A function_detail record was not added. Something is wrong ?????'
end

endofscript:
go


declare @rows_affected          int,
        @fd_id                  int

set @rows_affected = 0
if not exists (select 1
                  from dbo.function_detail
                  where function_num = 1401 and
                        entity_name = 'TradingEntity' and
                        attr_name = 'acctNum' and
                        operation is null)
   begin
      select @fd_id = isnull(max(fd_id), 0) + 1
      from dbo.function_detail
      insert into dbo.function_detail
        (fd_id,function_num,entity_name,attr_name,operation,entity_ind,trans_id)
       values(@fd_id, 1401, 'TradingEntity', 'acctNum', null, 1, 1)
      set @rows_affected = @@rowcount
   end
   if @rows_affected > 0
      print '=> A new function_detail record was added for function #1401 (entity_name = ''TradingEntity'') successfully!'
go

exec dbo.refresh_a_last_num 'function_detail', 'fd_id'
go

exec dbo.refresh_a_last_num 'function_detail_value', 'fdv_id'
go
