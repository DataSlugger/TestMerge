set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table commodity_type
go

print 'Loading system reference data into the commodity_type table ...'
go

insert into commodity_type values('A', 'RATE-BASED COST', 1)
go

insert into commodity_type values('C', 'CURRENCY', 1)
go

insert into commodity_type values('F', 'FREIGHT', 1)
go

insert into commodity_type values('G', 'COMMODITY  GROUP', 1)
go

insert into commodity_type values('I', 'FINANCIAL', 1)
go

insert into commodity_type values('O', 'SECONDARY COSTS', 1)
go

insert into commodity_type values('P', 'COMMODITY', 1)
go

insert into commodity_type values('T', 'TAX RATES', 1)
go

insert into commodity_type values('X', 'STORAGE', 1)
go

insert into commodity_type values('H', 'Commodity Rollup Group', 1)
go

insert into commodity_type values ('S', 'SPREAD OPTIONS', 1)
go
if not exists (select 1 
               from dbo.commodity_type 
               where cmdty_type_code = 'K' and 
                     cmdty_type_desc = 'CLEARED')
   insert into dbo.commodity_type
        (cmdty_type_code, cmdty_type_desc, trans_id)
            values('K','CLEARED', 1)
go  

if not exists (select 1 
               from dbo.commodity_type 
               where cmdty_type_code = 'R' and 
                     cmdty_type_desc = 'RINS')
begin
   insert into dbo.commodity_type(cmdty_type_code, cmdty_type_desc, trans_id)
   values('R', 'RINS', 1)
end
go
