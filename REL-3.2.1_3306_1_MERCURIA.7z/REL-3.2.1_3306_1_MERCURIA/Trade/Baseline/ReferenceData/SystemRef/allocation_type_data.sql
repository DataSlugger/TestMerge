set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table allocation_type
go

print 'Loading system reference data into the allocation_type table ...'
go

insert into dbo.allocation_type 
   values('A', 'Across Border', NULL, 'Y', 1)
go

insert into dbo.allocation_type 
   values('B', 'Comp. of Claims', NULL, 'N', 1)
go

insert into dbo.allocation_type 
   values('D', 'Crude pipe', NULL, 'Y', 1)
go

insert into dbo.allocation_type 
   values('G', 'Natual Gas pipe', NULL, 'Y', 1)
go

insert into dbo.allocation_type 
   values('J', 'Inventory Adj.', NULL, 'N', 1)
go

insert into dbo.allocation_type 
   values('K', 'Truck', NULL, 'Y', 1)
go

insert into dbo.allocation_type 
   values('L', 'Blending', NULL, 'Y', 1)
go

insert into dbo.allocation_type 
   values('N', 'Net out', NULL, 'N', 1)
go

insert into dbo.allocation_type 
   values('O', 'Bookout', NULL, 'N', 1)
go

insert into dbo.allocation_type 
   values('P', 'Product pipe', NULL, 'Y', 1)
go

insert into dbo.allocation_type 
   values('R', 'Rail Car', NULL, 'Y', 1)
go

insert into dbo.allocation_type 
   values('T', 'Tank transfer', NULL, 'Y', 1)
go

insert into dbo.allocation_type 
   values('W', 'Waterborne', NULL, 'Y', 1)
go

