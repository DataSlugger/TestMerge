set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bus_cost_child_gen
go

print 'Loading system reference data into the bus_cost_child_gen table ...'
go

insert into dbo.bus_cost_child_gen 
   values('ACCUM', 'ACCUMULATION', 'ACCUMULATION', 1)
go

insert into dbo.bus_cost_child_gen 
   values('ALLOCATE', 'ALLOCATION', 'ALLOCATION', 1)
go

insert into dbo.bus_cost_child_gen 
   values('EST_ACTUAL', 'EST_ACTUAL', 'EST_ACTUAL', 1)
go

insert into dbo.bus_cost_child_gen 
   values('NONE', 'NONE', 'NONE', 1)
go

insert into dbo.bus_cost_child_gen 
   values('PRELIMOFFSET', 'PRELIM OFFSET', 'Preliminary Offset', 1)
go

