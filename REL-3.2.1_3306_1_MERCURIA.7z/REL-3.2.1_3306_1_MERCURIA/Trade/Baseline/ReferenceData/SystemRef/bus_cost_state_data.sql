set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bus_cost_state
go

print 'Loading system reference data into the bus_cost_state table ...'
go

insert into dbo.bus_cost_state 
   values(1, 'NOSTATE', 'NOSTATE', 'NO STATE', 1)
go

insert into dbo.bus_cost_state 
   values(2, 'CREATED', 'CREATED', 'CREATED', 1)
go

insert into dbo.bus_cost_state 
   values(3, 'UPDATING', 'UPDATING', 'UPDATING', 1)
go

insert into dbo.bus_cost_state 
   values(4, 'ACTUALIZED', 'ACTUALIZED', 'ACTUALIZED', 1)
go

insert into dbo.bus_cost_state 
   values(5, 'COMPLETING', 'COMPLETING', 'COMPLETING', 1)
go

insert into dbo.bus_cost_state 
   values(6, 'VERIFIED', 'VERIFIED', 'VERIFIED', 1)
go

insert into dbo.bus_cost_state 
   values(7, 'PROCESSED', 'PROCESSED', 'PROCESSED', 1)
go

