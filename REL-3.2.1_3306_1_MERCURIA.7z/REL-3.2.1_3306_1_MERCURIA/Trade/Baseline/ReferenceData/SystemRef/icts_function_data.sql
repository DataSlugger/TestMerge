set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the icts_function table ...'
go

/* FUNCTION LIST

 function_num app_name             function_name
 ------------ -------------------- ----------------------------------------
            1 TradeCapture         ADD
            2 TradeCapture         MODIFY
            3 TradeCapture         DELETE
            4 TradeCapture         QUERY
            5 TradeCapture         COMMENT
            6 TradeCapture         CONFIRM
            7 TradeCapture         CONTR_INFO
            8 TradeCapture         PRELIM_PRICE
            9 TradeCapture         CONCL_TRADE
          150 TradeCapture         MODIFY_MKT_FORMULA
          151 TradeCapture         MODIFY_BROKER
          152 TradeCapture         OVERRIDE_ECOMFIRM_STATUS
          153 TradeCapture         ECONFIRM_RESUBMIT
          154 TradeCapture         MODIFY_AFTER_ALLOC
          155 TradeCapture         MODIFY_COMPLETED_SCHEDULING
          156 TradeCapture         EDIT_OKTOLOAD
          157 TradeCapture         INTERFACE_TRADE
          158 TradeCapture         INHOUSE_TRADE
          159 TradeCapture         CREDIT_TERM_OVERRIDE
          160 TradeCapture         EDIT_CREDIT_APPROVED
          161 TradeCapture         OVERRIDE_DEFAULT_CREDIT_TERM
          162 TradeCapture         CAN_EDIT_SECONDARY_COSTS
          163 TradeCapture         ADD_PAST_TRADE_DATE
          164 TradeCapture         UNCONFIRM
          165 TradeCapture         EDIT_CREDIT_UNAPPROVED
          166 TradeCapture         CAN_EDIT_INTERNAL_COSTS
          167 TradeCapture         ECONFIRM
          168 TradeCapture         MOVE_OPEN_QTY
          169 TradeCapture         EDIT_ECONFIRM
          170 TradeCapture         UPDATE_DEEMED_AFTER_CONFIRM
          172 TradeCapture         MODIFY_RiskMktPeriod
          173 TradeCapture         AllowLaycanDateEarlierThanContrDate
          174 TradeCapture         CAN_EDIT_EXCHANGE_FIELDS
          
           11 ContractEditor       QUERY
           12 ContractEditor       MODIFY
           13 ContractEditor       ADD

           16 AccountMaintenance   ADD
           17 AccountMaintenance   ADD+
           18 AccountMaintenance   MODIFY
           19 AccountMaintenance   MODIFY+
           20 AccountMaintenance   DELETE
           21 AccountMaintenance   DELETE+
           22 AccountMaintenance   CREDIT_INFO
           23 AccountMaintenance   CREDIT_LIMIT
           24 AccountMaintenance   ACCT_GROUP

           31 FuturesCapture       ADD
           32 FuturesCapture       DELETE
           33 FuturesCapture       MODIFY
           34 FuturesCapture       QUERY

           41 PriceManager         ADD
           42 PriceManager         DELETE
           43 PriceManager         MODIFY

           50 QuickFill            VIEW
           51 QuickFill            EDIT
           52 QuickFill            MAINTAIN_TRADER_PORTS

           53 Inhouse              EDIT
           54 Inhouse              VIEW

          100 PortfolioManager     DO_EVERYTHING
          101 PortfolioManager     MAINTAIN_INFRA_PORTS
          102 PortfolioManager     MAINTAIN_TRADER_PORTS
          103 PortfolioManager     VIEW_PORTS
          104 PortfolioManager     CAN_MOVE_PORTFOLIOS
          105 PortfolioManager     CanUpdateJMSReportsInfo
          106 PortfolioManager     CanUpdateJMSClassifCode
          107 PortfolioManager     CAN_LOCK_PORTS
          108 PortfolioManager     CanUpdateNoiseBands
          109 PortfolioManager     PORT_TAG_MODIFY_COST_CENTER
          110 PortfolioManager     PORT_TAG_MODIFY_BOOK_COMP
          113 PortfolioManager     CAN_DO_EVERYTHING
                    
          189 PASSApp              TASK_EXPIRE_FUTURES
          190 PASSApp              PASS_REPORT_TASKS
          191 PASSApp              GLOBAL_SNAPSHOT
          192 PASSApp              PERFORM_PL_TASKS
          193 PASSApp              PRICE_MKT_FORMS
          194 PASSApp              PRICE_TRADE_FORMS
          195 PASSApp              PROCESS_PERIODS
          196 PASSApp              FIFO
          197 PASSApp              INVENTORY
          198 PASSApp              UPDATE
          199 PASSApp              NOISE_BAND_EXP_TASKS
         9000 PASSApp              SymphonyInterfaceTasks
         9001 PASSApp              DO_EVERYTHING
         9002 PASSApp              CostUploadTask

          201 CommAccount          AUTO_PROCESS
          202 CommAccount          WRITE
          203 CommAccount          DELETE_COST
          204 CommAccount          DELETE_VOUCHER
          205 CommAccount          HOLD_COST
          206 CommAccount          VOUCHER
          207 CommAccount          OVERRIDE_ACCT_CODES
          210 CommAccount          REMOVE_FROM_VOUCHER
          211 CommAccount          REVERSE_VOUCHER
          212 CommAccount          REVERT
          214 CommAccount          WRITEOFF_OVERRIDE
          215 CommAccount          OVERRIDE_PRICE
          216 CommAccount          ACCRUE_COST
          220 CommAccount          CREATE
          221 CommAccount          READ
          222 CommAccount          REVERSE
          230 CommAccount          CRUDE_CLOSE
          231 CommAccount          PROD_CLOSE
          232 CommAccount          CASH_SUPERVISOR
          241 CommAccount          GENERATE_INVOICE
          242 CommAccount          GENERATE_PAYMENT
          243 CommAccount          REVERSE_INVOICE
          244 CommAccount          REVERSE_PAYMENT
          245 CommAccount          MODIFY_RECEIVABLE_BANK
          246 CommAccount          MODIFY_PAYABLE_BANK
          247 CommAccount          OVERRIDE_COST_EFF_DATE
          248 CommAccount          OVERRIDE_COST_DUE_DATE
          249 CommAccount          SUPERUSER
          250 CommAccount          ADD_COST
          251 CommAccount          UPDATE_COST
          252 CommAccount          CREATE_VOUCHER
          253 CommAccount          UPDATE_VOUCHER
          254 CommAccount          CAN_DO_EVERYTHING
          255 CommAccount          APPROVE_COST
          256 CommAccount          ADD_ADDLAX_COST
          257 CommAccount          UPDATE_ADDLAX_COST
          258 CommAccount          DELETE_ADDLAX_COST
          259 CommAccount          DELETE_ZYTAX_COST
          260 CommAccount          UPDATE_CUSTOMER_INVOICE_TYPE
          261 CommAccount          CAN_UPDATE_ZYTAX_COSTS
          262 CommAccount          EDIT_GST_COSTS
          263 CommAccount          CAN_EDIT_VOUCHER_COMMENT
          264 CommAccount          RECALCULATE_COST_DUE_DATE
          265 CommAccount          EDIT_CREDIT_TERM_ON_COST
          268 CommAccount          CAN_EDIT_PREPAY_IND
          269 CommAccount          APPROVE_VOUCHER
          270 CommAccount          CAN_EDIT_INTERNAL_COSTS
	        271 CommAccount	         HOLD_VOUCHER
	        272 CommAccount	         UNHOLD_VOUCHER
          273 CommAccount          UNAPPROVE_VOUCHER
         1630 CommAccount          CanVouchPastDueCosts
         1631 CommAccount          AUTO_OVERRIDE	  

          301 AutoVoucher          POST_BATCH
          302 AutoVoucher          DELETE_BATCH
          304 AutoVoucher          POST_VOUCHER
          305 AutoVoucher          DELETE_VOUCHER
          306 AutoVoucher          REVERSE_VOUCHER
          308 AutoVoucher          HOLD_COST
          309 AutoVoucher          AUTO_PROCESS
          310 AutoVoucher          MAN_PROCESS
          311 AutoVoucher          READ
          312 AutoVoucher          CRUDE_CLOSE
          313 AutoVoucher          PROD_CLOSE

          400 DocumentEditor       QUERY
          401 DocumentEditor       MODIFY
          402 DocumentEditor       ADD

          500 TraderDashboard      ADD
          501 TraderDashboard      MODIFY
          502 TraderDashboard      QUERY
          503 TraderDashboard      DELETE

          601 Allocation           ADD
          602 Allocation           QUERY
          603 Allocation           MODIFY
          604 Allocation           DELETE
          605 Allocation           COMMENT
          606 Allocation           APPROVE_COST
          607 Allocation           ADD_COST
          608 Allocation           UPDATE_COST
          609 Allocation           DELETE_COST
          610 Allocation           APPROVE_ALL_COSTS
          611 Allocation           QUALIFY_INVENTORY
          612 Allocation           OVERDRAW_INVENTORY
          613 Allocation           CAN_DO_EVERYTHING
          614 Allocation           EDIT_OKTOLOAD
          615 Allocation           EDIT_CREDIT_APPROVED
          616 Allocation           CAN_OVERRIDE_APPROVED_COSTS
          617 Allocation           OVERRIDE_INV_DRAW_VAL
          618 Allocation           CAN_EDIT_INTERNAL_COSTS
          627 Allocation           MODIFY_SCHD_NOMIN_QTY_AND_EST_EVENT_DATE
          628 Allocation           CAN_ASSIGN_UNASSIGN_LC
		  
          700 LC                   ADD
          701 LC                   UPDATE
          702 LC                   VIEW
          703 LC                   DELETE
          704 LC                   ASSIGN

          800 AccountViewer        VIEW

          810 CountryViewer        VIEW

          820 ParentGuarantee      VIEW
          821 ParentGuarantee      UPDATE
          822 ParentGuarantee      ADD
          823 ParentGuarantee      DELETE

          830 LCViewer             VIEW
          840 PGViewer             VIEW

          901 PricingApp           VIEW
          902 PricingApp           OVER_RIDE
          903 PricingApp           REPRICE
          904 PricingApp           SAVE
          905 PricingApp           REBUILD
          906 PricingApp           VOUCHER

          950 ReportExtractor      ADD
          951 ReportExtractor      MODIFY
          952 ReportExtractor      DELETE

         1000 PostedPriceMaint     ADD
         1001 PostedPriceMaint     DELETE
         1002 PostedPriceMaint     MODIFY
         1003 PostedPriceMaint     VIEW

         1100 Petroex              ADD

         1200 CreditViewer         QUERY
         1201 CreditViewer         ADD
         1202 CreditViewer         MODIFY
         1203 CreditViewer         DELETE

         1214 MasterCollateral     ADD
         1215 MasterCollateral     DELETE
         1216 MasterCollateral     UPDATE
         1217 MasterCollateral     ASSIGN
         1218 MasterCollateral     VIEW

         1300 PLManager            MOVE_PL
         1301 PLManager            BOOK_PL

         1400 ICTSControl          RUN
         1401 ICTSControl          TradingEntity  (Mercuria-specific)
                                                  (Noble-specific)

         1500 AutopoolCriteria     CREATE_DEL

         1598 AGIPNews             ALL
         1599 AGIPNews             READ-ONLY

         1600 LocationManager      ALL
         1601 LocationManager      READ-ONLY

         1602 CalendarMaintenance  ALL
         1603 CalendarMaintenance  READ-ONLY

         1604 UserMaintenance      ALL
         1605 UserMaintenance      READ-ONLY

         1606 CrudeProfile         ALL

         1607 CrudeEntry           ALL
         1608 AGIP01               ALL

         1609 CommodityRollup      ALL
         1610 CommodityRollup      READ-ONLY

         1620 CargoTracking        ALL
         1621 CargoTracking        READ-ONLY
         1622 CargoTracking        FAR EAST
         1623 CargoTracking        MEDITERRANEAN
         1624 CargoTracking        BLACK SEA
         1625 CargoTracking        NORTH SEA
         1626 CargoTracking        WEST AFRICA
         1627 CargoTracking        AMERICAS
         1628 CargoTracking        CASPIAN SEA
         1629 CargoTracking        PERSIAN GULF
         1630 CommAccount          CanVouchPastDueCosts
         1631 CommAccount          AUTO_OVERRIDE

         1701 Repricing            AUTO_OVERRIDE
         1702 Repricing            REPRICE_VOUCHED_COST

         1800 Bunkers              ADD
         1801 Bunkers              CONFIRM
         1802 Bunkers              DELETE
         1803 Bunkers              MODIFY
         1804 Bunkers              QUERY
         1805 Bunkers              ADD_ALLOC
         1806 Bunkers              DELETE_ALLOC
         1807 Bunkers              MODIFY_ALLOC
         1808 Bunkers              MODIFY_REFDATA
         1809 Bunkers              CONCL_TRADE

         1900 CAMaint              ORDERNUM_UPDATE

         2000 ENELSAPInterface     RUN
         2001 ENELSAPInterface     SC04

         2100 LivePrices           ALL
         
         2200 LivePriceLoad        ALL

         2500 RiskManager          MOVE_LINK_PORTFOLIOS
         2501 RiskManager          LOCK_UNLOCK_PORTFOLIOS	
         2502 RiskManager          VIEW_PORTFOLIOS
         2503 RiskManager          UPDATE_PORTFOLIOS

         2600 ReferenceData        ACCESS
               
         3000 SAPSelect            ARCHIVE
         3001 SAPSelect            HIDE
         3002 SAPSelect            DELETE
         3003 SAPSelect            MARK
         3004 SAPSelect            VIEW

         3070 TaxMaintenance       ALL

         3200 Logistics            CreateShipment
         3201 Logistics            ModifyShipment
         3202 Logistics            FinalizeShipment
         3203 Logistics            DeleteShipment
         3204 Logistics            CreateParcel
         3205 Logistics            ModifyParcel
         3206 Logistics            ActualizeParcel
         3207 Logistics            DeleteParcel
         3208 Logistics            MODIFY_SHARED_SEARCH
         3209 Logistics            MODIFY_SHARED_LAYOUT
         3210 Logistics            ADD_COST_TEMPLATE
         3211 Logistics            MODIFY_COST_TEMPLATE
         3212 Logistics            DELETE_COST_TEMPLATE
         3213 Logistics            ADD_PATH
         3214 Logistics            MODIFY_PATH
         3215 Logistics            DELETE_PATH
         3216 Logistics            ADD_COST_CODE
         3217 Logistics            MODIFY_COST_CODE
         3218 Logistics            DELETE_COST_CODE
         3219 Logistics            UPDATE_PL_IND
         3220 Logistics            ACCESS
         3221 Logistics            MODIFY_SEARCH_OPTIONS
         3222 Logistics            DELETE_SHARED_QUERIES
         3223 Logistics            ADJUST_RINS
         3224 Logistics            ADD_NEW_TRANSPORT
         3225 Logistics            CAN_RUN_CP2
         3226 Logistics            CAN_BULK_UPDATE_PARCEL_SHIPMENT_STATUS
         3227 Logistics            CAN_BULK_UPDATE_TI_COMPLETED_SCHEDULING
         3228 Logistics            CAN_CLEAN_OPEN_ZERO_COSTS
	       3229 Logistics            CanEditNominQtyOnPartiallyActlzdPrcls
         3230 Logistics            CAN_BULK_UPDATE_PORTFOLIOS

         4000 ICTSAdmin            ALL
         4001 ICTSAdmin            Account Maintenance - View
         4002 ICTSAdmin            Account Maintenance - Edit
         4003 ICTSAdmin            Calendar Maintenance - View
         4004 ICTSAdmin            Calendar Maintenance - Edit
         4005 ICTSAdmin            Commodity Market Maintenance - View
         4006 ICTSAdmin            Commodity Market Maintenance - Edit
         4007 ICTSAdmin            Configuration Data - View
         4008 ICTSAdmin            Configuration Data - Edit
         4009 ICTSAdmin            Credit - View
         4010 ICTSAdmin            Credit - Edit
         4011 ICTSAdmin            Location Maintenance - View
         4012 ICTSAdmin            Location Maintenance - Edit
         4013 ICTSAdmin            Pipeline Cycle Data - View
         4014 ICTSAdmin            Pipeline Cycle Data - Edit
         4015 ICTSAdmin            Site Reference Data - View
         4016 ICTSAdmin            Site Reference Data - Edit
         4017 ICTSAdmin            Trade Default Data - View
         4018 ICTSAdmin            Trade Default Data - Edit
         4019 ICTSAdmin            Uom Conversions - View
         4020 ICTSAdmin            Uom Conversions - Edit
         4021 ICTSAdmin            User Maintenance - View
         4022 ICTSAdmin            User Maintenance - Edit
         4023 ICTSAdmin            VAT - View
         4024 ICTSAdmin            VAT - Edit
         4025 ICTSAdmin            Commercial Accounting Maintenance - Edit
         4026 ICTSAdmin            Commercial Accounting Maintenance - View
         4027 ICTSAdmin            Tax Maintenance - Edit
         4028 ICTSAdmin            Tax Maintenance - View

         4100 ReportGenerator      ALL

         4200 TruckCapture         ALL
         4201 TruckCapture         NewTrade
         4202 TruckCapture         EditTrade
         4203 TruckCapture         ViewTrade
         4204 TruckCapture         NewAllocation
         4205 TruckCapture         CancelAllocation
         4206 TruckCapture         ViewAllocations
         4207 TruckCapture         EnterActuals
         4208 TruckCapture         CancelActuals
         4209 TruckCapture         PrintReleaseDocument
         4210 TruckCapture         PrintReleaseDocumentConfirm
         4211 TruckCapture         DeleteTrade

         4300 ProcessTicket        ALL

         4400 RMSInterface         ALL

         5000 CVXWebService        ALL (CVX specific)

         5200 GatewayInboundWS     ALL
         
         6000 ExchangeMonitor      LOADING_SCHEDULE_BY_ACCT

         6666 CAInterface          ALL

         7000 EntityTagEditor      EDIT
         
         8000 RC                   VIEW
         8001 RC                   ADD
         8002 RC                   EDIT
         8003 RC                   DELETE

        10001 4GenInterface        BUNKER_IMPORT   (CVX owned)
        10002 4GenInterface        BULK_EXPORT     (CVX owned)
        10003 4GenInterface        INV_EXPORT      (CVX owned)
        10004 4GenInterface        ACCT_LOAD       (CVX owned)

        14000 OpsManager           UPDATE_NONECO_DATA
        14001 OpsManager           UPDATE_NONECO_DATA_SWAP

        20001 PortfolioManager     PORT_TAG_MODIFY_CLASS
        20002 PortfolioManager     PORT_TAG_MODIFY_DEPT
        20003 PortfolioManager     PORT_TAG_MODIFY_DESK
        20004 PortfolioManager     PORT_TAG_MODIFY_DIVISION
        20005 PortfolioManager     PORT_TAG_MODIFY_GROUP
        20006 PortfolioManager     PORT_TAG_MODIFY_LEGALENT
        20007 PortfolioManager     PORT_TAG_MODIFY_LOCATION
        20008 PortfolioManager     PORT_TAG_MODIFY_PRFTCNTR
        20009 PortfolioManager     PORT_TAG_MODIFY_STRATEGY
        20010 PortfolioManager     PORT_TAG_MODIFY_TRADER

        30001 TradeSearch          EDIT_CREDIT_TERM
        30002 TradeSearch          EDIT_CREDIT_APPROVED

        9100  ICTSReports          CAN_UPDATE_PORTFOLIO
        
        9200  TicketActuals        FEED_SOURCE
        9201  TicketActuals        UPLOAD_ACTUALS
*/

create table #functions
(
   function_num        int primary key,
   app_name            varchar(20) not null,
   function_name       varchar(40) not null
)
go

print '=> Loading funcations for the ''TradeCapture'' app into the temp table ...'
go
insert into #functions values(1, 'TradeCapture', 'ADD')
insert into #functions values(2, 'TradeCapture', 'MODIFY')
insert into #functions values(3, 'TradeCapture', 'DELETE')
insert into #functions values(4, 'TradeCapture', 'QUERY')
insert into #functions values(5, 'TradeCapture', 'COMMENT')
insert into #functions values(6, 'TradeCapture', 'CONFIRM')
insert into #functions values(7, 'TradeCapture', 'CONTR_INFO')
insert into #functions values(8, 'TradeCapture', 'PRELIM_PRICE')
insert into #functions values(9, 'TradeCapture', 'CONCL_TRADE')
insert into #functions values(150, 'TradeCapture', 'MODIFY_MKT_FORMULA')
insert into #functions values(151, 'TradeCapture', 'MODIFY_BROKER')
insert into #functions values(154, 'TradeCapture', 'MODIFY_AFTER_ALLOC')
go

insert into #functions values(155, 'TradeCapture', 'MODIFY_COMPLETED_SCHEDULING')
insert into #functions values(156, 'TradeCapture', 'EDIT_OKTOLOAD')
insert into #functions values(157, 'TradeCapture', 'INTERFACE_TRADE')
insert into #functions values(158, 'TradeCapture', 'INHOUSE_TRADE')
insert into #functions values(159, 'TradeCapture', 'CREDIT_TERM_OVERRIDE')
insert into #functions values(160, 'TradeCapture', 'EDIT_CREDIT_APPROVED')
insert into #functions values(161, 'TradeCapture', 'OVERRIDE_DEFAULT_CREDIT_TERM')
insert into #functions values(162, 'TradeCapture', 'CAN_EDIT_SECONDARY_COSTS')
insert into #functions values(163, 'TradeCapture', 'ADD_PAST_TRADE_DATE')
insert into #functions values(164, 'TradeCapture', 'UNCONFIRM')
insert into #functions values(165, 'TradeCapture', 'EDIT_CREDIT_UNAPPROVED')
insert into #functions values(166, 'TradeCapture', 'CAN_EDIT_INTERNAL_COSTS')
insert into #functions values(167, 'TradeCapture', 'ECONFIRM')
insert into #functions values(168, 'TradeCapture', 'MOVE_OPEN_QTY')
insert into #functions values(169, 'TradeCapture', 'EDIT_ECONFIRM')
insert into #functions values(170, 'TradeCapture', 'UPDATE_DEEMED_AFTER_CONFIRM')
insert into #functions values(172, 'TradeCapture', 'MODIFY_RiskMktPeriod')
insert into #functions values(173, 'TradeCapture', 'AllowLaycanDateEarlierThanContrDate')
insert into #functions values(174, 'TradeCapture', 'CAN_EDIT_EXCHANGE_FIELDS')
go

print '=> Loading funcations for the ''ContractEditor'' app into the temp table ...'
go
insert into #functions values(11, 'ContractEditor', 'QUERY')
insert into #functions values(12, 'ContractEditor', 'MODIFY')
insert into #functions values(13, 'ContractEditor', 'ADD')
go

print '=> Loading funcations for the ''AccountMaintenance'' app into the temp table ...'
go
insert into #functions values(16, 'AccountMaintenance', 'ADD')
insert into #functions values(17, 'AccountMaintenance', 'ADD+')
insert into #functions values(18, 'AccountMaintenance', 'MODIFY')
insert into #functions values(19, 'AccountMaintenance', 'MODIFY+')
insert into #functions values(20, 'AccountMaintenance', 'DELETE')
insert into #functions values(21, 'AccountMaintenance', 'DELETE+')
insert into #functions values(22, 'AccountMaintenance', 'CREDIT_INFO')
insert into #functions values(23, 'AccountMaintenance', 'CREDIT_LIMIT')
insert into #functions values(24, 'AccountMaintenance', 'ACCT_GROUP')
go

print '=> Loading funcations for the ''FuturesCapture'' app into the temp table ...'
go
insert into #functions values(31, 'FuturesCapture', 'ADD')
insert into #functions values(32, 'FuturesCapture', 'DELETE')
insert into #functions values(33, 'FuturesCapture', 'MODIFY')
insert into #functions values(34, 'FuturesCapture', 'QUERY')
go

print '=> Loading funcations for the ''PriceManager'' app into the temp table ...'
go
insert into #functions values(41, 'PriceManager', 'ADD')
insert into #functions values(42, 'PriceManager', 'DELETE')
insert into #functions values(43, 'PriceManager', 'MODIFY')
go

print '=> Loading funcations for the ''PortfolioManager'' app into the temp table ...'
go
insert into #functions values(100, 'PortfolioManager', 'DO_EVERYTHING')
insert into #functions values(101, 'PortfolioManager', 'MAINTAIN_INFRA_PORTS')
insert into #functions values(102, 'PortfolioManager', 'MAINTAIN_TRADER_PORTS')
insert into #functions values(103, 'PortfolioManager', 'VIEW_PORTS')
insert into #functions values(104, 'PortfolioManager', 'CAN_MOVE_PORTFOLIOS')
insert into #functions values(105, 'PortfolioManager', 'CanUpdateJMSReportsInfo')
insert into #functions values(106, 'PortfolioManager', 'CanUpdateJMSClassifCode')
insert into #functions values(107, 'PortfolioManager', 'CAN_LOCK_PORTS')
insert into #functions values(108, 'PortfolioManager', 'CanUpdateNoiseBands')
insert into #functions values(109, 'PortfolioManager', 'PORT_TAG_MODIFY_COST_CENTER')
insert into #functions values(110, 'PortfolioManager', 'PORT_TAG_MODIFY_BOOK_COMP')
insert into #functions values(113, 'PortfolioManager', 'CAN_DO_EVERYTHING')
go

print '=> Loading funcations for the ''PASSApp'' app into the temp table ...'
go
insert into #functions values(189, 'PASSApp', 'TASK_EXPIRE_FUTURES')
insert into #functions values(190, 'PASSApp', 'PASS_REPORT_TASKS')
insert into #functions values(191, 'PASSApp', 'GLOBAL_SNAPSHOT')
insert into #functions values(192, 'PASSApp', 'PERFORM_PL_TASKS')
insert into #functions values(193, 'PASSApp', 'PRICE_MKT_FORMS')
insert into #functions values(194, 'PASSApp', 'PRICE_TRADE_FORMS')
insert into #functions values(195, 'PASSApp', 'PROCESS_PERIODS')
insert into #functions values(196, 'PASSApp', 'FIFO')
insert into #functions values(197, 'PASSApp', 'INVENTORY')
insert into #functions values(198, 'PASSApp', 'UPDATE')
insert into #functions values(199, 'PASSApp', 'NOISE_BAND_EXP_TASKS')
insert into #functions values(9000, 'PASSApp', 'SymphonyInterfaceTasks')
insert into #functions values(9001, 'PASSApp', 'DO_EVERYTHING')
insert into #functions values(9002, 'PASSApp', 'CostUploadTask')
go

print '=> Loading funcations for the ''CommAccount'' app into the temp table ...'
go
insert into #functions values(201, 'CommAccount', 'AUTO_PROCESS')
insert into #functions values(202, 'CommAccount', 'WRITE')
insert into #functions values(203, 'CommAccount', 'DELETE_COST')
insert into #functions values(204, 'CommAccount', 'DELETE_VOUCHER')
insert into #functions values(205, 'CommAccount', 'HOLD_COST')
insert into #functions values(206, 'CommAccount', 'VOUCHER')
insert into #functions values(207, 'CommAccount', 'OVERRIDE_ACCT_CODES')
insert into #functions values(210, 'CommAccount', 'REMOVE_FROM_VOUCHER')
insert into #functions values(211, 'CommAccount', 'REVERSE_VOUCHER')
insert into #functions values(212, 'CommAccount', 'REVERT')
insert into #functions values(214, 'CommAccount', 'WRITEOFF_OVERRIDE')
go
insert into #functions values(215, 'CommAccount', 'OVERRIDE_PRICE')
insert into #functions values(216, 'CommAccount', 'ACCRUE_COST')
insert into #functions values(220, 'CommAccount', 'CREATE')
insert into #functions values(221, 'CommAccount', 'READ')
insert into #functions values(222, 'CommAccount', 'REVERSE')
insert into #functions values(230, 'CommAccount', 'CRUDE_CLOSE')
insert into #functions values(231, 'CommAccount', 'PROD_CLOSE')
insert into #functions values(241, 'CommAccount', 'GENERATE_INVOICE')
insert into #functions values(242, 'CommAccount', 'GENERATE_PAYMENT')
insert into #functions values(243, 'CommAccount', 'REVERSE_INVOICE')
insert into #functions values(244, 'CommAccount', 'REVERSE_PAYMENT')
insert into #functions values(245, 'CommAccount', 'MODIFY_RECEIVABLE_BANK')
insert into #functions values(246, 'CommAccount', 'MODIFY_PAYABLE_BANK')
go

/* These are needed by ENEL SAP. 
insert into #functions values(247, 'CommAccount', 'OVERRIDE_COST_EFF_DATE')
insert into #functions values(248, 'CommAccount', 'OVERRIDE_COST_DUE_DATE')
insert into #functions values(249, 'CommAccount', 'SUPERUSER')
*/

insert into #functions values(250, 'CommAccount', 'ADD_COST')
insert into #functions values(251, 'CommAccount', 'UPDATE_COST')
insert into #functions values(252, 'CommAccount', 'CREATE_VOUCHER')
insert into #functions values(253, 'CommAccount', 'UPDATE_VOUCHER')
insert into #functions values(254, 'CommAccount', 'CAN_DO_EVERYTHING')
insert into #functions values(255, 'CommAccount', 'APPROVE_COST')
insert into #functions values(256, 'CommAccount', 'ADD_ADDLAX_COST')
insert into #functions values(257, 'CommAccount', 'UPDATE_ADDLAX_COST')
insert into #functions values(258, 'CommAccount', 'DELETE_ADDLAX_COST')
insert into #functions values(259, 'CommAccount', 'DELETE_ZYTAX_COST')
insert into #functions values(260, 'CommAccount', 'UPDATE_CUSTOMER_INVOICE_TYPE')
go

insert into #functions values(261, 'CommAccount', 'CAN_UPDATE_ZYTAX_COSTS')
insert into #functions values(262, 'CommAccount', 'EDIT_GST_COSTS')
insert into #functions values(263, 'CommAccount', 'CAN_EDIT_VOUCHER_COMMENT')
insert into #functions values(264, 'CommAccount', 'RECALCULATE_COST_DUE_DATE')
insert into #functions values(265, 'CommAccount', 'EDIT_CREDIT_TERM_ON_COST')
insert into #functions values(268, 'CommAccount', 'CAN_EDIT_PREPAY_IND')
insert into #functions values(269, 'CommAccount', 'APPROVE_VOUCHER')
insert into #functions values(270, 'CommAccount', 'CAN_EDIT_INTERNAL_COSTS')
insert into #functions values(271, 'CommAccount', 'HOLD_VOUCHER')
insert into #functions values(272, 'CommAccount', 'UNHOLD_VOUCHER')
insert into #functions values(273, 'CommAccount', 'UNAPPROVE_VOUCHER')
go

insert into #functions values(1630, 'CommAccount', 'CanVouchPastDueCosts')
insert into #functions values(1631, 'CommAccount', 'AUTO_OVERRIDE')
go

print '=> Loading funcations for the ''AutoVoucher'' app into the temp table ...'
go
insert into #functions values(301, 'AutoVoucher', 'POST_BATCH')
insert into #functions values(302, 'AutoVoucher', 'DELETE_BATCH')
insert into #functions values(304, 'AutoVoucher', 'POST_VOUCHER')
insert into #functions values(305, 'AutoVoucher', 'DELETE_VOUCHER')
insert into #functions values(306, 'AutoVoucher', 'REVERSE_VOUCHER')
insert into #functions values(308, 'AutoVoucher', 'HOLD_COST')
insert into #functions values(309, 'AutoVoucher', 'AUTO_PROCESS')
insert into #functions values(310, 'AutoVoucher', 'MAN_PROCESS')
insert into #functions values(311, 'AutoVoucher', 'READ')
insert into #functions values(312, 'AutoVoucher', 'CRUDE_CLOSE')
insert into #functions values(313, 'AutoVoucher', 'PROD_CLOSE')
go

print '=> Loading funcations for the ''DocumentEditor'' app into the temp table ...'
go
insert into #functions values(400, 'DocumentEditor', 'QUERY')
insert into #functions values(401, 'DocumentEditor', 'MODIFY')
insert into #functions values(402, 'DocumentEditor', 'ADD')

print '=> Loading funcations for the ''TraderDashboard'' app into the temp table ...'
go
insert into #functions values(500, 'TraderDashboard', 'ADD')
insert into #functions values(501, 'TraderDashboard', 'MODIFY')
insert into #functions values(502, 'TraderDashboard', 'QUERY')
insert into #functions values(503, 'TraderDashboard', 'DELETE')

print '=> Loading funcations for the ''Allocation'' app into the temp table ...'
go
insert into #functions values(601, 'Allocation', 'ADD')
insert into #functions values(602, 'Allocation', 'QUERY')
insert into #functions values(603, 'Allocation', 'MODIFY')
insert into #functions values(604, 'Allocation', 'DELETE')
insert into #functions values(605, 'Allocation', 'COMMENT')
insert into #functions values(606, 'Allocation', 'APPROVE_COST')
insert into #functions values(607, 'Allocation', 'ADD_COST')
insert into #functions values(608, 'Allocation', 'UPDATE_COST')
insert into #functions values(609, 'Allocation', 'DELETE_COST')
go
insert into #functions values(610, 'Allocation', 'APPROVE_ALL_COSTS')
insert into #functions values(611, 'Allocation', 'QUALIFY_INVENTORY')
insert into #functions values(612, 'Allocation', 'OVERDRAW_INVENTORY')
insert into #functions values(613, 'Allocation', 'CAN_DO_EVERYTHING')
insert into #functions values(614, 'Allocation', 'EDIT_OKTOLOAD')
insert into #functions values(615, 'Allocation', 'EDIT_CREDIT_APPROVED')
insert into #functions values(616, 'Allocation', 'CAN_OVERRIDE_APPROVED_COSTS')
insert into #functions values(617, 'Allocation', 'OVERRIDE_INV_DRAW_VAL')
insert into #functions values(618, 'Allocation', 'CAN_EDIT_INTERNAL_COSTS')
insert into #functions values(627, 'Allocation', 'MODIFY_SCHD_NOMIN_QTY_AND_EST_EVENT_DATE')
insert into #functions values(628, 'Allocation', 'CAN_ASSIGN_UNASSIGN_LC')
go

print '=> Loading funcations for the ''LC'' app into the temp table ...'
go
insert into #functions values(700, 'LC', 'ADD')
insert into #functions values(701, 'LC', 'UPDATE')
insert into #functions values(702, 'LC', 'VIEW')
insert into #functions values(703, 'LC', 'DELETE')
insert into #functions values(704, 'LC', 'ASSIGN')
go

print '=> Loading funcations for the ''AccountViewer'' app into the temp table ...'
go
insert into #functions values(800, 'AccountViewer', 'VIEW')
go

print '=> Loading funcations for the ''CountryViewer'' app into the temp table ...'
go
insert into #functions values(810, 'CountryViewer', 'VIEW')
go

print '=> Loading funcations for the ''ParentGuarantee'' app into the temp table ...'
go
insert into #functions values(820, 'ParentGuarantee', 'VIEW')
insert into #functions values(821, 'ParentGuarantee', 'UPDATE')
insert into #functions values(822, 'ParentGuarantee', 'ADD')
insert into #functions values(823, 'ParentGuarantee', 'DELETE')
go

print '=> Loading funcations for the ''LCViewer'' app into the temp table ...'
go
insert into #functions values(830, 'LCViewer', 'VIEW')
go

print '=> Loading funcations for the ''PGViewer'' app into the temp table ...'
go
insert into #functions values(840, 'PGViewer', 'VIEW')
go

print '=> Loading funcations for the ''PricingApp'' app into the temp table ...'
go
insert into #functions values(901, 'PricingApp', 'VIEW')
insert into #functions values(902, 'PricingApp', 'OVER_RIDE')
insert into #functions values(903, 'PricingApp', 'REPRICE')
insert into #functions values(904, 'PricingApp', 'SAVE')
insert into #functions values(905, 'PricingApp', 'REBUILD')
insert into #functions values(906, 'PricingApp', 'VOUCHER')
go

print '=> Loading funcations for the ''PostedPriceMaint'' app into the temp table ...'
go
insert into #functions values(1000, 'PostedPriceMaint', 'ADD')
insert into #functions values(1001, 'PostedPriceMaint', 'DELETE')
insert into #functions values(1002, 'PostedPriceMaint', 'MODIFY')
insert into #functions values(1003, 'PostedPriceMaint', 'VIEW')
go

print '=> Loading funcations for the ''Petroex'' app into the temp table ...'
go
insert into #functions values(1100, 'Petroex', 'ADD')
go

print '=> Loading funcations for the ''CreditViewer'' app into the temp table ...'
go
insert into #functions values(1200, 'CreditViewer', 'QUERY')
insert into #functions values(1201, 'CreditViewer', 'ADD')
insert into #functions values(1202, 'CreditViewer', 'MODIFY')
insert into #functions values(1203, 'CreditViewer', 'DELETE')
go

print '=> Loading funcations for the ''MasterCollateral'' app into the temp table ...'
go
insert into #functions values(1214, 'MasterCollateral', 'ADD')
insert into #functions values(1215, 'MasterCollateral', 'DELETE')
insert into #functions values(1216, 'MasterCollateral', 'UPDATE')
insert into #functions values(1217, 'MasterCollateral', 'ASSIGN')
insert into #functions values(1218, 'MasterCollateral', 'VIEW')
go

print '=> Loading funcations for the ''PLManager'' app into the temp table ...'
go
insert into #functions values(1300, 'PLManager', 'MOVE_PL')
insert into #functions values(1301, 'PLManager', 'BOOK_PL')
go

print '=> Loading funcations for the ''ICTSControl'' app into the temp table ...'
go
insert into #functions values(1400, 'ICTSControl', 'RUN')
insert into #functions values(1401, 'ICTSControl', 'TradingEntity')
go

print '=> Loading funcations for the ''AutopoolCriteria'' app into the temp table ...'
go
insert into #functions values(1500, 'AutopoolCriteria', 'CREATE_DEL')
go

print '=> Loading funcations for the ''AGIPNews'' app into the temp table ...'
go
insert into #functions values(1598, 'AGIPNews', 'ALL')
insert into #functions values(1599, 'AGIPNews', 'READ-ONLY')
go

print '=> Loading funcations for the ''LocationManager'' app into the temp table ...'
go
insert into #functions values(1600, 'LocationManager', 'ALL')
insert into #functions values(1601, 'LocationManager', 'READ-ONLY')
go

print '=> Loading funcations for the ''CalendarMaintenance'' app into the temp table ...'
go
insert into #functions values(1602, 'CalendarMaintenance', 'ALL')
insert into #functions values(1603, 'CalendarMaintenance', 'READ-ONLY')
go

print '=> Loading funcations for the ''UserMaintenance'' app into the temp table ...'
go
insert into #functions values(1604, 'UserMaintenance', 'ALL')
insert into #functions values(1605, 'UserMaintenance', 'READ-ONLY')
go

print '=> Loading funcations for the ''CrudeProfile'' app into the temp table ...'
go
insert into #functions values(1606, 'CrudeProfile', 'ALL')
go

print '=> Loading funcations for the ''CrudeEntry'' app into the temp table ...'
go
insert into #functions values(1607, 'CrudeEntry', 'ALL')
go

print '=> Loading funcations for the ''AGIP01'' app into the temp table ...'
go
insert into #functions values(1608, 'AGIP01', 'ALL')
go

print '=> Loading funcations for the ''CargoTracking'' app into the temp table ...'
go
insert into #functions values(1620, 'CargoTracking', 'ALL')
insert into #functions values(1621, 'CargoTracking', 'READ-ONLY')
insert into #functions values(1622, 'CargoTracking', 'FAR EAST')
insert into #functions values(1623, 'CargoTracking', 'MEDITERRANEAN')
insert into #functions values(1624, 'CargoTracking', 'BLACK SEA')
insert into #functions values(1625, 'CargoTracking', 'NORTH SEA')
insert into #functions values(1626, 'CargoTracking', 'WEST AFRICA')
insert into #functions values(1627, 'CargoTracking', 'AMERICAS')
insert into #functions values(1628, 'CargoTracking', 'CASPIAN SEA')
insert into #functions values(1629, 'CargoTracking', 'PERSIAN GULF')
go

print '=> Loading funcations for the ''QuickFill'' app into the temp table ...'
go
insert into #functions values(50, 'QuickFill', 'VIEW')
insert into #functions values(51, 'QuickFill', 'EDIT')
insert into #functions values(52, 'QuickFill', 'MAINTAIN_TRADER_PORTS')
go

print '=> Loading funcations for the ''Inhouse'' app into the temp table ...'
go
insert into #functions values(53, 'Inhouse', 'EDIT')
insert into #functions values(54, 'Inhouse', 'VIEW')
go

print '=> Loading funcations for the ''CommodityRollup'' app into the temp table ...'
go
insert into #functions values(1609, 'CommodityRollup', 'ALL')
insert into #functions values(1610, 'CommodityRollup', 'READ-ONLY')
go

print '=> Loading funcations for the ''ReportExtractor'' app into the temp table ...'
go
insert into #functions values(950, 'ReportExtractor', 'ADD')
insert into #functions values(951, 'ReportExtractor', 'MODIFY')
insert into #functions values(952, 'ReportExtractor', 'DELETE')
go

print '=> Loading funcations for the ''Repricing'' app into the temp table ...'
go
insert into #functions values(1701, 'Repricing', 'AUTO_OVERRIDE')
insert into #functions values(1702, 'Repricing', 'REPRICE_VOUCHED_COST')
go

print '=> Loading funcations for the ''Bunkers'' app into the temp table ...'
go
insert into #functions values(1800, 'Bunkers', 'ADD')
insert into #functions values(1801, 'Bunkers', 'CONFIRM')
insert into #functions values(1802, 'Bunkers', 'DELETE')
insert into #functions values(1803, 'Bunkers', 'MODIFY')
insert into #functions values(1804, 'Bunkers', 'QUERY')
insert into #functions values(1805, 'Bunkers', 'ADD_ALLOC')
insert into #functions values(1806, 'Bunkers', 'DELETE_ALLOC')
insert into #functions values(1807, 'Bunkers', 'MODIFY_ALLOC')
insert into #functions values(1808, 'Bunkers', 'MODIFY_REFDATA')
insert into #functions values(1809, 'Bunkers', 'CONCL_TRADE')
go

print '=> Loading funcations for the ''CAMaint'' app into the temp table ...'
go
insert into #functions values(1900, 'CAMaint', 'ORDERNUM_UPDATE')
go

print '=> Loading funcations for the ''ENELSAPInterface'' app into the temp table ...'
go
insert into #functions values(2000, 'ENELSAPInterface', 'RUN')
insert into #functions values(2001, 'ENELSAPInterface', 'SC04')
go

print '=> Loading funcations for the ''LivePrices'' app into the temp table ...'
go
insert into #functions values(2100, 'LivePrices', 'ALL')
go

print '=> Loading funcations for the ''LivePriceLoad'' app into the temp table ...'
go
insert into #functions values(2200, 'LivePriceLoad', 'ALL')
go

print '=> Loading funcations for the ''RiskManager'' app into the temp table ...'
go
insert into #functions values(2500, 'RiskManager', 'MOVE_LINK_PORTFOLIOS')
insert into #functions values(2501, 'RiskManager', 'LOCK_UNLOCK_PORTFOLIOS')	
insert into #functions values(2502, 'RiskManager', 'VIEW_PORTFOLIOS')
insert into #functions values(2503, 'RiskManager', 'UPDATE_PORTFOLIOS')
go

print '=> Loading funcations for the ''ReferenceData'' app into the temp table ...'
go
insert into #functions values(2600, 'ReferenceData',	'ACCESS')
go

print '=> Loading funcations for the ''SAPSelect'' app into the temp table ...'
go
insert into #functions values(3000, 'SAPSelect', 'ARCHIVE')
insert into #functions values(3001, 'SAPSelect', 'HIDE')
insert into #functions values(3002, 'SAPSelect', 'DELETE')
insert into #functions values(3003, 'SAPSelect', 'MARK')
insert into #functions values(3004, 'SAPSelect', 'VIEW')
go

print '=> Loading funcations for the ''TaxMaintenance'' app into the temp table ...'
go
insert into #functions values(3070, 'TaxMaintenance', 'ALL')
go
print '=> Loading funcations for the ''Logistics'' app into the temp table ...'
go
insert into #functions values(3200, 'Logistics', 'CreateShipment')
insert into #functions values(3201, 'Logistics', 'ModifyShipment')
insert into #functions values(3202, 'Logistics', 'FinalizeShipment')
insert into #functions values(3203, 'Logistics', 'DeleteShipment')
insert into #functions values(3204, 'Logistics', 'CreateParcel')
insert into #functions values(3205, 'Logistics', 'ModifyParcel')
insert into #functions values(3206, 'Logistics', 'ActualizeParcel')
insert into #functions values(3207, 'Logistics', 'DeleteParcel')
insert into #functions values(3208, 'Logistics', 'MODIFY_SHARED_SEARCH')
insert into #functions values(3209, 'Logistics', 'MODIFY_SHARED_LAYOUT')
go
insert into #functions values(3210, 'Logistics', 'ADD_COST_TEMPLATE')
insert into #functions values(3211, 'Logistics', 'MODIFY_COST_TEMPLATE')
insert into #functions values(3212, 'Logistics', 'DELETE_COST_TEMPLATE')
insert into #functions values(3213, 'Logistics', 'ADD_PATH')
insert into #functions values(3214, 'Logistics', 'MODIFY_PATH')
insert into #functions values(3215, 'Logistics', 'DELETE_PATH')
insert into #functions values(3216, 'Logistics', 'ADD_COST_CODE')
insert into #functions values(3217, 'Logistics', 'MODIFY_COST_CODE')
insert into #functions values(3218, 'Logistics', 'DELETE_COST_CODE')
insert into #functions values(3219, 'Logistics', 'UPDATE_PL_IND')
go
insert into #functions values(3220, 'Logistics', 'ACCESS')
insert into #functions values(3221, 'Logistics', 'MODIFY_SEARCH_OPTIONS')
insert into #functions values(3222, 'Logistics', 'DELETE_SHARED_QUERIES')
insert into #functions values(3223, 'Logistics', 'ADJUST_RINS')
insert into #functions values(3224, 'Logistics', 'ADD_NEW_TRANSPORT')
insert into #functions values(3225, 'Logistics', 'CAN_RUN_CP2')
insert into #functions values(3226, 'Logistics', 'CAN_BULK_UPDATE_PARCEL_SHIPMENT_STATUS')
insert into #functions values(3227, 'Logistics', 'CAN_BULK_UPDATE_TI_COMPLETED_SCHEDULING')
insert into #functions values(3228, 'Logistics', 'CAN_CLEAN_OPEN_ZERO_COSTS')
insert into #functions values(3229, 'Logistics', 'CanEditNominQtyOnPartiallyActlzdPrcls')
insert into #functions values(3230, 'Logistics', 'CAN_BULK_UPDATE_PORTFOLIOS')
go

print '=> Loading funcations for the ''ICTSAdmin'' app into the temp table ...'
go
insert into #functions values(4000, 'ICTSAdmin', 'ALL')
insert into #functions values(4001, 'ICTSAdmin', 'Account Maintenance - View')
insert into #functions values(4002, 'ICTSAdmin', 'Account Maintenance - Edit')
insert into #functions values(4003, 'ICTSAdmin', 'Calendar Maintenance - View')
insert into #functions values(4004, 'ICTSAdmin', 'Calendar Maintenance - Edit')
insert into #functions values(4005, 'ICTSAdmin', 'Commodity Market Maintenance - View')
insert into #functions values(4006, 'ICTSAdmin', 'Commodity Market Maintenance - Edit')
insert into #functions values(4007, 'ICTSAdmin', 'Configuration Data - View')
insert into #functions values(4008, 'ICTSAdmin', 'Configuration Data - Edit')
insert into #functions values(4009, 'ICTSAdmin', 'Credit - View')
insert into #functions values(4010, 'ICTSAdmin', 'Credit - Edit')
go
insert into #functions values(4011, 'ICTSAdmin', 'Location Maintenance - View')
insert into #functions values(4012, 'ICTSAdmin', 'Location Maintenance - Edit')
insert into #functions values(4013, 'ICTSAdmin', 'Pipeline Cycle Data - View')
insert into #functions values(4014, 'ICTSAdmin', 'Pipeline Cycle Data - Edit')
insert into #functions values(4015, 'ICTSAdmin', 'Site Reference Data - View')
insert into #functions values(4016, 'ICTSAdmin', 'Site Reference Data - Edit')
insert into #functions values(4017, 'ICTSAdmin', 'Trade Default Data - View')
insert into #functions values(4018, 'ICTSAdmin', 'Trade Default Data - Edit')
insert into #functions values(4019, 'ICTSAdmin', 'Uom Conversions - View')
insert into #functions values(4020, 'ICTSAdmin', 'Uom Conversions - Edit')
go
insert into #functions values(4021, 'ICTSAdmin', 'User Maintenance - View')
insert into #functions values(4022, 'ICTSAdmin', 'User Maintenance - Edit')
insert into #functions values(4023, 'ICTSAdmin', 'VAT - View')
insert into #functions values(4024, 'ICTSAdmin', 'VAT - Edit')
insert into #functions values(4025, 'ICTSAdmin', 'Commercial Accounting Maintenance - Edit')
insert into #functions values(4026, 'ICTSAdmin', 'Commercial Accounting Maintenance - View')
insert into #functions values(4027, 'ICTSAdmin', 'Tax Maintenance - Edit')
insert into #functions values(4028, 'ICTSAdmin', 'Tax Maintenance - View')
go

print '=> Loading funcations for the ''ReportGenerator'' app into the temp table ...'
go
insert into #functions values(4100, 'ReportGenerator', 'ALL')
go

print '=> Loading funcations for the ''TruckCapture'' app into the temp table ...'
go
insert into #functions values(4200, 'TruckCapture', 'ALL')
insert into #functions values(4201, 'TruckCapture', 'NewTrade')
insert into #functions values(4202, 'TruckCapture', 'EditTrade')
insert into #functions values(4203, 'TruckCapture', 'ViewTrade')
insert into #functions values(4204, 'TruckCapture', 'NewAllocation')
insert into #functions values(4205, 'TruckCapture', 'CancelAllocation')
insert into #functions values(4206, 'TruckCapture', 'ViewAllocations')
insert into #functions values(4207, 'TruckCapture', 'EnterActuals')
insert into #functions values(4208, 'TruckCapture', 'CancelActuals')
insert into #functions values(4209, 'TruckCapture', 'PrintReleaseDocument')
insert into #functions values(4210, 'TruckCapture', 'PrintReleaseDocumentConfirm')
insert into #functions values(4211, 'TruckCapture', 'DeleteTrade')
go

print '=> Loading funcations for the ''ProcessTicket'' app into the temp table ...'
go
insert into #functions values(4300, 'ProcessTicket', 'ALL')
go

print '=> Loading funcations for the ''RMSInterface'' app into the temp table ...'
go
insert into #functions values(4400, 'RMSInterface', 'ALL')
go

print '=> Loading funcations for the ''CVXWebService'' app into the temp table ...'
go
insert into #functions values(5000, 'CVXWebService', 'ALL')
go

print '=> Loading funcations for the ''ExchangeMonitor'' app into the temp table ...'
go
insert into #functions values(6000, 'ExchangeMonitor', 'LOADING_SCHEDULE_BY_ACCT')
go

print '=> Loading funcations for the ''GatewayInboundWS'' app into the temp table ...'
go
insert into #functions values(5200, 'GatewayInboundWS', 'ALL')
go

print '=> Loading funcations for the ''CAInterface'' app into the temp table ...'
go
insert into #functions values(6666, 'CAInterface', 'ALL')
go

print '=> Loading funcations for the ''EntityTagEditor'' app into the temp table ...'
go
insert into #functions values(7000, 'EntityTagEditor', 'EDIT')
go

print '=> Loading funcations for the ''RC'' app into the temp table ...'
go
insert into #functions values(8000, 'RC', 'VIEW')
insert into #functions values(8001, 'RC', 'ADD')
insert into #functions values(8002, 'RC', 'EDIT')
insert into #functions values(8003, 'RC', 'DELETE')
go


print '=> Loading funcations for the ''TicketActuals'' app into the temp table ...'
go
insert into #functions values(9200, 'TicketActuals', 'FEED_SOURCE')
insert into #functions values(9201, 'TicketActuals', 'UPLOAD_ACTUALS')
go

/* CVX/FAMM-specific functions     9/29/2004   requested by Frank Festini
insert into #functions values(10001, '4GenInterface', 'BUNKER_IMPORT')
insert into #functions values(10002, '4GenInterface', 'BULK_EXPORT')
insert into #functions values(10003, '4GenInterface', 'INV_EXPORT')
insert into #functions values(10004, '4GenInterface', 'ACCT_LOAD')
*/
go

/* NOTE that the functions #20000 ..#3000 are reserved for dynamically 
             assigned function_num for the security objects so that records 
             can be setup in the user_permission table to control whether a 
             used can edit the data in portfolio_tag table and related tables
*/

print '=> Loading functions for the ''OpsManager'' app into the temp table ...'
go
insert into #functions values(14000, 'OpsManager', 'UPDATE_NONECO_DATA')
insert into #functions values(14001, 'OpsManager', 'UPDATE_NONECO_DATA_SWAP')
go

print '=> Loading functions for the ''PortfolioManager'' app into the temp table ...'
go
insert into #functions values(20001, 'PortfolioManager', 'PORT_TAG_MODIFY_CLASS')
insert into #functions values(20002, 'PortfolioManager', 'PORT_TAG_MODIFY_DEPT')
insert into #functions values(20003, 'PortfolioManager', 'PORT_TAG_MODIFY_DESK')
insert into #functions values(20004, 'PortfolioManager', 'PORT_TAG_MODIFY_DIVISION')
insert into #functions values(20005, 'PortfolioManager', 'PORT_TAG_MODIFY_GROUP')
insert into #functions values(20006, 'PortfolioManager', 'PORT_TAG_MODIFY_LEGALENT')
insert into #functions values(20007, 'PortfolioManager', 'PORT_TAG_MODIFY_LOCATION')
insert into #functions values(20008, 'PortfolioManager', 'PORT_TAG_MODIFY_PRFTCNTR')
insert into #functions values(20009, 'PortfolioManager', 'PORT_TAG_MODIFY_STRATEGY')
insert into #functions values(20010, 'PortfolioManager', 'PORT_TAG_MODIFY_TRADER')
go

print '=> Loading functions for the ''TradeSearch'' app into the temp table ...'
go
insert into #functions values(30001, 'TradeSearch', 'EDIT_CREDIT_TERM')
insert into #functions values(30002, 'TradeSearch', 'EDIT_CREDIT_APPROVED')
go









/* DO NOT NEED TO CHANGE THE CODE BELOW */

print ' '
print 'Moving records in temp table to the icts_function table ...'
go

declare @function_num              int,
        @temp_function_num         int,
        @app_name                  varchar(20),
        @function_name             varchar(40),
        @rows_affected             int
        
select @function_num = min(function_num)
from #functions

while @function_num is not null
begin
   select @app_name = app_name,
          @function_name = function_name
   from #functions
   where function_num = @function_num
   
   select @temp_function_num = null
   select @temp_function_num = function_num
   from dbo.icts_function
   where app_name = @app_name and
         function_name = @function_name
   if @temp_function_num  is null
   begin
      begin try
        insert into dbo.icts_function
        select function_num, app_name, function_name, 1
        from #functions
        where app_name = @app_name and
              function_name = @function_name
        select @rows_affected = @@rowcount
      end try
      begin catch
        print '=> Failed to add function #' + cast(@function_num as varchar) + ' (' + @function_name + ') for the ''' + @app_name + ''' app due to the error:'
        print '==> ERROR: ' + ERROR_MESSAGE()
        goto nextfunc
      end catch
      if @rows_affected > 0
         print '=> The function #' + cast(@function_num as varchar) + ' (' + @function_name + ') for the ''' + @app_name + ''' app was added successfully'
      else
         print '=> The function #' + cast(@function_num as varchar) + ' (' + @function_name + ') for the ''' + @app_name + ''' app was NOT added successfully ?????'
   end
   else
   begin
      if @function_num <> @temp_function_num
      begin
         print '=> The different function #' + cast(@temp_function_num as varchar) + ' used by (app_name = ''' + @app_name + ''', function_name = ''' + @function_name + ''''
         goto nextfunc
      end
      else
         print '=> The function #' + cast(@function_num as varchar) + ' has already existed in the icts_function table!'
   end

nextfunc:
   select @function_num = min(function_num)
   from #functions
   where function_num > @function_num    
end
drop table #functions
go