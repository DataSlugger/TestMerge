set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bc_mail_criteria_time
go

print 'Loading system reference data into the bc_mail_criteria_time table ...'
go

insert into dbo.bc_mail_criteria_time 
   values('ACTUALIZED', 'Cost values are no longer estimates.', 1)
go

insert into dbo.bc_mail_criteria_time 
   values('COMPLETED', 'No current criteria defines completed.', 1)
go

insert into dbo.bc_mail_criteria_time 
   values('CREATED', 'Cost has been created', 1)
go

insert into dbo.bc_mail_criteria_time 
   values('PROCESSED', 'Cost processed and no longer editable.', 1)
go

insert into dbo.bc_mail_criteria_time 
   values('UPDATING', 'Cost is being updated', 1)
go

insert into dbo.bc_mail_criteria_time 
   values('VERIFIED', 'Cost is ready to be vouched.', 1)
go

