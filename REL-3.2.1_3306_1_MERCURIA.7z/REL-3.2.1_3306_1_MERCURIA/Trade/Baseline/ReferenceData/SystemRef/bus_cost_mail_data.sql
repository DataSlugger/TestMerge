set nocount on

set QUOTED_IDENTIFIER ON
go

truncate table bus_cost_mail
go

print 'Loading system reference data into the bus_cost_mail table ...'
go

insert into dbo.bus_cost_mail 
   values('MESSAGE', 'MESSAGE', 1)
go

