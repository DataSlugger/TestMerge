set nocount on

set QUOTED_IDENTIFIER ON
go

print 'Loading system reference data into the external_trade_state table ...'
go

if not exists (select 1
               from dbo.external_trade_state
               where external_trade_state_name = 'Add')
   INSERT dbo.external_trade_state 
     (oid, external_trade_state_name, trans_id) 
      VALUES (1, 'Add', 1)
go

if not exists (select 1
               from dbo.external_trade_state
               where external_trade_state_name = 'Update')
   INSERT dbo.external_trade_state 
     (oid, external_trade_state_name, trans_id) 
      VALUES (2, 'Update', 1)
go

if not exists (select 1
               from dbo.external_trade_state
               where external_trade_state_name = 'Delete')
   INSERT dbo.external_trade_state 
     (oid, external_trade_state_name, trans_id) 
      VALUES (3, 'Delete', 1)
go

if not exists (select 1
               from dbo.external_trade_state
               where external_trade_state_name = 'DeleteAndAdd')
   INSERT dbo.external_trade_state 
     (oid, external_trade_state_name, trans_id) 
      VALUES (4, 'DeleteAndAdd', 1)
go
