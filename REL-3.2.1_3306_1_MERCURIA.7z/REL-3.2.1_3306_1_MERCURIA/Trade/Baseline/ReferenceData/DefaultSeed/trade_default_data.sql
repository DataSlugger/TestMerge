print 'Loading additional seed data into the trade_default table ...'
go

insert into trade_default values(1, NULL, "BRENT", NULL, NULL, "N.SEA", "N.SEA", 
NULL, "MB", "USD", "BBL", 1, "SUKO90", "NC30ABL", "FOB", NULL, "SULLOM", 
NULL, "MB", NULL, "MB", 5.000000, "%", "+-", "BUYER", 3, NULL, NULL, NULL, 
"USD", "BBL", NULL, 1)
go

insert into trade_default values(2, NULL, "UNL92", NULL, NULL, "NYHCRG", 
"NYHCRG", 30000.000000, "MT", "USD", "BBL", 1, "TXO1/94", "NC3/5", "CIF", 
NULL, "DEL", NULL, NULL, NULL, NULL, 10.000000, "%", "+-", "SELLER", 3, 
NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(3, NULL, NULL, NULL, "SWAPFLT", NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, "SITCOCFD", "NC5AFP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, "%", "+/-", NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(4, NULL, "WTI", NULL, "PHYSICAL", "CUSHING", 
"CUSHING", NULL, "MB", "USD", "BBL", 1, "CONOCO5", "PROX20", "FIP", "ARCO", 
"CUSHING", NULL, "MB", NULL, "MB", NULL, "%", "+-", "SELLER", 3, NULL, NULL, 
NULL, "USD", "BBL", NULL, 1)
go

insert into trade_default values(5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(6, NULL, "CAPTAIN", NULL, "PHYSICAL", "N.SEA", 
"N.SEA", 500000.000000, "BBL", "USD", "BBL", 1, "TXO6/97", "NC30ACD", NULL, 
"SHUTTANK", "PEMBROKE", NULL, NULL, NULL, NULL, 10.000000, "%", "+/-", "SELLER", 
3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(7, NULL, "DUBAI", NULL, NULL, NULL, NULL, NULL, 
"MB", "USD", "BBL", 1, NULL, "NC30ABL", "FOB", NULL, "FATEH", NULL, "MB", 
NULL, "MB", 5.000000, "%", "+-", NULL, 3, NULL, NULL, NULL, "USD", "BBL", NULL, 
1)
go

insert into trade_default values(8, NULL, "DUC", NULL, "PHYSICAL", "N.SEA", 
"N.SEA", NULL, "MB", "USD", "BBL", 1, "TXO11/94", "NC30ABL", "FOB", "VESSEL", 
"DUCTERM", NULL, NULL, NULL, NULL, 5.000000, "%", "+/-", "SELLER", 3, NULL, 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(9, NULL, "STAT", NULL, "PHYSICAL", "N.SEA", 
"N.SEA", NULL, "BBL", "USD", "BBL", 1, "STATOIL", "NC30ABL", "CIF", "VESSEL", 
"STATFJOR", NULL, NULL, NULL, NULL, 10.000000, "%", "+/-", "SELLER", 3, NULL, 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(10, NULL, "BERYL", NULL, "PHYSICAL", "N.SEA", 
"N.SEA", NULL, "MB", "USD", "BBL", 1, "MOBIL", "NC30ACD", "OUTTURN", "SHUTTANK", 
"PEMBROKE", NULL, NULL, NULL, NULL, 5.000000, "%", "+/-", "SELLER", 3, NULL, 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(11, NULL, "URAL", NULL, "PHYSICAL", "DLVDRDAM", 
"DLVDRDAM", NULL, "BBL", "USD", "BBL", 1, "INCO", "NC30ABL", "CIF", "VESSEL", 
"ROTTERDA", NULL, NULL, NULL, NULL, 10.000000, "%", "+/-", "BUYER", 3, NULL, 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(12, NULL, "BLENHEIM", NULL, "PHYSICAL", 
"N.SEA", "N.SEA", NULL, "MB", "USD", "BBL", 1, "BPOI2", "NC30ACD", "OUTTURN", 
"SHUTTANK", "PEMBROKE", NULL, NULL, NULL, NULL, 5.000000, "%", "+/-", "SELLER", 
3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(13, NULL, "KIRKUK", NULL, "PHYSICAL", 
"CFOBARAG", "CFOBARAG", NULL, "MB", "USD", "BBL", 1, "SITCO1", "NC30FBL", "CFR", 
"VESSEL", "CEYHAM1", NULL, NULL, NULL, NULL, 5.000000, "%", "+/-", "SELLER", 3, 
NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(14, NULL, "BASRAHLT", NULL, "PHYSICAL", 
"PGULF", "PGULF", NULL, "BBL", "USD", "BBL", 1, "BPOI2", "OTHER", "INTANK", 
"STORAGE", "ROTTERDA", NULL, NULL, NULL, NULL, NULL, "%", "+/-", "SELLER", 3, 
NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(16, NULL, "LIVBAYBL", NULL, "PHYSICAL", 
"N.SEA", "N.SEA", NULL, "BBL", "USD", "BBL", 1, "BHP", "NC30ABL", "CFR", 
"VESSEL", "ROTTERDA", NULL, NULL, NULL, NULL, 10.000000, "%", "+/-", "SELLER", 
3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(18, NULL, "OSEBERG", NULL, "PHYSICAL", "N.SEA", 
"N.SEA", NULL, "BBL", "USD", "BBL", 1, "STATOIL", "NC30ABL", "FOB", "VESSEL", 
"STURE", NULL, NULL, NULL, NULL, 5.000000, "%", "+/-", "SELLER", 3, NULL, NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(19, NULL, "GULLFAKS", NULL, "PHYSICAL", 
"N.SEA", "N.SEA", NULL, "BBL", "USD", "BBL", 1, "STATOIL", "NC30ABL", "FOB", 
"VESSEL", "NORWAY", NULL, NULL, NULL, NULL, 5.000000, "%", "+/-", "SELLER", 3, 
NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(20, NULL, "GULLFAKC", NULL, "PHYSICAL", 
"N.SEA", "N.SEA", NULL, "BBL", "USD", "BBL", 1, "STATOIL", "NC30ABL", "FOB", 
"VESSEL", "NORWAY", NULL, NULL, NULL, NULL, 5.000000, "%", "+/-", "SELLER", 3, 
NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(40, NULL, "CABINDA", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, NULL, "NC30ABL", "FOB", NULL, "CABINDA", NULL, 
"MB", NULL, "MB", 5.000000, "%", "+-", NULL, 3, NULL, NULL, NULL, NULL, NULL, 
NULL, 1)
go

insert into trade_default values(42, NULL, "HO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, "PASADENA", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(45, NULL, "JET", NULL, NULL, NULL, NULL, NULL, 
"MB", "USD", "GAL", 1, NULL, "NC2ROI", "FOB", NULL, "NYHARBOR", NULL, "MB", 
NULL, "MB", NULL, "%", "+-", NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(62, NULL, "NO6LSSR", NULL, "PHYSICAL", 
"CFOBNWE", "CFOBNWE", NULL, "MT", "USD", "MT", 1, "CONOCO5", "NCENDMNT", "FOB", 
"VESSEL", "ROTTERDA", NULL, "MT", NULL, "MT", NULL, "%", "+-", "SELLER", 3, 
NULL, NULL, NULL, "USD", "MT", NULL, 1)
go

insert into trade_default values(120, NULL, "TAPIS", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
"MB", NULL, "MB", NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(126, NULL, "DURI", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, NULL, NULL, NULL, NULL, "DUMAI", NULL, "MB", NULL, 
"MB", NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(142, NULL, "URAL", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, "INCO", "NC30FBL", "CIF", NULL, "WILHEMS", 
NULL, "MB", NULL, "MB", 5.000000, "%", "+-", NULL, 3, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into trade_default values(197, NULL, "BONNYL", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, "NNPC", "NC30ABL", "FOB", NULL, "BONNY", NULL, 
"MB", NULL, "MB", 5.000000, "%", "+-", NULL, 3, NULL, NULL, NULL, NULL, NULL, 
NULL, 1)
go

insert into trade_default values(198, NULL, "BONNYM", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, NULL, NULL, NULL, NULL, NULL, NULL, "MB", NULL, 
"MB", NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(199, NULL, "BRASS", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, NULL, "NC30FBL", "FOB", NULL, "BRASS", NULL, 
"MB", NULL, "MB", 5.000000, "%", "+-", NULL, 3, NULL, NULL, NULL, NULL, NULL, 
NULL, 1)
go

insert into trade_default values(205, NULL, "EKOFISK", NULL, NULL, "N.SEA", 
"N.SEA", NULL, "MB", "USD", "BBL", 1, "PHILLIPS", "NC30ABL", "FOB", NULL, 
"TEESSIDE", NULL, "MB", NULL, "MB", 5.000000, "%", "+-", NULL, 3, NULL, NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(208, NULL, "ESCRAVOS", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, "INCO", "NC30FBL", "CIF", NULL, "ALGECIRA", 
NULL, "MB", NULL, "MB", 5.000000, "%", "+-", NULL, 3, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into trade_default values(209, NULL, "FLOTTA", NULL, NULL, "DTDNSEA", 
"DTDNSEA", NULL, "MB", "USD", "BBL", 1, "BPOI1", "NC30ABL", "FOB", NULL, 
"FLOTTA", NULL, "MB", NULL, "MB", 5.000000, "%", "+-", NULL, 3, NULL, NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(210, NULL, "FORCADOS", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, "INCO", "NC30ABL", "CFR", NULL, "ABIDJAN", 
NULL, "MB", NULL, "MB", 5.000000, "%", "+-", NULL, 3, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into trade_default values(211, NULL, "FORTIES", NULL, NULL, "DTDNSEA", 
"DTDNSEA", NULL, "MB", "USD", "BBL", 1, NULL, "NC30ABL", "FOB", NULL, 
"HOUNDS", NULL, "MB", NULL, "MB", 5.000000, "%", "+-", NULL, 3, NULL, NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(215, NULL, "LEONA", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, NULL, NULL, NULL, NULL, NULL, NULL, "MB", NULL, 
"MB", NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(218, NULL, "ORIENTE", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, NULL, NULL, NULL, NULL, NULL, NULL, "MB", NULL, 
"MB", NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(222, NULL, "QUAIBOE", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, "NNPC", "NC30ABL", "FOB", NULL, "QUA", NULL, 
"MB", NULL, "MB", 5.000000, "%", "+-", NULL, 3, NULL, NULL, NULL, NULL, NULL, 
NULL, 1)
go

insert into trade_default values(226, NULL, "SOYO", NULL, NULL, NULL, NULL, 
NULL, "MB", "USD", "BBL", 1, NULL, NULL, NULL, NULL, NULL, NULL, "MB", NULL, 
"MB", NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(232, NULL, "UNL87", NULL, NULL, "CUSGP", 
"CUSGP", NULL, "MB", "USD", "GAL", 1, "STANDARD", "NC2ABL", "FOB", NULL, 
"PASADENA", NULL, "MB", NULL, "MB", NULL, "%", "+-", NULL, 3, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into trade_default values(236, NULL, "MTBE", NULL, NULL, NULL, NULL, 
NULL, "BBL", "USD", "GAL", 1, NULL, "NC30FBL", "FOB", NULL, "HOUST/TC", NULL, 
"MB", NULL, "MB", 5.000000, "%", "+-", "BUYER", 3, NULL, NULL, NULL, NULL, NULL, 
NULL, 1)
go

insert into trade_default values(261, NULL, "NAPHTHA", NULL, "PHYSICAL", NULL, 
NULL, NULL, "MT", "USD", "MT", 1, "DOW", "NULL", "CFR", "VESSEL", "ROTTERDA", 
20.000000, "MT", 25.000000, "MT", NULL, "%", "+-", NULL, 3, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into trade_default values(264, NULL, "NATGAS", NULL, NULL, NULL, NULL, 
10000.000000, "MMBT", "USD", "MMBT", 1, NULL, "NC25FMD", "DLVD", NULL, NULL, 
NULL, "MMBT", NULL, "MMBT", NULL, "MMBT", "+-", NULL, 3, NULL, NULL, NULL, 
"USD", "MMBT", NULL, 1)
go

insert into trade_default values(276, NULL, "NATGAS", NULL, "OTCAPO", NULL, 
NULL, 10000.000000, "MMBT", "USD", "MMBT", 1, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, 
NULL, 1)
go

insert into trade_default values(277, NULL, "NATGAS", NULL, "OTCCASH", NULL, 
NULL, 10000.000000, "MMBT", "USD", "MMBT", 1, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, 
NULL, 1)
go

insert into trade_default values(278, NULL, "NATGAS", NULL, "OTCPHYS", NULL, 
NULL, 10000.000000, "MMBT", "USD", "MMBT", 1, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, 
NULL, 1)
go

insert into trade_default values(300, NULL, NULL, NULL, "SWAP", NULL, NULL, 
NULL, NULL, "USD", NULL, 1, "SITCOCFD", "NC5AFP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, "+/-", NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(373, NULL, NULL, NULL, "FUTURE", NULL, NULL, 
NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "%", "+/-", NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(400, NULL, "VGOHS", NULL, "PHYSICAL", 
"CFOBNWE", "CFOBNWE", NULL, "MT", "USD", "MT", 1, "CONOCO5", "NCENDMNT", "FOB", 
"VESSEL", "ROTTERDA", NULL, "MT", NULL, "MT", NULL, "%", "+-", "SELLER", 3, 
NULL, NULL, NULL, "USD", "MT", NULL, 1)
go

insert into trade_default values(401, NULL, "NO6-10", NULL, "PHYSICAL", 
"CCIFNWE", "CCIFNWE", NULL, "MT", "USD", "MT", 1, "CONOCO5", "NC30AFPC", "FOB", 
"VSLORBRG", "NORTH", 20000.000000, "MT", 25000.000000, "MT", NULL, NULL, "RNG", 
NULL, 3, NULL, NULL, NULL, "USD", "MT", NULL, 1)
go

insert into trade_default values(402, NULL, "E4F", NULL, "PHYSICAL", "CCIFNWE", 
"CCIFNWE", NULL, "MT", "USD", "BBL", 1, "SITCO2", "PROX20", "FOB", "VESSEL", 
"OXSUND", NULL, "MT", NULL, "MT", NULL, "%", "+/-", "SELLER", 3, NULL, NULL, 
NULL, "USD", "MT", NULL, 1)
go

insert into trade_default values(403, NULL, "NO6-30", NULL, "PHYSICAL", 
"CCIFNWE", "CCIFNWE", NULL, "MT", "USD", "MT", 1, "INCO", "NC5ABLC", "FOB", 
"VESSEL", "GOTHNBRG", 10000.000000, "MT", 13000.000000, "MT", NULL, NULL, "RNG", 
NULL, 3, NULL, NULL, NULL, "USD", "MT", NULL, 1)
go

insert into trade_default values(404, NULL, "NO6-35", NULL, "PHYSICAL", 
"CFOBNWE", "CFOBNWE", NULL, "MT", "USD", "MT", 1, "CONOCO5", "PROX20", "FOB", 
"VESSEL", "ROTTERDA", NULL, "MT", NULL, "MT", 10.000000, "MT", "+/-", "BUYER", 
3, NULL, NULL, NULL, "USD", "MT", NULL, 1)
go

insert into trade_default values(451, NULL, "SUMATRAL", NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, "DUMAI", NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(501, NULL, NULL, NULL, "OTCAPO", NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "STANDARD", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(502, NULL, NULL, NULL, "OTCCASH", NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "STANDARD", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(503, NULL, NULL, NULL, "OTCPHYS", NULL, NULL, 
NULL, NULL, NULL, NULL, 1, "STANDARD", NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into trade_default values(515, NULL, "NATGAS", NULL, "PHYSICAL", NULL, 
NULL, NULL, "MMBT", "USD", "MMBT", 1, NULL, "NC25FMD", "DLVD", NULL, NULL, NULL, 
"MMBT", NULL, "MMBT", NULL, "MMBT", "+-", NULL, 3, NULL, NULL, NULL, "USD", 
"MMBT", NULL, 1)
go

insert into trade_default values(516, NULL, "VGOLS", NULL, "PHYSICAL", 
"CCIFNWE", "CCIFNWE", NULL, "MT", "USD", "MT", 1, "CONOCO5", "NCENDMNT", "CFR", 
"VESSEL", "ROTTERDA", NULL, "MT", NULL, "MT", NULL, "%", "+-", "SELLER", 3, 
NULL, NULL, NULL, "USD", "MT", NULL, 1)
go

insert into trade_default values(517, NULL, "HSFO380", NULL, "PHYSICAL", 
"CFOBNWE", "CFOBNWE", NULL, "MT", "USD", "MT", 1, "CONOCO5", "NCENDMNT", "FOB", 
"VESSEL", "ROTTERDA", NULL, "MT", NULL, "MT", NULL, "MT", "+-", "SELLER", 3, 
NULL, NULL, NULL, "USD", "MT", NULL, 1)
go

insert into trade_default values(518, NULL, "GOIL590", NULL, "PHYSICAL", 
"CCIFNWE", "CCIFNWE", NULL, "MT", "USD", "MT", 1, "INCO", "NC3/5", "CIF", 
"VESSEL", "LE", NULL, "MT", NULL, "MT", 10.000000, "MT", "+/-", "SELLER", 2, 
NULL, NULL, NULL, "USD", "MT", NULL, 1)
go

insert into trade_default values(519, NULL, NULL, NULL, "STORAGE", 
NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, 
"STORAGE", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

