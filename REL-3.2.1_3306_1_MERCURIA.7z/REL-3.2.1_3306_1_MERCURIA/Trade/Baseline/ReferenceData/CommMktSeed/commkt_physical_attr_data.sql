print 'Loading additional seed data into the commkt_physical_attr table ...'
go

insert into commkt_physical_attr values(2, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200004', 'D', 'D', 'B', '', 'N', 7, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(12, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(26, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200003', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(27, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200003', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(28, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(30, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(31, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 11, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(34, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, '199912', 'D', 'D', 'B', '', 'N', 48, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(38, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(41, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(53, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(55, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(58, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(60, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(64, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(65, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(66, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(72, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(84, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(86, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(91, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(92, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(93, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(94, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(95, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(96, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(97, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(101, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '199912', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(102, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200002', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(104, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(105, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(113, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(117, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(125, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(126, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, 2.000000, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(131, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(135, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(137, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, 2.000000, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(140, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 1, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(141, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(143, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(144, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(146, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(149, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(150, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(164, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(168, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 1, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(170, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(187, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', 'A', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(201, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, '199903', 'D', 'D', 'B', 'A', 'N', 100, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(203, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '199901', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(204, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '199906', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(207, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(210, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(227, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200012', 'D', 'D', 'B', '', 'N', 111, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(228, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(229, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200006', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(230, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '199901', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(231, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(232, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, '200010', 'D', 'D', 'B', '', 'N', 48, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(234, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200003', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(236, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 48, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(237, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200006', 'D', 'D', 'B', '', 'N', 10, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(240, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(242, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200003', 'D', 'D', 'B', '', 'N', 120, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(243, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'M', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(251, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(257, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(348, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', 'A', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(400, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', 'A', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(402, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, '200004', 'D', 'D', 'B', 'A', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(800, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(801, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(802, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(808, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(809, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(814, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(818, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(821, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(883, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(899, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(902, 'A', 0.0, 'BBL', 'GAL', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(966, 'A', 0.0, 'BBL', 'BBL', 'USD', 'A', 
NULL, 2.000000, '200002', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1248, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1250, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1251, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1252, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200003', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1347, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1348, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1429, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 48, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1442, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1447, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1449, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1450, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1541, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1554, 'I', 0.0, 'BBL', 'BBL', 'USD', 
'A', 0.010000, 0.100000, 'SPOT01', 'D', 'D', 'B', '', 'N', 12, '1', NULL, NULL, 
NULL, NULL, 'M', NULL, 1.000000, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(1555, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, 'M', NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1557, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'W', '4', 'B', '', 'I', NULL, '0', NULL, NULL, 
NULL, NULL, 'M', NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1559, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', 0.010000, 0.100000, 'SPOT', 'D', 'D', 'B', '', 'N', 52, '0', NULL, NULL, 
NULL, NULL, 'M', NULL, 10.000000, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(1564, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'W', '4', 'B', '', 'I', NULL, '0', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1568, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1569, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1570, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1571, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, 'M', NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1573, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1575, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, 2.000000, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1579, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1583, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1587, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1594, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1596, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1599, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1603, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1610, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1612, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1615, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', 'APPI', 1)
go

insert into commkt_physical_attr values(1617, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1623, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1624, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1625, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1628, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1629, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1631, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1637, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1638, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1641, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1643, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, '200001', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1661, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, 'SPOT01', 'D', 'D', 'B', '', 'N', 1, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1662, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, 'SPOT01', 'D', 'D', 'B', '', 'N', 1, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1673, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1683, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1687, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1688, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1689, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1690, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1693, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1699, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1700, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT02', 'D', 'D', 'B', '', 'N', 2, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1701, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1729, 'A', 0.0, 'BBL', 'MMBT', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'E', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1731, 'A', 0.0, 'BBL', 'MMBT', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'E', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1733, 'A', 0.0, 'BBL', 'MMBT', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1776, 'A', 0.0, 'BBL', 'MMBT', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'E', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1777, 'A', 0.0, 'BBL', 'MMBT', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'R', 'R', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1780, 'A', 0.0, 'BBL', 'MMBT', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'E', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1790, 'A', 0.0, 'BBL', 'MMBT', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'E', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1796, 'A', 0.0, 'BBL', 'MMBT', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 40, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1813, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', 0.010000, 0.100000, '199804', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, 
NULL, NULL, 'M', NULL, NULL, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(1814, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1817, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1819, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1820, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1822, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1824, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1832, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1835, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1836, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '200012W4', 'D', 'D', 'A', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, 'M', NULL, NULL, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(1837, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, '199801', 'D', 'D', 'B', '', 'N', 12, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, 2.000000, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1838, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1839, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1840, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'E', NULL, '1', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1841, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, '199806', 'D', 'D', 'B', '', 'E', 18, '1', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1847, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'E', NULL, '1', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1848, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'E', NULL, '1', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1849, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'E', NULL, '1', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1851, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1852, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1854, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1855, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1856, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1857, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1859, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'M', '', 'N', 20, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1868, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1869, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, NULL, '199806', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(1870, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1871, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1875, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'E', 30, '1', NULL, NULL, 
'NYMEX', NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1876, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '199806', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1877, 'A', 0.0, 'BBL', 'MMBT', 'USD', 
'A', NULL, NULL, 'SPOT01', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, 'NYMEX', 
NULL, NULL, NULL, NULL, 'INTERNAL', 'FERC', 1)
go

insert into commkt_physical_attr values(1878, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1879, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, 2.000000, 'INTERNAL', 'OPIS', 1)
go

insert into commkt_physical_attr values(1880, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, 2.000000, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1882, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1883, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1884, 'A', 0.0, 'BBL', 'GAL', 'USC', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'E', 31, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1885, 'A', 0.0, 'BBL', 'GAL', 'USC', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'E', 31, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1886, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1887, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(1891, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1892, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1893, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1894, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'ARGUS', NULL, 1)
go

insert into commkt_physical_attr values(1895, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1896, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1897, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1899, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1903, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1905, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 31, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1907, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', 0.010000, 0.100000, '199809W1', 'D', 'D', 'A', '', 'N', 96, '2', NULL, 
NULL, NULL, NULL, 'M', NULL, 10.000000, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(1908, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199809W1', 'D', 'D', 'A', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, 'M', NULL, 10.000000, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(1910, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(1911, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '199806', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1913, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1916, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1917, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1918, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, NULL, '199810', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, 'NYMEX', 
NULL, 'M', NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(1919, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1920, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, NULL, '199810', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, 'NYMEX', 
NULL, 'M', NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(1923, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '199811', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, 'NYMEX', 
NULL, 'M', NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1926, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, '199810', 'D', 'D', 'M', '', 'N', 24, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1927, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, 'SPOT01', 'D', 'D', 'S', '', 'N', 12, '2', NULL, NULL, 'NYMEX', 
NULL, 'D', NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(1932, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, NULL, '199810', 'D', 'D', 'B', '', 'N', 12, '2', NULL, NULL, 'NYMEX', 
NULL, 'M', NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(1933, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, 2.000000, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1936, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, 2.000000, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1937, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, 2.000000, 'ARGUS', NULL, 1)
go

insert into commkt_physical_attr values(1938, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, 2.000000, 'ARGUS', NULL, 1)
go

insert into commkt_physical_attr values(1939, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199810', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, 'NYMEX', 
NULL, 'M', NULL, NULL, 'PLATTS', 'PLATTS', 1)
go

insert into commkt_physical_attr values(1940, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, 2.000000, 'ARGUS', NULL, 1)
go

insert into commkt_physical_attr values(1945, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, '199809', 'D', 'D', 'M', '', 'N', 2, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'PLATTS', 'PLATTS', 1)
go

insert into commkt_physical_attr values(1946, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, 4.000000, '199806', 'D', 'D', 'B', '', 'N', 4, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'PLATTS', 'PLATTS', 1)
go

insert into commkt_physical_attr values(1947, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, '199903', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'PLATTS', 'DRI', 1)
go

insert into commkt_physical_attr values(1951, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1953, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, 2.000000, 'PLATTS', NULL, 1)
go

insert into commkt_physical_attr values(1955, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, 'SPOT', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'PLATTS', NULL, 1)
go

insert into commkt_physical_attr values(1956, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', '', 'N', NULL, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, 3.000000, 'PLATTS', NULL, 1)
go

insert into commkt_physical_attr values(1958, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199812', 'D', 'D', 'B', '', 'N', 120, '0', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'KOCH', NULL, 1)
go

insert into commkt_physical_attr values(1959, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, 'SPOT', 'D', 'D', 'B', '', 'N', 48, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTS', NULL, 1)
go

insert into commkt_physical_attr values(1960, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, 'SPOT', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(1962, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, 'SPOT', 'D', 'D', 'B', '', 'N', 59, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'PLATTS', NULL, 1)
go

insert into commkt_physical_attr values(1968, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 120, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'PLATTS', NULL, 1)
go

insert into commkt_physical_attr values(1969, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 120, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1970, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, 'SPOT', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'SUNREF', NULL, 1)
go

insert into commkt_physical_attr values(1971, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 120, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1972, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, 'SPOT', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'SCURPERM', NULL, 1)
go

insert into commkt_physical_attr values(1973, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTS', NULL, 1)
go

insert into commkt_physical_attr values(1974, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1975, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 48, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1976, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 48, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTS', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(1978, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199902', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'ARGUS', 'ARGUS', 1)
go

insert into commkt_physical_attr values(1979, 'A', 0.0, 'BBL', '%', 'USD', 'A', 
NULL, NULL, '199901', 'D', 'D', 'M', '', 'N', 60, '0', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1980, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199902W1', 'D', 'D', 'A', '', 'N', 52, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1986, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1987, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1988, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1989, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1990, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1996, 'A', 0.0, 'BBL', 'UNIT', 'WGC', 
'A', NULL, NULL, '199902', 'D', 'D', 'B', '', 'I', 60, '1', NULL, NULL, NULL, 
NULL, 'M', NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(1997, 'A', 0.0, 'BBL', 'UNIT', 'USD', 
'A', NULL, NULL, '199903', 'D', 'D', 'B', '', 'I', 60, '1', NULL, NULL, 'WGC', 
NULL, NULL, NULL, NULL, 'INTERNAL', 'ICIS-LOR', 1)
go

insert into commkt_physical_attr values(1999, 'A', 0.0, 'BBL', 'UNIT', 'USD', 
'A', NULL, NULL, '199903', 'D', 'D', 'B', '', 'I', 60, '1', NULL, NULL, 'WGC', 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2001, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 48, '2', NULL, NULL, 
'NWP/US', NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2002, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199812', 'D', 'D', 'M', '', 'N', 24, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'PLATTS', NULL, 1)
go

insert into commkt_physical_attr values(2003, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199812', 'D', 'D', 'M', '', 'N', 24, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'PLATTS', NULL, 1)
go

insert into commkt_physical_attr values(2006, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'Q', NULL, NULL, '199903', 'D', 'D', 'B', '', 'I', 60, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2007, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'Q', NULL, NULL, '199903', 'D', 'D', 'B', '', 'I', 60, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2009, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199903W1', 'D', 'D', 'W', '', 'N', 52, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2010, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'M', '', 'N', 36, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'PLATTS', 'DRI', 1)
go

insert into commkt_physical_attr values(2011, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199903', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2012, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, '199904', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2013, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, NULL, 
'M', NULL, NULL, 'INTERNAL', 'DRI', 1)
go

insert into commkt_physical_attr values(2014, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199903', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'PLATTS', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2015, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'PLATTS', 'DRI', 1)
go

insert into commkt_physical_attr values(2016, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199903', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2017, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'PLATTS', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2019, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, '199901', 'D', 'D', 'B', '', 'N', 50, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2021, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199901', 'D', 'D', 'M', '', 'N', 36, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2023, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2024, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2026, 'A', 0.0, 'BBL', 'GAL', 'USD', 
'A', NULL, NULL, 'SPOT', 'D', 'D', 'A', '', 'N', 100, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2027, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199904', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2028, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199905', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2029, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199905', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2031, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199905', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2034, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199904', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2036, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199905', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2038, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199905', 'D', 'D', 'M', '', 'N', 36, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2041, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199905', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2043, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199905', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2049, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199906', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2050, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199907', 'D', 'D', 'B', '', 'N', 36, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2051, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199907', 'D', 'D', 'B', '', 'N', 12, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2052, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199907', 'D', 'D', 'M', '', 'N', 12, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2053, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199906', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTSPT', 'PLATTSPT', 1)
go

insert into commkt_physical_attr values(2054, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199906', 'D', 'D', 'B', '', 'N', 24, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTSPT', 'PLATTSPT', 1)
go

insert into commkt_physical_attr values(2055, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199906', 'R', 'R', 'B', '', 'N', 24, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTSPT', 'PLATTSPT', 1)
go

insert into commkt_physical_attr values(2056, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199906', 'R', 'R', 'B', '', 'N', 24, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTSPT', 'PLATTSPT', 1)
go

insert into commkt_physical_attr values(2057, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199906', 'R', 'R', 'B', '', 'N', 24, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTSPT', 'PLATTSPT', 1)
go

insert into commkt_physical_attr values(2058, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199906', 'R', 'R', 'B', '', 'N', 24, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTSPT', 'PLATTSPT', 1)
go

insert into commkt_physical_attr values(2059, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199906', 'R', 'R', 'B', '', 'N', 24, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTSPT', 'PLATTSPT', 1)
go

insert into commkt_physical_attr values(2060, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199906', 'R', 'R', 'B', '', 'N', 24, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTSPT', 'PLATTSPT', 1)
go

insert into commkt_physical_attr values(2061, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199906', 'R', 'R', 'B', '', 'N', 24, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTSPT', 'PLATTSPT', 1)
go

insert into commkt_physical_attr values(2063, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '199907', 'D', 'D', 'M', '', 'N', 18, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2064, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 4.000000, '199906', 'D', 'D', 'M', '', 'N', 18, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2065, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '199908', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2067, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '199908', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2070, 'A', 0.0, 'BBL', 'UNIT', 'CAC', 
'A', NULL, NULL, '199908', 'D', 'D', 'B', '', 'I', 60, '0', NULL, NULL, 'USD', 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2072, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199909', 'D', 'D', 'B', '', 'N', 12, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2075, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, '199909', 'D', 'D', 'B', '', 'N', 18, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'PLATTS', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2076, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, 'SPOT01', 'D', 'D', 'B', '', 'N', 6, '0', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'EXCHANGE', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2080, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199910', 'D', 'D', 'B', '', 'N', 1, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2081, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199910', 'D', 'D', 'B', '', 'N', 1, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2082, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199907', 'D', 'D', 'B', '', 'N', 6, '1', NULL, NULL, NULL, NULL, 
NULL, NULL, 3.000000, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2089, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199907', 'D', 'D', 'B', '', 'N', 48, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2094, 'A', 0.0, 'BBL', 'LOTS', 'USD', 
'A', NULL, 4.000000, '199909', 'D', 'D', 'M', '', 'N', 64, '1', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2095, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199909', 'D', 'D', 'B', '', 'N', 24, '1', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2098, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199910', 'D', 'D', 'B', '', 'N', 3, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, 3.000000, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2099, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '199909', 'D', 'D', 'B', '', 'N', 60, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2100, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199909', 'D', 'D', 'B', '', 'N', 24, '1', NULL, NULL, NULL, NULL, 
'D', NULL, NULL, 'PLATTSPT', 'PLATTSPT', 1)
go

insert into commkt_physical_attr values(2102, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, '199910', 'D', 'D', 'B', '', 'N', 20, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2103, 'A', 0.0, 'BBL', 'UNIT', 'GBP', 
'A', NULL, NULL, '199910', 'D', 'D', 'B', '', 'I', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2104, 'A', 0.0, 'BBL', 'UNIT', 'NLG', 
'A', NULL, NULL, '199910', 'D', 'D', 'B', '', 'I', 60, '1', NULL, NULL, 'USD', 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2105, 'A', 0.0, 'BBL', 'UNIT', 'UKC', 
'A', NULL, NULL, 'SPOT', 'D', 'D', 'B', '', 'I', 60, '1', NULL, NULL, 'USD', 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2107, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199911', 'D', 'D', 'B', '', 'N', 24, '1', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2108, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199911', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2126, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 2.000000, '199912', 'D', 'D', 'M', '', 'N', 10, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2129, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '200001', 'D', 'D', 'B', '', 'N', 60, '1', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2130, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '200001', 'D', 'D', 'M', '', 'N', 60, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2132, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '200002W1', 'D', 'D', 'A', '', 'N', 200, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2135, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '199901', 'D', 'D', 'B', '', 'N', 2, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2138, 'A', 0.0, 'BBL', 'UNIT', 'FFR', 
'A', NULL, NULL, 'SPOT', 'D', 'D', 'S', '', 'N', NULL, '1', NULL, NULL, 'USD', 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2139, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '200002', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'PLATTS', 1)
go

insert into commkt_physical_attr values(2141, 'A', 0.0, 'BBL', 'UNIT', 'SEK', 
'A', NULL, NULL, '200002', 'D', 'D', 'B', '', 'N', 60, '1', NULL, NULL, 'USD', 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2142, 'A', 0.0, 'BBL', 'UNIT', 'ITL', 
'A', NULL, NULL, '200002', 'D', 'D', 'B', '', 'N', 60, '1', NULL, NULL, 'USD', 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2143, 'A', 0.0, 'BBL', 'UNIT', 'BFR', 
'A', NULL, NULL, '200002', 'D', 'D', 'B', '', 'N', 60, '1', NULL, NULL, 'USD', 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2144, 'A', 0.0, 'BBL', 'UNIT', 'ESP', 
'A', NULL, NULL, '200002', 'D', 'D', 'B', '', 'N', 60, '1', NULL, NULL, 'USD', 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2145, 'A', 0.0, 'BBL', 'UNIT', 'UKC', 
'A', NULL, NULL, '200002', 'D', 'D', 'B', '', 'N', 60, '1', NULL, NULL, 'USD', 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2146, 'A', 0.0, 'BBL', 'UNIT', 'UKC', 
'A', NULL, NULL, '200002', 'D', 'D', 'B', '', 'N', 60, '1', NULL, NULL, 'USD', 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2147, 'A', 0.0, 'BBL', 'UNIT', 'GBP', 
'A', NULL, NULL, '200002', 'D', 'D', 'B', '', 'N', 60, '1', NULL, NULL, 'USD', 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2148, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '200002', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2149, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '200003', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2151, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '200003', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2155, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, '200002', 'D', 'D', 'M', '', 'N', 3, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2157, 'A', 0.0, 'BBL', 'UNIT', 
'EURODLR', 'A', NULL, NULL, 'SPOT', 'D', 'D', 'S', '', 'N', NULL, '2', NULL, 
NULL, 'USD', NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2160, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 10.000000, '200004', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2161, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 2.000000, '200004', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2163, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 50.000000, '200004', 'D', 'D', 'M', '', 'N', 3, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2164, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '200004', 'D', 'D', 'M', '', 'N', 60, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2171, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 8.000000, '200005', 'D', 'D', 'M', '', 'N', 2, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2172, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 5.000000, '200005', 'D', 'D', 'M', '', 'N', 3, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2173, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 5.000000, '200005', 'D', 'D', 'M', '', 'N', 12, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2174, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '200005', 'D', 'D', 'B', '', 'N', 6, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, 3.000000, 'PLATTS', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2178, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '200004', 'D', 'D', 'M', '', 'N', 60, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2179, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 5.000000, '200005', 'D', 'D', 'M', '', 'N', 5, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2183, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '200003', 'D', 'D', 'B', '', 'N', 48, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'PLATTS', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2185, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '200005', 'D', 'D', 'M', '', 'N', 60, '1', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2186, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '200005', 'D', 'D', 'M', '', 'N', 12, '1', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2190, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 8.000000, '200005', 'D', 'D', 'M', '', 'N', 5, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2191, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 8.000000, '200005', 'D', 'D', 'M', '', 'N', 24, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2194, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, 5.000000, '200006', 'D', 'D', 'M', '', 'N', 12, '2', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2195, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 5.000000, '200006', 'D', 'D', 'M', '', 'N', 12, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2196, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 5.000000, '200006', 'D', 'D', 'M', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2198, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 5.000000, '200006', 'D', 'D', 'M', '', 'N', 24, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2199, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, 5.000000, '200006', 'D', 'D', 'M', '', 'N', 12, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2200, 'A', 0.0, 'BBL', 'UNIT', 'DANKRN', 
'A', NULL, NULL, '200006', 'D', 'D', 'B', '', 'I', 60, '0', NULL, NULL, 'USD', 
NULL, NULL, NULL, NULL, 'INTERNAL', 'INTERNAL', 1)
go

insert into commkt_physical_attr values(2203, 'A', 0.0, 'BBL', 'BBL', 'USD', 
'A', NULL, NULL, 'SPOT', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'PLATTS', NULL, 1)
go

insert into commkt_physical_attr values(2206, 'A', 0.0, 'BBL', 'MT', 'USD', 'A', 
NULL, NULL, '200007', 'D', 'D', 'M', '', 'N', 60, '2', NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_physical_attr values(2207, 'A', 0.0, 'BBL', 'MMBT', 'USD', 
'A', NULL, NULL, '200007', 'D', 'D', 'B', '', 'N', 60, '2', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'INTERNAL', NULL, 1)
go

