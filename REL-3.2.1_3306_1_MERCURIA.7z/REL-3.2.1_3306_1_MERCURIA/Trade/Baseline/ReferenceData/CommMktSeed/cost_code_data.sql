print 'Populating data into the cost_code table ...'
go

set nocount on
declare @cmdty_code       char(8),
        @cmdty_full_name  varchar(40)

select @cmdty_code = min(cmdty_code)
from commodity
where cmdty_type = 'O'

while @cmdty_code is not null
begin
   if not exists (select 1
                  from cost_code
                  where cost_code = @cmdty_code)
   begin
      select @cmdty_full_name = cmdty_full_name
      from commodity
      where cmdty_code = @cmdty_code

      insert into cost_code (cost_code, cost_code_desc, trans_id)
        values(@cmdty_code, @cmdty_full_name, 1)
   end

   select @cmdty_code = min(cmdty_code)
   from commodity
   where cmdty_type = 'O' and
         cmdty_code > @cmdty_code
end
go
