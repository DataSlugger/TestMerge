/* MS SQL Server */

set nocount on

print ' '
print 'Loading additional seed data into the uom_conversion table ...'
go

create table #uomconv
(
   oid                int        NOT NULL PRIMARY KEY,
   uom_code_conv_from char(4)    NOT NULL,
   uom_code_conv_to   char(4)    NOT NULL,
   cmdty_code         char(8)    NULL,
   uom_api_val        float      NULL,
   uom_gravity_val    float      NULL,
   uom_conv_rate      float      NOT NULL,
   uom_conv_oper      char(1)    NOT NULL
)
go

insert into #uomconv values(31, 'BBL', 'BG60', 'WTI', NULL, NULL, 2.181152, 'M')
go
insert into #uomconv values(32, 'BBL', 'BG60', 'HO', NULL, NULL, 2.234737, 'M')
go
insert into #uomconv values(33, 'BBL', 'BG60', 'GASOIL', NULL, NULL, 2.234737, 'M')
go
insert into #uomconv values(34, 'BBL', 'BG60', 'LLS', NULL, NULL, 2.207006, 'M')
go
insert into #uomconv values(35, 'BBL', 'BG60', 'BRENT', NULL, NULL, 2.207006, 'M')
go
insert into #uomconv values(36, 'BBL', 'BG60', 'JET', NULL, NULL, 2.222497, 'M')
go
insert into #uomconv values(37, 'BBL', 'BG60', 'MPC', NULL, NULL, 2.222497, 'M')
go
insert into #uomconv values(38, 'BBL', 'BG60', 'KERO', NULL, NULL, 2.222497, 'M')
go
insert into #uomconv values(39, 'BBL', 'BG60', 'MEREY', NULL, NULL, 2.222497, 'M')
go
insert into #uomconv values(40, 'BBL', 'BG60', 'K3-VGO', NULL, NULL, 2.222497, 'M')
go
insert into #uomconv values(41, 'BBL', 'BG60', 'LAGUNA', NULL, NULL, 2.222497, 'M')
go
insert into #uomconv values(42, 'BBL', 'BG60', 'DUB-DIST', NULL, NULL, 2.222497, 'M')
go
insert into #uomconv values(43, 'BBL', 'BG60', 'UNL87', NULL, NULL, 1.965406, 'M')
go
insert into #uomconv values(44, 'BBL', 'BG60', 'VGOHS', NULL, NULL, 2.415459, 'M')
go
insert into #uomconv values(45, 'BBL', 'BG60', 'VGOLS', NULL, NULL, 2.415459, 'M')
go
insert into #uomconv values(46, 'BBL', 'BG60', 'LSWR', NULL, NULL, 2.487559, 'M')
go
insert into #uomconv values(47, 'BBL', 'BG60', 'NO6-10', NULL, NULL, 2.632961, 'M')
go
insert into #uomconv values(48, 'BBL', 'BG60', 'NO6-30', NULL, NULL, 2.632961, 'M')
go
insert into #uomconv values(49, 'BBL', 'BG69', 'LSWR', NULL, NULL, 2.163095, 'M')
go
insert into #uomconv values(50, 'BBL', 'BG69', 'UNL87', NULL, NULL, 1.709049, 'M')
go
insert into #uomconv values(51, 'BBL', 'BG69', 'BRENT', NULL, NULL, 1.919136, 'M')
go
insert into #uomconv values(52, 'BBL', 'BG69', 'GASOIL', NULL, NULL, 1.943249, 'M')
go
insert into #uomconv values(53, 'BBL', 'BG69', 'HO', NULL, NULL, 1.943250, 'M')
go
insert into #uomconv values(54, 'BBL', 'BG69', 'MPC', NULL, NULL, 1.932606, 'M')
go
insert into #uomconv values(55, 'BBL', 'BG69', 'MEREY', NULL, NULL, 1.932606, 'M')
go
insert into #uomconv values(56, 'BBL', 'BG69', 'K3-VGO', NULL, NULL, 1.932606, 'M')
go
insert into #uomconv values(57, 'BBL', 'BG69', 'LAGUNA', NULL, NULL, 1.932606, 'M')
go
insert into #uomconv values(58, 'BBL', 'BG69', 'VGOLS', NULL, NULL, 2.100399, 'M')
go
insert into #uomconv values(59, 'BBL', 'BG69', 'WTI', NULL, NULL, 1.896654, 'M')
go
insert into #uomconv values(60, 'BBL', 'BG69', 'NO6-10', NULL, NULL, 2.289531, 'M')
go
insert into #uomconv values(61, 'BBL', 'BG69', 'NO6-30', NULL, NULL, 2.289531, 'M')
go
insert into #uomconv values(62, 'BBL', 'BG70', 'NO6LSSR', NULL, NULL, 2.116402, 'M')
go
insert into #uomconv values(63, 'BBL', 'BG70', 'VGOHS', NULL, NULL, 2.070390, 'M')
go
insert into #uomconv values(64, 'BBL', 'BG70', 'EKOFISK', NULL, NULL, 1.834277, 'M')
go
insert into #uomconv values(65, 'BBL', 'BG70', 'VGOLS', NULL, NULL, 2.070393, 'M')
go
insert into #uomconv values(66, 'BBL', 'BG70', 'WTI', NULL, NULL, 1.869559, 'M')
go
insert into #uomconv values(67, 'BBL', 'BG70', 'K3-VGO', NULL, NULL, 1.905000, 'M')
go
insert into #uomconv values(68, 'BBL', 'BG70', 'NO6-10', NULL, NULL, 2.256824, 'M')
go
insert into #uomconv values(69, 'BBL', 'BG70', 'NO6-30', NULL, NULL, 2.256824, 'M')
go
insert into #uomconv values(70, 'BBL', 'BG70', 'E4F', NULL, NULL, 2.237734, 'M')
go
insert into #uomconv values(71, 'BBL', 'BG70', 'NO6-35', NULL, NULL, 2.256827, 'M')
go
insert into #uomconv values(72, 'BBL', 'BG70', 'M100', NULL, NULL, 2.237735, 'M')
go
insert into #uomconv values(73, 'BBL', 'BG70', 'BRENT', NULL, NULL, 1.891720, 'M')
go
insert into #uomconv values(74, 'BBL', 'BG70', 'UNL87', NULL, NULL, 1.684634, 'M')
go
insert into #uomconv values(75, 'BBL', 'BG70', 'FORTIES', NULL, NULL, 1.907509, 'M')
go
insert into #uomconv values(76, 'BBL', 'CMBT', 'WTI', NULL, NULL, 0.000580, 'M')
go
insert into #uomconv values(77, 'BBL', 'CMBT', 'NO6-10', NULL, NULL, 0.000629, 'M')
go
insert into #uomconv values(78, 'BBL', 'CMBT', 'NO6-35', NULL, NULL, 0.000629, 'M')
go
insert into #uomconv values(79, 'BBL', 'CMBT', 'NO6LSSR', NULL, NULL, 0.000629, 'M')
go
insert into #uomconv values(80, 'BBL', 'CMBT', 'NO6-30', NULL, NULL, 0.000650, 'M')
go
insert into #uomconv values(81, 'BBL', 'CMBT', 'UNL87', NULL, NULL, 0.000462, 'M')
go
insert into #uomconv values(82, 'BBL', 'GAL', 'AVGAS', NULL, NULL, 42.000000, 'M')
go
insert into #uomconv values(83, 'BBL', 'GAL', 'UNL87', NULL, NULL, 42.000000, 'M')
go
insert into #uomconv values(84, 'BBL', 'KG', 'K3-VGO', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(85, 'BBL', 'KG', 'FORTIES', NULL, NULL, 133.525610, 'M')
go
insert into #uomconv values(86, 'BBL', 'KG', 'BRENT', NULL, NULL, 132.420360, 'M')
go
insert into #uomconv values(87, 'BBL', 'KG', 'WTI', NULL, NULL, 130.869120, 'M')
go
insert into #uomconv values(88, 'BBL', 'KG', 'EKOFISK', NULL, NULL, 128.399373, 'M')
go
insert into #uomconv values(89, 'BBL', 'LB', 'BRENT', NULL, NULL, 291.936971, 'M')
go
insert into #uomconv values(90, 'BBL', 'LOTS', 'BRENT', NULL, NULL, 1000.000000, 'D')
go
insert into #uomconv values(91, 'BBL', 'LT', 'FORTIES', NULL, NULL, 0.131417, 'M')
go
insert into #uomconv values(92, 'BBL', 'LT', 'BRENT', NULL, NULL, 0.130329, 'M')
go
insert into #uomconv values(93, 'BBL', 'LT', 'KERO', NULL, NULL, 0.131244, 'M')
go
insert into #uomconv values(94, 'BBL', 'MG', 'UNL87', NULL, NULL, 0.420057, 'M')
go
insert into #uomconv values(95, 'BBL', 'MG', 'WTI', NULL, NULL, 0.420001, 'M')
go
insert into #uomconv values(96, 'BBL', 'MG', 'NO6-10', NULL, NULL, 0.419999, 'M')
go
insert into #uomconv values(97, 'BBL', 'MG', 'KERO', NULL, NULL, 0.420000, 'M')
go
insert into #uomconv values(98, 'BBL', 'MG', 'BRENT', NULL, NULL, 0.420000, 'M')
go
insert into #uomconv values(99, 'BBL', 'MG', 'NO6-30', NULL, NULL, 0.420000, 'M')
go
insert into #uomconv values(100, 'BBL', 'MG', 'NO6-35', NULL, NULL, 0.420000, 'M')
go
insert into #uomconv values(101, 'BBL', 'MG', 'GASOIL5', NULL, NULL, 0.420000, 'M')
go
insert into #uomconv values(102, 'BBL', 'MG', 'DUB-DIST', NULL, NULL, 0.420000, 'M')
go
insert into #uomconv values(103, 'BBL', 'MMBT', 'NO6-20', NULL, NULL, 6.500000, 'M')
go
insert into #uomconv values(104, 'BBL', 'MMBT', 'NO6-30', NULL, NULL, 6.500000, 'M')
go
insert into #uomconv values(105, 'BBL', 'MMBT', 'NO6-35', NULL, NULL, 6.500000, 'M')
go
insert into #uomconv values(106, 'BBL', 'MMBT', 'NO6-05', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(107, 'BBL', 'MMBT', 'NO6-07', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(108, 'BBL', 'MMBT', 'NO6-10', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(109, 'BBL', 'MMBT', 'NO6-16', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(110, 'BBL', 'MMBT', 'NO6-22', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(111, 'BBL', 'MMBT', 'NO6-28', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(112, 'BBL', 'MMBT', 'NO6-29', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(113, 'BBL', 'MMBT', 'HSFO180', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(114, 'BBL', 'MMBT', 'HSFO380', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(115, 'BBL', 'MMBT', 'HSRESID', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(116, 'BBL', 'MMBT', 'NO6HSCR', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(117, 'BBL', 'MMBT', 'NO6HSSR', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(118, 'BBL', 'MMBT', 'NO6LSCR', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(119, 'BBL', 'MMBT', 'NO6LSSR', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(120, 'BBL', 'MMBT', 'NO6-03HI', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(121, 'BBL', 'MMBT', 'NO6-03LO', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(122, 'BBL', 'MMBT', 'NO6-03MX', NULL, NULL, 6.290000, 'M')
go
insert into #uomconv values(123, 'BBL', 'MMBT', 'WTI', NULL, NULL, 5.800000, 'M')
go
insert into #uomconv values(124, 'BBL', 'MMBT', 'UNL87', NULL, NULL, 4.620000, 'M')
go
insert into #uomconv values(125, 'BBL', 'MT', 'KERO', NULL, NULL, 0.134200, 'M')
go
insert into #uomconv values(126, 'BBL', 'MT', 'EOCENE', NULL, NULL, 0.134220, 'M')
go
insert into #uomconv values(127, 'BBL', 'MT', 'E4F', NULL, NULL, 0.156642, 'M')
go
insert into #uomconv values(128, 'BBL', 'MT', 'NAPHTHA', NULL, NULL, 8.900000, 'D')
go
insert into #uomconv values(129, 'BBL', 'MT', 'ALB', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(130, 'BBL', 'MT', 'DUC', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(131, 'BBL', 'MT', 'MPC', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(132, 'BBL', 'MT', 'DEMUR', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(133, 'BBL', 'MT', 'MEREY', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(134, 'BBL', 'MT', 'BELIDA', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(135, 'BBL', 'MT', 'FULMAR', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(136, 'BBL', 'MT', 'JCOND', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(137, 'BBL', 'MT', 'K3-VGO', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(138, 'BBL', 'MT', 'LAGUNA', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(139, 'BBL', 'MT', 'MASILA', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(140, 'BBL', 'MT', 'NATGAS', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(141, 'BBL', 'MT', 'RATAWI', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(142, 'BBL', 'MT', 'WTI-HO', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(143, 'BBL', 'MT', 'CABINDA', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(144, 'BBL', 'MT', 'CAPTAIN', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(145, 'BBL', 'MT', 'HARDING', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(147, 'BBL', 'MT', 'DUB-DIST', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(148, 'BBL', 'MT', 'LAGOMEDI', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(149, 'BBL', 'MT', 'LIVBAYBL', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(150, 'BBL', 'MT', 'NANHAILT', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(151, 'BBL', 'MT', 'SUMATRAL', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(152, 'BBL', 'MT', 'THEVENAR', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(153, 'BBL', 'STN', 'NO6-10', NULL, NULL, 0.174141, 'M')
go
insert into #uomconv values(154, 'BBL', 'STN', 'NO6-30', NULL, NULL, 0.174141, 'M')
go
insert into #uomconv values(155, 'BBL', 'STN', 'HO', NULL, NULL, 0.147802, 'M')
go
insert into #uomconv values(156, 'BBL', 'STN', 'WTI', NULL, NULL, 0.144259, 'M')
go
insert into #uomconv values(157, 'BBL', 'STN', 'BRENT', NULL, NULL, 0.132414, 'M')
go
insert into #uomconv values(158, 'BBL', 'STN', 'VGOHS', NULL, NULL, 0.159755, 'M')
go
insert into #uomconv values(159, 'BBL', 'STN', 'VGOLS', NULL, NULL, 0.159755, 'M')
go
insert into #uomconv values(160, 'BBL', 'STN', 'UNL87', NULL, NULL, 0.129989, 'M')
go
insert into #uomconv values(161, 'BBL', 'STN', 'K3-VGO', NULL, NULL, 0.146993, 'M')
go
insert into #uomconv values(162, 'GAL', 'BG60', 'HO', NULL, NULL, 0.053208, 'M')
go
insert into #uomconv values(163, 'GAL', 'BG60', 'UNL87', NULL, NULL, 0.046789, 'M')
go
insert into #uomconv values(164, 'GAL', 'BG69', 'HO', NULL, NULL, 0.046268, 'M')
go
insert into #uomconv values(165, 'GAL', 'BG69', 'UNL87', NULL, NULL, 0.040686, 'M')
go
insert into #uomconv values(166, 'GAL', 'BG70', 'UNL87', NULL, NULL, 0.040105, 'M')
go
insert into #uomconv values(167, 'GAL', 'BG70', 'HO', NULL, NULL, 0.045607, 'M')
go
insert into #uomconv values(168, 'GAL', 'CMBT', 'UNL87', NULL, NULL, 0.000011, 'M')
go
insert into #uomconv values(169, 'GAL', 'LT', 'UNL87', NULL, NULL, 0.002763, 'M')
go
insert into #uomconv values(170, 'GAL', 'MT', 'PROPANE', NULL, NULL, 0.001920, 'M')
go
insert into #uomconv values(171, 'GAL', 'MT', 'GOIL590', NULL, NULL, 0.003175, 'M')
go
insert into #uomconv values(172, 'GAL', 'MT', 'HSFO180', NULL, NULL, 0.003761, 'M')
go
insert into #uomconv values(173, 'GAL', 'STN', 'HO', NULL, NULL, 0.003519, 'M')
go
insert into #uomconv values(174, 'GAL', 'STN', 'UNL87', NULL, NULL, 0.002807, 'M')
go
insert into #uomconv values(175, 'GAL', 'UNIT', 'HO', NULL, NULL, 0.023810, 'M')
go
insert into #uomconv values(176, 'GAL', 'UNIT', 'UNL87', NULL, NULL, 0.023810, 'M')
go
insert into #uomconv values(177, 'LB', 'BBL', 'WTI', NULL, NULL, 0.003466, 'M')
go
insert into #uomconv values(178, 'LOTS', 'BBL', 'BRENT', NULL, NULL, 1000.000000, 'M')
go
insert into #uomconv values(179, 'LOTS', 'MT', 'BRENT', NULL, NULL, 132.420515, 'M')
go
insert into #uomconv values(180, 'LT', 'BBL', 'INSPECT', NULL, NULL, 7.619400, 'M')
go
insert into #uomconv values(181, 'LT', 'MT', 'INSPECT', NULL, NULL, 1.015840, 'M')
go
insert into #uomconv values(182, 'M3', 'BBL', 'VGOLS', NULL, NULL, 6.289800, 'M')
go
insert into #uomconv values(183, 'M3', 'BG60', 'VGOLS', NULL, NULL, 15.192754, 'M')
go

insert into #uomconv values(184, 'M3', 'MB', 'VGOLS', NULL, NULL, 0.006290, 'M')
go

insert into #uomconv values(185, 'M3', 'MT', 'VGOLS', NULL, NULL, 0.911565, 'M')
go

insert into #uomconv values(186, 'MB', 'BG60', 'BRENT', NULL, NULL, 2207.005580, 'M')
go

insert into #uomconv values(187, 'MB', 'BG60', 'HO', NULL, NULL, 2234.728350, 'M')
go

insert into #uomconv values(188, 'MB', 'BG60', 'UNL87', NULL, NULL, 1965.411851, 'M')
go

insert into #uomconv values(189, 'MB', 'BG60', 'NO6-30', NULL, NULL, 2632.964769, 'M')
go

insert into #uomconv values(190, 'MB', 'BG60', 'WTI', NULL, NULL, 2181.151626, 'M')
go

insert into #uomconv values(191, 'MB', 'BG60', 'VGOLS', NULL, NULL, 2415.459000, 'M')
go

insert into #uomconv values(192, 'MB', 'BG60', 'FORTIES', NULL, NULL, 2225.423805, 'M')
go

insert into #uomconv values(193, 'MB', 'BG60', 'NO6-10', NULL, NULL, 2632.964717, 'M')
go

insert into #uomconv values(194, 'MB', 'BG60', 'VGOHS', NULL, NULL, 2415.458937, 'M')
go

insert into #uomconv values(195, 'MB', 'BG60', 'EKOFISK', NULL, NULL, 2139.986638, 'M')
go

insert into #uomconv values(196, 'MB', 'BG69', 'NO6-10', NULL, NULL, 2289.534537, 'M')
go

insert into #uomconv values(197, 'MB', 'BG69', 'UNL87', NULL, NULL, 1709.049000, 'M')
go

insert into #uomconv values(198, 'MB', 'BG69', 'WTI', NULL, NULL, 1896.653588, 'M')
go

insert into #uomconv values(199, 'MB', 'BG69', 'VGOHS', NULL, NULL, 2100.399076, 'M')
go

insert into #uomconv values(200, 'MB', 'BG69', 'HO', NULL, NULL, 1943.249348, 'M')
go

insert into #uomconv values(201, 'MB', 'BG69', 'NO6-30', NULL, NULL, 2289.531000, 'M')
go

insert into #uomconv values(202, 'MB', 'BG69', 'BRENT', NULL, NULL, 1919.135635, 'M')
go

insert into #uomconv values(203, 'MB', 'BG70', 'VGOLS', NULL, NULL, 2070.393300, 'M')
go

insert into #uomconv values(204, 'MB', 'BG70', 'VGOHS', NULL, NULL, 2070.393375, 'M')
go

insert into #uomconv values(205, 'MB', 'BG70', 'FORTIES', NULL, NULL, 1907.506465, 'M')
go

insert into #uomconv values(206, 'MB', 'BG70', 'BRENT', NULL, NULL, 1891.719412, 'M')
go

insert into #uomconv values(207, 'MB', 'BG70', 'WTI', NULL, NULL, 1869.558537, 'M')
go

insert into #uomconv values(208, 'MB', 'BG70', 'HO', NULL, NULL, 1915.488643, 'M')
go

insert into #uomconv values(209, 'MB', 'BG70', 'EKOFISK', NULL, NULL, 1834.274594, 'M')
go

insert into #uomconv values(210, 'MB', 'BG70', 'UNL87', NULL, NULL, 1684.634014, 'M')
go

insert into #uomconv values(211, 'MB', 'CMBT', 'WTI', NULL, NULL, 0.580000, 'M')
go

insert into #uomconv values(212, 'MB', 'CMBT', 'UNL87', NULL, NULL, 0.462000, 'M')
go

insert into #uomconv values(213, 'MB', 'CMBT', 'NO6-30', NULL, NULL, 0.650000, 'M')
go

insert into #uomconv values(214, 'MB', 'KG', 'BRENT', NULL, NULL, 132420.358815, 'M')
go

insert into #uomconv values(215, 'MB', 'KG', 'FORTIES', NULL, NULL, 133525.610000, 'M')
go

insert into #uomconv values(216, 'MB', 'KG', 'WTI', NULL, NULL, 130869.097560, 'M')
go

insert into #uomconv values(217, 'MB', 'KG', 'EKOFISK', NULL, NULL, 128399.373000, 'M')
go

insert into #uomconv values(218, 'MB', 'KG', 'OSEBERG', NULL, NULL, 135790.231000, 'M')
go

insert into #uomconv values(219, 'MB', 'LT', 'BRENT', NULL, NULL, 130.328975, 'M')
go

insert into #uomconv values(220, 'MB', 'LT', 'WTI', NULL, NULL, 141.986723, 'M')
go

insert into #uomconv values(221, 'MB', 'MG', 'BRENT', NULL, NULL, 420.000000, 'M')
go

insert into #uomconv values(222, 'MB', 'MG', 'VGOLS', NULL, NULL, 420.000000, 'M')
go

insert into #uomconv values(223, 'MB', 'MG', 'UNL87', NULL, NULL, 463.090086, 'M')
go

insert into #uomconv values(224, 'MB', 'MG', 'HO', NULL, NULL, 419.998562, 'M')
go
insert into #uomconv values(225, 'MB', 'MMBT', 'UNL87', NULL, NULL, 4620.000000, 'M')
go
insert into #uomconv values(226, 'MB', 'MMBT', 'NATGAS', NULL, NULL, 6500.000000, 'M')
go
insert into #uomconv values(227, 'MB', 'MMBT', 'NO6-30', NULL, NULL, 6500.000000, 'M')
go
insert into #uomconv values(228, 'MB', 'MMBT', 'NO6-35', NULL, NULL, 6500.000000, 'M')
go
insert into #uomconv values(229, 'MB', 'MMBT', 'NO6-22', NULL, NULL, 6290.000000, 'M')
go
insert into #uomconv values(230, 'MB', 'MMBT', 'WTI', NULL, NULL, 5800.000000, 'M')
go
insert into #uomconv values(231, 'MB', 'MMBT', 'NO6-10', NULL, NULL, 6290.000001, 'M')
go
insert into #uomconv values(232, 'MB', 'MT', 'AH', NULL, NULL, 141.623000, 'M')
go
insert into #uomconv values(233, 'MB', 'MT', 'NO6-10', NULL, NULL, 157.977883, 'M')
go
insert into #uomconv values(234, 'MB', 'MT', 'NO6-22', NULL, NULL, 157.977883, 'M')
go
insert into #uomconv values(235, 'MB', 'MT', 'NO6-30', NULL, NULL, 157.977883, 'M')
go
insert into #uomconv values(236, 'MB', 'MT', 'HO', NULL, NULL, 134.084205, 'M')
go
insert into #uomconv values(237, 'MB', 'MT', 'UNL92', NULL, NULL, 117.924528, 'M')
go
insert into #uomconv values(238, 'MB', 'MT', 'UNLR9', NULL, NULL, 117.924528, 'M')
go
insert into #uomconv values(239, 'MB', 'MT', 'OSEBERG', NULL, NULL, 135.790231, 'M')
go
insert into #uomconv values(240, 'MB', 'MT', 'BONNYL', NULL, NULL, 133.445427, 'M')
go
insert into #uomconv values(241, 'MB', 'MT', 'ALB', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(242, 'MB', 'MT', 'MESA', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(243, 'MB', 'MT', 'STAT', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(244, 'MB', 'MT', 'BELIDA', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(245, 'MB', 'MT', 'EOCENE', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(246, 'MB', 'MT', 'FULMAR', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(247, 'MB', 'MT', 'RATAWI', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(248, 'MB', 'MT', 'CAPTAIN', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(249, 'MB', 'MT', 'FORCADOS', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(250, 'MB', 'MT', 'GULLFAKC', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(251, 'MB', 'MT', 'LAGOMEDI', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(252, 'MB', 'MT', 'LIVBAYBL', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(253, 'MB', 'MT', 'NANHAILT', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(254, 'MB', 'MT', 'SEMBILAN', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(255, 'MB', 'MT', 'SUMATRAL', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(256, 'MB', 'MT', 'THEVENAR', NULL, NULL, 133.350000, 'M')
go
insert into #uomconv values(257, 'MB', 'MT', 'BRENT', NULL, NULL, 132.420515, 'M')
go
insert into #uomconv values(258, 'MB', 'MT', 'AVGAS', NULL, NULL, 117.647059, 'M')
go
insert into #uomconv values(259, 'MB', 'MT', 'AL', NULL, NULL, 135.954537, 'M')
go
insert into #uomconv values(260, 'MB', 'MT', 'FLOTTA', NULL, NULL, 134.244405, 'M')
go
insert into #uomconv values(261, 'MB', 'MT', 'QUAIBOE', NULL, NULL, 134.163357, 'M')
go
insert into #uomconv values(262, 'MB', 'MT', 'LSWR', NULL, NULL, 149.253731, 'M')
go
insert into #uomconv values(263, 'MB', 'MT', 'NEMBA', NULL, NULL, 133.351113, 'M')
go
insert into #uomconv values(264, 'MB', 'MT', 'CABINDA', NULL, NULL, 133.351113, 'M')
go
insert into #uomconv values(265, 'MB', 'MT', 'INSPECT', NULL, NULL, 133.351113, 'M')
go
insert into #uomconv values(266, 'MB', 'MT', 'MARIBLT', NULL, NULL, 133.351113, 'M')
go
insert into #uomconv values(267, 'MB', 'MT', 'PALANCA', NULL, NULL, 133.351113, 'M')
go
insert into #uomconv values(268, 'MB', 'MT', 'BASRAHLT', NULL, NULL, 133.351113, 'M')
go
insert into #uomconv values(269, 'MB', 'MT', 'MISCCHRG', NULL, NULL, 133.351113, 'M')
go
insert into #uomconv values(270, 'MB', 'MT', 'PENN', NULL, NULL, 133.525610, 'M')
go
insert into #uomconv values(271, 'MB', 'MT', 'FORTIES', NULL, NULL, 133.525610, 'M')
go
insert into #uomconv values(272, 'MB', 'MT', 'ORIENTE', NULL, NULL, 139.856228, 'M')
go
insert into #uomconv values(273, 'MB', 'MT', 'SYB', NULL, NULL, 133.349993, 'M')
go
insert into #uomconv values(274, 'MB', 'MT', 'ESCRAVOS', NULL, NULL, 141.701265, 'M')
go
insert into #uomconv values(275, 'MB', 'MT', 'NAPHTHA', NULL, NULL, 112.359551, 'M')
go
insert into #uomconv values(276, 'MB', 'MT', 'LEONA', NULL, NULL, 147.203863, 'M')
go
insert into #uomconv values(278, 'MB', 'MT', 'DURI', NULL, NULL, 146.243730, 'M')
go
insert into #uomconv values(279, 'MB', 'MT', 'TAPIS', NULL, NULL, 127.668267, 'M')
go
insert into #uomconv values(280, 'MB', 'MT', 'GASOIL', NULL, NULL, 134.228188, 'M')
go
insert into #uomconv values(281, 'MB', 'MT', 'GASOIL5', NULL, NULL, 134.228188, 'M')
go
insert into #uomconv values(282, 'MB', 'MT', 'BONNYM', NULL, NULL, 143.252109, 'M')
go
insert into #uomconv values(283, 'MB', 'MT', 'DUBAI', NULL, NULL, 137.287205, 'M')
go
insert into #uomconv values(284, 'MB', 'MT', 'EKOFISK', NULL, NULL, 128.399373, 'M')
go
insert into #uomconv values(285, 'MB', 'MT', 'WTI', NULL, NULL, 130.874635, 'M')
go
insert into #uomconv values(286, 'MB', 'STN', 'WTI', NULL, NULL, 144.258511, 'M')
go
insert into #uomconv values(287, 'MB', 'STN', 'NO6-10', NULL, NULL, 174.140837, 'M')
go
insert into #uomconv values(288, 'MB', 'STN', 'HO', NULL, NULL, 147.802360, 'M')
go
insert into #uomconv values(289, 'MB', 'STN', 'UNL87', NULL, NULL, 129.989387, 'M')
go
insert into #uomconv values(290, 'MB', 'STN', 'VGOHS', NULL, NULL, 159.755290, 'M')
go
insert into #uomconv values(291, 'MB', 'STN', 'NO6-35', NULL, NULL, 174.140841, 'M')
go
insert into #uomconv values(292, 'MB', 'UNIT', 'WTI', NULL, NULL, 1000.000000, 'M')
go
insert into #uomconv values(293, 'MB', 'UNIT', 'BRENT', NULL, NULL, 1000.000000, 'M')
go
insert into #uomconv values(294, 'MB', 'UNIT', 'VGOHS', NULL, NULL, 1000.000000, 'M')
go
insert into #uomconv values(295, 'MB', 'UNIT', 'NO6-10', NULL, NULL, 1000.000000, 'M')
go
insert into #uomconv values(296, 'MB', 'UNIT', 'EKOFISK', NULL, NULL, 1000.000000, 'M')
go
insert into #uomconv values(297, 'MB', 'UNIT', 'FORTIES', NULL, NULL, 1000.000000, 'M')
go
insert into #uomconv values(298, 'MB', 'UNIT', 'UNL87', NULL, NULL, 1000.020047, 'M')
go
insert into #uomconv values(299, 'MB', 'UNIT', 'HO', NULL, NULL, 1000.020000, 'M')
go
insert into #uomconv values(300, 'MMBT', 'BBL', 'NATGAS', NULL, NULL, 0.153847, 'M')
go
insert into #uomconv values(301, 'MMBT', 'BG60', 'NATGAS', NULL, NULL, 0.371149, 'M')
go
insert into #uomconv values(302, 'MMBT', 'BG70', 'NATGAS', NULL, NULL, 0.318129, 'M')
go
insert into #uomconv values(303, 'MMBT', 'GAL', 'WTI', NULL, NULL, 7.241379, 'M')
go
insert into #uomconv values(304, 'MMBT', 'GAL', 'NO6-05', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(305, 'MMBT', 'GAL', 'NO6-07', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(306, 'MMBT', 'GAL', 'NO6-10', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(307, 'MMBT', 'GAL', 'NO6-16', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(308, 'MMBT', 'GAL', 'NO6-20', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(309, 'MMBT', 'GAL', 'NO6-22', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(310, 'MMBT', 'GAL', 'NO6-28', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(311, 'MMBT', 'GAL', 'HSFO180', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(312, 'MMBT', 'GAL', 'HSFO380', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(313, 'MMBT', 'GAL', 'HSRESID', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(314, 'MMBT', 'GAL', 'NO6HSCR', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(315, 'MMBT', 'GAL', 'NO6HSSR', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(316, 'MMBT', 'GAL', 'NO6LSCR', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(317, 'MMBT', 'GAL', 'NO6LSSR', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(318, 'MMBT', 'GAL', 'NO6-03HI', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(319, 'MMBT', 'GAL', 'NO6-03LO', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(320, 'MMBT', 'GAL', 'NO6-03MX', NULL, NULL, 6.677265, 'M')
go
insert into #uomconv values(321, 'MMBT', 'GAL', 'NATGAS', NULL, NULL, 6.461538, 'M')
go
insert into #uomconv values(322, 'MMBT', 'GAL', 'NO6-29', NULL, NULL, 6.461538, 'M')
go
insert into #uomconv values(323, 'MMBT', 'GAL', 'NO6-30', NULL, NULL, 6.461538, 'M')
go
insert into #uomconv values(324, 'MMBT', 'GAL', 'NO6-35', NULL, NULL, 6.461538, 'M')
go
insert into #uomconv values(325, 'MMBT', 'GAL', 'UNL87', NULL, NULL, 9.090909, 'M')
go
insert into #uomconv values(326, 'MMBT', 'MT', 'NATGAS', NULL, NULL, 0.022269, 'M')
go
insert into #uomconv values(327, 'MMBT', 'STN', 'NATGAS', NULL, NULL, 0.024547, 'M')
go
insert into #uomconv values(328, 'MMBT', 'UNIT', 'NATGAS', NULL, NULL, 0.167000, 'M')
go
insert into #uomconv values(329, 'MT', 'BBL', 'NO6LSSR', NULL, NULL, 6.750000, 'M')
go
insert into #uomconv values(330, 'MT', 'BBL', 'GOIL590', NULL, NULL, 7.500000, 'M')
go
insert into #uomconv values(331, 'MT', 'BBL', 'AVGAS', NULL, NULL, 8.500000, 'M')
go
insert into #uomconv values(332, 'MT', 'BBL', 'ESCRAVOS', NULL, NULL, 7.057100, 'M')
go
insert into #uomconv values(333, 'MT', 'BBL', 'BONNYL', NULL, NULL, 7.493700, 'M')
go
insert into #uomconv values(334, 'MT', 'BBL', 'DURI', NULL, NULL, 6.837900, 'M')
go
insert into #uomconv values(335, 'MT', 'BBL', 'GULLFAKS', NULL, NULL, 7.132300, 'M')
go
insert into #uomconv values(336, 'MT', 'BBL', 'LLS', NULL, NULL, 7.551700, 'M')
go
insert into #uomconv values(337, 'MT', 'BBL', 'MIRI', NULL, NULL, 7.551700, 'M')
go
insert into #uomconv values(338, 'MT', 'BBL', 'PENN', NULL, NULL, 7.489200, 'M')
go
insert into #uomconv values(339, 'MT', 'BBL', 'FORTIES', NULL, NULL, 7.489200, 'M')
go
insert into #uomconv values(340, 'MT', 'BBL', 'SYB', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(341, 'MT', 'BBL', 'VAT', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(342, 'MT', 'BBL', 'ALBA', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(343, 'MT', 'BBL', 'DUTY', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(344, 'MT', 'BBL', 'MESA', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(345, 'MT', 'BBL', 'INSUR', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(346, 'MT', 'BBL', 'RME25', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(347, 'MT', 'BBL', 'SERIA', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(348, 'MT', 'BBL', 'TRANS', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(349, 'MT', 'BBL', 'RMG35', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(350, 'MT', 'BBL', 'ACCRUAL', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(351, 'MT', 'BBL', 'COMMISS', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(352, 'MT', 'BBL', 'DEADFRT', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(353, 'MT', 'BBL', 'FREIGHT', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(354, 'MT', 'BBL', 'GRAVITY', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(355, 'MT', 'BBL', 'INSPECT', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(356, 'MT', 'BBL', 'MSFO18', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(357, 'MT', 'BBL', 'OPTEXER', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(359, 'MT', 'BBL', 'SOUEDIE', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(360, 'MT', 'BBL', 'STORAGE', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(362, 'MT', 'BBL', 'ALKYLATE', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(363, 'MT', 'BBL', 'BARROWIS', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(365, 'MT', 'BBL', 'BROKERFE', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(367, 'MT', 'BBL', 'HARBORDU', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(368, 'MT', 'BBL', 'INTEREST', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(369, 'MT', 'BBL', 'LCGASOIL', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(370, 'MT', 'BBL', 'MARINEFE', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(371, 'MT', 'BBL', 'MISCCHRG', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(372, 'MT', 'BBL', 'PREXCISE', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(373, 'MT', 'BBL', 'PROCSFEE', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(374, 'MT', 'BBL', 'RMG35RFY', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(375, 'MT', 'BBL', 'SERVICEF', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(377, 'MT', 'BBL', 'BRASS', NULL, NULL, 7.730200, 'M')
go
insert into #uomconv values(378, 'MT', 'BBL', 'ZUEITINA', NULL, NULL, 7.730200, 'M')
go
insert into #uomconv values(379, 'MT', 'BBL', 'EN228', NULL, NULL, 8.330000, 'M')
go
insert into #uomconv values(380, 'MT', 'BBL', 'UNL92', NULL, NULL, 8.330000, 'M')
go
insert into #uomconv values(381, 'MT', 'BBL', 'UNL93', NULL, NULL, 8.330000, 'M')
go
insert into #uomconv values(382, 'MT', 'BBL', 'UNL92/O', NULL, NULL, 8.330000, 'M')
go
insert into #uomconv values(383, 'MT', 'BBL', 'EKOFISK', NULL, NULL, 7.788200, 'M')
go
insert into #uomconv values(384, 'MT', 'BBL', 'LOKELE', NULL, NULL, 6.771000, 'M')
go
insert into #uomconv values(385, 'MT', 'BBL', 'OSEBERG', NULL, NULL, 7.364300, 'M')
go
insert into #uomconv values(386, 'MT', 'BBL', 'BERYL', NULL, NULL, 7.484800, 'M')
go
insert into #uomconv values(387, 'MT', 'BBL', 'MARIBLT', NULL, NULL, 7.176900, 'M')
go
insert into #uomconv values(388, 'MT', 'BBL', 'AM', NULL, NULL, 7.239400, 'M')
go
insert into #uomconv values(389, 'MT', 'BBL', 'KUWAIT', NULL, NULL, 7.239400, 'M')
go
insert into #uomconv values(390, 'MT', 'BBL', 'MURBAN', NULL, NULL, 7.596300, 'M')
go
insert into #uomconv values(391, 'MT', 'BBL', 'NO6-05', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(392, 'MT', 'BBL', 'NO6-07', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(393, 'MT', 'BBL', 'NO6-10', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(394, 'MT', 'BBL', 'NO6-16', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(395, 'MT', 'BBL', 'NO6-20', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(396, 'MT', 'BBL', 'NO6-22', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(397, 'MT', 'BBL', 'NO6-28', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(398, 'MT', 'BBL', 'NO6-29', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(399, 'MT', 'BBL', 'NO6-30', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(400, 'MT', 'BBL', 'NO6-35', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(401, 'MT', 'BBL', 'HSFO180', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(402, 'MT', 'BBL', 'HSFO380', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(403, 'MT', 'BBL', 'HSRESID', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(404, 'MT', 'BBL', 'NO6HSCR', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(405, 'MT', 'BBL', 'NO6LSCR', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(406, 'MT', 'BBL', 'NO6-03HI', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(407, 'MT', 'BBL', 'NO6-03LO', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(408, 'MT', 'BBL', 'AH', NULL, NULL, 7.061000, 'M')
go
insert into #uomconv values(409, 'MT', 'BBL', 'ANS', NULL, NULL, 7.061000, 'M')
go
insert into #uomconv values(410, 'MT', 'BBL', 'JABIRU', NULL, NULL, 7.716800, 'M')
go
insert into #uomconv values(411, 'MT', 'BBL', 'K3-VGO', NULL, NULL, 7.090000, 'M')
go
insert into #uomconv values(412, 'MT', 'BBL', 'AL', NULL, NULL, 7.355400, 'M')
go
insert into #uomconv values(413, 'MT', 'BBL', 'COBAN', NULL, NULL, 6.994000, 'M')
go
insert into #uomconv values(414, 'MT', 'BBL', 'URAL', NULL, NULL, 7.350900, 'M')
go
insert into #uomconv values(415, 'MT', 'BBL', 'KOLE', NULL, NULL, 7.413400, 'M')
go
insert into #uomconv values(416, 'MT', 'BBL', 'QTMARINE', NULL, NULL, 7.475900, 'M')
go
insert into #uomconv values(417, 'MT', 'BBL', 'FUELOIL', NULL, NULL, 6.350000, 'M')
go
insert into #uomconv values(418, 'MT', 'BBL', 'VGO', NULL, NULL, 6.850000, 'M')
go
insert into #uomconv values(419, 'MT', 'BBL', 'MTBE', NULL, NULL, 8.450000, 'M')
go
insert into #uomconv values(420, 'MT', 'BBL', 'DJENO', NULL, NULL, 7.052000, 'M')
go
insert into #uomconv values(421, 'MT', 'BBL', 'TAPIS', NULL, NULL, 7.832800, 'M')
go
insert into #uomconv values(422, 'MT', 'BBL', 'JETA1', NULL, NULL, 7.860000, 'M')
go
insert into #uomconv values(423, 'MT', 'BBL', 'LORETTO', NULL, NULL, 6.873600, 'M')
go
insert into #uomconv values(424, 'MT', 'BBL', 'SHENGLI', NULL, NULL, 6.936100, 'M')
go
insert into #uomconv values(425, 'MT', 'BBL', 'CANOLIMO', NULL, NULL, 7.168000, 'M')
go
insert into #uomconv values(426, 'MT', 'BBL', 'BUNKERS', NULL, NULL, 6.370000, 'M')
go
insert into #uomconv values(427, 'MT', 'BBL', 'PALANCA', NULL, NULL, 7.582900, 'M')
go
insert into #uomconv values(428, 'MT', 'BBL', 'DUBAI', NULL, NULL, 7.284000, 'M')
go
insert into #uomconv values(429, 'MT', 'BBL', 'WTI', NULL, NULL, 7.640900, 'M')
go
insert into #uomconv values(430, 'MT', 'BBL', 'LSNO2', NULL, NULL, 3.070000, 'M')
go
insert into #uomconv values(431, 'MT', 'BBL', 'ANTAN', NULL, NULL, 7.404500, 'M')
go
insert into #uomconv values(432, 'MT', 'BBL', 'CINTA', NULL, NULL, 7.105600, 'M')
go
insert into #uomconv values(433, 'MT', 'BBL', 'BIMA', NULL, NULL, 6.806700, 'M')
go
insert into #uomconv values(434, 'MT', 'BBL', 'VGOLS', NULL, NULL, 6.900000, 'M')
go
insert into #uomconv values(435, 'MT', 'BBL', 'MINAS', NULL, NULL, 7.462500, 'M')
go
insert into #uomconv values(436, 'MT', 'BBL', 'SAHARABL', NULL, NULL, 7.819400, 'M')
go
insert into #uomconv values(437, 'MT', 'BBL', 'HO', NULL, NULL, 7.458000, 'M')
go
insert into #uomconv values(438, 'MT', 'BBL', 'GASOIL', NULL, NULL, 7.458000, 'M')
go
insert into #uomconv values(439, 'MT', 'BBL', 'GASOILP', NULL, NULL, 7.458000, 'M')
go
insert into #uomconv values(440, 'MT', 'BBL', 'GASOILCR', NULL, NULL, 7.458000, 'M')
go
insert into #uomconv values(441, 'MT', 'BBL', 'GASOILLP', NULL, NULL, 7.458000, 'M')
go
insert into #uomconv values(442, 'MT', 'BBL', 'GASOILPR', NULL, NULL, 7.458000, 'M')
go
insert into #uomconv values(443, 'MT', 'BBL', 'GIPPS', NULL, NULL, 7.877400, 'M')
go
insert into #uomconv values(444, 'MT', 'BBL', 'VGOHS', NULL, NULL, 6.920000, 'M')
go
insert into #uomconv values(445, 'MT', 'BBL', 'MANDJI', NULL, NULL, 7.217100, 'M')
go
insert into #uomconv values(446, 'MT', 'BBL', 'BONNYM', NULL, NULL, 6.980700, 'M')
go
insert into #uomconv values(447, 'MT', 'BBL', 'ZAIRE', NULL, NULL, 7.270600, 'M')
go
insert into #uomconv values(448, 'MT', 'BBL', 'BUTANE', NULL, NULL, 7.690000, 'M')
go
insert into #uomconv values(449, 'MT', 'BBL', 'PREM15', NULL, NULL, 7.690000, 'M')
go
insert into #uomconv values(450, 'MT', 'BBL', 'MOGASUNL', NULL, NULL, 7.690000, 'M')
go
insert into #uomconv values(451, 'MT', 'BBL', 'WTS', NULL, NULL, 7.328600, 'M')
go
insert into #uomconv values(452, 'MT', 'BBL', 'LABUAN', NULL, NULL, 7.328600, 'M')
go
insert into #uomconv values(453, 'MT', 'BBL', 'MBYA', NULL, NULL, 7.453600, 'M')
go
insert into #uomconv values(454, 'MT', 'BBL', 'QUAIBOE', NULL, NULL, 7.453600, 'M')
go
insert into #uomconv values(455, 'MT', 'BBL', 'ATTAKA', NULL, NULL, 7.873000, 'M')
go
insert into #uomconv values(456, 'MT', 'BBL', 'LSWR', NULL, NULL, 6.700000, 'M')
go
insert into #uomconv values(457, 'MT', 'BBL', 'NO6HSSR', NULL, NULL, 6.700000, 'M')
go
insert into #uomconv values(458, 'MT', 'BBL', 'JET', NULL, NULL, 7.450000, 'M')
go
insert into #uomconv values(459, 'MT', 'BBL', 'BRENT', NULL, NULL, 7.450000, 'M')
go
insert into #uomconv values(460, 'MT', 'BBL', 'GASOIL1', NULL, NULL, 7.450000, 'M')
go
insert into #uomconv values(461, 'MT', 'BBL', 'GASOIL2', NULL, NULL, 7.450000, 'M')
go
insert into #uomconv values(462, 'MT', 'BBL', 'GASOIL3', NULL, NULL, 7.450000, 'M')
go
insert into #uomconv values(463, 'MT', 'BBL', 'GASOIL5', NULL, NULL, 7.450000, 'M')
go
insert into #uomconv values(464, 'MT', 'BBL', 'NAPHTHA', NULL, NULL, 8.900000, 'M')
go
insert into #uomconv values(465, 'MT', 'BBL', 'PROPANE', NULL, NULL, 12.400000, 'M')
go
insert into #uomconv values(466, 'MT', 'BBL', 'FLOTTA', NULL, NULL, 7.449100, 'M')
go
insert into #uomconv values(467, 'MT', 'BBL', 'LEONA', NULL, NULL, 6.793300, 'M')
go
insert into #uomconv values(468, 'MT', 'BBL', 'ORIENTE', NULL, NULL, 7.150200, 'M')
go
insert into #uomconv values(469, 'MT', 'BBL', 'ARDJUNA', NULL, NULL, 7.507100, 'M')
go
insert into #uomconv values(470, 'MT', 'BBL', 'NINIAN', NULL, NULL, 7.444600, 'M')
go
insert into #uomconv values(471, 'MT', 'BBL', 'SARIR', NULL, NULL, 7.565100, 'M')
go
insert into #uomconv values(472, 'MT', 'BBL', 'VGO5', NULL, NULL, 6.970000, 'M')
go
insert into #uomconv values(473, 'MT', 'BBL', 'ESCALANT', NULL, NULL, 6.967300, 'M')
go
insert into #uomconv values(474, 'MT', 'BBL', 'TAKULA', NULL, NULL, 7.261700, 'M')
go
insert into #uomconv values(475, 'MT', 'BBL', 'LUCINA', NULL, NULL, 7.618600, 'M')
go
insert into #uomconv values(476, 'MT', 'BBL', 'E4F', NULL, NULL, 6.384000, 'M')
go
insert into #uomconv values(477, 'MT', 'BBL', 'M100', NULL, NULL, 6.384000, 'M')
go
insert into #uomconv values(478, 'MT', 'BBL', 'RABI', NULL, NULL, 7.382200, 'M')
go
insert into #uomconv values(479, 'MT', 'BBL', 'UNL87', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(480, 'MT', 'BBL', 'UNL89', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(481, 'MT', 'BBL', 'UNLM9', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(482, 'MT', 'BBL', 'UNLR9', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(483, 'MT', 'BBL', 'UNLS9', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(484, 'MT', 'BBL', 'LEADED', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(485, 'MT', 'BBL', 'UNLM15', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(486, 'MT', 'BBL', 'UNLMO9', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(487, 'MT', 'BBL', 'UNLP15', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(488, 'MT', 'BBL', 'UNLPO9', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(489, 'MT', 'BBL', 'UNLR15', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(490, 'MT', 'BBL', 'UNLRO9', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(491, 'MT', 'BBL', 'UNLS15', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(492, 'MT', 'BBL', 'UNL87/O', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(493, 'MT', 'BBL', 'UNL89/O', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(494, 'MT', 'BBL', 'UNLM78', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(495, 'MT', 'BBL', 'UNLMO15', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(496, 'MT', 'BBL', 'UNLMO78', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(497, 'MT', 'BBL', 'UNLP78', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(498, 'MT', 'BBL', 'UNLPO15', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(499, 'MT', 'BBL', 'UNLPO78', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(500, 'MT', 'BBL', 'UNLR78', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(501, 'MT', 'BBL', 'UNLRO15', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(502, 'MT', 'BBL', 'UNLRO78', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(503, 'MT', 'BBL', 'UNLS78', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(504, 'MT', 'BBL', 'UNLM115', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(505, 'MT', 'BBL', 'UNLM135', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(506, 'MT', 'BBL', 'UNLMO115', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(507, 'MT', 'BBL', 'UNLMO135', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(508, 'MT', 'BBL', 'UNLP115', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(509, 'MT', 'BBL', 'UNLP135', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(510, 'MT', 'BBL', 'UNLP87/9', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(511, 'MT', 'BBL', 'UNLPO115', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(512, 'MT', 'BBL', 'UNLPO135', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(513, 'MT', 'BBL', 'UNLR115', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(514, 'MT', 'BBL', 'UNLR135', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(515, 'MT', 'BBL', 'UNLRO115', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(516, 'MT', 'BBL', 'UNLRO135', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(517, 'MT', 'BBL', 'UNLS115', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(518, 'MT', 'BBL', 'UNLS135', NULL, NULL, 8.480000, 'M')
go
insert into #uomconv values(519, 'MT', 'BBL', 'HANDIL', NULL, NULL, 7.315200, 'M')
go
insert into #uomconv values(520, 'MT', 'BG60', 'E4F', NULL, NULL, 16.666644, 'M')
go
insert into #uomconv values(521, 'MT', 'BG60', 'WTI', NULL, NULL, 16.666644, 'M')
go
insert into #uomconv values(522, 'MT', 'BG60', 'M100', NULL, NULL, 16.666644, 'M')
go
insert into #uomconv values(523, 'MT', 'BG60', 'BRENT', NULL, NULL, 16.666644, 'M')
go
insert into #uomconv values(524, 'MT', 'BG60', 'RME25', NULL, NULL, 16.666644, 'M')
go
insert into #uomconv values(525, 'MT', 'BG60', 'UNL92', NULL, NULL, 16.666644, 'M')
go
insert into #uomconv values(526, 'MT', 'BG60', 'NAPHTHA', NULL, NULL, 16.666644, 'M')
go
insert into #uomconv values(527, 'MT', 'BG60', 'LCGASOIL', NULL, NULL, 16.666644, 'M')
go
insert into #uomconv values(528, 'MT', 'BG60', 'VGOLS', NULL, NULL, 16.666659, 'M')
go
insert into #uomconv values(529, 'MT', 'BG60', 'VGOHS', NULL, NULL, 16.666667, 'M')
go
insert into #uomconv values(530, 'MT', 'BG60', 'GASOIL', NULL, NULL, 16.666667, 'M')
go
insert into #uomconv values(531, 'MT', 'BG60', 'NO6-10', NULL, NULL, 16.666667, 'M')
go
insert into #uomconv values(532, 'MT', 'BG60', 'NO6-30', NULL, NULL, 16.666667, 'M')
go
insert into #uomconv values(533, 'MT', 'BG60', 'NO6-35', NULL, NULL, 16.666667, 'M')
go
insert into #uomconv values(534, 'MT', 'BG60', 'HSFO180', NULL, NULL, 16.666667, 'M')
go
insert into #uomconv values(535, 'MT', 'BG60', 'HSFO380', NULL, NULL, 16.666667, 'M')
go
insert into #uomconv values(536, 'MT', 'BG60', 'NO6LSSR', NULL, NULL, 16.666667, 'M')
go
insert into #uomconv values(537, 'MT', 'BG60', 'RMG35', NULL, NULL, 16.666647, 'M')
go
insert into #uomconv values(538, 'MT', 'BG69', 'E4F', NULL, NULL, 14.492734, 'M')
go
insert into #uomconv values(539, 'MT', 'BG69', 'VGOLS', NULL, NULL, 14.492750, 'M')
go
insert into #uomconv values(540, 'MT', 'BG69', 'WTI', NULL, NULL, 14.492754, 'M')
go
insert into #uomconv values(541, 'MT', 'BG69', 'BRENT', NULL, NULL, 14.492754, 'M')
go
insert into #uomconv values(542, 'MT', 'BG69', 'UNL92', NULL, NULL, 14.492754, 'M')
go
insert into #uomconv values(543, 'MT', 'BG69', 'GASOIL', NULL, NULL, 14.492754, 'M')
go
insert into #uomconv values(544, 'MT', 'BG69', 'NO6-10', NULL, NULL, 14.492754, 'M')
go
insert into #uomconv values(545, 'MT', 'BG69', 'NO6-30', NULL, NULL, 14.492754, 'M')
go
insert into #uomconv values(546, 'MT', 'BG69', 'NO6-35', NULL, NULL, 14.492754, 'M')
go
insert into #uomconv values(547, 'MT', 'BG69', 'HSFO180', NULL, NULL, 14.492754, 'M')
go
insert into #uomconv values(548, 'MT', 'BG69', 'HSFO380', NULL, NULL, 14.492754, 'M')
go
insert into #uomconv values(549, 'MT', 'BG69', 'NAPHTHA', NULL, NULL, 14.492754, 'M')
go
insert into #uomconv values(550, 'MT', 'BG69', 'NO6LSSR', NULL, NULL, 14.492754, 'M')
go
insert into #uomconv values(551, 'MT', 'BG69', 'RMG35', NULL, NULL, 14.492736, 'M')
go
insert into #uomconv values(552, 'MT', 'BG70', 'VGOHS', NULL, NULL, 14.285715, 'M')
go
insert into #uomconv values(553, 'MT', 'BG70', 'GASOIL', NULL, NULL, 14.285715, 'M')
go
insert into #uomconv values(554, 'MT', 'BG70', 'NO6-10', NULL, NULL, 14.285715, 'M')
go
insert into #uomconv values(555, 'MT', 'BG70', 'NO6-35', NULL, NULL, 14.285715, 'M')
go
insert into #uomconv values(556, 'MT', 'BG70', 'HSFO380', NULL, NULL, 14.285715, 'M')
go
insert into #uomconv values(557, 'MT', 'BG70', 'NO6LSSR', NULL, NULL, 14.285715, 'M')
go
insert into #uomconv values(558, 'MT', 'BG70', 'RMG35', NULL, NULL, 14.285697, 'M')
go
insert into #uomconv values(559, 'MT', 'BG70', 'NO6-30', NULL, NULL, 14.285717, 'M')
go
insert into #uomconv values(560, 'MT', 'BG70', 'HSFO180', NULL, NULL, 14.285717, 'M')
go
insert into #uomconv values(561, 'MT', 'BG70', 'BRENT', NULL, NULL, 14.285702, 'M')
go
insert into #uomconv values(562, 'MT', 'BG70', 'M100', NULL, NULL, 14.285714, 'M')
go
insert into #uomconv values(563, 'MT', 'BG70', 'LCGASOIL', NULL, NULL, 14.285714, 'M')
go
insert into #uomconv values(564, 'MT', 'BG70', 'E4F', NULL, NULL, 14.285695, 'M')
go
insert into #uomconv values(565, 'MT', 'BG70', 'WTI', NULL, NULL, 14.285695, 'M')
go
insert into #uomconv values(566, 'MT', 'CMBT', 'NO6-30', NULL, NULL, 0.004114, 'M')
go
insert into #uomconv values(567, 'MT', 'CMBT', 'WTI', NULL, NULL, 0.004349, 'M')
go
insert into #uomconv values(568, 'MT', 'CMBT', 'NO6-10', NULL, NULL, 0.003982, 'M')
go
insert into #uomconv values(569, 'MT', 'CMBT', 'NO6-35', NULL, NULL, 0.003982, 'M')
go
insert into #uomconv values(570, 'MT', 'CMBT', 'HSFO180', NULL, NULL, 0.003982, 'M')
go
insert into #uomconv values(571, 'MT', 'CMBT', 'HSFO380', NULL, NULL, 0.004717, 'M')
go
insert into #uomconv values(572, 'MT', 'GAL', 'VGOHS', NULL, NULL, 288.750000, 'M')
go
insert into #uomconv values(573, 'MT', 'GAL', 'VGOLS', NULL, NULL, 288.750000, 'M')
go
insert into #uomconv values(574, 'MT', 'GAL', 'AVGAS', NULL, NULL, 357.000000, 'M')
go
insert into #uomconv values(575, 'MT', 'GAL', 'BUTANE', NULL, NULL, 322.980000, 'M')
go
insert into #uomconv values(576, 'MT', 'GAL', 'PREM15', NULL, NULL, 322.980000, 'M')
go
insert into #uomconv values(577, 'MT', 'GAL', 'HO', NULL, NULL, 313.230000, 'M')
go
insert into #uomconv values(578, 'MT', 'GAL', 'MTBE', NULL, NULL, 354.900000, 'M')
go
insert into #uomconv values(579, 'MT', 'GAL', 'GASOIL', NULL, NULL, 312.900000, 'M')
go
insert into #uomconv values(580, 'MT', 'GAL', 'GASOIL1', NULL, NULL, 312.900000, 'M')
go
insert into #uomconv values(581, 'MT', 'GAL', 'GASOIL2', NULL, NULL, 312.900000, 'M')
go
insert into #uomconv values(582, 'MT', 'GAL', 'GASOIL3', NULL, NULL, 312.900000, 'M')
go
insert into #uomconv values(583, 'MT', 'GAL', 'GASOIL5', NULL, NULL, 312.900000, 'M')
go
insert into #uomconv values(584, 'MT', 'GAL', 'BRENT', NULL, NULL, 317.171400, 'M')
go
insert into #uomconv values(585, 'MT', 'GAL', 'JET', NULL, NULL, 330.880000, 'M')
go
insert into #uomconv values(586, 'MT', 'GAL', 'GASOILP', NULL, NULL, 313.236000, 'M')
go
insert into #uomconv values(587, 'MT', 'GAL', 'GASOILCR', NULL, NULL, 313.236000, 'M')
go
insert into #uomconv values(588, 'MT', 'GAL', 'GASOILLP', NULL, NULL, 313.236000, 'M')
go
insert into #uomconv values(589, 'MT', 'GAL', 'GASOILPR', NULL, NULL, 313.236000, 'M')
go
insert into #uomconv values(590, 'MT', 'GAL', 'UNL87', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(591, 'MT', 'GAL', 'UNL89', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(592, 'MT', 'GAL', 'UNL92', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(593, 'MT', 'GAL', 'UNL93', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(594, 'MT', 'GAL', 'UNLM9', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(595, 'MT', 'GAL', 'UNLR9', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(596, 'MT', 'GAL', 'UNLS9', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(597, 'MT', 'GAL', 'LEADED', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(598, 'MT', 'GAL', 'UNLM15', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(599, 'MT', 'GAL', 'UNLMO9', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(600, 'MT', 'GAL', 'UNLP15', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(601, 'MT', 'GAL', 'UNLPO9', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(602, 'MT', 'GAL', 'UNLR15', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(603, 'MT', 'GAL', 'UNLRO9', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(604, 'MT', 'GAL', 'UNLS15', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(605, 'MT', 'GAL', 'UNL87/O', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(606, 'MT', 'GAL', 'UNL89/O', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(607, 'MT', 'GAL', 'UNL92/O', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(608, 'MT', 'GAL', 'UNLM78', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(609, 'MT', 'GAL', 'UNLMO15', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(610, 'MT', 'GAL', 'UNLMO78', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(611, 'MT', 'GAL', 'UNLP78', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(612, 'MT', 'GAL', 'UNLPO15', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(613, 'MT', 'GAL', 'UNLPO78', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(614, 'MT', 'GAL', 'UNLR78', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(615, 'MT', 'GAL', 'UNLRO15', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(616, 'MT', 'GAL', 'UNLRO78', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(617, 'MT', 'GAL', 'UNLS78', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(618, 'MT', 'GAL', 'UNLM115', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(619, 'MT', 'GAL', 'UNLM135', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(620, 'MT', 'GAL', 'UNLMO115', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(621, 'MT', 'GAL', 'UNLMO135', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(622, 'MT', 'GAL', 'UNLP115', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(623, 'MT', 'GAL', 'UNLP135', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(624, 'MT', 'GAL', 'UNLP87/9', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(625, 'MT', 'GAL', 'UNLPO115', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(626, 'MT', 'GAL', 'UNLPO135', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(627, 'MT', 'GAL', 'UNLR115', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(628, 'MT', 'GAL', 'UNLR135', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(629, 'MT', 'GAL', 'UNLRO115', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(630, 'MT', 'GAL', 'UNLRO135', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(631, 'MT', 'GAL', 'UNLS115', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(632, 'MT', 'GAL', 'UNLS135', NULL, NULL, 356.160000, 'M')
go
insert into #uomconv values(633, 'MT', 'GAL', 'NAPHTHA', NULL, NULL, 373.800000, 'M')
go
insert into #uomconv values(634, 'MT', 'GAL', 'E4F', NULL, NULL, 314.960630, 'M')
go
insert into #uomconv values(635, 'MT', 'GAL', 'WTI', NULL, NULL, 314.960630, 'M')
go
insert into #uomconv values(636, 'MT', 'GAL', 'DUTY', NULL, NULL, 314.960630, 'M')
go
insert into #uomconv values(637, 'MT', 'GAL', 'LSWR', NULL, NULL, 314.960630, 'M')
go
insert into #uomconv values(638, 'MT', 'GAL', 'NO2', NULL, NULL, 314.960630, 'M')
go
insert into #uomconv values(639, 'MT', 'GAL', 'NO6-30', NULL, NULL, 314.960630, 'M')
go
insert into #uomconv values(640, 'MT', 'GAL', 'HSFO380', NULL, NULL, 314.960630, 'M')
go
insert into #uomconv values(641, 'MT', 'GAL', 'NO6LSSR', NULL, NULL, 314.960630, 'M')
go
insert into #uomconv values(642, 'MT', 'GAL', 'BROKERFE', NULL, NULL, 314.960630, 'M')
go
insert into #uomconv values(643, 'MT', 'GAL', 'LCGASOIL', NULL, NULL, 314.960630, 'M')
go
insert into #uomconv values(644, 'MT', 'GAL', 'NO6-10', NULL, NULL, 265.860000, 'M')
go
insert into #uomconv values(645, 'MT', 'GAL', 'NO6-35', NULL, NULL, 265.860000, 'M')
go
insert into #uomconv values(646, 'MT', 'GJ', 'NO6-35', NULL, NULL, 41.990234, 'M')
go
insert into #uomconv values(647, 'MT', 'LT', 'HSFO180', NULL, NULL, 0.984207, 'M')
go
insert into #uomconv values(648, 'MT', 'LT', 'GASOIL', NULL, NULL, 1.084953, 'M')
go
insert into #uomconv values(649, 'MT', 'LT', 'KERO', NULL, NULL, 0.984205, 'M')
go
insert into #uomconv values(650, 'MT', 'LT', 'EN228', NULL, NULL, 0.984205, 'M')
go
insert into #uomconv values(651, 'MT', 'LT', 'RMG35', NULL, NULL, 0.984205, 'M')
go
insert into #uomconv values(652, 'MT', 'MB', 'BUTANE', NULL, NULL, 0.007690, 'M')
go
insert into #uomconv values(653, 'MT', 'MB', 'PREM15', NULL, NULL, 0.007690, 'M')
go
insert into #uomconv values(654, 'MT', 'MB', 'MOGASUNL', NULL, NULL, 0.007690, 'M')
go
insert into #uomconv values(655, 'MT', 'MB', 'EN228', NULL, NULL, 0.008330, 'M')
go
insert into #uomconv values(656, 'MT', 'MB', 'GASOIL1', NULL, NULL, 0.007450, 'M')
go
insert into #uomconv values(657, 'MT', 'MB', 'GASOIL2', NULL, NULL, 0.007450, 'M')
go
insert into #uomconv values(658, 'MT', 'MB', 'NO6-05', NULL, NULL, 0.006330, 'M')
go
insert into #uomconv values(659, 'MT', 'MB', 'NO6-35', NULL, NULL, 0.006330, 'M')
go
insert into #uomconv values(660, 'MT', 'MB', 'HSFO180', NULL, NULL, 0.006330, 'M')
go
insert into #uomconv values(661, 'MT', 'MB', 'HSFO380', NULL, NULL, 0.006330, 'M')
go
insert into #uomconv values(662, 'MT', 'MB', 'NO6-03HI', NULL, NULL, 0.006330, 'M')
go
insert into #uomconv values(663, 'MT', 'MB', 'E4F', NULL, NULL, 0.006384, 'M')
go
insert into #uomconv values(664, 'MT', 'MB', 'MTBE', NULL, NULL, 0.008450, 'M')
go
insert into #uomconv values(665, 'MT', 'MB', 'KERO', NULL, NULL, 0.007499, 'M')
go
insert into #uomconv values(666, 'MT', 'MB', 'M100', NULL, NULL, 0.007499, 'M')
go
insert into #uomconv values(667, 'MT', 'MB', 'RME25', NULL, NULL, 0.007499, 'M')
go
insert into #uomconv values(668, 'MT', 'MB', 'K3-VGO', NULL, NULL, 0.007499, 'M')
go
insert into #uomconv values(669, 'MT', 'MB', 'RMG35', NULL, NULL, 0.007499, 'M')
go
insert into #uomconv values(670, 'MT', 'MB', 'BUNKERS', NULL, NULL, 0.007499, 'M')
go
insert into #uomconv values(671, 'MT', 'MB', 'FUELOIL', NULL, NULL, 0.007499, 'M')
go
insert into #uomconv values(672, 'MT', 'MB', 'MSFO18', NULL, NULL, 0.007499, 'M')
go
insert into #uomconv values(673, 'MT', 'MB', 'ALKYLATE', NULL, NULL, 0.007499, 'M')
go
insert into #uomconv values(674, 'MT', 'MB', 'LAGOTREC', NULL, NULL, 0.007499, 'M')
go
insert into #uomconv values(675, 'MT', 'MB', 'LCGASOIL', NULL, NULL, 0.007499, 'M')
go
insert into #uomconv values(676, 'MT', 'MB', 'RMG35RFY', NULL, NULL, 0.007499, 'M')
go
insert into #uomconv values(677, 'MT', 'MB', 'JET', NULL, NULL, 0.007878, 'M')
go
insert into #uomconv values(678, 'MT', 'MB', 'VGOHS', NULL, NULL, 0.006900, 'M')
go
insert into #uomconv values(679, 'MT', 'MB', 'VGOLS', NULL, NULL, 0.006900, 'M')
go
insert into #uomconv values(680, 'MT', 'MB', 'URAL', NULL, NULL, 0.007351, 'M')
go
insert into #uomconv values(681, 'MT', 'MB', 'DUC', NULL, NULL, 0.007500, 'M')
go
insert into #uomconv values(682, 'MT', 'MB', 'GOIL590', NULL, NULL, 0.007500, 'M')
go
insert into #uomconv values(683, 'MT', 'MB', 'NO6LSSR', NULL, NULL, 0.006750, 'M')
go
insert into #uomconv values(684, 'MT', 'MB', 'UNL87', NULL, NULL, 0.008480, 'M')
go
insert into #uomconv values(685, 'MT', 'MB', 'UNL93', NULL, NULL, 0.008480, 'M')
go
insert into #uomconv values(686, 'MT', 'MB', 'LEADED', NULL, NULL, 0.008480, 'M')
go
insert into #uomconv values(687, 'MT', 'MG', 'HSFO180', NULL, NULL, 2.658867, 'M')
go
insert into #uomconv values(688, 'MT', 'MG', 'NO6-35', NULL, NULL, 2.658600, 'M')
go
insert into #uomconv values(689, 'MT', 'MG', 'NO6-30', NULL, NULL, 2.658604, 'M')
go
insert into #uomconv values(690, 'MT', 'MG', 'NO6-10', NULL, NULL, 2.658606, 'M')
go
insert into #uomconv values(691, 'MT', 'MG', 'WTI', NULL, NULL, 3.209309, 'M')
go
insert into #uomconv values(692, 'MT', 'MG', 'BRENT', NULL, NULL, 3.171714, 'M')
go
insert into #uomconv values(693, 'MT', 'MG', 'M100', NULL, NULL, 3.149606, 'M')
go
insert into #uomconv values(694, 'MT', 'MG', 'RMG35', NULL, NULL, 3.149606, 'M')
go
insert into #uomconv values(696, 'MT', 'MG', 'LCGASOIL', NULL, NULL, 3.149606, 'M')
go
insert into #uomconv values(697, 'MT', 'MG', 'RMG35RFY', NULL, NULL, 3.149606, 'M')
go
insert into #uomconv values(698, 'MT', 'MG', 'GASOIL', NULL, NULL, 3.132361, 'M')
go
insert into #uomconv values(699, 'MT', 'MG', 'VGOLS', NULL, NULL, 2.887500, 'M')
go
insert into #uomconv values(700, 'MT', 'MG', 'NO6LSSR', NULL, NULL, 2.835000, 'M')
go
insert into #uomconv values(701, 'MT', 'MG', 'E4F', NULL, NULL, 2.822400, 'M')
go
insert into #uomconv values(702, 'MT', 'MG', 'VGOHS', NULL, NULL, 2.898007, 'M')
go
insert into #uomconv values(703, 'MT', 'MMBT', 'HSFO180', NULL, NULL, 39.819703, 'M')
go
insert into #uomconv values(704, 'MT', 'MMBT', 'NO6-10', NULL, NULL, 39.815700, 'M')
go
insert into #uomconv values(705, 'MT', 'MMBT', 'NO6-35', NULL, NULL, 39.815700, 'M')
go
insert into #uomconv values(706, 'MT', 'MMBT', 'UNL87', NULL, NULL, 39.177600, 'M')
go
insert into #uomconv values(707, 'MT', 'MMBT', 'HSFO380', NULL, NULL, 47.169104, 'M')
go
insert into #uomconv values(708, 'MT', 'MMBT', 'NO6LSSR', NULL, NULL, 47.169104, 'M')
go
insert into #uomconv values(709, 'MT', 'MMBT', 'NO6-30', NULL, NULL, 41.145000, 'M')
go
insert into #uomconv values(710, 'MT', 'MMBT', 'WTI', NULL, NULL, 43.494563, 'M')
go
insert into #uomconv values(711, 'MT', 'STN', 'HO', NULL, NULL, 1.102310, 'M')
go
insert into #uomconv values(712, 'MT', 'STN', 'E4F', NULL, NULL, 1.102310, 'M')
go
insert into #uomconv values(713, 'MT', 'STN', 'WTI', NULL, NULL, 1.102310, 'M')
go
insert into #uomconv values(714, 'MT', 'STN', 'M100', NULL, NULL, 1.102310, 'M')
go
insert into #uomconv values(715, 'MT', 'STN', 'BRENT', NULL, NULL, 1.102310, 'M')
go
insert into #uomconv values(716, 'MT', 'STN', 'UNL87', NULL, NULL, 1.102310, 'M')
go
insert into #uomconv values(717, 'MT', 'STN', 'LCGASOIL', NULL, NULL, 1.102310, 'M')
go
insert into #uomconv values(718, 'MT', 'STN', 'VGOLS', NULL, NULL, 1.102311, 'M')
go
insert into #uomconv values(719, 'MT', 'STN', 'VGOHS', NULL, NULL, 1.102312, 'M')
go
insert into #uomconv values(720, 'MT', 'STN', 'GASOIL', NULL, NULL, 1.102312, 'M')
go
insert into #uomconv values(721, 'MT', 'STN', 'NO6-10', NULL, NULL, 1.102312, 'M')
go
insert into #uomconv values(722, 'MT', 'STN', 'NO6-30', NULL, NULL, 1.102312, 'M')
go
insert into #uomconv values(723, 'MT', 'STN', 'NO6-35', NULL, NULL, 1.102312, 'M')
go
insert into #uomconv values(724, 'MT', 'STN', 'HSFO380', NULL, NULL, 1.102312, 'M')
go
insert into #uomconv values(725, 'MT', 'STN', 'NO6LSSR', NULL, NULL, 1.102312, 'M')
go
insert into #uomconv values(726, 'MT', 'STN', 'HSFO180', NULL, NULL, 0.999954, 'M')
go
insert into #uomconv values(727, 'MT', 'UNIT', 'NO6LSSR', NULL, NULL, 6.750000, 'M')
go
insert into #uomconv values(728, 'MT', 'UNIT', 'VGOLS', NULL, NULL, 6.875000, 'M')
go
insert into #uomconv values(729, 'MT', 'UNIT', 'BRENT', NULL, NULL, 7.551700, 'M')
go
insert into #uomconv values(730, 'MT', 'UNIT', 'RME25', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(731, 'MT', 'UNIT', 'RMG35', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(733, 'MT', 'UNIT', 'RMG35RFY', NULL, NULL, 7.499063, 'M')
go
insert into #uomconv values(734, 'MT', 'UNIT', 'UNL92', NULL, NULL, 8.330000, 'M')
go
insert into #uomconv values(735, 'MT', 'UNIT', 'NO6-10', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(736, 'MT', 'UNIT', 'NO6-30', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(737, 'MT', 'UNIT', 'NO6-35', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(738, 'MT', 'UNIT', 'HSFO180', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(739, 'MT', 'UNIT', 'HSFO380', NULL, NULL, 6.330000, 'M')
go
insert into #uomconv values(740, 'MT', 'UNIT', 'UNL87', NULL, NULL, 8.480170, 'M')
go
insert into #uomconv values(741, 'MT', 'UNIT', 'WTI', NULL, NULL, 7.640900, 'M')
go
insert into #uomconv values(742, 'MT', 'UNIT', 'LCGASOIL', NULL, NULL, 7.499062, 'M')
go
insert into #uomconv values(743, 'MT', 'UNIT', 'VGOHS', NULL, NULL, 6.900000, 'M')
go
insert into #uomconv values(744, 'MT', 'UNIT', 'HO', NULL, NULL, 7.458006, 'M')
go
insert into #uomconv values(745, 'MT', 'UNIT', 'GASOIL', NULL, NULL, 7.450000, 'M')
go
insert into #uomconv values(746, 'MT', 'UNIT', 'NAPHTHA', NULL, NULL, 8.900000, 'M')
go
insert into #uomconv values(747, 'MT', 'UNIT', 'E4F', NULL, NULL, 6.720000, 'M')
go
insert into #uomconv values(748, 'THER', 'BBL', 'NATGAS', NULL, NULL, 1.000000, 'M')
go
insert into #uomconv values(749, 'UNIT', 'MB', 'DM', NULL, NULL, 0.001000, 'M')
go
insert into #uomconv values(750, 'UNIT', 'MB', 'K-M', NULL, NULL, 0.001000, 'M')
go
insert into #uomconv values(751, 'UNIT', 'MT', 'DM', NULL, NULL, 0.133350, 'M')
go
insert into #uomconv values(752, 'UNIT', 'MT', 'K-M', NULL, NULL, 0.133350, 'M')
go

declare @minoid              int,
        @last_uom_conv_num   int,
        @rows_affected       int
        
   select @minoid = min(oid)
   from #uomconv
   
   select @last_uom_conv_num = isnull(max(uom_conv_num), 0)
   from dbo.uom_conversion

   begin tran
   begin try   
     insert into dbo.uom_conversion
         (uom_conv_num,
          uom_code_conv_from,
          uom_code_conv_to,
          cmdty_code,
          uom_api_val,
          uom_gravity_val,
          uom_conv_rate,
          uom_conv_oper,
          trans_id)
     select @last_uom_conv_num + oid - @minoid + 1,
            uom_code_conv_from,
            uom_code_conv_to,
            cmdty_code,
            uom_api_val,
            uom_gravity_val,
            uom_conv_rate,
            uom_conv_oper,
            1
     from #uomconv 
     select @rows_affected = @@rowcount
   end try
   begin catch
     print '=> Failed to add new records into the uom_conversion table due to the error:'
     print '==> ERROR: ' + ERROR_MESSAGE()
     if @@trancount > 0
        rollback tran
     goto endofscript
   end catch
   commit tran
   if @rows_affected > 0
      print '=> ' + cast(@rows_affected as varchar) + ' records were added into the uom_conversion table successfully'
   else
      print '=> No records were added into the uom_conversion table!'

endofscript:
go

drop table #uomconv
go

exec dbo.refresh_a_last_num 'uom_conversion', 'uom_conv_num'
go
   
   
   