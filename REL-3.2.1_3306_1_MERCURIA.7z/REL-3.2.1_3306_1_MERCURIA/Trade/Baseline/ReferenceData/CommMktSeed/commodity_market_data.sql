print 'Loading additional seed data into the commodity_market table ...'
go

/*
    commkt_key                 int      NOT NULL,
    mkt_code                   char(8)  NOT NULL,
    cmdty_code                 char(8)  NOT NULL,
    mtm_price_source_code      char(8)  NULL,
    dflt_opt_eval_method       char(1)  NULL,
    trans_id                   int      NOT NULL,
    man_input_sec_qty_required char(1)  default 'N' NULL
*/

insert into commodity_market values(1, 'NYMEX', 'WTI', 'EXCHANGE', 'L', 1, 'N')
go

insert into commodity_market values(2, 'CCIFMED', 'GASOIL', NULL, 'C', 1, 'N')
go

insert into commodity_market values(4, 'NYMEX', 'UNL87', 'EXCHANGE', 'C', 1, 'N')
go

insert into commodity_market values(5, 'NYMEX', 'HO', 'EXCHANGE', 'C', 1, 'N')
go

insert into commodity_market values(12, 'BFOBROT', 'JET', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(26, 'CCIFNWE', 'JET', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(27, 'CCIFNWE', 'NAPHTHA', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(28, 'CFOBNWE', 'GASOIL2', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(30, 'CCIFMED', 'PREM15', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(31, 'GULFPIPE', 'UNL87', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(34, 'GULFPIPE', 'JET', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(38, 'BFOBROT', 'GASOIL2', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(41, 'NYHCRG', 'NO6-30', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(53, 'CFOBCAR', 'GASOIL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(55, 'GULFPIPE', 'UNL92', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(58, 'CFOBNWE', 'JET', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(60, 'GULFUS', 'UNL92', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(64, 'BFOBROT', 'PREM15', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(65, 'CCIFNWE', 'GASOIL2', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(66, 'CFOBARAG', 'GASOIL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(72, 'PWCLA', 'UNL92', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(84, 'CFOBCAR', 'JET', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(86, 'CCIFNWE', 'UNL87', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(91, 'NYHCRG', 'UNL92', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(92, 'CFOBNWE', 'GASOIL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(93, 'CFOBNWE', 'PREM15', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(94, 'BFOBROT', 'GASOIL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(95, 'BFOBROT', 'UNL87', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(96, 'CCIFNWE', 'GASOIL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(97, 'CCIFNWE', 'PREM15', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(101, 'CFOBMED', 'GASOIL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(102, 'CFOBMED', 'JET', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(104, 'CFOBMED', 'PREM15', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(105, 'PWCLA', 'JET', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(113, 'GULFUS', 'NAPHTHA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(117, 'NYHCRG', 'UNL87', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(125, 'WAFRICA', 'BONNYL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(126, 'WAFRICA', 'BONNYM', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(131, 'SAMERICA', 'ORIENTE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(135, 'NSEA', 'BRENT', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(137, 'WAFRICA', 'FORCADOS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(140, 'NSEA', 'EKOFISK', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(141, 'NSEA', 'OSEBERG', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(143, 'PGULF', 'DUBAI', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(144, 'PGULF', 'OMAN', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(146, 'CCIFMED', 'URAL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(149, 'MIDLAND', 'WTS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(150, 'DOMPIPE', 'LLS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(164, 'NYHCRG', 'HO', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(168, 'GULFPIPE', 'HO', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(170, 'NYHBRG', 'HO', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(187, 'KOCH', 'WTS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(201, 'CUSHING', 'WTI', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(203, 'CCIFNWE', 'E4F', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(204, 'CCFSINGP', 'HSFO180', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(207, 'CCFSINGP', 'GASOIL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(210, 'CCFSINGP', 'MOGASUNL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(213, 'IPE', 'BRENT', 'EXCHANGE', 'L', 1, 'N')
go

insert into commodity_market values(215, 'IPE', 'GASOIL', 'EXCHANGE', 'C', 1, 'N')
go

insert into commodity_market values(227, 'BFOBROT', 'NO6-35', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(228, 'BFOBROT', 'NO6-10', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(229, 'CFOBNWE', 'NO6-30', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(230, 'CFOBNWE', 'NO6-35', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(231, 'CFOBMED', 'NO6-10', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(232, 'GULFUS', 'NO6-30', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(234, 'CCIFNWE', 'NO6-10', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(236, 'GULFUS', 'NO6-10', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(237, 'CFOBNWE', 'NO6-10', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(240, 'CCFSINGP', 'HSFO380', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(242, 'CCIFNWE', 'NO6-35', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(243, 'CFOBMED', 'NO6-35', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(251, 'MALAYSIA', 'TAPIS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(257, 'INDONESI', 'DURI', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(348, 'GULFUS', 'UNL89', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(400, 'GULFUS', 'HO', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(402, 'GULFUS', 'UNL87', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(800, 'WAFRICA', 'BRASS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(801, 'WAFRICA', 'CABINDA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(802, 'WAFRICA', 'ESCRAVOS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(808, 'WAFRICA', 'PENN', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(809, 'WAFRICA', 'QUAIBOE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(814, 'SAMERICA', 'LEONA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(818, 'NSEA', 'STAT', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(821, 'NSEA', 'GULLFAKS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(829, 'NYMEX', 'WTS', 'EXCHANGE', 'C', 1, 'N')
go

insert into commodity_market values(883, 'GULFUS', 'UNLP87/9', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(899, 'GULFPIPE', 'UNLR9', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(902, 'GULFUS', 'UNLR9', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(966, 'CCFSINGP', 'GASOIL5', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1248, 'FAREAST', 'TAPIS', 'APPI', 'C', 1, 'N')
go

insert into commodity_market values(1250, 'CCIFNWE', 'UNL92', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1251, 'CFOBNWE', 'UNL92', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1252, 'BFOBROT', 'UNL92', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1347, 'CCIFMED', 'GASOIL2', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1348, 'CFOBMED', 'GASOIL2', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1429, 'DLVDRDAM', 'URAL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1442, 'DLVDGULF', 'ORIENTE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1447, 'CFOBMED', 'GOIL590', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1449, 'CFOBNWE', 'GOIL590', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1450, 'CCIFNWE', 'GOIL590', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1541, 'BFOBROT', 'GOIL590', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1554, 'DEMO', 'RATAWI', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1555, 'FAREAST', 'RATAWI', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1557, 'CFOBARAG', 'AH', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1559, 'NSEA', 'DUC', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1562, 'NYMEX', 'NATGAS', 'EXCHANGE', 'C', 1, 'N')
go

insert into commodity_market values(1564, 'CFOBARAG', 'AL', 'APPI', 'C', 1, 'N')
go

insert into commodity_market values(1568, 'NSEA', 'CAPTAIN', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1569, 'INDONESI', 'BELIDA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1570, 'FAREAST', 'EOCENE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1571, 'WAFRICA', 'SOYO', 'DRI', 'C', 1, 'N')
go

insert into commodity_market values(1573, 'NSEA', 'BERYL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1575, 'CFOBARAG', 'EOCENE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1579, 'SAMERICA', 'MESA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1583, 'AUSTRAL', 'BARROWIS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1587, 'NSEA', 'FULMAR', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1594, 'CFOBARAG', 'ALB', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1596, 'NSEA', 'HELMBL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1599, 'MEXICO', 'MAYA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1603, 'C&FCHINA', 'NANHAILT', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1610, 'INDONESI', 'SEMBILAN', 'APPI', 'C', 1, 'N')
go

insert into commodity_market values(1612, 'CFOBMED', 'SOUEDIE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1615, 'INDONESI', 'SUMATRAL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1617, 'NSEA', 'BLENHEIM', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1623, 'PGULF', 'BASRAHLT', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1624, 'AUSTRAL', 'THEVENAR', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1625, 'NSEA', 'GULLFAKC', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1628, 'MEXICO', 'ISTHMUS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1629, 'CFOBARAG', 'KIRKUK', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1631, 'VENEZUEL', 'LAGOMEDI', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1637, 'FOBCHINA', 'NANHAILT', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1638, 'WAFRICA', 'ODUDU', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1640, 'IPE', 'NATGAS', 'EXCHANGE', 'C', 1, 'N')
go

insert into commodity_market values(1641, 'USGCPL54', 'JET', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1643, 'USGCWB54', 'JET', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1661, 'USGCPLLS', 'HO', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1662, 'USGCWBLS', 'HO', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1673, 'CFCARBBL', 'NO6-28', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1683, 'CFOBNWE', 'UNL87', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1687, 'RFGUSGPL', 'UNL87', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1688, 'RFGUSGWB', 'UNL87', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1689, 'CCIFMED', 'UNL92', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1690, 'CFOBMED', 'UNL92', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1693, 'RFGUSGPL', 'UNL92', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1699, 'FOBROT98', 'MOGASUNL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1700, 'SING95', 'MOGASUNL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1701, 'SING97', 'MOGASUNL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1729, 'IFPCGLA', 'NATGAS', 'FERC', 'C', 1, 'N')
go

insert into commodity_market values(1731, 'IFPPLSA', 'NATGAS', 'FERC', 'C', 1, 'N')
go

insert into commodity_market values(1733, 'IFWELAPP', 'NATGAS', NULL, 'C', 1, 'N')
go

insert into commodity_market values(1744, 'KCBT', 'NATGAS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1776, 'SNG/LA', 'NATGAS', 'FERC', 'C', 1, 'N')
go

insert into commodity_market values(1777, 'TENN/0', 'NATGAS', 'FERC', 'C', 1, 'N')
go

insert into commodity_market values(1780, 'TET/LA', 'NATGAS', 'FERC', 'C', 1, 'N')
go

insert into commodity_market values(1790, 'TRANS/3', 'NATGAS', 'FERC', 'C', 1, 'N')
go

insert into commodity_market values(1796, 'TRUNK/F', 'NATGAS', 'FERC', 'C', 1, 'N')
go

insert into commodity_market values(1813, 'GULFUS', 'GASOIL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1814, 'BFOBROT', 'MTBE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1817, 'GULFUS', 'MTBE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1819, 'SPRDICP', 'DURI', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1820, 'SPRDICP', 'SUMATRAL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1822, 'SPRDICP', 'BELIDA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1824, 'SPRDTAP', 'TAPIS', NULL, 'C', 1, 'N')
go

insert into commodity_market values(1832, 'CFOBNWE', 'NO6LSSR', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1835, 'CCFSINGP', 'LSWR', NULL, 'C', 1, 'N')
go

insert into commodity_market values(1836, 'DTDNSEA', 'BRENT', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1837, 'NSEA', 'NORNE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1838, 'NSEA', 'HARDING', NULL, 'C', 1, 'N')
go

insert into commodity_market values(1839, 'NSEA', 'DURWARD', NULL, 'C', 1, 'N')
go

insert into commodity_market values(1840, 'TXCARIB', 'AVGAS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1841, 'TXCAR95', 'LEADED', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1847, 'TXCARIB', 'JET', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1848, 'TXCARIB', 'NO6-28', 'TEXACO', 'C', 1, 'N')
go

insert into commodity_market values(1849, 'TXCAR95', 'UNL92', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1851, 'WAFRICA', 'NIGERIAN', NULL, 'C', 1, 'N')
go

insert into commodity_market values(1852, 'CCIFNWE', 'BUTANE', 'ARGUS', 'C', 1, 'N')
go

insert into commodity_market values(1854, 'MBELVIEW', 'BUTANE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1855, 'NSEA', 'LIVBAYBL', NULL, 'C', 1, 'N')
go

insert into commodity_market values(1856, 'NSEA', 'FIFE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1857, 'FAREAST', 'AH', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1859, 'GULFUS', 'AH', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1868, 'GULFUS', 'AM', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1869, 'GULFUS', 'MOGASUNL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1870, 'NSEA', 'VGOLS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1871, 'NSEA', 'VGOHS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1875, 'TXCAR87', 'UNL87', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1876, 'CCIFMED', 'LEADED', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1877, 'NWP/ROCK', 'NATGAS', 'FERC', 'C', 1, 'N')
go

insert into commodity_market values(1878, 'NSEA', 'ALBA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1879, 'MBELVIEW', 'PROPANE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1880, 'CCIFNWE', 'PROPANE', 'ARGUS', 'C', 1, 'N')
go

insert into commodity_market values(1882, 'WAFRICA', 'ZAFIRO', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1883, 'BFOBROT', 'LEADED', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1884, 'GULFPIPE', 'AVGAS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1885, 'GULFUS', 'AVGAS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1886, 'NWE', 'VGOLS', 'ARGUS', 'C', 1, 'N')
go

insert into commodity_market values(1887, 'CCIFNWE', 'VGOLS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1891, 'WCOAST', 'SANTABAR', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1892, 'NSEA', 'LCGASOIL', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1893, 'BFOBROT', 'VGOLS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1894, 'CFOBNWE', 'VGOLS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1895, 'CCIFNWE', 'LEADED', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1896, 'CFOBNWE', 'LEADED', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1897, 'CFOBNWE', 'LSWR', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1899, 'GULFUS', 'SPRAYTEX', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1903, 'VENEZUEL', 'LAGOTREC', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1905, 'BFOBROT', 'ALKYLATE', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1907, 'DTDNSEA', 'FLOTTA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1908, 'DTDNSEA', 'FORTIES', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1910, 'CFOBNWE', 'VGOHS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1911, 'CCIFNWE', 'LCGASOIL', 'PLATTS', 'L', 1, 'N')
go

insert into commodity_market values(1913, 'CCIFNWE', 'EN228', 'PLATTS', 'L', 1, 'N')
go

insert into commodity_market values(1916, 'CFOBNWE', 'EN228', 'PLATTS', 'L', 1, 'N')
go

insert into commodity_market values(1917, 'BFOBROT', 'EN228', 'PLATTS', 'L', 1, 'N')
go

insert into commodity_market values(1918, 'GULFUS', 'LS NO2', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1919, 'CFOBMED', 'LEADED', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1920, 'GULFPIPE', 'LS NO2', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1923, 'FAREAST', 'GASOIL', NULL, NULL, 1, 'N')
go

insert into commodity_market values(1926, 'WAFRICA', 'OSO', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1927, 'POTEN', 'PEN60/70', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1932, 'GULFUS', 'NO2', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1933, 'CCIFARA', 'BUTANE', 'ARGUS', 'L', 1, 'N')
go

insert into commodity_market values(1934, 'NYMEX', 'PROPANE', 'EXCHANGE', 'L', 1, 'N')
go

insert into commodity_market values(1936, 'CCIFARA', 'PROPANE', 'ARGUS', 'L', 1, 'N')
go

insert into commodity_market values(1937, 'SAUDARAM', 'BUTANE', 'ARGUS', 'L', 1, 'N')
go

insert into commodity_market values(1938, 'SAUDARAM', 'PROPANE', 'ARGUS', 'L', 1, 'N')
go

insert into commodity_market values(1939, 'CHEMASMN', 'GALEOTA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1940, 'NSEABP', 'BUTANE', 'ARGUS', 'L', 1, 'N')
go

insert into commodity_market values(1945, 'NSEA', 'FLOTTA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1946, 'GULFUS', 'JET', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1947, 'NSEA', 'FORTIES', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1951, 'CFOBNWE', 'UNL93', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1953, 'VENEZUEL', 'LAGMEDRE', 'PLATTS', 'L', 1, 'N')
go

insert into commodity_market values(1955, 'CFOBMED', 'SYB', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1956, 'MEXICO', 'MAYAISTH', 'PLATTS', 'L', 1, 'N')
go

insert into commodity_market values(1958, 'KOCH', 'WTI', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1959, 'CFOBNWE', 'GASOIL1', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1960, 'NYHCRG', 'NO6-10', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1962, 'P-PLUS', 'WTI', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1968, 'KPPC', 'WTI', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1969, 'SUNRCUSH', 'WTI', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1970, 'PPLUSUNC', 'WTI', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1971, 'SCERCUSH', 'WTI', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1972, 'PPLUSCER', 'WTI', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1973, 'CFOBNWE', 'HSFO380', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1974, 'CCIFNWE', 'NO6-30', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1975, 'CCIFMED', 'NO6-35', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1976, 'CCIFMED', 'NO6-10', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(1978, 'CCFSINGP', 'VGOLS', NULL, NULL, 1, 'N')
go

insert into commodity_market values(1979, 'INTRATE', 'USDINT', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1980, 'DTDNSEA', 'EKOFISK', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1986, 'ROTTERDA', 'EKOFISK', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1987, 'LATTAVRE', 'FORTIES', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(1988, 'LATTAVRE', 'BRENT', 'INTERNAL', 'L', 1, 'N')
go

insert into commodity_market values(1989, 'ROTTERDA', 'BRENT', 'INTERNAL', 'L', 1, 'N')
go

insert into commodity_market values(1990, 'WHAVEN', 'BRENT', 'INTERNAL', 'L', 1, 'N')
go

insert into commodity_market values(1991, 'INTRATES', 'USDINT', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(1996, 'USD', 'WGC', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(1997, 'USD', 'DM', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(1999, 'USD', 'USD_EX', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2001, 'LHSTOR', 'BRENT', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2002, 'INVROLL', 'PRODUCT', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(2003, 'INVROLL', 'PRODUCTS', NULL, NULL, 1, 'N')
go

insert into commodity_market values(2006, 'GULFUS', 'MPC', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2007, 'GULFUS', 'LAGUNA', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2009, 'DTDNSEA', 'NEMBA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(2010, 'INVROLL', 'CRUDE', 'PLATTS', 'L', 1, 'N')
go

insert into commodity_market values(2011, 'WHAVEN', 'FORTIES', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2012, 'WAFRICA', 'PALANCA', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(2013, 'MALMO', 'K3-VGO', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2014, 'NYCST', 'HSFO380', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2015, 'GULFUS', 'MEREY', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(2016, 'NYCST', 'BUNKERS', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(2017, 'NYHBRG', 'UNL87', 'PLATTS', NULL, 1, 'N')
go

insert into commodity_market values(2018, 'NYMEXGC', 'UNL87', 'PLATTS', NULL, 1, 'N')
go

insert into commodity_market values(2019, 'FOB', 'EKOFISK', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2021, 'VGOINV', 'VGOLS', 'INTERNAL', 'L', 1, 'N')
go

insert into commodity_market values(2023, 'NYHCRG', 'NO6-22', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(2024, 'CCIFNWE', 'M100', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2026, 'CUSGP', 'UNL87', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2027, 'STROSE', 'VGOHS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2028, 'STROSE', 'VGOLS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2029, 'NWEVGO', 'VGOHS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2031, 'HSFOB', 'NO6-35', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2034, 'KARLSHAM', 'HSFO380', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2036, 'HSVGOM', 'VGOHS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2038, 'VGO-OPN', 'VGOLS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2041, 'PETROTR', 'VGOHS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2043, 'RMG35', 'NO6-35', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2049, 'STATUK', 'M100', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2050, 'TOTAL', 'NO6-10', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2051, 'NTERM', 'M100', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2052, 'PETRONOR', 'NO6-35', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2053, 'NOMKTOMK', 'NO6LSSR', 'PLATTSPT', 'C', 1, 'N')
go

insert into commodity_market values(2054, 'NOMKTOMK', 'VGOHS', 'PLATTSPT', 'C', 1, 'N')
go

insert into commodity_market values(2055, 'NOMKTOMK', 'VGOLS', 'PLATTSPT', 'C', 1, 'N')
go

insert into commodity_market values(2056, 'NOMKTOMK', 'HSFO380', 'PLATTSPT', 'C', 1, 'N')
go

insert into commodity_market values(2057, 'NOMKTOMK', 'NO6-35', 'PLATTSPT', 'C', 1, 'N')
go

insert into commodity_market values(2058, 'NOMKTOMK', 'NO6-10', 'PLATTSPT', 'C', 1, 'N')
go

insert into commodity_market values(2059, 'NOMKTOMK', 'NO6-30', 'PLATTSPT', 'C', 1, 'N')
go

insert into commodity_market values(2060, 'NOMKTOMK', 'M100', 'PLATTSPT', 'C', 1, 'N')
go

insert into commodity_market values(2061, 'NOMKTOMK', 'E4F', 'PLATTSPT', 'C', 1, 'N')
go

insert into commodity_market values(2063, 'BFOBROT', 'M100', 'INTERNAL', 'L', 1, 'N')
go

insert into commodity_market values(2064, 'KARLSHAM', 'M100', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2065, 'BFOBROT', 'RMG35', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2067, 'BFOBROT', 'RMG35RFY', 'PLATTS', 'C', 1, 'N')
go

insert into commodity_market values(2070, 'USD', 'CAC', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2072, 'U-CFOB+8', 'NO6-10', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2075, 'MIDLAND', 'WTI', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2076, 'OCTWTI', 'WTI', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2077, 'NYMEX', 'VGOLS', 'EXCHANGE', 'C', 1, 'N')
go

insert into commodity_market values(2078, 'NYMEX', 'VGOHS', 'EXCHANGE', 'C', 1, 'N')
go

insert into commodity_market values(2080, 'OCTWTI', 'VGOLS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2081, 'OCTWTI', 'VGOHS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2082, 'CHGDLY', 'LCGASOIL', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2089, 'DINV', 'JCOND', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2090, 'IPE', 'FUELOIL', 'EXCHANGE', 'L', 1, 'N')
go

insert into commodity_market values(2094, 'INTFUTS', 'BRENT', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2095, 'BFOBROT', 'RME25', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2098, 'HICIF+$3', 'NO6-35', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2099, 'EOTT', 'WTI', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2100, 'NOMKTOMK', 'GASOIL2', 'PLATTSPT', 'C', 1, 'N')
go

insert into commodity_market values(2102, 'TRIGGER', 'BRENT', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2103, 'USD', 'UKC', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2104, 'USD', 'NLG', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2105, 'USD', 'GBP', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2107, 'BFOBROT', 'VGOHS', NULL, NULL, 1, 'N')
go

insert into commodity_market values(2108, 'CCIFNWE', 'VGOHS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2126, 'MYSTRAS', 'HSFO180', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2129, 'CFOBMED', 'NO6LSSR', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2130, 'FOBNWE', 'PALANCA', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2131, 'NYMEX', 'WTI-HO', 'EXCHANGE', 'L', 1, 'N')
go

insert into commodity_market values(2132, 'FOB*', 'EKOFISK', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2135, 'RMG35M', 'NO6-30', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2138, 'USD', 'FFR', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2139, 'CCIFMED', 'MSFO18', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2141, 'USD', 'SEK', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2142, 'USD', 'ITL', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2143, 'USD', 'BFR', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2144, 'USD', 'ESP', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2145, 'USD', 'IEP', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2146, 'USD', 'ATS', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2147, 'USD', 'PTE', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2148, 'CCIFMED', 'GOIL590', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2149, 'CCIFMED', 'JET', NULL, NULL, 1, 'N')
go

insert into commodity_market values(2151, 'CCFSINGP', 'KERO', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2155, 'NYHCRG', 'NO6LSSR', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2157, 'USD', 'EURODLR', NULL, NULL, 1, 'N')
go

insert into commodity_market values(2160, 'CFOBARAG', 'KERO', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2161, 'PGULF', 'DUB-DIST', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2163, 'JUNIP+EW', 'KERO', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2164, 'CIFMARG', 'VGOHS', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2171, 'ENFMED-5', 'GOIL590', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2172, 'LEHAVRE', 'JET', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2173, 'PETROLA', 'GASOIL2', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2174, 'CIFMAY-8', 'NO6-35', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2178, 'SINGA3', 'HSFO180', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2179, 'FMED+3', 'GASOIL2', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2183, 'FOBSING', 'JET', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2185, 'CCIFNWE', 'KERO', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2186, 'CROWN', 'GASOIL2', NULL, NULL, 1, 'N')
go

insert into commodity_market values(2188, 'TITRIG', 'WTI', 'INTERNAL', 'L', 1, 'N')
go

insert into commodity_market values(2190, 'MALT-INV', 'GOIL590', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2191, 'ENCMEDHI', 'GOIL590', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2194, 'SINGINV', 'JET', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2195, 'CIFNWE', 'JET', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2196, 'CIFNWE', 'JETA1', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2198, 'GHENTINV', 'JET', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2199, 'RUSSIAN', 'GASOIL2', 'INTERNAL', 'C', 1, 'N')
go

insert into commodity_market values(2200, 'USD', 'DANKRN', 'INTERNAL', NULL, 1, 'N')
go

insert into commodity_market values(2203, 'PGULF', 'GASOIL5', 'INTERNAL', 'L', 1, 'N')
go

insert into commodity_market values(2206, 'HSFOAUG', 'NO6-35', NULL, NULL, 1, 'N')
go

insert into commodity_market values(2207, 'IFHHCP', 'NATGAS', NULL, NULL, 1, 'N')
go

