/* 
TABLE dbo.commodity_specification 
    cmdty_code             char(8)      NOT NULL,
    spec_code              char(8)      NOT NULL,
    cmdty_spec_min_val     float        NOT NULL,
    cmdty_spec_max_val     float        NOT NULL,
    cmdty_spec_typical_val float        NOT NULL,
    spec_type		           char(1)      NOT NULL,   
    trans_id               int          NOT NULL,
    typical_string_value   varchar(40)  NULL
    dflt_spec_test_code	   char(8)	    NULL,
    standard_ind	         char(1)	    default 'Y' NOT NULL
        check (standard_ind in ('Y', 'N'))
*/

print 'Loading additional seed data into the commodity_specification table ...'
go

insert into commodity_specification values('BELIDA', 'TEMP-C', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('BELIDA', 'TEMP-F', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('BRENT', 'TEMP-C', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('BRENT', 'TEMP-F', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('CAPTAIN', 'TEMP-C', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('CAPTAIN', 'TEMP-F', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('DUC', 'TEMP-C', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('DUC', 'TEMP-F', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('DURI', 'TEMP-C', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('DURI', 'TEMP-F', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('EN228', 'BDENSITY', 0.0, 0.0, 0.755000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('EN228', 'EDENSITY', 0.0, 0.0, 0.755000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('EN228', 'EM13WINT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('EOCENE', 'TEMP-C', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('EOCENE', 'TEMP-F', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('FLOTTA', 'TEMP-C', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('FLOTTA', 'TEMP-F', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL', 'BDENSITY', 0.0, 0.0, 0.845000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL', 'EDENSITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'BDENSITY', 0.0, 0.0, 0.845000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'CETANE', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'CLOUDC', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'COLDFILT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'COLOR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'DENSITY1', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'DIST250C', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'DIST350C', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'EDENSITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'EG9', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'FLASHC', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'OXIDAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'TOTSULPH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'VICOS', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'WV_Qty', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GASOIL2', 'WV_Uom', 0.0, 0.0, 0.0, 'A', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GOIL590', 'BDENSITY', 0.0, 0.0, 0.845000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GOIL590', 'EDENSITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('GOIL590', 'EG11', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('HO', 'CPL75', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('HO', 'CPL76', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('HO', 'CPL86', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('HO', 'EXP76', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('HO', 'EXP77', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('HO', 'TET76', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('JET', 'BDENSITY', 0.0, 0.0, 0.800000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('JET', 'DEFSTAN', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('JET', 'DERD2494', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('JET', 'EA7', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('JET', 'EDENSITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('JET', 'EK3', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('KERO', 'CPL55', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('KERO', 'TET55', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('LEADED', 'BDENSITY', 0.0, 0.0, 0.755000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('LEADED', 'EDENSITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('MINAS', 'TEMP-C', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('MINAS', 'TEMP-F', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO2', 'CPL86', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03HI', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-03LO', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-05', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-07', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'BDENSITY', 0.0, 0.0, 6.330000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'EDENSITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-10', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-16', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-20', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-22', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-28', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-29', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-30', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6-35', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSCR', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSSR', 'ASPHALT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSSR', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSSR', 'DENSITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSSR', 'DISTILL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSSR', 'IBP', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSSR', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSSR', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSSR', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6HSSR', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'ALUMINUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'ASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'BTU/GAL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'COMPAT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'SHELL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'SILICON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSCR', 'WATERSED', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSSR', 'ASPHALT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSSR', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSSR', 'DENSITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSSR', 'DISTILL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSSR', 'IBP', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSSR', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSSR', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSSR', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('NO6LSSR', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('RATAWI', 'TEMP-C', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('RATAWI', 'TEMP-F', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('SOYO', 'TEMP-C', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('SOYO', 'TEMP-F', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL87', 'BDENSITY', 0.0, 0.0, 0.755000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL87', 'CPLM1', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL87', 'CPLM3', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL87', 'CPLM4', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL87', 'EDENSITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL92', 'BDENSITY', 0.0, 0.0, 0.755000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL92', 'CPLU2', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL92', 'CPLV3', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL92', 'CPLV4', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL92', 'EDENSITY', 0.0, 0.0, 0.755000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL93', 'CPLV1', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL93', 'CPLV3', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNL93', 'CPLV4', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLM115', 'CPL12', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLM115', 'CPL13', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLM135', 'CPL12', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLM135', 'CPL13', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLM78', 'CPL12', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLM78', 'CPL13', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLM9', 'CPL13', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLMO115', 'CPL11', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLMO135', 'CPL11', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLMO78', 'CPL11', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLMO9', 'CPL11', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLMO9', 'CPL15', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLP115', 'CPL20', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLP115', 'CPL22', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLP135', 'CPL20', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLP135', 'CPL22', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLP78', 'CPL20', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLP78', 'CPL22', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLP87/9', 'BDENSITY', 0.0, 0.0, 0.755000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLP87/9', 'EDENSITY', 0.0, 0.0, 0.755000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLR115', 'CPL44', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLR135', 'CPL44', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLR135', 'CPL48', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLR135', 'WPLN', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLR15', 'CPL48', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLR15', 'WPLN', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLR78', 'CPL44', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLR9', 'CPL44', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLR9', 'CPL48', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLR9', 'WPLN', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLRO135', 'CPL45', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLRO15', 'CPL45', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLRO9', 'CPL45', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLS115', 'CPL21', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLS115', 'CPL23', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLS135', 'CPL21', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLS135', 'CPL23', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLS78', 'CPL21', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('UNLS78', 'CPL23', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'ANILINE', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'BASICNIT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'DIST10', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'DIST20', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'DIST50', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'DIST90', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'DISTEND', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'DISTILL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'IBP', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'NITROGEN', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'ANILINE', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'BASICNIT', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'BS&W', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'CCR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'COPPER', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'DIST10', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'DIST20', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'DIST50', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'DIST90', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'DISTEND', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'DISTILL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'FLASH', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'GRAVITY', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'IBP', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'IRON', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'NICKEL', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'NITROGEN', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'POUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'SODIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'SULFUR', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGO5', 'VANADIUM', 0.0, 0.0, 0.0, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGOHS', 'API', 0.0, 0.0, 16.003000, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGOHS', 'DENS15C', 0.0, 0.0, 0.959300, 'N', 1, NULL, NULL, 'Y')
go

insert into commodity_specification values('VGOHS', 'SG60F', 0.0, 0.0, 0.959300, 'N', 1, NULL, NULL, 'Y')
go

