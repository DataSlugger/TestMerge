print 'Loading energy product data ...'
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ABRAINBO', 'Y', 'P', 'I', 'AB RAINBOW STRE', 'AB RAINBOW STREAM', 
         'CDN', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ABTEXCOM', 'Y', 'P', 'I', 'AB TEX COMMON S', 'AB TEX COM STREAM LT/SWEET', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('AH', 'N', 'P', 'I', 'ARAB HEAVY', 'ARAB HEAVY CRUDE OIL', 
         'SA', 'SAUDI ARABIA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('AL', 'N', 'P', 'I', 'ARAB LIGHT', 'ARAB LIGHT CRUDE OIL', 
         'SA', 'SAUDIA ARABIA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('AL/AH', 'Y', 'P', 'A', 'ARAB LIGHT/HEAV', 'ARAB LIGHT/ARAB HEAVY CRUDE OIL', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ALB', 'N', 'P', 'I', 'ARAB LIGHT BERR', 'ARAB LIGHT BERRI CRUDE OIL', 
         'SA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ALBA', 'N', 'P', 'I', 'ALBA', 'ALBA CRUDE OIL', 
         'UK', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ALGERIAN', 'Y', 'P', 'A', 'ALGERIAN CONDEN', 'ALGERIIAN CONDENSATE CRUDE OIL', 
         'DZ', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ALKYLATE', 'N', 'P', 'I', 'ALKYLATE', 'ALKYLATE', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('AM', 'N', 'P', 'I', 'ARAB MED', 'ARAB MEDIUM CRUDE OIL', 
         'SA', 'SAUDIA ARABIA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ANS', 'Y', 'P', 'A', 'ANS', 'ALASKA NORTH SLOPE CRUDE OIL', 
         'USA', 'ALASKA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ANTAN', 'Y', 'P', 'A', 'ANTAN', 'ANTAN CRUDE OIL', 
         'WAN', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ARDJUNA', 'N', 'P', 'I', 'ARDJUNA', 'ARDJUNA CRUDE OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ARUN', 'N', 'P', 'A', 'ARUN CONDENSATE', 'ARUN CONDENSATE CRUDE OIL', 
         'RI', 'INDONESIA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ASHT', 'N', 'P', 'I', 'ASHTART', 'ASHTART CRUDE OIL', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ASPHALT', 'N', 'P', 'I', 'ASPHALT', 'ASPHALT', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ATTAKA', 'N', 'P', 'A', 'ATTAKA', 'ATTAKA CRUDE OIL', 'RI', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('AVGAS', 'N', 'P', 'I', 'AVGAS 100/130', 'AVGAS 100/130', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BACH13', 'N', 'P', 'A', 'BACHAQUERO 13', 'BACHAQUERO 13 CRUDE OIL', 
         'YV', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BACH168', 'N', 'P', 'A', 'BACHAQUERO 16.8', 'BACHAQUERO 16.8 CRUDE OIL', 
         'YV', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BARROWIS', 'N', 'P', 'I', 'BARROW ISLAND', 'BARROW ISLAND CRUDE OIL', 
         'AUS', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BASRAHLT', 'Y', 'P', 'A', 'BASRAH LIGHT', 'BASRAH LIGHT CRUDE OIL', 
         'IRG', 'IRAG', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BBQ', 'N', 'P', 'I', 'BONNY,QUA IBOE', 'BONNY,QUA IBOE CRUDE OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BCF-24', 'Y', 'P', 'A', 'BCF-24', 'BCF-34 CRUDE OIL', 
         'YV', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BEATRICE', 'Y', 'P', 'A', 'BEATRICE', 'BEATRICE CRUDE OIL', 
         'UK', 'UNITED KINGDOM', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BELAYIM', 'Y', 'P', 'A', 'BELAYIM', 'BELAYIM CRUDE OIL', 
         'ET', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BELIDA', 'N', 'P', 'I', 'BELIDA', 'BELIDA CRUDE OIL', 
         'RI', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BERYL', 'N', 'P', 'I', 'BERYL', 'BERYL CRUDE OIL', 
         'UK', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BIMA', 'N', 'P', 'I', 'BIMA', 'BIMA CRUDE OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BLENHEIM', 'N', 'P', 'I', 'BLENHEIM', 'BLENHEIM CRUDE OIL', 
         'UK', 'UNITED KINGDOM', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BONNYL', 'Y', 'P', 'A', 'BONNY LIGHT', 'BONNY LIGHT CRUDE OIL', 
         'WAN', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BONNYM', 'Y', 'P', 'A', 'BONNY MED', 'BONNY MEDIUM CRUDE OIL', 
         'WAN', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BOWRIVER', 'Y', 'P', 'A', 'BOW RIVER', 'BOW RIVER CRUDE OIL', 
         'CDN', 'CANADA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BRASS', 'Y', 'P', 'A', 'BRASS', 'BRASS RIVER CRUDE OIL', 
         'WAN', NULL, NULL, NULL, 'BBL', 'MT', 1)
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BRUNEI', 'Y', 'P', 'A', 'BRUNEI CONDENSA', 'BRUNEI CONDENSATE CRUDE OIL', 
         'BRU', 'BRUNEI', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BUNKERS', 'Y', 'P', 'A', 'BUNKERS', 'BUNKERS', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BUTANE', 'N', 'P', 'I', 'BUTANE', 'BUTANE', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CABIMAS', 'Y', 'P', 'A', 'CABIMAS', 'CABIMAS CRUDE OIL', 
         'YV', 'VENEZUELA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CABINDA', 'Y', 'P', 'A', 'CABINDA', 'CABINDA CRUDE OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CANADONS', 'Y', 'P', 'I', 'CANADON SECO', 'CANADON SECO CRUDE OIL', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CANOHVY', 'Y', 'P', 'I', 'CANO LIMON HVY', 'CANO LIMON HEAVY CRUDE OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CANOLIMO', 'Y', 'P', 'A', 'CANO LIMON', 'CANO LIMON CRUDE OIL', 
         'CO', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CAPTAIN', 'N', 'P', 'I', 'CAPTAIN', 'CAPTAIN CRUDE OIL', 
         'UK', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CARB', 'N', 'P', 'I', 'CARB', 'CARB', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CHALLIS', 'N', 'P', 'I', 'CHALLIS', 'CHALLIS CRUDE OIL', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CHUBUT', 'Y', 'P', 'I', 'CHUBUT', 'CHUBUT CRUDE OIL', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CINTA', 'Y', 'P', 'A', 'CINTA', 'CINTA CRUDE OIL', 'RI', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('COBAN', 'Y', 'P', 'I', 'COBAN', 'COBAN CRUDE OIL', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRAUS', 'Y', 'P', 'I', 'CURR-AUD', 'AUSTRALIAN DOLLAR', 
         'AUS', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRBEF', 'Y', 'P', 'I', 'CURR-BEF', 'BELGIAN FRANC', 
         'B', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRCAN', 'Y', 'P', 'I', 'CURR-CAD', 'CANADIAN DOLLAR', 
         'CDN', NULL, NULL, 1.000000, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRCHF', 'Y', 'P', 'I', 'CURR-CHF', 'SWISS FRANC', 
         'CH', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRDEM', 'Y', 'P', 'I', 'CURR-DEM', 'GERMAN DEUTSCHEMARK', 
         'BRD', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRDKK', 'Y', 'P', 'I', 'CURR-DKK', 'DANISH KRONER', 
         'DK', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRECU', 'Y', 'P', 'I', 'CURR-ECU', 'EUROPEAN CURRENCY UNIT', 
         'UNKNOWN', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRESP', 'Y', 'P', 'I', 'CURR-ESP', 'SPANISH PESETA', 'E', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRFRF', 'Y', 'P', 'A', 'CURR-FRF', 'FRENCH FRANC', 'F', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRGBP', 'Y', 'P', 'I', 'CURR-GBP', 'BRITISH POUND STERLING', 
         'GB', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRITL', 'Y', 'P', 'I', 'CURR-ITL', 'ITALIAN LIRA', 
         'I', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRJPY', 'Y', 'P', 'I', 'CURR-JPY', 'JAPANESE YEN', 
         'J', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRMYR', 'Y', 'P', 'I', 'CURR-MYR', 'MALAYSIAN RINGGIT', 'MAL', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id)   
  values('CURRNLG', 'Y', 'P', 'I', 'CURR-NLG', 'NETHERLAND GUILDER', 'NL', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRNOK', 'Y', 'P', 'I', 'CURR-NOK', 'NORWEIGIAN KRONER', 
         'N', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRSAR', 'Y', 'P', 'I', 'CURR-ZAR', 'SOUTH AFRICAN RAND', 
         'ZA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRSEK', 'Y', 'P', 'I', 'CURR-SEK', 'SWEDISH KRONER', 
         'S', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRSGD', 'Y', 'P', 'I', 'CURR-SGD', 'SINGAPORE DOLLAR', 
         'SGP', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRUSC', 'Y', 'P', 'I', 'CURR-USC', 'US CENTS', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRUSD', 'Y', 'P', 'A', 'CURR-USD', 'U.S. DOLLARS', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DAQING', 'Y', 'P', 'I', 'DAQING', 'DAQING CRUDE OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DATED', 'N', 'P', 'I', 'DATED BRENT', 'DATED BRENT', 
         'UK', NULL, NULL, NULL, 'BBL', 'MT', 1)
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DJENO', 'Y', 'P', 'A', 'DJENO', 'DJENO CRUDE OIL', 'RCB', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DM', 'Y', 'P', 'A', 'DEUTSHCE MARKS', 'DM GER', 'USA', 
         '11', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DOMSWEET', 'Y', 'P', 'I', 'DOMESTIC SWEET', 'DOMESTIC SWEET CRUDE OIL', 
         'USA', 'USA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DRAUGEN', 'Y', 'P', 'A', 'DRAUGEN', 'DRAUGEN CRUDE OIL', 
         'N', 'NORWAY', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DUB-DIST', 'N', 'P', 'N', 'DUBAI-DIST', 'DUBAI DISTILLATE GROUP', 
         'USA', 'DUBAI', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DUBAI', 'Y', 'P', 'A', 'DUBAI', 'DUBAI CRUDE OIL', 'USA', 
         'DUBAI', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DUC', 'N', 'P', 'I', 'DUC CRUDE OIL', 'DUC CRUDE OIL', 
         'DK', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DURI', 'N', 'P', 'I', 'DURI', 'DURI CRUDE OIL', 
         'RI', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DURWARD', 'N', 'P', 'I', 'DURWARD BLEND', 'DURWARD BLEND CRUDE OIL', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('E4F', 'Y', 'P', 'A', 'E4', 'E4 FEEDSTOCK', NULL, 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('EKOFISK', 'Y', 'P', 'A', 'EKOFISK', 'EKOFISK CRUDE OIL', 'N', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('EN228', 'N', 'P', 'I', 'UNL PREM EUROGR', 'UNLEADED PREMIUM EUROGRADE', 
         'UK', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('EOCENE', 'N', 'P', 'I', 'EOCENE', 'EOCENE CRUDE OIL', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ES SIDER', 'Y', 'P', 'A', 'ES SIDER', 'ES SIDER CRUDE OIL', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ESCALANT', 'Y', 'P', 'A', 'ESCALANTE', 'ESCALANTE CRUDE OIL', 
         'AR', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ESCRAVOS', 'Y', 'P', 'A', 'ESCRAVOS', 'ESCRAVOS CRUDE OIL', 
         'WAN', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ETHVY', 'Y', 'P', 'I', 'E TEXAS HVY', 'EAST TEXAS HEAVY CRUDE OIL', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ETSWT', 'Y', 'P', 'I', 'E TEX SWEET', 'EAST TEXAS SWEET', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('EUGENE', 'Y', 'P', 'I', 'EUGENE ISLAND', 'EUGENE ISLAND', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('EUREAP', 'Y', 'P', 'I', 'EUREAP', 'EUREA PRILLED', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('FIFE', 'Y', 'P', 'A', 'FIFE', 'FIFE CRUDE OIL', NULL, 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('FLOTTA', 'Y', 'P', 'A', 'FLOTTA', 'FLOTTA CRUDE OIL', 
         'UK', 'FLOTTA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('FORCADOS', 'Y', 'P', 'A', 'FORCADOS', 'FORCADOS CRUDE OIL', 
         'WAN', 'FORCADOS', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('FORTIES', 'Y', 'P', 'A', 'FORTIES', 'FORTIES CRUDE OIL', 
         'UK', 'HOUND POINT', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('FUELOIL', 'Y', 'P', 'A', 'FUEL OIL', 'FUEL OIL', 'UK', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('FULMAR', 'Y', 'P', 'A', 'FULMAR', 'FULMAR CRUDE OIL', 
         'UK', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('FURRIAL', 'Y', 'P', 'A', 'FURRIAL', 'FURRIAL CRUDE OIL', 
         'YV', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GALEOTA', 'N', 'P', 'I', 'GALEOTA CRUDE', 'GALEOTA CRUDE', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GAMBA', 'Y', 'P', 'A', 'GAMBA', 'GAMBA CRUDE OIL', 'GAB', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GASOIL', 'Y', 'P', 'A', 'GASOIL', 'GASOIL', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GASOIL1', 'Y', 'P', 'A', 'GASOIL 1', 'GASOIL 1', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GASOIL2', 'Y', 'P', 'A', 'GASOIL 0.2', 'GASOIL 0.2', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GASOIL3', 'Y', 'P', 'I', 'GASOIL .3', 'GASOIL .3', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GASOIL5', 'Y', 'P', 'A', 'GASOIL 0.5', 'GASOIL 0.5', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GASOILCR', 'Y', 'P', 'A', 'GASOIL CRACKED', 'GASOIL CRACKED', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GASOILIP', 'Y', 'P', 'I', 'GASOIL IPE', 'GASOIL IPE', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GASOILLP', 'Y', 'P', 'A', 'GASOIL LP', 'GASOIL LP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GASOILP', 'Y', 'P', 'A', 'GASOIL PAPER', 'GASOIL PAPER', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GASOILPR', 'Y', 'P', 'A', 'GASOIL PURE', 'GASOIL PURE', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GCLC', 'Y', 'P', 'I', 'GC LIGHT', 'GULF COAST LIGHT CRUDE', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GIPPS', 'Y', 'P', 'A', 'GIPPSLAND', 'GIPPSLAND CRUDE OIL', 
         'AUS', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GOIL590', 'Y', 'P', 'A', 'GASOIL EN590', 'GASOIL EN590', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GUAFITA', 'Y', 'P', 'A', 'GUAFITA', 'GUAFITA CRUDE OIL', 
          'YV', 'VENEZUELA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GULLFAKC', 'Y', 'P', 'A', 'GULLFAKS C', 'GULLFAKS C CRUDE OIL', 
         'N', 'NORWAY', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GULLFAKS', 'Y', 'P', 'A', 'GULLFAKS A', 'GULLFAKS A CRUDE OIL', 
         'N', 'NORWAY', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HANDIL', 'Y', 'P', 'I', 'HANDIL', 'HANDIL', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HARDING', 'Y', 'P', 'A', 'HARDING', 'HARDING CRUDE OIL', 
         'NL', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HELMBL', 'Y', 'P', 'A', 'HELM BLEND', 'HELM BLEND CRUDE OIL', 
         'UK', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HISC', 'Y', 'P', 'I', 'HIGH ISLAND', 'HIGH ISLAND SWEET CRUDE', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HLS', 'Y', 'P', 'I', 'HVY LA. SWEET', 'HEAVY LOUISIANA SWEET', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HO', 'Y', 'P', 'A', 'HEATING OIL', 'HEATING OIL NO.2', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HSFO180', 'Y', 'P', 'A', 'HSFO 180', 'HIGH SULPHUR FUEL OIL 180 CST', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HSFO380', 'Y', 'P', 'A', 'HSFO 380', 'HIGH SULPHUR FUEL OIL 380 CST', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HSRESID', 'Y', 'P', 'I', 'HS RESID', 'HIGH SULPHUR FUEL OIL RESIDUAL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id)
   values('HUDSON', 'Y', 'P', 'A', 'HUDSON', 'HUDSON CRUDE OIL', 
          'UK', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('IH/IL', 'Y', 'P', 'I', 'IRAN HEAVY/LIGH', 'IRAN HEAVY/IRAN LIGHT', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('IHSIDI', 'N', 'P', 'I', 'INACTIVE', 'IRAN HEAVY SIDI', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('IKANPARI', 'Y', 'P', 'A', 'IKAN PARI', 'IKAN PARI CRUDE OIL', 
         'RI', 'INDONESIA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('IRAN HVY', 'Y', 'P', 'A', 'IRAN HEAVY', 'IRAN HEAVY CRUDE OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('IRANLGHT', 'Y', 'P', 'A', 'IRAN LIGHT', 'IRAN LIGHT CRUDE OIL', 
         'IR', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ISTHMUS', 'N', 'P', 'I', 'ISTHMUS', 'ISTHMUS CRUDE OIL', 
         'MEX', 'MEXICO', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('JCOND', 'Y', 'P', 'A', 'J CONDENSATE', 'J CONDENSATE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('JABIRU', 'Y', 'P', 'A', 'JABIRU', 'JABIRU CRUDE OIL', 
         'AUS', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('JET', 'Y', 'P', 'A', 'JET FUEL', 'JET FUEL', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('JETA1', 'Y', 'P', 'A', 'JET A1', 'JET A1', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('JET/KE54', 'Y', 'P', 'A', 'JET/KERO 54', 'JET/KERO 54', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('K-M', 'Y', 'P', 'A', 'K-M', 'K-M', 'USA', NULL, 
         NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('K3-VGO', 'Y', 'P', 'A', 'K3-VGO', 'K3-VGO', NULL, NULL, 
         NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('KERN', 'Y', 'P', 'A', 'KERN RIVER', 'KERN RIVER CRUDE OIL', 
         'USA', 'CALIFORNIA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('KERO', 'Y', 'P', 'A', 'KEROSENE', 'KEROSENE', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('KIRKUK', 'N', 'P', 'I', 'KIRKUK', 'KIRKUK CRUDE OIL', 'IRG', 
         'IRAQ', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('KM', 'N', 'P', 'I', 'KM', 'KM', 'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('KOCHALB', 'Y', 'P', 'A', 'KOCH ALBERTA LT', 
         'KOCH ALBERTA LIGHT SOUR CRUDE OIL', 'CDN', 'CANADA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('KOLE', 'Y', 'P', 'I', 'KOLE', 'CAMEROON KOLE', 'TC', 
         'CAMEROON', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('KUWAIT', 'Y', 'P', 'A', 'KUWAIT', 'KUWAIT CRUDE OIL', 
         'KWT', 'KUWAIT', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LABUAN', 'Y', 'P', 'A', 'LABUAN', 'LABUAN CRUDE OIL', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LAGMEDRE', 'N', 'P', 'I', 'LAGOMEDIO RECON', 'LAGOMEDIO RECON', 
         'YV', 'VENEZUELA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LAGOMEDI', 'N', 'P', 'I', 'LAGOMEDIO', 'LAGOMEDIO CRUDE OIL', 
         'YV', 'VENEZUELA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LAGOTREC', 'N', 'P', 'I', 'LAGOTRECO LT', 'LAGOTRECO LIGHT', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LAGUNA', 'Y', 'P', 'A', 'LAGUNA', 'LAGUNA', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LALANG', 'Y', 'P', 'A', 'LALANG', 'LALANG CRUDE OIL', 'RI', 
         'INDONESIA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LCGASOIL', 'Y', 'P', 'A', 'LIGHT CYCLE GAS', 'LIGHT CYCLE GASOIL', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LEADED', 'N', 'P', 'I', 'LEADED PREMIUM', 'LEADED PREMIUM GASOLINE', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LEADMID', 'N', 'P', 'I', 'LEADED MIDGRADE', 'LEADED MIDGRADE GASOLINE', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LEADREG', 'N', 'P', 'I', 'LEADED REGULAR', 'LEADED REGULAR GASOLINE', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LEONA', 'N', 'P', 'I', 'LEONA', 'LEONA CRUDE OIL', 'YV', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LINE63', 'Y', 'P', 'I', 'LINE 63', 'LINE 63', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LIVBAYBL', 'N', 'P', 'I', 'LIVERPOOL BAY B', 
         'LIVERPOOL BAY BLEND CRUDE OIL', 'NL', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LLS', 'Y', 'P', 'A', 'LOUSIANA LIGHT', 'LOUISIANA LIGHT AND SWEET', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LOKELE', 'N', 'P', 'I', 'LOKELE', 'LOKELE', 'TC', 'CAMEROON', 
         NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LORETTO', 'Y', 'P', 'A', 'LORETTO', 'LORETO CRUDE OIL', 'PE', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LS NO2', 'N', 'P', 'I', 'LOW SULPHUR #2', 'LOW SULPHUR #2', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LSHEAT', 'Y', 'P', 'I', 'LS HEATING OIL', 'LOW SULPHUR HEATING OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LSJET', 'Y', 'P', 'I', 'LS JET/KERO', 'LOW SULFUR JET / KERO', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LSNO2', 'Y', 'P', 'I', 'NO2 LS HO', 'LOW SULFUR NO 2 FUEL', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LSWR', 'Y', 'P', 'A', 'LSWR', 'LOW SULFUR WAXY RESID', NULL, 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LUCINA', 'Y', 'P', 'I', 'LUCINA', 'LUCINA', NULL, 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('M100', 'Y', 'P', 'A', 'M100', 'MAZOUT 100', 'CIS', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MANDJI', 'Y', 'P', 'A', 'MANDJI', 'MANDJI CRUDE OIL', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MARIBLT', 'Y', 'P', 'A', 'MARIB LIGHT', 'MARIB LIGHT CRUDE OIL', 
         'SA', 'RAS ISA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MASILA', 'Y', 'P', 'A', 'MASILA', 'MASILA BLEND CRUDE OIL', 
         'ADN', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MAUREEN', 'Y', 'P', 'A', 'MAUREEN', 'MAUREEN CRUDE OIL', 
         'UK', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MAYA', 'N', 'P', 'I', 'MAYA', 'MAYA CRUDE OIL', 'MEX', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MAYAISTH', 'Y', 'P', 'N', 'MAYA ISTHMUS BL', 'MAYA ISTHMUS BLEND', 
         'MEX', 'MEXICO', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MBYA', 'Y', 'P', 'I', 'M''BYA', 'M''BYA', NULL, NULL, 
         NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MC250', 'N', 'P', 'I', 'ASPHALT MC 250', 'ASPHALT MC250', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MEDANIT', 'Y', 'P', 'I', 'MEDANITO', 'MEDANITO', 'AR', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MENEMOTA', 'Y', 'P', 'A', 'MENEMOTA', 'MENEMOTA CRUDE OIL', 
         'YV', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MEREY', 'Y', 'P', 'A', 'MEREY', 'MEREY CRUDE OIL', 
         'YV', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MESA', 'N', 'P', 'I', 'MESA', 'MESA CRUDE OIL', 'YV', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MINAS', 'Y', 'P', 'I', 'MINAS', 'MINAS', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MIRI', 'Y', 'P', 'I', 'MIRI', 'MIRI', NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MOGAS15', 'Y', 'P', 'I', 'MOGAS .15', 'MOGAS .15', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MOGASUNL', 'N', 'P', 'I', 'MOGAS UNL', 'MOGAS UNLEADED', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MOLONGO', 'Y', 'P', 'A', 'MOLONGO', 'MOLONGO CRUDE OIL', 
         'ANG', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MPC', 'Y', 'P', 'A', 'MARS BLEND', 'MARS PACIDIAN CRUDE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MSFO18', 'Y', 'P', 'A', 'MSFO1.8', 'MEDIUM SULPHER FUEL OIL 1.8%', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MTBE', 'N', 'P', 'I', 'MTBE', 'MTBE', 'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MUBAREK', 'Y', 'P', 'A', 'MUBAREK', 'MUBAREK CRUDE OIL', 
         'UAE', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MURBAN', 'Y', 'P', 'A', 'MURBAN', 'U.A.E. MURBAN CRUDE OIL', 
         'UAE', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('N-BUTANE', 'N', 'P', 'I', 'NORMAL BUTANE', 'NORMAL BUTANE', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NANHAILT', 'N', 'P', 'I', 'NANHAI LIGHT', 'NANHAI LIGHT CRUDE OIL', 
         'PRC', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NAPHTHA', 'Y', 'P', 'A', 'NAPHTHA', 'NAPHTHA', NULL, 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NATGAS', 'Y', 'P', 'A', 'NATURAL GAS', 'NATURAL GAS', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NEMBA', 'Y', 'P', 'A', 'NEMBA', 'NEMBA', 
        'ANG', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NEUTRALZ', 'Y', 'P', 'A', 'NEUTRAL ZONE MI', 
         'NEUTRAL ZONE MIX CRUDE OIL', 'KWT', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NIGERIAN', 'Y', 'P', 'I', 'NIGERIAN CRUDES', 'NIGERIAN CRUDE OILS', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NINIAN', 'Y', 'P', 'A', 'NINIAN', 'NINIAN CRUDE OIL', 'UK', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO2', 'Y', 'P', 'A', 'NO. 2', 'NO. 2', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-03HI', 'Y', 'P', 'A', 'LSFO .3% HI PR', '.3 PERCENT LOW SULFUR FUEL OIL HIGH POUR', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-03LO', 'Y', 'P', 'A', 'LSFO .3% LO PR', '.3 PERCENT LOW SULFUR FUEL OIL LOW POUR', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-03MX', 'Y', 'P', 'I', 'FO.3%', 'NO 6 .3% S MAX', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-05', 'Y', 'P', 'A', 'LSFO .5%', '.5 PERCENT LOW SULFUR FUEL OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-07', 'Y', 'P', 'A', 'LSFO .7%', '.7 PERCENT LOW SULFUR FUEL OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-10', 'Y', 'P', 'A', 'LSFO 1%', '1 PERCENT LOW SULFUR FUEL OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-16', 'Y', 'P', 'I', 'LSFO 1.6%', '1.6% LOW SULFUR FUEL OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-20', 'Y', 'P', 'A', 'HSFO 2%', '2 PERCENT FUEL OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-22', 'Y', 'P', 'A', 'HSFO 2.2 %', '2.2 PERCENT FUEL OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-28', 'Y', 'P', 'A', 'HSFO 2.8%', '2.8 PERCENT FUEL OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-29', 'Y', 'P', 'I', 'HSFO 2.9%', '2.9 PERCENT HIGH SULFUR FUEL OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-30', 'Y', 'P', 'A', 'HSFO 3%', 'NO 6 3 PERCENT FUEL OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6-35', 'Y', 'P', 'A', 'HSFO 3.5%', '3.5 PERCENT FUEL OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6HSCR', 'Y', 'P', 'I', 'HSFO CRACKED', 'HIGH SULPHUR FUEL OIL CRACKED', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6HSSR', 'Y', 'P', 'I', 'HSFO STRAIGHT', 'HIGH SULFUR FUEL OIL STRAIGHT RUN', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6LSCR', 'Y', 'P', 'I', 'LSFO CRACKED', 'LOW SULFUR FUEL OIL CRACKED', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NO6LSSR', 'Y', 'P', 'A', 'LSFO STRAIGHT', 'LOW SULFUR FUEL OIL STRAIGHT RUN', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NORNE', 'N', 'P', 'I', 'NORNE', 'NORNE CRUDE OIL', 'N', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NTS', 'N', 'P', 'I', 'N TEX SOUR', 'NORTH TEXAS SOUR', NULL, 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NWSHELFC', 'Y', 'P', 'A', 'N W SHELF CONDE', 
         'NORTH WEST SHELF CONDENSATE CRUDE OIL', 'AUS', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ODUDU', 'N', 'P', 'I', 'ODUDU', 'ODUDU CRUDE OIL', 'WAN', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('OGUENDJO', 'N', 'P', 'I', 'OGUENDJO', 'OGUENDJO', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('OKSWT', 'Y', 'P', 'I', 'OKLAHOMA SWEET', 'OKLAHOMA SWEET', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('OLMECA', 'Y', 'P', 'A', 'OLMECA', 'OLMECA CRUDE OIL', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('OMAN', 'Y', 'P', 'A', 'OMAN', 'OMAN CRUDE OIL', 
         'OM', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('OMANMPM', 'N', 'P', 'I', 'OMAN ''MPM''', 'OMAN ''MPM''', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ORIENTE', 'N', 'P', 'I', 'ORIENTE', 'ORIENTE CRUDE OIL', 
         'EC', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ORITO', 'Y', 'P', 'A', 'ORITO', 'ORITO CRUDE OIL', 'CO', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('OSEBERG', 'Y', 'P', 'A', 'OSEBERG', 'OSEBERG CRUDE OIL', 'N', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('OSO', 'N', 'P', 'I', 'OSO CONDENSATE', 'OSO CONDENSATE', 'WAN', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PALANCA', 'Y', 'P', 'A', 'PALANCA', 'PALANCA CRUDE OIL', 'ANG', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PEN60/70', 'N', 'P', 'I', 'ASPHALT 60/70', 'ASPHALT PEN 60/70', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PENN', 'Y', 'P', 'A', 'PENNINGTON', 'PENNINGTON CRUDE OIL', 
         'WAN', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PILON', 'Y', 'P', 'A', 'PILON', 'PILON CRUDE OIL', 'YV', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PN85/100', 'N', 'P', 'I', 'ASPHALT 85/100', 'ASPHALT 85/100', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PR/LEAD', 'N', 'P', 'I', 'PROD. LEADED', 'PRODUCTION LEADED MOTOR GASOLINE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PR/ULEAD', 'N', 'P', 'I', 'PROD. UNLEADED', 'PRODUCTION UNLEADED MOTOR GASOLINE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go



insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PREM15', 'N', 'P', 'I', 'MOGAS .15G', 'MOGAS .15 GRAMS PER LITER', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PREM25', 'Y', 'P', 'I', 'MOGAS .25G', 'PREMIUM MOGAS .25 GRAMS PER LITER', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PROPANE', 'N', 'P', 'I', 'PROPANE', 'PROPANE', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('QTDUKHAN', 'Y', 'P', 'I', 'QATAR DUKHAN', 'QATAR DUKHAN CRUDE OIL', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('QTMARINE', 'Y', 'P', 'A', 'QATAR MARINE', 'QATAR MARINE CRUDE OIL', 
         'SWA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('QUAIBOE', 'Y', 'P', 'A', 'QUA IBOE', 'QUA IBOE CRUDE OIL', 
         'WAN', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('RABI', 'Y', 'P', 'A', 'RABI LIGHT', 'RABI LIGHT CRUDE OIL', 
         'GAB', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('RASGHARI', 'Y', 'P', 'A', 'RAS GHARIB', 'RAS GHARIB CRUDE OIL', 
         'ET', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('RATAWI', 'N', 'P', 'I', 'RATAWI', 'RATAWI CRUDE OIL', 'KWT', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('RBOB', 'N', 'P', 'A', 'RBOB', 'RBOB', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('RC250', 'N', 'P', 'I', 'ASPHALT RC 250', 'ASPHALT RC 250', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('RME25', 'Y', 'P', 'N', 'RME25', 'RME25', NULL, 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('RMG35', 'Y', 'P', 'A', 'RMG35', 'RMG35', 'UK', 
         'ROTTERDAM', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('RMG35RFY', 'Y', 'P', 'A', 'RMG35REFY', 
         'RMG 35 REFINERY', 'UK', 'ROTTERDAM', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SAHARA', 'Y', 'P', 'I', 'SAHARA', 'SAHARA', NULL, NULL, 
         NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SAHARABL', 'Y', 'P', 'A', 'SAHARAN BLEND', 'SAHARAN BLEND CRUDE OIL', 
         'DZ', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SALADIN', 'Y', 'P', 'A', 'SALADIN', 'SALADIN CRUDE OIL', 'AUS', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SANTABAR', 'N', 'P', 'I', 'SANTA BARBARA', 'SANTA BARBARA CRUDE OIL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SARIR', 'Y', 'P', 'A', 'SARIR', 'SARIR CRUDE OIL', 'LAR', 
          NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SEMBILAN', 'N', 'P', 'I', 'SEMBILANG', 'SEMBILANG CRUDE OIL', 
         'RI', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SEME', 'Y', 'P', 'I', 'SEME', 'SEME', NULL, NULL, 
         NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SERIA', 'Y', 'P', 'A', 'SERIA LIGHT EX', 'SERIA LIGHT EXPORT BLEND CRUDE OIL', 
         'BRU', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SHENGLI', 'Y', 'P', 'I', 'SHENGLI', 'SHENGLI', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SIBLITE', 'Y', 'P', 'I', 'SIBLITE', 'SIBERIAN LIGHT', 
         'SU', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SLR', 'Y', 'P', 'I', 'S LOUISIANA', 'SOUTH LOUISIANA REGULAR CRUDE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SOUEDIE', 'N', 'P', 'I', 'SOUEDIE', 'SOUEDIE CRUDE OIL', 
         'SYR', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SOUTHBLE', 'Y', 'P', 'A', 'SOUTH BLEND', 'SOUTH BLEND CRUDE OIL', 
         'CO', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SOVIETEX', 'Y', 'P', 'A', 'SOVIET EXPORT B', 'SOVIET EXPORT BLEND CRUDE OIL', 
         'SU', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SOYO', 'Y', 'P', 'A', 'SOYO', 'SOYO CRUDE OIL', 'ANG', 'ANGOLA', 
         NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SPRAYTEX', 'N', 'P', 'I', 'SPRAYTEX', 'SPRAYTEX', NULL, NULL, 
         NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('STAT', 'Y', 'P', 'A', 'STATFJORD', 'STATFJORD CRUDE OIL', 'N', 
         'STATFJORD', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('STS', 'Y', 'P', 'I', 'S.TX SOUR', 'SOUTH TEXAS SOUR', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('STSWT', 'Y', 'P', 'I', 'S TX SWEET', 'SOUTH TEXAS SWEET', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SUEZBLND', 'Y', 'P', 'A', 'SUEZ BLEND', 'GULF OF SUEZ BLEND CRUDE OIL', 
         'ET', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SUMATRAL', 'Y', 'P', 'A', 'SUMATRAN LIGHT', 'SUMATRAN LIGHT CRUDE OIL', 
         'RI', 'INDONESIA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SYB', 'Y', 'P', 'A', 'SYRIAN LIGHT', 'SYRIAN LIGHT', 'SYR', 
         'SYRIA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('TAKULA', 'Y', 'P', 'A', 'TAKULA', 'TAKULA CRUDE OIL', 'DZ', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('TAPIS', 'Y', 'P', 'A', 'TAPIS', 'TAPIS CRUDE OIL', 'MAL', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('THEVENAR', 'N', 'P', 'I', 'THEVENARD', 'THEVENARD CRUDE OIL', 
         'AUS', 'AUSTRALIA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('THUMS', 'Y', 'P', 'I', 'THUMS', 'THUMS', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UDANG', 'Y', 'P', 'A', 'UDANG', 'UDANG CRUDE OIL', 'RI', 
         'INDONESIA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UL87A4', 'Y', 'P', 'I', 'UNL87 A4', 'UNLEADED 87 RFG A4 GASOLINE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UL87A5', 'Y', 'P', 'I', 'UNL87 A5', 'UNLEADED 87 RFG A5 GASOLINE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UL87A8', 'Y', 'P', 'I', 'UNL87 A8 OXY', 'UNLEADED 87 RFG A8 OXY GASOLINE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UL87A9', 'Y', 'P', 'I', 'UNL87 A9 OXY', 'UNLEADED 87 RFG A9 OXY GASOLINE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UL93D9', 'Y', 'P', 'I', 'UNL93 D9 OXY', 'UNLEADED 93 RFG D9 OXY GASOLINE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UMSHAIF', 'Y', 'P', 'I', 'UMM SHAIF', 'UMM SHAIF CRUDE OIL', 
         'ABD', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNL87', 'Y', 'P', 'A', 'UNL 87 REGULAR', 'UNLEADED REGULAR GASOLINE', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNL87/O', 'N', 'P', 'I', 'UNL REGULAR OXY', 'UNLEADED REGULAR OXYGENATED', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNL89', 'N', 'P', 'I', 'UNL 89 MIDGRADE', 'UNLEADED MID-GRADE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNL89/O', 'N', 'P', 'I', 'UNL MIDGRAD OXY', 'UNLEADED MID-GRADE OXYGENATED', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNL92', 'Y', 'P', 'A', 'UNL PREMIUM', 'UNLEADED PREMIUM', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNL92/O', 'N', 'P', 'I', 'UNL PREMIUM OXY', 'UNLEADED PREMIUM OXYGENATED', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNL93', 'N', 'P', 'I', 'UNL SUPER PREM', 'UNLEADED SUPER PREMIUM', 
         'UK', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNL93/O', 'Y', 'P', 'I', 'UNL SUPER OXY', 'UNLEADED SUPER OXYGENATED', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNL93D5', 'Y', 'P', 'I', 'UNL93 D5', 'UNLEADED 93 RFG D5 GASOLINE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLM115', 'Y', 'P', 'I', 'UNL M 11.5 RVP', 'UNLEADED MID-GRADE 11.5 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLM135', 'Y', 'P', 'I', 'UNL M 13.5 RVP', 'UNLEADED MID-GRADE 13.5', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLM15', 'Y', 'P', 'I', 'UNL M 15.. RVP', 'UNLEADED MID-GRADE 15 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLM78', 'Y', 'P', 'I', 'UNL M7.5-7.8RVP', 'UNLEADED MID GRADE 7.5-7.8 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLM9', 'Y', 'P', 'A', 'UNL MID 9 RVP', 'UNLEADED MID-GRADE 9.0 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLMO115', 'Y', 'P', 'I', 'UNL MOXY11.5RVP', 'UNLEADED MID-GRADE OXYGENATED 11.5 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLMO135', 'Y', 'P', 'I', 'UNL MOXY13.5RVP', 'UNLEADED MID-GRADE 13.5 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLMO15', 'Y', 'P', 'I', 'UNL M OXY 15RVP', 'UNLEADED MID-GRADE OXYGENATED 15 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLMO78', 'Y', 'P', 'I', 'UNL MOXY7.5-7.8', 'UNLEADED MID-GRADE OXYGENATED 7.5/7.8 RV', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLMO9', 'Y', 'P', 'I', 'UNL M OXY 9 RVP', 'UNLEADED MID-GRADE OXYGENATED 9 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLP115', 'Y', 'P', 'I', 'UNL P 11.5 RVP', 'UNLEADED PREMIUM 11.5 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLP135', 'Y', 'P', 'I', 'UNL P 13.5 RVP', 'UNLEADED PREMIUM 13.5 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLP15', 'Y', 'P', 'I', 'UNL P 15.. RVP', 'UNLEADED PREMIUM 15 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLP78', 'Y', 'P', 'I', 'UNL P7.5-7.8RVP', 'UNLEADED PREMIUM 7.5-7.8 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLP87/9', 'N', 'P', 'I', 'UNL PREM 9 RVP', 'UNLEADED PREMIUM 9.0 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLPO115', 'Y', 'P', 'I', 'UNL POXY11.5RVP', 'UNLEADED PREMIUM OXYGENATED 11.5 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLPO135', 'Y', 'P', 'I', 'UNL POXY13.5RVP', 'UNLEADED PREMIUM OXYGENATED 13.5 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLPO15', 'Y', 'P', 'I', 'UNL P OXY 15RVP', 'UNLEADED PREMIUM OXYGENATED 15 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLPO78', 'Y', 'P', 'I', 'UNL POXY7.5-7.8', 'UNLEADED PREMIUM OXYGENATED 7.5-7.8 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLPO9', 'Y', 'P', 'I', 'UNL P OXY 9 RVP', 'UNLEADED PREMIUM OXYGENATED 9 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLR115', 'Y', 'P', 'I', 'UNL R 11.5 RVP', 'UNLEADED REGULAR 11.5 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLR135', 'Y', 'P', 'I', 'UNL R 13.5 RVP', 'UNLEADED REGULAR 13.5 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLR15', 'Y', 'P', 'I', 'UNL R 15.. RVP', 'UNLEADED REGULAR 15 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLR47', 'Y', 'P', 'I', 'UNL REGULAR(47)', 'UNLEADED REGULAR 47 GRADE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLR4748', 'Y', 'P', 'I', 'UNL REG (47/48)', 'UNLEADED REGULAR 47/48 GRADE', 
        'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLR48', 'Y', 'P', 'I', 'UNL REGULAR(48)', 'UNLEADED REGULAR 48 GRADE', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLR78', 'Y', 'P', 'I', 'UNL R7.5-7.8RVP', 'UNLEADED REGULAR 7.5-7.8 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLR9', 'N', 'P', 'I', 'UNL REG 9 RVP', 'UNLEADED REGULAR 9.0 RVP',
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLRO115', 'Y', 'P', 'I', 'UNL ROXY11.5RVP', 'UNLEADED REGULAR OXYGENATED 11.5 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLRO135', 'Y', 'P', 'I', 'UNL ROXY13.5RVP', 'UNLEADED REGULAR OXYGENATED 13.5 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLRO15', 'Y', 'P', 'I', 'UNL R OXY 15RVP', 'UNLEADED REGULAR OXYGENATED 15', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLRO78', 'Y', 'P', 'I', 'UNL ROXY7.5-7.8', 'UNLEADED REGULAR OXYGENATED 7.5/7.8 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLRO9', 'Y', 'P', 'I', 'UNL R OXY 9 RVP', 'UNLEADED REGULAR OXYGENATED 9 RVP', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLS115', 'Y', 'P', 'I', 'UNL S 11.5 RVP', 'UNLEADED SUPER 11.5 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLS135', 'Y', 'P', 'I', 'UNL S 13.5 RVP', 'UNLEADED SUPER 13.5 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLS15', 'Y', 'P', 'I', 'UNL S 15.. RVP', 'UNLEADED SUPER 15 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLS78', 'Y', 'P', 'I', 'UNL S7.5-7.8RVP', 'UNLEADED SUPER 7.5-7.8 RVP', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UNLS9', 'Y', 'P', 'I', 'UNL S(27) 8.7-9', 'UNLEADED SUPER 8.7-9.0 RVP 27 GRADE', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('URAL', 'Y', 'P', 'A', 'URALS', 'URALS CRUDE OIL', 'RU', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('USD_EX', 'Y', 'P', 'N', 'USD_EX', 'USD COMMODITY', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('VGO', 'N', 'P', 'I', 'VGO HS DIFF', 'VACUUM GASOIL HIGH SULPHUR DIFFERENTIAL', 
         'USA', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('VGO5', 'N', 'P', 'I', 'VGO LS DIFF', 'VACUM GASOIL LS DIFFERENTIAL', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('VGOHS', 'Y', 'P', 'A', 'VACUUM GAS HS', 'VACUUM GAS HIGH SULFUR', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('VGOLS', 'Y', 'P', 'A', 'VACUUM GAS LS', 'VACUUM GASOIL LOW SULFUR', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('WCHVY22', 'Y', 'P', 'I', 'WC HEAVY 22', 'WEST COAST HEAVY-22', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('WTI', 'Y', 'P', 'A', 'WTI', 'WEST TEXAS INTERMEDIATE (DOMESTIC SWEET)', 
         'USA', 'TEXAS', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('WTI-HO', 'Y', 'P', 'A', 'WTI-HEAT', 'WTI-HEATING OIL CRACK', 
         'USA', 'TEXAS', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('WTIPLUS', 'N', 'P', 'A', 'WTI PLUS', 'WEST TEXAS PLUS', 'USA', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('WTS', 'Y', 'P', 'A', 'WTS', 'WEST TEXAS SOUR CRUDE OIL', 
         'USA', 'TEXAS', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('WYOSWEET', 'Y', 'P', 'I', 'WYO SWEET', 'WYOMING SWEET', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ZAAFARAN', 'Y', 'P', 'I', 'ZAAFARAN', 'ZAAFARANA', 'ET', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ZAFIRO', 'Y', 'P', 'I', 'ZAFIRO', 'ZAFIRO CRUDE OIL WEST AFRICA', 
         NULL, NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ZAIRE', 'Y', 'P', 'A', 'ZAIRE', 'ZAIRE CRUDE OIL', 
         'ZR', NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ZAKUMLOW', 'Y', 'P', 'A', 'ZAKUM LOWER', 'LOWER ZAKUM CRUDE OIL', 
         'UAE', NULL, NULL, NULL, 'BBL', 'MT', 1)
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ZARZ', 'Y', 'P', 'A', 'ZARZAITINE', 'ZARZAITINE CRUDE OIL', 
         'TN', 'TUNISIA', NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ZEIT', 'Y', 'P', 'A', 'ZEIT BAY', 'ZEIT BAY CRUDE OIL', 'ET', 
         NULL, NULL, NULL, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ZUEITINA', 'Y', 'P', 'A', 'ZUEITINA', 'ZUEITINA CRUDE OIL', 
         'LAR', NULL, NULL, NULL, 'BBL', 'MT', 1)
go


/* ************************************************************ */
/* cmdty type = 'G' (commodity group)                           */
/* ************************************************************ */

print 'Loading commodity group data ...'
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('VGOGROUP', 'N', 'G', 'I', 'VGO GROUP', 'VGO GROUP', 'USA', 
         NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SGPGROUP', 'N', 'G', 'N', 'SGPGROUP', 'SINGAPORE SWAP GROUP', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('RESGRP', 'N', 'G', 'A', 'RESGRP', 'RESGRP', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CRUDE', 'N', 'G', 'A', 'CRUDE GROUP', 'CRUDE', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HEATOIL', 'N', 'G', 'I', 'HO GROUP', 'NO.2 HO GROUP', NULL, 
         NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CURRGRP', 'N', 'G', 'I', 'CURRENCIES', 'CURRENCIES', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DOMCRUDE', 'N', 'G', 'I', 'DOM CRUDE GROUP', 'DOMESTIC CRUDE OIL', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('FGNCRUDE', 'N', 'G', 'I', 'FOREIGN CRUDE', 'FOREIGN CRUDE GROUP(except BRENT/DUBAI)', 
         NULL, 'NON-DOMESTIC', NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('FUEL', 'N', 'G', 'I', 'FUEL OIL GROUP', 'FUEL OIL GROUP', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GASOILGR', 'N', 'G', 'I', 'GASOIL GROUP', 'GASOIL GROUP', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GASOLINE', 'N', 'G', 'I', 'GASOLINE GROUP', 'GASOLINE GROUP', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HOGROUP', 'N', 'G', 'I', 'HO GROUP', 'NO.2 HEATING OIL GROUP', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PRDGROUP', 'N', 'G', 'A', 'PRD GROUP', 'PRD GROUP', NULL, 
         NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PRODUCT', 'N', 'G', 'A', 'PRODUCT GROUP', 'PRODUCT GROUP', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PRODUCTS', 'N', 'G', 'A', 'PRODUCTS GROUP', 'REFINED PRODUCTS GROUP', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

/* ************************************************************ */
/* cmdty type = 'C' (Currency)                                  */
/* ************************************************************ */

print 'Loading currency data ...'
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ZAR', 'N', 'C', 'A', 'ZAR', 'SOUTH AFRICAN RAND', 'ZA', 
         'SOUTH AFRICA', 'ZAR', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('WGC', 'N', 'C', 'A', 'DEUTSCHE MARK', 'GERMAN DEUTSCHEMARK', 
         'DDR', NULL, 'WGC', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SFR', 'N', 'C', 'N', 'SWISS FRANC', 'SWISS FRANC', 'S', 
         NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SGD', 'N', 'C', 'A', 'SINGAPORE DLR', 'SINGAPORE DOLLAR', 
         'SGP', NULL, 'SGD', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CAC', 'N', 'C', 'A', 'CANADIAN DLR', 'CANADIAN DOLLAR', 
         'USA', NULL, 'CAC', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ATS', 'N', 'C', 'A', 'AUSSHIL', 'AUSTRIAN SCHILLINGS', 'AL', 
         NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BEF', 'N', 'C', 'A', 'BELGIAN FRANC', 'BELGIAN FRANC', 
         'B', NULL, 'BEF', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BFR', 'N', 'C', 'N', 'BELGIAN FRANC', 'BELGIAN FRANC', 
         'B', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DANKRN', 'Y', 'C', 'A', 'DANKRN', 'DANISH KRONER', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DEM', 'N', 'C', 'A', 'GERMAN DEUTSCHE', 'GERMAN DEUTSCHE MARK', 
         'BRD', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ESP', 'N', 'C', 'A', 'SPANISH PESETA', 'SPANISH PESETA', 
         'E', NULL, 'ESP', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('EURODLR', 'N', 'C', 'A', 'EURODOLLAR', 'EURODOLLAR', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('FFR', 'N', 'C', 'A', 'FRENCH FRANC', 'FRENCH FRANC', 
         'F', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GBP', 'N', 'C', 'A', 'POUND STERLING', 'POUND STERLING', 
         'UK', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('IEP', 'N', 'C', 'A', 'IREPOUND', 'IRISH POUND', 
         'IRL', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ITL', 'N', 'C', 'A', 'ITALIAN LIRA', 'ITALIAN LIRA', 
         'I', NULL, 'ITL', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('JAC', 'N', 'C', 'A', 'JAPANESE YEN', 'JAPANESE YEN', 'USA', 
         NULL, 'JAC', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MYR', 'N', 'C', 'A', 'MALAY RINGGIT', 'MALAYSIAN RINGGIT', 'MAL', 
         NULL, 'MYR', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('NLG', 'N', 'C', 'A', 'DUTCH GUILDER', 'DUTCH GUILDER', 
         'NL', NULL, 'NLG', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id)
   values('NOK', 'N', 'C', 'A', 'NORWEIGIAN KRON', 'NORWEIGIAN KRONER', 
          'N', NULL, 'NOK', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PESO', 'N', 'C', 'A', 'PESO', 'MEXICAN PESO', 'MEX', NULL, 
         'PESO', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PTE', 'N', 'C', 'N', 'PORESC', 'PORTUGAL ESCUDO', 'P', 
         NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SEK', 'N', 'C', 'A', 'SWEDISH KRONER', 'SWEDISH KRONER', 
         'S', NULL, 'SEK', 1.000000, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('UKC', 'N', 'C', 'A', 'GBP', 'POUND STERLING', 'UK', NULL, 
         'UKC', 1.000000, 'BBL', 'MT', 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('USC', 'N', 'C', 'A', 'USC', 'US CENT', 'USA', NULL, 
         'USD', 100.000000, NULL, NULL, 1)
go

/* ************************************************************ */
/* cmdty type = 'O' (Others)                                    */
/* ************************************************************ */

print 'Loading other type of commodity data ...'
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MILEAGE', 'N', 'O', 'A', 'MILEAGE', 'MILEAGE', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go


insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('WRTOFF', 'N', 'O', 'A', 'WRTOFFSTTL', 'WRITEOFF SETTLEMENT', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('VAT', 'N', 'O', 'A', 'VAT', 'Value Added Tax', 'USA', 
         NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('TRANS', 'N', 'O', 'A', 'TRANSACTION FEE', 'TRANSACTION FEE', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('ACCRUAL', 'N', 'O', 'A', 'ACCRUAL', 'ACCRUAL', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BANK', 'N', 'O', 'I', 'BANK CHARGES', 'BANK CHARGES', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BARTOLLS', 'N', 'O', 'A', 'BAR TOLLS', 'BAR TOLLS', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CUST DEC', 'N', 'O', 'I', 'CUSTOM DECLAR', 'CUSTOM DECLARATION', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('BROKERFE', 'N', 'O', 'A', 'BROKER FEE', 'BROKER FEE', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('CARRYCHG', 'N', 'O', 'I', 'CARRYING CHGS', 'CARRYING CHARGES', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DEADFRT', 'N', 'O', 'A', 'DEAD FREIGHT', 'DEAD FREIGHT', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DEMUR', 'N', 'O', 'A', 'DEMURRAGE', 'DEMURRAGE', 'USA', NULL, 
         NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('COMMISS', 'N', 'O', 'A', 'COMMISSION', 'COMMISSION', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HAULING', 'N', 'O', 'A', 'HAULING', 'HAULING', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('DUTY', 'N', 'O', 'N', 'DUTY', 'DUTY', 'USA', 
         NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('FREIGHT', 'N', 'O', 'A', 'FREIGHT', 'FREIGHT', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('FRT-T', 'N', 'O', 'I', 'FREIGHT - TRUCK', 'FREIGHT - TRUCK', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('GRAVITY', 'N', 'O', 'A', 'GRAVITY ADJUSTM', 'GRAVITY ADJUSTMENT', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('HARBORDU', 'N', 'O', 'A', 'HARBOR DUES', 'HARBOR DUES', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('IMPORTFE', 'N', 'O', 'A', 'IMPORTATION FEE', 'IMPORTATION FEE', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('INSPECT', 'N', 'O', 'A', 'INSPECTION FEE', 'INSPECTION FED', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('INSUR', 'N', 'O', 'A', 'INSURANCE', 'INSURANCE', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('INTCOTRA', 'N', 'O', 'N', 'INTERCOMPANY TR', 'INTERCOMPANY TRANSFER', 
         'UK', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('INTEREST', 'N', 'O', 'A', 'INTEREST', 'INTEREST', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('INTRANSI', 'N', 'O', 'A', 'INTRANSIT LOSS', 'INTRANSIT LOSS', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('JVCOST', 'N', 'O', 'A', 'JV COST', 'JOINT VENTURE COST', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LEG&PROF', 'N', 'O', 'N', 'LEGAL & PROFESS', 'LEGAL & PROFESSIONAL', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LEG_ADJ', 'N', 'O', 'A', 'LEGACY P/L ADJ', 'LEGACY P/L ADJUSTMENT', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('LOCOMOT', 'N', 'O', 'A', 'LOCOMOTIVE', 'LOCOMOTIVE', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MARINEFE', 'N', 'O', 'A', 'MARINE FEE', 'MARINE FEE', 'USA', 
         NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MARINVET', 'N', 'O', 'A', 'MARINE VETTING', 'MARINE VETTING', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('MISCCHRG', 'N', 'O', 'A', 'MISCELLANEOUS C', 'MISCELLANEOUS CHARGE', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('OPTEXER', 'N', 'O', 'N', 'OPTIONEXERCISE', 'OPTIONEXERCISE', 
         NULL, NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PIPELINE', 'N', 'O', 'A', 'PIPELINE CHARGE', 'PIPELINE CHARGES', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PREXCISE', 'N', 'O', 'A', 'PREXCISE', 'PUERTO RICO EXCISE TAX', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('PROCSFEE', 'N', 'O', 'A', 'PROCESSING FEE', 'PROCESSING FEE', 'USA', 
         NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('SERVICEF', 'N', 'O', 'A', 'SERVICE FEE', 'SERVICE FEE', 'USA', 
         NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('STORAGE', 'N', 'O', 'A', 'STORAGE COST', 'STORAGE COST', 
         'USA', NULL, NULL, NULL, NULL, NULL, 1)
go

/* ************************************************************ */
/* cmdty type = 'I'  (Interest rate)                            */
/* ************************************************************ */

print 'Loading interest rate data ...'
go

insert into commodity (
  cmdty_code,cmdty_tradeable_ind,cmdty_type,cmdty_status, 
  cmdty_short_name,cmdty_full_name,country_code,cmdty_loc_desc, 
  prim_curr_code,prim_curr_conv_rate, prim_uom_code,sec_uom_code,trans_id) 
  values('USDINT', 'Y', 'I', 'A', 'USDOLLAR', 'US DOLLAR INTEREST RATES', 
         'USA', 'USA', NULL, NULL, NULL, NULL, 1)
go
