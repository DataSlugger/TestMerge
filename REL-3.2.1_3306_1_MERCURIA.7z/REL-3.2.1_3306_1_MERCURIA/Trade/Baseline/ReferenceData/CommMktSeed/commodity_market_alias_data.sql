print ' '
print 'Loading additional seed data into the commodity_market_alias table ...'
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(1, 'BSI', 'U', 'CL', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(1, 'PS1', 'U', 'XNCL', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(4, 'BSI', 'U', 'HU', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(4, 'PS1', 'U', 'XNHU', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(5, 'BSI', 'U', 'HO', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(5, 'PS1', 'U', 'XNHO', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(213, 'BSI', 'U', 'IC', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(213, 'PS1', 'U', 'XILL', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(215, 'BSI', 'U', 'IG', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(215, 'PS1', 'U', 'XILO', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(1562, 'BSI', 'U', 'GA', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(1562, 'PS1', 'U', 'XNNG', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(1879, 'PS1', 'U', 'XNPN', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(1934, 'BSI', 'U', 'HP', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(1934, 'PS1', 'U', 'XNPN', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(1970, 'PS1', 'U', 'PSADG09C', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(1972, 'PS1', 'U', 'PSADF09C', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(2065, 'PS1', 'U', 'PUABC00H', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(2067, 'PS1', 'U', 'PUABC00L', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(2090, 'PS1', 'U', 'XIYO', NULL, 1)
go

insert into commodity_market_alias
   (commkt_key, alias_source_code, type, commkt_alias_name, 
    alias_format_code, trans_id)
  values(2200, 'PS1', 'U', 'DKK00C', NULL, 1)
go

