print 'Loading additional seed data into the market table ...'
go

insert into market values('AECO', 'P', 'A', 'AECO C N.I.T', 
'AECO C.N.I.T. (7A)', 1)
go

insert into market values('AECO-C', 'P', 'N', 'AECO-C CAN$', 
'AECO C.N.I.T. (7A)', 1)
go

insert into market values('AECOUSD', 'P', 'A', 'AECO USD C NIT', 
'AECO USD C NOVA INVENTORY TRANSFER', 1)
go

insert into market values('AER/AR/O', 'P', 'A', 'NORAM ARK OKL.', 
'NORAM GAS TRANSMISSION CO. ARKANSAS,OKLA', 1)
go

insert into market values('ALGER-S', 'P', 'A', 'ALGERIA-SKIKDA', 
'SKIKDA, ALGERIA', 1)
go

insert into market values('ANR/LA', 'P', 'N', 'ANR PIPE LA', 
'ANR PIPELINE CO. LOUISIANA', 1)
go

insert into market values('ANR/OFF', 'P', 'N', 'ANR PIPE OFFSHO', 
'ANR PIPELINE CO. OFFSHORE', 1)
go

insert into market values('ANR/OKI', 'P', 'A', 'ANR PIPE OKLA.', 
'ANR PIPELINE CO. OKLAHOMA', 1)
go

insert into market values('APCNGPC', 'P', 'A', 'APCH,CNG,POOL-C', 
'APPALACHIA CNG,POOL - COMMON', 1)
go

insert into market values('ARA', 'P', 'A', 'FOB ARA', 
'FOB AMSTERDAM-ROTTERDAM-ANTWERP', 1)
go

insert into market values('AUSTRAL', 'P', 'A', 'AUSTRALIA', 'AUSTRALIA', 1)
go

insert into market values('BAHAMAS', 'P', 'A', 'BAHAMAS', 'BAHAMAS', 1)
go

insert into market values('BFOBROT', 'P', 'A', 'BARGES FOB ROT', 
'BARGES FOB ROTTERDAM', 1)
go

insert into market values('BOSLSCAR', 'P', 'A', 'BOSTON LS CARGO', 
'BOSTON LOW SULFUR CARGO', 1)
go

insert into market values('BOSTONCR', 'P', 'A', 'BOSTON CARGO', 'BOSTON CARGO', 
1)
go

insert into market values('C&FCHINA', 'P', 'A', 'C&F CHINA', 'C&F CHINA', 1)
go

insert into market values('C&FKOREA', 'P', 'A', 'C & F KOREA', 'C & F KOREA', 1)
go

insert into market values('C&FTAIWA', 'P', 'A', 'C & F TAIWAN', 'C & F TAIWAN', 
1)
go

insert into market values('CAC', 'P', 'N', 'CANADIAN CROSS', 
'CANADIAN CROSS RATES', 1)
go

insert into market values('CBOT', 'E', 'A', 'CBOT', 'CHICAGO BOARD OF TRADE', 1)
go

insert into market values('CCFJAPAN', 'P', 'A', 'C & F JPN CARGO', 
'C & F JAPAN CARGOES', 1)
go

insert into market values('CCFSINGP', 'P', 'A', 'SINGAPORE CARGO', 
'SINGAPORE FOB', 1)
go

insert into market values('CCIFARA', 'P', 'A', 'CARGOES CIF ARA', 
'CARGOES CIF ARA', 1)
go

insert into market values('CCIFMED', 'P', 'A', 'CARGOES CIF MED', 
'CARGOS CIF MED BASIS GENOA', 1)
go

insert into market values('CCIFNWE', 'P', 'N', 'CARGOES CIF NWE', 
'CARGOES CIF NWE BASIS ARA', 1)
go

insert into market values('CFCARBBL', 'P', 'A', 'CARIB $/BBL', 
'CARIB $/BBL CARGOES FOB', 1)
go

insert into market values('CFFO/ARG', 'P', 'N', 'CFFO ARGENTINA', 
'CFFO ARGENTINA', 1)
go

insert into market values('CFFO/BR', 'P', 'N', 'CFFO BRAZIL', 'CFFO BRAZIL', 1)
go

insert into market values('CFFO/CAM', 'P', 'N', 'CFFO C. AMERICA', 
'CFFO CENTRAL AMERICA', 1)
go

insert into market values('CFFO/CH', 'P', 'N', 'CFFO CHILE', 'CFFO CHILE', 1)
go

insert into market values('CFFO/COL', 'P', 'N', 'CFFO COLOMBIA', 
'CFFO COLOMBIA', 1)
go

insert into market values('CFFO/MEX', 'P', 'N', 'CFFO MEXICO', 'CFFO MEXICO', 1)
go

insert into market values('CFFO/PER', 'P', 'N', 'CFFO PERU', 'CFFO PERU', 1)
go

insert into market values('CFFO/URU', 'P', 'N', 'CFFO URUGUAY', 'CFFO URUGUAY', 
1)
go

insert into market values('CFFO/USA', 'P', 'N', 'CFFO E.C. USA', 
'C&FFO EAST COAST USA', 1)
go

insert into market values('CFOBARAG', 'P', 'A', 'CARGOES FOB AG', 
'CARGOES FOB ARABIAN GULF', 1)
go

insert into market values('CFOBCAR', 'P', 'A', 'CARIB FOB C/GAL', 
'CARIBBEAN CARGOES FOB', 1)
go

insert into market values('CFOBCARM', 'P', 'A', 'CARIB CARG $/MT', 
'CARIBEAN CARGOES $/MT', 1)
go

insert into market values('CFOBMED', 'P', 'A', 'CARGOES FOB MED', 
'CARGOES FOB MED BASIS ITALY', 1)
go

insert into market values('CFOBNWE', 'P', 'A', 'CARGOES FOB NWE', 
'CARGOES FOB NWE', 1)
go

insert into market values('CHEMASMN', 'P', 'A', 'USGC SPOT FOB', 
'US GULF COAST SPOT FOB', 1)
go

insert into market values('CHGDLY', 'P', 'N', 'CHANGE DAILY', 'CHANGE DAILY', 
1)
go

insert into market values('CHICAGLS', 'P', 'A', 'CHICAGO LS PIPE', 
'CHICAGO LOW SULFUR PIPELINE', 1)
go

insert into market values('CHICITYG', 'P', 'A', 'CHICAGO CTYGATE', 
'CHICAGO CITYGATE', 1)
go

insert into market values('CHINA70', 'P', 'A', 'C&F CHINA 70 0.', 
'C&F CHINA MOGAS 70 0.4 G/L', 1)
go

insert into market values('CHINA83', 'P', 'A', 'C&F CHINA 83 0.', 
'C&F CHINA MOGAS 83 0.4 G/L', 1)
go

insert into market values('CHINA90', 'P', 'A', 'C&F CHINA 90 0.', 
'C&F CHINA MOGAS 90 0.4 G/L', 1)
go

insert into market values('CIFNWE', 'P', 'N', 'IPE+JET DIFF', 
'IPE + JET/GO DIFFERENTIAL', 1)
go

insert into market values('CIFFO/BR', 'P', 'N', 'CIFFO BRAZIL', 'CIFFO BRAZIL', 
1)
go

insert into market values('CIFFO/CH', 'P', 'N', 'CIFFO CHILE', 'CIFFO CHILE', 1)
go

insert into market values('CIFFOARG', 'P', 'N', 'CIFFO ARGENTINA', 
'CIFFO ARGENTINA', 1)
go

insert into market values('CIFFOCAM', 'P', 'N', 'CIFFO C.AMERICA', 
'CIFFFO CENTRAL AMERICA', 1)
go

insert into market values('CIFFOCOL', 'P', 'N', 'CIFFO COLOMBIA', 
'CIFFO COLOMBIA', 1)
go

insert into market values('CIFFOMEX', 'P', 'N', 'CIFFO MEXICO', 'CIFFO MEXICO', 
1)
go

insert into market values('CIFFOPER', 'P', 'N', 'CIFFO PERU', 'CIFFO PERU', 1)
go

insert into market values('CIFFOURU', 'P', 'N', 'CIFFO URUGUAY', 
'CIFFO URUGUAY', 1)
go

insert into market values('CIFFOUSA', 'P', 'N', 'CIFFO E.C. USA', 
'CIFFO EAST COAST USA', 1)
go

insert into market values('CIFMARG', 'P', 'A', 'CIF MN AR', 'CIF MEAN ARGUS', 1)
go

insert into market values('CIFMAY-8', 'P', 'N', 'HS CIF MAY-8', 
'HSFO CIF MAY-8', 1)
go

insert into market values('CME', 'E', 'A', 'CME', 'CHICAGO MERCANTILE EXCHANGE', 
1)
go

insert into market values('CNG/APP', 'P', 'N', 'CNG TRANS APPAL', 
'CNG TRANSMISSION CORP. APPALACHIA', 1)
go

insert into market values('COL/ROCK', 'P', 'N', 'COLO INTER.ROCK', 
'COLORADO INTERSTATE GAS CO. ROCKY MOUNTS', 1)
go

insert into market values('COLUM/AP', 'P', 'N', 'COL GS TRANS.AP', 
'COLUMBIA GAS TRANSMISSION CORP. APPALACH', 1)
go

insert into market values('COLUM/LA', 'P', 'N', 'COL GF TRANS LA', 
'COLUMBIA GULF TRANSMISSION CO. LOUISIANA', 1)
go

insert into market values('COLUM/OF', 'P', 'N', 'COL GF TRANS OF', 
'COLUMBIA GULF TRANSMISSION CO.OFFSHORE', 1)
go

insert into market values('COLUM/WV', 'P', 'N', 'COL GS TRANS.W.', 
'COLOMBIA GAS TRANSMISSION CO. W. VA.', 1)
go

insert into market values('COLUMAPP', 'P', 'A', 'COLUM TCO APP', 
'COLUMBIA APPALACHIA (TCO)', 1)
go

insert into market values('COLUMGON', 'P', 'A', 'COL GF TRANS ON', 
'COLUMBIA GULF TRANSMISSION CO.ONSHORE', 1)
go

insert into market values('COLUM_LA', 'P', 'A', 'COL GS TRANS LA', 
'COLUMBIA GAS TRANSMISSION CO. LA-ONSHORE', 1)
go

insert into market values('COMEX', 'E', 'A', 'COMEX', 'COMMODITIES EXCHANGE', 1)
go

insert into market values('CONWAY', 'P', 'A', 'CONWAY', 'CONWAY', 1)
go

insert into market values('CRB', 'P', 'A', 'CRB', 'COMMODITY RESEARCH BUREAU', 
1)
go

insert into market values('CROWN', 'P', 'N', 'CROWN', 'CROWN', 1)
go

insert into market values('CSCE', 'E', 'A', 'CSCE', 
'COFFEE SUGAR AND COCOA EXCHANGE', 1)
go

insert into market values('CTN', 'E', 'A', 'NYCE', 'NEW YORK COTTON EXCHANGE', 
1)
go

insert into market values('CTNCA', 'E', 'A', 'NYCTNCA', 
'NEW YORK COTTON EXCHANGE CITRUS ASSOCIAT', 1)
go

insert into market values('CUSGP', 'P', 'A', 'CYCLE USGP', 'CYCLE USGP', 1)
go

insert into market values('CUSHING', 'P', 'A', 'CUSHING', 'CUSHING', 1)
go

insert into market values('DINV', 'P', 'N', 'D INVENTORY', 'D INVENTORY FLAT', 1)
go

insert into market values('DEMO', 'P', 'A', 'DEMO', 
'DEMO FOR JOHN MARGARET AND ROBINN', 1)
go

insert into market values('DJCOB', 'P', 'A', 'DJ-COB', 
'DOW JONES CALIFORNIA/NEVADA-OREGON BORDE', 1)
go

insert into market values('DJMIDC', 'P', 'A', 'DJ-MID-COL', 
'DOW JONES MID-COLUMBIA', 1)
go

insert into market values('DJPV', 'P', 'A', 'DJ-PV', 'DOW JONES - PALO VERDE', 
1)
go

insert into market values('DLVDCAN', 'P', 'A', 'DLVD. QUEBEC CA', 
'DLVD. QUEBEC CANADA', 1)
go

insert into market values('DLVDGCED', 'P', 'A', 'US G/C EX. DUTY', 
'U.S. GULF COAST DLVD. EX. DUTY', 1)
go

insert into market values('DLVDGULF', 'P', 'I', 'U.S.GULF DLVD.', 
'DELIVERED U.S.GULF', 1)
go

insert into market values('DLVDNWE', 'P', 'A', 'NWE SPOT FD', 
'NWE SPOT FREE DELIVERED', 1)
go

insert into market values('DLVDRDAM', 'P', 'A', 'DLVD. R''DAM', 
'DELIVERED ROTTERDAM', 1)
go

insert into market values('DOMPIPE', 'P', 'A', 'DOMESTIC PIPELI', 
'DOMESTIC PIPELINE', 1)
go

insert into market values('DTDNSEA', 'P', 'A', 'DATED NORTH SEA', 
'DATED NORTH SEA', 1)
go

insert into market values('EACOAST', 'P', 'A', 'EAST COAST', 'EAST COAST', 1)
go

insert into market values('EAEUROPE', 'P', 'N', 'EAST EUROPE', 'EAST EUROPE', 1)
go

insert into market values('EMORSSUS', 'P', 'A', 'EMPRESS USD', 'EMPRESS USD', 1)
go

insert into market values('EMPRESS', 'P', 'A', 'EMPRESS-TCPL', 'EMPRESS (7)', 1)
go

insert into market values('EMPRSS', 'P', 'A', 'EMPRESS CAN$', 'EMPRESS (7)', 1)
go

insert into market values('EMPRSSIN', 'P', 'A', 'EMPRESS INDEX', 'EMPRESS (7)', 
1)
go

insert into market values('ENCMEDHI', 'P', 'N', 'HI CARGOES CIF', 
'EN590 CCMED HI', 1)
go

insert into market values('ENFMED-5', 'P', 'N', 'ENFMED-5', 'EN590 FOBMED -5', 
1)
go

insert into market values('ENO/OKL', 'P', 'A', 'ENOGEX OKLAHOMA', 
'ENOGEX INC. OKLAHOMA', 1)
go

insert into market values('EOTT', 'P', 'A', 'EOTT POSTING', 'EOTT POSTING', 1)
go

insert into market values('ERCOT', 'P', 'A', 'ERCOT', 
'ELECTRIC RELIABILITYCOUNCIL OF TEXAS', 1)
go

insert into market values('ESTCBRG', 'P', 'I', 'NYH CNTRACT BRG', 
'NY HARBOR CONTRACT BARGE', 1)
go

insert into market values('ESTCCRG', 'P', 'A', 'NYH CNTRCT CRGO', 
'NY HARBOR CONTRACT CARGO', 1)
go

insert into market values('FAREAST', 'P', 'A', 'FAREAST', 'FAREAST', 1)
go

insert into market values('FEDFUNDS', 'P', 'A', 'FED FUNDS', 'FEDERAL FUNDS', 1)
go

insert into market values('FERCHHUB', 'P', 'A', 'FERC H HUB', 'FERC H HUB', 1)
go

insert into market values('FMED+3', 'P', 'N', 'CFOBMED+3', 'CFOBMED+3', 1)
go

insert into market values('FOB', 'P', 'A', 'FOB', 'FOB', 1)
go

insert into market values('FOB*', 'P', 'A', 'FOB*', 'FOB*', 1)
go

insert into market values('FOB/CAN', 'P', 'N', 'FOB W.C. CANADA', 
'FOB W.C. CANADA', 1)
go

insert into market values('FOBALGER', 'P', 'A', 'ALGERIA-BETH', 
'BETHOUIA, ALGERIA', 1)
go

insert into market values('FOBBLACK', 'P', 'A', 'FOB BLACK SEA', 
'FOB BLACK SEA', 1)
go

insert into market values('FOBBNOLA', 'P', 'N', 'FOB BARGE NOLA', 
'FOB BARGE NOLA', 1)
go

insert into market values('FOBCHINA', 'P', 'A', 'FOB CHINA', 'FOB CHINA', 1)
go

insert into market values('FOBE/EUR', 'P', 'N', 'FOB EAST EUROPE', 
'FOB EAST EUROPE', 1)
go

insert into market values('FOBMOBIL', 'P', 'A', 'FOB MOBILE ALA.', 
'FOB MOBILE ALABAMA', 1)
go

insert into market values('FOBNWE', 'P', 'A', 'FOB NWE', 
'FOB NORTH WEST EUROPE', 1)
go

insert into market values('FOBROT98', 'P', 'A', 'FOBROTT 98 RON', 
'BARGES FOB ROTTERDAM 98 RON UNLEADED', 1)
go

insert into market values('FOBSARAB', 'P', 'A', 'FOB S. ARABIA', 
'FOB SAUDIA ARABIA', 1)
go

insert into market values('FOBSING', 'P', 'A', 'FOB SINGAPORE', 'FOB SINGAPORE', 
1)
go

insert into market values('FOBTAMPA', 'P', 'N', 'FOB T/R TAMPA', 
'FOB TRUCK / RAIL TAMPA', 1)
go

insert into market values('FOBTMPA', 'P', 'A', 'FOB VESSEL TAMP', 
'FOB VESSEL TAMPA', 1)
go

insert into market values('G3', 'P', 'A', 'GROUP 3', 'GROUP 3', 1)
go

insert into market values('G3LS', 'P', 'A', 'GROUP 3 LS', 
'GROUP THREE LOW SULFUR', 1)
go

insert into market values('GCFDCTR', 'P', 'N', 'USGC CTR FD', 
'US GULF COAST FD CONTRACT', 1)
go

insert into market values('GCLSPLFO', 'P', 'I', 'USG LS PL FORW', 
'U.S. GULF LOW SULFUR PIPELINE FORWARD', 1)
go

insert into market values('GCLSWBFO', 'P', 'I', 'USG LS WB FORW', 
'U.S. GULF LOW SULFUR WATERBORNE FORWARD', 1)
go

insert into market values('GCXTCTR', 'P', 'N', 'USGC CTR EXT', 
'US GULF COAST EX TANK CONTRACT', 1)
go

insert into market values('GHENTINV', 'P', 'N', 'GHENT INV', 'GHENT INVENTORY', 
1)
go

insert into market values('GULF', 'P', 'A', 'USGC-WBORN-DAIL', 
'U.S. GULF COAST WATERBORN-DAILY', 1)
go

insert into market values('GULFBG', 'P', 'A', 'U.S. GULF BARGE', 
'U.S. GULF BARGE', 1)
go

insert into market values('GULFPIPE', 'P', 'A', 'U.S.GULF PIPE', 
'U.S.GULF COAST PIPELINE', 1)
go

insert into market values('GULFUS', 'P', 'A', 'U.S.GULF W.BORN', 
'U.S. GULF COAST WATERBORNE', 1)
go

insert into market values('HHUB/LA', 'P', 'A', 'HENRY HUB LA.', 
'HENRY HUB LA.', 1)
go

insert into market values('HICIF+$3', 'P', 'A', 'HI CIF SPOT +$3', 
'HI CUF SPOT + $3', 1)
go

insert into market values('HSCEHKAT', 'P', 'A', 'HSC EH KATY', 
'HOUS SHPNG CHNL EAST-HOUSTON-KATY', 1)
go

insert into market values('HSCLPD', 'P', 'A', 'HSC LG PKG', 
'HOUS SHPNG CHNL LG PKG MONTHLY', 1)
go

insert into market values('HSCLPI', 'P', 'N', 'HSC LG INDX PKG', 
'HOUSTON SHIP CHANNEL-BEAUMONT,TEXAS', 1)
go

insert into market values('HSFOAUG', 'P', 'A', 'HSFOAUG', 'HSFOAUG', 1)
go

insert into market values('HSFOB', 'P', 'A', 'HSFOB', 'HSFOB', 1)
go

insert into market values('HSVGOM', 'P', 'A', 'HSVGOM', 'HSVGOM', 1)
go

insert into market values('IFBTHSTN', 'P', 'A', 'FERC B.T. HOUST', 
'INSIDE FERC BURNER TIP HOUSTON SMALL VOL', 1)
go

insert into market values('IFHHCP', 'P', 'A', 'FERC HH CASH PR', 
'HENRY HUB INSIDE FERC CASH PRICE', 1)
go

insert into market values('IFPCGLA', 'P', 'A', 'FERC COL GAS CO', 
'INSIDE FERC COLUMBIA GAS LOUISIANA', 1)
go

insert into market values('IFPPLSA', 'P', 'A', 'FERC PP LOUISIA', 
'INSIDE FERC PIPELINE LOUISIANA', 1)
go

insert into market values('IFPPNWCB', 'P', 'I', 'FERC N.W PP CAN', 
'INSIDE FERC N.W. CANADIAN BORDER', 1)
go

insert into market values('IFPPOKK', 'P', 'A', 'FERC PP OKK', 
'INSIDE FERC PIPELINE OKL/KANSAS', 1)
go

insert into market values('IFPPTEX', 'P', 'A', 'FERC PP TEX', 
'INSIDE FERC PIPELINE TEXAS', 1)
go

insert into market values('IFWELAPP', 'P', 'A', 'FERC WELL APPL', 
'INSIDE FERC WELL HEAD  APPALACHIA', 1)
go

insert into market values('ILLVNGPL', 'P', 'A', 'ILLINOIS VIA NG', 
'CALIF. BORDER/MIDWEST -ILLINOIS VIA NGPL', 1)
go

insert into market values('INDONESI', 'P', 'A', 'INDONESIA', 'INDONESIA', 1)
go

insert into market values('INTFUTS', 'P', 'N', 'INT FUTURES', 
'INTERNAL FUTURES', 1)
go

insert into market values('INTRATE', 'P', 'N', 'INTEREST RATE', 'INTEREST RATE', 
1)
go

insert into market values('INTRATES', 'P', 'A', 'INTRATES', 
'USD INTEREST RATES', 1)
go

insert into market values('INTRSTAT', 'P', 'A', 'INTERSTATE AVG', 
'INTERSTATE AVERAGE', 1)
go

insert into market values('INVROLL', 'P', 'N', 'INVENTORY ROLL', 
'INVENTORY ROLL', 1)
go

insert into market values('IPE', 'E', 'A', 'IPE', 
'LONDON INTERNATIONAL PETROLEUM EXCHANGE', 1)
go

insert into market values('JAC', 'P', 'A', 'YEN CROSS RATES', 
'JAPANESE YEN CROSS RATES', 1)
go

insert into market values('JOHN', 'P', 'I', 'JOHNS PARADISE', 'JOHNS', 1)
go

insert into market values('JUNIP+EW', 'P', 'N', 'M IPE +', 
'JUNE IPE + JET EW PREMIUM', 1)
go

insert into market values('KAREHGDD', 'P', 'A', 'KATY DAILY EH', 
'EAST-HOUSTON-KATY HUB TAILGATE', 1)
go

insert into market values('KARLSHAM', 'P', 'A', 'KARLSHAMN', 'KARLSHAMN', 1)
go

insert into market values('KATEHMCI', 'P', 'A', 'KATY MCI EH', 
'EAST-HOUSTON-KATY PLANT TAILGATE', 1)
go

insert into market values('KCBT', 'E', 'A', 'KCBT', 
'KANSAS CITY BOARD OF TRADE', 1)
go

insert into market values('KERN/WY', 'P', 'N', 'KERN RIVER WY.', 
'KERN RIVER GAS TRANSMISSION CO. WYOMING', 1)
go

insert into market values('KOCH', 'P', 'A', 'KOCH POSTING', 
'KOCH POSTING PRICES FOR CUSHING MARKET', 1)
go

insert into market values('KOCH+CSH', 'P', 'I', 'KOCH PPLUS CUSH', 
'KOCH PPLUS CUSHING', 1)
go

insert into market values('KPPC', 'P', 'A', 'KOCHP AND PPLUS', 
'KOCH PPLUS CUSHING', 1)
go

insert into market values('LAG/WH', 'P', 'A', 'LA. GULF ON W.H', 
'LA. GULF ONSHORE WELLHEAD', 1)
go

insert into market values('LA.OS/WH', 'P', 'A', 'LA. OFFSHORE W.', 
'LA. OFFSHORE W.HEAD', 1)
go

insert into market values('LAONSCOL', 'P', 'A', 'LA-ONS.S.COLUMB', 
'LOUISIANA-ONSHORE SOUTH - COUMBIA', 1)
go

insert into market values('LAONSHH', 'P', 'A', 'LA-ONS.S.H.HUB', 
'LOUISIANA-ONSHORE SOUTH - HENRY HUB', 1)
go

insert into market values('LAONSST', 'P', 'A', 'LA-ONS.STH.TENN', 
'LOUISIANA-ONSHORE SOUTH -TENNESSEE', 1)
go

insert into market values('LAONST5', 'P', 'A', 'LA-ONS.S.TEN500', 
'LOUISIANA-ONSHORE S. TENNESSEE, 500 LEG', 1)
go

insert into market values('LAONST8', 'P', 'A', 'LA-ONS.S.TEN800', 
'LOUISIANA-ONSHORE S. TENNESSEE, 800 LEG', 1)
go

insert into market values('LAONSTEE', 'P', 'A', 'LA-ONS.S.TEX E.', 
'LOUISIANA-ONSHORE SOUTH -TEXAS E (ELA)', 1)
go

insert into market values('LAONSTEW', 'P', 'A', 'LA-ONS.S.TEX W.', 
'LOUISIANA-ONSHORE SOUTH -TEXAS E (WLA)', 1)
go

insert into market values('LAONSTEX', 'P', 'A', 'LA-ONS TEXAS GA', 
'LA ONS. TEXAS GAS SL', 1)
go

insert into market values('LAONSTR3', 'P', 'A', 'LA-ONS.S.TRANSC', 
'LOUISIANA-ONSHORE SOUTH -TRANSCO Z3 ST65', 1)
go

insert into market values('LATTAVRE', 'P', 'A', 'LE HAVRE', 'LE HAVRE', 1)
go

insert into market values('LEHAVRE', 'P', 'N', 'LE HAVRE', 'JET A1-LEHAVRE', 1)
go

insert into market values('LFOX', 'E', 'A', 'LCE', 
'LONDON COMMODITIES EXCHANGE', 1)
go

insert into market values('LHSTOR', 'P', 'A', 'LEHAVRE STORAGE', 
'LEHAVRE STORAGE', 1)
go

insert into market values('LIBOR', 'P', 'A', 'LIBOR', 'LIBOR', 1)
go

insert into market values('LME', 'E', 'A', 'LME', 'LONDON METALS EXCHANGE', 1)
go

insert into market values('LSJETBOS', 'P', 'I', 'LS JET BOSTON C', 
'LS JET/KERO BOSTON CARGO', 1)
go

insert into market values('LSJETNYB', 'P', 'I', 'LS JET NY BARGE', 
'LOW SULFUR JET/KERO NY BARGE', 1)
go

insert into market values('LSJETNYC', 'P', 'I', 'LS JET NY CARGO', 
'LOW SULFUR JET/KERO NY CARGO', 1)
go

insert into market values('MACTEZM3', 'P', 'A', 'TEX.E.ZONEM3FTM', 
'MID-ATLAN. CITYGATES TEX.E.,ZONE M-3,FTM', 1)
go

insert into market values('MAIN', 'P', 'A', 'MAIN', 
'MID-AMERICA INTERCONNECTED NETWORK', 1)
go

insert into market values('MAL-INV3', 'P', 'N', 'MALT-INV3', 
'MALTA - INVENTORY3 (GASOIL 0.5)', 1)
go

insert into market values('MALAYSIA', 'P', 'A', 'MALAYSIA', 'MALAYSIA', 1)
go

insert into market values('MALMO', 'P', 'A', 'MALMO', 'MALMO', 1)
go

insert into market values('MALT-INV', 'P', 'N', 'MALT-INV1', 
'MALTA EN590 INVENTORY', 1)
go

insert into market values('MAPP', 'P', 'A', 'MAPP', 
'MID-CONTINENT AREA POWER POOL', 1)
go

insert into market values('MATIF', 'E', 'A', 'MATIF', 
'MARCHE A TERME DES INSTRUMENTS FINANCIER', 1)
go

insert into market values('MBELVIEW', 'P', 'N', 'MONT BELVIEU', 'MONT BELVIEU', 
1)
go

insert into market values('MEXICO', 'P', 'A', 'FOB VSL MEXICO', 
'FOB VESSEL MEXICO', 1)
go

insert into market values('MGE', 'E', 'A', 'MGE', 'MINNEAPOLIS GRAIN EXCHANGE', 
1)
go

insert into market values('MICHCONM', 'P', 'A', 'MICHCON-MIDWEST', 
'MICHIGAN CONSOLIDATED - MIDWEST', 1)
go

insert into market values('MIDAM', 'E', 'A', 'MIDAM', 
'MIDAMERICAN COMMODITIES EXCHANGE', 1)
go

insert into market values('MIDLAND', 'P', 'A', 'MIDLAND', 'MIDLAND', 1)
go

insert into market values('MONTBEL', 'P', 'A', 'MONT BELVIEW', 'MONT BEWVIEW', 
1)
go

insert into market values('MSM', 'P', 'A', 'ECAR', 'ECAR', 1)
go

insert into market values('MSMFLA', 'P', 'N', 'FLORIDA (SERC)', 
'STHEASTN. ELEC. RELIABILITY CNCL.FLORIDA', 1)
go

insert into market values('MSMSERC', 'P', 'A', 'SERC', 
'STHEASTN. ELEC. RELIABILITY CNCL. EX FLA', 1)
go

insert into market values('MSMSPP', 'P', 'A', 'SPP', 'SPP', 1)
go

insert into market values('MTBELNWA', 'P', 'A', 'MT.BELVIEU N-WR', 
'MT. BELVIEW NON-WARREN NON-TET', 1)
go

insert into market values('MTBELVOP', 'P', 'A', 'MT BELVIEW OPIS', 
'MOUNT BELVIEW OPIS', 1)
go

insert into market values('MTBELWAR', 'P', 'A', 'MT.BELVIEU WARR', 
'MT. BELVIEU WARREN NON-TET', 1)
go

insert into market values('MYSTRAS', 'P', 'N', 'MYSTRAS FO', 
'MYSTRAS FUEL OIL INVENTORY', 1)
go

insert into market values('NSEA', 'P', 'A', 'NORTH SEA', 'NORTH SEA', 1)
go

insert into market values('NSEABP', 'P', 'A', 'NORTH SEA BP', 'NORTH SEA BP', 
1)
go

insert into market values('NATAPI', 'P', 'A', 'NATIONAL API ST', 
'NATIONAL API STATS', 1)
go

insert into market values('NGAS/OKL', 'P', 'A', 'N.G.P/L MID-CZO', 
'NATURAL GAS PIPELINE CO. OF A. MID-CONTZ', 1)
go

insert into market values('NGP/LA', 'P', 'A', 'NAT GAS PIPE LA', 
'NATURAL GAS PIPELINE CO. OF AMERICA LA', 1)
go

insert into market values('NGP/TX', 'P', 'A', 'NAT GAS P/L STX', 
'NATURAL GAS PIPELINE CO. OF A.-S. TEXAS', 1)
go

insert into market values('NIAGNFGT', 'P', 'A', 'NIAGARA NFG TEN', 
'NIAGARA (NFG, TENN.)', 1)
go

insert into market values('NIGERIA', 'P', 'A', 'NIGERIA', 'NIGERIA', 1)
go

insert into market values('NMNEPOOL', 'P', 'A', 'NEPOOL', 'NEPOOL', 1)
go

insert into market values('NMNYPP', 'P', 'A', 'NYPP', 'NYPP', 1)
go

insert into market values('NMPJM', 'P', 'A', 'PJM', 'PJM', 1)
go

insert into market values('NMPJMBGE', 'P', 'A', 'PJM-BGE', 
'PENN./ NEW JERSEY/ MARYLAND (B G & E)', 1)
go

insert into market values('NNG/VENT', 'P', 'N', 'NORTH VENTURA', 
'NORTHERN NATURAL GAS CO. VENTURA IOWA', 1)
go

insert into market values('NNGDEMAR', 'P', 'A', 'NNG DEMARCATION', 
'NORTHERN NATGAS CO. DEMARCATION, KS', 1)
go

insert into market values('NOMKTOMK', 'P', 'A', 'NO MARK TO MARK', 
'NO MARK TO MARKET P/L', 1)
go

insert into market values('NORAME', 'P', 'A', 'NORAM EAST', 
'NORAM GAS TRANSMISSION CO. EAST', 1)
go

insert into market values('NORAMW', 'P', 'A', 'NORAM WEST', 
'NORAM GAS TRANSMISSION CO. WEST', 1)
go

insert into market values('NORTHERN', 'P', 'A', 'NORTH TX OK KA', 
'NORTHERN NATURAL GAS CO. TX. OKL. KAN.', 1)
go

insert into market values('NSPARTS', 'P', 'N', 'N. SEA PARTIALS', 
'NORTH SEA PARTIALS', 1)
go

insert into market values('NTERM', 'P', 'A', 'NTERMINAL', 'NTERMINAL', 1)
go

insert into market values('NWE', 'P', 'N', 'NWE CG FOB', 'NORTH WEST EUROPE', 1)
go

insert into market values('NWECFCTR', 'P', 'N', 'NWE CTR CIF', 
'NORTH WEST EUROPE CIF CONTRACT', 1)
go

insert into market values('NWEFDCTR', 'P', 'A', 'NWE CTR FD', 
'NORTH WEST EUROPE FD CONTRACT', 1)
go

insert into market values('NWEVGO', 'P', 'A', 'NORTHWEST EUROP', 
'NORTHWEST EUROPE', 1)
go

insert into market values('NWP/CA', 'P', 'N', 'NWP CANADA', 
'NORTHWEST PIPELINE CORP. CANADIAN BORDER', 1)
go

insert into market values('NWP/ROCK', 'P', 'A', 'NWP ROCKY MTS', 
'NORTH WEST PIPELINE CORP. ROCKY MOUNTAIN', 1)
go

insert into market values('NWP/US', 'P', 'N', 'NWP US CURR', 
'NORTH WEST PROVINCES - CANADA - USA CURR', 1)
go

insert into market values('NYCST', 'P', 'N', 'NY 380 CST', 'NY 380 CST', 1)
go

insert into market values('NYCGATE', 'P', 'A', 'NY CITY GATE', 
'NEW YORK CITY GATE - THIS WEEK', 1)
go

insert into market values('NYFE', 'E', 'A', 'NYFE', 'NEW YORK FUTURES EXCHANGE', 
1)
go

insert into market values('NYHBRG', 'P', 'N', 'NY HARBOR BARGE', 
'NY HARBOR BARGE', 1)
go

insert into market values('NYHCRG', 'P', 'N', 'NY HARBOR CARGO', 
'NY HARBOR CARGO', 1)
go

insert into market values('NYHLSBAR', 'P', 'A', 'NY HAR LS BARGE', 
'NY HARBOR LOW SULFUR BARGE', 1)
go

insert into market values('NYHLSCAR', 'P', 'A', 'NY HAR LS CARGO', 
'NY HARBOR LOW SULFUR CARGO', 1)
go

insert into market values('NYMEX', 'E', 'A', 'NYMEX', 
'NEW YORK MERCHANTILE EXCHANGE', 1)
go

insert into market values('NYMEXALB', 'E', 'A', 'NYMEX-ALBERTA', 
'NEW YORK MERCANTILE EXCHANGE - ALBERTA', 1)
go

insert into market values('NYMEXCOB', 'E', 'A', 'NYMEX-COB', 
'N. Y. MERC. EXCHANGE - CAL. OREG. BORDER', 1)
go

insert into market values('NYMEXGC', 'E', 'A', 'NYMEX GULFCOAST', 
'NY MERCHANTILE EXCHANGE GULF COAST', 1)
go

insert into market values('NYMEXPER', 'E', 'A', 'NYMEX-PERM', 
'N.Y.MERC. EXCH. - W.TEXAS (PERMIAN POOL)', 1)
go

insert into market values('NYMEXPV', 'E', 'A', 'NYMEX-PV', 
'N. Y. MERCANTILE EXCHANGE -PALO VERDE', 1)
go

insert into market values('NYSE', 'P', 'A', 'NYSE', 'NYSE', 1)
go

insert into market values('OCTWTI', 'P', 'N', 'OCT WTI', 'OCT WTI', 1)
go

insert into market values('OFFPGULF', 'P', 'A', 'OFFIC.PER.GULF', 
'OFFICIAL PERSIAN GULF PRICE', 1)
go

insert into market values('ONG/OKL', 'P', 'A', 'ONG TRANS. OKL.', 
'ONG TRANSMISSION CO. OKLAHOMA', 1)
go

insert into market values('P-PLUS', 'P', 'A', 'P-PLUS', 'P-PLUS', 1)
go

insert into market values('PAS/ANAD', 'P', 'A', 'EL PASO ANADARK', 
'EL PASO NATURAL GAS CO. ANADARKO BASIN', 1)
go

insert into market values('PAS/JUAN', 'P', 'A', 'EL PASO SANJUAN', 
'EL PASO NATURAL GAS CO. SAN JUAN BASIN', 1)
go

insert into market values('PAS/PERM', 'P', 'A', 'EL PASO PERMIAN', 
'EL PASO NATURAL GAS PERMIAN BASIN', 1)
go

insert into market values('PCHIC', 'P', 'A', 'CHICAGO PIPE', 'CHICAGO PIPELINE', 
1)
go

insert into market values('PEICRUDE', 'P', 'I', 'PHIBRO CRUDE', 'PHIBRO CRUDE', 
1)
go

insert into market values('PENULTIM', 'E', 'A', 'PENULTIMATE NYM', 
'PENULTIMATE NYMEX NG', 1)
go

insert into market values('PEP/T/O', 'P', 'A', 'PANHANDLE TX', 
'PANHANDLE EASTERN PIPE LINE CO. TX. OKL.', 1)
go

insert into market values('PERMPASO', 'P', 'A', 'PERM BASIN PASO', 
'PERMIAN BASIN AREA - EL PASO (DAY 2)', 1)
go

insert into market values('PERU', 'P', 'A', 'PERU', 'PERU', 1)
go

insert into market values('PETROLA', 'P', 'N', 'PETROLA TERM', 
'PETROLA TERM DEAL', 1)
go

insert into market values('PETRONOR', 'P', 'A', 'PETRONOR+4', 'PETRONOR+4', 1)
go

insert into market values('PETROTR', 'P', 'A', 'SEPWTI-2.66', 'SEPWTI-2.66', 1)
go

insert into market values('PGTM', 'P', 'A', 'PGT MALIN', 'PGT MALIN', 1)
go

insert into market values('PGULF', 'P', 'A', 'PERSIAN GULF', 'PERSIAN GULF', 1)
go

insert into market values('PHIBSUGR', 'P', 'A', 'PHIBRO SUGAR', 'PHIBRO SUGAR', 
1)
go

insert into market values('PIP', 'P', 'A', 'POOL INPUT PRIC', 
'POOL INPUT PRICE', 1)
go

insert into market values('PLATTSPT', 'P', 'A', 'PLATTS POST', 'PLATTS POSTING', 
1)
go

insert into market values('PLE4S', 'P', 'N', 'PLE4S', 'PLE4S', 1)
go

insert into market values('POP', 'P', 'A', 'POOL OUTPUT PRC', 
'POOL OUTPUT PRICE', 1)
go

insert into market values('POTEN', 'P', 'N', 'POTEN & PARTNER', 
'POTEN & PARTNERS, INC ASPHALT WEEKLY MON', 1)
go

insert into market values('PPLUSCER', 'P', 'A', 'SCURLOCK POSTIN', 'PPLUS SCER', 
1)
go

insert into market values('PPLUSUNC', 'P', 'A', 'SUNREF POSTING', 
'PPLUS SUNREF CUSHING', 1)
go

insert into market values('PSP', 'P', 'A', 'POOL SELLING PR', 
'POOL SELLING PRICE', 1)
go

insert into market values('PWCLA', 'P', 'A', 'W.C PIPE L.A', 
'WEST COAST PIPELINE L.A.', 1)
go

insert into market values('PWCLSEAT', 'P', 'A', 'W.C PIPE SEATL', 
'WEST COAST PIPELINE SEATTLE', 1)
go

insert into market values('PWCPORTL', 'P', 'A', 'W.C PIPE PORTL', 
'WEST COAST PIPELINE PORTLAND', 1)
go

insert into market values('PWCSF', 'P', 'A', 'W.C PIPE S.F', 
'WEST COAST PIPELINE S.F.', 1)
go

insert into market values('QUES/ROC', 'P', 'N', 'QUEST ROCKY MT.', 
'QUESTAR PIPELINE CO. ROCKY MOUNTAINS', 1)
go

insert into market values('RFGBOST', 'P', 'A', 'RFG BOSTON', 
'REFORMULATED GASOLINE BOSTON', 1)
go

insert into market values('RFGNYCA', 'P', 'A', 'RFG NY CARGO', 
'REFORMULATED GASOLINE NY CARGO', 1)
go

insert into market values('RFGNYHB', 'P', 'A', 'RFG NY BARGE', 
'REFORMULATED GASOLINE NY HARBOR BARGE', 1)
go

insert into market values('RFGUSGPL', 'P', 'A', 'RFG USGC PIPE', 
'REFORMULATED GASOLINE USGC PIPELINE', 1)
go

insert into market values('RFGUSGWB', 'P', 'A', 'RFG USGC WB', 
'REFORMULATED GASOLINE USGC WATERBORNE', 1)
go

insert into market values('RFGWCLA', 'P', 'A', 'RFG W.C LA', 
'REFORMULATED GASOLINE WEST COAST L.A.', 1)
go

insert into market values('RMG35', 'P', 'A', 'RMG3.5', 'RMG3.5', 1)
go

insert into market values('RMG35M', 'P', 'N', 'INV2', 'INV2', 1)
go

insert into market values('ROTTERDA', 'P', 'A', 'ROTTERDAM', 'ROTTERDAM', 1)
go

insert into market values('RUSSIAN', 'P', 'N', 'RUSSIAN GO', 'RUSSIAN GASOIL', 
1)
go

insert into market values('SAMERICA', 'P', 'A', 'SOUTH AMERICA', 
'SOUTH AMERICA', 1)
go

insert into market values('SAUDARAM', 'P', 'N', 'SAUDI ARAMCO', 'SAUDI ARAMCO', 
1)
go

insert into market values('SCERCUSH', 'P', 'A', 'CUSHING-SCERPER', 
'SCERPER CUSHING', 1)
go

insert into market values('SE_ASIA', 'P', 'A', 'SE ASIA', 'SOUTH EAST ASIA', 1)
go

insert into market values('SIMEX', 'E', 'A', 'SIMEX', 
'SINGAPORE INTERNATIONAL MONETARY EXCHANG', 1)
go

insert into market values('SINGINV', 'P', 'N', 'SING INV', 
'SINGAPORE INVENTORY', 1)
go

insert into market values('SING-3', 'P', 'A', 'SINGAPORE 180 -', 
'SINGAPORE 180 PLATTS AVG- 3', 1)
go

insert into market values('SING95', 'P', 'A', 'SING 95 RON', 
'SINGAPORE MOGAS 95 RON', 1)
go

insert into market values('SING97', 'P', 'A', 'SING 97 RON', 
'SINGAPORE MOGAS 97 RON', 1)
go

insert into market values('SINGA3', 'P', 'A', 'SING 180 -3', 
'SINGAPORE 180 PLATTS AVG -3', 1)
go

insert into market values('SKIKDA', 'P', 'A', 'SKIKDA', 'SKIKDA ALGERIA', 1)
go

insert into market values('SMP', 'P', 'A', 'SYS MARGIN PRIC', 
'SYSTEM MARGINAL PRICE', 1)
go

insert into market values('SNG/LA', 'P', 'N', 'SOUTH. N.GAS LA', 
'SOUTHERN NATURAL GAS CO. LOUISIANA', 1)
go

insert into market values('SOCALBDR', 'P', 'A', 'SOCAL BORDER', 
'SOTHERN CALIFORNIA BORDER AVG.', 1)
go

insert into market values('SPC', 'P', 'A', 'CUSH-SCURPERM', 
'SCURLOCK PERMIAN PRICES FOR CUSHING MARK', 1)
go

insert into market values('SPRDAG', 'P', 'A', 'SPREAD VS AG', 
'PLATTS SPREAD VS. MOP ARAB GULF', 1)
go

insert into market values('SPRDICP', 'P', 'A', 'SPREAD VS ICP', 
'PLATTS SPREAD VS. ICP', 1)
go

insert into market values('SPRDJAP', 'P', 'A', 'SPREAD VS JAPAN', 
'PLATTS SPREAD VS. MOP JAPAN', 1)
go

insert into market values('SPRDSING', 'P', 'N', 'SPREAD VS SING', 
'PLATTS SPREAD VS. MOP SINGAPORE', 1)
go

insert into market values('SPRDTAP', 'P', 'A', 'SPREAD VS TAPIS', 
'PLATTS SPREAD VS . TAPIS', 1)
go

insert into market values('STROSE', 'P', 'A', 'ST.ROSE', 'ST.ROSE', 1)
go

insert into market values('STATUK', 'P', 'A', 'STATOILUK', 'STATOILUK', 1)
go

insert into market values('SUNRCUSH', 'P', 'A', 'CUSHING-SUNREF', 
'SUNREF-CUSHING', 1)
go

insert into market values('TENN/0', 'P', 'N', 'TENN GAS TX. Z0', 
'TENNESSEE GAS PIPELINE CO.TEXAS (ZONE 0)', 1)
go

insert into market values('TET/LA', 'P', 'N', 'TETCO EAST LA.', 
'TEXAS EASTERN TRANSMISSION CORP. EAST LA', 1)
go

insert into market values('TET/TX', 'P', 'A', 'TETCO EAST TX.', 
'TEXAS EASTERN TRANSMISSION CORP. EAST TX', 1)
go

insert into market values('TETCOWLA', 'P', 'A', 'TETCO WEST LA.', 
'TEXAS EASTERN TRANSMISSION CORP. WEST LA', 1)
go

insert into market values('TETCOWTX', 'P', 'A', 'TETCO SOUTH TX.', 
'TEXAS EASTERN TRANSMISSION CORP.SOUTH TX', 1)
go

insert into market values('TETCOZME', 'P', 'A', 'TETCO ZONE M-3', 
'TEXAS EASTERN TRANSMISSION CORP.ZONE M-3', 1)
go

insert into market values('TEXACO', 'P', 'A', 'CUSHING-TEXACO', 
'TEXACO PRICES FOR CUSHING MARKET', 1)
go

insert into market values('TEXERNM3', 'P', 'A', 'TEX.E.M3MCI', 
'TEX. EASTERN M-3 (MONTHLY CONTRACT INDEX', 1)
go

insert into market values('TITRIG', 'E', 'A', 'WTI TRIGGER', 
'WEST TEXAS INTERMEDIATE TRIGGER', 1)
go

insert into market values('TOTAL', 'P', 'A', 'TOTALTERM', 'TOTALTERM', 1)
go

insert into market values('TPSNYWTI', 'P', 'A', 'TPS_NYMEX', 'TPS NYMEX', 1)
go

insert into market values('TPSPG', 'P', 'A', 'TPS_PERSIAN', 'TPS PERSIAN GULF', 
1)
go

insert into market values('TRANS/3', 'P', 'N', 'TRANS GAS Z3', 
'TRANSCONTINENTAL GAS PIPELINE CORP.ZONE3', 1)
go

insert into market values('TRANS/M', 'P', 'N', 'TRANS GAS MISS.', 
'TRANSCONTINENTAL GAS PIPELINE CORP.MISS,', 1)
go

insert into market values('TRANSCFT', 'P', 'A', 'TRANSCO FTM', 
'TRANSCO GAS PIPELINE CORP. FT MONTHLY', 1)
go

insert into market values('TRANSCIT', 'P', 'A', 'TRANSCO ITM', 
'TRANSCO GAS PIPELINE CORP. IT MONTHLY', 1)
go

insert into market values('TREASURY', 'P', 'A', 'TREASURY', 'TREASURY', 1)
go

insert into market values('TRIGGER', 'P', 'N', 'BRT TRIGGER', 'BRENT TRIGGER', 
1)
go

insert into market values('TRUNK/F', 'P', 'N', 'TRUNK GAS FZONE', 
'TRUNKLINE GAS CO. FIELD ZONE (TEXAS,LA.)', 1)
go

insert into market values('TW/PERM', 'P', 'A', 'TRANSWEST PERMI', 
'TRANSWESTERN PIPELINE CO. PERMIAN BASIN', 1)
go

insert into market values('TWSTA8', 'P', 'A', 'TRANSWEST STA 8', 
'TRANSWESTERN PIPELINE STATION 8', 1)
go

insert into market values('TXG/WH', 'P', 'A', 'TX. GULF ON W.H', 
'TEXAS GULF ONSHORE WELLHEAD', 1)
go

insert into market values('TX.OS/WH', 'P', 'A', 'TX. OFFSHORE W.', 
'TEXAS OFFSHORE WELLHEAD', 1)
go

insert into market values('TXCAR40', 'P', 'A', 'TEX CARIB 40 CE', 
'TEXACO CARIBBEAN 40 CETANE GASOIL 0.5%S', 1)
go

insert into market values('TXCAR45', 'P', 'A', 'TEX CARIB 45 CE', 
'TEXACO CARIBBEAN 45 CETANE GASOIL .5%S P', 1)
go

insert into market values('TXCAR83', 'P', 'A', 'TEX CARIB 83 MO', 
'TEXACO CARIBBEAN 83 MOGAS POSTING', 1)
go

insert into market values('TXCAR87', 'P', 'A', 'TEX CARIB 87 MO', 
'TEXACO CARIBBEAN 87 MOGAS POSTING', 1)
go

insert into market values('TXCAR93', 'P', 'A', 'TEX CARIB 93 MO', 
'TEXACO CARIBBEAN 93 MOGAS POSTING', 1)
go

insert into market values('TXCAR95', 'P', 'A', 'TEX CARIB 95 MO', 
'TEXACO CARIBBEAN 95 MOGAS POSTING', 1)
go

insert into market values('TXCARIB', 'P', 'A', 'TEX CARIB', 
'TEXACO CARIBBEAN POSTING', 1)
go

insert into market values('TXGAS/SL', 'P', 'N', 'TX GAS TRANS SL', 
'TEXAS GAS TRANSMISSION CORP. ZONE SL', 1)
go

insert into market values('U-CFOB+8', 'P', 'A', 'U-CFOB+8.00', 
'SEPTEMBER CARGOES FOB + 8.00', 1)
go

insert into market values('UKC', 'P', 'A', 'STG CROSS RATES', 
'STERLING CROSS RATES', 1)
go

insert into market values('UNITE/LA', 'P', 'A', 'KOCHGATEWAY LAP', 
'KOCH GATEWAY PIPELINE CO. LOUISIANA', 1)
go

insert into market values('UNITE/TX', 'P', 'N', 'KOCHGATEWAY TXP', 
'KOCH GATEWAY PIPELINE CO. TEXAS', 1)
go

insert into market values('US', 'P', 'N', 'USD/WGC', 'USD TO GERMAN MARK', 1)
go

insert into market values('USD', 'P', 'A', 'USD CROSS RATES', 'USD CROSS RATES', 
1)
go

insert into market values('USGCPL54', 'P', 'N', 'USGC PL 54', 
'US GULF COAST PIPE LINE 54', 1)
go

insert into market values('USGCPL55', 'P', 'N', 'USGC PL 55', 
'US GULF COAST PIPELINE 55', 1)
go

insert into market values('USGCPLLS', 'P', 'I', 'USG LS PIPE', 
'U.S. GULF LOW SULFUR PIPELINE', 1)
go

insert into market values('USGCWB54', 'P', 'A', 'USGC WB 54', 
'US GULF COAST WATERBORNE 54', 1)
go

insert into market values('USGCWB55', 'P', 'N', 'USGC WB 55', 
'US GULF COAST WATERBORNE 55', 1)
go

insert into market values('USGCWBLS', 'P', 'I', 'USG LS WB', 
'U.S. GULF LOW SULFUR WATERBORNE', 1)
go

insert into market values('VAL/TX', 'P', 'A', 'VALERO N.GAS TX', 
'VALERO TRANSMISSION L.P. TEXAS', 1)
go

insert into market values('VENEZUEL', 'P', 'A', 'VENEZUELA', 'VENEZUELA', 1)
go

insert into market values('VENTURA', 'P', 'A', 'VENTURA, IOWA', 'VENTURA, IOWA', 
1)
go

insert into market values('VGO-OPN', 'P', 'A', 'VGO-OPN_INV', 'VGO-OPN_INV', 1)
go

insert into market values('VGOINV', 'P', 'A', 'VGOINV', 'VGOINV', 1)
go

insert into market values('WAFRICA', 'P', 'A', 'WEST AFRICA', 'WEST AFRICA', 1)
go

insert into market values('WCLACARB', 'P', 'A', 'W.C LA CARB UNL', 
'W.C LA CARB UNLEADED PIPELINE', 1)
go

insert into market values('WCLACPRE', 'P', 'A', 'W.C LA PREM CAR', 
'W.C LA CARB PREMIUM UNLD PIPELINE', 1)
go

insert into market values('WCOAST', 'P', 'A', 'WEST COAST', 'WEST COAST', 1)
go

insert into market values('WCSFCARB', 'P', 'A', 'W.C SF CARB UNL', 
'W.C SAN FRANCISCO CARB UNLEADED PIPELINE', 1)
go

insert into market values('WCSFCPRE', 'P', 'A', 'W.C SF PREM CAR', 
'W.C SF PREMIUM UNLEADED CARB', 1)
go

insert into market values('WGC', 'P', 'A', 'DM CROSS RATES', 
'GERMAN MARKS CROSS RATES', 1)
go

insert into market values('WHAVEN', 'P', 'A', 'W''HAVEN', 'W''HAVEN', 1)
go

insert into market values('WM4CORNS', 'P', 'A', 'FOUR CORNERS', 'FOUR CORNERS', 
1)
go

insert into market values('WMCALORE', 'P', 'A', 'CALIF.-OREGON', 
'CALIF.-OREGON BORDER', 1)
go

insert into market values('WMMEAD', 'P', 'A', 'MEAD', 'MEAD', 1)
go

insert into market values('WMMIDCOL', 'P', 'A', 'MID-COLUMBIA', 'MID-COLUMBIA', 
1)
go

insert into market values('WMMIDWAY', 'P', 'A', 'MIDWAY', 'MIDWAY', 1)
go

insert into market values('WMPALVER', 'P', 'A', 'PALO VERDE', 'PALO VERDE', 1)
go

insert into market values('WNG/TOK', 'P', 'A', 'WILLIAMS TX, OK', 
'WILLIAMS NATURAL GAS CO. TEXAS OKLA. KAN', 1)
go

insert into market values('WPG', 'E', 'A', 'WPG', 'WINNIPEG COMMODITY EXCHANGE', 
1)
go

