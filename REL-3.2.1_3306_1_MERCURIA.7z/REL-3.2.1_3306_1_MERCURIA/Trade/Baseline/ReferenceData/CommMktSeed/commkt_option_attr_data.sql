print 'Loading additional seed data into the commkt_option_attr table ...'
go

insert into commkt_option_attr values(1, 'A', 1000.000000, 'BBL', 'BBL', 'P', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199908', 'D', 'D', 'B', 
NULL, NULL, NULL, 'A', '3:00', 'NEW YORK', '', 'N', 60, '1', NULL, NULL, NULL, 
NULL, 'M', NULL, NULL, 'EXCHANGE', NULL, 1,'P')
go

insert into commkt_option_attr values(4, 'A', 42000.000000, 'GAL', 'GAL', 'P', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199407', 'D', 'D', 'B', 
NULL, NULL, NULL, 'A', '3:00', 'NEW YORK', '', 'N', 51, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'EXCHANGE', NULL, 1,'P')
go

insert into commkt_option_attr values(5, 'A', 42000.000000, 'GAL', 'GAL', 'P', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199407', 'D', 'D', 'B', 
NULL, NULL, NULL, 'A', '3:00', 'NEW YORK', '', 'N', 51, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'EXCHANGE', NULL, 1,'P')
go

insert into commkt_option_attr values(135, 'A', 1.000000, 'BBL', 'BBL', 'P', 
'USD', 'A', 'NNNNNNNNNNNN', NULL, NULL, 2.000000, 'SPOT01', 'D', 'D', 'B', NULL, 
NULL, NULL, 'E', '0:00', NULL, '', 'N', 1, '2', NULL, NULL, NULL, NULL, NULL, 
NULL, 2.000000, 'PLATTS', NULL, 1,'P')
go

insert into commkt_option_attr values(213, 'A', 1000.000000, 'BBL', 'BBL', 'C', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199902', 'D', 'D', 'B', 
NULL, NULL, NULL, 'A', '3:00', 'LONDON', '', 'N', 120, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'EXCHANGE', NULL, 1,'P')
go

insert into commkt_option_attr values(215, 'A', 100.000000, 'MT', 'MT', 'P', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199407', 'D', 'D', 'B', 
NULL, NULL, NULL, 'A', '300', 'LONDON', '', 'N', 51, '1', NULL, NULL, NULL, 
NULL, NULL, NULL, NULL, 'EXCHANGE', NULL, 1,'P')
go

insert into commkt_option_attr values(1562, 'A', 10000.000000, 'MMBT', 'MMBT', 
'P', 'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199408', 'D', 'D', 
'B', NULL, NULL, NULL, 'A', '3:00', 'NEW YORK', '', 'N', 51, '1', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'PLATTS', NULL, 1,'P')
go

insert into commkt_option_attr values(1640, 'A', 1000.000000, 'MMBT', 'MMBT', 
'P', 'UKC', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199801', 'D', 'D', 
'B', NULL, NULL, NULL, 'E', '3:10', 'LONDON', '', 'N', 51, '1', NULL, NULL, 
NULL, NULL, NULL, NULL, NULL, 'EXCHANGE', NULL, 1,'P')
go

insert into commkt_option_attr values(2131, 'A', 1000.000000, 'BBL', 'BBL', 'P', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '200001', 'D', 'D', 'B', 
NULL, NULL, NULL, 'A', '3:00', 'NEW YORK', '', 'N', 24, '1', NULL, NULL, NULL, 
NULL, 'M', NULL, NULL, 'EXCHANGE', NULL, 1,'P')
go

