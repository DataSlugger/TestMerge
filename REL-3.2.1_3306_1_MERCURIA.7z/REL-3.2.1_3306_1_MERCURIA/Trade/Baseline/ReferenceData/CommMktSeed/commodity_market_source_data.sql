print 'Loading additional seed data into the commodity_market_source table ...'
go

insert into commodity_market_source values(1, 'EXCHANGE', 'DRI', 'NYMEX', 'N', 
'Y', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1, 'INTERNAL', 'PS1', 'NYMEX', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(2, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2, 'PLATTS', 'DRI', 'PLTSEURO', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(4, 'EXCHANGE', 'DRI', 'NYMEX', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(4, 'INTERNAL', 'DRI', 'NYMEX', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(5, 'EXCHANGE', 'DRI', 'NYMEX', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(5, 'INTERNAL', 'DRI', 'NYMEX', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(12, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(12, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(26, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(26, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(27, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(27, 'PLATTS', 'DRI', 'PLTSEURO', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(28, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(28, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(30, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(31, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 6, 1)
go

insert into commodity_market_source values(31, 'PLATTS', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', 6, 1)
go

insert into commodity_market_source values(34, 'INTERNAL', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(34, 'PLATTS', 'DRI', 'PLTSUSA', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(38, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(38, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(41, 'INTERNAL', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(41, 'PLATTS', 'DRI', 'PLTSUSA', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(53, 'PLATTS', 'DRI', 'PLTSEURO', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(55, 'PLATTS', 'DRI', 'PLTSUSA', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(58, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(58, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(60, 'PLATTS', 'DRI', 'PLTSUSA', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(64, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(65, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(65, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(66, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(66, 'PLATTS', 'DRI', 'PLTSARG', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(72, 'PLATTS', 'DRI', 'PLTSUSA', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(84, 'PLATTS', 'DRI', 'PLTSUSA', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(86, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(91, 'PLATTS', 'DRI', 'PLTSUSA', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(92, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(93, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(94, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(95, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(95, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(96, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(97, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(101, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(102, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(102, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(104, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(105, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(113, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(117, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 6, 1)
go

insert into commodity_market_source values(117, 'PLATTS', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', 6, 1)
go

insert into commodity_market_source values(125, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(126, 'PLATTS', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(131, 'PLATTS', 'DRI', 'NYMEX', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(135, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(135, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(137, 'PLATTS', 'DRI', 'NYMEX', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(140, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(140, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(141, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(143, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(143, 'PLATTS', 'DRI', 'PLTSMKTW', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(144, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(146, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(149, 'KOCH', 'DRI', 'USA', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(149, 'PLATTS', 'DRI', 'NYMEX', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(150, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(164, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(168, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(168, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(170, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(187, 'PLATTS', 'DRI', 'NYMEX', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(201, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(201, 'PLATTS', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(201, 'PLATTSPT', 'DRI', 'USA', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(203, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(203, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(204, 'INTERNAL', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(204, 'PLATTS', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(207, 'PLATTS', 'DRI', 'PLTSSING', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(210, 'PLATTS', 'DRI', 'PLTSSING', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(213, 'EXCHANGE', 'DRI', 'IPE', 'N', 
'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(213, 'INTERNAL', 'DRI', 'IPE', 'N', 
'Y', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(215, 'EXCHANGE', 'DRI', 'IPE', NULL, 
NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(215, 'INTERNAL', 'DRI', 'IPE', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(227, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(227, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(228, 'INTERNAL', 'PS1', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(228, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(229, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(229, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(230, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(230, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(231, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(232, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(232, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(234, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(234, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(236, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(237, 'ARGUS', 'DRI', 'PLTSEURO', 'N', 
'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(237, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(237, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(240, 'INTERNAL', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(240, 'PLATTS', 'DRI', 'PLTSSING', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(242, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(242, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(243, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(243, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(251, 'APPI', 'APPI', 'PLTSSING', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(251, 'PLATTS', 'DRI', 'PLTSSING', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(257, 'APPI', 'DRI', 'PLTSSING', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(257, 'PLATTS', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(348, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(400, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(400, 'PLATTS', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(402, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(402, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(800, 'PLATTS', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(801, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(801, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(802, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(808, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(809, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(814, 'PLATTS', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(818, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(821, 'PLATTS', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(829, 'EXCHANGE', 'DRI', 'NYMEX', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(883, 'INTERNAL', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(883, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(899, 'INTERNAL', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(899, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(902, 'INTERNAL', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(902, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(966, 'INTERNAL', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(966, 'PLATTS', 'DRI', 'PLTSSING', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(1248, 'APPI', 'DRI', 'APISTATS', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1248, 'INTERNAL', 'DRI', 'APISTATS', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(1250, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(1251, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(1252, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1252, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(1347, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1347, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(1348, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1348, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(1429, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1442, 'PLATTS', 'DRI', 'PLTSUSA', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(1447, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1447, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(1449, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1449, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(1450, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1450, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(1541, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1541, 'PLATTS', 'DRI', 'PLTSEURO', 
NULL, NULL, NULL, NULL, NULL, 1)
go

insert into commodity_market_source values(1554, 'PLATTS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1555, 'PLATTS', 'DRI', 'IPE', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1557, 'APPI', 'APPI', 'APISTATS', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1559, 'PLATTS', 'DRI', 'IPE', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1562, 'EXCHANGE', 'DRI', 'NYMEX', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1564, 'APPI', 'APPI', 'APISTATS', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1568, 'PLATTS', 'DEWITT', 'PLTSEURO', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1569, 'APPI', 'DRI', 'PLTSSING', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1569, 'PLATTS', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1570, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1571, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1573, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1575, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1579, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1583, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1587, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1594, 'PLATTS', 'DRI', 'APISTATS', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1596, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1599, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1603, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1610, 'APPI', 'DRI', 'APISTATS', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1610, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1612, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1615, 'PLATTS', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1617, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1623, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1624, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1625, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1628, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1629, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1631, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1637, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1638, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1640, 'EXCHANGE', 'DRI', 'IPE', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1641, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(1641, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1643, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(1643, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1661, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1661, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1662, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1673, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1683, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1687, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1688, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1689, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1690, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1693, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1699, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1700, 'PLATTS', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1701, 'PLATTS', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1729, 'FERC', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1731, 'FERC', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1733, 'FERC', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1744, 'PLATTS', 'DRI', 'NYMEX', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1776, 'FERC', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1777, 'FERC', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1780, 'FERC', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1790, 'FERC', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1796, 'FERC', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1813, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1814, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1817, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1819, 'PLATTS', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1820, 'PLATTS', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1822, 'PLATTS', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1824, 'PLATTS', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1832, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(1832, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(1835, 'PLATTS', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1836, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1836, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1837, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1838, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1839, 'PLATTS', 'PS1', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1840, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1841, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1847, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1848, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1849, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1851, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1852, 'ARGUS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1852, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1854, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1855, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1856, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1857, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1859, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1868, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1869, 'PLATTS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1870, 'ARGUS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1870, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1871, 'ARGUS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1871, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1875, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1876, 'PLATTS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1877, 'FERC', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1878, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1879, 'OPIS', 'OPIS', 'USA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1879, 'PLATTS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1880, 'ARGUS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1882, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1883, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1884, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1885, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1886, 'ARGUS', 'PS1', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1887, 'ARGUS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1887, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1891, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1892, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1893, 'ARGUS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1894, 'ARGUS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1894, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1895, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1896, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1897, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1899, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1903, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1905, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1907, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1907, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1908, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1908, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1910, 'ARGUS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1910, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1910, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1911, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1913, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1916, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1917, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1918, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1919, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1920, 'INTERNAL', 'PS1', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1920, 'PLATTS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1923, 'PLATTS', 'PS1', 'IPE', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1926, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1927, 'PLATTS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1932, 'PLATTS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1933, 'ARGUS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1934, 'EXCHANGE', 'DRI', 'NYMEX', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1936, 'ARGUS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1937, 'ARGUS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1938, 'ARGUS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1939, 'PLATTS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1940, 'ARGUS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(1945, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1946, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1946, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1947, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1951, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1953, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1955, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(1956, 'PLATTS', 'PS1', 'PLTSUSA', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(1958, 'KOCH', 'DRI', 'USA', 'N', 'N', 
'N', 'N', 4, 1)
go

insert into commodity_market_source values(1959, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1960, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(1960, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1962, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1968, 'INTERNAL', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1969, 'INTERNAL', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1970, 'SUNREF', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1971, 'INTERNAL', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1972, 'SCURPERM', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1973, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1974, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(1974, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(1975, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(1975, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(1976, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1976, 'PLATTS', 'PS1', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1978, 'ARGUS', 'DRI', 'SIMEX', 'N', 
'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(1979, 'INTERNAL', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1980, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1986, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1987, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1988, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1989, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1990, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1991, 'INTERNAL', 'DRI', 'USA', 'N', 
'Y', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(1996, 'INTERNAL', 'BSI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1997, 'INTERNAL', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(1999, 'INTERNAL', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2001, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2002, 'PLATTS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2003, 'PLATTS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2006, 'INTERNAL', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2007, 'INTERNAL', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2009, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2010, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2011, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2012, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2012, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(2013, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2014, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2014, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2015, 'PLATTS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2016, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2016, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2017, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2017, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2018, 'EXCHANGE', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2019, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2019, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(2021, 'INTERNAL', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2023, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2023, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2024, 'INTERNAL', 'PS1', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2026, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2027, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2028, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2029, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2031, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2034, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2036, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2038, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2041, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2043, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2049, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2050, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2051, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2052, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2053, 'PLATTSPT', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2054, 'PLATTSPT', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2055, 'PLATTSPT', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2056, 'PLATTSPT', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2057, 'PLATTSPT', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2058, 'PLATTSPT', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2059, 'PLATTSPT', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2060, 'PLATTSPT', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2061, 'PLATTSPT', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2063, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(2064, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(2065, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2065, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', NULL, 1)
go

insert into commodity_market_source values(2067, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2067, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2070, 'INTERNAL', 'DRI', 'CANADAGA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2072, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2075, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2075, 'PLATTS', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2076, 'EXCHANGE', 'DRI', 'NYMEX', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2077, 'EXCHANGE', 'DRI', 'NYMEX', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2078, 'EXCHANGE', 'DRI', 'NYMEX', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2080, 'INTERNAL', 'DRI', 'NYMEX', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2081, 'INTERNAL', 'DRI', 'NYMEX', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2082, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2089, 'INTERNAL', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2090, 'EXCHANGE', 'DRI', 'IPE', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2094, 'INTERNAL', 'DRI', 'IPE', 'N', 
'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(2095, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(2098, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2099, 'EOTT POS', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2099, 'INTERNAL', 'DRI', 'USA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2100, 'PLATTSPT', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2102, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(2103, 'INTERNAL', 'PS1', 'USA', 'N', 
'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2104, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2105, 'INTERNAL', 'DRI', 'IPE', 'N', 
'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2107, 'ARGUS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2108, 'ARGUS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2108, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2126, 'INTERNAL', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(2129, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2129, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2130, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2131, 'EXCHANGE', 'DRI', 'NYMEX', 
'N', 'Y', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(2132, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2132, 'PLATTS', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2135, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2138, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2139, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(2141, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2142, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2143, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2144, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2145, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2146, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2147, 'INTERNAL', 'DRI', 'PLTSMKTW', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2148, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2148, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2149, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2149, 'PLATTS', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2151, 'INTERNAL', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2151, 'PLATTS', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2155, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 5, 1)
go

insert into commodity_market_source values(2157, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2160, 'INTERNAL', 'DRI', 'PLTSARG', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2160, 'PLATTS', 'PS1', 'PLTSARG', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2161, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2161, 'PLATTS', 'PS1', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2163, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2164, 'INTERNAL', 'PS1', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2171, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2172, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2173, 'INTERNAL', 'PS1', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2174, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2178, 'INTERNAL', 'DRI', 'PLTSSING', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2179, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2183, 'INTERNAL', 'PS1', 'PLTSSING', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2183, 'PLATTS', 'PS1', 'PLTSSING', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2185, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2186, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2188, 'EXCHANGE', 'DRI', 'NYMEX', 
'N', 'Y', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(2190, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 2, 1)
go

insert into commodity_market_source values(2191, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2194, 'INTERNAL', 'DRI', 'PLTSARG', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2195, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2196, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2198, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2199, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2200, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2203, 'PLATTS', 'DRI', 'PLTSARG', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2206, 'INTERNAL', 'DRI', 'PLTSEURO', 
'N', 'N', 'N', 'N', 3, 1)
go

insert into commodity_market_source values(2207, 'FERC', 'DRI', 'PLTSUSA', 'N', 
'N', 'N', 'N', 4, 1)
go

insert into commodity_market_source values(2207, 'INTERNAL', 'DRI', 'PLTSUSA', 
'N', 'N', 'N', 'N', 4, 1)
go

