print 'Loading additional seed data into the commkt_source_alias table ...'
go

insert into commkt_source_alias values(26, 'INTERNAL', 'PS1', 'NWJE', NULL, 1)
go

insert into commkt_source_alias values(31, 'INTERNAL', 'PS1', 'GCHU', NULL, 1)
go

insert into commkt_source_alias values(65, 'INTERNAL', 'PS1', 'NW2GO', NULL, 1)
go

insert into commkt_source_alias values(143, 'INTERNAL', 'PS1', 'DUB', NULL, 1)
go

insert into commkt_source_alias values(168, 'INTERNAL', 'PS1', 'GCHO', NULL, 1)
go

insert into commkt_source_alias values(201, 'INTERNAL', 'PS1', 'MCM', NULL, 1)
go

insert into commkt_source_alias values(204, 'INTERNAL', 'PS1', 'SP180F', NULL, 
1)
go

insert into commkt_source_alias values(232, 'INTERNAL', 'PS1', 'GC3FO', NULL, 1)
go

insert into commkt_source_alias values(234, 'INTERNAL', 'PS1', 'NW1FO', NULL, 1)
go

insert into commkt_source_alias values(242, 'INTERNAL', 'PS1', 'NW35FO', NULL, 
1)
go

insert into commkt_source_alias values(1252, 'INTERNAL', 'PS1', 'NWEPU', NULL, 
1)
go

insert into commkt_source_alias values(1450, 'INTERNAL', 'PS1', 'NW590', NULL, 
1)
go

insert into commkt_source_alias values(1562, 'EXCHANGE', 'PS1', 'XNNG', NULL, 1)
go

insert into commkt_source_alias values(1641, 'INTERNAL', 'PS1', 'GCJE', NULL, 1)
go

insert into commkt_source_alias values(1920, 'INTERNAL', 'PS1', 'GCLS', NULL, 1)
go

