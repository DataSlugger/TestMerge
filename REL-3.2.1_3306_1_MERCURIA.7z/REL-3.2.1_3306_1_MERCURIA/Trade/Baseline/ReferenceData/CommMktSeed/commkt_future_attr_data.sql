print 'Loading additional seed data into the commkt_future_attr table ...'
go

insert into commkt_future_attr values(1, 'A', 1000.000000, 'BBL', 'BBL', 'P', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199809', 'D', 'D', 'B', 
NULL, NULL, NULL, 'N', 'N', 100, '1', 'NYMEX', NULL, NULL, NULL, 'M', NULL, 'Y', 
NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_future_attr values(4, 'A', 42000.000000, 'GAL', 'GAL', 'P', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199407', 'D', 'D', 'B', 
NULL, NULL, NULL, 'N', 'N', 51, '1', 'NYMEX', NULL, NULL, NULL, NULL, NULL, 'Y', 
NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_future_attr values(5, 'A', 42000.000000, 'GAL', 'GAL', 'C', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199407', 'D', 'D', 'B', 
NULL, NULL, NULL, 'N', 'N', 51, '1', 'NYMEX', NULL, NULL, NULL, NULL, NULL, 'Y', 
NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_future_attr values(213, 'A', 1000.000000, 'BBL', 'BBL', 'C', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199902', 'D', 'D', 'B', 
NULL, NULL, NULL, 'N', 'N', 111, '1', 'IPE', NULL, NULL, NULL, NULL, NULL, 'Y', 
NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_future_attr values(215, 'A', 100.000000, 'MT', 'MT', 'C', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '200012', 'D', 'D', 'B', 
NULL, NULL, NULL, 'N', 'N', 60, '1', 'IPE', NULL, NULL, NULL, NULL, NULL, 'Y', 
NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_future_attr values(829, 'A', 1000.000000, 'BBL', 'BBL', 'P', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', 0.010000, 1.000000, '199811', 'D', 'D', 'M', 
NULL, NULL, NULL, '', 'N', 18, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_future_attr values(1562, 'A', 10000.000000, 'MMBT', 'MMBT', 
'P', 'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199408', 'D', 'D', 
'B', NULL, NULL, NULL, ')', 'N', 51, '1', 'NYMEX', NULL, NULL, NULL, NULL, NULL, 
'Y', NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_future_attr values(1640, 'A', 1000.000000, 'THER', 'THER', 
'P', 'UKC', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199903', 'D', 'D', 
'B', NULL, NULL, NULL, ')', 'N', 51, '1', 'IPE', NULL, NULL, NULL, NULL, NULL, 
'Y', NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_future_attr values(1744, 'A', 10000.000000, 'MMBT', 'MMBT', 
'P', 'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '199408', 'D', 'D', 
'B', NULL, NULL, NULL, ')', 'N', 51, '1', 'KCBT', NULL, NULL, NULL, NULL, NULL, 
'Y', NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_future_attr values(1934, 'A', 42000.000000, 'GAL', 'GAL', 
'C', 'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, 'SPOT', 'D', 'D', 'B', 
NULL, NULL, NULL, ')', 'N', 24, '1', 'NYMEX', NULL, 'NYMEX', NULL, 'M', NULL, 
'Y', NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_future_attr values(2018, 'A', 1000.000000, 'BBL', 'GAL', 
NULL, 'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, NULL, '199901', 'D', 'D', 'M', 
NULL, NULL, NULL, ')', 'N', 18, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, 'EXCHANGE', 'DRI', 1)
go

insert into commkt_future_attr values(2077, 'A', 1000.000000, 'BBL', 'BBL', 'C', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYNN', NULL, NULL, '199908', 'D', 'D', 'B', NULL, 
NULL, NULL, ')', 'N', 12, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
'EXCHANGE', NULL, 1)
go

insert into commkt_future_attr values(2078, 'A', 1000.000000, 'MB', 'BBL', NULL, 
'USD', 'A', 'YYYYYYYYYYYY', 'YYNN', NULL, NULL, '199908', 'D', 'D', 'B', NULL, 
NULL, NULL, ')', 'N', 12, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
'EXCHANGE', NULL, 1)
go

insert into commkt_future_attr values(2090, 'A', 100.000000, 'MT', 'MT', NULL, 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, NULL, 'SPOT01', 'D', 'D', 'B', NULL, 
NULL, NULL, ')', 'N', 36, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
'EXCHANGE', 'EXCHANGE', 1)
go

insert into commkt_future_attr values(2131, 'A', 1000.000000, 'BBL', 'BBL', 'P', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '200001', 'D', 'D', 'B', 
NULL, NULL, NULL, ')', 'N', 24, '1', 'NYMEX', NULL, NULL, NULL, 'M', NULL, 'Y', 
NULL, 'INTERNAL', NULL, 1)
go

insert into commkt_future_attr values(2188, 'A', 1000.000000, 'BBL', 'BBL', 'P', 
'USD', 'A', 'YYYYYYYYYYYY', 'YYYY', NULL, 2.000000, '200005', 'D', 'D', 'B', 
NULL, NULL, NULL, ')', 'N', 60, '1', 'NYMEX', NULL, NULL, NULL, 'M', NULL, 'Y', 
NULL, 'INTERNAL', NULL, 1)
go

