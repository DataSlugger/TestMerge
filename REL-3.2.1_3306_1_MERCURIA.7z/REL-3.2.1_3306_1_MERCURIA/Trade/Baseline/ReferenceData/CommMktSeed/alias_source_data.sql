insert into alias_source values('ARGUS', 'X', 'ARGUS', 1)
go

insert into alias_source values('EOTT POS', 'X', 'EOTT POS', 1)
go

insert into alias_source values('EXCHANGE', 'X', 'EXCHANGE', 1)
go

insert into alias_source values('FERC', 'X', 'FERC', 1)
go

insert into alias_source values('ICIS-LOR', 'X', 'ICIS-LOR', 1)
go

insert into alias_source values('INTERNAL', 'X', 'INTERNAL SOURCE', 1)
go

insert into alias_source values('KOCH', 'X', 'KOCH', 1)
go

insert into alias_source values('PLATTS', 'X', 'PLATTS', 1)
go

insert into alias_source values('PLATTSPT', 'X', 'PLATTSPT', 1)
go

insert into alias_source values('SCURPERM', 'X', 'SCURPERM', 1)
go

insert into alias_source values('SUNREF', 'X', 'SUNREF', 1)
go








