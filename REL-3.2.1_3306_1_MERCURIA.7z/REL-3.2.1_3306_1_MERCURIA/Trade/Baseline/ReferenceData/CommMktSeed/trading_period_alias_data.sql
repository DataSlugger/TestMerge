print 'Loading additional seed data into the trading_period_alias table ...'
go

insert into trading_period_alias values(1, 'SPOT01', 'EXCHANGE', 'PS1', 'C', 
'XNCL001C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT01', 'EXCHANGE', 'PS1', 'H', 
'XNCL001H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT01', 'EXCHANGE', 'PS1', 'L', 
'XNCL001L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT02', 'EXCHANGE', 'PS1', 'C', 
'XNCL002C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT02', 'EXCHANGE', 'PS1', 'H', 
'XNCL002H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT02', 'EXCHANGE', 'PS1', 'L', 
'XNCL002L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT03', 'EXCHANGE', 'PS1', 'C', 
'XNCL003C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT03', 'EXCHANGE', 'PS1', 'H', 
'XNCL003H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT03', 'EXCHANGE', 'PS1', 'L', 
'XNCL003L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT04', 'EXCHANGE', 'PS1', 'C', 
'XNCL004C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT04', 'EXCHANGE', 'PS1', 'H', 
'XNCL004H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT04', 'EXCHANGE', 'PS1', 'L', 
'XNCL004L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT05', 'EXCHANGE', 'PS1', 'C', 
'XNCL005C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT05', 'EXCHANGE', 'PS1', 'H', 
'XNCL005H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT05', 'EXCHANGE', 'PS1', 'L', 
'XNCL005L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT06', 'EXCHANGE', 'PS1', 'C', 
'XNCL006C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT06', 'EXCHANGE', 'PS1', 'H', 
'XNCL006H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT06', 'EXCHANGE', 'PS1', 'L', 
'XNCL006L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT07', 'EXCHANGE', 'PS1', 'C', 
'XNCL007C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT07', 'EXCHANGE', 'PS1', 'H', 
'XNCL007H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT07', 'EXCHANGE', 'PS1', 'L', 
'XNCL007L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT08', 'EXCHANGE', 'PS1', 'C', 
'XNCL008C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT08', 'EXCHANGE', 'PS1', 'H', 
'XNCL008H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT08', 'EXCHANGE', 'PS1', 'L', 
'XNCL008L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT09', 'EXCHANGE', 'PS1', 'C', 
'XNCL009C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT09', 'EXCHANGE', 'PS1', 'H', 
'XNCL009H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT09', 'EXCHANGE', 'PS1', 'L', 
'XNCL009L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT10', 'EXCHANGE', 'PS1', 'C', 
'XNCL010C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT10', 'EXCHANGE', 'PS1', 'H', 
'XNCL010H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT10', 'EXCHANGE', 'PS1', 'L', 
'XNCL010L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT11', 'EXCHANGE', 'PS1', 'C', 
'XNCL011C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT11', 'EXCHANGE', 'PS1', 'H', 
'XNCL011H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT11', 'EXCHANGE', 'PS1', 'L', 
'XNCL011L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT12', 'EXCHANGE', 'PS1', 'C', 
'XNCL012C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT12', 'EXCHANGE', 'PS1', 'H', 
'XNCL012H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT12', 'EXCHANGE', 'PS1', 'L', 
'XNCL012L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT13', 'EXCHANGE', 'PS1', 'C', 
'XNCL013C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT13', 'EXCHANGE', 'PS1', 'H', 
'XNCL013H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT13', 'EXCHANGE', 'PS1', 'L', 
'XNCL013L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT14', 'EXCHANGE', 'PS1', 'C', 
'XNCL014C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT14', 'EXCHANGE', 'PS1', 'H', 
'XNCL014H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT14', 'EXCHANGE', 'PS1', 'L', 
'XNCL014L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT15', 'EXCHANGE', 'PS1', 'C', 
'XNCL015C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT15', 'EXCHANGE', 'PS1', 'H', 
'XNCL015H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT15', 'EXCHANGE', 'PS1', 'L', 
'XNCL015L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT16', 'EXCHANGE', 'PS1', 'C', 
'XNCL016C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT16', 'EXCHANGE', 'PS1', 'H', 
'XNCL016H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT16', 'EXCHANGE', 'PS1', 'L', 
'XNCL016L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT17', 'EXCHANGE', 'PS1', 'C', 
'XNCL017C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT17', 'EXCHANGE', 'PS1', 'H', 
'XNCL017H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT17', 'EXCHANGE', 'PS1', 'L', 
'XNCL017L', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT18', 'EXCHANGE', 'PS1', 'C', 
'XNCL018C', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT18', 'EXCHANGE', 'PS1', 'H', 
'XNCL018H', NULL, 1)
go

insert into trading_period_alias values(1, 'SPOT18', 'EXCHANGE', 'PS1', 'L', 
'XNCL018L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT01', 'EXCHANGE', 'PS1', 'C', 
'XNHU001C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT01', 'EXCHANGE', 'PS1', 'H', 
'XNHU001H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT01', 'EXCHANGE', 'PS1', 'L', 
'XNHU001L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT02', 'EXCHANGE', 'PS1', 'C', 
'XNHU002C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT02', 'EXCHANGE', 'PS1', 'H', 
'XNHU002H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT02', 'EXCHANGE', 'PS1', 'L', 
'XNHU002L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT03', 'EXCHANGE', 'PS1', 'C', 
'XNHU003C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT03', 'EXCHANGE', 'PS1', 'H', 
'XNHU003H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT03', 'EXCHANGE', 'PS1', 'L', 
'XNHU003L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT04', 'EXCHANGE', 'PS1', 'C', 
'XNHU004C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT04', 'EXCHANGE', 'PS1', 'H', 
'XNHU004H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT04', 'EXCHANGE', 'PS1', 'L', 
'XNHU004L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT05', 'EXCHANGE', 'PS1', 'C', 
'XNHU005C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT05', 'EXCHANGE', 'PS1', 'H', 
'XNHU005H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT05', 'EXCHANGE', 'PS1', 'L', 
'XNHU005L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT06', 'EXCHANGE', 'PS1', 'C', 
'XNHU006C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT06', 'EXCHANGE', 'PS1', 'H', 
'XNHU006H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT06', 'EXCHANGE', 'PS1', 'L', 
'XNHU006L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT07', 'EXCHANGE', 'PS1', 'C', 
'XNHU007C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT07', 'EXCHANGE', 'PS1', 'H', 
'XNHU007H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT07', 'EXCHANGE', 'PS1', 'L', 
'XNHU007L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT08', 'EXCHANGE', 'PS1', 'C', 
'XNHU008C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT08', 'EXCHANGE', 'PS1', 'H', 
'XNHU008H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT08', 'EXCHANGE', 'PS1', 'L', 
'XNHU008L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT09', 'EXCHANGE', 'PS1', 'C', 
'XNHU009C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT09', 'EXCHANGE', 'PS1', 'H', 
'XNHU009H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT09', 'EXCHANGE', 'PS1', 'L', 
'XNHU009L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT10', 'EXCHANGE', 'PS1', 'C', 
'XNHU010C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT10', 'EXCHANGE', 'PS1', 'H', 
'XNHU010H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT10', 'EXCHANGE', 'PS1', 'L', 
'XNHU010L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT11', 'EXCHANGE', 'PS1', 'C', 
'XNHU011C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT11', 'EXCHANGE', 'PS1', 'H', 
'XNHU011H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT11', 'EXCHANGE', 'PS1', 'L', 
'XNHU011L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT12', 'EXCHANGE', 'PS1', 'C', 
'XNHU012C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT12', 'EXCHANGE', 'PS1', 'H', 
'XNHU012H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT12', 'EXCHANGE', 'PS1', 'L', 
'XNHU012L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT13', 'EXCHANGE', 'PS1', 'C', 
'XNHU013C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT13', 'EXCHANGE', 'PS1', 'H', 
'XNHU013H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT13', 'EXCHANGE', 'PS1', 'L', 
'XNHU013L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT14', 'EXCHANGE', 'PS1', 'C', 
'XNHU014C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT14', 'EXCHANGE', 'PS1', 'H', 
'XNHU014H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT14', 'EXCHANGE', 'PS1', 'L', 
'XNHU014L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT15', 'EXCHANGE', 'PS1', 'C', 
'XNHU015C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT15', 'EXCHANGE', 'PS1', 'H', 
'XNHU015H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT15', 'EXCHANGE', 'PS1', 'L', 
'XNHU015L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT16', 'EXCHANGE', 'PS1', 'C', 
'XNHU016C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT16', 'EXCHANGE', 'PS1', 'H', 
'XNHU016H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT16', 'EXCHANGE', 'PS1', 'L', 
'XNHU016L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT17', 'EXCHANGE', 'PS1', 'C', 
'XNHU017C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT17', 'EXCHANGE', 'PS1', 'H', 
'XNHU017H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT17', 'EXCHANGE', 'PS1', 'L', 
'XNHU017L', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT18', 'EXCHANGE', 'PS1', 'C', 
'XNHU018C', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT18', 'EXCHANGE', 'PS1', 'H', 
'XNHU018H', NULL, 1)
go

insert into trading_period_alias values(4, 'SPOT18', 'EXCHANGE', 'PS1', 'L', 
'XNHU018L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT01', 'EXCHANGE', 'PS1', 'C', 
'XNHO001C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT01', 'EXCHANGE', 'PS1', 'H', 
'XNHO001H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT01', 'EXCHANGE', 'PS1', 'H', 
'XNHO001L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT02', 'EXCHANGE', 'PS1', 'C', 
'XNHO002C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT02', 'EXCHANGE', 'PS1', 'H', 
'XNHO002H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT02', 'EXCHANGE', 'PS1', 'L', 
'XNHO002L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT03', 'EXCHANGE', 'PS1', 'C', 
'XNHO003C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT03', 'EXCHANGE', 'PS1', 'H', 
'XNHO003H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT03', 'EXCHANGE', 'PS1', 'L', 
'XNHO003L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT04', 'EXCHANGE', 'PS1', 'C', 
'XNHO004C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT04', 'EXCHANGE', 'PS1', 'H', 
'XNHO004H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT04', 'EXCHANGE', 'PS1', 'L', 
'XNHO004L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT05', 'EXCHANGE', 'PS1', 'C', 
'XNHO005C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT05', 'EXCHANGE', 'PS1', 'H', 
'XNHO005H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT05', 'EXCHANGE', 'PS1', 'L', 
'XNHO005L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT06', 'EXCHANGE', 'PS1', 'C', 
'XNHO006C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT06', 'EXCHANGE', 'PS1', 'H', 
'XNHO006H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT06', 'EXCHANGE', 'PS1', 'L', 
'XNHO006L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT07', 'EXCHANGE', 'PS1', 'C', 
'XNHO007C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT07', 'EXCHANGE', 'PS1', 'H', 
'XNHO007H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT07', 'EXCHANGE', 'PS1', 'L', 
'XNHO007L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT08', 'EXCHANGE', 'PS1', 'C', 
'XNHO008C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT08', 'EXCHANGE', 'PS1', 'H', 
'XNHO008H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT08', 'EXCHANGE', 'PS1', 'L', 
'XNHO008L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT09', 'EXCHANGE', 'PS1', 'C', 
'XNHO009C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT09', 'EXCHANGE', 'PS1', 'H', 
'XNHO009H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT09', 'EXCHANGE', 'PS1', 'L', 
'XNHO009L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT10', 'EXCHANGE', 'PS1', 'C', 
'XNHO0010C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT10', 'EXCHANGE', 'PS1', 'C', 
'XNHO010C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT10', 'EXCHANGE', 'PS1', 'H', 
'XNHO0010H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT10', 'EXCHANGE', 'PS1', 'H', 
'XNHO010H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT10', 'EXCHANGE', 'PS1', 'L', 
'XNHO010L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT11', 'EXCHANGE', 'PS1', 'C', 
'XNHO011C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT11', 'EXCHANGE', 'PS1', 'H', 
'XNHO011H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT11', 'EXCHANGE', 'PS1', 'L', 
'XNHO011L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT12', 'EXCHANGE', 'PS1', 'C', 
'XNHO012C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT12', 'EXCHANGE', 'PS1', 'H', 
'XNHO012H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT12', 'EXCHANGE', 'PS1', 'L', 
'XNHO012L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT13', 'EXCHANGE', 'PS1', 'C', 
'XNHO013C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT13', 'EXCHANGE', 'PS1', 'H', 
'XNHO013H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT13', 'EXCHANGE', 'PS1', 'L', 
'XNHO013L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT14', 'EXCHANGE', 'PS1', 'C', 
'XNHO014C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT14', 'EXCHANGE', 'PS1', 'H', 
'XNHO014H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT14', 'EXCHANGE', 'PS1', 'L', 
'XNHO014L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT15', 'EXCHANGE', 'PS1', 'C', 
'XNHO015C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT15', 'EXCHANGE', 'PS1', 'H', 
'XNHO015H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT15', 'EXCHANGE', 'PS1', 'L', 
'XNHO015L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT16', 'EXCHANGE', 'PS1', 'C', 
'XNHO016C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT16', 'EXCHANGE', 'PS1', 'H', 
'XNHO016H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT16', 'EXCHANGE', 'PS1', 'L', 
'XNHO016L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT17', 'EXCHANGE', 'PS1', 'C', 
'XNHO017C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT17', 'EXCHANGE', 'PS1', 'H', 
'XNHO017H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT17', 'EXCHANGE', 'PS1', 'L', 
'XNHO017L', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT18', 'EXCHANGE', 'PS1', 'C', 
'XNHO018C', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT18', 'EXCHANGE', 'PS1', 'H', 
'XNHO018H', NULL, 1)
go

insert into trading_period_alias values(5, 'SPOT18', 'EXCHANGE', 'PS1', 'L', 
'XNHO018L', NULL, 1)
go

insert into trading_period_alias values(12, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PJABA00H', NULL, 1)
go

insert into trading_period_alias values(12, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PJABA00L', NULL, 1)
go

insert into trading_period_alias values(26, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PJAAU00H', NULL, 1)
go

insert into trading_period_alias values(26, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PJAAU00L', NULL, 1)
go

insert into trading_period_alias values(27, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PAAAL00H', NULL, 1)
go

insert into trading_period_alias values(27, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PAAAL00L', NULL, 1)
go

insert into trading_period_alias values(28, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAAD00H', NULL, 1)
go

insert into trading_period_alias values(28, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAAD00L', NULL, 1)
go

insert into trading_period_alias values(30, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABU00H', NULL, 1)
go

insert into trading_period_alias values(30, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABU00L', NULL, 1)
go

insert into trading_period_alias values(31, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGACT00H', NULL, 1)
go

insert into trading_period_alias values(31, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGACT00L', NULL, 1)
go

insert into trading_period_alias values(38, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAAG00H', NULL, 1)
go

insert into trading_period_alias values(38, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAAG00L', NULL, 1)
go

insert into trading_period_alias values(41, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAAX00H', NULL, 1)
go

insert into trading_period_alias values(41, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAAX00L', NULL, 1)
go

insert into trading_period_alias values(53, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAAU10H', NULL, 1)
go

insert into trading_period_alias values(53, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAAU10L', NULL, 1)
go

insert into trading_period_alias values(55, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAJB00H', NULL, 1)
go

insert into trading_period_alias values(55, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAJB00L', NULL, 1)
go

insert into trading_period_alias values(58, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PJAAV00H', NULL, 1)
go

insert into trading_period_alias values(58, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PJAAV00L', NULL, 1)
go

insert into trading_period_alias values(60, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAIX00H', NULL, 1)
go

insert into trading_period_alias values(60, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAIX00L', NULL, 1)
go

insert into trading_period_alias values(64, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABY00H', NULL, 1)
go

insert into trading_period_alias values(64, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABY00L', NULL, 1)
go

insert into trading_period_alias values(65, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAAC00H', NULL, 1)
go

insert into trading_period_alias values(65, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAAC00L', NULL, 1)
go

insert into trading_period_alias values(66, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAAT00H', NULL, 1)
go

insert into trading_period_alias values(66, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAAT00L', NULL, 1)
go

insert into trading_period_alias values(72, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABG00H', NULL, 1)
go

insert into trading_period_alias values(72, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABG00L', NULL, 1)
go

insert into trading_period_alias values(84, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PJAAD10H', NULL, 1)
go

insert into trading_period_alias values(84, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PJAAD10L', NULL, 1)
go

insert into trading_period_alias values(86, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGACZ00H', NULL, 1)
go

insert into trading_period_alias values(86, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGACZ00L', NULL, 1)
go

insert into trading_period_alias values(91, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGACP00H', NULL, 1)
go

insert into trading_period_alias values(91, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGACP00L', NULL, 1)
go

insert into trading_period_alias values(93, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABX00H', NULL, 1)
go

insert into trading_period_alias values(93, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABX00L', NULL, 1)
go

insert into trading_period_alias values(94, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAAG00H', NULL, 1)
go

insert into trading_period_alias values(94, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAAG00L', NULL, 1)
go

insert into trading_period_alias values(95, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGADE00H', NULL, 1)
go

insert into trading_period_alias values(95, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGADE00L', NULL, 1)
go

insert into trading_period_alias values(97, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABW00H', NULL, 1)
go

insert into trading_period_alias values(97, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABW00L', NULL, 1)
go

insert into trading_period_alias values(101, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAAB00H', NULL, 1)
go

insert into trading_period_alias values(101, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAAB00L', NULL, 1)
go

insert into trading_period_alias values(102, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PJAAT00H', NULL, 1)
go

insert into trading_period_alias values(102, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PJAAT00L', NULL, 1)
go

insert into trading_period_alias values(104, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABV00H', NULL, 1)
go

insert into trading_period_alias values(104, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABV00L', NULL, 1)
go

insert into trading_period_alias values(105, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PJAAP00H', NULL, 1)
go

insert into trading_period_alias values(105, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PJAAP00L', NULL, 1)
go

insert into trading_period_alias values(113, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PAAAC00H', NULL, 1)
go

insert into trading_period_alias values(113, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PAAAC00L', NULL, 1)
go

insert into trading_period_alias values(117, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGADC00H', NULL, 1)
go

insert into trading_period_alias values(117, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGADC00L', NULL, 1)
go

insert into trading_period_alias values(125, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAIC00H', NULL, 1)
go

insert into trading_period_alias values(125, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAIC00L', NULL, 1)
go

insert into trading_period_alias values(131, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCADE00H', NULL, 1)
go

insert into trading_period_alias values(131, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCADE00L', NULL, 1)
go

insert into trading_period_alias values(135, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'PCAAP00H', NULL, 1)
go

insert into trading_period_alias values(135, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'PCAAP00L', NULL, 1)
go

insert into trading_period_alias values(135, 'SPOT02', 'PLATTS', 'PS1', 'H', 
'PCAAQ00H', NULL, 1)
go

insert into trading_period_alias values(135, 'SPOT02', 'PLATTS', 'PS1', 'L', 
'PCAAQ00L', NULL, 1)
go

insert into trading_period_alias values(135, 'SPOT03', 'PLATTS', 'PS1', 'H', 
'PCAAR00H', NULL, 1)
go

insert into trading_period_alias values(135, 'SPOT03', 'PLATTS', 'PS1', 'L', 
'PCAAR00L', NULL, 1)
go

insert into trading_period_alias values(137, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCABC00H', NULL, 1)
go

insert into trading_period_alias values(137, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCABC00L', NULL, 1)
go

insert into trading_period_alias values(140, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCADI00H', NULL, 1)
go

insert into trading_period_alias values(140, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCADI00L', NULL, 1)
go

insert into trading_period_alias values(141, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAEU00H', NULL, 1)
go

insert into trading_period_alias values(141, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAEU00L', NULL, 1)
go

insert into trading_period_alias values(143, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAAT00H', NULL, 1)
go

insert into trading_period_alias values(143, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAAT00L', NULL, 1)
go

insert into trading_period_alias values(143, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'PCAAT00H', NULL, 1)
go

insert into trading_period_alias values(143, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'PCAAT00L', NULL, 1)
go

insert into trading_period_alias values(143, 'SPOT02', 'PLATTS', 'PS1', 'H', 
'PCAAU00H', NULL, 1)
go

insert into trading_period_alias values(143, 'SPOT02', 'PLATTS', 'PS1', 'L', 
'PCAAU00L', NULL, 1)
go

insert into trading_period_alias values(143, 'SPOT03', 'PLATTS', 'PS1', 'H', 
'PCAAV00H', NULL, 1)
go

insert into trading_period_alias values(143, 'SPOT03', 'PLATTS', 'PS1', 'L', 
'PCAAV00L', NULL, 1)
go

insert into trading_period_alias values(144, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCABS00H', NULL, 1)
go

insert into trading_period_alias values(144, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCABS00L', NULL, 1)
go

insert into trading_period_alias values(144, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'PCABS00H', NULL, 1)
go

insert into trading_period_alias values(144, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'PCABS00L', NULL, 1)
go

insert into trading_period_alias values(146, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCACE00H', NULL, 1)
go

insert into trading_period_alias values(146, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCACE00L', NULL, 1)
go

insert into trading_period_alias values(149, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCACK00H', NULL, 1)
go

insert into trading_period_alias values(149, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCACK00L', NULL, 1)
go

insert into trading_period_alias values(150, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCABN00H', NULL, 1)
go

insert into trading_period_alias values(150, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCABN00L', NULL, 1)
go

insert into trading_period_alias values(164, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAEH00H', NULL, 1)
go

insert into trading_period_alias values(164, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAEH00L', NULL, 1)
go

insert into trading_period_alias values(168, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAED00H', NULL, 1)
go

insert into trading_period_alias values(168, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAED00L', NULL, 1)
go

insert into trading_period_alias values(168, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'POAFK00H', NULL, 1)
go

insert into trading_period_alias values(168, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'POAFK00L', NULL, 1)
go

insert into trading_period_alias values(170, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAEG00H', NULL, 1)
go

insert into trading_period_alias values(170, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAEG00L', NULL, 1)
go

insert into trading_period_alias values(201, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'PCACG00H', NULL, 1)
go

insert into trading_period_alias values(201, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'PCACG00L', NULL, 1)
go

insert into trading_period_alias values(201, 'SPOT02', 'PLATTS', 'PS1', 'H', 
'PCACH00H', NULL, 1)
go

insert into trading_period_alias values(201, 'SPOT02', 'PLATTS', 'PS1', 'L', 
'PCACH00L', NULL, 1)
go

insert into trading_period_alias values(204, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUADV00H', NULL, 1)
go

insert into trading_period_alias values(204, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUADV00L', NULL, 1)
go

insert into trading_period_alias values(204, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'PUAXZ00H', NULL, 1)
go

insert into trading_period_alias values(204, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'PUAXZ00L', NULL, 1)
go

insert into trading_period_alias values(204, 'SPOT02', 'PLATTS', 'PS1', 'H', 
'PUAYF00H', NULL, 1)
go

insert into trading_period_alias values(204, 'SPOT02', 'PLATTS', 'PS1', 'L', 
'PUAYF00L', NULL, 1)
go

insert into trading_period_alias values(207, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POABC00H', NULL, 1)
go

insert into trading_period_alias values(207, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POABC00L', NULL, 1)
go

insert into trading_period_alias values(210, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAEY00H', NULL, 1)
go

insert into trading_period_alias values(210, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAEY00L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT01', 'EXCHANGE', 'PS1', 'C', 
'XILL001C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT01', 'EXCHANGE', 'PS1', 'H', 
'XILL001H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT01', 'EXCHANGE', 'PS1', 'L', 
'XILL001L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT02', 'EXCHANGE', 'PS1', 'C', 
'XILL002C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT02', 'EXCHANGE', 'PS1', 'H', 
'XILL002H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT02', 'EXCHANGE', 'PS1', 'L', 
'XILL002L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT03', 'EXCHANGE', 'PS1', 'C', 
'XILL003C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT03', 'EXCHANGE', 'PS1', 'H', 
'XILL003H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT03', 'EXCHANGE', 'PS1', 'L', 
'XILL003L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT04', 'EXCHANGE', 'PS1', 'C', 
'XILL004C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT04', 'EXCHANGE', 'PS1', 'H', 
'XILL004H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT04', 'EXCHANGE', 'PS1', 'L', 
'XILL004L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT05', 'EXCHANGE', 'PS1', 'C', 
'XILL005C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT05', 'EXCHANGE', 'PS1', 'H', 
'XILL005H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT05', 'EXCHANGE', 'PS1', 'L', 
'XILL005L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT06', 'EXCHANGE', 'PS1', 'C', 
'XILL006C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT06', 'EXCHANGE', 'PS1', 'H', 
'XILL006H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT06', 'EXCHANGE', 'PS1', 'L', 
'XILL006L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT07', 'EXCHANGE', 'PS1', 'C', 
'XILL007C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT07', 'EXCHANGE', 'PS1', 'H', 
'XILL007H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT07', 'EXCHANGE', 'PS1', 'L', 
'XILL007L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT08', 'EXCHANGE', 'PS1', 'C', 
'XILL008C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT08', 'EXCHANGE', 'PS1', 'H', 
'XILL008H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT08', 'EXCHANGE', 'PS1', 'L', 
'XILL008L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT09', 'EXCHANGE', 'PS1', 'C', 
'XILL009C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT09', 'EXCHANGE', 'PS1', 'H', 
'XILL009H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT09', 'EXCHANGE', 'PS1', 'L', 
'XILL009L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT10', 'EXCHANGE', 'PS1', 'C', 
'XILL010C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT10', 'EXCHANGE', 'PS1', 'H', 
'XILL010H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT10', 'EXCHANGE', 'PS1', 'L', 
'XILL010L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT11', 'EXCHANGE', 'PS1', 'C', 
'XILL011C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT11', 'EXCHANGE', 'PS1', 'H', 
'XILL011H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT11', 'EXCHANGE', 'PS1', 'L', 
'XILL011L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT12', 'EXCHANGE', 'PS1', 'C', 
'XILL012C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT12', 'EXCHANGE', 'PS1', 'H', 
'XILL012H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT12', 'EXCHANGE', 'PS1', 'L', 
'XILL012L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT13', 'EXCHANGE', 'PS1', 'C', 
'XILL013C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT13', 'EXCHANGE', 'PS1', 'H', 
'XILL013H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT13', 'EXCHANGE', 'PS1', 'L', 
'XILL013L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT14', 'EXCHANGE', 'PS1', 'C', 
'XILL014C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT14', 'EXCHANGE', 'PS1', 'H', 
'XILL013H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT14', 'EXCHANGE', 'PS1', 'L', 
'XILL013L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT15', 'EXCHANGE', 'PS1', 'C', 
'XILL015C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT15', 'EXCHANGE', 'PS1', 'H', 
'XILL015H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT15', 'EXCHANGE', 'PS1', 'L', 
'XILL015L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT16', 'EXCHANGE', 'PS1', 'C', 
'XILL016C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT16', 'EXCHANGE', 'PS1', 'H', 
'XILL016H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT16', 'EXCHANGE', 'PS1', 'L', 
'XILL016L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT17', 'EXCHANGE', 'PS1', 'C', 
'XILL017C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT17', 'EXCHANGE', 'PS1', 'H', 
'XILL017H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT17', 'EXCHANGE', 'PS1', 'L', 
'XILL017L', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT18', 'EXCHANGE', 'PS1', 'C', 
'XILL018C', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT18', 'EXCHANGE', 'PS1', 'H', 
'XILL018H', NULL, 1)
go

insert into trading_period_alias values(213, 'SPOT18', 'EXCHANGE', 'PS1', 'L', 
'XILL018L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT01', 'EXCHANGE', 'PS1', 'C', 
'XILO001C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT01', 'EXCHANGE', 'PS1', 'H', 
'XILO001H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT01', 'EXCHANGE', 'PS1', 'L', 
'XILO001L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT02', 'EXCHANGE', 'PS1', 'C', 
'XILO002C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT02', 'EXCHANGE', 'PS1', 'H', 
'XILO002H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT02', 'EXCHANGE', 'PS1', 'L', 
'XILO002L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT03', 'EXCHANGE', 'PS1', 'C', 
'XILO003C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT03', 'EXCHANGE', 'PS1', 'H', 
'XILO003H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT03', 'EXCHANGE', 'PS1', 'L', 
'XILO003L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT04', 'EXCHANGE', 'PS1', 'C', 
'XILO004C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT04', 'EXCHANGE', 'PS1', 'H', 
'XILO004H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT04', 'EXCHANGE', 'PS1', 'L', 
'XILO004L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT05', 'EXCHANGE', 'PS1', 'C', 
'XILO005C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT05', 'EXCHANGE', 'PS1', 'H', 
'XILO005H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT05', 'EXCHANGE', 'PS1', 'L', 
'XILO005L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT06', 'EXCHANGE', 'PS1', 'C', 
'XILO006C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT06', 'EXCHANGE', 'PS1', 'H', 
'XILO006H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT06', 'EXCHANGE', 'PS1', 'L', 
'XILO006L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT07', 'EXCHANGE', 'PS1', 'C', 
'XILO007C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT07', 'EXCHANGE', 'PS1', 'H', 
'XILO007H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT07', 'EXCHANGE', 'PS1', 'L', 
'XILO007L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT08', 'EXCHANGE', 'PS1', 'C', 
'XILO008C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT08', 'EXCHANGE', 'PS1', 'H', 
'XILO008H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT08', 'EXCHANGE', 'PS1', 'L', 
'XILO008L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT09', 'EXCHANGE', 'PS1', 'C', 
'XILO009C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT09', 'EXCHANGE', 'PS1', 'H', 
'XILO009H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT09', 'EXCHANGE', 'PS1', 'L', 
'XILO009L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT10', 'EXCHANGE', 'PS1', 'C', 
'XILO010C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT10', 'EXCHANGE', 'PS1', 'H', 
'XILO010H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT10', 'EXCHANGE', 'PS1', 'L', 
'XILO010L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT11', 'EXCHANGE', 'PS1', 'C', 
'XILO011C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT11', 'EXCHANGE', 'PS1', 'H', 
'XILO011H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT11', 'EXCHANGE', 'PS1', 'L', 
'XILO011L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT12', 'EXCHANGE', 'PS1', 'C', 
'XILO012C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT12', 'EXCHANGE', 'PS1', 'H', 
'XILO012H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT12', 'EXCHANGE', 'PS1', 'L', 
'XILO012L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT13', 'EXCHANGE', 'PS1', 'C', 
'XILO013C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT13', 'EXCHANGE', 'PS1', 'H', 
'XILO013H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT13', 'EXCHANGE', 'PS1', 'L', 
'XILO013L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT14', 'EXCHANGE', 'PS1', 'C', 
'XILO014C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT14', 'EXCHANGE', 'PS1', 'H', 
'XILO014H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT14', 'EXCHANGE', 'PS1', 'L', 
'XILO014L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT15', 'EXCHANGE', 'PS1', 'C', 
'XILO015C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT15', 'EXCHANGE', 'PS1', 'H', 
'XILO015H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT15', 'EXCHANGE', 'PS1', 'L', 
'XILO015L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT16', 'EXCHANGE', 'PS1', 'C', 
'XILO016C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT16', 'EXCHANGE', 'PS1', 'H', 
'XILO016H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT16', 'EXCHANGE', 'PS1', 'L', 
'XILO016L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT17', 'EXCHANGE', 'PS1', 'C', 
'XILO017C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT17', 'EXCHANGE', 'PS1', 'H', 
'XILO017H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT17', 'EXCHANGE', 'PS1', 'L', 
'XILO017L', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT18', 'EXCHANGE', 'PS1', 'C', 
'XILO018C', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT18', 'EXCHANGE', 'PS1', 'H', 
'XILO018H', NULL, 1)
go

insert into trading_period_alias values(215, 'SPOT18', 'EXCHANGE', 'PS1', 'L', 
'XILO018L', NULL, 1)
go

insert into trading_period_alias values(227, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUABC00H', NULL, 1)
go

insert into trading_period_alias values(227, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUABC00L', NULL, 1)
go

insert into trading_period_alias values(228, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAAP00H', NULL, 1)
go

insert into trading_period_alias values(228, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAAP00L', NULL, 1)
go

insert into trading_period_alias values(229, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAGB00H', NULL, 1)
go

insert into trading_period_alias values(229, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAGB00L', NULL, 1)
go

insert into trading_period_alias values(230, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUABB00H', NULL, 1)
go

insert into trading_period_alias values(230, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUABB00L', NULL, 1)
go

insert into trading_period_alias values(231, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAAK00H', NULL, 1)
go

insert into trading_period_alias values(231, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAAK00L', NULL, 1)
go

insert into trading_period_alias values(232, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAFZ00H', NULL, 1)
go

insert into trading_period_alias values(232, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAFZ00L', NULL, 1)
go

insert into trading_period_alias values(232, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'PUAXJ00H', NULL, 1)
go

insert into trading_period_alias values(232, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'PUAXJ00L', NULL, 1)
go

insert into trading_period_alias values(232, 'SPOT02', 'PLATTS', 'PS1', 'H', 
'PUAXL00H', NULL, 1)
go

insert into trading_period_alias values(232, 'SPOT02', 'PLATTS', 'PS1', 'L', 
'PUAXL00L', NULL, 1)
go

insert into trading_period_alias values(232, 'SPOT03', 'PLATTS', 'PS1', 'H', 
'PUAXN00H', NULL, 1)
go

insert into trading_period_alias values(232, 'SPOT03', 'PLATTS', 'PS1', 'L', 
'PUAXN00L', NULL, 1)
go

insert into trading_period_alias values(234, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAAL00H', NULL, 1)
go

insert into trading_period_alias values(234, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAAL00L', NULL, 1)
go

insert into trading_period_alias values(236, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PPAPW00H', NULL, 1)
go

insert into trading_period_alias values(236, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PPAPW00L', NULL, 1)
go

insert into trading_period_alias values(237, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAAM00H', NULL, 1)
go

insert into trading_period_alias values(237, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAAM00L', NULL, 1)
go

insert into trading_period_alias values(240, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PPXDK00H', NULL, 1)
go

insert into trading_period_alias values(240, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PPXDK00L', NULL, 1)
go

insert into trading_period_alias values(242, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUABA00H', NULL, 1)
go

insert into trading_period_alias values(242, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUABA00L', NULL, 1)
go

insert into trading_period_alias values(243, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAAZ00H', NULL, 1)
go

insert into trading_period_alias values(243, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAAZ00L', NULL, 1)
go

insert into trading_period_alias values(251, 'SPOT', 'APPI', 'PS1', 'H', 
'APTAPISH', NULL, 1)
go

insert into trading_period_alias values(251, 'SPOT', 'APPI', 'PS1', 'L', 
'APTAPISL', NULL, 1)
go

insert into trading_period_alias values(251, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCACB00H', NULL, 1)
go

insert into trading_period_alias values(251, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCACB00L', NULL, 1)
go

insert into trading_period_alias values(251, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'PCAFG00H', NULL, 1)
go

insert into trading_period_alias values(251, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'PCAFG00L', NULL, 1)
go

insert into trading_period_alias values(251, 'SPOT02', 'PLATTS', 'PS1', 'H', 
'PCAFH00H', NULL, 1)
go

insert into trading_period_alias values(251, 'SPOT02', 'PLATTS', 'PS1', 'L', 
'PCAFH00L', NULL, 1)
go

insert into trading_period_alias values(257, 'SPOT', 'APPI', 'PS1', 'H', 
'PCABA00H', NULL, 1)
go

insert into trading_period_alias values(257, 'SPOT', 'APPI', 'PS1', 'L', 
'PCABA00L', NULL, 1)
go

insert into trading_period_alias values(257, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCABA00H', NULL, 1)
go

insert into trading_period_alias values(257, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCABA00L', NULL, 1)
go

insert into trading_period_alias values(348, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAAZ00H', NULL, 1)
go

insert into trading_period_alias values(348, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAAZ00L', NULL, 1)
go

insert into trading_period_alias values(400, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAEE00H', NULL, 1)
go

insert into trading_period_alias values(400, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAEE00L', NULL, 1)
go

insert into trading_period_alias values(402, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGACU00H', NULL, 1)
go

insert into trading_period_alias values(402, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGACU00L', NULL, 1)
go

insert into trading_period_alias values(801, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAFD00H', NULL, 1)
go

insert into trading_period_alias values(801, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAFD00L', NULL, 1)
go

insert into trading_period_alias values(809, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAID00H', NULL, 1)
go

insert into trading_period_alias values(809, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAID00L', NULL, 1)
go

insert into trading_period_alias values(818, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAEE00H', NULL, 1)
go

insert into trading_period_alias values(818, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAEE00L', NULL, 1)
go

insert into trading_period_alias values(883, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAJF00H', NULL, 1)
go

insert into trading_period_alias values(883, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAJF00L', NULL, 1)
go

insert into trading_period_alias values(899, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAAB00H', NULL, 1)
go

insert into trading_period_alias values(899, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAAB00L', NULL, 1)
go

insert into trading_period_alias values(902, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAAC00H', NULL, 1)
go

insert into trading_period_alias values(902, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAAC00L', NULL, 1)
go

insert into trading_period_alias values(966, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POABC00H', NULL, 1)
go

insert into trading_period_alias values(966, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POABC00L', NULL, 1)
go

insert into trading_period_alias values(1248, 'SPOT', 'APPI', 'PS1', 'H', 
'APTAPISH', NULL, 1)
go

insert into trading_period_alias values(1248, 'SPOT', 'APPI', 'PS1', 'L', 
'APTAPISL', NULL, 1)
go

insert into trading_period_alias values(1250, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABH00H', NULL, 1)
go

insert into trading_period_alias values(1250, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABH00L', NULL, 1)
go

insert into trading_period_alias values(1251, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABI00H', NULL, 1)
go

insert into trading_period_alias values(1251, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABI00L', NULL, 1)
go

insert into trading_period_alias values(1252, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABM00H', NULL, 1)
go

insert into trading_period_alias values(1252, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABM00L', NULL, 1)
go

insert into trading_period_alias values(1347, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAAA00H', NULL, 1)
go

insert into trading_period_alias values(1347, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAAA00L', NULL, 1)
go

insert into trading_period_alias values(1348, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAAB00H', NULL, 1)
go

insert into trading_period_alias values(1348, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAAB00L', NULL, 1)
go

insert into trading_period_alias values(1429, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAFW00H', NULL, 1)
go

insert into trading_period_alias values(1429, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAFW00L', NULL, 1)
go

insert into trading_period_alias values(1447, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PPAQB00H', NULL, 1)
go

insert into trading_period_alias values(1447, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PPAQB00L', NULL, 1)
go

insert into trading_period_alias values(1449, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PPAQF00H', NULL, 1)
go

insert into trading_period_alias values(1449, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PPAQF00L', NULL, 1)
go

insert into trading_period_alias values(1450, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PPAQH00H', NULL, 1)
go

insert into trading_period_alias values(1450, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PPAQH00L', NULL, 1)
go

insert into trading_period_alias values(1541, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAFI00H', NULL, 1)
go

insert into trading_period_alias values(1541, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAFI00L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT01', 'EXCHANGE', 'PS1', 'C', 
'XNNG001C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT01', 'EXCHANGE', 'PS1', 'H', 
'XNNG001H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT01', 'EXCHANGE', 'PS1', 'H', 
'XNNG001L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT02', 'EXCHANGE', 'PS1', 'C', 
'XNNG002C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT02', 'EXCHANGE', 'PS1', 'H', 
'XNNG002H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT02', 'EXCHANGE', 'PS1', 'L', 
'XNNG002L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT03', 'EXCHANGE', 'PS1', 'C', 
'XNNG003C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT03', 'EXCHANGE', 'PS1', 'H', 
'XNNG003H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT03', 'EXCHANGE', 'PS1', 'L', 
'XNNG003L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT04', 'EXCHANGE', 'PS1', 'C', 
'XNNG004C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT04', 'EXCHANGE', 'PS1', 'H', 
'XNNG004H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT04', 'EXCHANGE', 'PS1', 'L', 
'XNNG004L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT05', 'EXCHANGE', 'PS1', 'C', 
'XNNG005C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT05', 'EXCHANGE', 'PS1', 'H', 
'XNNG005H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT05', 'EXCHANGE', 'PS1', 'L', 
'XNNG005L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT06', 'EXCHANGE', 'PS1', 'C', 
'XNNG006C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT06', 'EXCHANGE', 'PS1', 'H', 
'XNNG006H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT06', 'EXCHANGE', 'PS1', 'L', 
'XNNG006L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT07', 'EXCHANGE', 'PS1', 'C', 
'XNNG007C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT07', 'EXCHANGE', 'PS1', 'H', 
'XNNG007H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT07', 'EXCHANGE', 'PS1', 'L', 
'XNNG007L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT08', 'EXCHANGE', 'PS1', 'C', 
'XNNG008C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT08', 'EXCHANGE', 'PS1', 'H', 
'XNNG008H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT08', 'EXCHANGE', 'PS1', 'L', 
'XNNG008L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT09', 'EXCHANGE', 'PS1', 'C', 
'XNNG009C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT09', 'EXCHANGE', 'PS1', 'H', 
'XNNG009H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT09', 'EXCHANGE', 'PS1', 'L', 
'XNNG009L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT10', 'EXCHANGE', 'PS1', 'C', 
'XNNG010C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT10', 'EXCHANGE', 'PS1', 'H', 
'XNNG010H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT10', 'EXCHANGE', 'PS1', 'L', 
'XNNG010L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT11', 'EXCHANGE', 'PS1', 'C', 
'XNNG011C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT11', 'EXCHANGE', 'PS1', 'H', 
'XNNG011H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT11', 'EXCHANGE', 'PS1', 'L', 
'XNNG011L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT12', 'EXCHANGE', 'PS1', 'C', 
'XNNG012C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT12', 'EXCHANGE', 'PS1', 'H', 
'XNNG012H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT12', 'EXCHANGE', 'PS1', 'L', 
'XNNG012L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT13', 'EXCHANGE', 'PS1', 'C', 
'XNNG013C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT13', 'EXCHANGE', 'PS1', 'H', 
'XNNG013H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT13', 'EXCHANGE', 'PS1', 'L', 
'XNNG013L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT14', 'EXCHANGE', 'PS1', 'C', 
'XNNG014C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT14', 'EXCHANGE', 'PS1', 'H', 
'XNNG014H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT14', 'EXCHANGE', 'PS1', 'L', 
'XNNG014L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT15', 'EXCHANGE', 'PS1', 'C', 
'XNNG015C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT15', 'EXCHANGE', 'PS1', 'H', 
'XNNG015H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT15', 'EXCHANGE', 'PS1', 'L', 
'XNNG015L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT16', 'EXCHANGE', 'PS1', 'C', 
'XNNG016C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT16', 'EXCHANGE', 'PS1', 'H', 
'XNNG016H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT16', 'EXCHANGE', 'PS1', 'L', 
'XNNG016L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT17', 'EXCHANGE', 'PS1', 'C', 
'XNNG017C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT17', 'EXCHANGE', 'PS1', 'H', 
'XNNG017H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT17', 'EXCHANGE', 'PS1', 'L', 
'XNNG017L', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT18', 'EXCHANGE', 'PS1', 'C', 
'XNNG018C', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT18', 'EXCHANGE', 'PS1', 'H', 
'XNNG018H', NULL, 1)
go

insert into trading_period_alias values(1562, 'SPOT18', 'EXCHANGE', 'PS1', 'L', 
'XNNG018L', NULL, 1)
go

insert into trading_period_alias values(1569, 'SPOT', 'APPI', 'PS1', 'H', 
'PCAFL00H', NULL, 1)
go

insert into trading_period_alias values(1569, 'SPOT', 'APPI', 'PS1', 'L', 
'PCAFL00L', NULL, 1)
go

insert into trading_period_alias values(1569, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAFL00H', NULL, 1)
go

insert into trading_period_alias values(1569, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAFL00L', NULL, 1)
go

insert into trading_period_alias values(1615, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCABO00H', NULL, 1)
go

insert into trading_period_alias values(1615, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCABO00L', NULL, 1)
go

insert into trading_period_alias values(1623, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAHQ00H', NULL, 1)
go

insert into trading_period_alias values(1623, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAHQ00L', NULL, 1)
go

insert into trading_period_alias values(1624, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAFP00H', NULL, 1)
go

insert into trading_period_alias values(1624, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAFP00L', NULL, 1)
go

insert into trading_period_alias values(1629, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAHS00H', NULL, 1)
go

insert into trading_period_alias values(1629, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAHS00L', NULL, 1)
go

insert into trading_period_alias values(1637, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAFR00H', NULL, 1)
go

insert into trading_period_alias values(1637, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAFR00L', NULL, 1)
go

insert into trading_period_alias values(1641, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PJABO00H', NULL, 1)
go

insert into trading_period_alias values(1641, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PJABO00L', NULL, 1)
go

insert into trading_period_alias values(1643, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PJABM00H', NULL, 1)
go

insert into trading_period_alias values(1643, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PJABM00L', NULL, 1)
go

insert into trading_period_alias values(1643, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'PJACF00H', NULL, 1)
go

insert into trading_period_alias values(1643, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'PJACF00L', NULL, 1)
go

insert into trading_period_alias values(1661, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAER00H', NULL, 1)
go

insert into trading_period_alias values(1661, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAER00L', NULL, 1)
go

insert into trading_period_alias values(1661, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'POAFQ00H', NULL, 1)
go

insert into trading_period_alias values(1661, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'POAFQ00L', NULL, 1)
go

insert into trading_period_alias values(1662, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAES00H', NULL, 1)
go

insert into trading_period_alias values(1662, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAES00L', NULL, 1)
go

insert into trading_period_alias values(1662, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'POAGY00H', NULL, 1)
go

insert into trading_period_alias values(1662, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'POAGY00L', NULL, 1)
go

insert into trading_period_alias values(1673, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAAV00H', NULL, 1)
go

insert into trading_period_alias values(1673, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAAV00L', NULL, 1)
go

insert into trading_period_alias values(1683, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGADA00H', NULL, 1)
go

insert into trading_period_alias values(1683, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGADA00L', NULL, 1)
go

insert into trading_period_alias values(1687, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAKT00H', NULL, 1)
go

insert into trading_period_alias values(1687, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAKT00L', NULL, 1)
go

insert into trading_period_alias values(1688, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAKL00H', NULL, 1)
go

insert into trading_period_alias values(1688, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAKL00L', NULL, 1)
go

insert into trading_period_alias values(1689, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAMN00H', NULL, 1)
go

insert into trading_period_alias values(1689, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAMN00L', NULL, 1)
go

insert into trading_period_alias values(1690, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAMP00H', NULL, 1)
go

insert into trading_period_alias values(1690, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAMP00L', NULL, 1)
go

insert into trading_period_alias values(1693, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAKW00H', NULL, 1)
go

insert into trading_period_alias values(1693, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAKW00L', NULL, 1)
go

insert into trading_period_alias values(1699, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAMR00H', NULL, 1)
go

insert into trading_period_alias values(1699, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAMR00L', NULL, 1)
go

insert into trading_period_alias values(1700, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAEZ00H', NULL, 1)
go

insert into trading_period_alias values(1700, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAEZ00L', NULL, 1)
go

insert into trading_period_alias values(1700, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'PGAMT00H', NULL, 1)
go

insert into trading_period_alias values(1700, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'PGAMT00L', NULL, 1)
go

insert into trading_period_alias values(1700, 'SPOT02', 'PLATTS', 'PS1', 'H', 
'PGAMV00H', NULL, 1)
go

insert into trading_period_alias values(1700, 'SPOT02', 'PLATTS', 'PS1', 'L', 
'PGAMV00L', NULL, 1)
go

insert into trading_period_alias values(1701, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGAMS00H', NULL, 1)
go

insert into trading_period_alias values(1701, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGAMS00L', NULL, 1)
go

insert into trading_period_alias values(1729, 'SPOT', 'FERC', 'PS1', 'H', 
'IGABE00H', NULL, 1)
go

insert into trading_period_alias values(1729, 'SPOT', 'FERC', 'PS1', 'L', 
'IGABE00L', NULL, 1)
go

insert into trading_period_alias values(1731, 'SPOT', 'FERC', 'PS1', 'H', 
'IGABD00H', NULL, 1)
go

insert into trading_period_alias values(1731, 'SPOT', 'FERC', 'PS1', 'L', 
'IGABD00L', NULL, 1)
go

insert into trading_period_alias values(1776, 'SPOT', 'FERC', 'PS1', 'H', 
'IGABH00H', NULL, 1)
go

insert into trading_period_alias values(1776, 'SPOT', 'FERC', 'PS1', 'L', 
'IGABH00L', NULL, 1)
go

insert into trading_period_alias values(1777, 'SPOT', 'FERC', 'PS1', 'H', 
'IGACC00H', NULL, 1)
go

insert into trading_period_alias values(1777, 'SPOT', 'FERC', 'PS1', 'L', 
'IGACC00L', NULL, 1)
go

insert into trading_period_alias values(1780, 'SPOT', 'FERC', 'PS1', 'H', 
'IGABA00H', NULL, 1)
go

insert into trading_period_alias values(1780, 'SPOT', 'FERC', 'PS1', 'L', 
'IGABA00L', NULL, 1)
go

insert into trading_period_alias values(1790, 'SPOT', 'FERC', 'PS1', 'H', 
'IGABY00H', NULL, 1)
go

insert into trading_period_alias values(1790, 'SPOT', 'FERC', 'PS1', 'L', 
'IGABY00L', NULL, 1)
go

insert into trading_period_alias values(1796, 'SPOT', 'FERC', 'PS1', 'H', 
'IGABC00H', NULL, 1)
go

insert into trading_period_alias values(1796, 'SPOT', 'FERC', 'PS1', 'L', 
'IGABC00L', NULL, 1)
go

insert into trading_period_alias values(1814, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PHAKZ00H', NULL, 1)
go

insert into trading_period_alias values(1814, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PHAKZ00L', NULL, 1)
go

insert into trading_period_alias values(1817, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PHAKX00H', NULL, 1)
go

insert into trading_period_alias values(1817, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PHAKX00L', NULL, 1)
go

insert into trading_period_alias values(1819, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCABB00H', NULL, 1)
go

insert into trading_period_alias values(1819, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCABB00L', NULL, 1)
go

insert into trading_period_alias values(1820, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCABP00H', NULL, 1)
go

insert into trading_period_alias values(1820, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCABP00L', NULL, 1)
go

insert into trading_period_alias values(1822, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAFM00H', NULL, 1)
go

insert into trading_period_alias values(1822, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAFM00L', NULL, 1)
go

insert into trading_period_alias values(1824, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAHA00H', NULL, 1)
go

insert into trading_period_alias values(1824, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAHA00L', NULL, 1)
go

insert into trading_period_alias values(1832, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PKABA00H', NULL, 1)
go

insert into trading_period_alias values(1832, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PKABA00L', NULL, 1)
go

insert into trading_period_alias values(1836, '200001W3', 'INTERNAL', 'PS1', 
'H', '1836H', NULL, 1)
go

insert into trading_period_alias values(1836, '200001W3', 'INTERNAL', 'PS1', 
'L', '1836L', NULL, 1)
go

insert into trading_period_alias values(1836, '200001W4', 'INTERNAL', 'PS1', 
'H', '200001W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200001W4', 'INTERNAL', 'PS1', 
'L', '200001W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200002W1', 'INTERNAL', 'PS1', 
'H', '200002W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200002W1', 'INTERNAL', 'PS1', 
'L', '200002W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200002W2', 'INTERNAL', 'PS1', 
'H', '200002W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200002W2', 'INTERNAL', 'PS1', 
'L', '200002W2L', NULL, 1)
go

insert into trading_period_alias values(1836, '200002W3', 'INTERNAL', 'PS1', 
'H', '200002W3H', NULL, 1)
go

insert into trading_period_alias values(1836, '200002W3', 'INTERNAL', 'PS1', 
'L', '200002W3L', NULL, 1)
go

insert into trading_period_alias values(1836, '200002W4', 'INTERNAL', 'PS1', 
'H', '200002W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200002W4', 'INTERNAL', 'PS1', 
'L', '200002W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200003W1', 'INTERNAL', 'PS1', 
'H', '200003W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200003W1', 'INTERNAL', 'PS1', 
'L', '200003W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200003W2', 'INTERNAL', 'PS1', 
'H', '200003W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200003W2', 'INTERNAL', 'PS1', 
'L', '200003W2L', NULL, 1)
go

insert into trading_period_alias values(1836, '200003W3', 'INTERNAL', 'PS1', 
'H', '200003W3H', NULL, 1)
go

insert into trading_period_alias values(1836, '200003W3', 'INTERNAL', 'PS1', 
'L', '200003W3L', NULL, 1)
go

insert into trading_period_alias values(1836, '200003W4', 'INTERNAL', 'PS1', 
'H', '200003W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200003W4', 'INTERNAL', 'PS1', 
'L', '200003W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200004W1', 'INTERNAL', 'PS1', 
'H', '200004W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200004W1', 'INTERNAL', 'PS1', 
'L', '200004W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200004W2', 'INTERNAL', 'PS1', 
'H', '200004W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200004W2', 'INTERNAL', 'PS1', 
'L', '200004W2L', NULL, 1)
go

insert into trading_period_alias values(1836, '200004W3', 'INTERNAL', 'PS1', 
'H', '200004W3H', NULL, 1)
go

insert into trading_period_alias values(1836, '200004W3', 'INTERNAL', 'PS1', 
'L', '200004W3L', NULL, 1)
go

insert into trading_period_alias values(1836, '200004W4', 'INTERNAL', 'PS1', 
'H', '200004W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200004W4', 'INTERNAL', 'PS1', 
'L', '200004W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200005W1', 'INTERNAL', 'PS1', 
'H', '200005W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200005W1', 'INTERNAL', 'PS1', 
'L', '200005W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200005W2', 'INTERNAL', 'PS1', 
'H', '200005W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200005W2', 'INTERNAL', 'PS1', 
'L', '200005W2L', NULL, 1)
go

insert into trading_period_alias values(1836, '200005W3', 'INTERNAL', 'PS1', 
'H', '200005W3H', NULL, 1)
go

insert into trading_period_alias values(1836, '200005W3', 'INTERNAL', 'PS1', 
'L', '200005W3L', NULL, 1)
go

insert into trading_period_alias values(1836, '200005W4', 'INTERNAL', 'PS1', 
'H', '200005W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200005W4', 'INTERNAL', 'PS1', 
'L', '200005W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200005W5', 'INTERNAL', 'PS1', 
'H', '200005W5H', NULL, 1)
go

insert into trading_period_alias values(1836, '200005W5', 'INTERNAL', 'PS1', 
'L', '200005W5L', NULL, 1)
go

insert into trading_period_alias values(1836, '200006W1', 'INTERNAL', 'PS1', 
'H', '200006W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200006W1', 'INTERNAL', 'PS1', 
'L', '200006W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200006W2', 'INTERNAL', 'PS1', 
'H', '200006W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200006W2', 'INTERNAL', 'PS1', 
'L', '200006W2L', NULL, 1)
go

insert into trading_period_alias values(1836, '200006W3', 'INTERNAL', 'PS1', 
'H', '200006W3H', NULL, 1)
go

insert into trading_period_alias values(1836, '200006W3', 'INTERNAL', 'PS1', 
'L', '200006W3L', NULL, 1)
go

insert into trading_period_alias values(1836, '200006W4', 'INTERNAL', 'PS1', 
'H', '200006W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200006W4', 'INTERNAL', 'PS1', 
'L', '200006W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200007W1', 'INTERNAL', 'PS1', 
'H', '200007W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200007W1', 'INTERNAL', 'PS1', 
'L', '200007W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200007W2', 'INTERNAL', 'PS1', 
'H', '200007W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200007W2', 'INTERNAL', 'PS1', 
'L', '200007W2L', NULL, 1)
go

insert into trading_period_alias values(1836, '200007W3', 'INTERNAL', 'PS1', 
'H', '200007W3H', NULL, 1)
go

insert into trading_period_alias values(1836, '200007W3', 'INTERNAL', 'PS1', 
'L', '200007W3L', NULL, 1)
go

insert into trading_period_alias values(1836, '200007W4', 'INTERNAL', 'PS1', 
'H', '200007W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200007W4', 'INTERNAL', 'PS1', 
'L', '200007W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200007W5', 'INTERNAL', 'PS1', 
'H', '200007W5H', NULL, 1)
go

insert into trading_period_alias values(1836, '200007W5', 'INTERNAL', 'PS1', 
'L', '200007W5L', NULL, 1)
go

insert into trading_period_alias values(1836, '200008W1', 'INTERNAL', 'PS1', 
'H', '200008W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200008W1', 'INTERNAL', 'PS1', 
'L', '200008W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200008W2', 'INTERNAL', 'PS1', 
'H', '200008W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200008W2', 'INTERNAL', 'PS1', 
'L', '200008W2L', NULL, 1)
go

insert into trading_period_alias values(1836, '200008W3', 'INTERNAL', 'PS1', 
'H', '200008W3H', NULL, 1)
go

insert into trading_period_alias values(1836, '200008W3', 'INTERNAL', 'PS1', 
'L', '200008W3L', NULL, 1)
go

insert into trading_period_alias values(1836, '200008W4', 'INTERNAL', 'PS1', 
'H', '200008W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200008W4', 'INTERNAL', 'PS1', 
'L', '200008W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200009W1', 'INTERNAL', 'PS1', 
'H', '200009W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200009W1', 'INTERNAL', 'PS1', 
'L', '200009W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200009W2', 'INTERNAL', 'PS1', 
'H', '200009W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200009W2', 'INTERNAL', 'PS1', 
'L', '200009W2L', NULL, 1)
go

insert into trading_period_alias values(1836, '200009W3', 'INTERNAL', 'PS1', 
'H', '200009W3H', NULL, 1)
go

insert into trading_period_alias values(1836, '200009W3', 'INTERNAL', 'PS1', 
'L', '200009W3L', NULL, 1)
go

insert into trading_period_alias values(1836, '200009W4', 'INTERNAL', 'PS1', 
'H', '200009W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200009W4', 'INTERNAL', 'PS1', 
'L', '200009W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200009W5', 'INTERNAL', 'PS1', 
'H', '200009W5H', NULL, 1)
go

insert into trading_period_alias values(1836, '200009W5', 'INTERNAL', 'PS1', 
'L', '200009W5L', NULL, 1)
go

insert into trading_period_alias values(1836, '200010W1', 'INTERNAL', 'PS1', 
'H', '200010W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200010W1', 'INTERNAL', 'PS1', 
'L', '200010W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200010W2', 'INTERNAL', 'PS1', 
'H', '200010W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200010W2', 'INTERNAL', 'PS1', 
'L', '200010W2L', NULL, 1)
go

insert into trading_period_alias values(1836, '200010W3', 'INTERNAL', 'PS1', 
'H', '200010W3H', NULL, 1)
go

insert into trading_period_alias values(1836, '200010W3', 'INTERNAL', 'PS1', 
'L', '200010W3L', NULL, 1)
go

insert into trading_period_alias values(1836, '200010W4', 'INTERNAL', 'PS1', 
'H', '200010W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200010W4', 'INTERNAL', 'PS1', 
'L', '200010W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200010W5', 'INTERNAL', 'PS1', 
'H', '200010W5H', NULL, 1)
go

insert into trading_period_alias values(1836, '200010W5', 'INTERNAL', 'PS1', 
'L', '200010W5L', NULL, 1)
go

insert into trading_period_alias values(1836, '200011W1', 'INTERNAL', 'PS1', 
'H', '200011W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200011W1', 'INTERNAL', 'PS1', 
'L', '200011W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200011W2', 'INTERNAL', 'PS1', 
'H', '200011W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200011W2', 'INTERNAL', 'PS1', 
'L', '200011W2L', NULL, 1)
go

insert into trading_period_alias values(1836, '200011W3', 'INTERNAL', 'PS1', 
'H', '200011W3H', NULL, 1)
go

insert into trading_period_alias values(1836, '200011W3', 'INTERNAL', 'PS1', 
'L', '200011W3L', NULL, 1)
go

insert into trading_period_alias values(1836, '200011W4', 'INTERNAL', 'PS1', 
'H', '200011W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200011W4', 'INTERNAL', 'PS1', 
'L', '200011W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200012W1', 'INTERNAL', 'PS1', 
'H', '200012W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200012W1', 'INTERNAL', 'PS1', 
'L', '200012W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200012W2', 'INTERNAL', 'PS1', 
'H', '200012W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200012W2', 'INTERNAL', 'PS1', 
'L', '200012W2L', NULL, 1)
go

insert into trading_period_alias values(1836, '200012W3', 'INTERNAL', 'PS1', 
'H', '200012W3H', NULL, 1)
go

insert into trading_period_alias values(1836, '200012W3', 'INTERNAL', 'PS1', 
'L', '200012W3L', NULL, 1)
go

insert into trading_period_alias values(1836, '200012W4', 'INTERNAL', 'PS1', 
'H', '200012W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200012W4', 'INTERNAL', 'PS1', 
'L', '200012W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200101W1', 'INTERNAL', 'PS1', 
'H', '200101W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200101W1', 'INTERNAL', 'PS1', 
'L', '200101W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200101W2', 'INTERNAL', 'PS1', 
'H', '200101W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200101W2', 'INTERNAL', 'PS1', 
'L', '200101W2L', NULL, 1)
go

insert into trading_period_alias values(1836, '200101W3', 'INTERNAL', 'PS1', 
'H', '200101W3H', NULL, 1)
go

insert into trading_period_alias values(1836, '200101W3', 'INTERNAL', 'PS1', 
'L', '200101W3L', NULL, 1)
go

insert into trading_period_alias values(1836, '200101W4', 'INTERNAL', 'PS1', 
'H', '200101W4H', NULL, 1)
go

insert into trading_period_alias values(1836, '200101W4', 'INTERNAL', 'PS1', 
'L', '200101W4L', NULL, 1)
go

insert into trading_period_alias values(1836, '200101W5', 'INTERNAL', 'PS1', 
'H', '200101W5H', NULL, 1)
go

insert into trading_period_alias values(1836, '200101W5', 'INTERNAL', 'PS1', 
'L', '200101W5L', NULL, 1)
go

insert into trading_period_alias values(1836, '200102W1', 'INTERNAL', 'PS1', 
'H', '200102W1H', NULL, 1)
go

insert into trading_period_alias values(1836, '200102W1', 'INTERNAL', 'PS1', 
'L', '200102W1L', NULL, 1)
go

insert into trading_period_alias values(1836, '200102W2', 'INTERNAL', 'PS1', 
'H', '200102W2H', NULL, 1)
go

insert into trading_period_alias values(1836, '200102W2', 'INTERNAL', 'PS1', 
'L', '200102W2L', NULL, 1)
go

insert into trading_period_alias values(1836, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCAAS00H', NULL, 1)
go

insert into trading_period_alias values(1836, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCAAS00L', NULL, 1)
go

insert into trading_period_alias values(1852, 'SPOT', 'ARGUS', 'PS1', 'H', 
'PMAAK00H', NULL, 1)
go

insert into trading_period_alias values(1852, 'SPOT', 'ARGUS', 'PS1', 'L', 
'PMAAK00L', NULL, 1)
go

insert into trading_period_alias values(1852, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PMAAK00H', NULL, 1)
go

insert into trading_period_alias values(1852, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PMAAK00L', NULL, 1)
go

insert into trading_period_alias values(1854, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PMAAI00H', NULL, 1)
go

insert into trading_period_alias values(1854, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PMAAI00L', NULL, 1)
go

insert into trading_period_alias values(1869, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGACU00H', NULL, 1)
go

insert into trading_period_alias values(1869, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGACU00L', NULL, 1)
go

insert into trading_period_alias values(1876, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABU00H', NULL, 1)
go

insert into trading_period_alias values(1876, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABU00L', NULL, 1)
go

insert into trading_period_alias values(1876, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABW00H', NULL, 1)
go

insert into trading_period_alias values(1876, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABW00L', NULL, 1)
go

insert into trading_period_alias values(1877, 'SPOT', 'FERC', 'PS1', 'H', 
'IGABU00H', NULL, 1)
go

insert into trading_period_alias values(1877, 'SPOT', 'FERC', 'PS1', 'L', 
'IGABU00L', NULL, 1)
go

insert into trading_period_alias values(1879, 'SPOT', 'OPIS', 'PS1', 'H', 
'OMBLP00H', NULL, 1)
go

insert into trading_period_alias values(1879, 'SPOT', 'OPIS', 'PS1', 'L', 
'OMBLP00L', NULL, 1)
go

insert into trading_period_alias values(1879, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PMAAY00H', NULL, 1)
go

insert into trading_period_alias values(1879, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PMAAY00L', NULL, 1)
go

insert into trading_period_alias values(1883, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABY00H', NULL, 1)
go

insert into trading_period_alias values(1883, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABY00L', NULL, 1)
go

insert into trading_period_alias values(1893, 'SPOT', 'ARGUS', 'PS1', 'H', 
'PKABA00H', NULL, 1)
go

insert into trading_period_alias values(1893, 'SPOT', 'ARGUS', 'PS1', 'L', 
'PKABA00L', NULL, 1)
go

insert into trading_period_alias values(1895, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABW00H', NULL, 1)
go

insert into trading_period_alias values(1895, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABW00L', NULL, 1)
go

insert into trading_period_alias values(1896, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABX00H', NULL, 1)
go

insert into trading_period_alias values(1896, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABX00L', NULL, 1)
go

insert into trading_period_alias values(1907, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCACZ00H', NULL, 1)
go

insert into trading_period_alias values(1907, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCACZ00L', NULL, 1)
go

insert into trading_period_alias values(1908, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCADJ00H', NULL, 1)
go

insert into trading_period_alias values(1908, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCADJ00L', NULL, 1)
go

insert into trading_period_alias values(1913, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABH00H', NULL, 1)
go

insert into trading_period_alias values(1913, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABH00L', NULL, 1)
go

insert into trading_period_alias values(1916, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABI00H', NULL, 1)
go

insert into trading_period_alias values(1916, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABI00L', NULL, 1)
go

insert into trading_period_alias values(1917, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABM00H', NULL, 1)
go

insert into trading_period_alias values(1917, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABM00L', NULL, 1)
go

insert into trading_period_alias values(1918, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAES00H', NULL, 1)
go

insert into trading_period_alias values(1918, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAES00L', NULL, 1)
go

insert into trading_period_alias values(1919, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABV00H', NULL, 1)
go

insert into trading_period_alias values(1919, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PGABX00H', NULL, 1)
go

insert into trading_period_alias values(1919, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABV00L', NULL, 1)
go

insert into trading_period_alias values(1919, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PGABX00L', NULL, 1)
go

insert into trading_period_alias values(1920, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAER00H', NULL, 1)
go

insert into trading_period_alias values(1920, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAER00L', NULL, 1)
go

insert into trading_period_alias values(1932, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAEE00H', NULL, 1)
go

insert into trading_period_alias values(1932, 'SPOT', 'PLATTS', 'PS1', 'L', 
'POAEE00L', NULL, 1)
go

insert into trading_period_alias values(1937, 'SPOT', 'ARGUS', 'PS1', 'C', 
'TBSUDA0C', NULL, 1)
go

insert into trading_period_alias values(1938, 'SPOT', 'ARGUS', 'PS1', 'C', 
'TPSUDA0C', NULL, 1)
go

insert into trading_period_alias values(1947, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCADJ00H', NULL, 1)
go

insert into trading_period_alias values(1947, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCADJ00L', NULL, 1)
go

insert into trading_period_alias values(1958, 'SPOT', 'KOCH', 'PS1', 'C', 
'PSACX09C', NULL, 1)
go

insert into trading_period_alias values(1960, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAAO00H', NULL, 1)
go

insert into trading_period_alias values(1960, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAAO00L', NULL, 1)
go

insert into trading_period_alias values(1960, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'PUAXD00H', NULL, 1)
go

insert into trading_period_alias values(1960, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'PUAXD00L', NULL, 1)
go

insert into trading_period_alias values(1960, 'SPOT02', 'PLATTS', 'PS1', 'H', 
'PUAXF00H', NULL, 1)
go

insert into trading_period_alias values(1960, 'SPOT02', 'PLATTS', 'PS1', 'L', 
'PUAXF00L', NULL, 1)
go

insert into trading_period_alias values(1960, 'SPOT03', 'PLATTS', 'PS1', 'H', 
'PUAXG00H', NULL, 1)
go

insert into trading_period_alias values(1960, 'SPOT03', 'PLATTS', 'PS1', 'L', 
'PUAXG00L', NULL, 1)
go

insert into trading_period_alias values(1970, 'SPOT', 'SUNREF', 'PS1', 'C', 
'PSADG09C', NULL, 1)
go

insert into trading_period_alias values(1972, 'SPOT', 'SCURPERM', 'PS1', 'C', 
'PSADF09C', NULL, 1)
go

insert into trading_period_alias values(1974, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAGA00H', NULL, 1)
go

insert into trading_period_alias values(1974, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAGA00L', NULL, 1)
go

insert into trading_period_alias values(1975, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAAY00H', NULL, 1)
go

insert into trading_period_alias values(1975, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAAY00L', NULL, 1)
go

insert into trading_period_alias values(1976, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAAJ00H', NULL, 1)
go

insert into trading_period_alias values(1976, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAAJ00L', NULL, 1)
go

insert into trading_period_alias values(2016, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAFI00H', NULL, 1)
go

insert into trading_period_alias values(2016, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAFI00L', NULL, 1)
go

insert into trading_period_alias values(2019, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCADI00H', NULL, 1)
go

insert into trading_period_alias values(2019, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCADI00L', NULL, 1)
go

insert into trading_period_alias values(2023, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PUAAU00H', NULL, 1)
go

insert into trading_period_alias values(2023, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PUAAU00L', NULL, 1)
go

insert into trading_period_alias values(2070, 'SPOT', 'INTERNAL', 'PS1', 'C', 
'CDLRC', NULL, 1)
go

insert into trading_period_alias values(2075, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCACJ00H', NULL, 1)
go

insert into trading_period_alias values(2075, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCACJ00L', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT01', 'EXCHANGE', 'PS1', 'C', 
'XIYO001C', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT01', 'EXCHANGE', 'PS1', 'H', 
'XIYO001H', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT01', 'EXCHANGE', 'PS1', 'L', 
'XIYO002L', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT02', 'EXCHANGE', 'PS1', 'C', 
'XIYO002C', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT02', 'EXCHANGE', 'PS1', 'H', 
'XIYO002H', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT02', 'EXCHANGE', 'PS1', 'L', 
'XIYO002L', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT03', 'EXCHANGE', 'PS1', 'C', 
'XIYO003C', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT03', 'EXCHANGE', 'PS1', 'H', 
'XIYO003H', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT03', 'EXCHANGE', 'PS1', 'L', 
'XIYO003L', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT04', 'EXCHANGE', 'PS1', 'C', 
'XIYO004C', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT04', 'EXCHANGE', 'PS1', 'H', 
'XIYO004H', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT04', 'EXCHANGE', 'PS1', 'L', 
'XIYO004L', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT05', 'EXCHANGE', 'PS1', 'C', 
'XIYO005C', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT05', 'EXCHANGE', 'PS1', 'H', 
'XIYO005H', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT05', 'EXCHANGE', 'PS1', 'L', 
'XIYO005L', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT06', 'EXCHANGE', 'PS1', 'C', 
'XIYO006C', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT06', 'EXCHANGE', 'PS1', 'H', 
'XIYO006H', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT06', 'EXCHANGE', 'PS1', 'L', 
'XIYO006L', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT07', 'EXCHANGE', 'PS1', 'C', 
'XIYO007C', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT07', 'EXCHANGE', 'PS1', 'H', 
'XIYO007H', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT07', 'EXCHANGE', 'PS1', 'L', 
'XIYO007L', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT08', 'EXCHANGE', 'PS1', 'C', 
'XIYO008C', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT08', 'EXCHANGE', 'PS1', 'H', 
'XIYO008H', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT08', 'EXCHANGE', 'PS1', 'L', 
'XIYO008L', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT09', 'EXCHANGE', 'PS1', 'C', 
'XIYO009C', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT09', 'EXCHANGE', 'PS1', 'H', 
'XIYO009H', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT09', 'EXCHANGE', 'PS1', 'L', 
'XIYO009L', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT10', 'EXCHANGE', 'PS1', 'C', 
'XIYO0010C', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT10', 'EXCHANGE', 'PS1', 'H', 
'XIYO0010H', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT10', 'EXCHANGE', 'PS1', 'L', 
'XIYO0010L', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT11', 'EXCHANGE', 'PS1', 'C', 
'XIYO0011C', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT11', 'EXCHANGE', 'PS1', 'H', 
'XIYO0011H', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT11', 'EXCHANGE', 'PS1', 'L', 
'XIYO0011L', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT12', 'EXCHANGE', 'PS1', 'C', 
'XIYO0012C', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT12', 'EXCHANGE', 'PS1', 'H', 
'XIYO0012H', NULL, 1)
go

insert into trading_period_alias values(2090, 'SPOT12', 'EXCHANGE', 'PS1', 'L', 
'XIYO0012L', NULL, 1)
go

insert into trading_period_alias values(2099, 'SPOT', 'EOTT POS', 'PS1', 'C', 
'PSACT09C', NULL, 1)
go

insert into trading_period_alias values(2103, 'SPOT', 'INTERNAL', 'PS1', 'C', 
'BCADB00C', NULL, 1)
go

insert into trading_period_alias values(2104, 'SPOT', 'INTERNAL', 'PS1', 'C', 
'BCACZ00C', NULL, 1)
go

insert into trading_period_alias values(2105, 'SPOT', 'INTERNAL', 'PS1', 'C', 
'BCADB00C', NULL, 1)
go

insert into trading_period_alias values(2132, '200007W5', 'INTERNAL', 'PS1', 
'H', '200007EW5H', NULL, 1)
go

insert into trading_period_alias values(2132, '200007W5', 'INTERNAL', 'PS1', 
'L', '200007EW5L', NULL, 1)
go

insert into trading_period_alias values(2132, '200008W1', 'INTERNAL', 'PS1', 
'H', '200008EW1H', NULL, 1)
go

insert into trading_period_alias values(2132, '200008W1', 'INTERNAL', 'PS1', 
'L', '200008EW1L', NULL, 1)
go

insert into trading_period_alias values(2132, '200008W2', 'INTERNAL', 'PS1', 
'H', '200008EW2H', NULL, 1)
go

insert into trading_period_alias values(2132, '200008W2', 'INTERNAL', 'PS1', 
'L', '200008EW2L', NULL, 1)
go

insert into trading_period_alias values(2132, '200008W3', 'INTERNAL', 'PS1', 
'H', '200008EW3H', NULL, 1)
go

insert into trading_period_alias values(2132, '200008W3', 'INTERNAL', 'PS1', 
'L', '200008EW3L', NULL, 1)
go

insert into trading_period_alias values(2132, '200008W4', 'INTERNAL', 'PS1', 
'H', '200008EW4H', NULL, 1)
go

insert into trading_period_alias values(2132, '200008W4', 'INTERNAL', 'PS1', 
'L', '200008EW4L', NULL, 1)
go

insert into trading_period_alias values(2132, '200009W1', 'INTERNAL', 'PS1', 
'H', '200009EW1H', NULL, 1)
go

insert into trading_period_alias values(2132, '200009W1', 'INTERNAL', 'PS1', 
'L', '200009EW1L', NULL, 1)
go

insert into trading_period_alias values(2132, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PCADI00H', NULL, 1)
go

insert into trading_period_alias values(2132, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PCADI00L', NULL, 1)
go

insert into trading_period_alias values(2148, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PPAQD00H', NULL, 1)
go

insert into trading_period_alias values(2148, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PPAQD00L', NULL, 1)
go

insert into trading_period_alias values(2149, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PJAAU00H', NULL, 1)
go

insert into trading_period_alias values(2149, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PJAAU00L', NULL, 1)
go

insert into trading_period_alias values(2151, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PJABF00H', NULL, 1)
go

insert into trading_period_alias values(2151, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PJABF00L', NULL, 1)
go

insert into trading_period_alias values(2160, 'SPOT', 'PLATTS', 'PS1', 'H', 
'PJAAA00H', NULL, 1)
go

insert into trading_period_alias values(2160, 'SPOT', 'PLATTS', 'PS1', 'L', 
'PJAAA00L', NULL, 1)
go

insert into trading_period_alias values(2161, 'SPOT01', 'PLATTS', 'PS1', 'H', 
'PCAAT00H', NULL, 1)
go

insert into trading_period_alias values(2161, 'SPOT01', 'PLATTS', 'PS1', 'L', 
'PCAAT00L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT01', 'EXCHANGE', 'PS1', 'C', 
'XNCL001C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT01', 'EXCHANGE', 'PS1', 'H', 
'XNCL001H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT01', 'EXCHANGE', 'PS1', 'L', 
'XNCL001L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT02', 'EXCHANGE', 'PS1', 'C', 
'XNCL002C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT02', 'EXCHANGE', 'PS1', 'H', 
'XNCL002H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT02', 'EXCHANGE', 'PS1', 'L', 
'XNCL002L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT03', 'EXCHANGE', 'PS1', 'C', 
'XNCL003C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT03', 'EXCHANGE', 'PS1', 'H', 
'XNCL003H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT03', 'EXCHANGE', 'PS1', 'L', 
'XNCL003L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT04', 'EXCHANGE', 'PS1', 'C', 
'XNCL004C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT04', 'EXCHANGE', 'PS1', 'H', 
'XNCL004H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT04', 'EXCHANGE', 'PS1', 'L', 
'XNCL004L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT05', 'EXCHANGE', 'PS1', 'C', 
'XNCL005C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT05', 'EXCHANGE', 'PS1', 'H', 
'XNCL005H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT05', 'EXCHANGE', 'PS1', 'L', 
'XNCL005L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT06', 'EXCHANGE', 'PS1', 'C', 
'XNCL006C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT06', 'EXCHANGE', 'PS1', 'H', 
'XNCL006H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT06', 'EXCHANGE', 'PS1', 'L', 
'XNCL006L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT07', 'EXCHANGE', 'PS1', 'C', 
'XNCL007C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT07', 'EXCHANGE', 'PS1', 'H', 
'XNCL007H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT07', 'EXCHANGE', 'PS1', 'L', 
'XNCL007L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT08', 'EXCHANGE', 'PS1', 'C', 
'XNCL008C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT08', 'EXCHANGE', 'PS1', 'H', 
'XNCL008H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT08', 'EXCHANGE', 'PS1', 'L', 
'XNCL008L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT09', 'EXCHANGE', 'PS1', 'C', 
'XNCL009C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT09', 'EXCHANGE', 'PS1', 'H', 
'XNCL009H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT09', 'EXCHANGE', 'PS1', 'L', 
'XNCL009L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT10', 'EXCHANGE', 'PS1', 'C', 
'XNCL010C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT10', 'EXCHANGE', 'PS1', 'H', 
'XNCL010H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT10', 'EXCHANGE', 'PS1', 'L', 
'XNCL010L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT11', 'EXCHANGE', 'PS1', 'C', 
'XNCL011C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT11', 'EXCHANGE', 'PS1', 'H', 
'XNCL011H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT11', 'EXCHANGE', 'PS1', 'L', 
'XNCL011L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT12', 'EXCHANGE', 'PS1', 'C', 
'XNCL012C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT12', 'EXCHANGE', 'PS1', 'H', 
'XNCL012H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT12', 'EXCHANGE', 'PS1', 'L', 
'XNCL012L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT13', 'EXCHANGE', 'PS1', 'C', 
'XNCL013C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT13', 'EXCHANGE', 'PS1', 'H', 
'XNCL013H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT13', 'EXCHANGE', 'PS1', 'L', 
'XNCL013L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT14', 'EXCHANGE', 'PS1', 'C', 
'XNCL014C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT14', 'EXCHANGE', 'PS1', 'H', 
'XNCL014H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT14', 'EXCHANGE', 'PS1', 'L', 
'XNCL014L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT15', 'EXCHANGE', 'PS1', 'C', 
'XNCL015C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT15', 'EXCHANGE', 'PS1', 'H', 
'XNCL015H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT15', 'EXCHANGE', 'PS1', 'L', 
'XNCL015L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT16', 'EXCHANGE', 'PS1', 'C', 
'XNCL016C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT16', 'EXCHANGE', 'PS1', 'H', 
'XNCL016H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT16', 'EXCHANGE', 'PS1', 'L', 
'XNCL016L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT17', 'EXCHANGE', 'PS1', 'C', 
'XNCL017C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT17', 'EXCHANGE', 'PS1', 'H', 
'XNCL017H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT17', 'EXCHANGE', 'PS1', 'L', 
'XNCL017L', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT18', 'EXCHANGE', 'PS1', 'C', 
'XNCL018C', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT18', 'EXCHANGE', 'PS1', 'H', 
'XNCL018H', NULL, 1)
go

insert into trading_period_alias values(2188, 'SPOT18', 'EXCHANGE', 'PS1', 'L', 
'XNCL018L', NULL, 1)
go

insert into trading_period_alias values(2200, 'SPOT', 'INTERNAL', 'PS1', 'C', 
'DKK00C', NULL, 1)
go

insert into trading_period_alias values(2203, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAID00H', NULL, 1)
go

insert into trading_period_alias values(2203, 'SPOT', 'PLATTS', 'PS1', 'H', 
'POAID00L', NULL, 1)
go

