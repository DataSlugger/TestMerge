print 'Loading additional seed data into the commodity_uom table '
go

insert into commodity_uom values('ABRAINBO', 'L', '%', 1)
go

insert into commodity_uom values('ABRAINBO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ABRAINBO', 'PR', 'MT', 1)
go

insert into commodity_uom values('ABRAINBO', 'T', 'BBL', 1)
go

insert into commodity_uom values('ABRAINBO', 'T', 'MB', 1)
go

insert into commodity_uom values('ABRAINBO', 'T', 'MT', 1)
go

insert into commodity_uom values('ABTEXCOM', 'L', '%', 1)
go

insert into commodity_uom values('ABTEXCOM', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ABTEXCOM', 'PR', 'MT', 1)
go

insert into commodity_uom values('ABTEXCOM', 'T', 'BBL', 1)
go

insert into commodity_uom values('ABTEXCOM', 'T', 'MB', 1)
go

insert into commodity_uom values('ABTEXCOM', 'T', 'MT', 1)
go

insert into commodity_uom values('AH', 'L', '%', 1)
go

insert into commodity_uom values('AH', 'PR', 'BBL', 1)
go

insert into commodity_uom values('AH', 'PR', 'MT', 1)
go

insert into commodity_uom values('AH', 'S', 'MT', 1)
go

insert into commodity_uom values('AH', 'T', 'BBL', 1)
go

insert into commodity_uom values('AH', 'T', 'MB', 1)
go

insert into commodity_uom values('AH', 'T', 'MT', 1)
go

insert into commodity_uom values('AL', 'L', '%', 1)
go

insert into commodity_uom values('AL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('AL', 'PR', 'MT', 1)
go

insert into commodity_uom values('AL', 'T', 'BBL', 1)
go

insert into commodity_uom values('AL', 'T', 'MB', 1)
go

insert into commodity_uom values('AL', 'T', 'MT', 1)
go

insert into commodity_uom values('AL/AH', 'L', '%', 1)
go

insert into commodity_uom values('AL/AH', 'PR', 'BBL', 1)
go

insert into commodity_uom values('AL/AH', 'PR', 'MT', 1)
go

insert into commodity_uom values('AL/AH', 'T', 'BBL', 1)
go

insert into commodity_uom values('AL/AH', 'T', 'MB', 1)
go

insert into commodity_uom values('AL/AH', 'T', 'MT', 1)
go

insert into commodity_uom values('ALB', 'L', '%', 1)
go

insert into commodity_uom values('ALB', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ALB', 'PR', 'MT', 1)
go

insert into commodity_uom values('ALB', 'T', 'BBL', 1)
go

insert into commodity_uom values('ALB', 'T', 'MB', 1)
go

insert into commodity_uom values('ALB', 'T', 'MT', 1)
go

insert into commodity_uom values('ALBA', 'L', '%', 1)
go

insert into commodity_uom values('ALBA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ALBA', 'PR', 'MT', 1)
go

insert into commodity_uom values('ALBA', 'T', 'BBL', 1)
go

insert into commodity_uom values('ALBA', 'T', 'MB', 1)
go

insert into commodity_uom values('ALBA', 'T', 'MT', 1)
go

insert into commodity_uom values('ALGERIAN', 'L', '%', 1)
go

insert into commodity_uom values('ALGERIAN', 'P', 'BBL', 1)
go

insert into commodity_uom values('ALGERIAN', 'P', 'MT', 1)
go

insert into commodity_uom values('ALGERIAN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ALGERIAN', 'PR', 'MT', 1)
go

insert into commodity_uom values('ALGERIAN', 'T', 'BBL', 1)
go

insert into commodity_uom values('ALGERIAN', 'T', 'MB', 1)
go

insert into commodity_uom values('ALGERIAN', 'T', 'MT', 1)
go

insert into commodity_uom values('ALKYLATE', 'L', '%', 1)
go

insert into commodity_uom values('ALKYLATE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ALKYLATE', 'PR', 'GAL', 1)
go

insert into commodity_uom values('ALKYLATE', 'PR', 'MT', 1)
go

insert into commodity_uom values('ALKYLATE', 'T', 'BBL', 1)
go

insert into commodity_uom values('ALKYLATE', 'T', 'GAL', 1)
go

insert into commodity_uom values('ALKYLATE', 'T', 'MB', 1)
go

insert into commodity_uom values('ALKYLATE', 'T', 'MT', 1)
go

insert into commodity_uom values('AM', 'L', '%', 1)
go

insert into commodity_uom values('AM', 'PR', 'BBL', 1)
go

insert into commodity_uom values('AM', 'PR', 'MT', 1)
go

insert into commodity_uom values('AM', 'T', 'BBL', 1)
go

insert into commodity_uom values('AM', 'T', 'MB', 1)
go

insert into commodity_uom values('AM', 'T', 'MT', 1)
go

insert into commodity_uom values('ANS', 'I', 'BBL', 1)
go

insert into commodity_uom values('ANS', 'I', 'MT', 1)
go

insert into commodity_uom values('ANS', 'L', '%', 1)
go

insert into commodity_uom values('ANS', 'P', 'BBL', 1)
go

insert into commodity_uom values('ANS', 'P', 'MT', 1)
go

insert into commodity_uom values('ANS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ANS', 'PR', 'MT', 1)
go

insert into commodity_uom values('ANS', 'T', 'BBL', 1)
go

insert into commodity_uom values('ANS', 'T', 'GAL', 1)
go

insert into commodity_uom values('ANS', 'T', 'MB', 1)
go

insert into commodity_uom values('ANS', 'T', 'MT', 1)
go

insert into commodity_uom values('ANTAN', 'L', '%', 1)
go

insert into commodity_uom values('ANTAN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ANTAN', 'PR', 'MT', 1)
go

insert into commodity_uom values('ANTAN', 'T', 'BBL', 1)
go

insert into commodity_uom values('ANTAN', 'T', 'MB', 1)
go

insert into commodity_uom values('ANTAN', 'T', 'MT', 1)
go

insert into commodity_uom values('ARDJUNA', 'L', '%', 1)
go

insert into commodity_uom values('ARDJUNA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ARDJUNA', 'PR', 'MT', 1)
go

insert into commodity_uom values('ARDJUNA', 'T', 'BBL', 1)
go

insert into commodity_uom values('ARDJUNA', 'T', 'MB', 1)
go

insert into commodity_uom values('ARDJUNA', 'T', 'MT', 1)
go

insert into commodity_uom values('ARUN', 'L', '%', 1)
go

insert into commodity_uom values('ARUN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ARUN', 'PR', 'MT', 1)
go

insert into commodity_uom values('ARUN', 'T', 'BBL', 1)
go

insert into commodity_uom values('ARUN', 'T', 'MB', 1)
go

insert into commodity_uom values('ARUN', 'T', 'MT', 1)
go

insert into commodity_uom values('ASHT', 'L', '%', 1)
go

insert into commodity_uom values('ASHT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ASHT', 'PR', 'MT', 1)
go

insert into commodity_uom values('ASHT', 'T', 'BBL', 1)
go

insert into commodity_uom values('ASHT', 'T', 'MB', 1)
go

insert into commodity_uom values('ASHT', 'T', 'MT', 1)
go

insert into commodity_uom values('ATS', 'I', 'UNIT', 1)
go

insert into commodity_uom values('ATS', 'T', 'UNIT', 1)
go

insert into commodity_uom values('ATTAKA', 'L', '%', 1)
go

insert into commodity_uom values('ATTAKA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ATTAKA', 'PR', 'MT', 1)
go

insert into commodity_uom values('ATTAKA', 'T', 'BBL', 1)
go

insert into commodity_uom values('ATTAKA', 'T', 'MB', 1)
go

insert into commodity_uom values('ATTAKA', 'T', 'MT', 1)
go

insert into commodity_uom values('AVGAS', 'L', '%', 1)
go

insert into commodity_uom values('AVGAS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('AVGAS', 'PR', 'GAL', 1)
go

insert into commodity_uom values('AVGAS', 'PR', 'MT', 1)
go

insert into commodity_uom values('AVGAS', 'T', 'BBL', 1)
go

insert into commodity_uom values('AVGAS', 'T', 'GAL', 1)
go

insert into commodity_uom values('AVGAS', 'T', 'MB', 1)
go

insert into commodity_uom values('AVGAS', 'T', 'MT', 1)
go

insert into commodity_uom values('BACH13', 'L', '%', 1)
go

insert into commodity_uom values('BACH13', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BACH13', 'PR', 'MT', 1)
go

insert into commodity_uom values('BACH13', 'T', 'BBL', 1)
go

insert into commodity_uom values('BACH13', 'T', 'MB', 1)
go

insert into commodity_uom values('BACH13', 'T', 'MT', 1)
go

insert into commodity_uom values('BACH168', 'L', '%', 1)
go

insert into commodity_uom values('BACH168', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BACH168', 'PR', 'MT', 1)
go

insert into commodity_uom values('BACH168', 'T', 'BBL', 1)
go

insert into commodity_uom values('BACH168', 'T', 'MB', 1)
go

insert into commodity_uom values('BACH168', 'T', 'MT', 1)
go

insert into commodity_uom values('BARROWIS', 'L', '%', 1)
go

insert into commodity_uom values('BARROWIS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BARROWIS', 'PR', 'MT', 1)
go

insert into commodity_uom values('BARROWIS', 'T', 'BBL', 1)
go

insert into commodity_uom values('BARROWIS', 'T', 'MB', 1)
go

insert into commodity_uom values('BARROWIS', 'T', 'MT', 1)
go

insert into commodity_uom values('BASRAHLT', 'L', '%', 1)
go

insert into commodity_uom values('BASRAHLT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BASRAHLT', 'PR', 'MT', 1)
go

insert into commodity_uom values('BASRAHLT', 'T', 'BBL', 1)
go

insert into commodity_uom values('BASRAHLT', 'T', 'MB', 1)
go

insert into commodity_uom values('BASRAHLT', 'T', 'MT', 1)
go

insert into commodity_uom values('BBQ', 'L', '%', 1)
go

insert into commodity_uom values('BBQ', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BBQ', 'PR', 'MT', 1)
go

insert into commodity_uom values('BBQ', 'T', 'BBL', 1)
go

insert into commodity_uom values('BBQ', 'T', 'MB', 1)
go

insert into commodity_uom values('BBQ', 'T', 'MT', 1)
go

insert into commodity_uom values('BCF-24', 'L', '%', 1)
go

insert into commodity_uom values('BCF-24', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BCF-24', 'PR', 'MT', 1)
go

insert into commodity_uom values('BCF-24', 'T', 'BBL', 1)
go

insert into commodity_uom values('BCF-24', 'T', 'MB', 1)
go

insert into commodity_uom values('BCF-24', 'T', 'MT', 1)
go

insert into commodity_uom values('BEATRICE', 'L', '%', 1)
go

insert into commodity_uom values('BEATRICE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BEATRICE', 'PR', 'MB', 1)
go

insert into commodity_uom values('BEATRICE', 'PR', 'MT', 1)
go

insert into commodity_uom values('BEATRICE', 'T', 'BBL', 1)
go

insert into commodity_uom values('BEATRICE', 'T', 'MB', 1)
go

insert into commodity_uom values('BEATRICE', 'T', 'MT', 1)
go

insert into commodity_uom values('BEF', 'I', 'UNIT', 1)
go

insert into commodity_uom values('BEF', 'T', 'UNIT', 1)
go

insert into commodity_uom values('BELAYIM', 'L', '%', 1)
go

insert into commodity_uom values('BELAYIM', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BELAYIM', 'PR', 'MT', 1)
go

insert into commodity_uom values('BELAYIM', 'T', 'BBL', 1)
go

insert into commodity_uom values('BELAYIM', 'T', 'MB', 1)
go

insert into commodity_uom values('BELAYIM', 'T', 'MT', 1)
go

insert into commodity_uom values('BELIDA', 'L', '%', 1)
go

insert into commodity_uom values('BELIDA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BELIDA', 'PR', 'MB', 1)
go

insert into commodity_uom values('BELIDA', 'T', 'BBL', 1)
go

insert into commodity_uom values('BELIDA', 'T', 'MB', 1)
go

insert into commodity_uom values('BELIDA', 'T', 'MT', 1)
go

insert into commodity_uom values('BERYL', 'L', '%', 1)
go

insert into commodity_uom values('BERYL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BERYL', 'PR', 'MT', 1)
go

insert into commodity_uom values('BERYL', 'T', 'BBL', 1)
go

insert into commodity_uom values('BERYL', 'T', 'MB', 1)
go

insert into commodity_uom values('BERYL', 'T', 'MT', 1)
go

insert into commodity_uom values('BFR', 'I', 'UNIT', 1)
go

insert into commodity_uom values('BFR', 'T', 'UNIT', 1)
go

insert into commodity_uom values('BIMA', 'L', '%', 1)
go

insert into commodity_uom values('BIMA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BIMA', 'PR', 'MT', 1)
go

insert into commodity_uom values('BIMA', 'T', 'BBL', 1)
go

insert into commodity_uom values('BIMA', 'T', 'MB', 1)
go

insert into commodity_uom values('BIMA', 'T', 'MT', 1)
go

insert into commodity_uom values('BLENHEIM', 'L', '%', 1)
go

insert into commodity_uom values('BLENHEIM', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BLENHEIM', 'PR', 'MB', 1)
go

insert into commodity_uom values('BLENHEIM', 'PR', 'MT', 1)
go

insert into commodity_uom values('BLENHEIM', 'T', 'BBL', 1)
go

insert into commodity_uom values('BLENHEIM', 'T', 'MB', 1)
go

insert into commodity_uom values('BLENHEIM', 'T', 'MT', 1)
go

insert into commodity_uom values('BONNYL', 'L', '%', 1)
go

insert into commodity_uom values('BONNYL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BONNYL', 'PR', 'MT', 1)
go

insert into commodity_uom values('BONNYL', 'S', 'BBL', 1)
go

insert into commodity_uom values('BONNYL', 'T', 'BBL', 1)
go

insert into commodity_uom values('BONNYL', 'T', 'MB', 1)
go

insert into commodity_uom values('BONNYL', 'T', 'MT', 1)
go

insert into commodity_uom values('BONNYM', 'L', '%', 1)
go

insert into commodity_uom values('BONNYM', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BONNYM', 'PR', 'MT', 1)
go

insert into commodity_uom values('BONNYM', 'T', 'BBL', 1)
go

insert into commodity_uom values('BONNYM', 'T', 'MB', 1)
go

insert into commodity_uom values('BONNYM', 'T', 'MT', 1)
go

insert into commodity_uom values('BOWRIVER', 'L', '%', 1)
go

insert into commodity_uom values('BOWRIVER', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BOWRIVER', 'PR', 'MB', 1)
go

insert into commodity_uom values('BOWRIVER', 'PR', 'MT', 1)
go

insert into commodity_uom values('BOWRIVER', 'T', 'BBL', 1)
go

insert into commodity_uom values('BOWRIVER', 'T', 'MB', 1)
go

insert into commodity_uom values('BOWRIVER', 'T', 'MT', 1)
go

insert into commodity_uom values('BRASS', 'L', '%', 1)
go

insert into commodity_uom values('BRASS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BRASS', 'PR', 'MT', 1)
go

insert into commodity_uom values('BRASS', 'T', 'BBL', 1)
go

insert into commodity_uom values('BRASS', 'T', 'MB', 1)
go

insert into commodity_uom values('BRASS', 'T', 'MT', 1)
go

insert into commodity_uom values('BRENT', 'I', 'GAL', 1)
go

insert into commodity_uom values('BRENT', 'L', '%', 1)
go

insert into commodity_uom values('BRENT', 'P', 'GAL', 1)
go

insert into commodity_uom values('BRENT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BRENT', 'PR', 'BU', 1)
go

insert into commodity_uom values('BRENT', 'PR', 'GAL', 1)
go

insert into commodity_uom values('BRENT', 'PR', 'MT', 1)
go

insert into commodity_uom values('BRENT', 'S', 'GAL', 1)
go

insert into commodity_uom values('BRENT', 'T', 'BBL', 1)
go

insert into commodity_uom values('BRENT', 'T', 'GAL', 1)
go

insert into commodity_uom values('BRENT', 'T', 'LOTS', 1)
go

insert into commodity_uom values('BRENT', 'T', 'MB', 1)
go

insert into commodity_uom values('BRENT', 'T', 'MT', 1)
go

insert into commodity_uom values('BRUNEI', 'L', '%', 1)
go

insert into commodity_uom values('BRUNEI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BRUNEI', 'PR', 'MB', 1)
go

insert into commodity_uom values('BRUNEI', 'PR', 'MT', 1)
go

insert into commodity_uom values('BRUNEI', 'T', 'BBL', 1)
go

insert into commodity_uom values('BRUNEI', 'T', 'MB', 1)
go

insert into commodity_uom values('BRUNEI', 'T', 'MT', 1)
go

insert into commodity_uom values('BUNKERS', 'I', 'BBL', 1)
go

insert into commodity_uom values('BUNKERS', 'I', 'MT', 1)
go

insert into commodity_uom values('BUNKERS', 'O', 'BBL', 1)
go

insert into commodity_uom values('BUNKERS', 'O', 'MT', 1)
go

insert into commodity_uom values('BUNKERS', 'P', 'BBL', 1)
go

insert into commodity_uom values('BUNKERS', 'P', 'MT', 1)
go

insert into commodity_uom values('BUNKERS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BUNKERS', 'PR', 'MT', 1)
go

insert into commodity_uom values('BUNKERS', 'S', 'BBL', 1)
go

insert into commodity_uom values('BUNKERS', 'S', 'MT', 1)
go

insert into commodity_uom values('BUNKERS', 'T', 'BBL', 1)
go

insert into commodity_uom values('BUNKERS', 'T', 'MT', 1)
go

insert into commodity_uom values('BUTANE', 'L', '%', 1)
go

insert into commodity_uom values('BUTANE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('BUTANE', 'PR', 'GAL', 1)
go

insert into commodity_uom values('BUTANE', 'PR', 'MT', 1)
go

insert into commodity_uom values('BUTANE', 'T', 'BBL', 1)
go

insert into commodity_uom values('BUTANE', 'T', 'GAL', 1)
go

insert into commodity_uom values('BUTANE', 'T', 'MB', 1)
go

insert into commodity_uom values('BUTANE', 'T', 'MT', 1)
go

insert into commodity_uom values('CABIMAS', 'L', '%', 1)
go

insert into commodity_uom values('CABIMAS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('CABIMAS', 'PR', 'MB', 1)
go

insert into commodity_uom values('CABIMAS', 'PR', 'MT', 1)
go

insert into commodity_uom values('CABIMAS', 'T', 'BBL', 1)
go

insert into commodity_uom values('CABIMAS', 'T', 'MB', 1)
go

insert into commodity_uom values('CABIMAS', 'T', 'MT', 1)
go

insert into commodity_uom values('CABINDA', 'L', '%', 1)
go

insert into commodity_uom values('CABINDA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('CABINDA', 'PR', 'MT', 1)
go

insert into commodity_uom values('CABINDA', 'T', 'BBL', 1)
go

insert into commodity_uom values('CABINDA', 'T', 'MB', 1)
go

insert into commodity_uom values('CABINDA', 'T', 'MT', 1)
go

insert into commodity_uom values('CAC', 'O', 'UNIT', 1)
go

insert into commodity_uom values('CAC', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CAC', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CANADONS', 'L', '%', 1)
go

insert into commodity_uom values('CANADONS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('CANADONS', 'PR', 'MT', 1)
go

insert into commodity_uom values('CANADONS', 'T', 'BBL', 1)
go

insert into commodity_uom values('CANADONS', 'T', 'MB', 1)
go

insert into commodity_uom values('CANADONS', 'T', 'MT', 1)
go

insert into commodity_uom values('CANOHVY', 'L', '%', 1)
go

insert into commodity_uom values('CANOHVY', 'PR', 'BBL', 1)
go

insert into commodity_uom values('CANOHVY', 'PR', 'MT', 1)
go

insert into commodity_uom values('CANOHVY', 'T', 'BBL', 1)
go

insert into commodity_uom values('CANOHVY', 'T', 'MB', 1)
go

insert into commodity_uom values('CANOHVY', 'T', 'MT', 1)
go

insert into commodity_uom values('CANOLIMO', 'L', '%', 1)
go

insert into commodity_uom values('CANOLIMO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('CANOLIMO', 'PR', 'MT', 1)
go

insert into commodity_uom values('CANOLIMO', 'T', 'BBL', 1)
go

insert into commodity_uom values('CANOLIMO', 'T', 'MB', 1)
go

insert into commodity_uom values('CANOLIMO', 'T', 'MT', 1)
go

insert into commodity_uom values('CAPTAIN', 'I', 'BBL', 1)
go

insert into commodity_uom values('CAPTAIN', 'L', '%', 1)
go

insert into commodity_uom values('CAPTAIN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('CAPTAIN', 'PR', 'MB', 1)
go

insert into commodity_uom values('CAPTAIN', 'T', 'BBL', 1)
go

insert into commodity_uom values('CAPTAIN', 'T', 'MB', 1)
go

insert into commodity_uom values('CAPTAIN', 'T', 'MT', 1)
go

insert into commodity_uom values('CARB', 'L', '%', 1)
go

insert into commodity_uom values('CARB', 'PR', 'BBL', 1)
go

insert into commodity_uom values('CARB', 'PR', 'GAL', 1)
go

insert into commodity_uom values('CARB', 'PR', 'MT', 1)
go

insert into commodity_uom values('CARB', 'T', 'BBL', 1)
go

insert into commodity_uom values('CARB', 'T', 'GAL', 1)
go

insert into commodity_uom values('CARB', 'T', 'MB', 1)
go

insert into commodity_uom values('CARB', 'T', 'MT', 1)
go

insert into commodity_uom values('CHALLIS', 'L', '%', 1)
go

insert into commodity_uom values('CHALLIS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('CHALLIS', 'PR', 'MT', 1)
go

insert into commodity_uom values('CHALLIS', 'T', 'BBL', 1)
go

insert into commodity_uom values('CHALLIS', 'T', 'MB', 1)
go

insert into commodity_uom values('CHALLIS', 'T', 'MT', 1)
go

insert into commodity_uom values('CHUBUT', 'L', '%', 1)
go

insert into commodity_uom values('CHUBUT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('CHUBUT', 'PR', 'MT', 1)
go

insert into commodity_uom values('CHUBUT', 'T', 'BBL', 1)
go

insert into commodity_uom values('CHUBUT', 'T', 'MB', 1)
go

insert into commodity_uom values('CHUBUT', 'T', 'MT', 1)
go

insert into commodity_uom values('CINTA', 'L', '%', 1)
go

insert into commodity_uom values('CINTA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('CINTA', 'PR', 'MT', 1)
go

insert into commodity_uom values('CINTA', 'T', 'BBL', 1)
go

insert into commodity_uom values('CINTA', 'T', 'MB', 1)
go

insert into commodity_uom values('CINTA', 'T', 'MT', 1)
go

insert into commodity_uom values('COBAN', 'L', '%', 1)
go

insert into commodity_uom values('COBAN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('COBAN', 'PR', 'MT', 1)
go

insert into commodity_uom values('COBAN', 'T', 'BBL', 1)
go

insert into commodity_uom values('COBAN', 'T', 'MB', 1)
go

insert into commodity_uom values('COBAN', 'T', 'MT', 1)
go

insert into commodity_uom values('CRUDE', 'S', 'BBL', 1)
go

insert into commodity_uom values('CRUDE', 'T', 'BBL', 1)
go

insert into commodity_uom values('CURRAUS', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRAUS', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRAUS', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRAUS', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRAUS', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRAUS', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRBEF', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRBEF', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRBEF', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRBEF', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRBEF', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRBEF', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRCAN', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRCAN', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRCAN', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRCAN', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRCAN', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRCAN', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRCHF', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRCHF', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRCHF', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRCHF', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRCHF', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRCHF', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRDEM', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRDEM', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRDEM', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRDEM', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRDEM', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRDEM', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRDKK', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRDKK', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRDKK', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRDKK', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRDKK', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRDKK', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRECU', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRECU', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRECU', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRECU', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRECU', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRECU', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRESP', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRESP', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRESP', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRESP', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRESP', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRESP', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRFRF', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRFRF', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRFRF', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRFRF', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRFRF', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRFRF', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRGBP', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRGBP', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRGBP', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRGBP', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRGBP', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRGBP', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRITL', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRITL', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRITL', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRITL', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRITL', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRITL', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRJPY', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRJPY', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRJPY', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRJPY', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRJPY', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRJPY', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRMYR', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRMYR', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRMYR', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRMYR', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRMYR', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRMYR', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRNLG', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRNLG', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRNLG', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRNLG', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRNLG', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRNLG', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRNOK', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRNOK', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRNOK', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRNOK', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRNOK', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRNOK', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRSAR', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRSAR', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRSAR', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRSAR', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRSAR', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRSAR', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRSEK', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRSEK', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRSEK', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRSEK', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRSEK', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRSEK', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRSGD', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRSGD', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRSGD', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRSGD', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRSGD', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRSGD', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRUSC', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRUSC', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRUSC', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRUSC', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRUSC', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRUSC', 'T', 'UNIT', 1)
go

insert into commodity_uom values('CURRUSD', 'PR', 'MMUN', 1)
go

insert into commodity_uom values('CURRUSD', 'PR', 'MUN', 1)
go

insert into commodity_uom values('CURRUSD', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('CURRUSD', 'T', 'MMUN', 1)
go

insert into commodity_uom values('CURRUSD', 'T', 'MUN', 1)
go

insert into commodity_uom values('CURRUSD', 'T', 'UNIT', 1)
go

insert into commodity_uom values('DANKRN', 'I', 'UNIT', 1)
go

insert into commodity_uom values('DANKRN', 'O', 'UNIT', 1)
go

insert into commodity_uom values('DANKRN', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('DANKRN', 'S', 'UNIT', 1)
go

insert into commodity_uom values('DANKRN', 'T', 'UNIT', 1)
go

insert into commodity_uom values('DAQING', 'L', '%', 1)
go

insert into commodity_uom values('DAQING', 'PR', 'BBL', 1)
go

insert into commodity_uom values('DAQING', 'PR', 'MT', 1)
go

insert into commodity_uom values('DAQING', 'T', 'BBL', 1)
go

insert into commodity_uom values('DAQING', 'T', 'MB', 1)
go

insert into commodity_uom values('DAQING', 'T', 'MT', 1)
go

insert into commodity_uom values('DATED', 'I', 'GAL', 1)
go

insert into commodity_uom values('DATED', 'P', 'GAL', 1)
go

insert into commodity_uom values('DATED', 'PR', 'BBL', 1)
go

insert into commodity_uom values('DATED', 'PR', 'GAL', 1)
go

insert into commodity_uom values('DATED', 'S', 'GAL', 1)
go

insert into commodity_uom values('DATED', 'T', 'BBL', 1)
go

insert into commodity_uom values('DATED', 'T', 'GAL', 1)
go

insert into commodity_uom values('DATED', 'T', 'MB', 1)
go

insert into commodity_uom values('DEM', 'I', 'UNIT', 1)
go

insert into commodity_uom values('DEM', 'T', 'UNIT', 1)
go

insert into commodity_uom values('DJENO', 'L', '%', 1)
go

insert into commodity_uom values('DJENO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('DJENO', 'PR', 'MT', 1)
go

insert into commodity_uom values('DJENO', 'T', 'BBL', 1)
go

insert into commodity_uom values('DJENO', 'T', 'MB', 1)
go

insert into commodity_uom values('DJENO', 'T', 'MT', 1)
go

insert into commodity_uom values('DM', 'P', 'UNIT', 1)
go

insert into commodity_uom values('DM', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('DM', 'T', 'UNIT', 1)
go

insert into commodity_uom values('DOMSWEET', 'L', '%', 1)
go

insert into commodity_uom values('DOMSWEET', 'PR', 'BBL', 1)
go

insert into commodity_uom values('DOMSWEET', 'PR', 'MT', 1)
go

insert into commodity_uom values('DOMSWEET', 'T', 'BBL', 1)
go

insert into commodity_uom values('DOMSWEET', 'T', 'MB', 1)
go

insert into commodity_uom values('DOMSWEET', 'T', 'MT', 1)
go

insert into commodity_uom values('DRAUGEN', 'L', '%', 1)
go

insert into commodity_uom values('DRAUGEN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('DRAUGEN', 'PR', 'MT', 1)
go

insert into commodity_uom values('DRAUGEN', 'T', 'BBL', 1)
go

insert into commodity_uom values('DRAUGEN', 'T', 'MB', 1)
go

insert into commodity_uom values('DRAUGEN', 'T', 'MT', 1)
go

insert into commodity_uom values('DUB-DIST', 'L', '%', 1)
go

insert into commodity_uom values('DUB-DIST', 'P', 'BBL', 1)
go

insert into commodity_uom values('DUB-DIST', 'PR', 'BBL', 1)
go

insert into commodity_uom values('DUB-DIST', 'T', 'BBL', 1)
go

insert into commodity_uom values('DUB-DIST', 'T', 'MB', 1)
go

insert into commodity_uom values('DUB-DIST', 'T', 'MT', 1)
go

insert into commodity_uom values('DUBAI', 'L', '%', 1)
go

insert into commodity_uom values('DUBAI', 'P', 'BBL', 1)
go

insert into commodity_uom values('DUBAI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('DUBAI', 'PR', 'MT', 1)
go

insert into commodity_uom values('DUBAI', 'T', 'BBL', 1)
go

insert into commodity_uom values('DUBAI', 'T', 'MB', 1)
go

insert into commodity_uom values('DUBAI', 'T', 'MT', 1)
go

insert into commodity_uom values('DUC', 'L', '%', 1)
go

insert into commodity_uom values('DUC', 'PR', 'BBL', 1)
go

insert into commodity_uom values('DUC', 'PR', 'MT', 1)
go

insert into commodity_uom values('DUC', 'T', 'BBL', 1)
go

insert into commodity_uom values('DUC', 'T', 'MB', 1)
go

insert into commodity_uom values('DUC', 'T', 'MT', 1)
go

insert into commodity_uom values('DURI', 'L', '%', 1)
go

insert into commodity_uom values('DURI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('DURI', 'PR', 'MT', 1)
go

insert into commodity_uom values('DURI', 'T', 'BBL', 1)
go

insert into commodity_uom values('DURI', 'T', 'MB', 1)
go

insert into commodity_uom values('DURI', 'T', 'MT', 1)
go

insert into commodity_uom values('DURWARD', 'L', '%', 1)
go

insert into commodity_uom values('DURWARD', 'PR', 'BBL', 1)
go

insert into commodity_uom values('DURWARD', 'PR', 'MT', 1)
go

insert into commodity_uom values('DURWARD', 'T', 'BBL', 1)
go

insert into commodity_uom values('DURWARD', 'T', 'MB', 1)
go

insert into commodity_uom values('DURWARD', 'T', 'MT', 1)
go

insert into commodity_uom values('E4F', 'L', '%', 1)
go

insert into commodity_uom values('E4F', 'PR', 'BBL', 1)
go

insert into commodity_uom values('E4F', 'PR', 'MT', 1)
go

insert into commodity_uom values('E4F', 'T', 'BBL', 1)
go

insert into commodity_uom values('E4F', 'T', 'GAL', 1)
go

insert into commodity_uom values('E4F', 'T', 'MB', 1)
go

insert into commodity_uom values('E4F', 'T', 'MT', 1)
go

insert into commodity_uom values('EKOFISK', 'L', '%', 1)
go

insert into commodity_uom values('EKOFISK', 'PR', 'BBL', 1)
go

insert into commodity_uom values('EKOFISK', 'PR', 'MT', 1)
go

insert into commodity_uom values('EKOFISK', 'T', 'BBL', 1)
go

insert into commodity_uom values('EKOFISK', 'T', 'MB', 1)
go

insert into commodity_uom values('EKOFISK', 'T', 'MT', 1)
go

insert into commodity_uom values('EN228', 'L', '%', 1)
go

insert into commodity_uom values('EN228', 'PR', 'BBL', 1)
go

insert into commodity_uom values('EN228', 'PR', 'GAL', 1)
go

insert into commodity_uom values('EN228', 'PR', 'MT', 1)
go

insert into commodity_uom values('EN228', 'T', 'BBL', 1)
go

insert into commodity_uom values('EN228', 'T', 'GAL', 1)
go

insert into commodity_uom values('EN228', 'T', 'MB', 1)
go

insert into commodity_uom values('EN228', 'T', 'MT', 1)
go

insert into commodity_uom values('EOCENE', 'L', '%', 1)
go

insert into commodity_uom values('EOCENE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('EOCENE', 'PR', 'MB', 1)
go

insert into commodity_uom values('EOCENE', 'T', 'BBL', 1)
go

insert into commodity_uom values('EOCENE', 'T', 'MB', 1)
go

insert into commodity_uom values('EOCENE', 'T', 'MT', 1)
go

insert into commodity_uom values('ES SIDER', 'L', '%', 1)
go

insert into commodity_uom values('ES SIDER', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ES SIDER', 'PR', 'MT', 1)
go

insert into commodity_uom values('ES SIDER', 'T', 'BBL', 1)
go

insert into commodity_uom values('ES SIDER', 'T', 'MB', 1)
go

insert into commodity_uom values('ES SIDER', 'T', 'MT', 1)
go

insert into commodity_uom values('ESCALANT', 'L', '%', 1)
go

insert into commodity_uom values('ESCALANT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ESCALANT', 'PR', 'MT', 1)
go

insert into commodity_uom values('ESCALANT', 'T', 'BBL', 1)
go

insert into commodity_uom values('ESCALANT', 'T', 'MB', 1)
go

insert into commodity_uom values('ESCALANT', 'T', 'MT', 1)
go

insert into commodity_uom values('ESCRAVOS', 'L', '%', 1)
go

insert into commodity_uom values('ESCRAVOS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ESCRAVOS', 'PR', 'MT', 1)
go

insert into commodity_uom values('ESCRAVOS', 'T', 'BBL', 1)
go

insert into commodity_uom values('ESCRAVOS', 'T', 'MB', 1)
go

insert into commodity_uom values('ESCRAVOS', 'T', 'MT', 1)
go

insert into commodity_uom values('ESP', 'I', 'UNIT', 1)
go

insert into commodity_uom values('ESP', 'T', 'UNIT', 1)
go

insert into commodity_uom values('ETHVY', 'L', '%', 1)
go

insert into commodity_uom values('ETHVY', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ETHVY', 'PR', 'MT', 1)
go

insert into commodity_uom values('ETHVY', 'T', 'BBL', 1)
go

insert into commodity_uom values('ETHVY', 'T', 'MB', 1)
go

insert into commodity_uom values('ETHVY', 'T', 'MT', 1)
go

insert into commodity_uom values('ETSWT', 'L', '%', 1)
go

insert into commodity_uom values('ETSWT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ETSWT', 'PR', 'MT', 1)
go

insert into commodity_uom values('ETSWT', 'T', 'BBL', 1)
go

insert into commodity_uom values('ETSWT', 'T', 'MB', 1)
go

insert into commodity_uom values('ETSWT', 'T', 'MT', 1)
go

insert into commodity_uom values('EUGENE', 'L', '%', 1)
go

insert into commodity_uom values('EUGENE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('EUGENE', 'PR', 'GAL', 1)
go

insert into commodity_uom values('EUGENE', 'PR', 'MT', 1)
go

insert into commodity_uom values('EUGENE', 'T', 'BBL', 1)
go

insert into commodity_uom values('EUGENE', 'T', 'MB', 1)
go

insert into commodity_uom values('EUGENE', 'T', 'MT', 1)
go

insert into commodity_uom values('EURODLR', 'I', 'UNIT', 1)
go

insert into commodity_uom values('EURODLR', 'O', 'UNIT', 1)
go

insert into commodity_uom values('EURODLR', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('FFR', 'I', 'UNIT', 1)
go

insert into commodity_uom values('FFR', 'T', 'UNIT', 1)
go

insert into commodity_uom values('FIFE', 'L', '%', 1)
go

insert into commodity_uom values('FIFE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('FIFE', 'PR', 'MT', 1)
go

insert into commodity_uom values('FIFE', 'T', 'BBL', 1)
go

insert into commodity_uom values('FIFE', 'T', 'MB', 1)
go

insert into commodity_uom values('FIFE', 'T', 'MT', 1)
go

insert into commodity_uom values('FLOTTA', 'L', '%', 1)
go

insert into commodity_uom values('FLOTTA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('FLOTTA', 'PR', 'MT', 1)
go

insert into commodity_uom values('FLOTTA', 'T', 'BBL', 1)
go

insert into commodity_uom values('FLOTTA', 'T', 'MB', 1)
go

insert into commodity_uom values('FLOTTA', 'T', 'MT', 1)
go

insert into commodity_uom values('FORCADOS', 'L', '%', 1)
go

insert into commodity_uom values('FORCADOS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('FORCADOS', 'PR', 'MT', 1)
go

insert into commodity_uom values('FORCADOS', 'T', 'BBL', 1)
go

insert into commodity_uom values('FORCADOS', 'T', 'MB', 1)
go

insert into commodity_uom values('FORCADOS', 'T', 'MT', 1)
go

insert into commodity_uom values('FORTIES', 'L', '%', 1)
go

insert into commodity_uom values('FORTIES', 'P', '%', 1)
go

insert into commodity_uom values('FORTIES', 'P', 'BBL', 1)
go

insert into commodity_uom values('FORTIES', 'P', 'MB', 1)
go

insert into commodity_uom values('FORTIES', 'P', 'MT', 1)
go

insert into commodity_uom values('FORTIES', 'PR', 'BBL', 1)
go

insert into commodity_uom values('FORTIES', 'PR', 'MB', 1)
go

insert into commodity_uom values('FORTIES', 'PR', 'MT', 1)
go

insert into commodity_uom values('FORTIES', 'T', 'BBL', 1)
go

insert into commodity_uom values('FORTIES', 'T', 'MB', 1)
go

insert into commodity_uom values('FORTIES', 'T', 'MT', 1)
go

insert into commodity_uom values('FUELOIL', 'L', '%', 1)
go

insert into commodity_uom values('FUELOIL', 'P', 'LOTS', 1)
go

insert into commodity_uom values('FUELOIL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('FUELOIL', 'PR', 'LOTS', 1)
go

insert into commodity_uom values('FUELOIL', 'PR', 'MT', 1)
go

insert into commodity_uom values('FUELOIL', 'T', 'BBL', 1)
go

insert into commodity_uom values('FUELOIL', 'T', 'GAL', 1)
go

insert into commodity_uom values('FUELOIL', 'T', 'LOTS', 1)
go

insert into commodity_uom values('FUELOIL', 'T', 'MB', 1)
go

insert into commodity_uom values('FUELOIL', 'T', 'MT', 1)
go

insert into commodity_uom values('FULMAR', 'L', '%', 1)
go

insert into commodity_uom values('FULMAR', 'PR', 'BBL', 1)
go

insert into commodity_uom values('FULMAR', 'PR', 'MT', 1)
go

insert into commodity_uom values('FULMAR', 'T', 'BBL', 1)
go

insert into commodity_uom values('FULMAR', 'T', 'MB', 1)
go

insert into commodity_uom values('FULMAR', 'T', 'MT', 1)
go

insert into commodity_uom values('FURRIAL', 'L', '%', 1)
go

insert into commodity_uom values('FURRIAL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('FURRIAL', 'PR', 'MT', 1)
go

insert into commodity_uom values('FURRIAL', 'T', 'BBL', 1)
go

insert into commodity_uom values('FURRIAL', 'T', 'MB', 1)
go

insert into commodity_uom values('FURRIAL', 'T', 'MT', 1)
go

insert into commodity_uom values('GALEOTA', 'I', 'BBL', 1)
go

insert into commodity_uom values('GALEOTA', 'I', 'MB', 1)
go

insert into commodity_uom values('GALEOTA', 'I', 'MT', 1)
go

insert into commodity_uom values('GALEOTA', 'L', '%', 1)
go

insert into commodity_uom values('GALEOTA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GALEOTA', 'PR', 'MB', 1)
go

insert into commodity_uom values('GALEOTA', 'PR', 'MT', 1)
go

insert into commodity_uom values('GALEOTA', 'T', 'BBL', 1)
go

insert into commodity_uom values('GALEOTA', 'T', 'MB', 1)
go

insert into commodity_uom values('GALEOTA', 'T', 'MT', 1)
go

insert into commodity_uom values('GAMBA', 'L', '%', 1)
go

insert into commodity_uom values('GAMBA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GAMBA', 'PR', 'MT', 1)
go

insert into commodity_uom values('GAMBA', 'T', 'BBL', 1)
go

insert into commodity_uom values('GAMBA', 'T', 'MB', 1)
go

insert into commodity_uom values('GAMBA', 'T', 'MT', 1)
go

insert into commodity_uom values('GASOIL', 'L', '%', 1)
go

insert into commodity_uom values('GASOIL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GASOIL', 'PR', 'GAL', 1)
go

insert into commodity_uom values('GASOIL', 'PR', 'MT', 1)
go

insert into commodity_uom values('GASOIL', 'S', 'MT', 1)
go

insert into commodity_uom values('GASOIL', 'T', 'BBL', 1)
go

insert into commodity_uom values('GASOIL', 'T', 'GAL', 1)
go

insert into commodity_uom values('GASOIL', 'T', 'MB', 1)
go

insert into commodity_uom values('GASOIL', 'T', 'MT', 1)
go

insert into commodity_uom values('GASOIL1', 'L', '%', 1)
go

insert into commodity_uom values('GASOIL1', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GASOIL1', 'PR', 'MT', 1)
go

insert into commodity_uom values('GASOIL1', 'T', 'BBL', 1)
go

insert into commodity_uom values('GASOIL1', 'T', 'MB', 1)
go

insert into commodity_uom values('GASOIL1', 'T', 'MT', 1)
go

insert into commodity_uom values('GASOIL2', 'L', '%', 1)
go

insert into commodity_uom values('GASOIL2', 'PR', 'MT', 1)
go

insert into commodity_uom values('GASOIL2', 'S', 'MT', 1)
go

insert into commodity_uom values('GASOIL2', 'T', 'BBL', 1)
go

insert into commodity_uom values('GASOIL2', 'T', 'GAL', 1)
go

insert into commodity_uom values('GASOIL2', 'T', 'MB', 1)
go

insert into commodity_uom values('GASOIL2', 'T', 'MT', 1)
go

insert into commodity_uom values('GASOIL3', 'L', '%', 1)
go

insert into commodity_uom values('GASOIL3', 'PR', 'MT', 1)
go

insert into commodity_uom values('GASOIL3', 'S', 'MT', 1)
go

insert into commodity_uom values('GASOIL3', 'T', 'BBL', 1)
go

insert into commodity_uom values('GASOIL3', 'T', 'GAL', 1)
go

insert into commodity_uom values('GASOIL3', 'T', 'MB', 1)
go

insert into commodity_uom values('GASOIL3', 'T', 'MT', 1)
go

insert into commodity_uom values('GASOIL5', 'L', '%', 1)
go

insert into commodity_uom values('GASOIL5', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GASOIL5', 'PR', 'GAL', 1)
go

insert into commodity_uom values('GASOIL5', 'PR', 'MT', 1)
go

insert into commodity_uom values('GASOIL5', 'S', 'MT', 1)
go

insert into commodity_uom values('GASOIL5', 'T', 'BBL', 1)
go

insert into commodity_uom values('GASOIL5', 'T', 'GAL', 1)
go

insert into commodity_uom values('GASOIL5', 'T', 'MB', 1)
go

insert into commodity_uom values('GASOIL5', 'T', 'MT', 1)
go

insert into commodity_uom values('GASOILCR', 'L', '%', 1)
go

insert into commodity_uom values('GASOILCR', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GASOILCR', 'PR', 'MT', 1)
go

insert into commodity_uom values('GASOILCR', 'S', 'MT', 1)
go

insert into commodity_uom values('GASOILCR', 'T', 'BBL', 1)
go

insert into commodity_uom values('GASOILCR', 'T', 'MB', 1)
go

insert into commodity_uom values('GASOILCR', 'T', 'MT', 1)
go

insert into commodity_uom values('GASOILIP', 'L', '%', 1)
go

insert into commodity_uom values('GASOILIP', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GASOILIP', 'PR', 'MT', 1)
go

insert into commodity_uom values('GASOILIP', 'S', 'MT', 1)
go

insert into commodity_uom values('GASOILIP', 'T', 'BBL', 1)
go

insert into commodity_uom values('GASOILIP', 'T', 'GAL', 1)
go

insert into commodity_uom values('GASOILIP', 'T', 'MB', 1)
go

insert into commodity_uom values('GASOILIP', 'T', 'MT', 1)
go

insert into commodity_uom values('GASOILLP', 'L', '%', 1)
go

insert into commodity_uom values('GASOILLP', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GASOILLP', 'PR', 'MT', 1)
go

insert into commodity_uom values('GASOILLP', 'T', 'BBL', 1)
go

insert into commodity_uom values('GASOILLP', 'T', 'GAL', 1)
go

insert into commodity_uom values('GASOILLP', 'T', 'MB', 1)
go

insert into commodity_uom values('GASOILLP', 'T', 'MT', 1)
go

insert into commodity_uom values('GASOILP', 'L', '%', 1)
go

insert into commodity_uom values('GASOILP', 'T', 'BBL', 1)
go

insert into commodity_uom values('GASOILP', 'T', 'GAL', 1)
go

insert into commodity_uom values('GASOILP', 'T', 'MB', 1)
go

insert into commodity_uom values('GASOILPR', 'L', '%', 1)
go

insert into commodity_uom values('GASOILPR', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GASOILPR', 'PR', 'MT', 1)
go

insert into commodity_uom values('GASOILPR', 'S', 'MT', 1)
go

insert into commodity_uom values('GASOILPR', 'T', 'BBL', 1)
go

insert into commodity_uom values('GASOILPR', 'T', 'MB', 1)
go

insert into commodity_uom values('GASOILPR', 'T', 'MT', 1)
go

insert into commodity_uom values('GBP', 'I', 'UNIT', 1)
go

insert into commodity_uom values('GBP', 'O', 'UNIT', 1)
go

insert into commodity_uom values('GBP', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('GBP', 'T', 'UNIT', 1)
go

insert into commodity_uom values('GCLC', 'L', '%', 1)
go

insert into commodity_uom values('GCLC', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GCLC', 'PR', 'MT', 1)
go

insert into commodity_uom values('GCLC', 'T', 'BBL', 1)
go

insert into commodity_uom values('GCLC', 'T', 'MB', 1)
go

insert into commodity_uom values('GCLC', 'T', 'MT', 1)
go

insert into commodity_uom values('GIPPS', 'L', '%', 1)
go

insert into commodity_uom values('GIPPS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GIPPS', 'PR', 'MT', 1)
go

insert into commodity_uom values('GIPPS', 'T', 'BBL', 1)
go

insert into commodity_uom values('GIPPS', 'T', 'MB', 1)
go

insert into commodity_uom values('GIPPS', 'T', 'MT', 1)
go

insert into commodity_uom values('GOIL590', 'L', '%', 1)
go

insert into commodity_uom values('GOIL590', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GOIL590', 'PR', 'GAL', 1)
go

insert into commodity_uom values('GOIL590', 'PR', 'MT', 1)
go

insert into commodity_uom values('GOIL590', 'S', 'MT', 1)
go

insert into commodity_uom values('GOIL590', 'T', 'BBL', 1)
go

insert into commodity_uom values('GOIL590', 'T', 'GAL', 1)
go

insert into commodity_uom values('GOIL590', 'T', 'MB', 1)
go

insert into commodity_uom values('GOIL590', 'T', 'MT', 1)
go

insert into commodity_uom values('GUAFITA', 'L', '%', 1)
go

insert into commodity_uom values('GUAFITA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GUAFITA', 'PR', 'MT', 1)
go

insert into commodity_uom values('GUAFITA', 'T', 'BBL', 1)
go

insert into commodity_uom values('GUAFITA', 'T', 'MB', 1)
go

insert into commodity_uom values('GUAFITA', 'T', 'MT', 1)
go

insert into commodity_uom values('GULLFAKC', 'L', '%', 1)
go

insert into commodity_uom values('GULLFAKC', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GULLFAKC', 'PR', 'MT', 1)
go

insert into commodity_uom values('GULLFAKC', 'T', 'BBL', 1)
go

insert into commodity_uom values('GULLFAKC', 'T', 'MB', 1)
go

insert into commodity_uom values('GULLFAKC', 'T', 'MT', 1)
go

insert into commodity_uom values('GULLFAKS', 'L', '%', 1)
go

insert into commodity_uom values('GULLFAKS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('GULLFAKS', 'PR', 'MT', 1)
go

insert into commodity_uom values('GULLFAKS', 'T', 'BBL', 1)
go

insert into commodity_uom values('GULLFAKS', 'T', 'MB', 1)
go

insert into commodity_uom values('GULLFAKS', 'T', 'MT', 1)
go

insert into commodity_uom values('HANDIL', 'L', '%', 1)
go

insert into commodity_uom values('HANDIL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('HANDIL', 'PR', 'MT', 1)
go

insert into commodity_uom values('HANDIL', 'T', 'BBL', 1)
go

insert into commodity_uom values('HANDIL', 'T', 'MB', 1)
go

insert into commodity_uom values('HANDIL', 'T', 'MT', 1)
go

insert into commodity_uom values('HARDING', 'L', '%', 1)
go

insert into commodity_uom values('HARDING', 'PR', 'BBL', 1)
go

insert into commodity_uom values('HARDING', 'PR', 'MT', 1)
go

insert into commodity_uom values('HARDING', 'T', 'BBL', 1)
go

insert into commodity_uom values('HARDING', 'T', 'MB', 1)
go

insert into commodity_uom values('HARDING', 'T', 'MT', 1)
go

insert into commodity_uom values('HELMBL', 'L', '%', 1)
go

insert into commodity_uom values('HELMBL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('HELMBL', 'PR', 'MT', 1)
go

insert into commodity_uom values('HELMBL', 'T', 'BBL', 1)
go

insert into commodity_uom values('HELMBL', 'T', 'MB', 1)
go

insert into commodity_uom values('HELMBL', 'T', 'MT', 1)
go

insert into commodity_uom values('HISC', 'L', '%', 1)
go

insert into commodity_uom values('HISC', 'PR', 'BBL', 1)
go

insert into commodity_uom values('HISC', 'PR', 'MT', 1)
go

insert into commodity_uom values('HISC', 'T', 'BBL', 1)
go

insert into commodity_uom values('HISC', 'T', 'MB', 1)
go

insert into commodity_uom values('HISC', 'T', 'MT', 1)
go

insert into commodity_uom values('HLS', 'L', '%', 1)
go

insert into commodity_uom values('HLS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('HLS', 'PR', 'MT', 1)
go

insert into commodity_uom values('HLS', 'T', 'BBL', 1)
go

insert into commodity_uom values('HLS', 'T', 'MB', 1)
go

insert into commodity_uom values('HLS', 'T', 'MT', 1)
go

insert into commodity_uom values('HO', 'L', '%', 1)
go

insert into commodity_uom values('HO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('HO', 'PR', 'GAL', 1)
go

insert into commodity_uom values('HO', 'PR', 'MT', 1)
go

insert into commodity_uom values('HO', 'T', 'BBL', 1)
go

insert into commodity_uom values('HO', 'T', 'GAL', 1)
go

insert into commodity_uom values('HO', 'T', 'MB', 1)
go

insert into commodity_uom values('HO', 'T', 'MG', 1)
go

insert into commodity_uom values('HO', 'T', 'MT', 1)
go

insert into commodity_uom values('HSFO180', 'L', '%', 1)
go

insert into commodity_uom values('HSFO180', 'PR', 'BBL', 1)
go

insert into commodity_uom values('HSFO180', 'PR', 'GAL', 1)
go

insert into commodity_uom values('HSFO180', 'PR', 'MT', 1)
go

insert into commodity_uom values('HSFO180', 'T', 'BBL', 1)
go

insert into commodity_uom values('HSFO180', 'T', 'GAL', 1)
go

insert into commodity_uom values('HSFO180', 'T', 'M3', 1)
go

insert into commodity_uom values('HSFO180', 'T', 'MB', 1)
go

insert into commodity_uom values('HSFO180', 'T', 'MT', 1)
go

insert into commodity_uom values('HSFO380', 'L', '%', 1)
go

insert into commodity_uom values('HSFO380', 'PR', 'BBL', 1)
go

insert into commodity_uom values('HSFO380', 'PR', 'GAL', 1)
go

insert into commodity_uom values('HSFO380', 'PR', 'MT', 1)
go

insert into commodity_uom values('HSFO380', 'T', 'BBL', 1)
go

insert into commodity_uom values('HSFO380', 'T', 'GAL', 1)
go

insert into commodity_uom values('HSFO380', 'T', 'M3', 1)
go

insert into commodity_uom values('HSFO380', 'T', 'MB', 1)
go

insert into commodity_uom values('HSFO380', 'T', 'MT', 1)
go

insert into commodity_uom values('HSRESID', 'L', '%', 1)
go

insert into commodity_uom values('HSRESID', 'PR', 'BBL', 1)
go

insert into commodity_uom values('HSRESID', 'PR', 'MT', 1)
go

insert into commodity_uom values('HSRESID', 'T', 'BBL', 1)
go

insert into commodity_uom values('HSRESID', 'T', 'GAL', 1)
go

insert into commodity_uom values('HSRESID', 'T', 'MB', 1)
go

insert into commodity_uom values('HSRESID', 'T', 'MT', 1)
go

insert into commodity_uom values('HUDSON', 'L', '%', 1)
go

insert into commodity_uom values('HUDSON', 'PR', 'BBL', 1)
go

insert into commodity_uom values('HUDSON', 'PR', 'MT', 1)
go

insert into commodity_uom values('HUDSON', 'T', 'BBL', 1)
go

insert into commodity_uom values('HUDSON', 'T', 'MB', 1)
go

insert into commodity_uom values('HUDSON', 'T', 'MT', 1)
go

insert into commodity_uom values('IEP', 'I', 'UNIT', 1)
go

insert into commodity_uom values('IEP', 'T', 'UNIT', 1)
go

insert into commodity_uom values('IH/IL', 'L', '%', 1)
go

insert into commodity_uom values('IH/IL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('IH/IL', 'PR', 'MT', 1)
go

insert into commodity_uom values('IH/IL', 'T', 'BBL', 1)
go

insert into commodity_uom values('IH/IL', 'T', 'MB', 1)
go

insert into commodity_uom values('IH/IL', 'T', 'MT', 1)
go

insert into commodity_uom values('IHSIDI', 'L', '%', 1)
go

insert into commodity_uom values('IHSIDI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('IHSIDI', 'PR', 'MT', 1)
go

insert into commodity_uom values('IHSIDI', 'T', 'BBL', 1)
go

insert into commodity_uom values('IHSIDI', 'T', 'MB', 1)
go

insert into commodity_uom values('IHSIDI', 'T', 'MT', 1)
go

insert into commodity_uom values('IKANPARI', 'L', '%', 1)
go

insert into commodity_uom values('IKANPARI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('IKANPARI', 'PR', 'MT', 1)
go

insert into commodity_uom values('IKANPARI', 'T', 'BBL', 1)
go

insert into commodity_uom values('IKANPARI', 'T', 'MB', 1)
go

insert into commodity_uom values('IKANPARI', 'T', 'MT', 1)
go

insert into commodity_uom values('IRAN HVY', 'L', '%', 1)
go

insert into commodity_uom values('IRAN HVY', 'PR', 'BBL', 1)
go

insert into commodity_uom values('IRAN HVY', 'PR', 'MT', 1)
go

insert into commodity_uom values('IRAN HVY', 'T', 'BBL', 1)
go

insert into commodity_uom values('IRAN HVY', 'T', 'MB', 1)
go

insert into commodity_uom values('IRAN HVY', 'T', 'MT', 1)
go

insert into commodity_uom values('IRANLGHT', 'L', '%', 1)
go

insert into commodity_uom values('IRANLGHT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('IRANLGHT', 'PR', 'MT', 1)
go

insert into commodity_uom values('IRANLGHT', 'T', 'BBL', 1)
go

insert into commodity_uom values('IRANLGHT', 'T', 'MB', 1)
go

insert into commodity_uom values('IRANLGHT', 'T', 'MT', 1)
go

insert into commodity_uom values('ISTHMUS', 'L', '%', 1)
go

insert into commodity_uom values('ISTHMUS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ISTHMUS', 'PR', 'MT', 1)
go

insert into commodity_uom values('ISTHMUS', 'T', 'BBL', 1)
go

insert into commodity_uom values('ISTHMUS', 'T', 'MB', 1)
go

insert into commodity_uom values('ISTHMUS', 'T', 'MT', 1)
go

insert into commodity_uom values('ITL', 'I', 'UNIT', 1)
go

insert into commodity_uom values('ITL', 'T', 'UNIT', 1)
go

insert into commodity_uom values('JCOND', 'P', 'BBL', 1)
go

insert into commodity_uom values('JCOND', 'P', 'MB', 1)
go

insert into commodity_uom values('JCOND', 'PR', 'BBL', 1)
go

insert into commodity_uom values('JCOND', 'PR', 'MB', 1)
go

insert into commodity_uom values('JCOND', 'T', 'BBL', 1)
go

insert into commodity_uom values('JCOND', 'T', 'MB', 1)
go

insert into commodity_uom values('JABIRU', 'L', '%', 1)
go

insert into commodity_uom values('JABIRU', 'PR', 'BBL', 1)
go

insert into commodity_uom values('JABIRU', 'PR', 'MT', 1)
go

insert into commodity_uom values('JABIRU', 'T', 'BBL', 1)
go

insert into commodity_uom values('JABIRU', 'T', 'MB', 1)
go

insert into commodity_uom values('JABIRU', 'T', 'MT', 1)
go

insert into commodity_uom values('JET', 'L', '%', 1)
go

insert into commodity_uom values('JET', 'PR', 'BBL', 1)
go

insert into commodity_uom values('JET', 'PR', 'GAL', 1)
go

insert into commodity_uom values('JET', 'PR', 'MT', 1)
go

insert into commodity_uom values('JET', 'T', 'BBL', 1)
go

insert into commodity_uom values('JET', 'T', 'GAL', 1)
go

insert into commodity_uom values('JET', 'T', 'MB', 1)
go

insert into commodity_uom values('JET', 'T', 'MG', 1)
go

insert into commodity_uom values('JET', 'T', 'MT', 1)
go

insert into commodity_uom values('JETA1', 'L', '%', 1)
go

insert into commodity_uom values('JETA1', 'PR', 'BBL', 1)
go

insert into commodity_uom values('JETA1', 'PR', 'MT', 1)
go

insert into commodity_uom values('JETA1', 'T', 'BBL', 1)
go

insert into commodity_uom values('JETA1', 'T', 'GAL', 1)
go

insert into commodity_uom values('JETA1', 'T', 'MB', 1)
go

insert into commodity_uom values('JETA1', 'T', 'MT', 1)
go

insert into commodity_uom values('K-M', 'I', 'UNIT', 1)
go

insert into commodity_uom values('K-M', 'P', 'UNIT', 1)
go

insert into commodity_uom values('K-M', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('K-M', 'T', 'UNIT', 1)
go

insert into commodity_uom values('K3-VGO', 'I', 'BBL', 1)
go

insert into commodity_uom values('K3-VGO', 'I', 'MT', 1)
go

insert into commodity_uom values('K3-VGO', 'O', 'BBL', 1)
go

insert into commodity_uom values('K3-VGO', 'P', 'BBL', 1)
go

insert into commodity_uom values('K3-VGO', 'P', 'MT', 1)
go

insert into commodity_uom values('K3-VGO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('K3-VGO', 'PR', 'MT', 1)
go

insert into commodity_uom values('K3-VGO', 'S', 'BBL', 1)
go

insert into commodity_uom values('K3-VGO', 'S', 'MT', 1)
go

insert into commodity_uom values('K3-VGO', 'T', 'BBL', 1)
go

insert into commodity_uom values('K3-VGO', 'T', 'MT', 1)
go

insert into commodity_uom values('KERN', 'L', '%', 1)
go

insert into commodity_uom values('KERN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('KERN', 'PR', 'GAL', 1)
go

insert into commodity_uom values('KERN', 'PR', 'MT', 1)
go

insert into commodity_uom values('KERN', 'T', 'BBL', 1)
go

insert into commodity_uom values('KERN', 'T', 'MB', 1)
go

insert into commodity_uom values('KERN', 'T', 'MT', 1)
go

insert into commodity_uom values('KERO', 'L', '%', 1)
go

insert into commodity_uom values('KERO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('KERO', 'PR', 'GAL', 1)
go

insert into commodity_uom values('KERO', 'PR', 'MT', 1)
go

insert into commodity_uom values('KERO', 'T', 'BBL', 1)
go

insert into commodity_uom values('KERO', 'T', 'MB', 1)
go

insert into commodity_uom values('KERO', 'T', 'MT', 1)
go

insert into commodity_uom values('KIRKUK', 'L', '%', 1)
go

insert into commodity_uom values('KIRKUK', 'PR', 'BBL', 1)
go

insert into commodity_uom values('KIRKUK', 'PR', 'MT', 1)
go

insert into commodity_uom values('KIRKUK', 'T', 'BBL', 1)
go

insert into commodity_uom values('KIRKUK', 'T', 'MB', 1)
go

insert into commodity_uom values('KIRKUK', 'T', 'MT', 1)
go

insert into commodity_uom values('KM', 'O', 'UNIT', 1)
go

insert into commodity_uom values('KM', 'P', 'UNIT', 1)
go

insert into commodity_uom values('KM', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('KM', 'T', 'UNIT', 1)
go

insert into commodity_uom values('KOCHALB', 'L', '%', 1)
go

insert into commodity_uom values('KOCHALB', 'PR', 'BBL', 1)
go

insert into commodity_uom values('KOCHALB', 'PR', 'MT', 1)
go

insert into commodity_uom values('KOCHALB', 'T', 'BBL', 1)
go

insert into commodity_uom values('KOCHALB', 'T', 'MB', 1)
go

insert into commodity_uom values('KOCHALB', 'T', 'MT', 1)
go

insert into commodity_uom values('KOLE', 'L', '%', 1)
go

insert into commodity_uom values('KOLE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('KOLE', 'PR', 'MT', 1)
go

insert into commodity_uom values('KOLE', 'T', 'BBL', 1)
go

insert into commodity_uom values('KOLE', 'T', 'MB', 1)
go

insert into commodity_uom values('KOLE', 'T', 'MT', 1)
go

insert into commodity_uom values('KUWAIT', 'L', '%', 1)
go

insert into commodity_uom values('KUWAIT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('KUWAIT', 'PR', 'MT', 1)
go

insert into commodity_uom values('KUWAIT', 'T', 'BBL', 1)
go

insert into commodity_uom values('KUWAIT', 'T', 'MB', 1)
go

insert into commodity_uom values('KUWAIT', 'T', 'MT', 1)
go

insert into commodity_uom values('LABUAN', 'L', '%', 1)
go

insert into commodity_uom values('LABUAN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LABUAN', 'PR', 'MT', 1)
go

insert into commodity_uom values('LABUAN', 'T', 'BBL', 1)
go

insert into commodity_uom values('LABUAN', 'T', 'MB', 1)
go

insert into commodity_uom values('LABUAN', 'T', 'MT', 1)
go

insert into commodity_uom values('LAGMEDRE', 'L', '%', 1)
go

insert into commodity_uom values('LAGMEDRE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LAGMEDRE', 'PR', 'GAL', 1)
go

insert into commodity_uom values('LAGMEDRE', 'PR', 'MB', 1)
go

insert into commodity_uom values('LAGMEDRE', 'PR', 'MT', 1)
go

insert into commodity_uom values('LAGMEDRE', 'T', 'BBL', 1)
go

insert into commodity_uom values('LAGMEDRE', 'T', 'GAL', 1)
go

insert into commodity_uom values('LAGMEDRE', 'T', 'MB', 1)
go

insert into commodity_uom values('LAGMEDRE', 'T', 'MT', 1)
go

insert into commodity_uom values('LAGOMEDI', 'L', '%', 1)
go

insert into commodity_uom values('LAGOMEDI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LAGOMEDI', 'PR', 'MT', 1)
go

insert into commodity_uom values('LAGOMEDI', 'T', 'BBL', 1)
go

insert into commodity_uom values('LAGOMEDI', 'T', 'MB', 1)
go

insert into commodity_uom values('LAGOMEDI', 'T', 'MT', 1)
go

insert into commodity_uom values('LAGOTREC', 'L', '%', 1)
go

insert into commodity_uom values('LAGOTREC', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LAGOTREC', 'PR', 'MT', 1)
go

insert into commodity_uom values('LAGOTREC', 'T', 'BBL', 1)
go

insert into commodity_uom values('LAGOTREC', 'T', 'MB', 1)
go

insert into commodity_uom values('LAGOTREC', 'T', 'MT', 1)
go

insert into commodity_uom values('LAGUNA', 'I', 'BBL', 1)
go

insert into commodity_uom values('LAGUNA', 'I', 'MB', 1)
go

insert into commodity_uom values('LAGUNA', 'P', 'BBL', 1)
go

insert into commodity_uom values('LAGUNA', 'P', 'MB', 1)
go

insert into commodity_uom values('LAGUNA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LAGUNA', 'T', 'BBL', 1)
go

insert into commodity_uom values('LAGUNA', 'T', 'MB', 1)
go

insert into commodity_uom values('LALANG', 'L', '%', 1)
go

insert into commodity_uom values('LALANG', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LALANG', 'PR', 'MT', 1)
go

insert into commodity_uom values('LALANG', 'T', 'BBL', 1)
go

insert into commodity_uom values('LALANG', 'T', 'MB', 1)
go

insert into commodity_uom values('LALANG', 'T', 'MT', 1)
go

insert into commodity_uom values('LCGASOIL', 'L', '%', 1)
go

insert into commodity_uom values('LCGASOIL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LCGASOIL', 'PR', 'GAL', 1)
go

insert into commodity_uom values('LCGASOIL', 'PR', 'MT', 1)
go

insert into commodity_uom values('LCGASOIL', 'T', 'BBL', 1)
go

insert into commodity_uom values('LCGASOIL', 'T', 'GAL', 1)
go

insert into commodity_uom values('LCGASOIL', 'T', 'MB', 1)
go

insert into commodity_uom values('LCGASOIL', 'T', 'MT', 1)
go

insert into commodity_uom values('LEADED', 'I', 'MT', 1)
go

insert into commodity_uom values('LEADED', 'L', '%', 1)
go

insert into commodity_uom values('LEADED', 'P', 'MT', 1)
go

insert into commodity_uom values('LEADED', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LEADED', 'PR', 'GAL', 1)
go

insert into commodity_uom values('LEADED', 'PR', 'MB', 1)
go

insert into commodity_uom values('LEADED', 'PR', 'MT', 1)
go

insert into commodity_uom values('LEADED', 'S', 'MT', 1)
go

insert into commodity_uom values('LEADED', 'T', 'BBL', 1)
go

insert into commodity_uom values('LEADED', 'T', 'GAL', 1)
go

insert into commodity_uom values('LEADED', 'T', 'MB', 1)
go

insert into commodity_uom values('LEADED', 'T', 'MT', 1)
go

insert into commodity_uom values('LEADMID', 'L', '%', 1)
go

insert into commodity_uom values('LEADMID', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LEADMID', 'PR', 'GAL', 1)
go

insert into commodity_uom values('LEADMID', 'PR', 'MB', 1)
go

insert into commodity_uom values('LEADMID', 'T', 'BBL', 1)
go

insert into commodity_uom values('LEADMID', 'T', 'GAL', 1)
go

insert into commodity_uom values('LEADMID', 'T', 'MB', 1)
go

insert into commodity_uom values('LEADMID', 'T', 'MT', 1)
go

insert into commodity_uom values('LEADREG', 'L', '%', 1)
go

insert into commodity_uom values('LEADREG', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LEADREG', 'PR', 'GAL', 1)
go

insert into commodity_uom values('LEADREG', 'PR', 'MB', 1)
go

insert into commodity_uom values('LEADREG', 'T', 'BBL', 1)
go

insert into commodity_uom values('LEADREG', 'T', 'GAL', 1)
go

insert into commodity_uom values('LEADREG', 'T', 'MB', 1)
go

insert into commodity_uom values('LEADREG', 'T', 'MT', 1)
go

insert into commodity_uom values('LEONA', 'L', '%', 1)
go

insert into commodity_uom values('LEONA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LEONA', 'PR', 'MT', 1)
go

insert into commodity_uom values('LEONA', 'T', 'BBL', 1)
go

insert into commodity_uom values('LEONA', 'T', 'MB', 1)
go

insert into commodity_uom values('LEONA', 'T', 'MT', 1)
go

insert into commodity_uom values('LINE63', 'L', '%', 1)
go

insert into commodity_uom values('LINE63', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LINE63', 'PR', 'MT', 1)
go

insert into commodity_uom values('LINE63', 'T', 'BBL', 1)
go

insert into commodity_uom values('LINE63', 'T', 'MB', 1)
go

insert into commodity_uom values('LINE63', 'T', 'MT', 1)
go

insert into commodity_uom values('LIVBAYBL', 'L', '%', 1)
go

insert into commodity_uom values('LIVBAYBL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LIVBAYBL', 'PR', 'MT', 1)
go

insert into commodity_uom values('LIVBAYBL', 'T', 'BBL', 1)
go

insert into commodity_uom values('LIVBAYBL', 'T', 'MB', 1)
go

insert into commodity_uom values('LIVBAYBL', 'T', 'MT', 1)
go

insert into commodity_uom values('LLS', 'L', '%', 1)
go

insert into commodity_uom values('LLS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LLS', 'PR', 'MT', 1)
go

insert into commodity_uom values('LLS', 'T', 'BBL', 1)
go

insert into commodity_uom values('LLS', 'T', 'MB', 1)
go

insert into commodity_uom values('LLS', 'T', 'MT', 1)
go

insert into commodity_uom values('LOKELE', 'L', '%', 1)
go

insert into commodity_uom values('LOKELE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LOKELE', 'PR', 'MT', 1)
go

insert into commodity_uom values('LOKELE', 'T', 'BBL', 1)
go

insert into commodity_uom values('LOKELE', 'T', 'MB', 1)
go

insert into commodity_uom values('LOKELE', 'T', 'MT', 1)
go

insert into commodity_uom values('LORETTO', 'L', '%', 1)
go

insert into commodity_uom values('LORETTO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LORETTO', 'PR', 'MT', 1)
go

insert into commodity_uom values('LORETTO', 'T', 'BBL', 1)
go

insert into commodity_uom values('LORETTO', 'T', 'MB', 1)
go

insert into commodity_uom values('LORETTO', 'T', 'MT', 1)
go

insert into commodity_uom values('LSNO2', 'I', 'GAL', 1)
go

insert into commodity_uom values('LSNO2', 'L', '%', 1)
go

insert into commodity_uom values('LSNO2', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LSNO2', 'PR', 'GAL', 1)
go

insert into commodity_uom values('LSNO2', 'PR', 'MT', 1)
go

insert into commodity_uom values('LSNO2', 'T', 'BBL', 1)
go

insert into commodity_uom values('LSNO2', 'T', 'GAL', 1)
go

insert into commodity_uom values('LSNO2', 'T', 'MB', 1)
go

insert into commodity_uom values('LSHEAT', 'L', '%', 1)
go

insert into commodity_uom values('LSHEAT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LSHEAT', 'PR', 'GAL', 1)
go

insert into commodity_uom values('LSHEAT', 'PR', 'MT', 1)
go

insert into commodity_uom values('LSHEAT', 'T', 'BBL', 1)
go

insert into commodity_uom values('LSHEAT', 'T', 'MB', 1)
go

insert into commodity_uom values('LSHEAT', 'T', 'MT', 1)
go

insert into commodity_uom values('LSWR', 'L', '%', 1)
go

insert into commodity_uom values('LSWR', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LSWR', 'PR', 'GAL', 1)
go

insert into commodity_uom values('LSWR', 'PR', 'MT', 1)
go

insert into commodity_uom values('LSWR', 'T', 'BBL', 1)
go

insert into commodity_uom values('LSWR', 'T', 'GAL', 1)
go

insert into commodity_uom values('LSWR', 'T', 'MB', 1)
go

insert into commodity_uom values('LSWR', 'T', 'MT', 1)
go

insert into commodity_uom values('LUCINA', 'L', '%', 1)
go

insert into commodity_uom values('LUCINA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('LUCINA', 'PR', 'MT', 1)
go

insert into commodity_uom values('LUCINA', 'T', 'BBL', 1)
go

insert into commodity_uom values('LUCINA', 'T', 'MB', 1)
go

insert into commodity_uom values('LUCINA', 'T', 'MT', 1)
go

insert into commodity_uom values('M100', 'L', '%', 1)
go

insert into commodity_uom values('M100', 'PR', 'BBL', 1)
go

insert into commodity_uom values('M100', 'PR', 'MT', 1)
go

insert into commodity_uom values('M100', 'T', 'BBL', 1)
go

insert into commodity_uom values('M100', 'T', 'MB', 1)
go

insert into commodity_uom values('M100', 'T', 'MT', 1)
go

insert into commodity_uom values('MANDJI', 'L', '%', 1)
go

insert into commodity_uom values('MANDJI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MANDJI', 'PR', 'MT', 1)
go

insert into commodity_uom values('MANDJI', 'T', 'BBL', 1)
go

insert into commodity_uom values('MANDJI', 'T', 'MB', 1)
go

insert into commodity_uom values('MANDJI', 'T', 'MT', 1)
go

insert into commodity_uom values('MARIBLT', 'L', '%', 1)
go

insert into commodity_uom values('MARIBLT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MARIBLT', 'PR', 'MT', 1)
go

insert into commodity_uom values('MARIBLT', 'T', 'BBL', 1)
go

insert into commodity_uom values('MARIBLT', 'T', 'MB', 1)
go

insert into commodity_uom values('MARIBLT', 'T', 'MT', 1)
go

insert into commodity_uom values('MASILA', 'L', '%', 1)
go

insert into commodity_uom values('MASILA', 'P', 'BBL', 1)
go

insert into commodity_uom values('MASILA', 'P', 'MB', 1)
go

insert into commodity_uom values('MASILA', 'P', 'MT', 1)
go

insert into commodity_uom values('MASILA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MASILA', 'PR', 'MB', 1)
go

insert into commodity_uom values('MASILA', 'PR', 'MT', 1)
go

insert into commodity_uom values('MASILA', 'S', 'BBL', 1)
go

insert into commodity_uom values('MASILA', 'S', 'MB', 1)
go

insert into commodity_uom values('MASILA', 'S', 'MT', 1)
go

insert into commodity_uom values('MASILA', 'T', 'BBL', 1)
go

insert into commodity_uom values('MASILA', 'T', 'MB', 1)
go

insert into commodity_uom values('MASILA', 'T', 'MT', 1)
go

insert into commodity_uom values('MAUREEN', 'L', '%', 1)
go

insert into commodity_uom values('MAUREEN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MAUREEN', 'PR', 'MT', 1)
go

insert into commodity_uom values('MAUREEN', 'T', 'BBL', 1)
go

insert into commodity_uom values('MAUREEN', 'T', 'MB', 1)
go

insert into commodity_uom values('MAUREEN', 'T', 'MT', 1)
go

insert into commodity_uom values('MAYA', 'L', '%', 1)
go

insert into commodity_uom values('MAYA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MAYA', 'PR', 'MT', 1)
go

insert into commodity_uom values('MAYA', 'T', 'BBL', 1)
go

insert into commodity_uom values('MAYA', 'T', 'MB', 1)
go

insert into commodity_uom values('MAYA', 'T', 'MT', 1)
go

insert into commodity_uom values('MAYAISTH', 'L', '%', 1)
go

insert into commodity_uom values('MAYAISTH', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MAYAISTH', 'PR', 'GAL', 1)
go

insert into commodity_uom values('MAYAISTH', 'PR', 'MB', 1)
go

insert into commodity_uom values('MAYAISTH', 'PR', 'MT', 1)
go

insert into commodity_uom values('MAYAISTH', 'T', 'BBL', 1)
go

insert into commodity_uom values('MAYAISTH', 'T', 'GAL', 1)
go

insert into commodity_uom values('MAYAISTH', 'T', 'MB', 1)
go

insert into commodity_uom values('MAYAISTH', 'T', 'MT', 1)
go

insert into commodity_uom values('MBYA', 'L', '%', 1)
go

insert into commodity_uom values('MBYA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MBYA', 'PR', 'MT', 1)
go

insert into commodity_uom values('MBYA', 'T', 'BBL', 1)
go

insert into commodity_uom values('MBYA', 'T', 'MB', 1)
go

insert into commodity_uom values('MBYA', 'T', 'MT', 1)
go

insert into commodity_uom values('MC250', 'I', 'BBL', 1)
go

insert into commodity_uom values('MC250', 'I', 'MT', 1)
go

insert into commodity_uom values('MC250', 'L', '%', 1)
go

insert into commodity_uom values('MC250', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MC250', 'PR', 'MT', 1)
go

insert into commodity_uom values('MC250', 'T', 'BBL', 1)
go

insert into commodity_uom values('MC250', 'T', 'MT', 1)
go

insert into commodity_uom values('MEDANIT', 'L', '%', 1)
go

insert into commodity_uom values('MEDANIT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MEDANIT', 'PR', 'MT', 1)
go

insert into commodity_uom values('MEDANIT', 'T', 'BBL', 1)
go

insert into commodity_uom values('MEDANIT', 'T', 'MB', 1)
go

insert into commodity_uom values('MEDANIT', 'T', 'MT', 1)
go

insert into commodity_uom values('MENEMOTA', 'L', '%', 1)
go

insert into commodity_uom values('MENEMOTA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MENEMOTA', 'PR', 'MT', 1)
go

insert into commodity_uom values('MENEMOTA', 'T', 'BBL', 1)
go

insert into commodity_uom values('MENEMOTA', 'T', 'MB', 1)
go

insert into commodity_uom values('MENEMOTA', 'T', 'MT', 1)
go

insert into commodity_uom values('MEREY', 'L', '%', 1)
go

insert into commodity_uom values('MEREY', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MEREY', 'PR', 'MT', 1)
go

insert into commodity_uom values('MEREY', 'T', 'BBL', 1)
go

insert into commodity_uom values('MEREY', 'T', 'MB', 1)
go

insert into commodity_uom values('MEREY', 'T', 'MT', 1)
go

insert into commodity_uom values('MESA', 'L', '%', 1)
go

insert into commodity_uom values('MESA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MESA', 'PR', 'MT', 1)
go

insert into commodity_uom values('MESA', 'T', 'BBL', 1)
go

insert into commodity_uom values('MESA', 'T', 'MB', 1)
go

insert into commodity_uom values('MESA', 'T', 'MT', 1)
go

insert into commodity_uom values('MINAS', 'L', '%', 1)
go

insert into commodity_uom values('MINAS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MINAS', 'PR', 'MT', 1)
go

insert into commodity_uom values('MINAS', 'T', 'BBL', 1)
go

insert into commodity_uom values('MINAS', 'T', 'MB', 1)
go

insert into commodity_uom values('MINAS', 'T', 'MT', 1)
go

insert into commodity_uom values('MIRI', 'L', '%', 1)
go

insert into commodity_uom values('MIRI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MIRI', 'PR', 'MT', 1)
go

insert into commodity_uom values('MIRI', 'T', 'BBL', 1)
go

insert into commodity_uom values('MIRI', 'T', 'MB', 1)
go

insert into commodity_uom values('MIRI', 'T', 'MT', 1)
go

insert into commodity_uom values('MOGAS15', 'L', '%', 1)
go

insert into commodity_uom values('MOGAS15', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MOGAS15', 'PR', 'GAL', 1)
go

insert into commodity_uom values('MOGAS15', 'PR', 'MT', 1)
go

insert into commodity_uom values('MOGAS15', 'T', 'BBL', 1)
go

insert into commodity_uom values('MOGAS15', 'T', 'GAL', 1)
go

insert into commodity_uom values('MOGAS15', 'T', 'MB', 1)
go

insert into commodity_uom values('MOGAS15', 'T', 'MT', 1)
go

insert into commodity_uom values('MOGASUNL', 'L', '%', 1)
go

insert into commodity_uom values('MOGASUNL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MOGASUNL', 'PR', 'GAL', 1)
go

insert into commodity_uom values('MOGASUNL', 'PR', 'MT', 1)
go

insert into commodity_uom values('MOGASUNL', 'T', 'BBL', 1)
go

insert into commodity_uom values('MOGASUNL', 'T', 'GAL', 1)
go

insert into commodity_uom values('MOGASUNL', 'T', 'MB', 1)
go

insert into commodity_uom values('MOGASUNL', 'T', 'MT', 1)
go

insert into commodity_uom values('MOLONGO', 'L', '%', 1)
go

insert into commodity_uom values('MOLONGO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MOLONGO', 'PR', 'MT', 1)
go

insert into commodity_uom values('MOLONGO', 'T', 'BBL', 1)
go

insert into commodity_uom values('MOLONGO', 'T', 'MB', 1)
go

insert into commodity_uom values('MOLONGO', 'T', 'MT', 1)
go

insert into commodity_uom values('MPC', 'I', 'BBL', 1)
go

insert into commodity_uom values('MPC', 'I', 'MB', 1)
go

insert into commodity_uom values('MPC', 'P', 'BBL', 1)
go

insert into commodity_uom values('MPC', 'P', 'MB', 1)
go

insert into commodity_uom values('MPC', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MPC', 'PR', 'MB', 1)
go

insert into commodity_uom values('MPC', 'T', 'BBL', 1)
go

insert into commodity_uom values('MPC', 'T', 'MB', 1)
go

insert into commodity_uom values('MSFO18', 'P', 'BBL', 1)
go

insert into commodity_uom values('MSFO18', 'P', 'MT', 1)
go

insert into commodity_uom values('MSFO18', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MSFO18', 'PR', 'MT', 1)
go

insert into commodity_uom values('MSFO18', 'T', 'BBL', 1)
go

insert into commodity_uom values('MSFO18', 'T', 'MT', 1)
go

insert into commodity_uom values('MTBE', 'L', '%', 1)
go

insert into commodity_uom values('MTBE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MTBE', 'PR', 'GAL', 1)
go

insert into commodity_uom values('MTBE', 'PR', 'MT', 1)
go

insert into commodity_uom values('MTBE', 'T', 'BBL', 1)
go

insert into commodity_uom values('MTBE', 'T', 'GAL', 1)
go

insert into commodity_uom values('MTBE', 'T', 'MB', 1)
go

insert into commodity_uom values('MTBE', 'T', 'MT', 1)
go

insert into commodity_uom values('MUBAREK', 'L', '%', 1)
go

insert into commodity_uom values('MUBAREK', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MUBAREK', 'PR', 'MT', 1)
go

insert into commodity_uom values('MUBAREK', 'T', 'BBL', 1)
go

insert into commodity_uom values('MUBAREK', 'T', 'MB', 1)
go

insert into commodity_uom values('MUBAREK', 'T', 'MT', 1)
go

insert into commodity_uom values('MURBAN', 'L', '%', 1)
go

insert into commodity_uom values('MURBAN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('MURBAN', 'PR', 'MT', 1)
go

insert into commodity_uom values('MURBAN', 'T', 'BBL', 1)
go

insert into commodity_uom values('MURBAN', 'T', 'MB', 1)
go

insert into commodity_uom values('MURBAN', 'T', 'MT', 1)
go

insert into commodity_uom values('N-BUTANE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('N-BUTANE', 'PR', 'GAL', 1)
go

insert into commodity_uom values('N-BUTANE', 'PR', 'MT', 1)
go

insert into commodity_uom values('N-BUTANE', 'T', 'BBL', 1)
go

insert into commodity_uom values('N-BUTANE', 'T', 'GAL', 1)
go

insert into commodity_uom values('N-BUTANE', 'T', 'LOTS', 1)
go

insert into commodity_uom values('N-BUTANE', 'T', 'MB', 1)
go

insert into commodity_uom values('N-BUTANE', 'T', 'MG', 1)
go

insert into commodity_uom values('N-BUTANE', 'T', 'MT', 1)
go

insert into commodity_uom values('NANHAILT', 'L', '%', 1)
go

insert into commodity_uom values('NANHAILT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NANHAILT', 'PR', 'MT', 1)
go

insert into commodity_uom values('NANHAILT', 'T', 'BBL', 1)
go

insert into commodity_uom values('NANHAILT', 'T', 'MB', 1)
go

insert into commodity_uom values('NANHAILT', 'T', 'MT', 1)
go

insert into commodity_uom values('NAPHTHA', 'L', '%', 1)
go

insert into commodity_uom values('NAPHTHA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NAPHTHA', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NAPHTHA', 'PR', 'MT', 1)
go

insert into commodity_uom values('NAPHTHA', 'T', 'BBL', 1)
go

insert into commodity_uom values('NAPHTHA', 'T', 'GAL', 1)
go

insert into commodity_uom values('NAPHTHA', 'T', 'MB', 1)
go

insert into commodity_uom values('NAPHTHA', 'T', 'MT', 1)
go

insert into commodity_uom values('NATGAS', 'P', 'MMBT', 1)
go

insert into commodity_uom values('NATGAS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NATGAS', 'PR', 'MMBT', 1)
go

insert into commodity_uom values('NATGAS', 'PR', 'THER', 1)
go

insert into commodity_uom values('NATGAS', 'T', 'BBL', 1)
go

insert into commodity_uom values('NATGAS', 'T', 'MMBT', 1)
go

insert into commodity_uom values('NATGAS', 'T', 'THER', 1)
go

insert into commodity_uom values('NEMBA', 'P', 'BBL', 1)
go

insert into commodity_uom values('NEMBA', 'P', 'MB', 1)
go

insert into commodity_uom values('NEMBA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NEMBA', 'PR', 'MB', 1)
go

insert into commodity_uom values('NEMBA', 'S', 'BBL', 1)
go

insert into commodity_uom values('NEMBA', 'S', 'MB', 1)
go

insert into commodity_uom values('NEMBA', 'T', 'BBL', 1)
go

insert into commodity_uom values('NEMBA', 'T', 'MB', 1)
go

insert into commodity_uom values('NEUTRALZ', 'L', '%', 1)
go

insert into commodity_uom values('NEUTRALZ', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NEUTRALZ', 'PR', 'MB', 1)
go

insert into commodity_uom values('NEUTRALZ', 'PR', 'MT', 1)
go

insert into commodity_uom values('NEUTRALZ', 'T', 'BBL', 1)
go

insert into commodity_uom values('NEUTRALZ', 'T', 'MB', 1)
go

insert into commodity_uom values('NEUTRALZ', 'T', 'MT', 1)
go

insert into commodity_uom values('NIGERIAN', 'L', '%', 1)
go

insert into commodity_uom values('NIGERIAN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NIGERIAN', 'PR', 'MT', 1)
go

insert into commodity_uom values('NIGERIAN', 'T', 'BBL', 1)
go

insert into commodity_uom values('NIGERIAN', 'T', 'MB', 1)
go

insert into commodity_uom values('NIGERIAN', 'T', 'MT', 1)
go

insert into commodity_uom values('NINIAN', 'L', '%', 1)
go

insert into commodity_uom values('NINIAN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NINIAN', 'PR', 'MT', 1)
go

insert into commodity_uom values('NINIAN', 'T', 'BBL', 1)
go

insert into commodity_uom values('NINIAN', 'T', 'MB', 1)
go

insert into commodity_uom values('NINIAN', 'T', 'MT', 1)
go

insert into commodity_uom values('NLG', 'I', 'UNIT', 1)
go

insert into commodity_uom values('NLG', 'O', 'UNIT', 1)
go

insert into commodity_uom values('NLG', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('NLG', 'T', 'UNIT', 1)
go

insert into commodity_uom values('NO2', 'L', '%', 1)
go

insert into commodity_uom values('NO2', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO2', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO2', 'S', 'BBL', 1)
go

insert into commodity_uom values('NO2', 'S', 'GAL', 1)
go

insert into commodity_uom values('NO2', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO2', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-03HI', 'L', '%', 1)
go

insert into commodity_uom values('NO6-03HI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6-03HI', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6-03HI', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-03HI', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-03HI', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-03HI', 'T', 'M3', 1)
go

insert into commodity_uom values('NO6-03HI', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-03HI', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6-03LO', 'L', '%', 1)
go

insert into commodity_uom values('NO6-03LO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6-03LO', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6-03LO', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-03LO', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-03LO', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-03LO', 'T', 'M3', 1)
go

insert into commodity_uom values('NO6-03LO', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-03LO', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6-03MX', 'L', '%', 1)
go

insert into commodity_uom values('NO6-03MX', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-03MX', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-03MX', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-03MX', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-03MX', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6-05', 'L', '%', 1)
go

insert into commodity_uom values('NO6-05', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6-05', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6-05', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-05', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-05', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-05', 'T', 'M3', 1)
go

insert into commodity_uom values('NO6-05', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-05', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6-07', 'L', '%', 1)
go

insert into commodity_uom values('NO6-07', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6-07', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6-07', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-07', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-07', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-07', 'T', 'M3', 1)
go

insert into commodity_uom values('NO6-07', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-07', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6-10', 'L', '%', 1)
go

insert into commodity_uom values('NO6-10', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6-10', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6-10', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-10', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-10', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-10', 'T', 'M3', 1)
go

insert into commodity_uom values('NO6-10', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-10', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6-16', 'L', '%', 1)
go

insert into commodity_uom values('NO6-16', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6-16', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6-16', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-16', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-16', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-16', 'T', 'M3', 1)
go

insert into commodity_uom values('NO6-16', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-16', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6-20', 'L', '%', 1)
go

insert into commodity_uom values('NO6-20', 'P', 'MMBT', 1)
go

insert into commodity_uom values('NO6-20', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6-20', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6-20', 'PR', 'MMBT', 1)
go

insert into commodity_uom values('NO6-20', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-20', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-20', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-20', 'T', 'M3', 1)
go

insert into commodity_uom values('NO6-20', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-20', 'T', 'MMBT', 1)
go

insert into commodity_uom values('NO6-20', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6-22', 'L', '%', 1)
go

insert into commodity_uom values('NO6-22', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6-22', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6-22', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-22', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-22', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-22', 'T', 'M3', 1)
go

insert into commodity_uom values('NO6-22', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-22', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6-28', 'L', '%', 1)
go

insert into commodity_uom values('NO6-28', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6-28', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6-28', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-28', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-28', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-28', 'T', 'M3', 1)
go

insert into commodity_uom values('NO6-28', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-28', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6-29', 'L', '%', 1)
go

insert into commodity_uom values('NO6-29', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6-29', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6-29', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-29', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-29', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-29', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-29', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6-30', 'L', '%', 1)
go

insert into commodity_uom values('NO6-30', 'P', 'MMBT', 1)
go

insert into commodity_uom values('NO6-30', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6-30', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6-30', 'PR', 'MMBT', 1)
go

insert into commodity_uom values('NO6-30', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-30', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-30', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-30', 'T', 'M3', 1)
go

insert into commodity_uom values('NO6-30', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-30', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6-35', 'L', '%', 1)
go

insert into commodity_uom values('NO6-35', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6-35', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6-35', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6-35', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6-35', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6-35', 'T', 'M3', 1)
go

insert into commodity_uom values('NO6-35', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6-35', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6HSCR', 'L', '%', 1)
go

insert into commodity_uom values('NO6HSCR', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6HSCR', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6HSCR', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6HSCR', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6HSCR', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6HSCR', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6HSSR', 'L', '%', 1)
go

insert into commodity_uom values('NO6HSSR', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6HSSR', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6HSSR', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6HSSR', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6HSSR', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6HSSR', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6LSCR', 'L', '%', 1)
go

insert into commodity_uom values('NO6LSCR', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6LSCR', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6LSCR', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6LSCR', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6LSCR', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6LSCR', 'T', 'MT', 1)
go

insert into commodity_uom values('NO6LSSR', 'L', '%', 1)
go

insert into commodity_uom values('NO6LSSR', 'P', 'BBL', 1)
go

insert into commodity_uom values('NO6LSSR', 'P', 'GAL', 1)
go

insert into commodity_uom values('NO6LSSR', 'P', 'MT', 1)
go

insert into commodity_uom values('NO6LSSR', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NO6LSSR', 'PR', 'GAL', 1)
go

insert into commodity_uom values('NO6LSSR', 'PR', 'MT', 1)
go

insert into commodity_uom values('NO6LSSR', 'T', 'BBL', 1)
go

insert into commodity_uom values('NO6LSSR', 'T', 'GAL', 1)
go

insert into commodity_uom values('NO6LSSR', 'T', 'M3', 1)
go

insert into commodity_uom values('NO6LSSR', 'T', 'MB', 1)
go

insert into commodity_uom values('NO6LSSR', 'T', 'MT', 1)
go

insert into commodity_uom values('NORNE', 'L', '%', 1)
go

insert into commodity_uom values('NORNE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NORNE', 'PR', 'MT', 1)
go

insert into commodity_uom values('NORNE', 'T', 'BBL', 1)
go

insert into commodity_uom values('NORNE', 'T', 'MB', 1)
go

insert into commodity_uom values('NORNE', 'T', 'MT', 1)
go

insert into commodity_uom values('NTS', 'L', '%', 1)
go

insert into commodity_uom values('NTS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NTS', 'PR', 'MT', 1)
go

insert into commodity_uom values('NTS', 'T', 'BBL', 1)
go

insert into commodity_uom values('NTS', 'T', 'MB', 1)
go

insert into commodity_uom values('NTS', 'T', 'MT', 1)
go

insert into commodity_uom values('NWSHELFC', 'L', '%', 1)
go

insert into commodity_uom values('NWSHELFC', 'PR', 'BBL', 1)
go

insert into commodity_uom values('NWSHELFC', 'PR', 'MTU', 1)
go

insert into commodity_uom values('NWSHELFC', 'T', 'BBL', 1)
go

insert into commodity_uom values('NWSHELFC', 'T', 'MB', 1)
go

insert into commodity_uom values('NWSHELFC', 'T', 'MT', 1)
go

insert into commodity_uom values('ODUDU', 'L', '%', 1)
go

insert into commodity_uom values('ODUDU', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ODUDU', 'PR', 'MT', 1)
go

insert into commodity_uom values('ODUDU', 'T', 'BBL', 1)
go

insert into commodity_uom values('ODUDU', 'T', 'MB', 1)
go

insert into commodity_uom values('ODUDU', 'T', 'MT', 1)
go

insert into commodity_uom values('OGUENDJO', 'L', '%', 1)
go

insert into commodity_uom values('OGUENDJO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('OGUENDJO', 'PR', 'MT', 1)
go

insert into commodity_uom values('OGUENDJO', 'T', 'BBL', 1)
go

insert into commodity_uom values('OGUENDJO', 'T', 'MB', 1)
go

insert into commodity_uom values('OGUENDJO', 'T', 'MT', 1)
go

insert into commodity_uom values('OKSWT', 'L', '%', 1)
go

insert into commodity_uom values('OKSWT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('OKSWT', 'PR', 'MT', 1)
go

insert into commodity_uom values('OKSWT', 'T', 'BBL', 1)
go

insert into commodity_uom values('OKSWT', 'T', 'MB', 1)
go

insert into commodity_uom values('OKSWT', 'T', 'MT', 1)
go

insert into commodity_uom values('OLMECA', 'L', '%', 1)
go

insert into commodity_uom values('OLMECA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('OLMECA', 'PR', 'MT', 1)
go

insert into commodity_uom values('OLMECA', 'T', 'BBL', 1)
go

insert into commodity_uom values('OLMECA', 'T', 'MB', 1)
go

insert into commodity_uom values('OLMECA', 'T', 'MT', 1)
go

insert into commodity_uom values('OMAN', 'L', '%', 1)
go

insert into commodity_uom values('OMAN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('OMAN', 'PR', 'MT', 1)
go

insert into commodity_uom values('OMAN', 'T', 'BBL', 1)
go

insert into commodity_uom values('OMAN', 'T', 'MB', 1)
go

insert into commodity_uom values('OMAN', 'T', 'MT', 1)
go

insert into commodity_uom values('OMANMPM', 'L', '%', 1)
go

insert into commodity_uom values('OMANMPM', 'PR', 'BBL', 1)
go

insert into commodity_uom values('OMANMPM', 'T', 'BBL', 1)
go

insert into commodity_uom values('OMANMPM', 'T', 'MB', 1)
go

insert into commodity_uom values('ORIENTE', 'L', '%', 1)
go

insert into commodity_uom values('ORIENTE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ORIENTE', 'PR', 'MT', 1)
go

insert into commodity_uom values('ORIENTE', 'T', 'BBL', 1)
go

insert into commodity_uom values('ORIENTE', 'T', 'MB', 1)
go

insert into commodity_uom values('ORIENTE', 'T', 'MT', 1)
go

insert into commodity_uom values('ORITO', 'L', '%', 1)
go

insert into commodity_uom values('ORITO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ORITO', 'PR', 'MT', 1)
go

insert into commodity_uom values('ORITO', 'T', 'BBL', 1)
go

insert into commodity_uom values('ORITO', 'T', 'MB', 1)
go

insert into commodity_uom values('ORITO', 'T', 'MT', 1)
go

insert into commodity_uom values('OSEBERG', 'L', '%', 1)
go

insert into commodity_uom values('OSEBERG', 'PR', 'BBL', 1)
go

insert into commodity_uom values('OSEBERG', 'PR', 'MT', 1)
go

insert into commodity_uom values('OSEBERG', 'T', 'BBL', 1)
go

insert into commodity_uom values('OSEBERG', 'T', 'MB', 1)
go

insert into commodity_uom values('OSEBERG', 'T', 'MT', 1)
go

insert into commodity_uom values('OSO', 'L', '%', 1)
go

insert into commodity_uom values('OSO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('OSO', 'PR', 'MT', 1)
go

insert into commodity_uom values('OSO', 'T', 'BBL', 1)
go

insert into commodity_uom values('OSO', 'T', 'MB', 1)
go

insert into commodity_uom values('OSO', 'T', 'MT', 1)
go

insert into commodity_uom values('PALANCA', 'L', '%', 1)
go

insert into commodity_uom values('PALANCA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('PALANCA', 'PR', 'MT', 1)
go

insert into commodity_uom values('PALANCA', 'T', 'BBL', 1)
go

insert into commodity_uom values('PALANCA', 'T', 'MB', 1)
go

insert into commodity_uom values('PALANCA', 'T', 'MT', 1)
go

insert into commodity_uom values('PEN60/70', 'I', 'BBL', 1)
go

insert into commodity_uom values('PEN60/70', 'I', 'MT', 1)
go

insert into commodity_uom values('PEN60/70', 'L', '%', 1)
go

insert into commodity_uom values('PEN60/70', 'PR', 'BBL', 1)
go

insert into commodity_uom values('PEN60/70', 'PR', 'MT', 1)
go

insert into commodity_uom values('PEN60/70', 'S', 'BBL', 1)
go

insert into commodity_uom values('PEN60/70', 'T', 'BBL', 1)
go

insert into commodity_uom values('PEN60/70', 'T', 'MT', 1)
go

insert into commodity_uom values('PENN', 'I', 'BBL', 1)
go

insert into commodity_uom values('PENN', 'L', '%', 1)
go

insert into commodity_uom values('PENN', 'P', 'BBL', 1)
go

insert into commodity_uom values('PENN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('PENN', 'PR', 'MT', 1)
go

insert into commodity_uom values('PENN', 'T', 'BBL', 1)
go

insert into commodity_uom values('PENN', 'T', 'MB', 1)
go

insert into commodity_uom values('PENN', 'T', 'MT', 1)
go

insert into commodity_uom values('PILON', 'L', '%', 1)
go

insert into commodity_uom values('PILON', 'PR', 'BBL', 1)
go

insert into commodity_uom values('PILON', 'PR', 'MT', 1)
go

insert into commodity_uom values('PILON', 'T', 'BBL', 1)
go

insert into commodity_uom values('PILON', 'T', 'MB', 1)
go

insert into commodity_uom values('PILON', 'T', 'MT', 1)
go

insert into commodity_uom values('PN85/100', 'I', 'BBL', 1)
go

insert into commodity_uom values('PN85/100', 'I', 'MT', 1)
go

insert into commodity_uom values('PN85/100', 'L', '%', 1)
go

insert into commodity_uom values('PN85/100', 'PR', 'BBL', 1)
go

insert into commodity_uom values('PN85/100', 'PR', 'MT', 1)
go

insert into commodity_uom values('PN85/100', 'T', 'BBL', 1)
go

insert into commodity_uom values('PN85/100', 'T', 'MT', 1)
go

insert into commodity_uom values('PR/LEAD', 'L', '%', 1)
go

insert into commodity_uom values('PR/ULEAD', 'L', '%', 1)
go

insert into commodity_uom values('PREM15', 'L', '%', 1)
go

insert into commodity_uom values('PREM15', 'PR', 'BBL', 1)
go

insert into commodity_uom values('PREM15', 'PR', 'GAL', 1)
go

insert into commodity_uom values('PREM15', 'PR', 'MT', 1)
go

insert into commodity_uom values('PREM15', 'T', 'BBL', 1)
go

insert into commodity_uom values('PREM15', 'T', 'GAL', 1)
go

insert into commodity_uom values('PREM15', 'T', 'MB', 1)
go

insert into commodity_uom values('PREM15', 'T', 'MT', 1)
go

insert into commodity_uom values('PREM25', 'L', '%', 1)
go

insert into commodity_uom values('PREM25', 'PR', 'BBL', 1)
go

insert into commodity_uom values('PREM25', 'PR', 'GAL', 1)
go

insert into commodity_uom values('PREM25', 'PR', 'MT', 1)
go

insert into commodity_uom values('PREM25', 'T', 'BBL', 1)
go

insert into commodity_uom values('PREM25', 'T', 'GAL', 1)
go

insert into commodity_uom values('PREM25', 'T', 'MB', 1)
go

insert into commodity_uom values('PREM25', 'T', 'MT', 1)
go

insert into commodity_uom values('PRODUCT', 'P', 'BBL', 1)
go

insert into commodity_uom values('PRODUCT', 'P', 'GAL', 1)
go

insert into commodity_uom values('PRODUCT', 'P', 'MB', 1)
go

insert into commodity_uom values('PRODUCT', 'P', 'MT', 1)
go

insert into commodity_uom values('PRODUCT', 'S', 'BBL', 1)
go

insert into commodity_uom values('PRODUCT', 'S', 'GAL', 1)
go

insert into commodity_uom values('PRODUCT', 'S', 'MB', 1)
go

insert into commodity_uom values('PRODUCT', 'S', 'MT', 1)
go

insert into commodity_uom values('PRODUCT', 'T', 'BBL', 1)
go

insert into commodity_uom values('PRODUCT', 'T', 'GAL', 1)
go

insert into commodity_uom values('PRODUCT', 'T', 'MB', 1)
go

insert into commodity_uom values('PRODUCT', 'T', 'MT', 1)
go

insert into commodity_uom values('PRODUCTS', 'I', 'BBL', 1)
go

insert into commodity_uom values('PRODUCTS', 'I', 'MB', 1)
go

insert into commodity_uom values('PRODUCTS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('PRODUCTS', 'PR', 'GAL', 1)
go

insert into commodity_uom values('PRODUCTS', 'PR', 'MB', 1)
go

insert into commodity_uom values('PRODUCTS', 'T', 'BBL', 1)
go

insert into commodity_uom values('PRODUCTS', 'T', 'GAL', 1)
go

insert into commodity_uom values('PRODUCTS', 'T', 'MB', 1)
go

insert into commodity_uom values('PROPANE', 'I', 'MT', 1)
go

insert into commodity_uom values('PROPANE', 'L', '%', 1)
go

insert into commodity_uom values('PROPANE', 'P', 'MT', 1)
go

insert into commodity_uom values('PROPANE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('PROPANE', 'PR', 'GAL', 1)
go

insert into commodity_uom values('PROPANE', 'PR', 'MT', 1)
go

insert into commodity_uom values('PROPANE', 'T', 'BBL', 1)
go

insert into commodity_uom values('PROPANE', 'T', 'GAL', 1)
go

insert into commodity_uom values('PROPANE', 'T', 'MB', 1)
go

insert into commodity_uom values('PROPANE', 'T', 'MT', 1)
go

insert into commodity_uom values('PTE', 'I', 'UNIT', 1)
go

insert into commodity_uom values('PTE', 'T', 'UNIT', 1)
go

insert into commodity_uom values('QTDUKHAN', 'L', '%', 1)
go

insert into commodity_uom values('QTDUKHAN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('QTDUKHAN', 'PR', 'LT', 1)
go

insert into commodity_uom values('QTDUKHAN', 'T', 'LOTS', 1)
go

insert into commodity_uom values('QTDUKHAN', 'T', 'MB', 1)
go

insert into commodity_uom values('QTDUKHAN', 'T', 'MT', 1)
go

insert into commodity_uom values('QTMARINE', 'L', '%', 1)
go

insert into commodity_uom values('QTMARINE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('QTMARINE', 'PR', 'MT', 1)
go

insert into commodity_uom values('QTMARINE', 'T', 'BBL', 1)
go

insert into commodity_uom values('QTMARINE', 'T', 'MB', 1)
go

insert into commodity_uom values('QTMARINE', 'T', 'MT', 1)
go

insert into commodity_uom values('QUAIBOE', 'L', '%', 1)
go

insert into commodity_uom values('QUAIBOE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('QUAIBOE', 'PR', 'MT', 1)
go

insert into commodity_uom values('QUAIBOE', 'T', 'BBL', 1)
go

insert into commodity_uom values('QUAIBOE', 'T', 'MB', 1)
go

insert into commodity_uom values('QUAIBOE', 'T', 'MT', 1)
go

insert into commodity_uom values('RABI', 'L', '%', 1)
go

insert into commodity_uom values('RABI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('RABI', 'PR', 'MT', 1)
go

insert into commodity_uom values('RABI', 'T', 'BBL', 1)
go

insert into commodity_uom values('RABI', 'T', 'MB', 1)
go

insert into commodity_uom values('RABI', 'T', 'MT', 1)
go

insert into commodity_uom values('RASGHARI', 'L', '%', 1)
go

insert into commodity_uom values('RASGHARI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('RASGHARI', 'PR', 'MT', 1)
go

insert into commodity_uom values('RASGHARI', 'T', 'BBL', 1)
go

insert into commodity_uom values('RASGHARI', 'T', 'MB', 1)
go

insert into commodity_uom values('RASGHARI', 'T', 'MT', 1)
go

insert into commodity_uom values('RATAWI', 'L', '%', 1)
go

insert into commodity_uom values('RATAWI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('RATAWI', 'PR', 'MB', 1)
go

insert into commodity_uom values('RATAWI', 'T', 'BBL', 1)
go

insert into commodity_uom values('RATAWI', 'T', 'GAL', 1)
go

insert into commodity_uom values('RATAWI', 'T', 'MB', 1)
go

insert into commodity_uom values('RATAWI', 'T', 'MT', 1)
go

insert into commodity_uom values('RBOB', 'L', '%', 1)
go

insert into commodity_uom values('RBOB', 'PR', 'BBL', 1)
go

insert into commodity_uom values('RBOB', 'PR', 'GAL', 1)
go

insert into commodity_uom values('RBOB', 'PR', 'MT', 1)
go

insert into commodity_uom values('RBOB', 'T', 'BBL', 1)
go

insert into commodity_uom values('RBOB', 'T', 'GAL', 1)
go

insert into commodity_uom values('RBOB', 'T', 'MB', 1)
go

insert into commodity_uom values('RBOB', 'T', 'MT', 1)
go

insert into commodity_uom values('RC250', 'I', 'BBL', 1)
go

insert into commodity_uom values('RC250', 'I', 'MT', 1)
go

insert into commodity_uom values('RC250', 'L', '%', 1)
go

insert into commodity_uom values('RC250', 'PR', 'BBL', 1)
go

insert into commodity_uom values('RC250', 'PR', 'MT', 1)
go

insert into commodity_uom values('RC250', 'T', 'BBL', 1)
go

insert into commodity_uom values('RC250', 'T', 'MT', 1)
go

insert into commodity_uom values('RME25', 'I', 'MT', 1)
go

insert into commodity_uom values('RME25', 'P', 'MT', 1)
go

insert into commodity_uom values('RME25', 'PR', 'BBL', 1)
go

insert into commodity_uom values('RME25', 'PR', 'MT', 1)
go

insert into commodity_uom values('RME25', 'T', 'MT', 1)
go

insert into commodity_uom values('RMG35', 'L', '%', 1)
go

insert into commodity_uom values('RMG35', 'PR', 'BBL', 1)
go

insert into commodity_uom values('RMG35', 'PR', 'GAL', 1)
go

insert into commodity_uom values('RMG35', 'PR', 'MT', 1)
go

insert into commodity_uom values('RMG35', 'T', 'BBL', 1)
go

insert into commodity_uom values('RMG35', 'T', 'GAL', 1)
go

insert into commodity_uom values('RMG35', 'T', 'M3', 1)
go

insert into commodity_uom values('RMG35', 'T', 'MB', 1)
go

insert into commodity_uom values('RMG35', 'T', 'MT', 1)
go

insert into commodity_uom values('RMG35RFY', 'L', '%', 1)
go

insert into commodity_uom values('RMG35RFY', 'PR', 'BBL', 1)
go

insert into commodity_uom values('RMG35RFY', 'PR', 'GAL', 1)
go

insert into commodity_uom values('RMG35RFY', 'PR', 'MT', 1)
go

insert into commodity_uom values('RMG35RFY', 'T', 'BBL', 1)
go

insert into commodity_uom values('RMG35RFY', 'T', 'GAL', 1)
go

insert into commodity_uom values('RMG35RFY', 'T', 'M3', 1)
go

insert into commodity_uom values('RMG35RFY', 'T', 'MB', 1)
go

insert into commodity_uom values('RMG35RFY', 'T', 'MT', 1)
go

insert into commodity_uom values('SAHARA', 'L', '%', 1)
go

insert into commodity_uom values('SAHARA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SAHARA', 'PR', 'MT', 1)
go

insert into commodity_uom values('SAHARA', 'T', 'BBL', 1)
go

insert into commodity_uom values('SAHARA', 'T', 'MB', 1)
go

insert into commodity_uom values('SAHARA', 'T', 'MT', 1)
go

insert into commodity_uom values('SAHARABL', 'L', '%', 1)
go

insert into commodity_uom values('SAHARABL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SAHARABL', 'PR', 'MT', 1)
go

insert into commodity_uom values('SAHARABL', 'T', 'BBL', 1)
go

insert into commodity_uom values('SAHARABL', 'T', 'MB', 1)
go

insert into commodity_uom values('SAHARABL', 'T', 'MT', 1)
go

insert into commodity_uom values('SALADIN', 'L', '%', 1)
go

insert into commodity_uom values('SALADIN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SALADIN', 'PR', 'MT', 1)
go

insert into commodity_uom values('SALADIN', 'T', 'BBL', 1)
go

insert into commodity_uom values('SALADIN', 'T', 'MB', 1)
go

insert into commodity_uom values('SALADIN', 'T', 'MT', 1)
go

insert into commodity_uom values('SANTABAR', 'L', '%', 1)
go

insert into commodity_uom values('SANTABAR', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SANTABAR', 'PR', 'MT', 1)
go

insert into commodity_uom values('SANTABAR', 'T', 'BBL', 1)
go

insert into commodity_uom values('SANTABAR', 'T', 'MB', 1)
go

insert into commodity_uom values('SANTABAR', 'T', 'MT', 1)
go

insert into commodity_uom values('SARIR', 'L', '%', 1)
go

insert into commodity_uom values('SARIR', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SARIR', 'PR', 'MT', 1)
go

insert into commodity_uom values('SARIR', 'T', 'BBL', 1)
go

insert into commodity_uom values('SARIR', 'T', 'MB', 1)
go

insert into commodity_uom values('SARIR', 'T', 'MT', 1)
go

insert into commodity_uom values('SEK', 'I', 'UNIT', 1)
go

insert into commodity_uom values('SEK', 'T', 'UNIT', 1)
go

insert into commodity_uom values('SEMBILAN', 'L', '%', 1)
go

insert into commodity_uom values('SEMBILAN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SEMBILAN', 'PR', 'MT', 1)
go

insert into commodity_uom values('SEMBILAN', 'T', 'BBL', 1)
go

insert into commodity_uom values('SEMBILAN', 'T', 'MB', 1)
go

insert into commodity_uom values('SEMBILAN', 'T', 'MT', 1)
go

insert into commodity_uom values('SEME', 'L', '%', 1)
go

insert into commodity_uom values('SEME', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SEME', 'PR', 'MT', 1)
go

insert into commodity_uom values('SEME', 'T', 'BBL', 1)
go

insert into commodity_uom values('SEME', 'T', 'MB', 1)
go

insert into commodity_uom values('SEME', 'T', 'MT', 1)
go

insert into commodity_uom values('SERIA', 'L', '%', 1)
go

insert into commodity_uom values('SERIA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SERIA', 'PR', 'MT', 1)
go

insert into commodity_uom values('SERIA', 'T', 'BBL', 1)
go

insert into commodity_uom values('SERIA', 'T', 'MB', 1)
go

insert into commodity_uom values('SERIA', 'T', 'MT', 1)
go

insert into commodity_uom values('SHENGLI', 'L', '%', 1)
go

insert into commodity_uom values('SHENGLI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SHENGLI', 'PR', 'MT', 1)
go

insert into commodity_uom values('SHENGLI', 'T', 'BBL', 1)
go

insert into commodity_uom values('SHENGLI', 'T', 'MB', 1)
go

insert into commodity_uom values('SHENGLI', 'T', 'MT', 1)
go

insert into commodity_uom values('SIBLITE', 'L', '%', 1)
go

insert into commodity_uom values('SIBLITE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SIBLITE', 'PR', 'MT', 1)
go

insert into commodity_uom values('SIBLITE', 'T', 'BBL', 1)
go

insert into commodity_uom values('SIBLITE', 'T', 'MB', 1)
go

insert into commodity_uom values('SIBLITE', 'T', 'MT', 1)
go

insert into commodity_uom values('SLR', 'L', '%', 1)
go

insert into commodity_uom values('SLR', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SLR', 'PR', 'MT', 1)
go

insert into commodity_uom values('SLR', 'T', 'BBL', 1)
go

insert into commodity_uom values('SLR', 'T', 'MB', 1)
go

insert into commodity_uom values('SLR', 'T', 'MT', 1)
go

insert into commodity_uom values('SOUEDIE', 'L', '%', 1)
go

insert into commodity_uom values('SOUEDIE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SOUEDIE', 'PR', 'MT', 1)
go

insert into commodity_uom values('SOUEDIE', 'T', 'BBL', 1)
go

insert into commodity_uom values('SOUEDIE', 'T', 'MB', 1)
go

insert into commodity_uom values('SOUEDIE', 'T', 'MT', 1)
go

insert into commodity_uom values('SOUTHBLE', 'L', '%', 1)
go

insert into commodity_uom values('SOUTHBLE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SOUTHBLE', 'PR', 'MT', 1)
go

insert into commodity_uom values('SOUTHBLE', 'T', 'BBL', 1)
go

insert into commodity_uom values('SOUTHBLE', 'T', 'MB', 1)
go

insert into commodity_uom values('SOUTHBLE', 'T', 'MT', 1)
go

insert into commodity_uom values('SOVIETEX', 'L', '%', 1)
go

insert into commodity_uom values('SOVIETEX', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SOVIETEX', 'PR', 'MT', 1)
go

insert into commodity_uom values('SOVIETEX', 'T', 'BBL', 1)
go

insert into commodity_uom values('SOVIETEX', 'T', 'MB', 1)
go

insert into commodity_uom values('SOVIETEX', 'T', 'MT', 1)
go

insert into commodity_uom values('SOYO', 'L', '%', 1)
go

insert into commodity_uom values('SOYO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SOYO', 'PR', 'MB', 1)
go

insert into commodity_uom values('SOYO', 'T', 'BBL', 1)
go

insert into commodity_uom values('SOYO', 'T', 'MB', 1)
go

insert into commodity_uom values('SOYO', 'T', 'MT', 1)
go

insert into commodity_uom values('SPRAYTEX', 'L', '%', 1)
go

insert into commodity_uom values('SPRAYTEX', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SPRAYTEX', 'PR', 'GAL', 1)
go

insert into commodity_uom values('SPRAYTEX', 'PR', 'MB', 1)
go

insert into commodity_uom values('SPRAYTEX', 'T', 'BBL', 1)
go

insert into commodity_uom values('SPRAYTEX', 'T', 'GAL', 1)
go

insert into commodity_uom values('SPRAYTEX', 'T', 'MB', 1)
go

insert into commodity_uom values('SPRAYTEX', 'T', 'MT', 1)
go

insert into commodity_uom values('STAT', 'L', '%', 1)
go

insert into commodity_uom values('STAT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('STAT', 'PR', 'MT', 1)
go

insert into commodity_uom values('STAT', 'T', 'BBL', 1)
go

insert into commodity_uom values('STAT', 'T', 'MB', 1)
go

insert into commodity_uom values('STAT', 'T', 'MT', 1)
go

insert into commodity_uom values('STS', 'L', '%', 1)
go

insert into commodity_uom values('STS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('STS', 'PR', 'MT', 1)
go

insert into commodity_uom values('STS', 'T', 'BBL', 1)
go

insert into commodity_uom values('STS', 'T', 'MB', 1)
go

insert into commodity_uom values('STS', 'T', 'MT', 1)
go

insert into commodity_uom values('STSWT', 'L', '%', 1)
go

insert into commodity_uom values('STSWT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('STSWT', 'PR', 'MT', 1)
go

insert into commodity_uom values('STSWT', 'T', 'BBL', 1)
go

insert into commodity_uom values('STSWT', 'T', 'MB', 1)
go

insert into commodity_uom values('STSWT', 'T', 'MT', 1)
go

insert into commodity_uom values('SUEZBLND', 'L', '%', 1)
go

insert into commodity_uom values('SUEZBLND', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SUEZBLND', 'PR', 'MT', 1)
go

insert into commodity_uom values('SUEZBLND', 'T', 'BBL', 1)
go

insert into commodity_uom values('SUEZBLND', 'T', 'MB', 1)
go

insert into commodity_uom values('SUEZBLND', 'T', 'MT', 1)
go

insert into commodity_uom values('SUMATRAL', 'L', '%', 1)
go

insert into commodity_uom values('SUMATRAL', 'P', 'BBL', 1)
go

insert into commodity_uom values('SUMATRAL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SUMATRAL', 'PR', 'MT', 1)
go

insert into commodity_uom values('SUMATRAL', 'T', 'BBL', 1)
go

insert into commodity_uom values('SUMATRAL', 'T', 'MB', 1)
go

insert into commodity_uom values('SUMATRAL', 'T', 'MT', 1)
go

insert into commodity_uom values('SYB', 'L', '%', 1)
go

insert into commodity_uom values('SYB', 'PR', 'BBL', 1)
go

insert into commodity_uom values('SYB', 'PR', 'MT', 1)
go

insert into commodity_uom values('SYB', 'T', 'BBL', 1)
go

insert into commodity_uom values('SYB', 'T', 'MB', 1)
go

insert into commodity_uom values('SYB', 'T', 'MT', 1)
go

insert into commodity_uom values('TAKULA', 'L', '%', 1)
go

insert into commodity_uom values('TAKULA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('TAKULA', 'PR', 'MT', 1)
go

insert into commodity_uom values('TAKULA', 'T', 'BBL', 1)
go

insert into commodity_uom values('TAKULA', 'T', 'MB', 1)
go

insert into commodity_uom values('TAKULA', 'T', 'MT', 1)
go

insert into commodity_uom values('TAPIS', 'L', '%', 1)
go

insert into commodity_uom values('TAPIS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('TAPIS', 'PR', 'MT', 1)
go

insert into commodity_uom values('TAPIS', 'T', 'BBL', 1)
go

insert into commodity_uom values('TAPIS', 'T', 'MB', 1)
go

insert into commodity_uom values('TAPIS', 'T', 'MT', 1)
go

insert into commodity_uom values('THEVENAR', 'L', '%', 1)
go

insert into commodity_uom values('THEVENAR', 'PR', 'BBL', 1)
go

insert into commodity_uom values('THEVENAR', 'PR', 'MT', 1)
go

insert into commodity_uom values('THEVENAR', 'T', 'BBL', 1)
go

insert into commodity_uom values('THEVENAR', 'T', 'MB', 1)
go

insert into commodity_uom values('THEVENAR', 'T', 'MT', 1)
go

insert into commodity_uom values('THUMS', 'L', '%', 1)
go

insert into commodity_uom values('THUMS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('THUMS', 'PR', 'MT', 1)
go

insert into commodity_uom values('THUMS', 'T', 'BBL', 1)
go

insert into commodity_uom values('THUMS', 'T', 'MB', 1)
go

insert into commodity_uom values('THUMS', 'T', 'MT', 1)
go

insert into commodity_uom values('UDANG', 'L', '%', 1)
go

insert into commodity_uom values('UDANG', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UDANG', 'PR', 'MT', 1)
go

insert into commodity_uom values('UDANG', 'T', 'BBL', 1)
go

insert into commodity_uom values('UDANG', 'T', 'MB', 1)
go

insert into commodity_uom values('UDANG', 'T', 'MT', 1)
go

insert into commodity_uom values('UKC', 'O', 'UNIT', 1)
go

insert into commodity_uom values('UKC', 'P', 'UNIT', 1)
go

insert into commodity_uom values('UKC', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('UKC', 'T', 'UNIT', 1)
go

insert into commodity_uom values('UL87A4', 'L', '%', 1)
go

insert into commodity_uom values('UL87A4', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UL87A4', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UL87A4', 'PR', 'MT', 1)
go

insert into commodity_uom values('UL87A4', 'T', 'BBL', 1)
go

insert into commodity_uom values('UL87A4', 'T', 'MB', 1)
go

insert into commodity_uom values('UL87A4', 'T', 'MT', 1)
go

insert into commodity_uom values('UL87A5', 'L', '%', 1)
go

insert into commodity_uom values('UL87A5', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UL87A5', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UL87A5', 'PR', 'MT', 1)
go

insert into commodity_uom values('UL87A5', 'T', 'BBL', 1)
go

insert into commodity_uom values('UL87A5', 'T', 'MB', 1)
go

insert into commodity_uom values('UL87A5', 'T', 'MT', 1)
go

insert into commodity_uom values('UL87A8', 'L', '%', 1)
go

insert into commodity_uom values('UL87A8', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UL87A8', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UL87A8', 'PR', 'MT', 1)
go

insert into commodity_uom values('UL87A8', 'T', 'BBL', 1)
go

insert into commodity_uom values('UL87A8', 'T', 'MB', 1)
go

insert into commodity_uom values('UL87A8', 'T', 'MT', 1)
go

insert into commodity_uom values('UL87A9', 'L', '%', 1)
go

insert into commodity_uom values('UL87A9', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UL87A9', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UL87A9', 'PR', 'MT', 1)
go

insert into commodity_uom values('UL87A9', 'T', 'BBL', 1)
go

insert into commodity_uom values('UL87A9', 'T', 'MB', 1)
go

insert into commodity_uom values('UL87A9', 'T', 'MT', 1)
go

insert into commodity_uom values('UL93D9', 'L', '%', 1)
go

insert into commodity_uom values('UL93D9', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UL93D9', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UL93D9', 'PR', 'MT', 1)
go

insert into commodity_uom values('UL93D9', 'T', 'BBL', 1)
go

insert into commodity_uom values('UL93D9', 'T', 'MB', 1)
go

insert into commodity_uom values('UL93D9', 'T', 'MT', 1)
go

insert into commodity_uom values('UMSHAIF', 'L', '%', 1)
go

insert into commodity_uom values('UMSHAIF', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UMSHAIF', 'PR', 'LT', 1)
go

insert into commodity_uom values('UMSHAIF', 'T', 'BBL', 1)
go

insert into commodity_uom values('UMSHAIF', 'T', 'LOTS', 1)
go

insert into commodity_uom values('UMSHAIF', 'T', 'LT', 1)
go

insert into commodity_uom values('UMSHAIF', 'T', 'MB', 1)
go

insert into commodity_uom values('UNL87', 'L', '%', 1)
go

insert into commodity_uom values('UNL87', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNL87', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNL87', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNL87', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNL87', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNL87', 'T', 'LOTS', 1)
go

insert into commodity_uom values('UNL87', 'T', 'MB', 1)
go

insert into commodity_uom values('UNL87', 'T', 'MG', 1)
go

insert into commodity_uom values('UNL87', 'T', 'MT', 1)
go

insert into commodity_uom values('UNL87/O', 'L', '%', 1)
go

insert into commodity_uom values('UNL87/O', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNL87/O', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNL87/O', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNL87/O', 'T', 'MB', 1)
go

insert into commodity_uom values('UNL87/O', 'T', 'MG', 1)
go

insert into commodity_uom values('UNL87/O', 'T', 'MT', 1)
go

insert into commodity_uom values('UNL89', 'L', '%', 1)
go

insert into commodity_uom values('UNL89', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNL89', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNL89', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNL89', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNL89', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNL89', 'T', 'MB', 1)
go

insert into commodity_uom values('UNL89', 'T', 'MT', 1)
go

insert into commodity_uom values('UNL89/O', 'L', '%', 1)
go

insert into commodity_uom values('UNL89/O', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNL89/O', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNL89/O', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNL89/O', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNL89/O', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNL89/O', 'T', 'MB', 1)
go

insert into commodity_uom values('UNL89/O', 'T', 'MG', 1)
go

insert into commodity_uom values('UNL89/O', 'T', 'MT', 1)
go

insert into commodity_uom values('UNL92', 'L', '%', 1)
go

insert into commodity_uom values('UNL92', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNL92', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNL92', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNL92', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNL92', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNL92', 'T', 'MB', 1)
go

insert into commodity_uom values('UNL92', 'T', 'MT', 1)
go

insert into commodity_uom values('UNL92/O', 'L', '%', 1)
go

insert into commodity_uom values('UNL92/O', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNL92/O', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNL92/O', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNL92/O', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNL92/O', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNL92/O', 'T', 'MB', 1)
go

insert into commodity_uom values('UNL92/O', 'T', 'MG', 1)
go

insert into commodity_uom values('UNL93', 'L', '%', 1)
go

insert into commodity_uom values('UNL93', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNL93', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNL93', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNL93', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNL93', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNL93', 'T', 'LOTS', 1)
go

insert into commodity_uom values('UNL93', 'T', 'MB', 1)
go

insert into commodity_uom values('UNL93', 'T', 'MT', 1)
go

insert into commodity_uom values('UNL93/O', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNL93/O', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNL93/O', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNL93/O', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNL93/O', 'T', 'MB', 1)
go

insert into commodity_uom values('UNL93D5', 'L', '%', 1)
go

insert into commodity_uom values('UNL93D5', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNL93D5', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNL93D5', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNL93D5', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNL93D5', 'T', 'MB', 1)
go

insert into commodity_uom values('UNL93D5', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLM115', 'L', '%', 1)
go

insert into commodity_uom values('UNLM115', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLM115', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLM115', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLM115', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLM115', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLM115', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLM115', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLM115', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLM135', 'L', '%', 1)
go

insert into commodity_uom values('UNLM135', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLM135', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLM135', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLM135', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLM135', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLM135', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLM135', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLM135', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLM15', 'L', '%', 1)
go

insert into commodity_uom values('UNLM15', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLM15', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLM15', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLM15', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLM15', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLM15', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLM15', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLM15', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLM78', 'L', '%', 1)
go

insert into commodity_uom values('UNLM78', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLM78', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLM78', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLM78', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLM78', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLM78', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLM78', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLM78', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLM9', 'L', '%', 1)
go

insert into commodity_uom values('UNLM9', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLM9', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLM9', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLM9', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLM9', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLM9', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLM9', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLM9', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLMO115', 'L', '%', 1)
go

insert into commodity_uom values('UNLMO115', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLMO115', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLMO115', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLMO115', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLMO115', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLMO115', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLMO115', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLMO135', 'L', '%', 1)
go

insert into commodity_uom values('UNLMO135', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLMO135', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLMO135', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLMO135', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLMO135', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLMO135', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLMO135', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLMO135', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLMO15', 'L', '%', 1)
go

insert into commodity_uom values('UNLMO15', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLMO15', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLMO15', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLMO15', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLMO15', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLMO15', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLMO15', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLMO78', 'L', '%', 1)
go

insert into commodity_uom values('UNLMO78', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLMO78', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLMO78', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLMO78', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLMO78', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLMO78', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLMO78', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLMO78', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLMO9', 'L', '%', 1)
go

insert into commodity_uom values('UNLMO9', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLMO9', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLMO9', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLMO9', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLMO9', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLMO9', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLMO9', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLMO9', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLP115', 'L', '%', 1)
go

insert into commodity_uom values('UNLP115', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLP115', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLP115', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLP115', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLP115', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLP115', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLP115', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLP115', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLP135', 'L', '%', 1)
go

insert into commodity_uom values('UNLP135', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLP135', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLP135', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLP135', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLP135', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLP135', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLP135', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLP135', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLP135', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLP15', 'L', '%', 1)
go

insert into commodity_uom values('UNLP15', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLP15', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLP15', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLP15', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLP15', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLP15', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLP15', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLP15', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLP78', 'L', '%', 1)
go

insert into commodity_uom values('UNLP78', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLP78', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLP78', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLP78', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLP78', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLP78', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLP78', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLP78', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLP78', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLP87/9', 'L', '%', 1)
go

insert into commodity_uom values('UNLP87/9', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLP87/9', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLP87/9', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLP87/9', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLP87/9', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLP87/9', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLP87/9', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLP87/9', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLP87/9', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLPO115', 'L', '%', 1)
go

insert into commodity_uom values('UNLPO115', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLPO115', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLPO115', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLPO115', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLPO115', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLPO115', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLPO115', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLPO135', 'L', '%', 1)
go

insert into commodity_uom values('UNLPO135', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLPO135', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLPO135', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLPO135', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLPO135', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLPO135', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLPO135', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLPO15', 'L', '%', 1)
go

insert into commodity_uom values('UNLPO15', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLPO15', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLPO15', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLPO15', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLPO15', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLPO15', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLPO15', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLPO15', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLPO78', 'L', '%', 1)
go

insert into commodity_uom values('UNLPO78', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLPO78', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLPO78', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLPO78', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLPO78', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLPO78', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLPO78', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLPO78', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLPO9', 'L', '%', 1)
go

insert into commodity_uom values('UNLPO9', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLPO9', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLPO9', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLPO9', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLPO9', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLPO9', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLPO9', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLPO9', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLR115', 'L', '%', 1)
go

insert into commodity_uom values('UNLR115', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLR115', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLR115', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLR115', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLR115', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLR115', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLR115', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLR115', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLR115', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLR135', 'L', '%', 1)
go

insert into commodity_uom values('UNLR135', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLR135', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLR135', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLR135', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLR135', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLR135', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLR135', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLR135', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLR135', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLR15', 'L', '%', 1)
go

insert into commodity_uom values('UNLR15', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLR15', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLR15', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLR15', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLR15', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLR15', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLR15', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLR15', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLR15', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLR47', 'L', '%', 1)
go

insert into commodity_uom values('UNLR47', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLR47', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLR47', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLR47', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLR47', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLR47', 'T', 'LOTS', 1)
go

insert into commodity_uom values('UNLR47', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLR47', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLR47', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLR4748', 'L', '%', 1)
go

insert into commodity_uom values('UNLR4748', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLR4748', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLR4748', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLR4748', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLR4748', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLR4748', 'T', 'LOTS', 1)
go

insert into commodity_uom values('UNLR4748', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLR4748', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLR4748', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLR48', 'L', '%', 1)
go

insert into commodity_uom values('UNLR48', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLR48', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLR48', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLR48', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLR48', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLR48', 'T', 'LOTS', 1)
go

insert into commodity_uom values('UNLR48', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLR48', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLR48', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLR78', 'L', '%', 1)
go

insert into commodity_uom values('UNLR78', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLR78', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLR78', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLR78', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLR78', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLR78', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLR78', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLR78', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLR78', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLR9', 'L', '%', 1)
go

insert into commodity_uom values('UNLR9', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLR9', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLR9', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLR9', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLR9', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLR9', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLR9', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLR9', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLR9', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLRO115', 'L', '%', 1)
go

insert into commodity_uom values('UNLRO115', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLRO115', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLRO115', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLRO115', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLRO115', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLRO115', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLRO115', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLRO135', 'L', '%', 1)
go

insert into commodity_uom values('UNLRO135', 'P', 'BBL', 1)
go

insert into commodity_uom values('UNLRO135', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLRO135', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLRO135', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLRO135', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLRO135', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLRO135', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLRO135', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLRO15', 'L', '%', 1)
go

insert into commodity_uom values('UNLRO15', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLRO15', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLRO15', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLRO15', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLRO15', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLRO15', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLRO15', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLRO15', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLRO78', 'L', '%', 1)
go

insert into commodity_uom values('UNLRO78', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLRO78', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLRO78', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLRO78', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLRO78', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLRO78', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLRO78', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLRO9', 'L', '%', 1)
go

insert into commodity_uom values('UNLRO9', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLRO9', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLRO9', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLRO9', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLRO9', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLRO9', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLRO9', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLRO9', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLS115', 'L', '%', 1)
go

insert into commodity_uom values('UNLS115', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLS115', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLS115', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLS115', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLS115', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLS115', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLS115', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLS115', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLS115', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLS135', 'L', '%', 1)
go

insert into commodity_uom values('UNLS135', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLS135', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLS135', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLS135', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLS135', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLS135', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLS135', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLS135', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLS15', 'L', '%', 1)
go

insert into commodity_uom values('UNLS15', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLS15', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLS15', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLS15', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLS15', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLS15', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLS15', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLS15', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLS15', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLS78', 'L', '%', 1)
go

insert into commodity_uom values('UNLS78', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLS78', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLS78', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLS78', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLS78', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLS78', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLS78', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLS78', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLS78', 'T', 'MT', 1)
go

insert into commodity_uom values('UNLS9', 'L', '%', 1)
go

insert into commodity_uom values('UNLS9', 'P', 'MG', 1)
go

insert into commodity_uom values('UNLS9', 'PR', 'BBL', 1)
go

insert into commodity_uom values('UNLS9', 'PR', 'GAL', 1)
go

insert into commodity_uom values('UNLS9', 'PR', 'MT', 1)
go

insert into commodity_uom values('UNLS9', 'T', 'BBL', 1)
go

insert into commodity_uom values('UNLS9', 'T', 'GAL', 1)
go

insert into commodity_uom values('UNLS9', 'T', 'MB', 1)
go

insert into commodity_uom values('UNLS9', 'T', 'MG', 1)
go

insert into commodity_uom values('UNLS9', 'T', 'MT', 1)
go

insert into commodity_uom values('URAL', 'L', '%', 1)
go

insert into commodity_uom values('URAL', 'PR', 'BBL', 1)
go

insert into commodity_uom values('URAL', 'PR', 'MT', 1)
go

insert into commodity_uom values('URAL', 'T', 'BBL', 1)
go

insert into commodity_uom values('URAL', 'T', 'MB', 1)
go

insert into commodity_uom values('URAL', 'T', 'MT', 1)
go

insert into commodity_uom values('USC', 'T', 'UNIT', 1)
go

insert into commodity_uom values('USD', 'O', 'UNIT', 1)
go

insert into commodity_uom values('USD', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('USD', 'T', 'UNIT', 1)
go

insert into commodity_uom values('USDINT', 'PR', '%', 1)
go

insert into commodity_uom values('USD_EX', 'P', 'UNIT', 1)
go

insert into commodity_uom values('USD_EX', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('USD_EX', 'T', 'UNIT', 1)
go

insert into commodity_uom values('VGO', 'L', '%', 1)
go

insert into commodity_uom values('VGO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('VGO', 'PR', 'GAL', 1)
go

insert into commodity_uom values('VGO', 'PR', 'MT', 1)
go

insert into commodity_uom values('VGO', 'T', 'BBL', 1)
go

insert into commodity_uom values('VGO', 'T', 'MB', 1)
go

insert into commodity_uom values('VGO', 'T', 'MT', 1)
go

insert into commodity_uom values('VGO5', 'L', '%', 1)
go

insert into commodity_uom values('VGO5', 'PR', 'BBL', 1)
go

insert into commodity_uom values('VGO5', 'PR', 'GAL', 1)
go

insert into commodity_uom values('VGO5', 'PR', 'MT', 1)
go

insert into commodity_uom values('VGO5', 'T', 'BBL', 1)
go

insert into commodity_uom values('VGO5', 'T', 'MB', 1)
go

insert into commodity_uom values('VGO5', 'T', 'MT', 1)
go

insert into commodity_uom values('VGOHS', 'I', 'M3', 1)
go

insert into commodity_uom values('VGOHS', 'I', 'MT', 1)
go

insert into commodity_uom values('VGOHS', 'L', '%', 1)
go

insert into commodity_uom values('VGOHS', 'O', 'M3', 1)
go

insert into commodity_uom values('VGOHS', 'P', 'M3', 1)
go

insert into commodity_uom values('VGOHS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('VGOHS', 'PR', 'GAL', 1)
go

insert into commodity_uom values('VGOHS', 'PR', 'M3', 1)
go

insert into commodity_uom values('VGOHS', 'PR', 'MT', 1)
go

insert into commodity_uom values('VGOHS', 'S', 'M3', 1)
go

insert into commodity_uom values('VGOHS', 'S', 'MT', 1)
go

insert into commodity_uom values('VGOHS', 'T', 'BBL', 1)
go

insert into commodity_uom values('VGOHS', 'T', 'M3', 1)
go

insert into commodity_uom values('VGOHS', 'T', 'MB', 1)
go

insert into commodity_uom values('VGOHS', 'T', 'MT', 1)
go

insert into commodity_uom values('VGOLS', 'I', 'M3', 1)
go

insert into commodity_uom values('VGOLS', 'L', '%', 1)
go

insert into commodity_uom values('VGOLS', 'O', 'M3', 1)
go

insert into commodity_uom values('VGOLS', 'P', 'M3', 1)
go

insert into commodity_uom values('VGOLS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('VGOLS', 'PR', 'GAL', 1)
go

insert into commodity_uom values('VGOLS', 'PR', 'M3', 1)
go

insert into commodity_uom values('VGOLS', 'PR', 'MT', 1)
go

insert into commodity_uom values('VGOLS', 'S', 'M3', 1)
go

insert into commodity_uom values('VGOLS', 'T', 'BBL', 1)
go

insert into commodity_uom values('VGOLS', 'T', 'GAL', 1)
go

insert into commodity_uom values('VGOLS', 'T', 'M3', 1)
go

insert into commodity_uom values('VGOLS', 'T', 'MB', 1)
go

insert into commodity_uom values('VGOLS', 'T', 'MT', 1)
go

insert into commodity_uom values('WCHVY22', 'L', '%', 1)
go

insert into commodity_uom values('WCHVY22', 'PR', 'BBL', 1)
go

insert into commodity_uom values('WCHVY22', 'PR', 'GAL', 1)
go

insert into commodity_uom values('WCHVY22', 'PR', 'MT', 1)
go

insert into commodity_uom values('WCHVY22', 'T', 'BBL', 1)
go

insert into commodity_uom values('WCHVY22', 'T', 'MB', 1)
go

insert into commodity_uom values('WCHVY22', 'T', 'MT', 1)
go

insert into commodity_uom values('WGC', 'PR', 'UNIT', 1)
go

insert into commodity_uom values('WGC', 'T', 'UNIT', 1)
go

insert into commodity_uom values('WTI', 'L', '%', 1)
go

insert into commodity_uom values('WTI', 'PR', 'BBL', 1)
go

insert into commodity_uom values('WTI', 'PR', 'GAL', 1)
go

insert into commodity_uom values('WTI', 'PR', 'MT', 1)
go

insert into commodity_uom values('WTI', 'T', 'BBL', 1)
go

insert into commodity_uom values('WTI', 'T', 'LOTS', 1)
go

insert into commodity_uom values('WTI', 'T', 'MB', 1)
go

insert into commodity_uom values('WTI', 'T', 'MT', 1)
go

insert into commodity_uom values('WTI-HO', 'L', '%', 1)
go

insert into commodity_uom values('WTI-HO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('WTI-HO', 'PR', 'GAL', 1)
go

insert into commodity_uom values('WTI-HO', 'PR', 'MT', 1)
go

insert into commodity_uom values('WTI-HO', 'T', 'BBL', 1)
go

insert into commodity_uom values('WTI-HO', 'T', 'LOTS', 1)
go

insert into commodity_uom values('WTI-HO', 'T', 'MB', 1)
go

insert into commodity_uom values('WTI-HO', 'T', 'MT', 1)
go

insert into commodity_uom values('WTIPLUS', 'L', '%', 1)
go

insert into commodity_uom values('WTIPLUS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('WTIPLUS', 'T', 'BBL', 1)
go

insert into commodity_uom values('WTIPLUS', 'T', 'MB', 1)
go

insert into commodity_uom values('WTS', 'L', '%', 1)
go

insert into commodity_uom values('WTS', 'PR', 'BBL', 1)
go

insert into commodity_uom values('WTS', 'PR', 'MT', 1)
go

insert into commodity_uom values('WTS', 'T', 'BBL', 1)
go

insert into commodity_uom values('WTS', 'T', 'MB', 1)
go

insert into commodity_uom values('WTS', 'T', 'MT', 1)
go

insert into commodity_uom values('WYOSWEET', 'L', '%', 1)
go

insert into commodity_uom values('WYOSWEET', 'PR', 'BBL', 1)
go

insert into commodity_uom values('WYOSWEET', 'PR', 'MT', 1)
go

insert into commodity_uom values('WYOSWEET', 'T', 'BBL', 1)
go

insert into commodity_uom values('WYOSWEET', 'T', 'MB', 1)
go

insert into commodity_uom values('WYOSWEET', 'T', 'MT', 1)
go

insert into commodity_uom values('ZAAFARAN', 'L', '%', 1)
go

insert into commodity_uom values('ZAAFARAN', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ZAAFARAN', 'PR', 'LT', 1)
go

insert into commodity_uom values('ZAAFARAN', 'PR', 'MT', 1)
go

insert into commodity_uom values('ZAAFARAN', 'T', 'BBL', 1)
go

insert into commodity_uom values('ZAAFARAN', 'T', 'LT', 1)
go

insert into commodity_uom values('ZAAFARAN', 'T', 'MB', 1)
go

insert into commodity_uom values('ZAAFARAN', 'T', 'MT', 1)
go

insert into commodity_uom values('ZAFIRO', 'L', '%', 1)
go

insert into commodity_uom values('ZAFIRO', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ZAFIRO', 'PR', 'MT', 1)
go

insert into commodity_uom values('ZAFIRO', 'T', 'BBL', 1)
go

insert into commodity_uom values('ZAFIRO', 'T', 'MB', 1)
go

insert into commodity_uom values('ZAFIRO', 'T', 'MT', 1)
go

insert into commodity_uom values('ZAIRE', 'L', '%', 1)
go

insert into commodity_uom values('ZAIRE', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ZAIRE', 'PR', 'MT', 1)
go

insert into commodity_uom values('ZAIRE', 'T', 'BBL', 1)
go

insert into commodity_uom values('ZAIRE', 'T', 'MB', 1)
go

insert into commodity_uom values('ZAIRE', 'T', 'MT', 1)
go

insert into commodity_uom values('ZAKUMLOW', 'L', '%', 1)
go

insert into commodity_uom values('ZAKUMLOW', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ZAKUMLOW', 'PR', 'MT', 1)
go

insert into commodity_uom values('ZAKUMLOW', 'T', 'BBL', 1)
go

insert into commodity_uom values('ZAKUMLOW', 'T', 'MB', 1)
go

insert into commodity_uom values('ZAKUMLOW', 'T', 'MT', 1)
go

insert into commodity_uom values('ZARZ', 'L', '%', 1)
go

insert into commodity_uom values('ZARZ', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ZARZ', 'PR', 'MT', 1)
go

insert into commodity_uom values('ZARZ', 'T', 'BBL', 1)
go

insert into commodity_uom values('ZARZ', 'T', 'MB', 1)
go

insert into commodity_uom values('ZARZ', 'T', 'MT', 1)
go

insert into commodity_uom values('ZEIT', 'L', '%', 1)
go

insert into commodity_uom values('ZEIT', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ZEIT', 'PR', 'MT', 1)
go

insert into commodity_uom values('ZEIT', 'T', 'BBL', 1)
go

insert into commodity_uom values('ZEIT', 'T', 'MB', 1)
go

insert into commodity_uom values('ZEIT', 'T', 'MT', 1)
go

insert into commodity_uom values('ZUEITINA', 'L', '%', 1)
go

insert into commodity_uom values('ZUEITINA', 'PR', 'BBL', 1)
go

insert into commodity_uom values('ZUEITINA', 'PR', 'MT', 1)
go

insert into commodity_uom values('ZUEITINA', 'T', 'BBL', 1)
go

insert into commodity_uom values('ZUEITINA', 'T', 'MB', 1)
go

insert into commodity_uom values('ZUEITINA', 'T', 'MT', 1)
go

