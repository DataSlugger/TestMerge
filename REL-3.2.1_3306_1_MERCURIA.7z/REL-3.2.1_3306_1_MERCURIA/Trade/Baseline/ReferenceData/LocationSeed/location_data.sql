print ' '
print 'Loading additional seed data into the location table ...'
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AAHRUS', 'AAHRUS', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ABIDJAN', 'ABIDJAN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ABU', 'ABU AL BUKOOSH', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ACADIAN', 'ACADIAN SYSTEM', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ACAJUTL', 'ACAJUTLA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ACCRA', 'ACCRA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ADAMOVO', 'ADAMOVO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AECO', 'AECO C', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AECOA', 'AECO', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AECOCFOO', 'AECO C FOOTHILL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AECONOVA', 'AECO C, ON NOVA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AEP/APS', 'AEP/APS', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AEP/VEP', 'AEP/VEPCO', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AGHII', 'AGHII THEODORI', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AINSUK', 'AIN SUKHNA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AKABA', 'AKABA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AL-BAKR', 'AL-BAKR', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ALBANY', 'ALBANY  NY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ALGECIRA', 'ALGECIRAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ALGERIA', 'ALGERIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ALGONQU', 'MAHWAH,  NJ (TGP/ALGONQUIN)', 'N', 'Y', 
'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ALGONQU1', 'MENDON, MA (TGP/ALGONQUIN )', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ALGONQU2', 'CITYGATE, MA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ALGONQU3', 'BROOKFIELD, CT(IROQUOIS/ALGONQUIN)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ALGONQU4', 'LAMBERTVILLE, NJ', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ALGONQU5', 'CENTERVILLE, NJ (TRANSCO/ALGONQUIN)', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ALGONQU6', 'HANOVER, NJ (COLGAS/ALGONQUIN)', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ALIAGA', 'ALIAGA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ALLIANCE', 'ALLIANCE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AMBARLI', 'AMBARLI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AMSROTAN', 'AMSTERDAM/ROTTERDAM/ANTWERP', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AMSTERDA', 'AMSTERDAM', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AMSTROTT', 'AMSTERDAM/ROTTERDAM', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AMUAY', 'AMUAY BAY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ANG', 'PALANKA', 'N', 'N', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ANGOLA', 'ANGOLA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ANR', 'ANR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ANR-PAT', 'PATTERSON, LA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ANR-SE L', 'ANR -SE LEG, LA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ANRCUSTR', 'ANR CUSTER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ANRLKAR', 'ANR LAKE ATHUR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ANRSOHIO', 'ANR SOHIO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ANTAN', 'ANTAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ANTWERP', 'ANTWERP', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('APS', 'APS INTERCONNECT', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('APS/PJM', 'APS/PJM', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ARA', 'ARA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ARATU', 'ARATU', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ARDJUNA', 'ARDJUNA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ARGENTIN', 'ARGENTINA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ARGYLL', 'ARGYLL  FLATFORM', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ARUBA', 'ARUBA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ARZANNAH', 'ARZANNAH  ISLAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ARZEW', 'ARZEW', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ASH', 'ASH SHIHR, YEMEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ASHKELO', 'ASHKELON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ASHTART', 'ASHTART OFF SHORE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ASPROPYR', 'ASPROPYRGOS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ASUNCIO', 'ASUNCION, PARAGUAY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ATHENS', 'ATHENS', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AUGHNISH', 'AUGHINISH', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AUGUSTA', 'AUGUSTA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AUGUSTAT', 'AUGUSTA-TENNESSEE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AUSTRAL', 'AUSTRALIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AUSTRALI', 'AUSTRALIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AVILES', 'AVILES', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('AVNMOUTH', 'AVONMOUTH', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('Africa', 'Conacry', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BA', 'BUENOS AIRES', 'N', 'Y', 'N', 6, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BACTON', 'BACTON, UK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BADAK', 'BADAK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BAHAMAS', 'BAHAMAS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BAHIA', 'BAHIA BLANCA, ARGENTINA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BAHRAIN', 'BAHRAIN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BAJO', 'BAJO GRANDE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BALAOEQ', 'BALAO, EQUADOR', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BALBOA', 'BALBOA, PANAMA', 'N', 'N', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BALBOA,', 'BALBOA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BALONGAN', 'BALONGAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BALTIMO', 'BALTIMORE-NORTH, MD', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BALTIMOR', 'BALTIMORE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BANBURY', 'BANBURY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BANDAR', 'BANDAR IMAM', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BANDAR1', 'BANDAR IMAM KHOMEINI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BANGCHAK', 'BANGCHAK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BANGKOK', 'BANGKOK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BANIAS', 'BANIAS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BAR', 'BAR, YUGOSLAVIA (FORMER)', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BARCELO', 'BARCELONA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BARROWIL', 'BARROW ISLAND', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BARRY', 'BARRY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BARTONAL', 'BARTON-ALABAMA/TN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BARTONTN', 'BARTON-TENNESSEE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BATAM', 'BATAM ISLAND.', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BATANGAS', 'BATANGAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BATON', 'BATON  ROUGE LA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BATUMI', 'BATUMI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BAYONNE', 'BAYONNE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BAYOVAR', 'BAYOVAR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BAYPORT', 'BAYPORT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BAYTOWN', 'BAYTOWN, TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BEATRICE', 'BEATRICE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BEAUMON', 'BEAUMONT, TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BEAUMON1', 'BEAUMONT,TEXAS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BEAUMON2', 'BEAUMONT - HOUSTON, TX', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BEIRUT', 'BEIRUT', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BEJAIA', 'BEJAIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BELEM-M', 'BELEM-MACEIO RANGE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BELEM-P', 'BELEM-PARANAGUA RANGE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BELFAST', 'BELFAST', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BELGIAN', 'BELGIAN REFINING', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BELGIUM', 'BELGIUM', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BELIDA', 'BELIDA TERMINAL', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BELMONT', 'BELMONT  CITY GATE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BELVEDE', 'BELVEDERE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BERGEN,', 'BERGEN, SWEDEN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BERYL', 'BERYL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BGE', 'BGE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BILBAO', 'BILBAO', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BIRMIN', 'BIRMINGHAM, AL', 'N', 'Y', 'Y', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BIZERTE', 'BIZERTE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BLANG', 'BLANG LANCAG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BOMBAY', 'BOMBAY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BONNY', 'BONNY', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BONYTHON', 'BONYTHON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BORDEAUX', 'BORDEAUX', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BOSTON', 'BOSTON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BOTLEK', 'BOTLEK', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BOTROP', 'BOTROP', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BOURGAS', 'BOURGAS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BP', 'BP  GOTENBERG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BPBIENVL', 'BP-BIENVILLE SONAT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BPREF', 'BP REFINERY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BRASS', 'BRASS  RIVER', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BRAZIL', 'BRAZIL', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BRCANTW', 'BRC ANTWERP', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BREMEN', 'BREMEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BREST', 'BREST', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BRIDGEL', 'BRIDGELINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BROF', 'BROFJORDEN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BROOKLNY', 'BROOKLYN, NY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BROWNSV', 'BROWNSVILLE, TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BRUNSBUT', 'BRUNSBUTTEL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BUDAPES', 'BUDAPEST', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BUDKOVCE', 'BUDKOVCE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BUENAVE', 'BUENAVENTURA,COLUMBIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BUENOS', 'BUENOS AIRES.ARG.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BULGARI', 'BULGARIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BULLENBA', 'BULLENBAAI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BUNYU', 'BUNYU', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BURNABY', 'BURNABY BC', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('BUSAN', 'BUSAN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CA', 'CARTAGENA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CABINDA', 'CABINDA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CALAIS', 'CALAIS', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CALCUTA', 'CALCUTA, INDIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CALETA', 'CALETA OLIVIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CALIFOR', 'CALIFORNIA-OREGON BORDER', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CAMDEN', 'CAMDEN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CAMDEN,', 'CAMDEN, NJ', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CAMDEN,1', 'CAMDEN,NEW JERSEY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CAMEROON', 'CAMEROON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CAMMAC', 'CAMMAC YARD', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CAMPANA', 'CAMPANA,ARGENTINA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CANADA', 'CANADA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CANAJO', 'CANAJOHARIE CNG/IROQ', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CANAJOH', 'CANAJOHARIE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CANARY', 'CANARY ISLANDS', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CAP', 'CAP LOPEZ', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CAPETOWN', 'CAPE TOWN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CAPTAIN', 'CAPTAIN FPSO', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CARACASB', 'CARACASBAAI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CARDIFF', 'CARDIFF', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CARDON', 'CARDON', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CARIPITO', 'CARIPITO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CARLTON', 'CARLTON GT LAKES/N.N', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CARTHAG', 'CARTHAGE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CARUTHER', 'CARUTHERSVILLE, MO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CARVILL', 'CARVILLE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CASABLAN', 'CASABLANCA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CASTELLO', 'CASTELLON', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CAYMAN', 'CAYMAN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CAYO', 'CAYO ARCAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CENTERCG', 'CENTERVILLE COL GULF', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CENTERVI', 'CENTERVILLE TEXAS GAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CENTERVT', 'CENTERVILLE TRUNKLIN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CEYHAM1', 'BOTAS-CEYHAN 1', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CEYHAN2', 'BOTAS-CEYHAM 2', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CEYLON', 'CEYLON  PETROLEUM  REF', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CFLORIDA', 'CENTRAL FLORIDA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CGT-POO', 'CENTRAN POOL, KY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CGT/RAY', 'RAYNE, LA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CGTPOOL', 'CGT POOL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHALMET', 'CHALMETTE, LA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHIBA', 'CHIBA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHICAGO', 'CHICAGO', 'N', 'Y', 'Y', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHICAGO1', 'CHICAGO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHICCITY', 'CHICAGO/CITYGATE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHILIE', 'CHILIE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHINA', 'CHINA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHINESE', 'CHINESE PORT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHIPAWA', 'CHIPAWA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHIRK,U', 'CHIRK,UK', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHITA', 'CHITA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHITTAGO', 'CHITTAGONG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHOCBAHO', 'CHOC BAYOU MANVIL/CH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHOCBATR', 'CHOC BAYOU MANVL/CHO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CHOCOLA', 'CHOCOLATE BAYOU', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CIERNA', 'CIERNA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CIF', 'CIF CHINA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CIFBORDX', 'CIF BORDEAUX', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CIFLEITH', 'CIF LEITH', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CIG', 'MAINLINE STOR', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CIG OPAL', 'CIG OPAL KING', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CIG PARA', 'CIG PARACHUTE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CILICAP', 'CILICAP', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CINCINNA', 'CINCINNATI, OH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CINERGY', 'CINERGY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CINTA', 'CINTA JAVA SEA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CITSERTR', 'CITIES SERVICE-TRNKL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CITYGATE', 'CITYGATE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CIVITAV', 'CIVITAVECCIA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CLARENCI', 'CLARENCIA GREGORIO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CLEVELA', 'CLEVELAND', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CLIFTON', 'CLIFTON PIER, BAHAMAS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CNG', 'STA 65 POOL(MOBIL)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CNGPOOL', 'CNG POOL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COATZACO', 'COATZACOLCOS, MEXICO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COCHIN', 'COCHIN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COL/ALGO', 'COLUMBIA GAS/ALGON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COLLINS', 'COLLINS, MS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COLOMBIA', 'COLOMBIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COLOMBO', 'COLOMBA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COLONIA', 'BOURNE, MA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COLUMBI', 'COLUMBIA GULF ONSHORE, LA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COLUMBIA', 'COLUMBIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COLUMBU', 'COLUMBUS, OHIO', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COMEX', 'COMEX WHSE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COMODORO', 'COMODORO RIVADAVIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CONED', 'CONED', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CONNECT', 'CONNECTICUT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CONSTANT', 'CONSTANTZA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CONSUME', 'CONSUMERS EDA(TCPL/UNION)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CONSUME1', 'CONSUMERS (MI) GATE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CONVENT', 'CONVENT, LA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COOLKEER', 'COOLKEERAGH', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CORMAN', 'CORMAN RR SITE,KENTUCKY,USA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CORP', 'CORPORATION  ORGUDAWATTE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CORPUS', 'CORPUS  CHRSITI  TX', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CORPUS1', 'CORPUS CHRISTI', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CORYTON', 'CORYTON', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COSTARIC', 'COSTA RICA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COURTAU', 'COURTAULDS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('COVENAS', 'COVENAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CPL/VEP', 'CPL/VEPCO INTERCONNECT', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CRAU', 'CRAU  TERMINAL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CURACAO', 'CURACAO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CUSHING', 'CUSHING, OKLAHOMA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CYPRESS', 'CYPRESS-SABINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CYPRESS-', 'CYPRESS-SABINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CYPRESS1', 'CYPRESS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('CZECH', 'CZECH REPUBLIC', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('Couronne', 'Petit Couronne', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DAESAN', 'DAESAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DAKAR', 'DAKAR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DAR', 'DAR ES SALAM', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DAS', 'DAS ISLAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DAWNKOCH', 'DAWN STORAGE-UNION', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DEASAN', 'DEASAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DEER', 'DEER PARK, TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DELAWARE', 'DELAWARE  CITY  DE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DENMARK', 'DENMARK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DERINCE', 'DERINCE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DETROIMI', 'DETROIT, MI', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DJENO', 'DJENO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DJIBOUT', 'DJIBOUTI & BERBERA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DLBAWIPL', 'DLVD BAXTER WILSON PLANT', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DLVD', 'DLVD TEXAS INTRASTATE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DLVD1', 'DLVD TCO', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DLVDACAD', 'DLVD ACADIAN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DLVDNOPS', 'DLVD NOPSI', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DLVDOLYM', 'DLVD OLYMPIC', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DLVDWATE', 'DLVD WATERFORD', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DLVNINMI', 'DLVD NINE MILE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DOCK/WH', 'DOCK/WHSE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DOM', 'DOM REPUBLIC', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DONGES', 'DONGES', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DOS', 'DOS BOCAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DUBAI', 'DUBAI', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DUBLIN', 'DUBLIN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DUCTERM', 'DUC TERMINAL', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DUMAI', 'DUMAI, INDONESIA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DUMASNN', 'DUMAS  ELPS/NO. NATR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DUNKERQU', 'DUNKERQUE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DUNKIRK', 'DUNKIRK', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DURBAN', 'DURBAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('DUTCH', 'DUTCH MILLS, ROTTERDAM', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('E.AURORA', 'EAST AURORA,NY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EAGLE', 'EAGLE POINT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EAGLE1', 'EAGLE POINT,N.J.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EAST', 'EAST ZEIT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EAST1', 'EAST AURORA, NY (NATFUEL/TGP)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EAST2', 'EAST COAST, USA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EASTLVRP', 'EAST LIVERPOOL, OHIO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EEC', 'EEC OR BRAZIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EEC,', 'EEC, EUROPE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EGYPT', 'EGYPT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EILAT', 'EILAT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EIMSHAV', 'EIMSHAVEN, HOLLAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ELEFSIS', 'ELEFSIS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ELIZABNJ', 'ELIZABETH, NJ', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ELPASO', 'EL PASO, TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ELSALVAD', 'EL SALVADOR', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EMPIRE', 'EMPIRE CITYGATE-NY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EMPIRE-', 'ROYALTON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EMPIRE-1', 'PHOENIX 63', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EMPIRE-2', 'EMPIRE-NY CHIPPAWA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EMPIRE-3', 'EMPIRE-NY MENDON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EMPRESS', 'EMPRESS STATION (TCPL/NOVA)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EMPRESSN', 'EMPRESS-NOVA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ENGLAND', 'ENGLAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ENTERGY', 'ENTERGY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EPNG', 'EPNG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ERATH', 'ERATH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ERATHCOL', 'ERATH-COL.GULF', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ERATHKOC', 'ERATH-KOCH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ERATHLRC', 'ERATH-LRC', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ERATHNGP', 'ERATH-NGPL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ERATHSAB', 'ERATH (SABINE/SEA ROBIN)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ERATHSEA', 'ERATH (SEA/COLGULF)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ERATHSON', 'ERATH-SONAT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ERATTERM', 'ERATH/TERMINUS', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ERAWAN', 'ERAWAN GASFIELD', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ERG', 'ERG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ES', 'ES SIDER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ESCRAVOS', 'ESCRAVOS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ESMERALD', 'ESMERALDAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ESSIDER', 'ESSIDER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ESSO', 'ESSO TERMINAL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ESSOPAC', 'ESSO  PAC', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ESSOTERM', 'ESSO  TERMINAL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EUROPAK', 'EUROPAK', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EUROPEA', 'EUROPEAN PORTS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EVANSVI', 'EVANSVILLE, INDIANA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EX-WARE', 'EX-WAREHOUSE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EXCLVOTT', 'EXCLUDING VOTT', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('EXXKATTA', 'EXXON KATY TAILGATE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('Everglad', 'Port Everglades', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FALCONA', 'FALCONARA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FALL', 'FALL RIVER, MA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FALL1', 'WESTPORT, MA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FALMOUTH', 'FALMOUTH', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FATEH', 'FATEH', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FAWLEY', 'FAWLEY', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FAYNE,', 'FAYNE, OHIO', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FELEY', 'FELEY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FELIXST', 'FELIXSTOWE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FENYESLI', 'FENYESLITKE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FEODOSI', 'FEODOSIYA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FERROL', 'FERROL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FIFE OFF', 'FIFE OFFSHORE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FIFEOFFS', 'FIFE OFFSHORE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FINA', 'FINA REFINERY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FINLAND', 'FINLAND BORDER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FINNART', 'FINNART', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FIPPEMB', 'FIP PEMBROKE', 'N', 'N', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FLOMAR', 'FLOMAR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FLOOPLAN', 'FLOODWAY PLANT', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FLORIDA', 'FLA. GAS TRANS ZONE2', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FLORKAPL', 'FLORIDA/KAPLAN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FLOTTA', 'FLOTTA TERMINAL', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FLUSHIN', 'FLUSHING', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FNDTRNSF', 'FUNDS TRANSFER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FORCADOS', 'FORCADOS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FORTUNE', 'FORTUNE LAKE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FOS', 'FOS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FOURCORN', 'FOUR CORNERS WEST HYNES STATION', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FPSO', 'FPSO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FRANCE', 'FRANCE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FREDERIC', 'FREDERICIA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FREEPORT', 'FREEPORT, TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FUIMICIN', 'FUIMICINO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FUJAIRA', 'FUJAIRAH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('FUSINA', 'FUSINA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('Fateh', 'Fateh', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GABON', 'GABON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GAEVLE,', 'GAEVLE, SWEDEN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GALENA', 'GALENA PK, TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GALEOTA', 'GALEOTA  POINT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GALVESTO', 'GALVESTON', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GAMBA', 'GAMBA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GARRYVIL', 'GARRYVILLE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GARYVILL', 'GARYVILLE LA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GATX,', 'GATX, CARTERET, NJ', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GATX/PH', 'GATX/PHILADELPHIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GBGPK371', 'GOTHENBURG PAKTANK TANK 371', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GDANSK', 'GDANSK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GDANSTET', 'GDANSK/STETTIN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GDYNIA', 'GDYNIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GEBZE', 'GEBZE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GEDANSK', 'GEDANSK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GEISMAR', 'GEISMAR, LA.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GEISUM', 'GEISUM', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GELA', 'GELA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GELSENK', 'GELSENKIRCHEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GENOA', 'GENOA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GEORGETN', 'GEORGETOWN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GERMANY', 'GERMANY', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GERONA,', 'GERONA, SPAIN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GIBRALT', 'GIBRALTAR', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GONFREVI', 'GONFREVILLE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GOODHOP', 'GOODHOPE, LA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GOTHENB', 'GOTHENBURG, SWEDEN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GOTHNBRG', 'GOTHENBURG', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GRANGEM', 'GRANGEMOUTH', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GRANITE', 'GRANITE CITY, ILL.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GRAVENC', 'GRAVENCHON', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GREECE', 'GREECE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GREENBO', 'GREENSBORO, NC', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GREENFO', 'GREENFORD', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GREENFO1', 'GREENFORD', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GRIM', 'GRIM', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GRIMSBY', 'GRIMSBY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GUANGZH', 'GUANGZHOU', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GUATEMA', 'GUATEMALA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GUATEMAL', 'GUATEMALA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GUAYAMA', 'GUAYAMA, PUERTO RICO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GUAYANIL', 'GUAYANILLA, PUERTO RICO', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GULFHAVN', 'GULFHAVN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GULFHOU', 'GULFHOUSTON, TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GUMOWICE', 'GUMOWICE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('GUYAQUI', 'GUYAQUIL, ECUADOR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('Green', 'Greenville', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('H', 'T - HOUSTON', 'N', 'N', 'Y', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HAIFA', 'HAIFA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HALDIA', 'HALDIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HALIFAX', 'HALIFAX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HALUL', 'HALIL ISLAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HAMBURG', 'HAMBURG', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HAMINA', 'HAMINA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HAR', 'H - HARRISON', 'N', 'N', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HART', 'HARTFORD  IL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HARVEY', 'HARVEY & PETROUNITED SUNSHINE L.A.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HARVEY,', 'HARVEY,LOUISSIANA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HARVEY/', 'HARVEY/NEW ORLEANS RANGE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HEBERT', 'HEBERT, TX', 'N', 'Y', 'Y', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HELSINK', 'HELSINKI', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HENRYHUB', 'HENRY HUB(IN)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HHALGONQ', 'HENRY HUB ALGONQUIN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HHCLO.GU', 'HENRY HUB COL. GULF', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HHDOW', 'HENRY HUB DOW INTER.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HHLRC', 'HENRY HUB LRC', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HHNGPL', 'HENRY HUB-NGPL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HHSONAT', 'HENRY HUB-SONAT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HHTEXASG', 'HENRY HUB TEXAS GAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HHTRANSC', 'HENRY HUB-TRANSCO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HHTRNKLN', 'HENRY HUB TRUNKLINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HHUBOUT', 'HENRY HUB (OUT)', 'N', 'Y', 'Y', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HK', 'HONG KONG', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HO', 'HO CHI MINH, VIETNAM', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HODDEID', 'HODDEIDAH, YEMEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOLLAND', 'HOLLAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOLLAND/', 'HOLLAND/GERMANY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOLLYBE', 'HOLLYBEACH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOLLYLRC', 'HOLLY BEACH LRC', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOLLYNGP', 'HOLLY BEACH  /NGPL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOLLYSTI', 'HOLLY BEACH STINGRAY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOLYROOD', 'HOLYROOD', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HONGKONG', 'HONG KONG', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOUCORCH', 'HOUSTON/CORPUS CHRISTI', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOUNDS', 'HOUNDS  POINT', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOUST/TC', 'HOUSTON/TEXAS CITY', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOUSTON', 'HOUSTON, TEXAS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOUSTON1', 'HOUSTON/TEXAS CITY/PORT ARTHUR', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOUSTON2', 'HOUSTON/TEXAS CITY/FREEPORT', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOUSTON3', 'HOUSTON/TEXAS CITY/PORT ARTHUR/ CORPUS C', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOUSTON4', 'HOUSTON/TEXAS CITY/CORPUS CHRISTI', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOUSTON5', 'HOUSTON/BEAUMONT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOUSTON6', 'HOUSTON/TEXAS CITY/BEAUMONT', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HOUSTON7', 'HOUSTON/PLAQUEMINE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HPCL', 'HPCL BOMBAY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HUANGPU', 'HUANGPU, CHINA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HUELVA', 'HUELVA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HUIZHOU', 'HUIZHOU', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HULL', 'HULL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HUNGARY', 'HUNGARY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('HUNTERS', 'HUNTERSTON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('IJMUIDE', 'IJMUIDEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ILITCHE', 'ILITCHEVSK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ILLINOI', 'WEST JOLIET, IL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('IMMINGHA', 'IMMINGHAM', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('IMTT,ST', 'IMTT,ST ROSE. L.A.', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('IMTT/NE', 'IMTT/NEW YORK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('INCHON', 'INCHON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('INDIA', 'INDIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('INDIANA', 'INDIANA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('INDONESI', 'INDONESIA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('IPLOM', 'IPLOM', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('IRAN', 'IRAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('IRELAND', 'IRELAND', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('IROQUOI', 'IROQUOIS-ZN 2', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('IROQUOI1', 'IROQUOIS-ZN 1', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ISKENDRU', 'ISKENDRUN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ISRAEL', 'ISRAEL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ISTANBU', 'ISTANBUL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ITALY', 'ITALY', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('IVORY', 'IVORY COAST', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('IZMIT', 'IZMIT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('Italy', 'Venice', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JABIRU', 'JABIRU', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JACKSNCG', 'JACKSON CITY GATE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JACKSON', 'JACKSONVILLE, FL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JAKARTA', 'JAKARTA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JAMAICA', 'JAMAICA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JAPAN', 'JAPAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JEBEL', 'JEBEL  ALI', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JEBELDHA', 'JEBEL DHANNA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JEDDAH,', 'JEDDAH, SAUDI ARABIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JEFFERS', 'JEFFERSONVILLE, IND.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JIANG', 'JIANG YIN, CHINA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JINSHAN', 'JINSHAN WEI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JOSE,', 'JOSE, VENEZUELA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('JUAYMAH', 'JUAYMAH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KAKAP', 'KAKAP', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KALINING', 'KALININGRAD', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KALUNDBO', 'KALUNDBORG', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KAMPALA', 'KAMPALA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KANDLA', 'KANDLA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KAOHSIUN', 'KAOHSIUNG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KARLSHA', 'KARLSHAMN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KARLSHM', 'KARLSHAMN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KARLSHM1', 'KARLSHAMN STS CAVERN 1', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KARLSTA', 'KARLSTAD, SWEDEN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KAS', 'KASIM', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KATY-PL', 'OASIS KATY, TX', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KATY-WE', 'KATY-WESTERN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KATYDOW', 'KATY-DOW', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KATYENSR', 'KATY ENSEARCH KATY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KATYLONE', 'KATY-LONE STAR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KATYTGPL', 'KATY-TENNESSEE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KATYTRSC', 'KATY  -EXXON/SUN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KAWASAK', 'KAWASAKI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KAZAKHS', 'KAZAKHSTAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KEELUNG', 'KEELUNG/HONGKONG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KEIHIN', 'KEIHIN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KENTUCK', 'KENTUCKY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KETTON', 'KETTON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KHARG', 'KHARG ISLAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KIIRE', 'KIIRE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KILLING', 'KILLINGHOLME', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KINDER', 'KINDER  TENN/TRUNMLN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KING', 'KING FAHD YANBU', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KLAIPED', 'KLAIPEDA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KOBE', 'KOBE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KOBE/YO', 'KOBE/YOKOHAMA ANCHORAGE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KOCH', 'KOCH GATEWAY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KOLE', 'KOLE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KOPER', 'KOPER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KOREA', 'KOREA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KOTKA', 'KOTKA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KRALENDI', 'KRALENDIJK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KRONSTAD', 'KRONSTADT', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KROTZSPR', 'KROTZ SPRINGS, LA', 'N', 'Y', 'Y', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KUALABEU', 'KAULA BEUKAH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KUANTAN', 'KUANTAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KUMUL', 'KUMUL MARINE TERMINAL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KUWAIT', 'KUWAIT  PETROLEUM  EURO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KWANGYAN', 'KWANGYANG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('KWANTAN', 'KWANTAN, MALAYSIA', 'N', 'Y', 'Y', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LA', 'LA KAISER TERMINAL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LA1', 'LA HAVRE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LACORUNA', 'LA CORUNA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LAEM', 'LAEM  CHABANG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LAGOS', 'LAGOS NIGERIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LAGUAIR', 'LAGUAIRA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LAKE', 'LAKE CHARLES', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LALANG', 'LALANG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LAREDO,', 'LAREDO, TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LARNE', 'LARNE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LAS', 'LAS MINAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LAS1', 'LAS PALMAS, SPAIN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LASALINA', 'LA SALINA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LASPEZIA', 'LA SPEZIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LAVAN', 'LAVAN ISLAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LAVERA', 'LAVERA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LAVRION', 'LAVRION', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LAZARO', 'LAZARO CARDENAS, MEX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LE', 'LE HAVRE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LEBANON', 'LEBANON, OH (TGT/CGAS)', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LEIDY', 'LEIDY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LEIDYCNG', 'LEIDY TX EASRERN/CNG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LEIDYNF', 'LEIDY     POTTER PA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LEIDYTR', 'LEIDY TRANSCO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LEITH', 'LEITH', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LEIXOES', 'LEIXOES', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LENDAVA', 'LENDAVA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LIBECENT', 'LIBERTY CENTER', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LIMASSO', 'LIMASSOL CYPRUS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LIMAY', 'LIMAY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LIMBE', 'LIMBE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LIMERICK', 'LIMERICK', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LIMETREE', 'LIMETREE BAY ST CROIX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LIMON', 'LIMON', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LINDEN', 'LINDEN,  NJ', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LISBOA', 'LISBOA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LISBON', 'LISBON', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LITTLEBR', 'LITTLEBROOK', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LIV&GEN', 'LIVORNO & GENOA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LIVERPOO', 'LIVERPOOL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LIVORNO', 'LIVORNO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LOMBO', 'LOMBO TERMINAL', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LONDON', 'LONDON', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LONG', 'LONG ISLAND,NEW YORK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LOOP', 'LOOP', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LOS', 'LOS  ANGELES CA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LOS1', 'LOS ANGELES, CA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LOUISIA', 'LOUISIANIA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LOUISVI', 'LOUISVILLE, KY.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LRC', 'ERATH (SEA/LRC) - PARK PERDUE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('LUCINA', 'LUCINA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('Louisia', 'Marrero', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('M3', 'M3', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MAASVLAK', 'MAASVLAKTE  OLIE  TER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MAATSCHA', 'MAATSCHAP EUROPOORT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MACEIO,', 'MACEIO, BRAZIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MACEIO,1', 'MACEIO, ALAGOAS/BRAZIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MADRAS', 'MADRAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MAINE', 'MAINE NH BOARDER', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MAINLIN', 'MAINLINE Q', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MAINLIN1', 'MAINLINE NWPL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MAINLIN2', 'MAINLINE STOR W/D', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MAINLINA', 'MAINLINE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MAINLINE', 'MAINLINE NWPL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MAINORSY', 'MAINLINE/NORTH SYSTEM', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MALAGA', 'MALAGA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MALASIA', 'MALASIA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MALAYSI', 'MALAYSIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MALMO', 'MALMO', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MALMO308', 'MALMO STS TANK 308', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MALMO313', 'MALMO STS TANK 313', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MALONGO', 'MALONGO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MALTA', 'MALTA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MAMMONAL', 'MAMMONAL', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MANATEE', 'MANATEE TERMINAL, PORT MANATEE, FL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MANCHEST', 'MANCHESTER TERMINAL', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MANCHUR', 'MANCHURIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MANDJI', 'MANDJI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MANGALOR', 'MANGALORE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MANILA', 'MANILA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MANILLA', 'MANILLA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MANZANI', 'MANZANILLO, MEXICO', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MARCUS', 'MARCUS  HOOK  PA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MARIFU', 'MARIFU', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MARIUPOL', 'MARIUPOL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MARSA', 'MARSA EL HARUGA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MARSABR', 'MARSA EL BREGA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MARSEIL', 'MARSEILLE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MARYLAN', 'MARYLAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MARYSVI', 'MARYSVILLE, OH', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MASILA', 'MASILA TERMINAL, YEMEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MATANZA', 'MATANZAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MAUREEN', 'MAUREEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MAZHEKAI', 'MAZHEKAI', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MBYA', 'MBAY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MED', 'MED', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MEIZHOUW', 'MEIZHOUWAN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MERAK', 'MERAK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MERSA', 'MERSA AL BREGA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MERSAAL', 'MERSAAL HARIGA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MERSIN', 'MERSIN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MESAQATA', 'MESAIEED,QATAR', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MEXICO', 'MEXICO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MIAMI', 'MIAMI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MICHCITY', 'MICHCON/CITYGATE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MICHCON', 'MICHCON', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MICHIGA', 'MICHIGAN CITYGATE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MICHNIP', 'MICHIGAN CITY NIPSCO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MICTGTPA', 'MI CITYGATE PANHANDEL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MICTGTTR', 'MI CITYGATE TRUNKLINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MID-COL', 'MID-COLUMBIA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MIDCOLS', 'MID-COLUMBIA''S', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MIDDLEB', 'MIDDLEBURG', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MIDLAND', 'MIDLAND TEXAS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MIDWEST', 'MIDWESTERN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MILAZZO', 'MILAZZO', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MILFORD', 'MILFORD HAVEN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MINA', 'MINA ABDULLAH', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MINA1', 'MINA AL FAHAL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MINAAL', 'MINA AL AHMADI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MINASAUD', 'MINA  SAUD', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MINE', 'MINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MINNESO', 'MINNESOTA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MISSISS', 'MISSISSAUGA, ONTARIO', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MIZUSHI', 'MIZUSHIMA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MJP', 'MJP', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MNDVILLE', 'MOUNDVILLE,AL', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOBIL', 'MOBIL JURONG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOBILCOL', 'MOBIL COL GULF', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOBILE', 'MOBILE  AL', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOBILGTW', 'MOBIL MARRYANN MBL/G', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOBILKOC', 'MOBIL MARYANN PLANT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOBILTNK', 'MOBIL (G.I.82)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOERDIJK', 'MOERDIJK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOHAMMED', 'MOHAMMEDIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOMBASA', 'MOMBASA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MONGSTAT', 'MONGSTAT  BERGEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MONT4TRN', 'MONTGOMERY 4 TRUNKLN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MONTBELV', 'MONT BELVIEU', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MONTEVI', 'MONTEVIDEO, URUGUAY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MONTREAL', 'MONTREAL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOPS', 'MOPS', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOROCCO', 'MOROCCO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOSCOW', 'MOSCOW', 'N', 'N', 'N', 5, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MOUDI', 'MOUDI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MT.', 'MT. BELVIEU', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MT.VERN', 'MT.VERNON, IND.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MUANDA', 'MUANDA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MULBERRY', 'MULBERRY, FLORIDA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('MYLAKI', 'MYLAKI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('N', 'N', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('N. BORDE', 'N. BORDER/NNG MATT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('N.BOARDE', 'N.BOARDER/NNG VENTURA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('N.BORDE', 'NBP/NNG VENTURA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('N.BORDE1', 'N.BORDER/NGPL HARPER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('N.E.B.P', 'N.E.B.P.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NAFTABAN', 'NAFTA B ANTWERP', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NANJING', 'NANJING', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NANTES,', 'NANTES, FRANCE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NANTONG', 'NANTONG,CHINA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NAPLES', 'NAPLES', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NATIONA', 'NATIONAL FUEL DISTRIBUTION', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NBORKEOK', 'N.BOARDER/NGPL KEOKU', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NC', 'Greenville', 'N', 'N', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEDERLAN', 'NEDERLAND', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEREFCO', 'NEREFCO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NETHER', 'NETHERLAND  TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NETHERLA', 'NETHERLANDS ANTILLES', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NETHRLA', 'NETHRLANDS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEW', 'WHITE PLAINS, NY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEW1', 'NEW ENGLAND CITYGATE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEW13', 'MTALOC', 'N', 'N', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEW2', 'NEW CASTLE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEW3', 'GULFPORT-LINDEN, NY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEW4', 'NEW MANGALORE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEW5', 'NEW HAMPSHIRE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEW6', 'NEW HAVEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEW7', 'NEW YORK/WILMINGTON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEW8', 'NEW YORK/PHILADELPHIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEWARK', 'NEWARK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEWJERSE', 'NEW JERSEY NATURAL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEWPORT', 'NEWPORT', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NEWYORNY', 'NEW YORK, NY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NFGDNYPO', 'NFGDC-NY POOL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NFGS', 'CONOCO-POOL, NY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NFGS/TE', 'NFGS/TECO @ BRISTORIA,PA.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NFGS1', 'IP POOL, PA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NFGS2', 'ROSE LAKE, PA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NGPL', 'NGPL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NGPL1', 'GOODRICH POLK, TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NGPL2', 'NGPL LA DLVD', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NIAGARA', 'NIAGARA, NY (TCPL/TRANSCO)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NIAGARAA', 'NIAGARA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NIAGARAT', 'NIAGARA, NY TRANSCO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NICARAG', 'NICARAGUA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NIGAS', 'NIGAS  JONES-DUPR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NIGERIA', 'NIGERIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NIGG BAY', 'NIGG BAY', 'N', 'Y', 'Y', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NIGGBAY', 'NIGG BAY', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NINGBO', 'NINGBO, CHINA', 'N', 'Y', 'Y', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NINGBO1', 'NINGBO CHINA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NIPSCO', 'NIPSCO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NIPSCONG', 'NIPSCO CITY GT JNS-D', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NIPSCOPE', 'NIPSCO-FT WAYNE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NIPSCOTK', 'NIPSCO BREMEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NIT', 'NIT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NOLA', 'NEW ORLEANS,  LA.', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NORCO', 'NORCO', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NORFOLK', 'NORFOLK, VA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NORNE', 'NORNE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NORRK', 'NORRKOPING', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NORTH', 'NORTH WEST EUROPE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NORTH1', 'NORTH LITTLE ROCK,ARK.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NORTHWE', 'NORTHWEST PIPELINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NORWAY', 'NORWAY', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NOSL9921', 'NOPSI SLN 9921', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NOVANIT-', 'NOVA NIT-NOVA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NOVOROSS', 'NOVOROSSISK', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('NYHARBOR', 'NEW YORK HARBOR', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OAKLAND', 'OAKLAND', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OAKVILL', 'OAKVILLE, ONTARIO - CANADA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ODESSA', 'ODESSA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ODUDTERM', 'ODUDU TERMINAL', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OFFSHOR', 'OFFSHORE LOUISIANA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OFFSHORE', 'OFF  SHORE  TRIPOLI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OGUENDJO', 'OGUENDJO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OHIO', 'OHIO VALLEY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OHIO1', 'OHIO', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OHITA', 'OHITA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OJIBWAY', 'OJIBWAY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OLYMPIC', 'OLYMPIC', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OMISALJ', 'OMISALJ', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OMNIBUS', 'OMNIBUS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ONSAN', 'ONSAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OPAL', 'OPAL PLANT WY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OPALNWPL', 'OPAL PLANT TAILGATE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OPENWRLD', 'OPEN WORLD', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OSLO,', 'OSLO, NORWAY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OXELSND3', 'OXELOSUND STS TANK 3', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OXSUND', 'OXELOSUND', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OXYCAMAN', 'OXY CAMERON-ANR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OXYCAMCG', 'OXY CAMERON MEADOWS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OXYCAMLR', 'OXY CAMERON LRC', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OXYCAMNG', 'OXY CAMRON MDW TAILG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OXYCAMST', 'OXY CAMERON STINGRAY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('OXYUTOS', 'OXY PLANT INLET UTOS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PAJARITO', 'PAJARITOS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PAKHI', 'PAKHI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PAKISTAN', 'PAKISTAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PAKTANK', 'PAKTANK  NETHERLAND', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PAKTBOTL', 'PAKTANK BOTLEK', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PAKTROTT', 'PAKTANK ROTTERDAM', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PALANKA', 'PALANKA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PALOVERD', 'PALO VERDE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PAMPILLA', 'PAMPILLA, PERU', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PANHAND', 'PANHANDLE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PAPHAITI', 'PORT AU PRINCE, HAITI', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PARANAG', 'PARANAGUA, BRAZIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PARKWAY', 'PARKWAY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PARKWAYU', 'PARKWAY STORAGE-UNION', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PASADENA', 'PASADENA, TX', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PASCAGO', 'PASCAGOULA, MISS.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PATANRCG', 'PATTERSON, LA (ANR/CGULF)', 'N', 'Y', 'Y', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PATANRTG', 'PATTERSON, LA (ANR/TGT)', 'N', 'Y', 'Y', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PAUILLAC', 'PAUILLAC', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PAULSBO', 'PAULSBORO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PAUPITRE', 'PORT AU PITRE, MARTINIQUE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PDVSA', 'PDVSA FACILITIES', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PEAVEY', 'PEAVEY TERMINAL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PEMBROKE', 'PEMBROKE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PENNINGT', 'PENNINGTON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PENNSYL', 'PENNSYLVANIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PENNYORK', 'PENN YORK STORAGE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PEPCO/P', 'PEPCO/PJM-BRIGHTON', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PERMIAN', 'PERMIAN POOL, TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PERTHAMB', 'PERTH  AMBOY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PERU', 'PERU', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PETAL', 'PETAL STORAGE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PETROCI', 'PETROCI  TERMINAL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PHILADE', 'PHILADELPHIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PHILIPP', 'PHILIPPINES', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PHILNYNK', 'PHILA/NY/NORFOLK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PHLADEL', 'PHLADELPHIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PIACAQU', 'PIACAQUERA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PITTSBRG', 'PITTSBURG', 'N', 'N', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PJM', 'PJM 500KV', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PLANTAT', 'PLANTATION PIPELINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PLAQUEM', 'PLAQUEMINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('POINT', 'POINT TUPPER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('POINT1', 'POINT COMFORT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('POINTE', 'POINTE A PIERRE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('POL', 'POL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('POLISH', 'POLISH BORDER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORT', 'PORT STANVAC', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORT AU', 'PORT AU PITRE, MARTINIQUE', 'N', 'Y', 'Y', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORT1', 'PORT DICKSON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORT2', 'PORT R', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORT3', 'PORT  READING NJ', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORT4', 'PORT READING NJ', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORT5', 'PORT OF BRAZIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORT6', 'PORT ELIZABET', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORT7', 'PORT ELIZABETH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORTARTH', 'PORT ARTHUR, TX', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORTLAN', 'PORTLAND JONES-DUPRB', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORTLAN1', 'PORTLAND,  OR', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORTLAND', 'PORTLAND  TENN/MIDW.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORTNECH', 'PORT  NECHES  TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORTO', 'PORTO MARGHERA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORTO1', 'PORTO ALEGRE, BRAZIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORTO2', 'PORTO TORRES', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PORTUGAL', 'PORTUGAL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('POZOSCOL', 'POZOS, COLORADO', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PRAIA', 'PRAIA MOLE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PRESIDI', 'PRESIDIO, TX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PRINOS', 'PRINOS  OFFSHORE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PRIOLO', 'PRIOLO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PROVIDE', 'PROVIDENCE GAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PT. BAR', 'PT. BARRIOS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PT. BARR', 'PT. BARROIS', 'N', 'Y', 'Y', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PT.COR', 'PT. CORTEZ', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PTJEROME', 'PORT JEROME', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PTT', 'PTT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PUERRICO', 'PUERTO RICO', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PUERTO', 'PUERTO  LA  CRUZ', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PUERTO1', 'PUERTO ROSALES', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PUERTOMI', 'PUERTO  MIRANDA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PUERTOOR', 'PUERTO  ORDAZ', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PUNTA', 'PUNTA  DE  PALMA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PUNTA1', 'PUNTA CARDON', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('Peru', 'Peru', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('PkTnkSwd', 'Paktank,Gothenburg,Sweden', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('QUA', 'QUA IBOE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('QUESTAR', 'QUESTAR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('QUINTERO', 'QUINTERO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RABON', 'RABON GRANDE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RAIL', 'RAIL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RAS', 'RAS  ISA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RASALKHA', 'RAS AL KHAFJI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RASG', 'RAS  GHARIB', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RASLAN', 'RAS LANAFF', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RASLANUF', 'RAS LANUF', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RASSHUK', 'RAS SHUKHEIR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RASTANUR', 'RAS TANURA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RAUMA', 'RAUMA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RAVENNA', 'RAVENNA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RAYONG', 'RAYONG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RBCT', 'RBCT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RECIFE', 'RECIFE OR CABEDELLO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RECIFE,', 'RECIFE, BRAZIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RECIFE1', 'RECIFE OR MACEIO,BRAZIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('REFUGIOT', 'REFUGIO TRANSCO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RENI', 'RENI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RICHARD', 'RICHARDSBAY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RICHMON', 'RICHMOND, VA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RICHMOND', 'RICHMOND  CA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RIGA', 'RIGA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RIJEKA', 'RIJEKA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RIO', 'RIO GRANDE, BRAZIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RIO1', 'RIO DE JANEIRO, BRAZIL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RIOGRAND', 'RIO GRANDE BRAZIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RIORSECA', 'RICHMOND OR SELBY, CA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RIVERHE', 'RIVERHEAD,LI', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ROCKY', 'ROCKY MOUNTAINS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ROMANIA', 'ROMANIA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ROMEGA', 'ROME, GA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ROSARIO', 'ROSARIO, ARGENTINA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ROT+E-V', 'ROTT +E -V', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ROTT+E+P', 'ROTT +E +P', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ROTT+E+V', 'ROTT +E +V', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ROTTERDA', 'ROTTERDAM', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ROUEN', 'ROUEN, FRANCE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ROUSSE', 'ROUSSE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RTRFONLY', 'ROTT REF ONLY', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RUNNIOWA', 'RUNNELLS, IOWA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('RUSSIAN', 'RUSSIAN/BALTIC BORDER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('S AFRICA', 'SOUTH AFRICA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SABINE', 'SABINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SABINIHT', 'SABINE/IHT', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SAINT', 'SAINT JOHN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SAINT1', 'SAINT JOHN, NEW BRUNSWICK', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SALINA', 'SALINA CRUZ', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SALONIC', 'SALONICA, GREECE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SALONICA', 'SALONICA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SAN', 'SAN FRANCISCO-L.A. RANGE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SAN1', 'SAN LORENZO, ARGENTINA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SAN2', 'SAN PEDRO', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SAN3', 'SAN  FRANCISCO CA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SAN4', 'SAN LEANDRO', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SANFRANS', 'SAN  FRANSISCO CA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SANJOSE', 'SAN JOSE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SANSALVA', 'SAN SALVADOR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SANTA', 'SANTA PANAGIA BA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SANTOS', 'SANTOS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SANTOS,', 'SANTOS, BRAZIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SANTOS/', 'SANTOS/VITORIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SANTOS/1', 'SANTOS/ALEMOA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SANTOS1', 'SANTOS OR PARANAGUA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SARNIA', 'SARNIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SARROCH', 'SARROCH', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SAUDABAY', 'SAUDANHA BAY', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SAUDI', 'SAUDI ARABIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SAVANNA', 'SAVANNAH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SAVANNAH', 'SAVANAH  SAV/ATL GAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SAVONA', 'SAVONA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SCOTLAND', 'SCOTLAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SEA', 'VERMILION, LA ERATH (SABINE/SEAROB)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SEALSAND', 'SEALSANDS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SEATTLE', 'SEATTLE-WA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SECAUCU', 'SECAUCUS, NJ', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SEN', 'SENIPAH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SEPETIB', 'SEPETIBA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SERIA', 'SERIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SERTAOZ', 'SERTAOZINHO SP', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SETE,', 'SETE, FRANCE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SETUBAL', 'SETUBAL', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SHANGHAI', 'SHANGHAI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SHANNON', 'SHANNON AIRPORT', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SHANTOU', 'SHANTOU', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SHELHAVN', 'SHELLHAVEN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SHELLGOT', 'SHELL  GOTENBERG', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SHELLNET', 'SHELL  NETHERLAND  REF', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SHELLPUL', 'SHELL  PULAU  BUKOM', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SHELLTGT', 'SHELL BAY PIGS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SHELLTRN', 'SHELL ISLD PASS TRNK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SHELMOER', 'SHELL MOERDIJK', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SHELTIRO', 'SHELTON A TENN/IROQU', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SHOREHA', 'SHOREHAM', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SIDI', 'SIDI KERIR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SIKKA', 'SIKKA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SINES', 'SINES', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SING', 'S - SINGAPORE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SINGAPOR', 'SINGAPORE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SIR', 'SIR FLOATING BUOY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SIRRI', 'SIRRI ISLAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SKIKDA', 'SKIKDA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SKIRRA', 'SKIRRA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SLAGENTA', 'SLAGENTAAGEN TOENSBERG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SLUISKI', 'SLUISKIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SNAM', 'SNAM', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SONAT', 'SONAT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SORRSTOR', 'SORRENTO STORAGE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SOUTAFRI', 'SOUTH AFRICA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SOUTH', 'SOUTH  SEA CHINA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SOUTH1', 'SOUTH RIDING PT.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SOUTH2', 'SOUTH OF SHANGHAI, CHINA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SOYO', 'SOYO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SPAIN', 'SPAIN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SPC', 'SPC', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SPEL', 'SPEL  TERMINAL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SRI', 'SRI LANKA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SRIRACHA', 'SRIRACHA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ST PETER', 'ST PETERSBURG', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ST.', 'ST. MONET, FRANCE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ST. CROI', 'ST. CROIX, U.S. VIRGIN ISLANDS', 'N', 'Y', 'Y', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ST. ROSE', 'ST. ROSE', 'N', 'Y', 'Y', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ST.CROIX', 'ST CROIX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ST.EUSTA', 'ST.EUSTATIUS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ST.JAMES', 'ST. JAMES LA.', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ST.PETE', 'ST.PETERSBERG,RUSSIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STANLOW', 'STANLOW', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STARAZA', 'STARAZAGORA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STATFJOR', 'STATFJORD', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STAVANGE', 'STAVANGER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STCLAI', 'ST. CLAIR', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STCLAIA', 'ST CLAIR', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STENSND8', 'STENUNGSUND STS TANK 8', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STENSND9', 'STENUNGSUND STS TANK 9', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STENSUND', 'STENUNGSUND', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STJAMES', 'ST  JAMES  LA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STJAMLA', 'ST. JAMES, LA.', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STOCKHO', 'STOCKHOLM', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STSKarls', 'STS,Karlshamn,Sweden', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STSMalmo', 'STS,Malmo,Sweden', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STSOxelo', 'STS,Oxelosund,Sweden', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STSstenu', 'STS,Stenungsund,Sweden', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('STURE', 'STURE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SULLOM', 'SULLOM VOE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SUMAS', 'SUMAS  W.COAST/N.W.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SUNSHIN', 'SUNSHINE, LA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SWANSEA', 'SWANSEA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SWEDEN', 'SWEDEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SWITZER', 'SWITZERLAND', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('SYRIA', 'SYRIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TABANGAO', 'TABANGAO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TAFT,', 'TAFT, LA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TAICHUNG', 'TAICHUNG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TAIWAN', 'TAIWAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TAKASAYO', 'TAKASAYO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TAKOLA', 'TAKOLA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TALARA', 'TALARA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TALLINN', 'TALLINN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TAMPA', 'TAMPA, FLA.', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TANGA', 'TANGA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TANJUNG', 'TANJUNG  SANTAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TAO', 'TAO YUAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TARANTO', 'TARANTO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TARBERT', 'TARBERT', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TARNOW', 'TARNOW', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TARRAGON', 'TARRAGONA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TARTOUS', 'TARTOUS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TASMANI', 'TASMANIA', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TCOPOOL', 'TCO POOL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TCPL', 'DAWN, ONTARIO,CANADA (UGAS/TCPL)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TCPL1', 'PARKWAY, ONTARIO, CANADA(TCPL/UGAS)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TCPL2', 'WADDINGTON, NY(IROQUOIS/TCPL)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TCPL3', 'TCPL @ UNION(ST.CLAIRE)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TCPL4', 'TCPL @ EMERSON', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TCPL5', 'TCPL @ GLGT/ ST. CLAIRE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TCPLWADD', 'TCPL@WADDINGTON(IROQ)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TCPUNIDA', 'TCPL/UNION/DAWN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TEESSIDE', 'TEESSIDE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TEMA', 'TEMA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TENERIFE', 'TENERIFE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TENN', 'TENN ZONE 1', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TENNPOOL', 'TENN POOL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TERBNCGL', 'TERREBONE   / LA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TERMINU', 'TERMINUS STINGRAY-HB', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TERNEUZE', 'TERNEUZEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TETCO', 'OAKFORD, PA (TETCO/CONGAS)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TETCO-C', 'TETCO-CITY GATE-M3', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TETCO-C1', 'TETCO-CITY GATE-BUG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TETCO-E', 'ELA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TETCO-E1', 'ETX', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TETCO-S', 'STX', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TETCO-W', 'WLA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TETCO1', 'M1 24'', OH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TETCO2', 'M2 24'', OH', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TETCOPO', 'TETCOPOOL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TETNEY', 'TETNEY', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TEXACOES', 'TEXACO  ESSO  MAATSCHAP', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TEXAS', 'TEXAS GAS ZONE SL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TEXAS1', 'TEXAS GAS ZONE 1', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TEXASCIT', 'TEXAS CITY, TX', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TGP', 'TGP', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TGPL', 'WRIGHT, NY(TGP/IROQUOIS)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TGPL-10', 'TGPL-100 LINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TGPL-50', 'TGPL-500 LINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TGPL-80', 'TGPL-800 LINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TGPL-HA', 'TGPL-HATIESBURG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TGPL1', 'STATION 87 POOL, SUMNER, TN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TGPL4', 'TGPL DELIVERED ZONE4', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TGPL5', 'TGPL DELIVERED ZONE5', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TGPL6', 'TGPL DELIVERED ZONE6', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TGT', 'TGT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TGTCNTRV', 'TEXAS GAS CENTERVILLE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('THAILAND', 'THAILAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('THAMES', 'THAMES', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('THEVENAR', 'THEVENARD ISLAND', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TIERRA', 'TIERRA DEL FUEGO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TILLBUR', 'TILLBURY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TNCOLUNI', 'TENN/COL. UMIONVILLE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TNNIAGRA', 'NIAGRA (TGP/TCPL)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TNWESTMN', 'TENN/UGPL WEST MONROE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TO', 'TO BE ADVISED', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TOGLIAT', 'TOGLIATTI', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TOKUYAMA', 'TOKUYAMA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TOKYO', 'TOKYO, JAPAN', 'N', 'Y', 'N', 4, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TOLEDO,', 'TOLEDO, OHIO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TOMAS', 'TOMAS DE CASTILLA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TORONTO', 'TORONTO,CN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TOTALREF', 'TOTAL  REFINERY', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRANMERE', 'TRANMERE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRANSCO', 'LEIDY, PA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRANSCO1', 'TRANSCO ZONE 1 POOL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRANSCO2', 'TRANSCOPOOL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRANSCO3', 'TRANSCO ZONE 3 POOL, STA 65 POOL (TEXCO)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRANSCO4', 'TRANSCO ZONE 4 HEIDELBURG', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRANSCO5', 'TRANSCO ZONE 5', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRANSCO6', 'TRANSCO ZONE 6', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRANSCO7', 'TRANSCOZONE 4', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRANSCOH', 'TRANSCO HENRY HUB', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRANSCOL', 'TRANSCO-LEIDY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRANSCOW', 'TRANSCO WELLHEAD', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRENTON', 'TRENTON, NJ', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRIESTE', 'TRIESTE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRINIDAD', 'TRINIDAD', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRNKLNTE', 'TRUNKLINE-TERREBONNE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRNSCO65', 'STA 65 POOL (NGCH)', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRUNKLI', 'TRUNKLINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRUNKLI1', 'TRUNKLINE-TERREBONNE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRUNKLI2', 'TRNKLN/PEPL @ TUSCOLA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRZOS365', 'TRANSCO ZONE 3/STATION 65', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TRZOS485', 'TRANSCO ZONE 4/STATION 85', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TUAPSE', 'TUAPSE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TUMACO', 'TUMACO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TUNISIA', 'TUNISIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TURKEY', 'TURKEY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TUXPAN', 'TUXPAN', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TUXPAN/', 'TUXPAN/CIUDAD MADERO, MEXICO', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('TUXPMEXI', 'TUXPAN,MEXICO', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UDANG', 'UDANG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UGPL/ER', 'ERATH', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UGPL/VE', 'UGPL/VENICE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UJUNG', 'UJUNG PANDANG INDONESIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UK', 'Isle of Grain', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UKRAINE', 'UKRAINE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ULSAN', 'ULSAN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UMM', 'UMM SAID', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UNION', 'UNION GAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UNITED', 'UNITED  KINGDOM', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UNIVERSA', 'UNIVERSAL REFINING', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UNKNOWN', 'UNKNOWN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UNRESTR', 'UNRESTRICTED', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('URAN', 'URAN TERMINAL ONGC', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('URUGUAI', 'URUGUAIANA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('USA', 'Vicksburg', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('USGULF', 'US GULF', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('UTOSTRNK', 'UTOS TERMINUS TRUNKL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('V', 'V', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VADINAR', 'VADINAR', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VADO', 'VADO LIGURE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VALENCI', 'VALENCIA, SPAIN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VANCOUV', 'VANCOUVER CANADA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VARNA', 'VARNA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VENEZU', 'VENEZUELA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VENICE', 'VENICE', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VENTSPI', 'VENTSPILS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VENTSPIC', 'VENTSPICS', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VENTURA', 'VENTURA N BORDR/ NT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VIETNAM', 'VIETNAM', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VIGO', 'VIGO', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VIRGINI', 'BULL RUN, VIRGINIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VISTA', 'VISTA', 'N', 'N', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VITORIA', 'VITORIA GAS', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VITORIA1', 'VITORIA, BRASIL', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VIZAG', 'VIZAG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VOTTGoth', 'VOTT,Gothenburg,Sweden', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('VUNGTAN', 'VUNGTAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WADDINGT', 'WADDINGTON', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WADI', 'WADI  FEIRAN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WATERSTN', 'WATERSTONE', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WEST', 'WEST SUMATERA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WEST1', 'WEST VIRGINIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WESTERN', 'WESTERNPORT', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WESTKATY', 'WESTERN KATY', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WHANGERA', 'WHANGERAI, NEW ZEALAND', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WHITEGAT', 'WHITEGATE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WILHEMS', 'WILHEMSHAVEN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WILLEMST', 'WILLEMSTAD', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WILMING', 'WILMINGTON OR PERTH AMBOY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WILMING1', 'WILMINGTON N.CAROLINA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WISMAR', 'WISMAR GERMANY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WITNELL', 'WITNELL BAY DAMPIER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('WMONROE', 'WEST MONROE KOCH/TEN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('YABUCO', 'YABUCOA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('YACUIBA', 'YACUIBA, BOLIVIA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('YALOVA', 'YALOVA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('YARIMCA', 'YARIMCA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('YEMEN', 'YEMEN', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('YEOSU', 'YEOSU', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('YOKKAIC', 'YOKKAICHI', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('YOKOHAM', 'YOKOHAMA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('YORK,UK', 'YORK,UK', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('YORKTOWN', 'YORKTOWN  VA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('YUZHNY', 'YUZHNY, UKRAINE', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('Yemen', 'Ras Isa', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ZADAR', 'ZADAR', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ZAFIRO', 'ZAFIRO WEST AFRICA', 'N', 'Y', 'N', 0, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ZAIRE', 'ZAIRE RIVER', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ZEIT', 'ZEIT  BAY', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ZHANGJIA', 'ZHANGJIAGN', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ZHANJIAN', 'ZHANJIANG', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ZHENHAI', 'ZHENHAI, CHINA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ZIRKU', 'ZIRKU  ISLAND', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ZONESL', 'ZONE SL', 'N', 'Y', 'N', 9, 'N', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('ZUEITINA', 'ZUEITINA', 'N', 'Y', 'N', 9, 'A', 1)
go

insert into dbo.location
    (loc_code, loc_name, office_loc_ind, del_loc_ind, inv_loc_ind, 
     loc_num, loc_status, trans_id) 
   values('humriv', 'Humber River', 'N', 'Y', 'N', 0, 'A', 1)
go

