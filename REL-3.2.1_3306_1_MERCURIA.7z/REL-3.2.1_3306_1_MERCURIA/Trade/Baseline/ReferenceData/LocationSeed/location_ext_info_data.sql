print 'Loading additional seed data into the location_ext_info table ...'
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AAHRUS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ABIDJAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ABU", NULL, NULL, NULL, "ZR", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ACADIAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ACAJUTL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ACCRA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ADAMOVO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AECO", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AECOA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AECOCFOO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AECONOVA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AEP/APS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AEP/VEP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AGHII", NULL, NULL, NULL, "TC", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AINSUK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AKABA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AL-BAKR", NULL, NULL, NULL, "TN", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ALBANY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ALGECIRA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ALGERIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ALGONQU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ALGONQU1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ALGONQU2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ALGONQU3", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ALGONQU4", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ALGONQU5", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ALGONQU6", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ALIAGA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ALLIANCE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AMBARLI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AMSROTAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AMSTERDA", NULL, NULL, NULL, "B", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AMSTROTT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AMUAY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ANG", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ANGOLA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ANR", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ANR-PAT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ANR-SE L", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ANRCUSTR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ANRLKAR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ANRSOHIO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ANTAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ANTWERP", NULL, NULL, NULL, "B", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("APS", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("APS/PJM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ARA", NULL, NULL, NULL, "B", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ARATU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ARDJUNA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ARGENTIN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ARGYLL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ARUBA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ARZANNAH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ARZEW", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ASH", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ASHKELO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ASHTART", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ASPROPYR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ASUNCIO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ATHENS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AUGHNISH", NULL, NULL, NULL, "IRL", NULL, 
"LIMERICK", "ASKEATON", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AUGUSTA", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AUGUSTAT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AUSTRAL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AUSTRALI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AVILES", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("AVNMOUTH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("Africa", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BACTON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BADAK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BAHAMAS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BAHIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BAHRAIN", NULL, NULL, NULL, "BRN", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BAJO", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BALAOEQ", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BALBOA", NULL, NULL, NULL, "PA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BALONGAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BALTIMO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BALTIMOR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BANBURY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BANDAR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BANDAR1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BANGCHAK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BANGKOK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BANIAS", NULL, NULL, NULL, "SYR", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BAR", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BARCELO", NULL, NULL, NULL, "E", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BARROWIL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BARRY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BARTONAL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BARTONTN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BATAM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BATANGAS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BATON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BATUMI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BAYONNE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BAYOVAR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BAYPORT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BAYTOWN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BEATRICE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BEAUMON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BEAUMON1", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BEAUMON2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BEIRUT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BEJAIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BELEM-M", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BELEM-P", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BELFAST", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BELGIAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BELGIUM", NULL, NULL, NULL, "B", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BELIDA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BELMONT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BELVEDE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BERGEN,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BERYL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BGE", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BILBAO", NULL, NULL, NULL, "E", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BIRMIN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BIZERTE", NULL, NULL, NULL, "TN", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BLANG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BOMBAY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BONNY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BONYTHON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BORDEAUX", NULL, NULL, NULL, "F", NULL, 
NULL, "BORDEAUX", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BOSTON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BOTLEK", NULL, NULL, NULL, "NL", NULL, 
NULL, "ROTTERDA", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BOTROP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BOURGAS", NULL, NULL, NULL, "BG", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BP", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BPBIENVL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BPREF", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BRASS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BRAZIL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BRCANTW", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BREMEN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BREST", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BRIDGEL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BROF", NULL, NULL, NULL, "S", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BROOKLNY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BROWNSV", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BRUNSBUT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BUDAPES", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BUDKOVCE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BUENAVE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BUENOS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BULGARI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BULLENBA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BUNYU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BURNABY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("BUSAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CA", NULL, NULL, NULL, "CO", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CABINDA", NULL, NULL, NULL, "ANG", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CALAIS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CALCUTA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CALETA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CALIFOR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CAMDEN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CAMDEN,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CAMDEN,1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CAMEROON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CAMMAC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CAMPANA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CANADA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CANAJO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CANAJOH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CANARY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CAP", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CAPETOWN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CAPTAIN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CARACASB", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CARDIFF", NULL, NULL, NULL, "UK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CARDON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CARIPITO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CARLTON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CARTHAG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CARUTHER", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CARVILL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CASABLAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CASTELLO", NULL, NULL, NULL, "E", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CAYMAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CAYO", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CENTERCG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CENTERVI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CENTERVT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CEYHAM1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CEYHAN2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CEYLON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CFLORIDA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CGT-POO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CGT/RAY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CGTPOOL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHALMET", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHIBA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHICAGO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHICAGO1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHICCITY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHILIE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHINA", NULL, NULL, NULL, "PRC", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHINESE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHIPAWA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHIRK,U", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHITA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHITTAGO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHOCBAHO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHOCBATR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CHOCOLA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CIERNA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CIF", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CIFBORDX", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CIFLEITH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CIG", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CIG OPAL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CIG PARA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CILICAP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CINCINNA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CINERGY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CINTA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CITSERTR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CITYGATE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CIVITAV", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CLARENCI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CLEVELA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CLIFTON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CNG", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CNGPOOL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COATZACO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COCHIN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COL/ALGO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COLLINS", NULL, NULL, NULL, "USA", "MS", 
NULL, "COLLINS", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COLOMBIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COLOMBO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COLONIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COLUMBI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COLUMBIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COLUMBU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COMEX", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COMODORO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CONED", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CONNECT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CONSTANT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CONSUME", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CONSUME1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CONVENT", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COOLKEER", NULL, NULL, NULL, "UK", NULL, 
"LONDONDE", "COOLKEER", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CORMAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CORP", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CORPUS", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CORPUS1", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CORYTON", NULL, NULL, NULL, "UK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COSTARIC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COURTAU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("COVENAS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CPL/VEP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CRAU", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CURACAO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CUSHING", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CYPRESS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CYPRESS-", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CYPRESS1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("CZECH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("Couronne", NULL, NULL, NULL, "F", NULL, 
NULL, "PETIT CO", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DAESAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DAKAR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DAR", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DAS", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DAWNKOCH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DEASAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DEER", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DELAWARE", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DENMARK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DERINCE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DETROIMI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DJENO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DJIBOUT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DLBAWIPL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DLVD", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DLVD1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DLVDACAD", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DLVDNOPS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DLVDOLYM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DLVDWATE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DLVNINMI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DOCK/WH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DOM", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DONGES", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DOS", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DUBAI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DUBLIN", NULL, NULL, NULL, "IRL", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DUCTERM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DUMAI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DUMASNN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DUNKERQU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DUNKIRK", NULL, NULL, NULL, "F", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DURBAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("DUTCH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("E.AURORA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EAGLE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EAGLE1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EAST", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EAST1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EAST2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EASTLVRP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EEC", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EEC,", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EGYPT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EILAT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EIMSHAV", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ELEFSIS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ELIZABNJ", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ELPASO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ELSALVAD", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EMPIRE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EMPIRE-", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EMPIRE-1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EMPIRE-2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EMPIRE-3", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EMPRESS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EMPRESSN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ENGLAND", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ENTERGY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EPNG", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ERATH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ERATHCOL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ERATHKOC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ERATHLRC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ERATHNGP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ERATHSAB", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ERATHSEA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ERATHSON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ERATTERM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ERAWAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ERG", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ES", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ESCRAVOS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ESMERALD", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ESSIDER", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ESSO", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ESSOPAC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ESSOTERM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EUROPAK", NULL, NULL, NULL, "NL", NULL, 
NULL, "ROTTERDA", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EUROPEA", NULL, NULL, NULL, "F", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EVANSVI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EX-WARE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EXCLVOTT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("EXXKATTA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("Everglad", NULL, NULL, NULL, "USA", "FL", 
"BROWARD", NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FALCONA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FALL", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FALL1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FALMOUTH", NULL, NULL, NULL, "UK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FATEH", NULL, NULL, NULL, "UAE", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FAWLEY", NULL, NULL, NULL, "UK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FAYNE,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FELEY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FELIXST", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FENYESLI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FEODOSI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FERROL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FIFEOFFS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FINA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FINLAND", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FINNART", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FIPPEMB", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FLOMAR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FLOOPLAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FLORIDA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FLORKAPL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FLOTTA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FLUSHIN", NULL, NULL, NULL, "B", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FNDTRNSF", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FORCADOS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FORTUNE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FOS", NULL, NULL, NULL, "F", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FOURCORN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FRANCE", NULL, NULL, NULL, "F", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FREDERIC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FREEPORT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FUIMICIN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FUJAIRA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("FUSINA", NULL, NULL, NULL, "I", NULL, 
NULL, "FUSINA", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("Fateh", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GABON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GAEVLE,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GALENA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GALEOTA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GALVESTO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GAMBA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GARRYVIL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GARYVILL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GATX,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GATX/PH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GBGPK371", NULL, NULL, NULL, "S", NULL, 
NULL, "GOTHENBU", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GDANSK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GDANSTET", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GDYNIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GEBZE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GEDANSK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GEISMAR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GEISUM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GELA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GELSENK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GENOA", NULL, NULL, NULL, "I", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GEORGETN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GERMANY", NULL, NULL, NULL, "BRD", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GERONA,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GIBRALT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GONFREVI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GOODHOP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GOTHENB", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GOTHNBRG", NULL, NULL, NULL, "S", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GRANGEM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GRANITE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GRAVENC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GREECE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GREENBO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GREENFO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GREENFO1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GRIM", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GRIMSBY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GUANGZH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GUATEMA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GUATEMAL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GUAYAMA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GUAYANIL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GULFHAVN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GULFHOU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GUMOWICE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("GUYAQUI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("Green", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("H", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HAIFA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HALDIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HALIFAX", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HALUL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HAMBURG", NULL, NULL, NULL, "BRD", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HAMINA", NULL, NULL, NULL, "SF", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HAR", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HART", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HARVEY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HARVEY,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HARVEY/", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HEBERT", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HELSINK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HENRYHUB", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HHALGONQ", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HHCLO.GU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HHDOW", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HHLRC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HHNGPL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HHSONAT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HHTEXASG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HHTRANSC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HHTRNKLN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HHUBOUT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HK", NULL, NULL, NULL, "HK", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HO", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HODDEID", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOLLAND", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOLLAND/", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOLLYBE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOLLYLRC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOLLYNGP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOLLYSTI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOLYROOD", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HONGKONG", NULL, NULL, NULL, "HK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOUCORCH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOUNDS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOUST/TC", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOUSTON", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOUSTON1", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOUSTON2", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOUSTON3", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOUSTON4", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOUSTON5", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOUSTON6", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HOUSTON7", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HPCL", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HUANGPU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HUELVA", NULL, NULL, NULL, "E", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HUIZHOU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HULL", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HUNGARY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("HUNTERS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("IJMUIDE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ILITCHE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ILLINOI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("IMMINGHA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "VESSEL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("IMTT,ST", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("IMTT/NE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("INCHON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("INDIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("INDIANA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("INDONESI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("IPLOM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("IRAN", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("IRELAND", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("IROQUOI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("IROQUOI1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ISKENDRU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ISRAEL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ISTANBU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ITALY", NULL, NULL, NULL, "I", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("IVORY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("IZMIT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("Italy", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JABIRU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JACKSNCG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JACKSON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JAKARTA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JAMAICA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JAPAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JEBEL", NULL, NULL, NULL, "UAE", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JEBELDHA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JEDDAH,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JEFFERS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JIANG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JINSHAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JOSE,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("JUAYMAH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KAKAP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KALINING", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KALUNDBO", NULL, NULL, NULL, "DK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KAMPALA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KANDLA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KAOHSIUN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KARLSHA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KARLSHM", NULL, NULL, NULL, "S", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KARLSHM1", NULL, NULL, NULL, "S", NULL, 
NULL, "KARLSHAM", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KARLSTA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KAS", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KATY-PL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KATY-WE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KATYDOW", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KATYENSR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KATYLONE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KATYTGPL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KATYTRSC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KAWASAK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KAZAKHS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KEELUNG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KEIHIN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KENTUCK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KETTON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KHARG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KIIRE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KILLING", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KINDER", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KING", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KLAIPED", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KOBE", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KOBE/YO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KOCH", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KOLE", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KOPER", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KOREA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KOTKA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KRALENDI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KRONSTAD", NULL, NULL, NULL, "S", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KROTZSPR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KUALABEU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KUANTAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KUMUL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KUWAIT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KWANGYAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("KWANTAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LA1", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LACORUNA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LAEM", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LAGOS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LAGUAIR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LAKE", NULL, NULL, NULL, "USA", NULL, NULL, 
NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LALANG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LAREDO,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LARNE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LAS", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LAS1", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LASALINA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LASPEZIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LAVAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LAVERA", NULL, NULL, NULL, "I", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LAVRION", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LAZARO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LE", NULL, NULL, NULL, "F", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LEBANON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LEIDY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LEIDYCNG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LEIDYNF", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LEIDYTR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LEITH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LEIXOES", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LENDAVA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LIBECENT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LIMASSO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LIMAY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LIMBE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LIMERICK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LIMETREE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LIMON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LINDEN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LISBOA", NULL, NULL, NULL, "P", NULL, 
NULL, "LISBON", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LISBON", NULL, NULL, NULL, "P", NULL, 
NULL, "LISBON", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LITTLEBR", NULL, NULL, NULL, "UK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LIV&GEN", NULL, NULL, NULL, "I", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LIVERPOO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LIVORNO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LOMBO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LONDON", NULL, NULL, NULL, "UK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LONG", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LOOP", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LOS", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LOS1", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LOUISIA", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LOUISVI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LRC", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("LUCINA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("Louisia", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("M3", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MAASVLAK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MAATSCHA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MACEIO,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MACEIO,1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MADRAS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MAINE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MAINLIN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MAINLIN1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MAINLIN2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MAINLINA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MAINLINE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MAINORSY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MALAGA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MALASIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MALAYSI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MALMO", NULL, NULL, NULL, "S", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MALMO308", NULL, NULL, NULL, "S", NULL, 
NULL, "MALMO", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MALMO313", NULL, NULL, NULL, "S", NULL, 
NULL, "MALMO", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MALONGO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MALTA", NULL, NULL, NULL, "M", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MAMMONAL", NULL, NULL, NULL, "CO", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MANATEE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MANCHEST", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MANCHUR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MANDJI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MANGALOR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MANILA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MANILLA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MANZANI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MARCUS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MARIFU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MARIUPOL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MARSA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MARSABR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MARSEIL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MARYLAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MARYSVI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MASILA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MATANZA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MAUREEN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MAZHEKAI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MBYA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MED", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MEIZHOUW", NULL, NULL, NULL, "PRC", NULL, 
"FUJIAN", "QUANZHOU", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MERAK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MERSA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MERSAAL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MERSIN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MESAQATA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MEXICO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MIAMI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MICHCITY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MICHCON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MICHIGA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MICHNIP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MICTGTPA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MICTGTTR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MID-COL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MIDCOLS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MIDDLEB", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MIDLAND", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MIDWEST", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MILAZZO", NULL, NULL, NULL, "I", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MILFORD", NULL, NULL, NULL, "UK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MINA", NULL, NULL, NULL, "KWT", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MINA1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MINAAL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MINASAUD", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MINE", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MINNESO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MISSISS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MIZUSHI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MJP", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MNDVILLE", NULL, NULL, NULL, "USA", "AL", 
NULL, "MOUNDVIL", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOBIL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOBILCOL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOBILE", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOBILGTW", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOBILKOC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOBILTNK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOERDIJK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOHAMMED", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOMBASA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MONGSTAT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MONT4TRN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MONTBELV", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MONTEVI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MONTREAL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOPS", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOROCCO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOSCOW", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MOUDI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MT.", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MT.VERN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MUANDA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MULBERRY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("MYLAKI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("N", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("N. BORDE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("N.BOARDE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("N.BORDE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("N.BORDE1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("N.E.B.P", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NAFTABAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NANJING", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NANTES,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NANTONG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NAPLES", NULL, NULL, NULL, "I", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NATIONA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NBORKEOK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NC", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEDERLAN", NULL, NULL, NULL, "NL", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEREFCO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NETHER", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NETHERLA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NETHRLA", NULL, NULL, NULL, "NL", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEW", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEW1", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEW13", NULL, NULL, NULL, "USA", "NY", 
"WESTCHES", "WHITE PL", "VESSELGO", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEW2", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEW3", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEW4", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEW5", NULL, NULL, NULL, "USA", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEW6", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEW7", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEW8", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEWARK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEWJERSE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEWPORT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NEWYORNY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NFGDNYPO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NFGS", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NFGS/TE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NFGS1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NFGS2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NGPL", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NGPL1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NGPL2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NIAGARA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NIAGARAA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NIAGARAT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NICARAG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NIGAS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NIGERIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NIGGBAY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NINGBO", NULL, NULL, NULL, "PRC", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NINGBO1", NULL, NULL, NULL, "PRC", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NIPSCO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NIPSCONG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NIPSCOPE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NIPSCOTK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NIT", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NOLA", NULL, NULL, NULL, "USA", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NORCO", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NORFOLK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NORNE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NORRK", NULL, NULL, NULL, "S", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NORTH", NULL, NULL, NULL, "NL", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NORTH1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NORTHWE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NORWAY", NULL, NULL, NULL, "N", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NOSL9921", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NOVANIT-", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NOVOROSS", NULL, NULL, NULL, "RUS", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("NYHARBOR", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OAKLAND", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OAKVILL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ODESSA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ODUDTERM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OFFSHOR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OFFSHORE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OGUENDJO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OHIO", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OHIO1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OHITA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OJIBWAY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OLYMPIC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OMISALJ", NULL, NULL, NULL, "S", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OMNIBUS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ONSAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OPAL", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OPALNWPL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OPENWRLD", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OSLO,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OXELSND3", NULL, NULL, NULL, "S", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OXSUND", NULL, NULL, NULL, "S", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OXYCAMAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OXYCAMCG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OXYCAMLR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OXYCAMNG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OXYCAMST", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("OXYUTOS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PAJARITO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PAKHI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PAKISTAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PAKTANK", NULL, NULL, NULL, "NL", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PAKTBOTL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PAKTROTT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PALANKA", NULL, NULL, NULL, "ANG", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PALOVERD", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PAMPILLA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PANHAND", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PAPHAITI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PARANAG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PARKWAY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PARKWAYU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PASADENA", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, "EPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PASCAGO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PATANRCG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PATANRTG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PAUILLAC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PAULSBO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PAUPITRE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PDVSA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PEAVEY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PEMBROKE", NULL, NULL, NULL, "UK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PENNINGT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PENNSYL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PENNYORK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PEPCO/P", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PERMIAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PERTHAMB", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PERU", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PETAL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PETROCI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PHILADE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PHILIPP", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PHILNYNK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PHLADEL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PIACAQU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PITTSBRG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PJM", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PLANTAT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PLAQUEM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("POINT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("POINT1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("POINTE", NULL, NULL, NULL, "TT", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("POL", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("POLISH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORT", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORT1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORT2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORT3", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORT4", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORT5", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORT6", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORT7", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORTARTH", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORTLAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORTLAN1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORTLAND", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORTNECH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORTO", NULL, NULL, NULL, "I", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORTO1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORTO2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PORTUGAL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("POZOSCOL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PRAIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PRESIDI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PRINOS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PRIOLO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PROVIDE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PT. BAR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PT.COR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PTJEROME", NULL, NULL, NULL, "F", NULL, 
NULL, "ROUEN", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PTT", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PUERRICO", NULL, NULL, NULL, "PRI", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PUERTO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PUERTO1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PUERTOMI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PUERTOOR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PUNTA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PUNTA1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("Peru", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("PkTnkSwd", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("QUA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("QUESTAR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("QUINTERO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RABON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RAIL", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RAS", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RASALKHA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RASG", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RASLAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RASLANUF", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RASSHUK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RASTANUR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RAUMA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RAVENNA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RAYONG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RBCT", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RECIFE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RECIFE,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RECIFE1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("REFUGIOT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RENI", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RICHARD", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RICHMON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RICHMOND", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RIGA", NULL, NULL, NULL, "RUS", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RIJEKA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RIO", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RIO1", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RIOGRAND", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RIORSECA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RIVERHE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ROCKY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ROMANIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ROMEGA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ROSARIO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ROT+E-V", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "VESSEL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ROTT+E+P", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "VESSEL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ROTT+E+V", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "VESSEL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ROTTERDA", NULL, NULL, NULL, "NL", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ROUEN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ROUSSE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RTRFONLY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "VESSEL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RUNNIOWA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("RUSSIAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("S AFRICA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SABINE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SABINIHT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SAINT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SAINT1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SALINA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SALONIC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SALONICA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SAN", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SAN1", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SAN2", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SAN3", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SAN4", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SANFRANS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SANJOSE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SANSALVA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SANTA", NULL, NULL, NULL, "I", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SANTOS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SANTOS,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SANTOS/", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SANTOS/1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SANTOS1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SARNIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SARROCH", NULL, NULL, NULL, "I", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SAUDABAY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SAUDI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SAVANNA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SAVANNAH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SAVONA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SCOTLAND", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SEA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SEALSAND", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SEATTLE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SECAUCU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SEN", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SEPETIB", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SERIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SERTAOZ", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SETE,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SETUBAL", NULL, NULL, NULL, "P", NULL, 
NULL, "SETUBAL", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SHANGHAI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SHANNON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SHANTOU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SHELHAVN", NULL, NULL, NULL, "UK", NULL, 
NULL, "LONDON", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SHELLGOT", NULL, NULL, NULL, "BRD", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SHELLNET", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SHELLPUL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SHELLTGT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SHELLTRN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SHELMOER", NULL, NULL, NULL, "NL", NULL, 
NULL, "DORDRECH", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SHELTIRO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SHOREHA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SIDI", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SIKKA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SINES", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SING", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SINGAPOR", NULL, NULL, NULL, "SGP", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SIR", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SIRRI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SKIKDA", NULL, NULL, NULL, "DZ", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SKIRRA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SLAGENTA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SLUISKI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SNAM", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SONAT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SORRSTOR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SOUTAFRI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SOUTH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SOUTH1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SOUTH2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SOYO", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SPAIN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SPC", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SPEL", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SRI", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SRIRACHA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ST PETER", NULL, NULL, NULL, "RUS", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ST.", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ST. ROSE", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ST.CROIX", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ST.EUSTA", NULL, NULL, NULL, "NA", NULL, 
NULL, "ST.EUSTA", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ST.JAMES", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ST.PETE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STANLOW", NULL, NULL, NULL, "UK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STARAZA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STATFJOR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STAVANGE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STCLAI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STCLAIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STENSND8", NULL, NULL, NULL, "S", NULL, 
NULL, "STENUNGS", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STENSND9", NULL, NULL, NULL, "S", NULL, 
NULL, "STENUNGS", NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STENSUND", NULL, NULL, NULL, "S", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STJAMES", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STJAMLA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STOCKHO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STSKarls", NULL, NULL, NULL, "S", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STSMalmo", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STSOxelo", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STSstenu", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("STURE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SULLOM", NULL, NULL, NULL, "UK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SUMAS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SUNSHIN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SWANSEA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SWEDEN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SWITZER", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("SYRIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TABANGAO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TAFT,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TAICHUNG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TAIWAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TAKASAYO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TAKOLA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TALARA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TALLINN", NULL, NULL, NULL, "RUS", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TAMPA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TANGA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TANJUNG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TAO", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TARANTO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TARBERT", NULL, NULL, NULL, "IRL", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TARNOW", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TARRAGON", NULL, NULL, NULL, "E", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TARTOUS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TASMANI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TCOPOOL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TCPL", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TCPL1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TCPL2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TCPL3", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TCPL4", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TCPL5", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TCPLWADD", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TCPUNIDA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TEESSIDE", NULL, NULL, NULL, "UK", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TEMA", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TENERIFE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TENN", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TENNPOOL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TERBNCGL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TERMINU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TERNEUZE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TETCO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TETCO-C", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TETCO-C1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TETCO-E", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TETCO-E1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TETCO-S", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TETCO-W", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TETCO1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TETCO2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TETCOPO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TETNEY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TEXACOES", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TEXAS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TEXAS1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TEXASCIT", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TGP", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TGPL", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TGPL-10", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TGPL-50", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TGPL-80", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TGPL-HA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TGPL1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TGPL4", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TGPL5", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TGPL6", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TGT", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TGTCNTRV", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("THAILAND", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("THAMES", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("THEVENAR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TIERRA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TILLBUR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TNCOLUNI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TNNIAGRA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TNWESTMN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TO", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TOGLIAT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TOKUYAMA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TOKYO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TOLEDO,", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TOMAS", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TORONTO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TOTALREF", NULL, NULL, NULL, "F", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRANMERE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRANSCO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRANSCO1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRANSCO2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRANSCO3", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRANSCO4", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRANSCO5", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRANSCO6", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRANSCO7", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRANSCOH", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRANSCOL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRANSCOW", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRENTON", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRIESTE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRINIDAD", NULL, NULL, NULL, "TT", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRNKLNTE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRNSCO65", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRUNKLI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRUNKLI1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRUNKLI2", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRZOS365", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TRZOS485", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TUAPSE", NULL, NULL, NULL, "RUS", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TUMACO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TUNISIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TURKEY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TUXPAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TUXPAN/", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("TUXPMEXI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UDANG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UGPL/ER", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UGPL/VE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UJUNG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UK", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UKRAINE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ULSAN", NULL, NULL, NULL, "KOR", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UMM", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UNION", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UNITED", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UNIVERSA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UNKNOWN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UNRESTR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("URAN", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("URUGUAI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("USA", NULL, NULL, NULL, "USA", NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("USGULF", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, "CPL", 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("UTOSTRNK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("V", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VADINAR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VADO", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VALENCI", NULL, NULL, NULL, "E", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VANCOUV", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VARNA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VENEZU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VENICE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VENTSPI", NULL, NULL, NULL, "RUS", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VENTSPIC", NULL, NULL, NULL, "RUS", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VENTURA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VIETNAM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VIGO", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VIRGINI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VISTA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VITORIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VITORIA1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VIZAG", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VOTTGoth", NULL, NULL, NULL, "S", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("VUNGTAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WADDINGT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WADI", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WATERSTN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WEST", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WEST1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WESTERN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WESTKATY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WHANGERA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WHITEGAT", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WILHEMS", NULL, NULL, NULL, "BRD", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WILLEMST", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WILMING", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WILMING1", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WISMAR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WITNELL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("WMONROE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("YABUCO", NULL, NULL, NULL, "PRI", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("YACUIBA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("YALOVA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("YARIMCA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("YEMEN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("YEOSU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("YOKKAIC", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("YOKOHAM", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("YORK,UK", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("YORKTOWN", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("YUZHNY", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("Yemen", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ZADAR", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ZAFIRO", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ZAIRE", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ZEIT", NULL, NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ZHANGJIA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ZHANJIAN", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ZHENHAI", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ZIRKU", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ZONESL", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("ZUEITINA", NULL, NULL, NULL, NULL, NULL, 
NULL, NULL, NULL, 1)
go

insert into location_ext_info
   (loc_code, accountant_id,scheduler_id, trader_id,
     country_code, state_code, county_code, city_code,
     dflt_mot_code,trans_id) 
    values("humriv", NULL, NULL, NULL, "USA", NULL, 
NULL, NULL, NULL, 1)
go

