print 'Loading additional seed data into the location_group table ...'
go

insert into location_group values("/", "AAHRUS", "DEL", "N", 1)
go

insert into location_group values("/", "ABIDJAN", "DEL", "N", 1)
go

insert into location_group values("/", "ABU", "DEL", "N", 1)
go

insert into location_group values("/", "ACADIAN", "DEL", "N", 1)
go

insert into location_group values("/", "ACAJUTL", "DEL", "N", 1)
go

insert into location_group values("/", "ACCRA", "DEL", "N", 1)
go

insert into location_group values("/", "ADAMOVO", "DEL", "N", 1)
go

insert into location_group values("/", "AECO", "DEL", "N", 1)
go

insert into location_group values("/", "AECOA", "DEL", "N", 1)
go

insert into location_group values("/", "AECOCFOO", "DEL", "N", 1)
go

insert into location_group values("/", "AECONOVA", "DEL", "N", 1)
go

insert into location_group values("/", "AEP/APS", "DEL", "N", 1)
go

insert into location_group values("/", "AEP/VEP", "DEL", "N", 1)
go

insert into location_group values("/", "AGHII", "DEL", "N", 1)
go

insert into location_group values("/", "AINSUK", "DEL", "N", 1)
go

insert into location_group values("/", "AKABA", "DEL", "N", 1)
go

insert into location_group values("/", "AL-BAKR", "DEL", "N", 1)
go

insert into location_group values("/", "AL-BAKR", "RCP", "N", 1)
go

insert into location_group values("/", "ALBANY", "DEL", "N", 1)
go

insert into location_group values("/", "ALGECIRA", "DEL", "N", 1)
go

insert into location_group values("/", "ALGERIA", "DEL", "N", 1)
go

insert into location_group values("/", "ALGONQU", "DEL", "N", 1)
go

insert into location_group values("/", "ALGONQU1", "DEL", "N", 1)
go

insert into location_group values("/", "ALGONQU2", "DEL", "N", 1)
go

insert into location_group values("/", "ALGONQU3", "DEL", "N", 1)
go

insert into location_group values("/", "ALGONQU4", "DEL", "N", 1)
go

insert into location_group values("/", "ALGONQU5", "DEL", "N", 1)
go

insert into location_group values("/", "ALGONQU6", "DEL", "N", 1)
go

insert into location_group values("/", "ALIAGA", "DEL", "N", 1)
go

insert into location_group values("/", "ALLIANCE", "DEL", "N", 1)
go

insert into location_group values("/", "AMBARLI", "DEL", "N", 1)
go

insert into location_group values("/", "AMSROTAN", "DEL", "N", 1)
go

insert into location_group values("/", "AMSTERDA", "DEL", "N", 1)
go

insert into location_group values("/", "AMSTROTT", "DEL", "N", 1)
go

insert into location_group values("/", "AMUAY", "DEL", "N", 1)
go

insert into location_group values("/", "ANG", "RCP", "N", 1)
go

insert into location_group values("/", "ANGOLA", "DEL", "N", 1)
go

insert into location_group values("/", "ANR", "DEL", "N", 1)
go

insert into location_group values("/", "ANR-PAT", "DEL", "N", 1)
go

insert into location_group values("/", "ANR-SE L", "DEL", "N", 1)
go

insert into location_group values("/", "ANRCUSTR", "DEL", "N", 1)
go

insert into location_group values("/", "ANRLKAR", "DEL", "N", 1)
go

insert into location_group values("/", "ANRSOHIO", "DEL", "N", 1)
go

insert into location_group values("/", "ANTAN", "DEL", "N", 1)
go

insert into location_group values("/", "ANTWERP", "DEL", "N", 1)
go

insert into location_group values("/", "APS", "DEL", "N", 1)
go

insert into location_group values("/", "APS/PJM", "DEL", "N", 1)
go

insert into location_group values("/", "ARA", "DEL", "N", 1)
go

insert into location_group values("/", "ARATU", "DEL", "N", 1)
go

insert into location_group values("/", "ARDJUNA", "DEL", "N", 1)
go

insert into location_group values("/", "ARGENTIN", "DEL", "N", 1)
go

insert into location_group values("/", "ARGYLL", "DEL", "N", 1)
go

insert into location_group values("/", "ARUBA", "DEL", "N", 1)
go

insert into location_group values("/", "ARUBA", "RCP", "N", 1)
go

insert into location_group values("/", "ARZANNAH", "DEL", "N", 1)
go

insert into location_group values("/", "ARZEW", "DEL", "N", 1)
go

insert into location_group values("/", "ASH", "DEL", "N", 1)
go

insert into location_group values("/", "ASHKELO", "DEL", "N", 1)
go

insert into location_group values("/", "ASHTART", "DEL", "N", 1)
go

insert into location_group values("/", "ASPROPYR", "DEL", "N", 1)
go

insert into location_group values("/", "ASUNCIO", "DEL", "N", 1)
go

insert into location_group values("/", "ATHENS", "DEL", "N", 1)
go

insert into location_group values("/", "AUGHNISH", "DEL", "N", 1)
go

insert into location_group values("/", "AUGHNISH", "RCP", "N", 1)
go

insert into location_group values("/", "AUGUSTA", "DEL", "N", 1)
go

insert into location_group values("/", "AUGUSTAT", "DEL", "N", 1)
go

insert into location_group values("/", "AUSTRAL", "DEL", "N", 1)
go

insert into location_group values("/", "AUSTRALI", "DEL", "N", 1)
go

insert into location_group values("/", "AUSTRALI", "OFF", "N", 1)
go

insert into location_group values("/", "AVILES", "DEL", "N", 1)
go

insert into location_group values("/", "AVNMOUTH", "DEL", "N", 1)
go

insert into location_group values("/", "AVNMOUTH", "RCP", "N", 1)
go

insert into location_group values("/", "Africa", "DEL", "N", 1)
go

insert into location_group values("/", "Africa", "RCP", "N", 1)
go

insert into location_group values("/", "BA", "DEL", "N", 1)
go

insert into location_group values("/", "BA", "OFF", "N", 1)
go

insert into location_group values("/", "BACTON", "DEL", "N", 1)
go

insert into location_group values("/", "BADAK", "DEL", "N", 1)
go

insert into location_group values("/", "BAHAMAS", "DEL", "N", 1)
go

insert into location_group values("/", "BAHAMAS", "RCP", "N", 1)
go

insert into location_group values("/", "BAHIA", "DEL", "N", 1)
go

insert into location_group values("/", "BAHRAIN", "DEL", "N", 1)
go

insert into location_group values("/", "BAJO", "DEL", "N", 1)
go

insert into location_group values("/", "BALAOEQ", "DEL", "N", 1)
go

insert into location_group values("/", "BALAOEQ", "RCP", "N", 1)
go

insert into location_group values("/", "BALBOA", "DEL", "N", 1)
go

insert into location_group values("/", "BALBOA", "RCP", "N", 1)
go

insert into location_group values("/", "BALONGAN", "DEL", "N", 1)
go

insert into location_group values("/", "BALTIMO", "DEL", "N", 1)
go

insert into location_group values("/", "BALTIMOR", "DEL", "N", 1)
go

insert into location_group values("/", "BANBURY", "DEL", "N", 1)
go

insert into location_group values("/", "BANDAR", "DEL", "N", 1)
go

insert into location_group values("/", "BANDAR1", "DEL", "N", 1)
go

insert into location_group values("/", "BANGCHAK", "DEL", "N", 1)
go

insert into location_group values("/", "BANGKOK", "DEL", "N", 1)
go

insert into location_group values("/", "BANIAS", "DEL", "N", 1)
go

insert into location_group values("/", "BAR", "DEL", "N", 1)
go

insert into location_group values("/", "BAR", "RCP", "N", 1)
go

insert into location_group values("/", "BARCELO", "DEL", "N", 1)
go

insert into location_group values("/", "BARROWIL", "DEL", "N", 1)
go

insert into location_group values("/", "BARRY", "DEL", "N", 1)
go

insert into location_group values("/", "BARTONAL", "DEL", "N", 1)
go

insert into location_group values("/", "BARTONTN", "DEL", "N", 1)
go

insert into location_group values("/", "BATAM", "DEL", "N", 1)
go

insert into location_group values("/", "BATANGAS", "DEL", "N", 1)
go

insert into location_group values("/", "BATON", "DEL", "N", 1)
go

insert into location_group values("/", "BATUMI", "DEL", "N", 1)
go

insert into location_group values("/", "BAYONNE", "DEL", "N", 1)
go

insert into location_group values("/", "BAYOVAR", "DEL", "N", 1)
go

insert into location_group values("/", "BAYPORT", "DEL", "N", 1)
go

insert into location_group values("/", "BAYTOWN", "DEL", "N", 1)
go

insert into location_group values("/", "BEATRICE", "DEL", "N", 1)
go

insert into location_group values("/", "BEAUMON", "DEL", "N", 1)
go

insert into location_group values("/", "BEAUMON1", "DEL", "N", 1)
go

insert into location_group values("/", "BEAUMON2", "DEL", "N", 1)
go

insert into location_group values("/", "BEIRUT", "DEL", "N", 1)
go

insert into location_group values("/", "BEJAIA", "DEL", "N", 1)
go

insert into location_group values("/", "BELEM-M", "DEL", "N", 1)
go

insert into location_group values("/", "BELEM-P", "DEL", "N", 1)
go

insert into location_group values("/", "BELFAST", "DEL", "N", 1)
go

insert into location_group values("/", "BELFAST", "RCP", "N", 1)
go

insert into location_group values("/", "BELGIAN", "DEL", "N", 1)
go

insert into location_group values("/", "BELGIUM", "DEL", "N", 1)
go

insert into location_group values("/", "BELIDA", "DEL", "N", 1)
go

insert into location_group values("/", "BELIDA", "RCP", "N", 1)
go

insert into location_group values("/", "BELMONT", "DEL", "N", 1)
go

insert into location_group values("/", "BELVEDE", "DEL", "N", 1)
go

insert into location_group values("/", "BERGEN,", "DEL", "N", 1)
go

insert into location_group values("/", "BERYL", "DEL", "N", 1)
go

insert into location_group values("/", "BGE", "DEL", "N", 1)
go

insert into location_group values("/", "BILBAO", "DEL", "N", 1)
go

insert into location_group values("/", "BIRMIN", "DEL", "N", 1)
go

insert into location_group values("/", "BIZERTE", "DEL", "N", 1)
go

insert into location_group values("/", "BLANG", "DEL", "N", 1)
go

insert into location_group values("/", "BOMBAY", "DEL", "N", 1)
go

insert into location_group values("/", "BONNY", "DEL", "N", 1)
go

insert into location_group values("/", "BONYTHON", "DEL", "N", 1)
go

insert into location_group values("/", "BORDEAUX", "DEL", "N", 1)
go

insert into location_group values("/", "BORDEAUX", "RCP", "N", 1)
go

insert into location_group values("/", "BOSTON", "DEL", "N", 1)
go

insert into location_group values("/", "BOTLEK", "DEL", "N", 1)
go

insert into location_group values("/", "BOTLEK", "RCP", "N", 1)
go

insert into location_group values("/", "BOTROP", "DEL", "N", 1)
go

insert into location_group values("/", "BOURGAS", "DEL", "N", 1)
go

insert into location_group values("/", "BP", "DEL", "N", 1)
go

insert into location_group values("/", "BPBIENVL", "DEL", "N", 1)
go

insert into location_group values("/", "BPREF", "DEL", "N", 1)
go

insert into location_group values("/", "BRASS", "DEL", "N", 1)
go

insert into location_group values("/", "BRAZIL", "DEL", "N", 1)
go

insert into location_group values("/", "BRCANTW", "DEL", "N", 1)
go

insert into location_group values("/", "BREMEN", "DEL", "N", 1)
go

insert into location_group values("/", "BREST", "DEL", "N", 1)
go

insert into location_group values("/", "BRIDGEL", "DEL", "N", 1)
go

insert into location_group values("/", "BROF", "DEL", "N", 1)
go

insert into location_group values("/", "BROOKLNY", "DEL", "N", 1)
go

insert into location_group values("/", "BROWNSV", "DEL", "N", 1)
go

insert into location_group values("/", "BRUNSBUT", "DEL", "N", 1)
go

insert into location_group values("/", "BUDAPES", "DEL", "N", 1)
go

insert into location_group values("/", "BUDKOVCE", "DEL", "N", 1)
go

insert into location_group values("/", "BUENAVE", "DEL", "N", 1)
go

insert into location_group values("/", "BUENOS", "DEL", "N", 1)
go

insert into location_group values("/", "BULGARI", "DEL", "N", 1)
go

insert into location_group values("/", "BULLENBA", "DEL", "N", 1)
go

insert into location_group values("/", "BUNYU", "DEL", "N", 1)
go

insert into location_group values("/", "BURNABY", "DEL", "N", 1)
go

insert into location_group values("/", "BUSAN", "DEL", "N", 1)
go

insert into location_group values("/", "CA", "DEL", "N", 1)
go

insert into location_group values("/", "CABINDA", "DEL", "N", 1)
go

insert into location_group values("/", "CALAIS", "DEL", "N", 1)
go

insert into location_group values("/", "CALCUTA", "DEL", "N", 1)
go

insert into location_group values("/", "CALETA", "DEL", "N", 1)
go

insert into location_group values("/", "CALIFOR", "DEL", "N", 1)
go

insert into location_group values("/", "CAMDEN", "DEL", "N", 1)
go

insert into location_group values("/", "CAMDEN,", "DEL", "N", 1)
go

insert into location_group values("/", "CAMDEN,1", "DEL", "N", 1)
go

insert into location_group values("/", "CAMEROON", "DEL", "N", 1)
go

insert into location_group values("/", "CAMMAC", "DEL", "N", 1)
go

insert into location_group values("/", "CAMPANA", "DEL", "N", 1)
go

insert into location_group values("/", "CANADA", "DEL", "N", 1)
go

insert into location_group values("/", "CANAJO", "DEL", "N", 1)
go

insert into location_group values("/", "CANAJOH", "DEL", "N", 1)
go

insert into location_group values("/", "CANARY", "DEL", "N", 1)
go

insert into location_group values("/", "CAP", "DEL", "N", 1)
go

insert into location_group values("/", "CAPETOWN", "DEL", "N", 1)
go

insert into location_group values("/", "CAPETOWN", "RCP", "N", 1)
go

insert into location_group values("/", "CAPTAIN", "DEL", "N", 1)
go

insert into location_group values("/", "CAPTAIN", "RCP", "N", 1)
go

insert into location_group values("/", "CARACASB", "DEL", "N", 1)
go

insert into location_group values("/", "CARDIFF", "DEL", "N", 1)
go

insert into location_group values("/", "CARDIFF", "RCP", "N", 1)
go

insert into location_group values("/", "CARDON", "DEL", "N", 1)
go

insert into location_group values("/", "CARDON", "RCP", "N", 1)
go

insert into location_group values("/", "CARIPITO", "DEL", "N", 1)
go

insert into location_group values("/", "CARLTON", "DEL", "N", 1)
go

insert into location_group values("/", "CARTHAG", "DEL", "N", 1)
go

insert into location_group values("/", "CARUTHER", "DEL", "N", 1)
go

insert into location_group values("/", "CARVILL", "DEL", "N", 1)
go

insert into location_group values("/", "CASABLAN", "DEL", "N", 1)
go

insert into location_group values("/", "CASTELLO", "DEL", "N", 1)
go

insert into location_group values("/", "CAYMAN", "DEL", "N", 1)
go

insert into location_group values("/", "CAYMAN", "RCP", "N", 1)
go

insert into location_group values("/", "CAYO", "DEL", "N", 1)
go

insert into location_group values("/", "CENTERCG", "DEL", "N", 1)
go

insert into location_group values("/", "CENTERVI", "DEL", "N", 1)
go

insert into location_group values("/", "CENTERVT", "DEL", "N", 1)
go

insert into location_group values("/", "CEYHAM1", "DEL", "N", 1)
go

insert into location_group values("/", "CEYHAN2", "DEL", "N", 1)
go

insert into location_group values("/", "CEYLON", "DEL", "N", 1)
go

insert into location_group values("/", "CFLORIDA", "DEL", "N", 1)
go

insert into location_group values("/", "CGT-POO", "DEL", "N", 1)
go

insert into location_group values("/", "CGT/RAY", "DEL", "N", 1)
go

insert into location_group values("/", "CGTPOOL", "DEL", "N", 1)
go

insert into location_group values("/", "CHALMET", "DEL", "N", 1)
go

insert into location_group values("/", "CHIBA", "DEL", "N", 1)
go

insert into location_group values("/", "CHICAGO", "DEL", "N", 1)
go

insert into location_group values("/", "CHICAGO1", "DEL", "N", 1)
go

insert into location_group values("/", "CHICCITY", "DEL", "N", 1)
go

insert into location_group values("/", "CHILIE", "DEL", "N", 1)
go

insert into location_group values("/", "CHILIE", "RCP", "N", 1)
go

insert into location_group values("/", "CHINA", "DEL", "N", 1)
go

insert into location_group values("/", "CHINESE", "DEL", "N", 1)
go

insert into location_group values("/", "CHIPAWA", "DEL", "N", 1)
go

insert into location_group values("/", "CHIRK,U", "DEL", "N", 1)
go

insert into location_group values("/", "CHITA", "DEL", "N", 1)
go

insert into location_group values("/", "CHITTAGO", "DEL", "N", 1)
go

insert into location_group values("/", "CHOCBAHO", "DEL", "N", 1)
go

insert into location_group values("/", "CHOCBATR", "DEL", "N", 1)
go

insert into location_group values("/", "CHOCOLA", "DEL", "N", 1)
go

insert into location_group values("/", "CIERNA", "DEL", "N", 1)
go

insert into location_group values("/", "CIF", "DEL", "N", 1)
go

insert into location_group values("/", "CIFBORDX", "DEL", "N", 1)
go

insert into location_group values("/", "CIFBORDX", "RCP", "N", 1)
go

insert into location_group values("/", "CIFLEITH", "DEL", "N", 1)
go

insert into location_group values("/", "CIFLEITH", "RCP", "N", 1)
go

insert into location_group values("/", "CIG", "DEL", "N", 1)
go

insert into location_group values("/", "CIG OPAL", "DEL", "N", 1)
go

insert into location_group values("/", "CIG PARA", "DEL", "N", 1)
go

insert into location_group values("/", "CILICAP", "DEL", "N", 1)
go

insert into location_group values("/", "CINCINNA", "DEL", "N", 1)
go

insert into location_group values("/", "CINERGY", "DEL", "N", 1)
go

insert into location_group values("/", "CINTA", "DEL", "N", 1)
go

insert into location_group values("/", "CITSERTR", "DEL", "N", 1)
go

insert into location_group values("/", "CITYGATE", "DEL", "N", 1)
go

insert into location_group values("/", "CIVITAV", "DEL", "N", 1)
go

insert into location_group values("/", "CLARENCI", "DEL", "N", 1)
go

insert into location_group values("/", "CLEVELA", "DEL", "N", 1)
go

insert into location_group values("/", "CLIFTON", "DEL", "N", 1)
go

insert into location_group values("/", "CLIFTON", "RCP", "N", 1)
go

insert into location_group values("/", "CNG", "DEL", "N", 1)
go

insert into location_group values("/", "CNGPOOL", "DEL", "N", 1)
go

insert into location_group values("/", "COATZACO", "DEL", "N", 1)
go

insert into location_group values("/", "COCHIN", "DEL", "N", 1)
go

insert into location_group values("/", "COL/ALGO", "DEL", "N", 1)
go

insert into location_group values("/", "COLLINS", "DEL", "N", 1)
go

insert into location_group values("/", "COLLINS", "RCP", "N", 1)
go

insert into location_group values("/", "COLOMBIA", "DEL", "N", 1)
go

insert into location_group values("/", "COLOMBO", "DEL", "N", 1)
go

insert into location_group values("/", "COLONIA", "DEL", "N", 1)
go

insert into location_group values("/", "COLUMBI", "DEL", "N", 1)
go

insert into location_group values("/", "COLUMBIA", "DEL", "N", 1)
go

insert into location_group values("/", "COLUMBU", "DEL", "N", 1)
go

insert into location_group values("/", "COMEX", "DEL", "N", 1)
go

insert into location_group values("/", "COMODORO", "DEL", "N", 1)
go

insert into location_group values("/", "CONED", "DEL", "N", 1)
go

insert into location_group values("/", "CONNECT", "DEL", "N", 1)
go

insert into location_group values("/", "CONSTANT", "DEL", "N", 1)
go

insert into location_group values("/", "CONSUME", "DEL", "N", 1)
go

insert into location_group values("/", "CONSUME1", "DEL", "N", 1)
go

insert into location_group values("/", "CONVENT", "DEL", "N", 1)
go

insert into location_group values("/", "COOLKEER", "DEL", "N", 1)
go

insert into location_group values("/", "COOLKEER", "RCP", "N", 1)
go

insert into location_group values("/", "CORMAN", "DEL", "N", 1)
go

insert into location_group values("/", "CORP", "DEL", "N", 1)
go

insert into location_group values("/", "CORPUS", "DEL", "N", 1)
go

insert into location_group values("/", "CORPUS1", "DEL", "N", 1)
go

insert into location_group values("/", "CORYTON", "DEL", "N", 1)
go

insert into location_group values("/", "COSTARIC", "DEL", "N", 1)
go

insert into location_group values("/", "COSTARIC", "RCP", "N", 1)
go

insert into location_group values("/", "COURTAU", "DEL", "N", 1)
go

insert into location_group values("/", "COVENAS", "DEL", "N", 1)
go

insert into location_group values("/", "CPL/VEP", "DEL", "N", 1)
go

insert into location_group values("/", "CRAU", "DEL", "N", 1)
go

insert into location_group values("/", "CURACAO", "DEL", "N", 1)
go

insert into location_group values("/", "CUSHING", "DEL", "N", 1)
go

insert into location_group values("/", "CYPRESS", "DEL", "N", 1)
go

insert into location_group values("/", "CYPRESS-", "DEL", "N", 1)
go

insert into location_group values("/", "CYPRESS1", "DEL", "N", 1)
go

insert into location_group values("/", "CZECH", "DEL", "N", 1)
go

insert into location_group values("/", "Couronne", "DEL", "N", 1)
go

insert into location_group values("/", "Couronne", "RCP", "N", 1)
go

insert into location_group values("/", "DAESAN", "DEL", "N", 1)
go

insert into location_group values("/", "DAKAR", "DEL", "N", 1)
go

insert into location_group values("/", "DAR", "DEL", "N", 1)
go

insert into location_group values("/", "DAS", "DEL", "N", 1)
go

insert into location_group values("/", "DAWNKOCH", "DEL", "N", 1)
go

insert into location_group values("/", "DEASAN", "DEL", "N", 1)
go

insert into location_group values("/", "DEER", "DEL", "N", 1)
go

insert into location_group values("/", "DELAWARE", "DEL", "N", 1)
go

insert into location_group values("/", "DENMARK", "DEL", "N", 1)
go

insert into location_group values("/", "DERINCE", "DEL", "N", 1)
go

insert into location_group values("/", "DETROIMI", "DEL", "N", 1)
go

insert into location_group values("/", "DJENO", "DEL", "N", 1)
go

insert into location_group values("/", "DJIBOUT", "DEL", "N", 1)
go

insert into location_group values("/", "DLBAWIPL", "DEL", "N", 1)
go

insert into location_group values("/", "DLVD", "DEL", "N", 1)
go

insert into location_group values("/", "DLVD1", "DEL", "N", 1)
go

insert into location_group values("/", "DLVDACAD", "DEL", "N", 1)
go

insert into location_group values("/", "DLVDNOPS", "DEL", "N", 1)
go

insert into location_group values("/", "DLVDOLYM", "DEL", "N", 1)
go

insert into location_group values("/", "DLVDWATE", "DEL", "N", 1)
go

insert into location_group values("/", "DLVNINMI", "DEL", "N", 1)
go

insert into location_group values("/", "DOCK/WH", "DEL", "N", 1)
go

insert into location_group values("/", "DOM", "DEL", "N", 1)
go

insert into location_group values("/", "DONGES", "DEL", "N", 1)
go

insert into location_group values("/", "DOS", "DEL", "N", 1)
go

insert into location_group values("/", "DUBAI", "DEL", "N", 1)
go

insert into location_group values("/", "DUBLIN", "DEL", "N", 1)
go

insert into location_group values("/", "DUBLIN", "RCP", "N", 1)
go

insert into location_group values("/", "DUCTERM", "DEL", "N", 1)
go

insert into location_group values("/", "DUCTERM", "RCP", "N", 1)
go

insert into location_group values("/", "DUMAI", "DEL", "N", 1)
go

insert into location_group values("/", "DUMASNN", "DEL", "N", 1)
go

insert into location_group values("/", "DUNKERQU", "DEL", "N", 1)
go

insert into location_group values("/", "DUNKIRK", "DEL", "N", 1)
go

insert into location_group values("/", "DURBAN", "DEL", "N", 1)
go

insert into location_group values("/", "DURBAN", "RCP", "N", 1)
go

insert into location_group values("/", "DUTCH", "DEL", "N", 1)
go

insert into location_group values("/", "E.AURORA", "DEL", "N", 1)
go

insert into location_group values("/", "EAGLE", "DEL", "N", 1)
go

insert into location_group values("/", "EAGLE1", "DEL", "N", 1)
go

insert into location_group values("/", "EAST", "DEL", "N", 1)
go

insert into location_group values("/", "EAST1", "DEL", "N", 1)
go

insert into location_group values("/", "EAST2", "DEL", "N", 1)
go

insert into location_group values("/", "EASTLVRP", "DEL", "N", 1)
go

insert into location_group values("/", "EEC", "DEL", "N", 1)
go

insert into location_group values("/", "EEC,", "DEL", "N", 1)
go

insert into location_group values("/", "EGYPT", "DEL", "N", 1)
go

insert into location_group values("/", "EILAT", "DEL", "N", 1)
go

insert into location_group values("/", "EIMSHAV", "DEL", "N", 1)
go

insert into location_group values("/", "ELEFSIS", "DEL", "N", 1)
go

insert into location_group values("/", "ELIZABNJ", "DEL", "N", 1)
go

insert into location_group values("/", "ELPASO", "DEL", "N", 1)
go

insert into location_group values("/", "ELSALVAD", "DEL", "N", 1)
go

insert into location_group values("/", "ELSALVAD", "RCP", "N", 1)
go

insert into location_group values("/", "EMPIRE", "DEL", "N", 1)
go

insert into location_group values("/", "EMPIRE-", "DEL", "N", 1)
go

insert into location_group values("/", "EMPIRE-1", "DEL", "N", 1)
go

insert into location_group values("/", "EMPIRE-2", "DEL", "N", 1)
go

insert into location_group values("/", "EMPIRE-3", "DEL", "N", 1)
go

insert into location_group values("/", "EMPRESS", "DEL", "N", 1)
go

insert into location_group values("/", "EMPRESSN", "DEL", "N", 1)
go

insert into location_group values("/", "ENGLAND", "DEL", "N", 1)
go

insert into location_group values("/", "ENTERGY", "DEL", "N", 1)
go

insert into location_group values("/", "EPNG", "DEL", "N", 1)
go

insert into location_group values("/", "ERATH", "DEL", "N", 1)
go

insert into location_group values("/", "ERATHCOL", "DEL", "N", 1)
go

insert into location_group values("/", "ERATHKOC", "DEL", "N", 1)
go

insert into location_group values("/", "ERATHLRC", "DEL", "N", 1)
go

insert into location_group values("/", "ERATHNGP", "DEL", "N", 1)
go

insert into location_group values("/", "ERATHSAB", "DEL", "N", 1)
go

insert into location_group values("/", "ERATHSEA", "DEL", "N", 1)
go

insert into location_group values("/", "ERATHSON", "DEL", "N", 1)
go

insert into location_group values("/", "ERATTERM", "DEL", "N", 1)
go

insert into location_group values("/", "ERAWAN", "DEL", "N", 1)
go

insert into location_group values("/", "ERG", "DEL", "N", 1)
go

insert into location_group values("/", "ES", "DEL", "N", 1)
go

insert into location_group values("/", "ESCRAVOS", "DEL", "N", 1)
go

insert into location_group values("/", "ESMERALD", "DEL", "N", 1)
go

insert into location_group values("/", "ESSIDER", "DEL", "N", 1)
go

insert into location_group values("/", "ESSO", "DEL", "N", 1)
go

insert into location_group values("/", "ESSOPAC", "DEL", "N", 1)
go

insert into location_group values("/", "ESSOTERM", "DEL", "N", 1)
go

insert into location_group values("/", "EUROPAK", "DEL", "N", 1)
go

insert into location_group values("/", "EUROPAK", "RCP", "N", 1)
go

insert into location_group values("/", "EUROPEA", "DEL", "N", 1)
go

insert into location_group values("/", "EVANSVI", "DEL", "N", 1)
go

insert into location_group values("/", "EX-WARE", "DEL", "N", 1)
go

insert into location_group values("/", "EXCLVOTT", "RCP", "N", 1)
go

insert into location_group values("/", "EXXKATTA", "DEL", "N", 1)
go

insert into location_group values("/", "Everglad", "DEL", "N", 1)
go

insert into location_group values("/", "Everglad", "RCP", "N", 1)
go

insert into location_group values("/", "FALCONA", "DEL", "N", 1)
go

insert into location_group values("/", "FALL", "DEL", "N", 1)
go

insert into location_group values("/", "FALL1", "DEL", "N", 1)
go

insert into location_group values("/", "FALMOUTH", "DEL", "N", 1)
go

insert into location_group values("/", "FATEH", "DEL", "N", 1)
go

insert into location_group values("/", "FAWLEY", "DEL", "N", 1)
go

insert into location_group values("/", "FAYNE,", "DEL", "N", 1)
go

insert into location_group values("/", "FELEY", "DEL", "N", 1)
go

insert into location_group values("/", "FELIXST", "DEL", "N", 1)
go

insert into location_group values("/", "FENYESLI", "DEL", "N", 1)
go

insert into location_group values("/", "FEODOSI", "DEL", "N", 1)
go

insert into location_group values("/", "FERROL", "DEL", "N", 1)
go

insert into location_group values("/", "FIFEOFFS", "DEL", "N", 1)
go

insert into location_group values("/", "FIFEOFFS", "RCP", "N", 1)
go

insert into location_group values("/", "FINA", "DEL", "N", 1)
go

insert into location_group values("/", "FINLAND", "DEL", "N", 1)
go

insert into location_group values("/", "FINNART", "DEL", "N", 1)
go

insert into location_group values("/", "FINNART", "RCP", "N", 1)
go

insert into location_group values("/", "FIPPEMB", "RCP", "N", 1)
go

insert into location_group values("/", "FLOMAR", "DEL", "N", 1)
go

insert into location_group values("/", "FLOOPLAN", "DEL", "N", 1)
go

insert into location_group values("/", "FLORIDA", "DEL", "N", 1)
go

insert into location_group values("/", "FLORKAPL", "DEL", "N", 1)
go

insert into location_group values("/", "FLOTTA", "DEL", "N", 1)
go

insert into location_group values("/", "FLUSHIN", "DEL", "N", 1)
go

insert into location_group values("/", "FNDTRNSF", "DEL", "N", 1)
go

insert into location_group values("/", "FORCADOS", "DEL", "N", 1)
go

insert into location_group values("/", "FORTUNE", "DEL", "N", 1)
go

insert into location_group values("/", "FOS", "DEL", "N", 1)
go

insert into location_group values("/", "FOURCORN", "DEL", "N", 1)
go

insert into location_group values("/", "FPSO", "DEL", "N", 1)
go

insert into location_group values("/", "FRANCE", "DEL", "N", 1)
go

insert into location_group values("/", "FREDERIC", "DEL", "N", 1)
go

insert into location_group values("/", "FREEPORT", "DEL", "N", 1)
go

insert into location_group values("/", "FUIMICIN", "DEL", "N", 1)
go

insert into location_group values("/", "FUJAIRA", "DEL", "N", 1)
go

insert into location_group values("/", "FUSINA", "DEL", "N", 1)
go

insert into location_group values("/", "FUSINA", "RCP", "N", 1)
go

insert into location_group values("/", "Fateh", "DEL", "N", 1)
go

insert into location_group values("/", "Fateh", "RCP", "N", 1)
go

insert into location_group values("/", "GABON", "DEL", "N", 1)
go

insert into location_group values("/", "GAEVLE,", "DEL", "N", 1)
go

insert into location_group values("/", "GALENA", "DEL", "N", 1)
go

insert into location_group values("/", "GALEOTA", "DEL", "N", 1)
go

insert into location_group values("/", "GALVESTO", "DEL", "N", 1)
go

insert into location_group values("/", "GAMBA", "DEL", "N", 1)
go

insert into location_group values("/", "GARRYVIL", "DEL", "N", 1)
go

insert into location_group values("/", "GARYVILL", "DEL", "N", 1)
go

insert into location_group values("/", "GATX,", "DEL", "N", 1)
go

insert into location_group values("/", "GATX/PH", "DEL", "N", 1)
go

insert into location_group values("/", "GBGPK371", "DEL", "N", 1)
go

insert into location_group values("/", "GBGPK371", "RCP", "N", 1)
go

insert into location_group values("/", "GDANSK", "DEL", "N", 1)
go

insert into location_group values("/", "GDANSTET", "DEL", "N", 1)
go

insert into location_group values("/", "GDYNIA", "DEL", "N", 1)
go

insert into location_group values("/", "GEBZE", "DEL", "N", 1)
go

insert into location_group values("/", "GEDANSK", "DEL", "N", 1)
go

insert into location_group values("/", "GEISMAR", "DEL", "N", 1)
go

insert into location_group values("/", "GEISUM", "DEL", "N", 1)
go

insert into location_group values("/", "GELA", "DEL", "N", 1)
go

insert into location_group values("/", "GELSENK", "DEL", "N", 1)
go

insert into location_group values("/", "GENOA", "DEL", "N", 1)
go

insert into location_group values("/", "GEORGETN", "DEL", "N", 1)
go

insert into location_group values("/", "GEORGETN", "RCP", "N", 1)
go

insert into location_group values("/", "GERMANY", "DEL", "N", 1)
go

insert into location_group values("/", "GERONA,", "DEL", "N", 1)
go

insert into location_group values("/", "GIBRALT", "DEL", "N", 1)
go

insert into location_group values("/", "GONFREVI", "DEL", "N", 1)
go

insert into location_group values("/", "GOODHOP", "DEL", "N", 1)
go

insert into location_group values("/", "GOTHENB", "DEL", "N", 1)
go

insert into location_group values("/", "GOTHNBRG", "DEL", "N", 1)
go

insert into location_group values("/", "GOTHNBRG", "RCP", "N", 1)
go

insert into location_group values("/", "GRANGEM", "DEL", "N", 1)
go

insert into location_group values("/", "GRANITE", "DEL", "N", 1)
go

insert into location_group values("/", "GRAVENC", "DEL", "N", 1)
go

insert into location_group values("/", "GREECE", "DEL", "N", 1)
go

insert into location_group values("/", "GREENBO", "DEL", "N", 1)
go

insert into location_group values("/", "GREENFO", "DEL", "N", 1)
go

insert into location_group values("/", "GREENFO1", "DEL", "N", 1)
go

insert into location_group values("/", "GRIM", "DEL", "N", 1)
go

insert into location_group values("/", "GRIMSBY", "DEL", "N", 1)
go

insert into location_group values("/", "GUANGZH", "DEL", "N", 1)
go

insert into location_group values("/", "GUATEMA", "DEL", "N", 1)
go

insert into location_group values("/", "GUATEMAL", "DEL", "N", 1)
go

insert into location_group values("/", "GUATEMAL", "RCP", "N", 1)
go

insert into location_group values("/", "GUAYAMA", "DEL", "N", 1)
go

insert into location_group values("/", "GUAYANIL", "DEL", "N", 1)
go

insert into location_group values("/", "GUAYANIL", "RCP", "N", 1)
go

insert into location_group values("/", "GULFHAVN", "DEL", "N", 1)
go

insert into location_group values("/", "GULFHOU", "DEL", "N", 1)
go

insert into location_group values("/", "GUMOWICE", "DEL", "N", 1)
go

insert into location_group values("/", "GUYAQUI", "DEL", "N", 1)
go

insert into location_group values("/", "Green", "DEL", "N", 1)
go

insert into location_group values("/", "Green", "RCP", "N", 1)
go

insert into location_group values("/", "H", "OFF", "N", 1)
go

insert into location_group values("/", "HAIFA", "DEL", "N", 1)
go

insert into location_group values("/", "HALDIA", "DEL", "N", 1)
go

insert into location_group values("/", "HALIFAX", "DEL", "N", 1)
go

insert into location_group values("/", "HALUL", "DEL", "N", 1)
go

insert into location_group values("/", "HAMBURG", "DEL", "N", 1)
go

insert into location_group values("/", "HAMINA", "DEL", "N", 1)
go

insert into location_group values("/", "HAMINA", "RCP", "N", 1)
go

insert into location_group values("/", "HAR", "OFF", "N", 1)
go

insert into location_group values("/", "HART", "DEL", "N", 1)
go

insert into location_group values("/", "HARVEY", "DEL", "N", 1)
go

insert into location_group values("/", "HARVEY,", "DEL", "N", 1)
go

insert into location_group values("/", "HARVEY/", "DEL", "N", 1)
go

insert into location_group values("/", "HEBERT", "DEL", "N", 1)
go

insert into location_group values("/", "HELSINK", "DEL", "N", 1)
go

insert into location_group values("/", "HENRYHUB", "DEL", "N", 1)
go

insert into location_group values("/", "HHALGONQ", "DEL", "N", 1)
go

insert into location_group values("/", "HHCLO.GU", "DEL", "N", 1)
go

insert into location_group values("/", "HHDOW", "DEL", "N", 1)
go

insert into location_group values("/", "HHLRC", "DEL", "N", 1)
go

insert into location_group values("/", "HHNGPL", "DEL", "N", 1)
go

insert into location_group values("/", "HHSONAT", "DEL", "N", 1)
go

insert into location_group values("/", "HHTEXASG", "DEL", "N", 1)
go

insert into location_group values("/", "HHTRANSC", "DEL", "N", 1)
go

insert into location_group values("/", "HHTRNKLN", "DEL", "N", 1)
go

insert into location_group values("/", "HHUBOUT", "DEL", "N", 1)
go

insert into location_group values("/", "HK", "DEL", "N", 1)
go

insert into location_group values("/", "HO", "DEL", "N", 1)
go

insert into location_group values("/", "HODDEID", "DEL", "N", 1)
go

insert into location_group values("/", "HOLLAND", "DEL", "N", 1)
go

insert into location_group values("/", "HOLLAND/", "DEL", "N", 1)
go

insert into location_group values("/", "HOLLYBE", "DEL", "N", 1)
go

insert into location_group values("/", "HOLLYLRC", "DEL", "N", 1)
go

insert into location_group values("/", "HOLLYNGP", "DEL", "N", 1)
go

insert into location_group values("/", "HOLLYSTI", "DEL", "N", 1)
go

insert into location_group values("/", "HOLYROOD", "DEL", "N", 1)
go

insert into location_group values("/", "HOLYROOD", "RCP", "N", 1)
go

insert into location_group values("/", "HONGKONG", "DEL", "N", 1)
go

insert into location_group values("/", "HOUCORCH", "DEL", "N", 1)
go

insert into location_group values("/", "HOUNDS", "DEL", "N", 1)
go

insert into location_group values("/", "HOUST/TC", "DEL", "N", 1)
go

insert into location_group values("/", "HOUSTON", "DEL", "N", 1)
go

insert into location_group values("/", "HOUSTON1", "DEL", "N", 1)
go

insert into location_group values("/", "HOUSTON2", "DEL", "N", 1)
go

insert into location_group values("/", "HOUSTON3", "DEL", "N", 1)
go

insert into location_group values("/", "HOUSTON4", "DEL", "N", 1)
go

insert into location_group values("/", "HOUSTON5", "DEL", "N", 1)
go

insert into location_group values("/", "HOUSTON6", "DEL", "N", 1)
go

insert into location_group values("/", "HOUSTON7", "DEL", "N", 1)
go

insert into location_group values("/", "HPCL", "DEL", "N", 1)
go

insert into location_group values("/", "HUANGPU", "DEL", "N", 1)
go

insert into location_group values("/", "HUELVA", "DEL", "N", 1)
go

insert into location_group values("/", "HUIZHOU", "DEL", "N", 1)
go

insert into location_group values("/", "HUIZHOU", "RCP", "N", 1)
go

insert into location_group values("/", "HULL", "DEL", "N", 1)
go

insert into location_group values("/", "HUNGARY", "DEL", "N", 1)
go

insert into location_group values("/", "HUNTERS", "DEL", "N", 1)
go

insert into location_group values("/", "IJMUIDE", "DEL", "N", 1)
go

insert into location_group values("/", "ILITCHE", "DEL", "N", 1)
go

insert into location_group values("/", "ILLINOI", "DEL", "N", 1)
go

insert into location_group values("/", "IMMINGHA", "DEL", "N", 1)
go

insert into location_group values("/", "IMTT,ST", "DEL", "N", 1)
go

insert into location_group values("/", "IMTT/NE", "DEL", "N", 1)
go

insert into location_group values("/", "INCHON", "DEL", "N", 1)
go

insert into location_group values("/", "INDIA", "DEL", "N", 1)
go

insert into location_group values("/", "INDIANA", "DEL", "N", 1)
go

insert into location_group values("/", "INDONESI", "DEL", "N", 1)
go

insert into location_group values("/", "IPLOM", "DEL", "N", 1)
go

insert into location_group values("/", "IRAN", "DEL", "N", 1)
go

insert into location_group values("/", "IRELAND", "DEL", "N", 1)
go

insert into location_group values("/", "IROQUOI", "DEL", "N", 1)
go

insert into location_group values("/", "IROQUOI1", "DEL", "N", 1)
go

insert into location_group values("/", "ISKENDRU", "DEL", "N", 1)
go

insert into location_group values("/", "ISRAEL", "DEL", "N", 1)
go

insert into location_group values("/", "ISTANBU", "DEL", "N", 1)
go

insert into location_group values("/", "ITALY", "DEL", "N", 1)
go

insert into location_group values("/", "IVORY", "DEL", "N", 1)
go

insert into location_group values("/", "IZMIT", "DEL", "N", 1)
go

insert into location_group values("/", "Italy", "DEL", "N", 1)
go

insert into location_group values("/", "Italy", "RCP", "N", 1)
go

insert into location_group values("/", "JABIRU", "DEL", "N", 1)
go

insert into location_group values("/", "JACKSNCG", "DEL", "N", 1)
go

insert into location_group values("/", "JACKSON", "DEL", "N", 1)
go

insert into location_group values("/", "JAKARTA", "DEL", "N", 1)
go

insert into location_group values("/", "JAMAICA", "DEL", "N", 1)
go

insert into location_group values("/", "JAMAICA", "RCP", "N", 1)
go

insert into location_group values("/", "JAPAN", "DEL", "N", 1)
go

insert into location_group values("/", "JEBEL", "DEL", "N", 1)
go

insert into location_group values("/", "JEBELDHA", "DEL", "N", 1)
go

insert into location_group values("/", "JEDDAH,", "DEL", "N", 1)
go

insert into location_group values("/", "JEFFERS", "DEL", "N", 1)
go

insert into location_group values("/", "JIANG", "DEL", "N", 1)
go

insert into location_group values("/", "JINSHAN", "DEL", "N", 1)
go

insert into location_group values("/", "JOSE,", "DEL", "N", 1)
go

insert into location_group values("/", "JUAYMAH", "DEL", "N", 1)
go

insert into location_group values("/", "KAKAP", "DEL", "N", 1)
go

insert into location_group values("/", "KALINING", "DEL", "N", 1)
go

insert into location_group values("/", "KALUNDBO", "DEL", "N", 1)
go

insert into location_group values("/", "KAMPALA", "DEL", "N", 1)
go

insert into location_group values("/", "KANDLA", "DEL", "N", 1)
go

insert into location_group values("/", "KAOHSIUN", "DEL", "N", 1)
go

insert into location_group values("/", "KARLSHA", "DEL", "N", 1)
go

insert into location_group values("/", "KARLSHM", "DEL", "N", 1)
go

insert into location_group values("/", "KARLSHM", "RCP", "N", 1)
go

insert into location_group values("/", "KARLSHM1", "DEL", "N", 1)
go

insert into location_group values("/", "KARLSHM1", "RCP", "N", 1)
go

insert into location_group values("/", "KARLSTA", "DEL", "N", 1)
go

insert into location_group values("/", "KAS", "DEL", "N", 1)
go

insert into location_group values("/", "KATY-PL", "DEL", "N", 1)
go

insert into location_group values("/", "KATY-WE", "DEL", "N", 1)
go

insert into location_group values("/", "KATYDOW", "DEL", "N", 1)
go

insert into location_group values("/", "KATYENSR", "DEL", "N", 1)
go

insert into location_group values("/", "KATYLONE", "DEL", "N", 1)
go

insert into location_group values("/", "KATYTGPL", "DEL", "N", 1)
go

insert into location_group values("/", "KATYTRSC", "DEL", "N", 1)
go

insert into location_group values("/", "KAWASAK", "DEL", "N", 1)
go

insert into location_group values("/", "KAZAKHS", "DEL", "N", 1)
go

insert into location_group values("/", "KEELUNG", "DEL", "N", 1)
go

insert into location_group values("/", "KEIHIN", "DEL", "N", 1)
go

insert into location_group values("/", "KENTUCK", "DEL", "N", 1)
go

insert into location_group values("/", "KETTON", "DEL", "N", 1)
go

insert into location_group values("/", "KHARG", "DEL", "N", 1)
go

insert into location_group values("/", "KIIRE", "DEL", "N", 1)
go

insert into location_group values("/", "KILLING", "DEL", "N", 1)
go

insert into location_group values("/", "KINDER", "DEL", "N", 1)
go

insert into location_group values("/", "KING", "DEL", "N", 1)
go

insert into location_group values("/", "KLAIPED", "DEL", "N", 1)
go

insert into location_group values("/", "KOBE", "DEL", "N", 1)
go

insert into location_group values("/", "KOBE/YO", "DEL", "N", 1)
go

insert into location_group values("/", "KOCH", "DEL", "N", 1)
go

insert into location_group values("/", "KOLE", "DEL", "N", 1)
go

insert into location_group values("/", "KOPER", "DEL", "N", 1)
go

insert into location_group values("/", "KOREA", "DEL", "N", 1)
go

insert into location_group values("/", "KOTKA", "DEL", "N", 1)
go

insert into location_group values("/", "KRALENDI", "DEL", "N", 1)
go

insert into location_group values("/", "KRONSTAD", "DEL", "N", 1)
go

insert into location_group values("/", "KRONSTAD", "RCP", "N", 1)
go

insert into location_group values("/", "KROTZSPR", "DEL", "N", 1)
go

insert into location_group values("/", "KUALABEU", "DEL", "N", 1)
go

insert into location_group values("/", "KUANTAN", "DEL", "N", 1)
go

insert into location_group values("/", "KUMUL", "DEL", "N", 1)
go

insert into location_group values("/", "KUWAIT", "DEL", "N", 1)
go

insert into location_group values("/", "KWANGYAN", "DEL", "N", 1)
go

insert into location_group values("/", "KWANTAN", "DEL", "N", 1)
go

insert into location_group values("/", "LA", "DEL", "N", 1)
go

insert into location_group values("/", "LA1", "DEL", "N", 1)
go

insert into location_group values("/", "LACORUNA", "DEL", "N", 1)
go

insert into location_group values("/", "LAEM", "DEL", "N", 1)
go

insert into location_group values("/", "LAGOS", "DEL", "N", 1)
go

insert into location_group values("/", "LAGUAIR", "DEL", "N", 1)
go

insert into location_group values("/", "LAKE", "DEL", "N", 1)
go

insert into location_group values("/", "LALANG", "DEL", "N", 1)
go

insert into location_group values("/", "LAREDO,", "DEL", "N", 1)
go

insert into location_group values("/", "LARNE", "DEL", "N", 1)
go

insert into location_group values("/", "LAS", "DEL", "N", 1)
go

insert into location_group values("/", "LAS1", "DEL", "N", 1)
go

insert into location_group values("/", "LASALINA", "DEL", "N", 1)
go

insert into location_group values("/", "LASPEZIA", "DEL", "N", 1)
go

insert into location_group values("/", "LAVAN", "DEL", "N", 1)
go

insert into location_group values("/", "LAVERA", "DEL", "N", 1)
go

insert into location_group values("/", "LAVRION", "DEL", "N", 1)
go

insert into location_group values("/", "LAZARO", "DEL", "N", 1)
go

insert into location_group values("/", "LE", "DEL", "N", 1)
go

insert into location_group values("/", "LEBANON", "DEL", "N", 1)
go

insert into location_group values("/", "LEIDY", "DEL", "N", 1)
go

insert into location_group values("/", "LEIDYCNG", "DEL", "N", 1)
go

insert into location_group values("/", "LEIDYNF", "DEL", "N", 1)
go

insert into location_group values("/", "LEIDYTR", "DEL", "N", 1)
go

insert into location_group values("/", "LEITH", "DEL", "N", 1)
go

insert into location_group values("/", "LEITH", "RCP", "N", 1)
go

insert into location_group values("/", "LEIXOES", "DEL", "N", 1)
go

insert into location_group values("/", "LENDAVA", "DEL", "N", 1)
go

insert into location_group values("/", "LIBECENT", "DEL", "N", 1)
go

insert into location_group values("/", "LIMASSO", "DEL", "N", 1)
go

insert into location_group values("/", "LIMAY", "DEL", "N", 1)
go

insert into location_group values("/", "LIMBE", "DEL", "N", 1)
go

insert into location_group values("/", "LIMERICK", "DEL", "N", 1)
go

insert into location_group values("/", "LIMETREE", "DEL", "N", 1)
go

insert into location_group values("/", "LIMON", "DEL", "N", 1)
go

insert into location_group values("/", "LIMON", "RCP", "N", 1)
go

insert into location_group values("/", "LINDEN", "DEL", "N", 1)
go

insert into location_group values("/", "LISBOA", "DEL", "N", 1)
go

insert into location_group values("/", "LISBOA", "RCP", "N", 1)
go

insert into location_group values("/", "LISBON", "DEL", "N", 1)
go

insert into location_group values("/", "LITTLEBR", "DEL", "N", 1)
go

insert into location_group values("/", "LIV&GEN", "DEL", "N", 1)
go

insert into location_group values("/", "LIV&GEN", "RCP", "N", 1)
go

insert into location_group values("/", "LIVERPOO", "DEL", "N", 1)
go

insert into location_group values("/", "LIVORNO", "DEL", "N", 1)
go

insert into location_group values("/", "LOMBO", "DEL", "N", 1)
go

insert into location_group values("/", "LOMBO", "RCP", "N", 1)
go

insert into location_group values("/", "LONDON", "DEL", "N", 1)
go

insert into location_group values("/", "LONG", "DEL", "N", 1)
go

insert into location_group values("/", "LOOP", "DEL", "N", 1)
go

insert into location_group values("/", "LOS", "DEL", "N", 1)
go

insert into location_group values("/", "LOS1", "DEL", "N", 1)
go

insert into location_group values("/", "LOUISIA", "DEL", "N", 1)
go

insert into location_group values("/", "LOUISVI", "DEL", "N", 1)
go

insert into location_group values("/", "LRC", "DEL", "N", 1)
go

insert into location_group values("/", "LUCINA", "DEL", "N", 1)
go

insert into location_group values("/", "Louisia", "DEL", "N", 1)
go

insert into location_group values("/", "Louisia", "RCP", "N", 1)
go

insert into location_group values("/", "M3", "DEL", "N", 1)
go

insert into location_group values("/", "MAASVLAK", "DEL", "N", 1)
go

insert into location_group values("/", "MAATSCHA", "DEL", "N", 1)
go

insert into location_group values("/", "MACEIO,", "DEL", "N", 1)
go

insert into location_group values("/", "MACEIO,1", "DEL", "N", 1)
go

insert into location_group values("/", "MADRAS", "DEL", "N", 1)
go

insert into location_group values("/", "MAINE", "DEL", "N", 1)
go

insert into location_group values("/", "MAINLIN", "DEL", "N", 1)
go

insert into location_group values("/", "MAINLIN1", "DEL", "N", 1)
go

insert into location_group values("/", "MAINLIN2", "DEL", "N", 1)
go

insert into location_group values("/", "MAINLINA", "DEL", "N", 1)
go

insert into location_group values("/", "MAINLINE", "DEL", "N", 1)
go

insert into location_group values("/", "MAINORSY", "DEL", "N", 1)
go

insert into location_group values("/", "MALAGA", "DEL", "N", 1)
go

insert into location_group values("/", "MALASIA", "DEL", "N", 1)
go

insert into location_group values("/", "MALAYSI", "DEL", "N", 1)
go

insert into location_group values("/", "MALMO", "DEL", "N", 1)
go

insert into location_group values("/", "MALMO", "RCP", "N", 1)
go

insert into location_group values("/", "MALMO308", "DEL", "N", 1)
go

insert into location_group values("/", "MALMO308", "RCP", "N", 1)
go

insert into location_group values("/", "MALMO313", "DEL", "N", 1)
go

insert into location_group values("/", "MALMO313", "RCP", "N", 1)
go

insert into location_group values("/", "MALONGO", "DEL", "N", 1)
go

insert into location_group values("/", "MALTA", "DEL", "N", 1)
go

insert into location_group values("/", "MAMMONAL", "DEL", "N", 1)
go

insert into location_group values("/", "MANATEE", "DEL", "N", 1)
go

insert into location_group values("/", "MANCHEST", "DEL", "N", 1)
go

insert into location_group values("/", "MANCHEST", "RCP", "N", 1)
go

insert into location_group values("/", "MANCHUR", "DEL", "N", 1)
go

insert into location_group values("/", "MANDJI", "DEL", "N", 1)
go

insert into location_group values("/", "MANGALOR", "DEL", "N", 1)
go

insert into location_group values("/", "MANILA", "DEL", "N", 1)
go

insert into location_group values("/", "MANILLA", "DEL", "N", 1)
go

insert into location_group values("/", "MANZANI", "DEL", "N", 1)
go

insert into location_group values("/", "MARCUS", "DEL", "N", 1)
go

insert into location_group values("/", "MARIFU", "DEL", "N", 1)
go

insert into location_group values("/", "MARIUPOL", "DEL", "N", 1)
go

insert into location_group values("/", "MARSA", "DEL", "N", 1)
go

insert into location_group values("/", "MARSABR", "DEL", "N", 1)
go

insert into location_group values("/", "MARSEIL", "DEL", "N", 1)
go

insert into location_group values("/", "MARYLAN", "DEL", "N", 1)
go

insert into location_group values("/", "MARYSVI", "DEL", "N", 1)
go

insert into location_group values("/", "MASILA", "DEL", "N", 1)
go

insert into location_group values("/", "MATANZA", "DEL", "N", 1)
go

insert into location_group values("/", "MAUREEN", "DEL", "N", 1)
go

insert into location_group values("/", "MAZHEKAI", "DEL", "N", 1)
go

insert into location_group values("/", "MBYA", "DEL", "N", 1)
go

insert into location_group values("/", "MED", "DEL", "N", 1)
go

insert into location_group values("/", "MEIZHOUW", "DEL", "N", 1)
go

insert into location_group values("/", "MEIZHOUW", "RCP", "N", 1)
go

insert into location_group values("/", "MERAK", "DEL", "N", 1)
go

insert into location_group values("/", "MERSA", "DEL", "N", 1)
go

insert into location_group values("/", "MERSAAL", "DEL", "N", 1)
go

insert into location_group values("/", "MERSIN", "DEL", "N", 1)
go

insert into location_group values("/", "MESAQATA", "DEL", "N", 1)
go

insert into location_group values("/", "MEXICO", "DEL", "N", 1)
go

insert into location_group values("/", "MIAMI", "DEL", "N", 1)
go

insert into location_group values("/", "MICHCITY", "DEL", "N", 1)
go

insert into location_group values("/", "MICHCON", "DEL", "N", 1)
go

insert into location_group values("/", "MICHIGA", "DEL", "N", 1)
go

insert into location_group values("/", "MICHNIP", "DEL", "N", 1)
go

insert into location_group values("/", "MICTGTPA", "DEL", "N", 1)
go

insert into location_group values("/", "MICTGTTR", "DEL", "N", 1)
go

insert into location_group values("/", "MID-COL", "DEL", "N", 1)
go

insert into location_group values("/", "MIDCOLS", "DEL", "N", 1)
go

insert into location_group values("/", "MIDDLEB", "DEL", "N", 1)
go

insert into location_group values("/", "MIDLAND", "DEL", "N", 1)
go

insert into location_group values("/", "MIDWEST", "DEL", "N", 1)
go

insert into location_group values("/", "MILAZZO", "DEL", "N", 1)
go

insert into location_group values("/", "MILFORD", "DEL", "N", 1)
go

insert into location_group values("/", "MINA", "DEL", "N", 1)
go

insert into location_group values("/", "MINA1", "DEL", "N", 1)
go

insert into location_group values("/", "MINAAL", "DEL", "N", 1)
go

insert into location_group values("/", "MINASAUD", "DEL", "N", 1)
go

insert into location_group values("/", "MINE", "DEL", "N", 1)
go

insert into location_group values("/", "MINNESO", "DEL", "N", 1)
go

insert into location_group values("/", "MISSISS", "DEL", "N", 1)
go

insert into location_group values("/", "MIZUSHI", "DEL", "N", 1)
go

insert into location_group values("/", "MJP", "DEL", "N", 1)
go

insert into location_group values("/", "MNDVILLE", "DEL", "N", 1)
go

insert into location_group values("/", "MNDVILLE", "RCP", "N", 1)
go

insert into location_group values("/", "MOBIL", "DEL", "N", 1)
go

insert into location_group values("/", "MOBILCOL", "DEL", "N", 1)
go

insert into location_group values("/", "MOBILE", "DEL", "N", 1)
go

insert into location_group values("/", "MOBILGTW", "DEL", "N", 1)
go

insert into location_group values("/", "MOBILKOC", "DEL", "N", 1)
go

insert into location_group values("/", "MOBILTNK", "DEL", "N", 1)
go

insert into location_group values("/", "MOERDIJK", "DEL", "N", 1)
go

insert into location_group values("/", "MOHAMMED", "DEL", "N", 1)
go

insert into location_group values("/", "MOMBASA", "DEL", "N", 1)
go

insert into location_group values("/", "MONGSTAT", "DEL", "N", 1)
go

insert into location_group values("/", "MONT4TRN", "DEL", "N", 1)
go

insert into location_group values("/", "MONTBELV", "DEL", "N", 1)
go

insert into location_group values("/", "MONTEVI", "DEL", "N", 1)
go

insert into location_group values("/", "MONTREAL", "DEL", "N", 1)
go

insert into location_group values("/", "MOPS", "DEL", "N", 1)
go

insert into location_group values("/", "MOROCCO", "DEL", "N", 1)
go

insert into location_group values("/", "MOSCOW", "OFF", "N", 1)
go

insert into location_group values("/", "MOUDI", "DEL", "N", 1)
go

insert into location_group values("/", "MT.", "DEL", "N", 1)
go

insert into location_group values("/", "MT.VERN", "DEL", "N", 1)
go

insert into location_group values("/", "MUANDA", "DEL", "N", 1)
go

insert into location_group values("/", "MULBERRY", "DEL", "N", 1)
go

insert into location_group values("/", "MYLAKI", "DEL", "N", 1)
go

insert into location_group values("/", "N", "DEL", "N", 1)
go

insert into location_group values("/", "N. BORDE", "DEL", "N", 1)
go

insert into location_group values("/", "N.BOARDE", "DEL", "N", 1)
go

insert into location_group values("/", "N.BORDE", "DEL", "N", 1)
go

insert into location_group values("/", "N.BORDE1", "DEL", "N", 1)
go

insert into location_group values("/", "N.E.B.P", "DEL", "N", 1)
go

insert into location_group values("/", "NAFTABAN", "DEL", "N", 1)
go

insert into location_group values("/", "NANJING", "DEL", "N", 1)
go

insert into location_group values("/", "NANTES,", "DEL", "N", 1)
go

insert into location_group values("/", "NANTONG", "DEL", "N", 1)
go

insert into location_group values("/", "NAPLES", "DEL", "N", 1)
go

insert into location_group values("/", "NATIONA", "DEL", "N", 1)
go

insert into location_group values("/", "NBORKEOK", "DEL", "N", 1)
go

insert into location_group values("/", "NEDERLAN", "DEL", "N", 1)
go

insert into location_group values("/", "NEDERLAN", "RCP", "N", 1)
go

insert into location_group values("/", "NEREFCO", "DEL", "N", 1)
go

insert into location_group values("/", "NETHER", "DEL", "N", 1)
go

insert into location_group values("/", "NETHERLA", "DEL", "N", 1)
go

insert into location_group values("/", "NETHRLA", "DEL", "N", 1)
go

insert into location_group values("/", "NEW", "DEL", "N", 1)
go

insert into location_group values("/", "NEW1", "DEL", "N", 1)
go

insert into location_group values("/", "NEW13", "RCP", "N", 1)
go

insert into location_group values("/", "NEW2", "DEL", "N", 1)
go

insert into location_group values("/", "NEW3", "DEL", "N", 1)
go

insert into location_group values("/", "NEW4", "DEL", "N", 1)
go

insert into location_group values("/", "NEW5", "DEL", "N", 1)
go

insert into location_group values("/", "NEW6", "DEL", "N", 1)
go

insert into location_group values("/", "NEW7", "DEL", "N", 1)
go

insert into location_group values("/", "NEW8", "DEL", "N", 1)
go

insert into location_group values("/", "NEWARK", "DEL", "N", 1)
go

insert into location_group values("/", "NEWJERSE", "DEL", "N", 1)
go

insert into location_group values("/", "NEWPORT", "DEL", "N", 1)
go

insert into location_group values("/", "NEWYORNY", "DEL", "N", 1)
go

insert into location_group values("/", "NFGDNYPO", "DEL", "N", 1)
go

insert into location_group values("/", "NFGS", "DEL", "N", 1)
go

insert into location_group values("/", "NFGS/TE", "DEL", "N", 1)
go

insert into location_group values("/", "NFGS1", "DEL", "N", 1)
go

insert into location_group values("/", "NFGS2", "DEL", "N", 1)
go

insert into location_group values("/", "NGPL", "DEL", "N", 1)
go

insert into location_group values("/", "NGPL1", "DEL", "N", 1)
go

insert into location_group values("/", "NGPL2", "DEL", "N", 1)
go

insert into location_group values("/", "NIAGARA", "DEL", "N", 1)
go

insert into location_group values("/", "NIAGARAA", "DEL", "N", 1)
go

insert into location_group values("/", "NIAGARAT", "DEL", "N", 1)
go

insert into location_group values("/", "NICARAG", "DEL", "N", 1)
go

insert into location_group values("/", "NIGAS", "DEL", "N", 1)
go

insert into location_group values("/", "NIGERIA", "DEL", "N", 1)
go

insert into location_group values("/", "NIGGBAY", "DEL", "N", 1)
go

insert into location_group values("/", "NIGGBAY", "RCP", "N", 1)
go

insert into location_group values("/", "NINGBO", "DEL", "N", 1)
go

insert into location_group values("/", "NINGBO1", "DEL", "N", 1)
go

insert into location_group values("/", "NIPSCO", "DEL", "N", 1)
go

insert into location_group values("/", "NIPSCONG", "DEL", "N", 1)
go

insert into location_group values("/", "NIPSCOPE", "DEL", "N", 1)
go

insert into location_group values("/", "NIPSCOTK", "DEL", "N", 1)
go

insert into location_group values("/", "NIT", "DEL", "N", 1)
go

insert into location_group values("/", "NOLA", "DEL", "N", 1)
go

insert into location_group values("/", "NORCO", "DEL", "N", 1)
go

insert into location_group values("/", "NORFOLK", "DEL", "N", 1)
go

insert into location_group values("/", "NORNE", "DEL", "N", 1)
go

insert into location_group values("/", "NORNE", "RCP", "N", 1)
go

insert into location_group values("/", "NORRK", "DEL", "N", 1)
go

insert into location_group values("/", "NORRK", "RCP", "N", 1)
go

insert into location_group values("/", "NORTH", "DEL", "N", 1)
go

insert into location_group values("/", "NORTH1", "DEL", "N", 1)
go

insert into location_group values("/", "NORTHWE", "DEL", "N", 1)
go

insert into location_group values("/", "NORWAY", "DEL", "N", 1)
go

insert into location_group values("/", "NOSL9921", "DEL", "N", 1)
go

insert into location_group values("/", "NOVANIT-", "DEL", "N", 1)
go

insert into location_group values("/", "NOVOROSS", "DEL", "N", 1)
go

insert into location_group values("/", "NYHARBOR", "DEL", "N", 1)
go

insert into location_group values("/", "OAKLAND", "DEL", "N", 1)
go

insert into location_group values("/", "OAKVILL", "DEL", "N", 1)
go

insert into location_group values("/", "ODESSA", "DEL", "N", 1)
go

insert into location_group values("/", "ODUDTERM", "DEL", "N", 1)
go

insert into location_group values("/", "ODUDTERM", "RCP", "N", 1)
go

insert into location_group values("/", "OFFSHOR", "DEL", "N", 1)
go

insert into location_group values("/", "OFFSHORE", "DEL", "N", 1)
go

insert into location_group values("/", "OGUENDJO", "DEL", "N", 1)
go

insert into location_group values("/", "OHIO", "DEL", "N", 1)
go

insert into location_group values("/", "OHIO1", "DEL", "N", 1)
go

insert into location_group values("/", "OHITA", "DEL", "N", 1)
go

insert into location_group values("/", "OJIBWAY", "DEL", "N", 1)
go

insert into location_group values("/", "OLYMPIC", "DEL", "N", 1)
go

insert into location_group values("/", "OMISALJ", "DEL", "N", 1)
go

insert into location_group values("/", "OMNIBUS", "DEL", "N", 1)
go

insert into location_group values("/", "ONSAN", "DEL", "N", 1)
go

insert into location_group values("/", "OPAL", "DEL", "N", 1)
go

insert into location_group values("/", "OPALNWPL", "DEL", "N", 1)
go

insert into location_group values("/", "OPENWRLD", "DEL", "N", 1)
go

insert into location_group values("/", "OSLO,", "DEL", "N", 1)
go

insert into location_group values("/", "OXELSND3", "DEL", "N", 1)
go

insert into location_group values("/", "OXSUND", "DEL", "N", 1)
go

insert into location_group values("/", "OXSUND", "RCP", "N", 1)
go

insert into location_group values("/", "OXYCAMAN", "DEL", "N", 1)
go

insert into location_group values("/", "OXYCAMCG", "DEL", "N", 1)
go

insert into location_group values("/", "OXYCAMLR", "DEL", "N", 1)
go

insert into location_group values("/", "OXYCAMNG", "DEL", "N", 1)
go

insert into location_group values("/", "OXYCAMST", "DEL", "N", 1)
go

insert into location_group values("/", "OXYUTOS", "DEL", "N", 1)
go

insert into location_group values("/", "PAJARITO", "DEL", "N", 1)
go

insert into location_group values("/", "PAKHI", "DEL", "N", 1)
go

insert into location_group values("/", "PAKISTAN", "DEL", "N", 1)
go

insert into location_group values("/", "PAKTANK", "DEL", "N", 1)
go

insert into location_group values("/", "PAKTBOTL", "DEL", "N", 1)
go

insert into location_group values("/", "PAKTROTT", "DEL", "N", 1)
go

insert into location_group values("/", "PALANKA", "DEL", "N", 1)
go

insert into location_group values("/", "PALOVERD", "DEL", "N", 1)
go

insert into location_group values("/", "PAMPILLA", "DEL", "N", 1)
go

insert into location_group values("/", "PAMPILLA", "RCP", "N", 1)
go

insert into location_group values("/", "PANHAND", "DEL", "N", 1)
go

insert into location_group values("/", "PAPHAITI", "DEL", "N", 1)
go

insert into location_group values("/", "PAPHAITI", "RCP", "N", 1)
go

insert into location_group values("/", "PARANAG", "DEL", "N", 1)
go

insert into location_group values("/", "PARKWAY", "DEL", "N", 1)
go

insert into location_group values("/", "PARKWAYU", "DEL", "N", 1)
go

insert into location_group values("/", "PASADENA", "DEL", "N", 1)
go

insert into location_group values("/", "PASCAGO", "DEL", "N", 1)
go

insert into location_group values("/", "PATANRCG", "DEL", "N", 1)
go

insert into location_group values("/", "PATANRTG", "DEL", "N", 1)
go

insert into location_group values("/", "PAUILLAC", "DEL", "N", 1)
go

insert into location_group values("/", "PAUILLAC", "RCP", "N", 1)
go

insert into location_group values("/", "PAULSBO", "DEL", "N", 1)
go

insert into location_group values("/", "PAUPITRE", "DEL", "N", 1)
go

insert into location_group values("/", "PAUPITRE", "RCP", "N", 1)
go

insert into location_group values("/", "PDVSA", "DEL", "N", 1)
go

insert into location_group values("/", "PDVSA", "RCP", "N", 1)
go

insert into location_group values("/", "PEAVEY", "DEL", "N", 1)
go

insert into location_group values("/", "PEMBROKE", "DEL", "N", 1)
go

insert into location_group values("/", "PENNINGT", "DEL", "N", 1)
go

insert into location_group values("/", "PENNSYL", "DEL", "N", 1)
go

insert into location_group values("/", "PENNYORK", "DEL", "N", 1)
go

insert into location_group values("/", "PEPCO/P", "DEL", "N", 1)
go

insert into location_group values("/", "PERMIAN", "DEL", "N", 1)
go

insert into location_group values("/", "PERTHAMB", "DEL", "N", 1)
go

insert into location_group values("/", "PERU", "DEL", "N", 1)
go

insert into location_group values("/", "PETAL", "DEL", "N", 1)
go

insert into location_group values("/", "PETROCI", "DEL", "N", 1)
go

insert into location_group values("/", "PHILADE", "DEL", "N", 1)
go

insert into location_group values("/", "PHILIPP", "DEL", "N", 1)
go

insert into location_group values("/", "PHILNYNK", "DEL", "N", 1)
go

insert into location_group values("/", "PHLADEL", "DEL", "N", 1)
go

insert into location_group values("/", "PIACAQU", "DEL", "N", 1)
go

insert into location_group values("/", "PITTSBRG", "OFF", "N", 1)
go

insert into location_group values("/", "PJM", "DEL", "N", 1)
go

insert into location_group values("/", "PLANTAT", "DEL", "N", 1)
go

insert into location_group values("/", "PLAQUEM", "DEL", "N", 1)
go

insert into location_group values("/", "POINT", "DEL", "N", 1)
go

insert into location_group values("/", "POINT1", "DEL", "N", 1)
go

insert into location_group values("/", "POINTE", "DEL", "N", 1)
go

insert into location_group values("/", "POL", "DEL", "N", 1)
go

insert into location_group values("/", "POLISH", "DEL", "N", 1)
go

insert into location_group values("/", "PORT", "DEL", "N", 1)
go

insert into location_group values("/", "PORT1", "DEL", "N", 1)
go

insert into location_group values("/", "PORT2", "DEL", "N", 1)
go

insert into location_group values("/", "PORT3", "DEL", "N", 1)
go

insert into location_group values("/", "PORT4", "DEL", "N", 1)
go

insert into location_group values("/", "PORT5", "DEL", "N", 1)
go

insert into location_group values("/", "PORT6", "DEL", "N", 1)
go

insert into location_group values("/", "PORT7", "DEL", "N", 1)
go

insert into location_group values("/", "PORTARTH", "DEL", "N", 1)
go

insert into location_group values("/", "PORTLAN", "DEL", "N", 1)
go

insert into location_group values("/", "PORTLAN1", "DEL", "N", 1)
go

insert into location_group values("/", "PORTLAND", "DEL", "N", 1)
go

insert into location_group values("/", "PORTNECH", "DEL", "N", 1)
go

insert into location_group values("/", "PORTO", "DEL", "N", 1)
go

insert into location_group values("/", "PORTO1", "DEL", "N", 1)
go

insert into location_group values("/", "PORTO2", "DEL", "N", 1)
go

insert into location_group values("/", "PORTUGAL", "DEL", "N", 1)
go

insert into location_group values("/", "POZOSCOL", "DEL", "N", 1)
go

insert into location_group values("/", "POZOSCOL", "RCP", "N", 1)
go

insert into location_group values("/", "PRAIA", "DEL", "N", 1)
go

insert into location_group values("/", "PRESIDI", "DEL", "N", 1)
go

insert into location_group values("/", "PRINOS", "DEL", "N", 1)
go

insert into location_group values("/", "PRIOLO", "DEL", "N", 1)
go

insert into location_group values("/", "PROVIDE", "DEL", "N", 1)
go

insert into location_group values("/", "PT. BAR", "DEL", "N", 1)
go

insert into location_group values("/", "PT. BAR", "RCP", "N", 1)
go

insert into location_group values("/", "PT.COR", "DEL", "N", 1)
go

insert into location_group values("/", "PT.COR", "RCP", "N", 1)
go

insert into location_group values("/", "PTJEROME", "DEL", "N", 1)
go

insert into location_group values("/", "PTJEROME", "RCP", "N", 1)
go

insert into location_group values("/", "PTT", "DEL", "N", 1)
go

insert into location_group values("/", "PUERRICO", "DEL", "N", 1)
go

insert into location_group values("/", "PUERRICO", "RCP", "N", 1)
go

insert into location_group values("/", "PUERTO", "DEL", "N", 1)
go

insert into location_group values("/", "PUERTO1", "DEL", "N", 1)
go

insert into location_group values("/", "PUERTOMI", "DEL", "N", 1)
go

insert into location_group values("/", "PUERTOOR", "DEL", "N", 1)
go

insert into location_group values("/", "PUNTA", "DEL", "N", 1)
go

insert into location_group values("/", "PUNTA1", "DEL", "N", 1)
go

insert into location_group values("/", "Peru", "DEL", "N", 1)
go

insert into location_group values("/", "Peru", "RCP", "N", 1)
go

insert into location_group values("/", "PkTnkSwd", "DEL", "N", 1)
go

insert into location_group values("/", "PkTnkSwd", "RCP", "N", 1)
go

insert into location_group values("/", "QUA", "DEL", "N", 1)
go

insert into location_group values("/", "QUESTAR", "DEL", "N", 1)
go

insert into location_group values("/", "QUINTERO", "DEL", "N", 1)
go

insert into location_group values("/", "RABON", "DEL", "N", 1)
go

insert into location_group values("/", "RAIL", "DEL", "N", 1)
go

insert into location_group values("/", "RAS", "DEL", "N", 1)
go

insert into location_group values("/", "RASALKHA", "DEL", "N", 1)
go

insert into location_group values("/", "RASG", "DEL", "N", 1)
go

insert into location_group values("/", "RASLAN", "DEL", "N", 1)
go

insert into location_group values("/", "RASLANUF", "DEL", "N", 1)
go

insert into location_group values("/", "RASSHUK", "DEL", "N", 1)
go

insert into location_group values("/", "RASTANUR", "DEL", "N", 1)
go

insert into location_group values("/", "RAUMA", "DEL", "N", 1)
go

insert into location_group values("/", "RAVENNA", "DEL", "N", 1)
go

insert into location_group values("/", "RAYONG", "DEL", "N", 1)
go

insert into location_group values("/", "RBCT", "DEL", "N", 1)
go

insert into location_group values("/", "RECIFE", "DEL", "N", 1)
go

insert into location_group values("/", "RECIFE,", "DEL", "N", 1)
go

insert into location_group values("/", "RECIFE1", "DEL", "N", 1)
go

insert into location_group values("/", "REFUGIOT", "DEL", "N", 1)
go

insert into location_group values("/", "RENI", "DEL", "N", 1)
go

insert into location_group values("/", "RICHARD", "DEL", "N", 1)
go

insert into location_group values("/", "RICHMON", "DEL", "N", 1)
go

insert into location_group values("/", "RICHMOND", "DEL", "N", 1)
go

insert into location_group values("/", "RIGA", "DEL", "N", 1)
go

insert into location_group values("/", "RIGA", "RCP", "N", 1)
go

insert into location_group values("/", "RIJEKA", "DEL", "N", 1)
go

insert into location_group values("/", "RIO", "DEL", "N", 1)
go

insert into location_group values("/", "RIO1", "DEL", "N", 1)
go

insert into location_group values("/", "RIOGRAND", "DEL", "N", 1)
go

insert into location_group values("/", "RIORSECA", "DEL", "N", 1)
go

insert into location_group values("/", "RIVERHE", "DEL", "N", 1)
go

insert into location_group values("/", "ROCKY", "DEL", "N", 1)
go

insert into location_group values("/", "ROMANIA", "DEL", "N", 1)
go

insert into location_group values("/", "ROMEGA", "DEL", "N", 1)
go

insert into location_group values("/", "ROSARIO", "DEL", "N", 1)
go

insert into location_group values("/", "ROT+E-V", "DEL", "N", 1)
go

insert into location_group values("/", "ROT+E-V", "RCP", "N", 1)
go

insert into location_group values("/", "ROTT+E+P", "DEL", "N", 1)
go

insert into location_group values("/", "ROTT+E+P", "RCP", "N", 1)
go

insert into location_group values("/", "ROTT+E+V", "DEL", "N", 1)
go

insert into location_group values("/", "ROTT+E+V", "RCP", "N", 1)
go

insert into location_group values("/", "ROTTERDA", "DEL", "N", 1)
go

insert into location_group values("/", "ROUEN", "DEL", "N", 1)
go

insert into location_group values("/", "ROUSSE", "DEL", "N", 1)
go

insert into location_group values("/", "RTRFONLY", "DEL", "N", 1)
go

insert into location_group values("/", "RTRFONLY", "RCP", "N", 1)
go

insert into location_group values("/", "RUNNIOWA", "DEL", "N", 1)
go

insert into location_group values("/", "RUSSIAN", "DEL", "N", 1)
go

insert into location_group values("/", "S AFRICA", "DEL", "N", 1)
go

insert into location_group values("/", "S AFRICA", "RCP", "N", 1)
go

insert into location_group values("/", "SABINE", "DEL", "N", 1)
go

insert into location_group values("/", "SABINIHT", "DEL", "N", 1)
go

insert into location_group values("/", "SAINT", "DEL", "N", 1)
go

insert into location_group values("/", "SAINT1", "DEL", "N", 1)
go

insert into location_group values("/", "SALINA", "DEL", "N", 1)
go

insert into location_group values("/", "SALONIC", "DEL", "N", 1)
go

insert into location_group values("/", "SALONICA", "DEL", "N", 1)
go

insert into location_group values("/", "SAN", "DEL", "N", 1)
go

insert into location_group values("/", "SAN1", "DEL", "N", 1)
go

insert into location_group values("/", "SAN2", "DEL", "N", 1)
go

insert into location_group values("/", "SAN3", "DEL", "N", 1)
go

insert into location_group values("/", "SAN4", "DEL", "N", 1)
go

insert into location_group values("/", "SANFRANS", "DEL", "N", 1)
go

insert into location_group values("/", "SANJOSE", "DEL", "N", 1)
go

insert into location_group values("/", "SANSALVA", "DEL", "N", 1)
go

insert into location_group values("/", "SANTA", "DEL", "N", 1)
go

insert into location_group values("/", "SANTOS", "DEL", "N", 1)
go

insert into location_group values("/", "SANTOS,", "DEL", "N", 1)
go

insert into location_group values("/", "SANTOS/", "DEL", "N", 1)
go

insert into location_group values("/", "SANTOS/1", "DEL", "N", 1)
go

insert into location_group values("/", "SANTOS1", "DEL", "N", 1)
go

insert into location_group values("/", "SARNIA", "DEL", "N", 1)
go

insert into location_group values("/", "SARROCH", "DEL", "N", 1)
go

insert into location_group values("/", "SARROCH", "RCP", "N", 1)
go

insert into location_group values("/", "SAUDABAY", "DEL", "N", 1)
go

insert into location_group values("/", "SAUDABAY", "RCP", "N", 1)
go

insert into location_group values("/", "SAUDI", "DEL", "N", 1)
go

insert into location_group values("/", "SAVANNA", "DEL", "N", 1)
go

insert into location_group values("/", "SAVANNAH", "DEL", "N", 1)
go

insert into location_group values("/", "SAVONA", "DEL", "N", 1)
go

insert into location_group values("/", "SCOTLAND", "DEL", "N", 1)
go

insert into location_group values("/", "SEA", "DEL", "N", 1)
go

insert into location_group values("/", "SEALSAND", "DEL", "N", 1)
go

insert into location_group values("/", "SEATTLE", "DEL", "N", 1)
go

insert into location_group values("/", "SECAUCU", "DEL", "N", 1)
go

insert into location_group values("/", "SEN", "DEL", "N", 1)
go

insert into location_group values("/", "SEPETIB", "DEL", "N", 1)
go

insert into location_group values("/", "SERIA", "DEL", "N", 1)
go

insert into location_group values("/", "SERTAOZ", "DEL", "N", 1)
go

insert into location_group values("/", "SETE,", "DEL", "N", 1)
go

insert into location_group values("/", "SETUBAL", "DEL", "N", 1)
go

insert into location_group values("/", "SETUBAL", "RCP", "N", 1)
go

insert into location_group values("/", "SHANGHAI", "DEL", "N", 1)
go

insert into location_group values("/", "SHANNON", "DEL", "N", 1)
go

insert into location_group values("/", "SHANNON", "RCP", "N", 1)
go

insert into location_group values("/", "SHANTOU", "DEL", "N", 1)
go

insert into location_group values("/", "SHELHAVN", "DEL", "N", 1)
go

insert into location_group values("/", "SHELHAVN", "RCP", "N", 1)
go

insert into location_group values("/", "SHELLGOT", "DEL", "N", 1)
go

insert into location_group values("/", "SHELLNET", "DEL", "N", 1)
go

insert into location_group values("/", "SHELLPUL", "DEL", "N", 1)
go

insert into location_group values("/", "SHELLTGT", "DEL", "N", 1)
go

insert into location_group values("/", "SHELLTRN", "DEL", "N", 1)
go

insert into location_group values("/", "SHELMOER", "DEL", "N", 1)
go

insert into location_group values("/", "SHELMOER", "RCP", "N", 1)
go

insert into location_group values("/", "SHELTIRO", "DEL", "N", 1)
go

insert into location_group values("/", "SHOREHA", "DEL", "N", 1)
go

insert into location_group values("/", "SIDI", "DEL", "N", 1)
go

insert into location_group values("/", "SIKKA", "DEL", "N", 1)
go

insert into location_group values("/", "SINES", "DEL", "N", 1)
go

insert into location_group values("/", "SING", "DEL", "N", 1)
go

insert into location_group values("/", "SING", "OFF", "N", 1)
go

insert into location_group values("/", "SINGAPOR", "DEL", "N", 1)
go

insert into location_group values("/", "SIR", "DEL", "N", 1)
go

insert into location_group values("/", "SIRRI", "DEL", "N", 1)
go

insert into location_group values("/", "SKIKDA", "DEL", "N", 1)
go

insert into location_group values("/", "SKIRRA", "DEL", "N", 1)
go

insert into location_group values("/", "SLAGENTA", "DEL", "N", 1)
go

insert into location_group values("/", "SLUISKI", "DEL", "N", 1)
go

insert into location_group values("/", "SNAM", "DEL", "N", 1)
go

insert into location_group values("/", "SONAT", "DEL", "N", 1)
go

insert into location_group values("/", "SORRSTOR", "DEL", "N", 1)
go

insert into location_group values("/", "SOUTAFRI", "DEL", "N", 1)
go

insert into location_group values("/", "SOUTH", "DEL", "N", 1)
go

insert into location_group values("/", "SOUTH1", "DEL", "N", 1)
go

insert into location_group values("/", "SOUTH2", "DEL", "N", 1)
go

insert into location_group values("/", "SOYO", "DEL", "N", 1)
go

insert into location_group values("/", "SPAIN", "DEL", "N", 1)
go

insert into location_group values("/", "SPC", "DEL", "N", 1)
go

insert into location_group values("/", "SPEL", "DEL", "N", 1)
go

insert into location_group values("/", "SRI", "DEL", "N", 1)
go

insert into location_group values("/", "SRIRACHA", "DEL", "N", 1)
go

insert into location_group values("/", "ST PETER", "DEL", "N", 1)
go

insert into location_group values("/", "ST.", "DEL", "N", 1)
go

insert into location_group values("/", "ST. ROSE", "DEL", "N", 1)
go

insert into location_group values("/", "ST.CROIX", "DEL", "N", 1)
go

insert into location_group values("/", "ST.EUSTA", "DEL", "N", 1)
go

insert into location_group values("/", "ST.EUSTA", "RCP", "N", 1)
go

insert into location_group values("/", "ST.JAMES", "DEL", "N", 1)
go

insert into location_group values("/", "ST.PETE", "DEL", "N", 1)
go

insert into location_group values("/", "STANLOW", "DEL", "N", 1)
go

insert into location_group values("/", "STANLOW", "RCP", "N", 1)
go

insert into location_group values("/", "STARAZA", "DEL", "N", 1)
go

insert into location_group values("/", "STATFJOR", "DEL", "N", 1)
go

insert into location_group values("/", "STAVANGE", "DEL", "N", 1)
go

insert into location_group values("/", "STCLAI", "DEL", "N", 1)
go

insert into location_group values("/", "STCLAIA", "DEL", "N", 1)
go

insert into location_group values("/", "STENSND8", "DEL", "N", 1)
go

insert into location_group values("/", "STENSND8", "RCP", "N", 1)
go

insert into location_group values("/", "STENSND9", "DEL", "N", 1)
go

insert into location_group values("/", "STENSND9", "RCP", "N", 1)
go

insert into location_group values("/", "STENSUND", "DEL", "N", 1)
go

insert into location_group values("/", "STENSUND", "RCP", "N", 1)
go

insert into location_group values("/", "STJAMES", "DEL", "N", 1)
go

insert into location_group values("/", "STJAMLA", "DEL", "N", 1)
go

insert into location_group values("/", "STOCKHO", "DEL", "N", 1)
go

insert into location_group values("/", "STSKarls", "DEL", "N", 1)
go

insert into location_group values("/", "STSKarls", "RCP", "N", 1)
go

insert into location_group values("/", "STSMalmo", "DEL", "N", 1)
go

insert into location_group values("/", "STSMalmo", "RCP", "N", 1)
go

insert into location_group values("/", "STSOxelo", "DEL", "N", 1)
go

insert into location_group values("/", "STSOxelo", "RCP", "N", 1)
go

insert into location_group values("/", "STSstenu", "DEL", "N", 1)
go

insert into location_group values("/", "STSstenu", "RCP", "N", 1)
go

insert into location_group values("/", "STURE", "DEL", "N", 1)
go

insert into location_group values("/", "SULLOM", "DEL", "N", 1)
go

insert into location_group values("/", "SUMAS", "DEL", "N", 1)
go

insert into location_group values("/", "SUNSHIN", "DEL", "N", 1)
go

insert into location_group values("/", "SWANSEA", "DEL", "N", 1)
go

insert into location_group values("/", "SWEDEN", "DEL", "N", 1)
go

insert into location_group values("/", "SWITZER", "DEL", "N", 1)
go

insert into location_group values("/", "SYRIA", "DEL", "N", 1)
go

insert into location_group values("/", "TABANGAO", "DEL", "N", 1)
go

insert into location_group values("/", "TAFT,", "DEL", "N", 1)
go

insert into location_group values("/", "TAICHUNG", "DEL", "N", 1)
go

insert into location_group values("/", "TAIWAN", "DEL", "N", 1)
go

insert into location_group values("/", "TAKASAYO", "DEL", "N", 1)
go

insert into location_group values("/", "TAKOLA", "DEL", "N", 1)
go

insert into location_group values("/", "TALARA", "DEL", "N", 1)
go

insert into location_group values("/", "TALLINN", "DEL", "N", 1)
go

insert into location_group values("/", "TAMPA", "DEL", "N", 1)
go

insert into location_group values("/", "TANGA", "DEL", "N", 1)
go

insert into location_group values("/", "TANJUNG", "DEL", "N", 1)
go

insert into location_group values("/", "TAO", "DEL", "N", 1)
go

insert into location_group values("/", "TARANTO", "DEL", "N", 1)
go

insert into location_group values("/", "TARBERT", "DEL", "N", 1)
go

insert into location_group values("/", "TARNOW", "DEL", "N", 1)
go

insert into location_group values("/", "TARRAGON", "DEL", "N", 1)
go

insert into location_group values("/", "TARTOUS", "DEL", "N", 1)
go

insert into location_group values("/", "TASMANI", "DEL", "N", 1)
go

insert into location_group values("/", "TCOPOOL", "DEL", "N", 1)
go

insert into location_group values("/", "TCPL", "DEL", "N", 1)
go

insert into location_group values("/", "TCPL1", "DEL", "N", 1)
go

insert into location_group values("/", "TCPL2", "DEL", "N", 1)
go

insert into location_group values("/", "TCPL3", "DEL", "N", 1)
go

insert into location_group values("/", "TCPL4", "DEL", "N", 1)
go

insert into location_group values("/", "TCPL5", "DEL", "N", 1)
go

insert into location_group values("/", "TCPLWADD", "DEL", "N", 1)
go

insert into location_group values("/", "TCPUNIDA", "DEL", "N", 1)
go

insert into location_group values("/", "TEESSIDE", "DEL", "N", 1)
go

insert into location_group values("/", "TEMA", "DEL", "N", 1)
go

insert into location_group values("/", "TENERIFE", "DEL", "N", 1)
go

insert into location_group values("/", "TENN", "DEL", "N", 1)
go

insert into location_group values("/", "TENNPOOL", "DEL", "N", 1)
go

insert into location_group values("/", "TERBNCGL", "DEL", "N", 1)
go

insert into location_group values("/", "TERMINU", "DEL", "N", 1)
go

insert into location_group values("/", "TERNEUZE", "DEL", "N", 1)
go

insert into location_group values("/", "TETCO", "DEL", "N", 1)
go

insert into location_group values("/", "TETCO-C", "DEL", "N", 1)
go

insert into location_group values("/", "TETCO-C1", "DEL", "N", 1)
go

insert into location_group values("/", "TETCO-E", "DEL", "N", 1)
go

insert into location_group values("/", "TETCO-E1", "DEL", "N", 1)
go

insert into location_group values("/", "TETCO-S", "DEL", "N", 1)
go

insert into location_group values("/", "TETCO-W", "DEL", "N", 1)
go

insert into location_group values("/", "TETCO1", "DEL", "N", 1)
go

insert into location_group values("/", "TETCO2", "DEL", "N", 1)
go

insert into location_group values("/", "TETCOPO", "DEL", "N", 1)
go

insert into location_group values("/", "TETNEY", "DEL", "N", 1)
go

insert into location_group values("/", "TETNEY", "RCP", "N", 1)
go

insert into location_group values("/", "TEXACOES", "DEL", "N", 1)
go

insert into location_group values("/", "TEXAS", "DEL", "N", 1)
go

insert into location_group values("/", "TEXAS1", "DEL", "N", 1)
go

insert into location_group values("/", "TEXASCIT", "DEL", "N", 1)
go

insert into location_group values("/", "TGP", "DEL", "N", 1)
go

insert into location_group values("/", "TGPL", "DEL", "N", 1)
go

insert into location_group values("/", "TGPL-10", "DEL", "N", 1)
go

insert into location_group values("/", "TGPL-50", "DEL", "N", 1)
go

insert into location_group values("/", "TGPL-80", "DEL", "N", 1)
go

insert into location_group values("/", "TGPL-HA", "DEL", "N", 1)
go

insert into location_group values("/", "TGPL1", "DEL", "N", 1)
go

insert into location_group values("/", "TGPL4", "DEL", "N", 1)
go

insert into location_group values("/", "TGPL5", "DEL", "N", 1)
go

insert into location_group values("/", "TGPL6", "DEL", "N", 1)
go

insert into location_group values("/", "TGT", "DEL", "N", 1)
go

insert into location_group values("/", "TGTCNTRV", "DEL", "N", 1)
go

insert into location_group values("/", "THAILAND", "DEL", "N", 1)
go

insert into location_group values("/", "THAMES", "DEL", "N", 1)
go

insert into location_group values("/", "THAMES", "RCP", "N", 1)
go

insert into location_group values("/", "THEVENAR", "DEL", "N", 1)
go

insert into location_group values("/", "TIERRA", "DEL", "N", 1)
go

insert into location_group values("/", "TILLBUR", "DEL", "N", 1)
go

insert into location_group values("/", "TNCOLUNI", "DEL", "N", 1)
go

insert into location_group values("/", "TNNIAGRA", "DEL", "N", 1)
go

insert into location_group values("/", "TNWESTMN", "DEL", "N", 1)
go

insert into location_group values("/", "TO", "DEL", "N", 1)
go

insert into location_group values("/", "TOGLIAT", "DEL", "N", 1)
go

insert into location_group values("/", "TOKUYAMA", "DEL", "N", 1)
go

insert into location_group values("/", "TOKYO", "DEL", "N", 1)
go

insert into location_group values("/", "TOKYO", "OFF", "N", 1)
go

insert into location_group values("/", "TOLEDO,", "DEL", "N", 1)
go

insert into location_group values("/", "TOMAS", "DEL", "N", 1)
go

insert into location_group values("/", "TORONTO", "DEL", "N", 1)
go

insert into location_group values("/", "TOTALREF", "DEL", "N", 1)
go

insert into location_group values("/", "TRANMERE", "DEL", "N", 1)
go

insert into location_group values("/", "TRANMERE", "RCP", "N", 1)
go

insert into location_group values("/", "TRANSCO", "DEL", "N", 1)
go

insert into location_group values("/", "TRANSCO1", "DEL", "N", 1)
go

insert into location_group values("/", "TRANSCO2", "DEL", "N", 1)
go

insert into location_group values("/", "TRANSCO3", "DEL", "N", 1)
go

insert into location_group values("/", "TRANSCO4", "DEL", "N", 1)
go

insert into location_group values("/", "TRANSCO5", "DEL", "N", 1)
go

insert into location_group values("/", "TRANSCO6", "DEL", "N", 1)
go

insert into location_group values("/", "TRANSCO7", "DEL", "N", 1)
go

insert into location_group values("/", "TRANSCOH", "DEL", "N", 1)
go

insert into location_group values("/", "TRANSCOL", "DEL", "N", 1)
go

insert into location_group values("/", "TRANSCOW", "DEL", "N", 1)
go

insert into location_group values("/", "TRENTON", "DEL", "N", 1)
go

insert into location_group values("/", "TRIESTE", "DEL", "N", 1)
go

insert into location_group values("/", "TRINIDAD", "DEL", "N", 1)
go

insert into location_group values("/", "TRNKLNTE", "DEL", "N", 1)
go

insert into location_group values("/", "TRNSCO65", "DEL", "N", 1)
go

insert into location_group values("/", "TRUNKLI", "DEL", "N", 1)
go

insert into location_group values("/", "TRUNKLI1", "DEL", "N", 1)
go

insert into location_group values("/", "TRUNKLI2", "DEL", "N", 1)
go

insert into location_group values("/", "TRZOS365", "DEL", "N", 1)
go

insert into location_group values("/", "TRZOS485", "DEL", "N", 1)
go

insert into location_group values("/", "TUAPSE", "DEL", "N", 1)
go

insert into location_group values("/", "TUMACO", "DEL", "N", 1)
go

insert into location_group values("/", "TUNISIA", "DEL", "N", 1)
go

insert into location_group values("/", "TURKEY", "DEL", "N", 1)
go

insert into location_group values("/", "TUXPAN", "DEL", "N", 1)
go

insert into location_group values("/", "TUXPAN/", "DEL", "N", 1)
go

insert into location_group values("/", "TUXPMEXI", "DEL", "N", 1)
go

insert into location_group values("/", "UDANG", "DEL", "N", 1)
go

insert into location_group values("/", "UGPL/ER", "DEL", "N", 1)
go

insert into location_group values("/", "UGPL/VE", "DEL", "N", 1)
go

insert into location_group values("/", "UJUNG", "DEL", "N", 1)
go

insert into location_group values("/", "UK", "DEL", "N", 1)
go

insert into location_group values("/", "UK", "RCP", "N", 1)
go

insert into location_group values("/", "UKRAINE", "DEL", "N", 1)
go

insert into location_group values("/", "ULSAN", "DEL", "N", 1)
go

insert into location_group values("/", "UMM", "DEL", "N", 1)
go

insert into location_group values("/", "UNION", "DEL", "N", 1)
go

insert into location_group values("/", "UNITED", "DEL", "N", 1)
go

insert into location_group values("/", "UNIVERSA", "DEL", "N", 1)
go

insert into location_group values("/", "UNKNOWN", "DEL", "N", 1)
go

insert into location_group values("/", "UNRESTR", "DEL", "N", 1)
go

insert into location_group values("/", "URAN", "DEL", "N", 1)
go

insert into location_group values("/", "URUGUAI", "DEL", "N", 1)
go

insert into location_group values("/", "USA", "DEL", "N", 1)
go

insert into location_group values("/", "USA", "RCP", "N", 1)
go

insert into location_group values("/", "USGULF", "DEL", "N", 1)
go

insert into location_group values("/", "UTOSTRNK", "DEL", "N", 1)
go

insert into location_group values("/", "V", "DEL", "N", 1)
go

insert into location_group values("/", "VADINAR", "DEL", "N", 1)
go

insert into location_group values("/", "VADO", "DEL", "N", 1)
go

insert into location_group values("/", "VALENCI", "DEL", "N", 1)
go

insert into location_group values("/", "VANCOUV", "DEL", "N", 1)
go

insert into location_group values("/", "VARNA", "DEL", "N", 1)
go

insert into location_group values("/", "VENEZU", "DEL", "N", 1)
go

insert into location_group values("/", "VENICE", "DEL", "N", 1)
go

insert into location_group values("/", "VENTSPI", "DEL", "N", 1)
go

insert into location_group values("/", "VENTSPIC", "DEL", "N", 1)
go

insert into location_group values("/", "VENTURA", "DEL", "N", 1)
go

insert into location_group values("/", "VIETNAM", "DEL", "N", 1)
go

insert into location_group values("/", "VIGO", "DEL", "N", 1)
go

insert into location_group values("/", "VIRGINI", "DEL", "N", 1)
go

insert into location_group values("/", "VISTA", "RCP", "N", 1)
go

insert into location_group values("/", "VITORIA", "DEL", "N", 1)
go

insert into location_group values("/", "VITORIA1", "DEL", "N", 1)
go

insert into location_group values("/", "VIZAG", "DEL", "N", 1)
go

insert into location_group values("/", "VOTTGoth", "DEL", "N", 1)
go

insert into location_group values("/", "VOTTGoth", "RCP", "N", 1)
go

insert into location_group values("/", "VUNGTAN", "DEL", "N", 1)
go

insert into location_group values("/", "WADDINGT", "DEL", "N", 1)
go

insert into location_group values("/", "WADI", "DEL", "N", 1)
go

insert into location_group values("/", "WATERSTN", "DEL", "N", 1)
go

insert into location_group values("/", "WATERSTN", "RCP", "N", 1)
go

insert into location_group values("/", "WEST", "DEL", "N", 1)
go

insert into location_group values("/", "WEST1", "DEL", "N", 1)
go

insert into location_group values("/", "WESTERN", "DEL", "N", 1)
go

insert into location_group values("/", "WESTKATY", "DEL", "N", 1)
go

insert into location_group values("/", "WHANGERA", "DEL", "N", 1)
go

insert into location_group values("/", "WHANGERA", "RCP", "N", 1)
go

insert into location_group values("/", "WHITEGAT", "DEL", "N", 1)
go

insert into location_group values("/", "WILHEMS", "DEL", "N", 1)
go

insert into location_group values("/", "WILLEMST", "DEL", "N", 1)
go

insert into location_group values("/", "WILMING", "DEL", "N", 1)
go

insert into location_group values("/", "WILMING1", "DEL", "N", 1)
go

insert into location_group values("/", "WISMAR", "DEL", "N", 1)
go

insert into location_group values("/", "WITNELL", "DEL", "N", 1)
go

insert into location_group values("/", "WMONROE", "DEL", "N", 1)
go

insert into location_group values("/", "YABUCO", "DEL", "N", 1)
go

insert into location_group values("/", "YACUIBA", "DEL", "N", 1)
go

insert into location_group values("/", "YALOVA", "DEL", "N", 1)
go

insert into location_group values("/", "YARIMCA", "DEL", "N", 1)
go

insert into location_group values("/", "YEMEN", "DEL", "N", 1)
go

insert into location_group values("/", "YEMEN", "RCP", "N", 1)
go

insert into location_group values("/", "YEOSU", "DEL", "N", 1)
go

insert into location_group values("/", "YOKKAIC", "DEL", "N", 1)
go

insert into location_group values("/", "YOKOHAM", "DEL", "N", 1)
go

insert into location_group values("/", "YORK,UK", "DEL", "N", 1)
go

insert into location_group values("/", "YORKTOWN", "DEL", "N", 1)
go

insert into location_group values("/", "YUZHNY", "DEL", "N", 1)
go

insert into location_group values("/", "Yemen", "DEL", "N", 1)
go

insert into location_group values("/", "Yemen", "RCP", "N", 1)
go

insert into location_group values("/", "ZADAR", "DEL", "N", 1)
go

insert into location_group values("/", "ZAFIRO", "DEL", "N", 1)
go

insert into location_group values("/", "ZAFIRO", "RCP", "N", 1)
go

insert into location_group values("/", "ZAIRE", "DEL", "N", 1)
go

insert into location_group values("/", "ZEIT", "DEL", "N", 1)
go

insert into location_group values("/", "ZHANGJIA", "DEL", "N", 1)
go

insert into location_group values("/", "ZHANJIAN", "DEL", "N", 1)
go

insert into location_group values("/", "ZHENHAI", "DEL", "N", 1)
go

insert into location_group values("/", "ZIRKU", "DEL", "N", 1)
go

insert into location_group values("/", "ZONESL", "DEL", "N", 1)
go

insert into location_group values("/", "ZUEITINA", "DEL", "N", 1)
go

insert into location_group values("/", "humriv", "DEL", "N", 1)
go

insert into location_group values("/", "humriv", "RCP", "N", 1)
go

insert into location_group values("ROTTERDA", "EXCLVOTT", "DEL", "N", 1)
go

insert into location_group values("USA", "NC", "RCP", "N", 1)
go

