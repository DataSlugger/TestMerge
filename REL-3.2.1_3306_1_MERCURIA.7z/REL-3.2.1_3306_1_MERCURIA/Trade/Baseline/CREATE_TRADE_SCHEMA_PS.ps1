# CREATE_TRADE_SCHEMA_PS.ps1
#    This script is used to create an ICTS trade schema in the selected database. The
#    user can provide the db connection info via command line
#
#      Usage:
#         PowerShell .\CREATE_TRADE_SCHEMA_PS.ps1 -S <server> 
#                                                 -U <login> 
#                                                 -P <pwd> 
#                                                 -D <name of trade database>
#
#      Dependency:
#        It uses the functions stored in
#           CommonDBUpgradeSupportToolSet module
#           TradeDBUpgradeSupportToolSet module
#
#     Created By         : Peter Lo   04/14/2016
#     Last Edited By     : Peter Lo   11/08/2016
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
# *****************************************************************************************

Param (
  [Parameter(Mandatory=$true,HelpMessage="You must provide a server instance name")]
     [string]$S,
  [string]$U,
  [string]$P,
  [Parameter(Mandatory=$true,HelpMessage="You must provide the name of a trade database")]
     [string]$D
)

# get PS version
$ver = $PsVersionTable.psversion.major
# Check to see if it's V3
If ($ver -lt 3) 
{ 
   Write-Host "You need PS version v3.0 or later in order to run this script - exiting" 
   return
}

# Everything that follows is V3 or later

$ScriptRootPath = $pwd.Path

$DOCDIR = [Environment]::GetFolderPath("MyDocuments")
$PSMODULE_DESTDIR = "$DOCDIR\WindowsPowerShell"

Write-Host "Creating subfolder 'WindowsPowerShell' under '$DOCDIR' if it does not exist ...";
if (!(Test-Path -Path $PSMODULE_DESTDIR))
{
   New-Item -ItemType directory -Path $PSMODULE_DESTDIR
}

Write-Host "Creating subfolder 'Modules' under '$DOCDIR\WindowsPowerShell' if it does not exist ...";
$PSMODULE_DESTDIR = "$DOCDIR\WindowsPowerShell\Modules"
if (!(Test-Path -Path $PSMODULE_DESTDIR))
{
   New-Item -ItemType directory -Path $PSMODULE_DESTDIR
}

Write-Host "Copying the latest version of PowerShell sharable modules for schema creation ...";
Set-Location -Path $ScriptRootPath
Set-Location "..\..\PowerShellModules";
$PSMODULE_SRCPATH = $pwd.Path
$SRCPATH="$PSMODULE_SRCPATH\CommonDBUpgradeSupportToolSet";
Copy-Item -Path $SRCPATH  -Destination $PSMODULE_DESTDIR -force -recurse
#
Write-Host "Copying the latest version of PowerShell modules supporting PASS schema creation ...";
$SRCPATH="$PSMODULE_SRCPATH\PassDBUpgradeSupportToolSet";
Copy-Item -Path $SRCPATH -Destination $PSMODULE_DESTDIR -force -recurse
#
Write-Host "Copying the latest version of PowerShell modules supporting TRADE schema creation ...";
$SRCPATH="$PSMODULE_SRCPATH\TradeDBUpgradeSupportToolSet";
Copy-Item -Path $SRCPATH -Destination $PSMODULE_DESTDIR -force -recurse

Set-Location -Path $ScriptRootPath

$Server=$S
$Login=$U
$Password=$P
$Database=$D

$DebugOn=$true

if ($DebugOn)
{
   Write-Host "DEBUG: Server is '$Server'"
   Write-Host "DEBUG: Login is '$Login'"
   Write-Host "DEBUG: Password is '$Password'"
   Write-Host "DEBUG: Database is '$Database'"
   Write-Host " "
}

if ($Database -eq "master" -or $Database -eq "msdb" -or $Database -eq "tempdb" -or $Database -eq "model")
{ 
   Write-Host "You must provide the name of an ICTS trade database for the argument '-D'" 
   exit
}

# Before importing PS modules, we need to make sure that the modules are in the module search path
$module_path = $env:PSModulePath
$str = $PSMODULE_DESTDIR -replace '\\','\\'
if (-not ($module_path -match $str)) 
{
    Write-Host "The Symphony module path '$PSMODULE_DESTDIR' is not included in enviroment variable `$env:PSModulePath, add it"
    if (Test-Path $PSMODULE_DESTDIR) {
        $env:PSModulePath=$PSMODULE_DESTDIR + ";" + $module_path
    }
    else {
        write-host "The module path '$PSMODULE_DESTDIR' does not exist, this can cause errors" -foregroundcolor yellow
    }
}

Import-Module CommonDBUpgradeSupportToolSet -Force
Import-Module TradeDBUpgradeSupportToolSet -Force

if ($Login.Length -eq 0 -and $Password.Length -gt 0)
{
   Write-Host "You need to provide a DB login if password was given" 
   exit
}

if ($Login.Length -gt 0 -and $Password.Length -eq 0)
{
   Write-Host "You need to provide a password if DB login was given" 
   exit
}

if ($Login.Length -eq 0 -and $Password.Length -eq 0)
{
   $Authentication = "Windows Authentication"
   if (!(TestDBConnection -S $Server -AUTH $Authentication -D $Database)) {exit}
   $ConnStr="Server=$Server;Database=$Database;Integrated Security=True"
}
else
{
   $Authentication = "SQL Server Authentication"
   if (!(TestDBConnection -S $Server -AUTH $Authentication -U $Login -P $Password -D $Database)) {exit}
   $ConnStr="Server=$Server;Database=$Database;User=$Login;Password=$Password;Integrated Security=False"
}

# YES, we can open a db connection successfully
$UserAccessMode = GetDBAccessMode -ConnString $ConnStr -Database $Database
if ($UserAccessMode) {write-host "The current user access mode of the '$Database' database is $UserAccessMode"}
else
{
   Write-Host "Unable to find the current user access mode for the '$Database' database!"
   exit
}

$DBRecoveryModel = GetDBRecoveryModel -ConnString $ConnStr -Database $Database
if ($DBRecoveryModel) {write-host "The current recovery mode of the '$Database' database is $DBRecoveryModel"}
else
{
   Write-Host "Unable to find the current recovery mode for the '$Database' database!"
   exit
}

[boolean]$DBInMirroringState = DBInMirroringState -ConnString $ConnStr -Database $Database
if ($DBInMirroringState) {Write-Host "The '$Database' database is a mirrored database"}
else {Write-Host "The '$Database' database is NOT a mirrored database!"}

# We need to set DB Recovery model to SIMPLE. However, we can not change the FULL db 
# receovery mode if database is involved with mirroring 

if (!($DBInMirroringState))
{
   if ($DBRecoveryModel -ne "SIMPLE")
   {
      AlterDBRecoveryModel -ConnString $ConnStr -Database $Database -NewRecoveryModel "SIMPLE"
   }
}

[boolean]$PermissionOK = HasAdminPermission -ConnString $ConnStr -Database $Database
if ($PermissionOK)
{
   Write-Host "The '$Login' has the required administrative permissions"
}
else
{
   Write-Host "The '$Login' does not have the required administrative permissions"
   exit
}

. ./CreateSchema.ps1 $Server $Authentication $Login $Password $Database

# Remind DBA to backup the database which has newly created ICTS trade schema and then set database to be MULTI_USER mode
# set database back to its original recovery model
# cleanup temp files

# We need to reset DB Recovery model back to its original model. 

if (!($DBInMirroringState))
{
   if ($DBRecoveryModel -ne "SIMPLE")
   {
      AlterDBRecoveryModel -ConnString $ConnStr -Database $Database -NewRecoveryModel $DBRecoveryModel
   }
}

# Scan logs in the Logs subfolder
# *************************************************************************
# Scanning logs in the Logs subfolder
if (ErrorsExistedInLogs $ScriptRootPath) 
{
   Write-Host " "
   Write-Host -ForegroundColor DarkRed "The ICTS trade schema was failed to be created in the '$Database' database!" 
   Write-Host -ForegroundColor DarkRed "You may examine the log files listed above and investigate what caused errors." 
   Write-Host -ForegroundColor DarkRed "After you have fixed the errors, you can try to create schema again" 
}
else
{
   Write-Host " "
   Write-Host -ForegroundColor DarkBlue "The ICTS trade schema was created successfully in the '$Database' database!"
   Write-Host -ForegroundColor DarkBlue "Before you allow users to access this database, if this database is a production"
   Write-Host -ForegroundColor DarkBlue "database, it is recommended that you make a database backup immediately. "
   Write-Host -ForegroundColor DarkBlue "After that, you execute the 'ALTER DATABASE .. SET MULTI_USER' statement "
   Write-Host -ForegroundColor DarkBlue "so that your users can access the database"
}
Write-Host " "
Write-Host "This was done by using PowerShell version $ver"
Write-Host " "
