# UpdateSchema.ps1
#    This script can be called from POST_TRADE_SCHEMA_UPGRADE_PS.ps1 (in Structure folder) or
#    called from my_upgrade_PS.ps1 (in Migration folder)
#
#      Usage:
#         . .\UpdateSchema.ps1 -S <server> 
#                              -AUTH <an authentication mode>
#                              -U <login> 
#                              -P <pwd> 
#                              -D <name of trade database>
#
#      Dependency:
#        It uses the functions stored in
#           CommonDBUpgradeSupportToolSet module
#           TradeDBUpgradeSupportToolSet module
#
#     Created By         : Peter Lo   09/01/2016
#     Last Edited By     : Peter Lo   11/05/2016
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
# *****************************************************************************************

Param (
   [string]$S,
   [string]$AUTH,
   [string]$U,
   [string]$P,
   [string]$D
)

$Server=$S
$Authentication=$AUTH
$Login=$U
$Password=$P
$Database=$D

[bool]$DebugOn=$false
[bool]$PauseOn=$false
[bool]$ExitNow=$true

if ($DebugOn)
{
   Write-Host "DEBUG: Server is '$Server'"
   Write-Host "DEBUG: Login is '$Login'"
   Write-Host "DEBUG: Password is '$Password'"
   Write-Host "DEBUG: Database is '$Database'"
   Write-Host " "
}

$ScriptRootPath = $pwd.Path   

if ($debugon) {Write-Host "DEBUG: Script Root Path = '$ScriptRootPath'"}

CreateLogsSubFolderIfNotExist $ScriptRootPath

# *************************************************************************

#if (ExitOnError) {$ExitNow=$true}

if (!(AddNewTradeDbUsers $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateForeignKeyConstraints $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateUDFs $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateViews $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateMainIndexes $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateAuditIndexes $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateProcedures $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateDelTriggers $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateInsTriggers $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateUpdTriggers $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(GrantObjectPermissions $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(AddMissingSystemRefData $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(AddOrUpdateSeedRefData $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}

if (!(CreateOrUpdateDashboardDbObjects $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}

if (!(RefreshLastNums $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}

#if (!(GenExtendedPropertiesScripts $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
#if ($PauseOn) {Pause}
#if (!(AddExtendedProperties $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
#if ($PauseOn) {Pause}

