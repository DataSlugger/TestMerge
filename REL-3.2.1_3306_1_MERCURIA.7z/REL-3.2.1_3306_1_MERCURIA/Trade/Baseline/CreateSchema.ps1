# CreateSchema.ps1
#    This script is used by a number of PowerSell scripts to create an ICTS TRADE schema
#
#      Usage:
#         . .\CreateSchema.ps1 -S <server> 
#                              -AUTH <an authentication mode>
#                              -U <login> 
#                              -P <pwd> 
#                              -D <name of trade database>
#
#      Dependency:
#        It uses the functions stored in
#           DBUpgradeSupportToolSet module
#
#     Created By         : Peter Lo   04/14/2016
#     Last Edited By     : Peter Lo   09/18/2017
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
# *****************************************************************************************

Param (
   [string]$S,
   [string]$AUTH,
   [string]$U,
   [string]$P,
   [string]$D
)

$Server=$S
$Authentication=$AUTH
$Login=$U
$Password=$P
$Database=$D

[bool]$DebugOn=$false
[bool]$PauseOn=$false
[bool]$ExitNow=$false
[bool]$DebugOn=$true

$ScriptRootPath = $pwd.Path

if ($Authentication -eq "Windows Authentication")
{
   $ConnStr="Server=$Server;Database=$Database;Integrated Security=True"
}
else
{
   $ConnStr="Server=$Server;Database=$Database;User=$Login;Password=$Password;Integrated Security=False"
}

if ($DebugOn) {Write-Host "DEBUG: Script Root Path = '$ScriptRootPath'"}

# if ($DebugOn) {Write-Host "DEBUG: Loading SQLPS module ..."}
# Import-MrSqlModule

if ($DebugOn) {Write-Host "DEBUG: Creating Logs subfolder if it does not exist ..."}

CreateLogsSubFolderIfNotExist $ScriptRootPath

# *************************************************************************

$ScriptRootPath = $pwd.Path   

#if (ExitOnError) {$ExitNow=$true}

#if ($DebugOn) {Write-Host "DEBUG: Creating trade db roles ..."}
if (!(CreateTradeDbRoles $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
#if ($DebugOn) {Write-Host "DEBUG: Creating trade db users ..."}
if (!(CreateTradeDbUsers $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
#if ($DebugOn) {Write-Host "DEBUG: Creating tables ..."}
if (!(CreateMainTables $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateAuditTables $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateUDFs $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateViews $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateMainIndexes $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateAuditIndexes $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateProcedures $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(LoadSystemRefData $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(LoadSeedRefData $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateForeignKeyConstraints $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateDelTriggers $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateInsTriggers $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateUpdTriggers $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreateOrUpdateDashboardDbObjects $Server $Authentication $Login $Password $Database $ScriptRootPath "N")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(GrantObjectPermissions $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(RefreshLastNums $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
#if ($PauseOn) {Pause}
#if (!(GenExtendedPropertiesScripts $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
#if ($PauseOn) {Pause}
#if (!(AddExtendedProperties $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
#if ($PauseOn) {Pause}


