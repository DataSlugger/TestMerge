print ' '
print 'Creating new indexes to support ''v_BI_trade_search'' view ...'
go

/* ** account ** */
IF EXISTS (SELECT * FROM sysindexes
           WHERE id = OBJECT_ID('dbo.account') AND
                  name = 'account_TS_idx90' and
                  indid > 0 and indid < 255)
   DROP INDEX account_TS_idx90 on dbo.account;
go

CREATE NONCLUSTERED INDEX account_TS_idx90 
   ON dbo.account(acct_num, acct_short_name)
go

/* ** assign_trade ** */
IF NOT EXISTS (SELECT * FROM sysindexes
               WHERE id = OBJECT_ID('dbo.assign_trade') AND
                     name = 'assign_trade_TS_idx90' and
                     indid > 0 and indid < 255)
   CREATE NONCLUSTERED INDEX assign_trade_TS_idx90 
      ON dbo.assign_trade(ct_doc_type, alloc_num)
go

/* ** cost ** */
/* The following index was dropped. The idx2 was modified to include
   columns covered by this index - issue #1362376     09/18/2013 Peter Lo
IF EXISTS (SELECT * FROM sysindexes
           WHERE id = OBJECT_ID('dbo.cost') AND
                 name = 'cost_TS_idx90' and
                 indid > 0 and indid < 255)
   DROP INDEX cost_TS_idx90 on dbo.cost;


CREATE NONCLUSTERED INDEX cost_TS_idx90 
   ON dbo.cost(cost_owner_key6, cost_owner_key7, cost_owner_key8, 
               cost_status, cost_prim_sec_ind, cost_pay_rec_ind, cost_amt)
*/
go

/* ** formula ** */
IF EXISTS (SELECT * FROM sysindexes
           WHERE id = OBJECT_ID('dbo.formula') AND
                 name = 'formula_TS_idx90' and
                 indid > 0 and indid < 255)
   DROP INDEX formula_TS_idx90 on dbo.formula
go

CREATE NONCLUSTERED INDEX formula_TS_idx90 
   ON dbo.formula(parent_formula_num, formula_num)
go

/* ** formula_body ** */
IF NOT EXISTS (SELECT * FROM sysindexes
               WHERE id = OBJECT_ID('dbo.formula_body') AND
                     name = 'formula_body_TS_idx90' and
                     indid > 0 and indid < 255)
   CREATE NONCLUSTERED INDEX formula_body_TS_idx90 
      ON dbo.formula_body(formula_body_type, formula_num, formula_body_num)
go

/* ** lc ** */
IF NOT EXISTS (SELECT * FROM sysindexes
               WHERE id = OBJECT_ID('dbo.lc') AND
                     name = 'lc_TS_idx90' and
                     indid > 0 and indid < 255)
   CREATE NONCLUSTERED INDEX lc_TS_idx90 
      ON dbo.lc(lc_issuing_bank)
go

/* ** trade ** */
IF EXISTS (SELECT * FROM sysindexes
           WHERE id = OBJECT_ID('dbo.trade') AND
                 name = 'trade_TS_idx90' and
                 indid > 0 and indid < 255)
   DROP INDEX trade_TS_idx90 on dbo.trade
go

CREATE NONCLUSTERED INDEX trade_TS_idx90 
   ON dbo.trade(creation_date)
go

/* ** trade_item ** */
IF NOT EXISTS (SELECT * FROM sysindexes
               WHERE id = OBJECT_ID('dbo.trade_item') AND
                     name = 'trade_item_TS_idx90' and
                     indid > 0 and indid < 255)
   CREATE NONCLUSTERED INDEX trade_item_TS_idx90 
      ON dbo.trade_item (cmdty_code, risk_mkt_code)
go

IF NOT EXISTS (SELECT * FROM sysindexes
               WHERE id = OBJECT_ID('dbo.trade_item') AND
                     name = 'trade_item_TS_idx91' and
                     indid > 0 and indid < 255)
   CREATE NONCLUSTERED INDEX trade_item_TS_idx91 
      ON dbo.trade_item (brkr_num)
go

IF NOT EXISTS (SELECT * FROM sysindexes
               WHERE id = OBJECT_ID('dbo.trade_item') AND
                     name = 'trade_item_TS_idx92' and
                     indid > 0 and indid < 255)
   CREATE NONCLUSTERED INDEX trade_item_TS_idx92 
      ON dbo.trade_item (booking_comp_num)
go

IF NOT EXISTS (SELECT * FROM sysindexes
               WHERE id = OBJECT_ID('dbo.trade_item') AND
                     name = 'trade_item_TS_idx93' and
                     indid > 0 and indid < 255)
   CREATE NONCLUSTERED INDEX trade_item_TS_idx93 
      ON dbo.trade_item (risk_mkt_code, cmdty_code)
go

IF NOT EXISTS (SELECT * FROM sysindexes
               WHERE id = OBJECT_ID('dbo.trade_item') AND
                     name = 'trade_item_TS_idx94' and
                     indid > 0 and indid < 255)
   CREATE NONCLUSTERED INDEX trade_item_TS_idx94 
      ON dbo.trade_item (cmnt_num)
go

/* ** trade_item_dist ** */
IF NOT EXISTS (SELECT * FROM sysindexes
               WHERE id = OBJECT_ID('dbo.trade_item_dist') AND
                     name = 'trade_item_dist_TS_idx90' and
                     indid > 0 and indid < 255)
   CREATE NONCLUSTERED INDEX trade_item_dist_TS_idx90 
      ON dbo.trade_item_dist(dist_type, real_synth_ind, real_port_num)
go

/* ** trade_item_exch_opt ** */
IF NOT EXISTS (SELECT * FROM sysindexes
               WHERE id = OBJECT_ID('dbo.trade_item_exch_opt') AND
                     name = 'trade_item_exch_opt_TS_idx90' and
                     indid > 0 and indid < 255)
   CREATE NONCLUSTERED INDEX trade_item_exch_opt_TS_idx90 
      ON dbo.trade_item_exch_opt(clr_brkr_num)
go

/* ** trade_item_fut ** */
IF NOT EXISTS (SELECT * FROM sysindexes
               WHERE id = OBJECT_ID('dbo.trade_item_fut') AND
                     name = 'trade_item_fut_TS_idx90' and
                     indid > 0 and indid < 255)
   CREATE NONCLUSTERED INDEX trade_item_fut_TS_idx90 
      ON dbo.trade_item_fut(clr_brkr_num)
go

/* ** trade_order ** */

IF EXISTS (SELECT * FROM sysindexes
           WHERE id = OBJECT_ID('dbo.trade_order') AND
                 name = 'trade_order_TS_idx90' and
                 indid > 0 and indid < 255)
   DROP INDEX trade_order_TS_idx90 on dbo.trade_order
go

CREATE NONCLUSTERED INDEX trade_order_TS_idx90 
   ON dbo.trade_order (trade_num, order_num, order_type_code)
go

