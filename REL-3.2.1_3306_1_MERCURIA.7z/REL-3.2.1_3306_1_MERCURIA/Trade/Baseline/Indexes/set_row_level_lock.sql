/*
   Set row-level lock for the following indexes:
   
      Table                         Index
      ----------------------------  -------------------------------
      als_run_archive               als_run_archive_pk
                                    als_run_archive_idx1
      als_run_status                als_run_status_pk
      als_run_touch                 als_run_touch_pk
                                    als_run_touch_idx2
                                    als_run_touch_idx1
      transaction_touch             transaction_touch_pk
                                    transaction_touch_idx1
                                    transaction_touch_idx2
      als_module_entity             als_module_entity_pk
      als_run                       als_run_pk
                                    als_run_idx1
      tid_mark_to_market            tid_mark_to_market_pk
                                    tid_mark_to_market_idx1
      pl_history                    pl_history_pk
                                    pl_history_idx2
                                    pl_history_idx6
                                    pl_history_idx8

*/
print ' '
print 'Making tables to use the row-level lock ...'
go

create table #indexes
(
   oid              int IDENTITY primary key,
   table_name       sysname not null,
   index_name       sysname not null
)
go

insert into #indexes (table_name, index_name)
select 'als_run_archive', 'als_run_archive_pk'
union all
select 'als_run_archive', 'als_run_archive_idx1'
union all
select 'als_run_status', 'als_run_status_pk'
union all
select 'als_run_touch', 'als_run_touch_pk'
union all
select 'als_run_touch', 'als_run_touch_idx2'
union all
select 'als_run_touch', 'als_run_touch_idx1'
union all
select 'transaction_touch', 'transaction_touch_pk'
union all
select 'transaction_touch', 'transaction_touch_idx1'
union all
select 'transaction_touch', 'transaction_touch_idx2'
union all
select 'als_module_entity', 'als_module_entity_pk'
union all
select 'als_run', 'als_run_pk'
union all
select 'als_run', 'als_run_idx1'
union all
select 'tid_mark_to_market', 'tid_mark_to_market_pk'
union all
select 'tid_mark_to_market', 'tid_mark_to_market_idx1'
union all
select 'pl_history', 'pl_history_pk'
union all
select 'pl_history', 'pl_history_idx2'
union all
select 'pl_history', 'pl_history_idx6'
union all
select 'pl_history', 'pl_history_idx8'
go

declare @oid             int,
        @table_name      sysname,
        @index_name      sysname,
        @tempstr         varchar(255),
        @sql             varchar(800)
        
select @oid = min(oid)
from #indexes

while @oid is not null
begin
   select @table_name = table_name,
          @index_name = index_name
   from #indexes
   where oid = @oid      
  
   select @tempstr = '=> Processing ' + @table_name + '.' + @index_name
   RAISERROR (@tempstr, 0, 1) WITH NOWAIT

   set @sql = 'alter index ' + @index_name + ' on dbo.' + @table_name + ' set (ALLOW_PAGE_LOCKS = OFF)'
   begin try
     exec(@sql)
   end try
   begin catch
     print '==> Failed to turn off PAGE locks for the index ''' + @index_name + ''' due to the error:'
     print '===> ERROR: ' + ERROR_MESSAGE()
     goto nextoid
   end catch
   if exists (select 1
              from sys.indexes
              where object_id = object_id('dbo.' + @table_name) and 
                    name = @index_name and
                    allow_page_locks = 0)
      print '==> The PAGE locks on the index ''' + @index_name + ''' was turned off'
   else
      print '==> The PAGE locks on the index ''' + @index_name + ''' was not turned off'
   
   set @sql = 'alter index ' + @index_name + ' on dbo.' + @table_name + ' set (ALLOW_ROW_LOCKS = ON)'
   begin try
     exec(@sql)
   end try
   begin catch
     print '==> Failed to turn on ROW locks for the index ''' + @index_name + ''' due to the error:'
     print '===> ERROR: ' + ERROR_MESSAGE()
     goto nextoid
   end catch
   if exists (select 1
              from sys.indexes
              where object_id = object_id('dbo.' + @table_name) and 
                    name = @index_name and
                    allow_row_locks = 1)
      print '==> The ROW locks on the index ''' + @index_name + ''' was turned on'
   else
      print '==> The ROW locks on the index ''' + @index_name + ''' was not turned on'

nextoid:
   select @oid = min(oid)
   from #indexes
   where oid > @oid
end
go

if object_id('tempdb..#indexes', 'U') is not null
   exec('drop table #indexes')
go
