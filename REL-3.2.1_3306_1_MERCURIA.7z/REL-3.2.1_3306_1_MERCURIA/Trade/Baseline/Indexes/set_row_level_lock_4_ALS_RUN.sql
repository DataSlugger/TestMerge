print ' '
print 'Changing index option for the als_run table to use row-level lock ...'
go

if not exists (select 1
               from dbo.sysindexes
               where id = object_id('dbo.als_run') and
                     name = 'als_run_pk' and
                     lockflags = 2)
   exec dbo.sp_indexoption 'als_run.als_run_pk', 'AllowRowLocks', TRUE
go

if not exists (select 1
               from dbo.sysindexes
               where id = object_id('dbo.als_run') and
                     name = 'als_run_idx1' and
                     lockflags = 2)
   exec dbo.sp_indexoption 'als_run.als_run_idx1', 'AllowRowLocks', TRUE
go

print 'Changing index option for the als_run_touch table to use row-level lock ...'
go
if not exists (select 1
               from dbo.sysindexes
               where id = object_id('dbo.als_run_touch') and
                     name = 'als_run_touch_pk' and
                     lockflags = 2)
   exec dbo.sp_indexoption 'als_run_touch.als_run_touch_pk', 'AllowRowLocks', TRUE
go

if not exists (select 1
               from dbo.sysindexes
               where id = object_id('dbo.als_run') and
                     name = 'als_run_touch_idx1' and
                     lockflags = 2)
   exec dbo.sp_indexoption 'als_run_touch.als_run_touch_idx1', 'AllowRowLocks', TRUE
go

if not exists (select 1
               from dbo.sysindexes
               where id = object_id('dbo.als_run') and
                     name = 'als_run_touch_idx2' and
                     lockflags = 2)
   exec dbo.sp_indexoption 'als_run_touch.als_run_touch_idx2', 'AllowRowLocks', TRUE
go
