# **********************************************************************************************************
#  GenAuditTableGrantScript.ps1
#     It creates a db script file for granting permissions on audit tables
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  06/25/2016
#   Last Edited By       : Peter Lo  06/25/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
   Write-Host "Generating a database script file ..."   

   $ScriptRootPath = $pwd.Path
   Set-Location $ScriptRootPath
   $ScriptFileName="GrantAuditTableScript"
   $ScriptFullFileName="$ScriptRootPath\$ScriptFileName.sql"

   Write-Output " " | out-file $ScriptFullFileName
   
   Get-ChildItem $ScriptRootPath -Filter *.tbl | 
      Foreach-Object {
         $ScriptFileName = $_
         $tablename = $ScriptFileName -replace '.tbl',''
         Write-Output "insert into dbo.xx0917grants values('$tablename')" | out-file $ScriptFullFileName -append
         Write-Output "go" | out-file $ScriptFullFileName -append
      }
