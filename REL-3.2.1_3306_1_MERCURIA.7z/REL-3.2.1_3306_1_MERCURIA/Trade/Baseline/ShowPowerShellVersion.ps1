$PSVersionTable.PSVersion
