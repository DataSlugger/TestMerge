use master
go

backup log DBA_amphora_trade with truncate_only
go
