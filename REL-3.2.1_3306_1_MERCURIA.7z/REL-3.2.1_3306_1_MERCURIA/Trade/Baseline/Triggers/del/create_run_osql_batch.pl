#!c:\Perl\bin\perl
#
# ------------------------------------------------------------------
#   create_run_osql_batch.pl   
# ------------------------------------------------------------------

open (OUTFILE, "> run_osql_createDELtrg.bat") || die "Can't create the run_osql_createDELtrg.bat: $!";
print OUTFILE "\@echo off\n";
print OUTFILE "REM Test parameters\n";
print OUTFILE "IF %1NOTHING==NOTHING GOTO WARNING\n";
print OUTFILE "IF %2NOTHING==NOTHING GOTO WARNING\n";
print OUTFILE "IF %3NOTHING==NOTHING GOTO WARNING\n";
print OUTFILE "REM\n";
print OUTFILE "set ISQL=\"osql.exe\"\n";
print OUTFILE "REM\n";
while (defined($filename = glob("*.trg")) ) {
   $scriptfile = get_script_filename($filename);
   ($triggername = $scriptfile) =~ s/\.trg//g;
   print OUTFILE "echo Creating the '$triggername' trigger ...\n";
   print OUTFILE "%ISQL% -S %1 -U %2 -P %3 -n -i Triggers\\del\\$scriptfile\n";   
 }
print OUTFILE "echo Bye...Bye...\n";
print OUTFILE "goto end\n";
print OUTFILE ":WARNING\n";
print OUTFILE "Echo Usage: run_osql_createDELtrg [server] [login] [password]\n";
print OUTFILE ":END\n";
close OUTFILE;

# -----------------------------------------------------
#  get_script_filename
#
#     This function extracts a script file name from
#     a full filename specfication
# -----------------------------------------------------

sub get_script_filename {
   my ($fullfilename) = @_;

   my @tokens = split(/\//, $fullfilename);
   @tokens = reverse(@tokens);
   return $tokens[0];
 }
