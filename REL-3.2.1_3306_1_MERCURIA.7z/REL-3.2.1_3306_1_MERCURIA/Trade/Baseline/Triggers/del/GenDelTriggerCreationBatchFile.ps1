# **********************************************************************************************************
#  GenDelTriggerCreationBatchFile.ps1
#     It create a Windows BATCH file for creating deletion triggers
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  06/25/2016
#   Last Edited By       : Peter Lo  06/25/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
   Write-Host "Generating a Windows batch file ..."   

   $ScriptRootPath = $pwd.Path
   Set-Location $ScriptRootPath
   $BatchFileName="run_osql_createDELtrg"
   $BatchFullFileName="$ScriptRootPath\$BatchFileName.bat"

   Write-Output "@echo off" | out-file $BatchFullFileName
   Write-Output "REM Test parameters" | out-file $BatchFullFileName -append
   Write-Output "IF %1NOTHING==NOTHING GOTO WARNING" | out-file $BatchFullFileName -append
   Write-Output "IF %2NOTHING==NOTHING GOTO WARNING" | out-file $BatchFullFileName -append
   Write-Output "IF %3NOTHING==NOTHING GOTO WARNING" | out-file $BatchFullFileName -append
   Write-Output "IF %4NOTHING==NOTHING GOTO WARNING" | out-file $BatchFullFileName -append
   Write-Output "REM" | out-file $BatchFullFileName -append
   Write-Output "set ISQL=""sqlcmd.exe""" | out-file $BatchFullFileName -append
   Write-Output "set SQLCMDLOGINTIMEOUT=0" | out-file $BatchFullFileName -append
   Write-Output "REM" | out-file $BatchFullFileName -append
   Write-Output "REM ====================================================" | out-file $BatchFullFileName -append
   Write-Output "REM  Creating all deletion triggers" | out-file $BatchFullFileName -append
   Write-Output "REM ====================================================" | out-file $BatchFullFileName -append
   
   Get-ChildItem $ScriptRootPath -Filter *.trg | 
      Foreach-Object {
         $ScriptFileName = $_
         Write-Host "Appending a SQLCMD line for executing the script '$ScriptFileName' ..."
         Write-Output "echo Executing the script '$ScriptFileName' ..." | out-file $BatchFullFileName -append
         Write-Output "%ISQL% -S %1 -U %2 -P %3 -d %4 -w 200 -i Triggers\del\$ScriptFileName" | out-file $BatchFullFileName -append
      }

   Write-Output "REM ************************************************************************************************" | out-file $BatchFullFileName -append   
   Write-Output "REM  APP LAUNCHER triggers" | out-file $BatchFullFileName -append  
   Write-Output "REM ************************************************************************************************" | out-file $BatchFullFileName -append  

   Get-ChildItem "$ScriptRootPath\ForAppLauncher" -Filter *.trg | 
      Foreach-Object {
         $ScriptFileName = $_
         Write-Host "Appending a SQLCMD line for executing the script '$ScriptFileName' ..."
         Write-Output "echo Executing the script '$ScriptFileName' ..." | out-file $BatchFullFileName -append
         Write-Output "%ISQL% -S %1 -U %2 -P %3 -d %4 -w 200 -i Triggers\del\ForAppLauncher\$ScriptFileName" | out-file $BatchFullFileName -append
      }

   Write-Output "REM ************************************************************************************************" | out-file $BatchFullFileName -append   
   Write-Output "REM  INSTEAD OF triggers for Updateable views" | out-file $BatchFullFileName -append  
   Write-Output "REM ************************************************************************************************" | out-file $BatchFullFileName -append  

   Get-ChildItem "$ScriptRootPath\ForViews" -Filter *.trg | 
      Foreach-Object {
         $ScriptFileName = $_
         Write-Host "Appending a SQLCMD line for executing the script '$ScriptFileName' ..."
         Write-Output "echo Executing the script '$ScriptFileName' ..." | out-file $BatchFullFileName -append
         Write-Output "%ISQL% -S %1 -U %2 -P %3 -d %4 -w 200 -i Triggers\del\ForViews\$ScriptFileName" | out-file $BatchFullFileName -append
      }

   Write-Output "REM" | out-file $BatchFullFileName -append
   Write-Output "echo Bye...Bye..." | out-file $BatchFullFileName -append
   Write-Output "goto end" | out-file $BatchFullFileName -append
   Write-Output ":WARNING" | out-file $BatchFullFileName -append
   Write-Output "Echo Usage: $BatchFileName [server] [login] [password] [database]" | out-file $BatchFullFileName -append
   Write-Output ":end" | out-file $BatchFullFileName -append
   Set-Location $ScriptRootPath
