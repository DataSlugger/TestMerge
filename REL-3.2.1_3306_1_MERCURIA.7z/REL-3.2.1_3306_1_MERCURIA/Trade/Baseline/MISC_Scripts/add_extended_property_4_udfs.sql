set nocount on
go
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''fnToSplit'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fnToSplit') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'fnToSplit'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_allocation_capacity'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_allocation_capacity') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_allocation_capacity'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_booking_companies'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_booking_companies') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_booking_companies'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_booking_company_nums'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_booking_company_nums') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_booking_company_nums'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_column_check_constraint_options'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_column_check_constraint_options') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_column_check_constraint_options'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_column_default_value'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_column_default_value') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_column_default_value'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_column_exists'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_column_exists') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_column_exists'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_count_a_char_occurrences'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_count_a_char_occurrences') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_count_a_char_occurrences'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_currency_exch_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_currency_exch_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_currency_exch_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_event_price_string'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_event_price_string') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_event_price_string'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_get_formulabody_invoiceDescription'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_get_formulabody_invoiceDescription') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_get_formulabody_invoiceDescription'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_get_portfolio'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_get_portfolio') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_get_portfolio'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_get_tpcount'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_get_tpcount') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_get_tpcount'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_getUomConversion'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_getUomConversion') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_getUomConversion'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_ListToTable'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_ListToTable') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_ListToTable'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_move_items_from_list_to_table'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_move_items_from_list_to_table') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_move_items_from_list_to_table'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_pkey_column_list'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_pkey_column_list') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_pkey_column_list'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_portfolio_list'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_portfolio_list') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_portfolio_list'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_portfolio_tag_id'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_portfolio_tag_id') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_portfolio_tag_id'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_position_type_desc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_position_type_desc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_position_type_desc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_profit_centers'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_profit_centers') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_profit_centers'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_RVFile_child_port_nums'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_RVFile_child_port_nums') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_RVFile_child_port_nums'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_split'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_split') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_split'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_split_TOIs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_split_TOIs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_split_TOIs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_split_value'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_split_value') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_split_value'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_table_colinfo'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_table_colinfo') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_table_colinfo'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_table_column_data_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_table_column_data_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_table_column_data_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_table_column_list'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_table_column_list') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_table_column_list'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_table_pkey_columns_and_their_datatypes'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_table_pkey_columns_and_their_datatypes') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_table_pkey_columns_and_their_datatypes'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_trading_entities'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_trading_entities') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_trading_entities'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_uom_conv_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_uom_conv_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_uom_conv_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_VAR_getUomConvMultiplier'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_VAR_getUomConvMultiplier') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_VAR_getUomConvMultiplier'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the user-defined function ''udf_XML_get_string_data'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.udf_XML_get_string_data') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'FUNCTION',
              @level1name = N'udf_XML_get_string_data'
go
 
