set nocount on
go
print '=> Adding extended property ''SymphonyProduct'' for the table ''account'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_address'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_address') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_address'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_affiliated'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_affiliated') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_affiliated'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_agreement'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_agreement') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_agreement'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_bank_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_bank_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_bank_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_collateral'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_collateral') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_collateral'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_commkt_gtc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_commkt_gtc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_commkt_gtc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_contact'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_contact') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_contact'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_credit_alarm_log'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_credit_alarm_log') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_credit_alarm_log'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_credit_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_credit_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_credit_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_credit_limit'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_credit_limit') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_credit_limit'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_group_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_group_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_group_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_instr_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_instr_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_instr_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_instruction'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_instruction') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_instruction'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_net_out'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_net_out') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_net_out'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_petroex'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_petroex') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_petroex'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''account_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'account_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''acct_bc_ot_crinfo'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.acct_bc_ot_crinfo') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'acct_bc_ot_crinfo'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''acct_bookcomp'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.acct_bookcomp') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'acct_bookcomp'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''acct_bookcomp_collatera'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.acct_bookcomp_collatera') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'acct_bookcomp_collatera'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''acct_bookcomp_crinfo'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.acct_bookcomp_crinfo') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'acct_bookcomp_crinfo'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''acct_bookcomp_guarantee'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.acct_bookcomp_guarantee') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'acct_bookcomp_guarantee'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''acct_bookcomp_restrict'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.acct_bookcomp_restrict') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'acct_bookcomp_restrict'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''acct_cr_bus_category'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.acct_cr_bus_category') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'acct_cr_bus_category'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''acct_fiscal_rep'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.acct_fiscal_rep') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'acct_fiscal_rep'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''acct_sub_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.acct_sub_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'acct_sub_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''acct_sub_type_ref'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.acct_sub_type_ref') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'acct_sub_type_ref'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''acct_vat_number'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.acct_vat_number') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'acct_vat_number'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''accumulation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.accumulation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'accumulation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''actual_char_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.actual_char_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'actual_char_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''actual_lot'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.actual_lot') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'actual_lot'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_btt_ack_cnfrm'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_btt_ack_cnfrm') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_btt_ack_cnfrm'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_btt_ack_cnfrm_litem'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_btt_ack_cnfrm_litem') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_btt_ack_cnfrm_litem'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_btt_nom_litem'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_btt_nom_litem') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_btt_nom_litem'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_btt_nomination'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_btt_nomination') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_btt_nomination'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_btt_order_ticket'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_btt_order_ticket') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_btt_order_ticket'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_btt_sch_upd_litem'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_btt_sch_upd_litem') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_btt_sch_upd_litem'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_btt_schedule_updt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_btt_schedule_updt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_btt_schedule_updt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_btt_ticket_litem'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_btt_ticket_litem') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_btt_ticket_litem'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_consignee_tankage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_consignee_tankage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_consignee_tankage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_custody_ticket'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_custody_ticket') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_custody_ticket'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_external_codes'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_external_codes') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_external_codes'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_nomination'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_nomination') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_nomination'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_nomination_line_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_nomination_line_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_nomination_line_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_schedule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_schedule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_schedule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_schedule_line_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_schedule_line_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_schedule_line_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_truck_actual_details'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_truck_actual_details') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_truck_actual_details'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ag_truck_shipper_stmt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ag_truck_shipper_stmt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ag_truck_shipper_stmt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ai_est_act_inv_pricing'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ai_est_act_inv_pricing') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ai_est_act_inv_pricing'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ai_est_actual'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ai_est_actual') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ai_est_actual'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ai_est_actual_airline'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ai_est_actual_airline') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ai_est_actual_airline'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ai_est_actual_bulk_search'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ai_est_actual_bulk_search') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ai_est_actual_bulk_search'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ai_est_actual_char_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ai_est_actual_char_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ai_est_actual_char_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ai_est_actual_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ai_est_actual_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ai_est_actual_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ai_est_actual_interface'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ai_est_actual_interface') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ai_est_actual_interface'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ai_est_actual_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ai_est_actual_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ai_est_actual_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ai_est_actual_spec_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ai_est_actual_spec_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ai_est_actual_spec_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ai_est_actual_vat'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ai_est_actual_vat') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ai_est_actual_vat'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''alias_source'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.alias_source') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'alias_source'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''alloc_item_imp_exp'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.alloc_item_imp_exp') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'alloc_item_imp_exp'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_chain'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_chain') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_chain'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_criteria'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_criteria') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_criteria'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_insp'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_insp') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_insp'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_item_insp'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_item_insp') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_item_insp'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_item_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_item_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_item_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_item_transport'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_item_transport') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_item_transport'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_item_vat'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_item_vat') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_item_vat'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_pl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_pl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_pl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_transfer'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_transfer') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_transfer'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''allocation_world_scale'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_world_scale') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'allocation_world_scale'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''als_module_entity'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.als_module_entity') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'als_module_entity'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''als_run'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.als_run') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'als_run'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''als_run_archive'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.als_run_archive') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'als_run_archive'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''als_run_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.als_run_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'als_run_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''als_run_touch'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.als_run_touch') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'als_run_touch'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''als_run_touch_archive'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.als_run_touch_archive') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'als_run_touch_archive'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''APPLAUNCHER_APPS'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.APPLAUNCHER_APPS') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'APPLAUNCHER_APPS'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''APPLAUNCHER_CATEGORIES'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.APPLAUNCHER_CATEGORIES') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'APPLAUNCHER_CATEGORIES'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''APPLAUNCHER_CATEGORIES_APPS'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.APPLAUNCHER_CATEGORIES_APPS') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'APPLAUNCHER_CATEGORIES_APPS'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''APPLAUNCHER_DASHBOARDS'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.APPLAUNCHER_DASHBOARDS') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'APPLAUNCHER_DASHBOARDS'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''APPLAUNCHER_USER_DASHBOARDS'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.APPLAUNCHER_USER_DASHBOARDS') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'APPLAUNCHER_USER_DASHBOARDS'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''APPLAUNCHER_USER_FAVORITES'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.APPLAUNCHER_USER_FAVORITES') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'APPLAUNCHER_USER_FAVORITES'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''APPLAUNCHER_USER_LAYOUT'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.APPLAUNCHER_USER_LAYOUT') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'APPLAUNCHER_USER_LAYOUT'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''application'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.application') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'application'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''APPLICATION_AUDIT'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.APPLICATION_AUDIT') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'APPLICATION_AUDIT'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''archive_pl_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.archive_pl_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'archive_pl_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''archive_ti_mtm'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.archive_ti_mtm') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'archive_ti_mtm'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''archive_tid_mtm'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.archive_tid_mtm') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'archive_tid_mtm'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''assign_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.assign_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'assign_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_address'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_address') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_address'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_affiliated'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_affiliated') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_affiliated'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_agreement'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_agreement') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_agreement'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_bank_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_bank_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_bank_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_collateral'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_collateral') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_collateral'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_commkt_gtc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_commkt_gtc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_commkt_gtc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_contact'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_contact') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_contact'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_credit_alarm_log'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_credit_alarm_log') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_credit_alarm_log'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_credit_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_credit_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_credit_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_credit_limit'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_credit_limit') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_credit_limit'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_group_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_group_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_group_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_instr_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_instr_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_instr_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_instruction'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_instruction') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_instruction'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_net_out'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_net_out') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_net_out'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_account_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_account_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_account_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_acct_bc_ot_crinfo'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_acct_bc_ot_crinfo') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_acct_bc_ot_crinfo'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_acct_bookcomp'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_acct_bookcomp') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_acct_bookcomp'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_acct_bookcomp_collatera'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_acct_bookcomp_collatera') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_acct_bookcomp_collatera'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_acct_bookcomp_crinfo'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_acct_bookcomp_crinfo') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_acct_bookcomp_crinfo'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_acct_bookcomp_guarantee'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_acct_bookcomp_guarantee') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_acct_bookcomp_guarantee'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_acct_bookcomp_restrict'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_acct_bookcomp_restrict') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_acct_bookcomp_restrict'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_acct_cr_bus_category'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_acct_cr_bus_category') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_acct_cr_bus_category'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_acct_fiscal_rep'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_acct_fiscal_rep') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_acct_fiscal_rep'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_acct_sub_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_acct_sub_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_acct_sub_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_acct_sub_type_ref'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_acct_sub_type_ref') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_acct_sub_type_ref'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_acct_vat_number'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_acct_vat_number') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_acct_vat_number'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_accumulation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_accumulation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_accumulation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_actual_lot'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_actual_lot') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_actual_lot'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_btt_ack_cnfrm'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_btt_ack_cnfrm') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_btt_ack_cnfrm'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_btt_ack_cnfrm_litem'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_btt_ack_cnfrm_litem') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_btt_ack_cnfrm_litem'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_btt_nom_litem'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_btt_nom_litem') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_btt_nom_litem'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_btt_nomination'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_btt_nomination') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_btt_nomination'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_btt_order_ticket'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_btt_order_ticket') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_btt_order_ticket'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_btt_sch_upd_litem'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_btt_sch_upd_litem') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_btt_sch_upd_litem'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_btt_schedule_updt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_btt_schedule_updt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_btt_schedule_updt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_btt_ticket_litem'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_btt_ticket_litem') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_btt_ticket_litem'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_custody_ticket'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_custody_ticket') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_custody_ticket'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_external_codes'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_external_codes') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_external_codes'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_nomination'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_nomination') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_nomination'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_nomination_line_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_nomination_line_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_nomination_line_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_schedule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_schedule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_schedule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_schedule_line_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_schedule_line_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_schedule_line_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_truck_actual_details'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_truck_actual_details') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_truck_actual_details'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ag_truck_shipper_stmt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ag_truck_shipper_stmt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ag_truck_shipper_stmt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ai_est_act_inv_pricing'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ai_est_act_inv_pricing') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ai_est_act_inv_pricing'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ai_est_actual'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ai_est_actual') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ai_est_actual'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ai_est_actual_airline'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ai_est_actual_airline') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ai_est_actual_airline'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ai_est_actual_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ai_est_actual_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ai_est_actual_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ai_est_actual_interface'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ai_est_actual_interface') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ai_est_actual_interface'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ai_est_actual_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ai_est_actual_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ai_est_actual_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ai_est_actual_vat'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ai_est_actual_vat') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ai_est_actual_vat'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_alias_source'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_alias_source') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_alias_source'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_alloc_item_imp_exp'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_alloc_item_imp_exp') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_alloc_item_imp_exp'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_chain'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_chain') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_chain'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_criteria'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_criteria') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_criteria'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_insp'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_insp') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_insp'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_item_insp'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_item_insp') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_item_insp'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_item_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_item_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_item_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_item_transport'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_item_transport') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_item_transport'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_item_vat'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_item_vat') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_item_vat'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_pl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_pl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_pl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_transfer'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_transfer') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_transfer'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_allocation_world_scale'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_allocation_world_scale') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_allocation_world_scale'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_application'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_application') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_application'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_assign_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_assign_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_assign_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_avg_buy_sell_price_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_avg_buy_sell_price_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_avg_buy_sell_price_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_bank_credit_alarm_log'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_bank_credit_alarm_log') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_bank_credit_alarm_log'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_bank_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_bank_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_bank_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_broker_commission_default'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_broker_commission_default') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_broker_commission_default'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_broker_cost_autogen'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_broker_cost_autogen') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_broker_cost_autogen'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_broker_cost_step_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_broker_cost_step_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_broker_cost_step_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_broker_fifo_run_rec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_broker_fifo_run_rec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_broker_fifo_run_rec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_broker_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_broker_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_broker_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_bunker_pur_price_lookup'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_bunker_pur_price_lookup') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_bunker_pur_price_lookup'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_bus_cost_fate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_bus_cost_fate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_bus_cost_fate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_bus_cost_order_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_bus_cost_order_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_bus_cost_order_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_bus_cost_state'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_bus_cost_state') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_bus_cost_state'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_bus_cost_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_bus_cost_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_bus_cost_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_calendar'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_calendar') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_calendar'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_calendar_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_calendar_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_calendar_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cash_collateral'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cash_collateral') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cash_collateral'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cash_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cash_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cash_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cash_settle_date'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cash_settle_date') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cash_settle_date'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cmdty_nomenclature'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cmdty_nomenclature') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cmdty_nomenclature'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_collateral_party'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_collateral_party') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_collateral_party'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_collateral_pledged'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_collateral_pledged') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_collateral_pledged'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_collateral_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_collateral_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_collateral_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commkt_clrd_swap_attr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commkt_clrd_swap_attr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commkt_clrd_swap_attr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commkt_future_attr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commkt_future_attr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commkt_future_attr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commkt_option_attr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commkt_option_attr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commkt_option_attr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commkt_physical_attr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commkt_physical_attr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commkt_physical_attr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commkt_source_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commkt_source_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commkt_source_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commkt_source_roll_date'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commkt_source_roll_date') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commkt_source_roll_date'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commkt_src_alias_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commkt_src_alias_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commkt_src_alias_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity_category'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity_category') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity_category'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity_desc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity_desc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity_desc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity_location'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity_location') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity_location'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity_market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity_market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity_market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity_market_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity_market_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity_market_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity_market_formula'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity_market_formula') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity_market_formula'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity_market_source'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity_market_source') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity_market_source'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity_specification'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity_specification') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity_specification'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_commodity_uom'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_commodity_uom') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_commodity_uom'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_company_code_list'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_company_code_list') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_company_code_list'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_confirm_method'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_confirm_method') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_confirm_method'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_confirm_template'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_confirm_template') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_confirm_template'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_contract'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_contract') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_contract'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_contract_message_list'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_contract_message_list') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_contract_message_list'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_contract_skeleton'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_contract_skeleton') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_contract_skeleton'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_contract_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_contract_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_contract_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_contract_transmission'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_contract_transmission') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_contract_transmission'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_approval'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_approval') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_approval'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_center'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_center') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_center'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_code'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_code') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_code'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_credit_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_credit_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_credit_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_distribution'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_distribution') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_distribution'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_equalization_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_equalization_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_equalization_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_interface_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_interface_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_interface_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_owner'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_owner') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_owner'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_price_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_price_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_price_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_relative_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_relative_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_relative_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_scheduled_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_scheduled_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_scheduled_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_scheduled_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_scheduled_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_scheduled_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_specification'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_specification') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_specification'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_template'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_template') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_template'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_template_cntparty'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_template_cntparty') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_template_cntparty'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_template_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_template_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_template_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_template_grp_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_template_grp_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_template_grp_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_template_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_template_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_template_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_cost_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_cost_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_cost_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_country'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_country') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_country'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_country_by_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_country_by_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_country_by_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_country_credit_alarm_log'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_country_credit_alarm_log') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_country_credit_alarm_log'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_country_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_country_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_country_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_credit_alarm'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_credit_alarm') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_credit_alarm'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_credit_alarm_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_credit_alarm_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_credit_alarm_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_credit_alarm_log'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_credit_alarm_log') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_credit_alarm_log'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_credit_alarm_log_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_credit_alarm_log_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_credit_alarm_log_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_credit_bus_category'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_credit_bus_category') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_credit_bus_category'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_credit_limit'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_credit_limit') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_credit_limit'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_credit_limit_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_credit_limit_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_credit_limit_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_credit_reserve'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_credit_reserve') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_credit_reserve'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_credit_sector'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_credit_sector') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_credit_sector'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_credit_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_credit_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_credit_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_credit_term_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_credit_term_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_credit_term_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_custom_contract_range'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_custom_contract_range') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_custom_contract_range'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_custom_voucher_range'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_custom_voucher_range') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_custom_voucher_range'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_data_file'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_data_file') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_data_file'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_delivery_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_delivery_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_delivery_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_delivery_term_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_delivery_term_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_delivery_term_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_department'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_department') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_department'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_desk'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_desk') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_desk'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_desk_location'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_desk_location') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_desk_location'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_document'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_document') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_document'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_document_message'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_document_message') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_document_message'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_document_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_document_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_document_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_edpl_event'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_edpl_event') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_edpl_event'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_eipp_task'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_eipp_task') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_eipp_task'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_eipp_task_name'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_eipp_task_name') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_eipp_task_name'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_entity_tag'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_entity_tag') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_entity_tag'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_entity_tag_definition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_entity_tag_definition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_entity_tag_definition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_entity_tag_insp_attr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_entity_tag_insp_attr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_entity_tag_insp_attr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_entity_tag_option'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_entity_tag_option') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_entity_tag_option'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_event'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_event') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_event'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_event_price_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_event_price_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_event_price_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_exceptions_additions'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_exceptions_additions') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_exceptions_additions'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_exch_fifo_alloc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_exch_fifo_alloc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_exch_fifo_alloc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_exch_fifo_alloc_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_exch_fifo_alloc_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_exch_fifo_alloc_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_exch_tools_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_exch_tools_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_exch_tools_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_execution_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_execution_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_execution_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_exposure_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_exposure_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_exposure_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ext_ref_keys'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ext_ref_keys') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ext_ref_keys'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ext_refdata_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ext_refdata_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ext_refdata_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ext_trandata_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ext_trandata_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ext_trandata_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ext_trans_keys'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ext_trans_keys') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ext_trans_keys'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_external_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_external_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_external_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_external_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_external_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_external_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_external_position'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_external_position') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_external_position'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_external_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_external_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_external_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_external_trade_source'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_external_trade_source') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_external_trade_source'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_external_trade_state'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_external_trade_state') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_external_trade_state'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_external_trade_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_external_trade_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_external_trade_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_external_trade_system'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_external_trade_system') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_external_trade_system'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_external_trade_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_external_trade_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_external_trade_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_facility'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_facility') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_facility'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_facility_commodity'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_facility_commodity') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_facility_commodity'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_facility_link'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_facility_link') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_facility_link'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_facility_mot'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_facility_mot') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_facility_mot'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_facility_tank_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_facility_tank_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_facility_tank_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_facility_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_facility_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_facility_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fb_event_price_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fb_event_price_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fb_event_price_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fb_modular_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fb_modular_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fb_modular_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_feed_data'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_feed_data') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_feed_data'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_feed_definition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_feed_definition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_feed_definition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_feed_definition_xsd_xml'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_feed_definition_xsd_xml') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_feed_definition_xsd_xml'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_feed_detail_data'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_feed_detail_data') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_feed_detail_data'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_feed_xsd_xml_text'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_feed_xsd_xml_text') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_feed_xsd_xml_text'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fifo_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fifo_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fifo_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_file_load'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_file_load') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_file_load'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_file_load_error'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_file_load_error') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_file_load_error'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fips_city'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fips_city') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fips_city'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fips_county'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fips_county') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fips_county'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fips_state'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fips_state') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fips_state'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fiscal_classification'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fiscal_classification') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fiscal_classification'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''AUD_FL_GROUPS'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.AUD_FL_GROUPS') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'AUD_FL_GROUPS'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''AUD_FL_GROUPS_ROLES'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.AUD_FL_GROUPS_ROLES') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'AUD_FL_GROUPS_ROLES'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''AUD_FL_GROUPS_USERS'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.AUD_FL_GROUPS_USERS') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'AUD_FL_GROUPS_USERS'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''AUD_FL_ROLES'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.AUD_FL_ROLES') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'AUD_FL_ROLES'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''AUD_FL_USERS'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.AUD_FL_USERS') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'AUD_FL_USERS'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''AUD_FL_USERS_ROLES'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.AUD_FL_USERS_ROLES') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'AUD_FL_USERS_ROLES'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_flat_rates'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_flat_rates') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_flat_rates'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_folder'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_folder') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_folder'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_folder_document'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_folder_document') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_folder_document'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_forecast_value'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_forecast_value') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_forecast_value'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_formula'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_formula') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_formula'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_formula_body'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_formula_body') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_formula_body'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_formula_body_trigger'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_formula_body_trigger') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_formula_body_trigger'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_formula_body_trigger_actual'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_formula_body_trigger_actual') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_formula_body_trigger_actual'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_formula_comp_price_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_formula_comp_price_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_formula_comp_price_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_formula_component'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_formula_component') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_formula_component'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_formula_condition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_formula_condition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_formula_condition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_function_action'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_function_action') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_function_action'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_function_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_function_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_function_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_function_detail_value'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_function_detail_value') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_function_detail_value'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fx_cost_draw_down_hist'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fx_cost_draw_down_hist') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fx_cost_draw_down_hist'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fx_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fx_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fx_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fx_exposure_currency'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fx_exposure_currency') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fx_exposure_currency'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fx_exposure_dist'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fx_exposure_dist') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fx_exposure_dist'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fx_exposure_pl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fx_exposure_pl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fx_exposure_pl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fx_hedge_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fx_hedge_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fx_hedge_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fx_linked_costs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fx_linked_costs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fx_linked_costs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fx_linking'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fx_linking') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fx_linking'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_fx_rate_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_fx_rate_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_fx_rate_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_generic_data_definition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_generic_data_definition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_generic_data_definition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_generic_data_name'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_generic_data_name') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_generic_data_name'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_generic_data_values'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_generic_data_values') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_generic_data_values'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_grade_commodity_market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_grade_commodity_market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_grade_commodity_market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_gtc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_gtc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_gtc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_handling_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_handling_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_handling_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_hedge_physical'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_hedge_physical') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_hedge_physical'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ice_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ice_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ice_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_icts_entity_name'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_icts_entity_name') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_icts_entity_name'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_icts_function'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_icts_function') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_icts_function'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_icts_message'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_icts_message') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_icts_message'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_icts_message_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_icts_message_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_icts_message_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_icts_timezones'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_icts_timezones') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_icts_timezones'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_icts_user'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_icts_user') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_icts_user'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_icts_user_permission'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_icts_user_permission') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_icts_user_permission'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_idms_board_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_idms_board_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_idms_board_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_idms_department_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_idms_department_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_idms_department_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_idms_location_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_idms_location_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_idms_location_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_implied_pr_differential'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_implied_pr_differential') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_implied_pr_differential'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_importer_record_reason'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_importer_record_reason') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_importer_record_reason'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_inhouse_post'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_inhouse_post') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_inhouse_post'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_interface_exec_params'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_interface_exec_params') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_interface_exec_params'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_inv_actual'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_inv_actual') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_inv_actual'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_inv_actual_fifo'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_inv_actual_fifo') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_inv_actual_fifo'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_inv_build_draw_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_inv_build_draw_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_inv_build_draw_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_inv_credit_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_inv_credit_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_inv_credit_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_inv_pricing_period'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_inv_pricing_period') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_inv_pricing_period'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_inventory'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_inventory') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_inventory'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_inventory_build_draw'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_inventory_build_draw') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_inventory_build_draw'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_inventory_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_inventory_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_inventory_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_inventory_roll_criteria'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_inventory_roll_criteria') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_inventory_roll_criteria'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_inventory_voyage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_inventory_voyage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_inventory_voyage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_job_schedule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_job_schedule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_job_schedule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_key_value'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_key_value') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_key_value'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_key_value_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_key_value_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_key_value_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_account_usage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_account_usage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_account_usage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_allocation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_allocation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_allocation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_bankfee_autogen'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_bankfee_autogen') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_bankfee_autogen'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_bankfee_refdata'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_bankfee_refdata') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_bankfee_refdata'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_doc_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_doc_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_doc_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_document'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_document') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_document'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_draw'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_draw') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_draw'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_item_document'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_item_document') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_item_document'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_special_condition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_special_condition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_special_condition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_status_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_status_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_status_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lc_usage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lc_usage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lc_usage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lic_tax_implication'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lic_tax_implication') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lic_tax_implication'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_license'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_license') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_license'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_license_covers'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_license_covers') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_license_covers'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_limit_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_limit_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_limit_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_live_scenario'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_live_scenario') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_live_scenario'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_live_scenario_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_live_scenario_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_live_scenario_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lm_acctdata_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lm_acctdata_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lm_acctdata_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lm_margin_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lm_margin_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lm_margin_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lm_marketdata_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lm_marketdata_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lm_marketdata_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lm_net_position_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lm_net_position_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lm_net_position_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lm_risk_exch_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lm_risk_exch_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lm_risk_exch_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_lm_risk_file'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_lm_risk_file') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_lm_risk_file'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_location'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_location') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_location'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_location_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_location_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_location_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_location_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_location_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_location_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_location_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_location_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_location_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_location_tank_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_location_tank_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_location_tank_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_location_tank_info_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_location_tank_info_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_location_tank_info_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_location_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_location_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_location_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_margin_call'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_margin_call') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_margin_call'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_market_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_market_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_market_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_market_formula_default'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_market_formula_default') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_market_formula_default'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_market_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_market_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_market_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_market_price_quote_dates'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_market_price_quote_dates') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_market_price_quote_dates'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_market_pricing_condition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_market_pricing_condition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_market_pricing_condition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_market_pricing_costs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_market_pricing_costs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_market_pricing_costs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_market_pricing_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_market_pricing_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_market_pricing_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_market_value'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_market_value') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_market_value'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_marketable_security'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_marketable_security') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_marketable_security'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_marketdata_supplier'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_marketdata_supplier') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_marketdata_supplier'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_master_coll_agreement'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_master_coll_agreement') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_master_coll_agreement'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_material_adv_chg_clause'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_material_adv_chg_clause') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_material_adv_chg_clause'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mca_account'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mca_account') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mca_account'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mca_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mca_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mca_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mca_invoice_terms'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mca_invoice_terms') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mca_invoice_terms'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mca_mat_adv_chg_clause'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mca_mat_adv_chg_clause') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mca_mat_adv_chg_clause'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mca_trade_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mca_trade_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mca_trade_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mot'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mot') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mot'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mot_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mot_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mot_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mot_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mot_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mot_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mot_location'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mot_location') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mot_location'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mot_location_tariff'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mot_location_tariff') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mot_location_tariff'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mot_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mot_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mot_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mot_type_for_order'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mot_type_for_order') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mot_type_for_order'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_mtm_cash_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_mtm_cash_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_mtm_cash_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_noise_band_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_noise_band_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_noise_band_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_operation_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_operation_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_operation_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_option_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_option_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_option_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_option_skew'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_option_skew') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_option_skew'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_option_strike'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_option_strike') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_option_strike'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_option_strike_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_option_strike_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_option_strike_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_order_instruction'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_order_instruction') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_order_instruction'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_order_term_evergreen'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_order_term_evergreen') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_order_term_evergreen'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_order_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_order_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_order_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_otc_option'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_otc_option') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_otc_option'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_otc_option_value'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_otc_option_value') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_otc_option_value'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_paper_allocation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_paper_allocation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_paper_allocation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_paper_allocation_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_paper_allocation_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_paper_allocation_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_parcel'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_parcel') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_parcel'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_parcel_quality_slate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_parcel_quality_slate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_parcel_quality_slate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_parcel_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_parcel_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_parcel_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_parent_guar_subs_covered'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_parent_guar_subs_covered') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_parent_guar_subs_covered'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_parent_guarantee'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_parent_guarantee') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_parent_guarantee'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_parent_guarantee_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_parent_guarantee_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_parent_guarantee_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_parser'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_parser') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_parser'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_parser_field'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_parser_field') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_parser_field'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_parser_field_map'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_parser_field_map') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_parser_field_map'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_pass_control_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_pass_control_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_pass_control_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_path'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_path') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_path'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_path_segment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_path_segment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_path_segment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_payment_method'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_payment_method') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_payment_method'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_payment_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_payment_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_payment_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_pcg_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_pcg_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_pcg_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_pei_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_pei_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_pei_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_pipeline_cycle'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_pipeline_cycle') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_pipeline_cycle'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_pl_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_pl_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_pl_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_pl_offset_transfer'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_pl_offset_transfer') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_pl_offset_transfer'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_pl_reconciliation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_pl_reconciliation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_pl_reconciliation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_pm_trade_match_criteria'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_pm_trade_match_criteria') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_pm_trade_match_criteria'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_pm_type_b_record'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_pm_type_b_record') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_pm_type_b_record'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_portfolio'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_portfolio') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_portfolio'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_portfolio_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_portfolio_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_portfolio_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_portfolio_edpl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_portfolio_edpl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_portfolio_edpl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_portfolio_eod'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_portfolio_eod') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_portfolio_eod'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_portfolio_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_portfolio_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_portfolio_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_portfolio_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_portfolio_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_portfolio_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_portfolio_group_eod'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_portfolio_group_eod') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_portfolio_group_eod'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_portfolio_jv'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_portfolio_jv') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_portfolio_jv'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_portfolio_pos_limit'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_portfolio_pos_limit') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_portfolio_pos_limit'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_portfolio_profit_loss'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_portfolio_profit_loss') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_portfolio_profit_loss'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_pos_limit_definition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_pos_limit_definition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_pos_limit_definition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_position'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_position') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_position'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_position_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_position_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_position_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_position_group_eod'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_position_group_eod') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_position_group_eod'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_position_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_position_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_position_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_position_mark_to_market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_position_mark_to_market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_position_mark_to_market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_posting_account'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_posting_account') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_posting_account'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_price_change'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_price_change') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_price_change'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_price_source'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_price_source') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_price_source'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_priced_quote_period'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_priced_quote_period') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_priced_quote_period'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_product'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_product') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_product'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_product_usage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_product_usage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_product_usage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ps_group_code_ref'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ps_group_code_ref') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ps_group_code_ref'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_purchase_sale_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_purchase_sale_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_purchase_sale_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_qty_adj_rule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_qty_adj_rule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_qty_adj_rule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_qual_slate_cmdty_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_qual_slate_cmdty_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_qual_slate_cmdty_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_qual_slate_cmdty_sptest'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_qual_slate_cmdty_sptest') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_qual_slate_cmdty_sptest'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_quality_slate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_quality_slate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_quality_slate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''AUD_QUERIES'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.AUD_QUERIES') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'AUD_QUERIES'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_quote'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_quote') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_quote'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_quote_marketdata_source'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_quote_marketdata_source') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_quote_marketdata_source'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_quote_period_description'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_quote_period_description') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_quote_period_description'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_quote_period_duration'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_quote_period_duration') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_quote_period_duration'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_quote_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_quote_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_quote_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_quote_price_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_quote_price_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_quote_price_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_quote_pricing_period'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_quote_pricing_period') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_quote_pricing_period'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_rc_assign_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_rc_assign_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_rc_assign_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_rc_code'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_rc_code') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_rc_code'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_rc_instr_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_rc_instr_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_rc_instr_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_rc_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_rc_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_rc_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_realiza_price_frg_cost'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_realiza_price_frg_cost') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_realiza_price_frg_cost'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_release_document'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_release_document') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_release_document'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_release_document_driver'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_release_document_driver') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_release_document_driver'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_reprice_event'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_reprice_event') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_reprice_event'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_reprice_event_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_reprice_event_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_reprice_event_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_resource_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_resource_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_resource_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_rin_definition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_rin_definition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_rin_definition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_rin_equivalence'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_rin_equivalence') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_rin_equivalence'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_rin_obligation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_rin_obligation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_rin_obligation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_risk_cover'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_risk_cover') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_risk_cover'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_risk_transfer_indicator'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_risk_transfer_indicator') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_risk_transfer_indicator'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_riskmgr_win_def'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_riskmgr_win_def') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_riskmgr_win_def'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_riskmgr_win_pivot_def'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_riskmgr_win_pivot_def') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_riskmgr_win_pivot_def'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_sap_confirmation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_sap_confirmation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_sap_confirmation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_scenario'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_scenario') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_scenario'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_scenario_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_scenario_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_scenario_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_segment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_segment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_segment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_send_to_SAP'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_send_to_SAP') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_send_to_SAP'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_shipment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_shipment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_shipment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_shipment_chain'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_shipment_chain') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_shipment_chain'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_shipment_mot'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_shipment_mot') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_shipment_mot'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_shipment_path'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_shipment_path') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_shipment_path'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_shipment_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_shipment_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_shipment_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_simple_formula'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_simple_formula') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_simple_formula'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_special_condition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_special_condition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_special_condition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_specification'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_specification') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_specification'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_specification_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_specification_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_specification_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_spread_composition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_spread_composition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_spread_composition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_state'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_state') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_state'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_strategy'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_strategy') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_strategy'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_substituted_text'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_substituted_text') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_substituted_text'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_symphony_outbound_data'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_symphony_outbound_data') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_symphony_outbound_data'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_sys_resources'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_sys_resources') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_sys_resources'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_tax'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_tax') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_tax'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_tax_location'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_tax_location') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_tax_location'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_tax_qualification_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_tax_qualification_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_tax_qualification_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_tax_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_tax_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_tax_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_tax_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_tax_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_tax_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_ti_mark_to_market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_ti_mark_to_market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_ti_mark_to_market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_tid_mark_to_market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_tid_mark_to_market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_tid_mark_to_market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_tid_mtm_correlation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_tid_mtm_correlation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_tid_mtm_correlation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_tid_mtm_volatility'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_tid_mtm_volatility') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_tid_mtm_volatility'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_tid_pl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_tid_pl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_tid_pl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_time_zone'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_time_zone') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_time_zone'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_default'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_default') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_default'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_feed'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_feed') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_feed'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_formula'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_formula') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_formula'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_group_cmdty_mkt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_group_cmdty_mkt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_group_cmdty_mkt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_bunker'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_bunker') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_bunker'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_cash_phy'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_cash_phy') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_cash_phy'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_cleared'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_cleared') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_cleared'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_curr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_curr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_curr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_dist'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_dist') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_dist'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_dry_phy'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_dry_phy') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_dry_phy'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_edpl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_edpl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_edpl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_exch_opt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_exch_opt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_exch_opt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_fill'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_fill') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_fill'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_fill_fifo'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_fill_fifo') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_fill_fifo'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_fut'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_fut') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_fut'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_otc_opt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_otc_opt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_otc_opt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_pl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_pl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_pl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_rin'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_rin') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_rin'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_storage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_storage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_storage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_transport'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_transport') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_transport'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_item_wet_phy'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_item_wet_phy') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_item_wet_phy'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_order'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_order') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_order'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_order_bal'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_order_bal') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_order_bal'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_order_bunker'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_order_bunker') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_order_bunker'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_order_on_exch'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_order_on_exch') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_order_on_exch'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_order_pos_effect'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_order_pos_effect') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_order_pos_effect'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_sync'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_sync') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_sync'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_tenor'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_tenor') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_tenor'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trade_term_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trade_term_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trade_term_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trading_period'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trading_period') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trading_period'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_trading_period_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_trading_period_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_trading_period_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_transport_cost_schedule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_transport_cost_schedule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_transport_cost_schedule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_tripartite_assignment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_tripartite_assignment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_tripartite_assignment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_uic_report_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_uic_report_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_uic_report_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_uic_rpt_criteria'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_uic_rpt_criteria') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_uic_rpt_criteria'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_uic_rpt_criteria_entity'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_uic_rpt_criteria_entity') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_uic_rpt_criteria_entity'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_uic_rpt_values_config'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_uic_rpt_values_config') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_uic_rpt_values_config'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_uic_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_uic_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_uic_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_umpire_rule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_umpire_rule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_umpire_rule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_uom'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_uom') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_uom'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_uom_conversion'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_uom_conversion') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_uom_conversion'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_user_contact'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_user_contact') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_user_contact'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_user_default'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_user_default') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_user_default'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_user_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_user_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_user_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_user_login_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_user_login_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_user_login_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_user_resources'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_user_resources') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_user_resources'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_user_user_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_user_user_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_user_user_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_uur_tool_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_uur_tool_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_uur_tool_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_valid_quote_duration'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_valid_quote_duration') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_valid_quote_duration'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_var_component'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_var_component') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_var_component'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_var_ext_position'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_var_ext_position') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_var_ext_position'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_var_limit'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_var_limit') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_var_limit'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_var_output'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_var_output') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_var_output'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_var_pnl_distribution'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_var_pnl_distribution') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_var_pnl_distribution'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_var_run'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_var_run') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_var_run'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_var_run_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_var_run_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_var_run_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_varfeed_beta'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_varfeed_beta') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_varfeed_beta'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_vat_declaration'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_vat_declaration') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_vat_declaration'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_vat_trans_nature'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_vat_trans_nature') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_vat_trans_nature'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_vat_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_vat_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_vat_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_venue'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_venue') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_venue'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_vessel_dist'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_vessel_dist') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_vessel_dist'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voucher'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voucher') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voucher'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voucher_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voucher_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voucher_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voucher_approval'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voucher_approval') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voucher_approval'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voucher_category'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voucher_category') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voucher_category'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voucher_cost'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voucher_cost') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voucher_cost'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voucher_duedate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voucher_duedate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voucher_duedate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voucher_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voucher_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voucher_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voucher_pay_approval'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voucher_pay_approval') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voucher_pay_approval'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voucher_payment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voucher_payment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voucher_payment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voucher_relation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voucher_relation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voucher_relation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voucher_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voucher_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voucher_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voucher_vat'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voucher_vat') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voucher_vat'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''aud_voyage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.aud_voyage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'aud_voyage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''autopool_criteria'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.autopool_criteria') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'autopool_criteria'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''avg_buy_sell_price_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.avg_buy_sell_price_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'avg_buy_sell_price_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''balmo_product'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.balmo_product') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'balmo_product'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bank_credit_alarm_log'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bank_credit_alarm_log') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bank_credit_alarm_log'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bank_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bank_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bank_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bank_exposure_summary'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bank_exposure_summary') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bank_exposure_summary'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bc_mail_criteria_time'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bc_mail_criteria_time') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bc_mail_criteria_time'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''BI_snapshot_pos_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.BI_snapshot_pos_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'BI_snapshot_pos_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''booked_inv_reconcil'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.booked_inv_reconcil') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'booked_inv_reconcil'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''booking_company_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.booking_company_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'booking_company_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''booking_period'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.booking_period') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'booking_period'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''broker_commission_default'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.broker_commission_default') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'broker_commission_default'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''broker_cost_autogen'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.broker_cost_autogen') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'broker_cost_autogen'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''broker_cost_step_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.broker_cost_step_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'broker_cost_step_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''broker_fifo_run_rec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.broker_fifo_run_rec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'broker_fifo_run_rec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''broker_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.broker_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'broker_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bulk_voucher_assigned'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bulk_voucher_assigned') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bulk_voucher_assigned'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bulk_voucher_processed'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bulk_voucher_processed') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bulk_voucher_processed'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bulk_voucher_queue'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bulk_voucher_queue') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bulk_voucher_queue'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bunker_pur_price_lookup'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bunker_pur_price_lookup') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bunker_pur_price_lookup'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_child_gen'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_child_gen') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_child_gen'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_fate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_fate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_fate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_fate_date'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_fate_date') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_fate_date'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_fate_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_fate_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_fate_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_leaf'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_leaf') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_leaf'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_mail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_mail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_mail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_mail_list'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_mail_list') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_mail_list'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_mail_time'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_mail_time') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_mail_time'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_matriarch'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_matriarch') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_matriarch'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_num_children'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_num_children') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_num_children'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_order_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_order_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_order_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_state'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_state') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_state'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_sub_owner'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_sub_owner') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_sub_owner'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''bus_cost_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.bus_cost_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'bus_cost_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''calendar'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.calendar') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'calendar'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''calendar_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.calendar_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'calendar_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cash_coll_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cash_coll_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cash_coll_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cash_collateral'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cash_collateral') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cash_collateral'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cash_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cash_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cash_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cash_forecast_file'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cash_forecast_file') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cash_forecast_file'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cash_settle_date'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cash_settle_date') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cash_settle_date'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cki_outbound_data'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cki_outbound_data') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cki_outbound_data'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cki_upload_actuals_feed_data'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cki_upload_actuals_feed_data') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cki_upload_actuals_feed_data'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cmdty_nomenclature'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cmdty_nomenclature') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cmdty_nomenclature'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cmf_dependency'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cmf_dependency') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cmf_dependency'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cmf_for_price_update'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cmf_for_price_update') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cmf_for_price_update'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''collateral_party'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.collateral_party') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'collateral_party'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''collateral_pledged'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.collateral_pledged') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'collateral_pledged'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''collateral_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.collateral_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'collateral_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commkt_clrd_swap_attr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commkt_clrd_swap_attr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commkt_clrd_swap_attr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commkt_future_attr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commkt_future_attr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commkt_future_attr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commkt_option_attr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commkt_option_attr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commkt_option_attr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commkt_physical_attr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commkt_physical_attr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commkt_physical_attr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commkt_source_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commkt_source_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commkt_source_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commkt_source_roll_date'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commkt_source_roll_date') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commkt_source_roll_date'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commkt_src_alias_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commkt_src_alias_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commkt_src_alias_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_by_rollup_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_by_rollup_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_by_rollup_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_category'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_category') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_category'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_char_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_char_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_char_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_desc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_desc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_desc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_group_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_group_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_group_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_location'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_location') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_location'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_market_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_market_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_market_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_market_formula'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_market_formula') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_market_formula'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_market_source'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_market_source') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_market_source'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_rollup_hierarchy'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_rollup_hierarchy') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_rollup_hierarchy'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_rollup_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_rollup_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_rollup_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_specification'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_specification') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_specification'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''commodity_uom'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_uom') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'commodity_uom'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''company_code_list'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.company_code_list') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'company_code_list'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''confirm_method'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.confirm_method') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'confirm_method'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''confirm_template'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.confirm_template') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'confirm_template'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''constants'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.constants') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'constants'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''contract'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.contract') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'contract'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''contract_analyst'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.contract_analyst') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'contract_analyst'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''contract_message_list'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.contract_message_list') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'contract_message_list'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''contract_skeleton'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.contract_skeleton') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'contract_skeleton'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''contract_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.contract_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'contract_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''contract_transmission'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.contract_transmission') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'contract_transmission'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''correlation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.correlation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'correlation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_approval'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_approval') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_approval'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_center'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_center') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_center'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_code'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_code') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_code'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_composite'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_composite') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_composite'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_credit_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_credit_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_credit_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_distribution'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_distribution') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_distribution'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_equalization_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_equalization_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_equalization_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_interface_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_interface_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_interface_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_owner'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_owner') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_owner'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_price_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_price_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_price_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_relative_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_relative_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_relative_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_report_snapshot'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_report_snapshot') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_report_snapshot'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_scheduled_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_scheduled_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_scheduled_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_scheduled_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_scheduled_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_scheduled_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_specification'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_specification') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_specification'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_template'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_template') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_template'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_template_cntparty'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_template_cntparty') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_template_cntparty'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_template_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_template_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_template_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_template_grp_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_template_grp_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_template_grp_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_template_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_template_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_template_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''cost_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'cost_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''country'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.country') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'country'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''country_by_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.country_by_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'country_by_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''country_credit_alarm_log'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.country_credit_alarm_log') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'country_credit_alarm_log'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''country_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.country_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'country_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''country_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.country_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'country_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''credit_alarm'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.credit_alarm') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'credit_alarm'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''credit_alarm_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.credit_alarm_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'credit_alarm_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''credit_alarm_log'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.credit_alarm_log') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'credit_alarm_log'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''credit_alarm_log_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.credit_alarm_log_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'credit_alarm_log_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''credit_bus_category'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.credit_bus_category') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'credit_bus_category'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''credit_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.credit_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'credit_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''credit_limit'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.credit_limit') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'credit_limit'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''credit_limit_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.credit_limit_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'credit_limit_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''credit_reserve'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.credit_reserve') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'credit_reserve'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''credit_sector'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.credit_sector') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'credit_sector'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''credit_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.credit_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'credit_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''credit_term_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.credit_term_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'credit_term_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''currency_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.currency_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'currency_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''custom_contract_range'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.custom_contract_range') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'custom_contract_range'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''custom_voucher_range'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.custom_voucher_range') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'custom_voucher_range'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''dashboard_configuration'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.dashboard_configuration') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'dashboard_configuration'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''dashboard_errorlog'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.dashboard_errorlog') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'dashboard_errorlog'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''data_file'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.data_file') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'data_file'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''database_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.database_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'database_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''dbupgrade_log'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.dbupgrade_log') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'dbupgrade_log'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''defaults_domain'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.defaults_domain') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'defaults_domain'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''delivery_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.delivery_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'delivery_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''delivery_term_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.delivery_term_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'delivery_term_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''department'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.department') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'department'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''desk'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.desk') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'desk'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''desk_location'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.desk_location') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'desk_location'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''document'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.document') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'document'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''document_message'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.document_message') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'document_message'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''document_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.document_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'document_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''driver'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.driver') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'driver'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''edpl_event'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.edpl_event') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'edpl_event'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''eipp_task'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.eipp_task') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'eipp_task'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''eipp_task_name'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.eipp_task_name') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'eipp_task_name'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''entity_key_name'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.entity_key_name') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'entity_key_name'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''entity_tag'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.entity_tag') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'entity_tag'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''entity_tag_definition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.entity_tag_definition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'entity_tag_definition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''entity_tag_insp_attr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.entity_tag_insp_attr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'entity_tag_insp_attr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''entity_tag_option'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.entity_tag_option') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'entity_tag_option'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''eo_sequence_table'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.eo_sequence_table') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'eo_sequence_table'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''eom_posting_batch'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.eom_posting_batch') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'eom_posting_batch'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''event'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.event') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'event'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''event_price_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.event_price_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'event_price_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''exceptions_additions'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.exceptions_additions') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'exceptions_additions'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''exch_fifo_alloc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.exch_fifo_alloc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'exch_fifo_alloc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''exch_fifo_alloc_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.exch_fifo_alloc_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'exch_fifo_alloc_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''exch_tools_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.exch_tools_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'exch_tools_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''exch_tools_trade_archive'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.exch_tools_trade_archive') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'exch_tools_trade_archive'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''execution_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.execution_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'execution_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''exposure_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.exposure_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'exposure_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ext_ref_keys'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ext_ref_keys') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ext_ref_keys'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ext_refdata_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ext_refdata_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ext_refdata_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ext_trade_loading_sched'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ext_trade_loading_sched') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ext_trade_loading_sched'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ext_trandata_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ext_trandata_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ext_trandata_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ext_trans_keys'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ext_trans_keys') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ext_trans_keys'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''external_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.external_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'external_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''external_comment_archive'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.external_comment_archive') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'external_comment_archive'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''external_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.external_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'external_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''external_position'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.external_position') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'external_position'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''external_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.external_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'external_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''external_trade_archive'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.external_trade_archive') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'external_trade_archive'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''external_trade_source'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.external_trade_source') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'external_trade_source'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''external_trade_state'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.external_trade_state') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'external_trade_state'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''external_trade_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.external_trade_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'external_trade_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''external_trade_system'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.external_trade_system') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'external_trade_system'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''external_trade_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.external_trade_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'external_trade_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''facility'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.facility') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'facility'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''facility_commodity'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.facility_commodity') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'facility_commodity'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''facility_link'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.facility_link') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'facility_link'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''facility_mot'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.facility_mot') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'facility_mot'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''facility_tank_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.facility_tank_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'facility_tank_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''facility_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.facility_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'facility_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fb_event_price_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fb_event_price_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fb_event_price_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fb_modular_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fb_modular_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fb_modular_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_cash_inbound'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_cash_inbound') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_cash_inbound'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_data'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_data') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_data'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_data_archive'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_data_archive') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_data_archive'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_definition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_definition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_definition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_definition_xsd_xml'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_definition_xsd_xml') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_definition_xsd_xml'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_detail_data'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_detail_data') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_detail_data'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_detail_data_archive'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_detail_data_archive') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_detail_data_archive'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_error'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_error') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_error'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_error_archive'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_error_archive') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_error_archive'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_refdata_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_refdata_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_refdata_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_scheduler'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_scheduler') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_scheduler'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_trans_sequence'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_trans_sequence') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_trans_sequence'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_transaction'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_transaction') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_transaction'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_transaction_archive'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_transaction_archive') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_transaction_archive'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_xsd_xml_text'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_xsd_xml_text') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_xsd_xml_text'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''feed_xsd_xml_text_archive'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.feed_xsd_xml_text_archive') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'feed_xsd_xml_text_archive'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fifo_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fifo_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fifo_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''file_load'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.file_load') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'file_load'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''file_load_error'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.file_load_error') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'file_load_error'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''filedownloader'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.filedownloader') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'filedownloader'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''filters'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.filters') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'filters'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''financial_reconcil'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.financial_reconcil') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'financial_reconcil'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fips_city'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fips_city') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fips_city'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fips_county'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fips_county') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fips_county'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fips_state'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fips_state') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fips_state'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fiscal_classification'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fiscal_classification') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fiscal_classification'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''FL_GROUPS'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.FL_GROUPS') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'FL_GROUPS'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''FL_GROUPS_ROLES'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.FL_GROUPS_ROLES') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'FL_GROUPS_ROLES'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''FL_GROUPS_USERS'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.FL_GROUPS_USERS') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'FL_GROUPS_USERS'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''FL_ROLES'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.FL_ROLES') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'FL_ROLES'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''FL_USERS'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.FL_USERS') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'FL_USERS'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''FL_USERS_ROLES'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.FL_USERS_ROLES') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'FL_USERS_ROLES'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''flat_rates'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.flat_rates') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'flat_rates'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''folder'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.folder') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'folder'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''folder_document'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.folder_document') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'folder_document'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''forecast_value'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.forecast_value') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'forecast_value'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''formula'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.formula') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'formula'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''formula_body'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.formula_body') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'formula_body'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''formula_body_trigger'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.formula_body_trigger') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'formula_body_trigger'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''formula_body_trigger_actual'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.formula_body_trigger_actual') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'formula_body_trigger_actual'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''formula_comp_price_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.formula_comp_price_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'formula_comp_price_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''formula_component'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.formula_component') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'formula_component'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''formula_component_ext'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.formula_component_ext') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'formula_component_ext'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''formula_condition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.formula_condition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'formula_condition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''FREIGHT_DBINFO'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.FREIGHT_DBINFO') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'FREIGHT_DBINFO'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''function_action'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.function_action') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'function_action'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''function_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.function_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'function_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''function_detail_value'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.function_detail_value') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'function_detail_value'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fx_cost_draw_down_hist'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fx_cost_draw_down_hist') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fx_cost_draw_down_hist'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fx_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fx_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fx_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fx_exposure_currency'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fx_exposure_currency') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fx_exposure_currency'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fx_exposure_dist'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fx_exposure_dist') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fx_exposure_dist'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fx_exposure_pl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fx_exposure_pl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fx_exposure_pl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fx_exposure_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fx_exposure_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fx_exposure_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fx_hedge_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fx_hedge_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fx_hedge_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fx_linked_costs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fx_linked_costs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fx_linked_costs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fx_linking'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fx_linking') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fx_linking'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''fx_rate_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.fx_rate_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'fx_rate_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''gdd_attribute_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.gdd_attribute_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'gdd_attribute_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''generic_data_definition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.generic_data_definition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'generic_data_definition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''generic_data_name'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.generic_data_name') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'generic_data_name'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''generic_data_values'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.generic_data_values') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'generic_data_values'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''gl_account_balance'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.gl_account_balance') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'gl_account_balance'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''gl_account_validity'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.gl_account_validity') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'gl_account_validity'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''glfile_bh'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.glfile_bh') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'glfile_bh'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''glfile_fh'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.glfile_fh') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'glfile_fh'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''glfile_td'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.glfile_td') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'glfile_td'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''glfile_th'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.glfile_th') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'glfile_th'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''grade_commodity_market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.grade_commodity_market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'grade_commodity_market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''gravity_adj'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.gravity_adj') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'gravity_adj'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''gravity_table_name'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.gravity_table_name') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'gravity_table_name'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''gtc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.gtc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'gtc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''handling_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.handling_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'handling_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''hedge_physical'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.hedge_physical') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'hedge_physical'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''historical_volatility'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.historical_volatility') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'historical_volatility'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ice_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ice_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ice_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ice_trade_archive'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ice_trade_archive') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ice_trade_archive'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''icts_entity_name'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.icts_entity_name') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'icts_entity_name'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''icts_function'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.icts_function') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'icts_function'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''icts_message'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.icts_message') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'icts_message'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''icts_message_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.icts_message_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'icts_message_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''icts_product'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.icts_product') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'icts_product'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''icts_timezones'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.icts_timezones') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'icts_timezones'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''icts_trans_sequence'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.icts_trans_sequence') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'icts_trans_sequence'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''icts_transaction'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.icts_transaction') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'icts_transaction'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''icts_user'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.icts_user') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'icts_user'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''icts_user_permission'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.icts_user_permission') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'icts_user_permission'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''idms_board_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.idms_board_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'idms_board_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''idms_department_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.idms_department_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'idms_department_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''idms_location_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.idms_location_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'idms_location_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''implied_pr_curve'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.implied_pr_curve') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'implied_pr_curve'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''implied_pr_curve_hist'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.implied_pr_curve_hist') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'implied_pr_curve_hist'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''implied_pr_differential'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.implied_pr_differential') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'implied_pr_differential'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''importer_record_reason'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.importer_record_reason') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'importer_record_reason'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inhouse_post'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inhouse_post') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inhouse_post'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''interco_map'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.interco_map') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'interco_map'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''interface_exec_params'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.interface_exec_params') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'interface_exec_params'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inv_actual'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inv_actual') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inv_actual'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inv_actual_fifo'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inv_actual_fifo') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inv_actual_fifo'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inv_build_draw_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inv_build_draw_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inv_build_draw_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inv_credit_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inv_credit_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inv_credit_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inv_pricing_period'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inv_pricing_period') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inv_pricing_period'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inventory'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inventory') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inventory'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inventory_balance'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inventory_balance') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inventory_balance'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inventory_build_draw'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inventory_build_draw') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inventory_build_draw'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inventory_bulk_search'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inventory_bulk_search') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inventory_bulk_search'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inventory_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inventory_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inventory_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inventory_history_mac'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inventory_history_mac') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inventory_history_mac'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inventory_roll_criteria'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inventory_roll_criteria') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inventory_roll_criteria'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''inventory_voyage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.inventory_voyage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'inventory_voyage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''job_schedule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.job_schedule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'job_schedule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''key_value'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.key_value') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'key_value'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''key_value_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.key_value_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'key_value_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_account_usage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_account_usage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_account_usage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_allocation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_allocation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_allocation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_bankfee_autogen'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_bankfee_autogen') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_bankfee_autogen'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_bankfee_refdata'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_bankfee_refdata') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_bankfee_refdata'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_doc_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_doc_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_doc_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_document'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_document') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_document'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_draw'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_draw') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_draw'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_item_document'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_item_document') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_item_document'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_special_condition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_special_condition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_special_condition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_status_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_status_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_status_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lc_usage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_usage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lc_usage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lic_tax_implication'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lic_tax_implication') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lic_tax_implication'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''license'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.license') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'license'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''license_covers'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.license_covers') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'license_covers'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''limit_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.limit_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'limit_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''live_detail_daily'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.live_detail_daily') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'live_detail_daily'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''live_option_pr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.live_option_pr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'live_option_pr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''live_option_pr_hist'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.live_option_pr_hist') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'live_option_pr_hist'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''live_scenario'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.live_scenario') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'live_scenario'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''live_scenario_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.live_scenario_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'live_scenario_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''live_summary_daily'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.live_summary_daily') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'live_summary_daily'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lm_acctdata_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lm_acctdata_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lm_acctdata_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lm_margin_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lm_margin_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lm_margin_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lm_marketdata_mapping'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lm_marketdata_mapping') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lm_marketdata_mapping'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lm_net_position_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lm_net_position_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lm_net_position_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lm_risk_exch_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lm_risk_exch_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lm_risk_exch_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''lm_risk_file'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lm_risk_file') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'lm_risk_file'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''loc_type_by_order'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.loc_type_by_order') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'loc_type_by_order'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''location'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.location') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'location'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''location_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.location_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'location_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''location_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.location_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'location_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''location_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.location_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'location_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''location_tank_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.location_tank_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'location_tank_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''location_tank_info_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.location_tank_info_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'location_tank_info_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''location_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.location_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'location_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''locked_pl_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.locked_pl_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'locked_pl_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''locked_ti_mtm'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.locked_ti_mtm') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'locked_ti_mtm'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''locked_tid_mtm'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.locked_tid_mtm') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'locked_tid_mtm'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''margin_call'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.margin_call') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'margin_call'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''market_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.market_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'market_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''market_formula_default'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.market_formula_default') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'market_formula_default'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''market_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.market_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'market_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''market_info_cmnt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.market_info_cmnt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'market_info_cmnt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''market_price_formula'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.market_price_formula') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'market_price_formula'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''market_price_quote_dates'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.market_price_quote_dates') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'market_price_quote_dates'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''market_pricing_condition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.market_pricing_condition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'market_pricing_condition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''market_pricing_costs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.market_pricing_costs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'market_pricing_costs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''market_pricing_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.market_pricing_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'market_pricing_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''market_value'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.market_value') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'market_value'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''marketable_security'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.marketable_security') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'marketable_security'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''marketdata_supplier'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.marketdata_supplier') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'marketdata_supplier'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''master_coll_agreement'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.master_coll_agreement') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'master_coll_agreement'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''material_adv_chg_clause'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.material_adv_chg_clause') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'material_adv_chg_clause'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mca_account'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mca_account') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mca_account'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mca_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mca_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mca_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mca_invoice_terms'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mca_invoice_terms') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mca_invoice_terms'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mca_mat_adv_chg_clause'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mca_mat_adv_chg_clause') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mca_mat_adv_chg_clause'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mca_payment_method'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mca_payment_method') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mca_payment_method'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mca_payment_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mca_payment_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mca_payment_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mca_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mca_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mca_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mca_trade_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mca_trade_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mca_trade_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mf_account_contact'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mf_account_contact') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mf_account_contact'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mf_account_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mf_account_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mf_account_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mf_account_instruction'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mf_account_instruction') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mf_account_instruction'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mot'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mot') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mot'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mot_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mot_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mot_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mot_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mot_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mot_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mot_location'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mot_location') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mot_location'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mot_location_tariff'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mot_location_tariff') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mot_location_tariff'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mot_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mot_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mot_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mot_type_for_order'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mot_type_for_order') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mot_type_for_order'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mrk_sec_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mrk_sec_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mrk_sec_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_feed_data'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_feed_data') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_feed_data'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_inbound_actual'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_inbound_actual') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_inbound_actual'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_inbound_contract_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_inbound_contract_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_inbound_contract_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_inbound_credit_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_inbound_credit_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_inbound_credit_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_inbound_invoice'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_inbound_invoice') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_inbound_invoice'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_inbound_payment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_inbound_payment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_inbound_payment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_inbound_shipment_parcel'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_inbound_shipment_parcel') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_inbound_shipment_parcel'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_md_inbound_account'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_md_inbound_account') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_md_inbound_account'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_md_inbound_bank'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_md_inbound_bank') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_md_inbound_bank'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_md_inbound_location'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_md_inbound_location') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_md_inbound_location'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_md_inbound_material'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_md_inbound_material') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_md_inbound_material'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_md_inbound_taxrep'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_md_inbound_taxrep') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_md_inbound_taxrep'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_md_inbound_vehicle'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_md_inbound_vehicle') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_md_inbound_vehicle'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''msi_outbound_data'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.msi_outbound_data') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'msi_outbound_data'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mtm_cash_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mtm_cash_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mtm_cash_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''mtm_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.mtm_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'mtm_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''new_num'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.new_num') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'new_num'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''noise_band_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.noise_band_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'noise_band_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''operation_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.operation_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'operation_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''option_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.option_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'option_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''option_skew'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.option_skew') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'option_skew'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''option_strike'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.option_strike') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'option_strike'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''option_strike_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.option_strike_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'option_strike_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''order_instruction'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.order_instruction') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'order_instruction'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''order_term_evergreen'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.order_term_evergreen') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'order_term_evergreen'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''order_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.order_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'order_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''order_type_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.order_type_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'order_type_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''order_type_grp_desc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.order_type_grp_desc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'order_type_grp_desc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''otc_option'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.otc_option') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'otc_option'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''otc_option_value'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.otc_option_value') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'otc_option_value'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''paper_allocation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.paper_allocation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'paper_allocation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''paper_allocation_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.paper_allocation_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'paper_allocation_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''parcel'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.parcel') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'parcel'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''parcel_bulk_search'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.parcel_bulk_search') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'parcel_bulk_search'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''parcel_quality_slate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.parcel_quality_slate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'parcel_quality_slate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''parcel_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.parcel_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'parcel_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''parent_guar_subs_covered'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.parent_guar_subs_covered') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'parent_guar_subs_covered'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''parent_guarantee'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.parent_guarantee') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'parent_guarantee'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''parent_guarantee_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.parent_guarantee_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'parent_guarantee_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''parser'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.parser') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'parser'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''parser_field'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.parser_field') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'parser_field'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''parser_field_map'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.parser_field_map') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'parser_field_map'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pass_control_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pass_control_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pass_control_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pass_schedule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pass_schedule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pass_schedule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pass_schedule_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pass_schedule_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pass_schedule_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''path'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.path') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'path'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''path_segment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.path_segment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'path_segment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''payment_method'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.payment_method') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'payment_method'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''payment_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.payment_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'payment_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pcg_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pcg_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pcg_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pdfx_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pdfx_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pdfx_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pei_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pei_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pei_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pei_comment_cmnt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pei_comment_cmnt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pei_comment_cmnt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pipeline_cycle'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pipeline_cycle') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pipeline_cycle'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pl_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pl_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pl_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pl_offset_transfer'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pl_offset_transfer') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pl_offset_transfer'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pl_reconciliation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pl_reconciliation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pl_reconciliation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pm_trade_match_criteria'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pm_trade_match_criteria') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pm_trade_match_criteria'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pm_type_4_record'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pm_type_4_record') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pm_type_4_record'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pm_type_5_record'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pm_type_5_record') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pm_type_5_record'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pm_type_a_record'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pm_type_a_record') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pm_type_a_record'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pm_type_b_record'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pm_type_b_record') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pm_type_b_record'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_book_pl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_book_pl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_book_pl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_edpl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_edpl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_edpl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_eod'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_eod') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_eod'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_eod_icon'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_eod_icon') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_eod_icon'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_group_eod'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_group_eod') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_group_eod'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_icon'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_icon') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_icon'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_jv'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_jv') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_jv'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_pos_limit'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_pos_limit') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_pos_limit'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''portfolio_profit_loss'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_profit_loss') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'portfolio_profit_loss'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''pos_limit_definition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.pos_limit_definition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'pos_limit_definition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''POSGRID_excluded_pos_nums'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.POSGRID_excluded_pos_nums') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'POSGRID_excluded_pos_nums'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''POSGRID_pl_history_yearend'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.POSGRID_pl_history_yearend') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'POSGRID_pl_history_yearend'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''POSGRID_snapshot_pos_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.POSGRID_snapshot_pos_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'POSGRID_snapshot_pos_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''POSGRID_snapshot_pos_summary'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.POSGRID_snapshot_pos_summary') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'POSGRID_snapshot_pos_summary'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''position'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.position') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'position'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''position_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.position_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'position_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''position_group_eod'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.position_group_eod') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'position_group_eod'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''position_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.position_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'position_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''position_mark_to_market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.position_mark_to_market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'position_mark_to_market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''posting_account'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.posting_account') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'posting_account'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''posting_bulletin'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.posting_bulletin') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'posting_bulletin'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''posting_search_prec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.posting_search_prec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'posting_search_prec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''price_change'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.price_change') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'price_change'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''price_gravity_adj'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.price_gravity_adj') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'price_gravity_adj'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''price_source'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.price_source') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'price_source'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''price_temp'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.price_temp') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'price_temp'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''priced_quote_period'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.priced_quote_period') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'priced_quote_period'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''product'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.product') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'product'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''product_usage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.product_usage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'product_usage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ps_group_code_ref'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ps_group_code_ref') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ps_group_code_ref'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''purchase_sale_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.purchase_sale_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'purchase_sale_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''qpp_mark_to_market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.qpp_mark_to_market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'qpp_mark_to_market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''qty_adj_rule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.qty_adj_rule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'qty_adj_rule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''qual_slate_cmdty_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.qual_slate_cmdty_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'qual_slate_cmdty_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''qual_slate_cmdty_sptest'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.qual_slate_cmdty_sptest') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'qual_slate_cmdty_sptest'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''quality_slate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.quality_slate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'quality_slate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''QUERIES'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.QUERIES') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'QUERIES'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''quote'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.quote') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'quote'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''quote_marketdata_source'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.quote_marketdata_source') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'quote_marketdata_source'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''quote_period_description'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.quote_period_description') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'quote_period_description'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''quote_period_duration'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.quote_period_duration') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'quote_period_duration'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''quote_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.quote_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'quote_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''quote_price_term'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.quote_price_term') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'quote_price_term'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''quote_pricing_period'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.quote_pricing_period') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'quote_pricing_period'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rabbitmq_security_auth'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rabbitmq_security_auth') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rabbitmq_security_auth'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''railcar_identifier_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.railcar_identifier_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'railcar_identifier_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''railcar_ptp_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.railcar_ptp_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'railcar_ptp_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rc_assign_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rc_assign_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rc_assign_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rc_code'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rc_code') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rc_code'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rc_instr_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rc_instr_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rc_instr_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rc_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rc_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rc_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rc_status_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rc_status_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rc_status_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''realiza_price_frg_cost'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.realiza_price_frg_cost') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'realiza_price_frg_cost'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''recap_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.recap_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'recap_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''reference_tab_list'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.reference_tab_list') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'reference_tab_list'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''release_document'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.release_document') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'release_document'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''release_document_driver'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.release_document_driver') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'release_document_driver'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''reprice_event'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.reprice_event') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'reprice_event'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''reprice_event_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.reprice_event_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'reprice_event_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''resource_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.resource_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'resource_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rg_staging_acct'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rg_staging_acct') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rg_staging_acct'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rg_staging_acct_address'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rg_staging_acct_address') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rg_staging_acct_address'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rg_staging_acct_bank_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rg_staging_acct_bank_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rg_staging_acct_bank_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rin_definition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rin_definition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rin_definition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rin_equivalence'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rin_equivalence') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rin_equivalence'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rin_obligation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rin_obligation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rin_obligation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''risk_cover'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.risk_cover') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'risk_cover'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''risk_transfer_indicator'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.risk_transfer_indicator') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'risk_transfer_indicator'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''risk_value_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.risk_value_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'risk_value_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''riskmgr_win_def'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.riskmgr_win_def') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'riskmgr_win_def'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''riskmgr_win_pivot_def'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.riskmgr_win_pivot_def') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'riskmgr_win_pivot_def'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''route'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.route') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'route'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''route_point'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.route_point') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'route_point'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rt_live_detail_daily'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rt_live_detail_daily') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rt_live_detail_daily'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rt_live_summary_daily'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rt_live_summary_daily') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rt_live_summary_daily'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''rt_vol_exposure'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.rt_vol_exposure') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'rt_vol_exposure'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''sap_confirmation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.sap_confirmation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'sap_confirmation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''SAP_file'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.SAP_file') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'SAP_file'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''scenario'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.scenario') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'scenario'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''scenario_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.scenario_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'scenario_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''search_temp_values'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.search_temp_values') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'search_temp_values'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''segment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.segment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'segment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''send_to_SAP'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.send_to_SAP') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'send_to_SAP'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''server'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.server') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'server'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''server_config'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.server_config') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'server_config'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''shipment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.shipment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'shipment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''shipment_bulk_search'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.shipment_bulk_search') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'shipment_bulk_search'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''shipment_chain'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.shipment_chain') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'shipment_chain'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''shipment_mot'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.shipment_mot') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'shipment_mot'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''shipment_path'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.shipment_path') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'shipment_path'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''shipment_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.shipment_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'shipment_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''simple_formula'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.simple_formula') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'simple_formula'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''spec_test'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.spec_test') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'spec_test'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''special_condition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.special_condition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'special_condition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''specification'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.specification') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'specification'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''specification_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.specification_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'specification_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''spread_composition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.spread_composition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'spread_composition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''spread_template'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.spread_template') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'spread_template'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''state'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.state') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'state'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''strategy'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.strategy') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'strategy'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''substituted_text'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.substituted_text') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'substituted_text'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''symphony_outbound_data'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.symphony_outbound_data') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'symphony_outbound_data'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''sys_resources'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.sys_resources') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'sys_resources'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''tax'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tax') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'tax'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''tax_addtl_costs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tax_addtl_costs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'tax_addtl_costs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''tax_location'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tax_location') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'tax_location'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''tax_qualification_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tax_qualification_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'tax_qualification_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''tax_rate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tax_rate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'tax_rate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''tax_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tax_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'tax_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''temp_docgen_data'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.temp_docgen_data') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'temp_docgen_data'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''temp_value_adjust'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.temp_value_adjust') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'temp_value_adjust'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_book_inv'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_book_inv') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_book_inv'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_bulk_ignore'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_bulk_ignore') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_bulk_ignore'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_demand_forecast'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_demand_forecast') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_demand_forecast'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_exch_bal'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_exch_bal') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_exch_bal'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_feed_definition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_feed_definition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_feed_definition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_feed_error'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_feed_error') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_feed_error'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_feed_schedule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_feed_schedule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_feed_schedule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_feed_trans_sequence'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_feed_trans_sequence') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_feed_trans_sequence'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_feed_transaction'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_feed_transaction') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_feed_transaction'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ti_field_modified'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ti_field_modified') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ti_field_modified'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_financial_results'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_financial_results') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_financial_results'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_inbound_data_xml'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_inbound_data_xml') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_inbound_data_xml'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''ti_mark_to_market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.ti_mark_to_market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'ti_mark_to_market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_PSMV_feed'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_PSMV_feed') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_PSMV_feed'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_PSMVal_feed'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_PSMVal_feed') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_PSMVal_feed'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_PSMVol_spot'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_PSMVol_spot') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_PSMVol_spot'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_rate_table'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_rate_table') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_rate_table'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_refinery_actual'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_refinery_actual') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_refinery_actual'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_req_res_xml'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_req_res_xml') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_req_res_xml'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_RS_refinery_plan'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_RS_refinery_plan') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_RS_refinery_plan'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_SOP_refinery_plan'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_SOP_refinery_plan') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_SOP_refinery_plan'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_sop_trade_plan'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_sop_trade_plan') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_sop_trade_plan'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_TSW_schedule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_TSW_schedule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_TSW_schedule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_TSW_spot'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_TSW_spot') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_TSW_spot'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''TI_ZDEF_exch_objective'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.TI_ZDEF_exch_objective') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'TI_ZDEF_exch_objective'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''tid_mark_to_market'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tid_mark_to_market') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'tid_mark_to_market'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''tid_mtm_correlation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tid_mtm_correlation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'tid_mtm_correlation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''tid_mtm_volatility'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tid_mtm_volatility') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'tid_mtm_volatility'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''tid_pl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tid_pl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'tid_pl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''time_zone'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.time_zone') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'time_zone'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''tmp_position'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tmp_position') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'tmp_position'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''topic_portfolio_mappings'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.topic_portfolio_mappings') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'topic_portfolio_mappings'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_default'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_default') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_default'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_feed'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_feed') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_feed'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_formula'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_formula') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_formula'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_group_cmdty_mkt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_group_cmdty_mkt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_group_cmdty_mkt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_bulk_search'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_bulk_search') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_bulk_search'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_bunker'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_bunker') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_bunker'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_cash_phy'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_cash_phy') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_cash_phy'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_cleared'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_cleared') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_cleared'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_composite'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_composite') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_composite'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_curr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_curr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_curr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_dist'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_dist') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_dist'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_dry_phy'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_dry_phy') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_dry_phy'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_edpl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_edpl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_edpl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_exch_opt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_exch_opt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_exch_opt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_exercise'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_exercise') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_exercise'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_fill'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_fill') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_fill'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_fill_fifo'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_fill_fifo') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_fill_fifo'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_fut'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_fut') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_fut'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_otc_opt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_otc_opt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_otc_opt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_pl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_pl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_pl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_rin'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_rin') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_rin'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_spec'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_spec') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_spec'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_storage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_storage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_storage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_transport'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_transport') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_transport'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_item_wet_phy'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_item_wet_phy') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_item_wet_phy'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_order'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_order') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_order'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_order_bal'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_order_bal') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_order_bal'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_order_bunker'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_order_bunker') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_order_bunker'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_order_on_exch'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_order_on_exch') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_order_on_exch'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_order_pos_effect'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_order_pos_effect') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_order_pos_effect'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_order_railcar'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_order_railcar') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_order_railcar'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_sync'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_sync') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_sync'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_tenor'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_tenor') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_tenor'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trade_term_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_term_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trade_term_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trading_period'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trading_period') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trading_period'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''trading_period_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trading_period_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'trading_period_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''transaction_touch'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.transaction_touch') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'transaction_touch'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''transaction_touch_archive'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.transaction_touch_archive') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'transaction_touch_archive'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''transport_cost_schedule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.transport_cost_schedule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'transport_cost_schedule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''tripartite_assignment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tripartite_assignment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'tripartite_assignment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''truck'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.truck') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'truck'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''uic_report_modification'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.uic_report_modification') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'uic_report_modification'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''uic_report_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.uic_report_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'uic_report_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''uic_reporting_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.uic_reporting_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'uic_reporting_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''uic_rpt_criteria'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.uic_rpt_criteria') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'uic_rpt_criteria'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''uic_rpt_criteria_entity'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.uic_rpt_criteria_entity') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'uic_rpt_criteria_entity'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''uic_rpt_criteria_values'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.uic_rpt_criteria_values') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'uic_rpt_criteria_values'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''uic_rpt_values_config'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.uic_rpt_values_config') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'uic_rpt_values_config'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''uic_status'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.uic_status') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'uic_status'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''umpire_rule'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.umpire_rule') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'umpire_rule'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''uom'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.uom') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'uom'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''uom_conversion'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.uom_conversion') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'uom_conversion'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''user_contact'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.user_contact') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'user_contact'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''user_default'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.user_default') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'user_default'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''user_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.user_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'user_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''user_group_permission'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.user_group_permission') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'user_group_permission'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''user_job_title'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.user_job_title') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'user_job_title'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''user_login_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.user_login_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'user_login_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''user_resources'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.user_resources') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'user_resources'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''user_user_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.user_user_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'user_user_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''uur_tool_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.uur_tool_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'uur_tool_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''valid_quote_duration'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.valid_quote_duration') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'valid_quote_duration'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''var_component'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.var_component') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'var_component'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''var_ext_position'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.var_ext_position') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'var_ext_position'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''var_limit'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.var_limit') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'var_limit'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''var_output'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.var_output') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'var_output'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''var_pnl_distribution'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.var_pnl_distribution') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'var_pnl_distribution'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''var_run'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.var_run') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'var_run'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''var_run_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.var_run_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'var_run_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''varfeed_beta'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.varfeed_beta') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'varfeed_beta'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''vat_declaration'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.vat_declaration') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'vat_declaration'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''vat_trans_nature'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.vat_trans_nature') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'vat_trans_nature'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''vat_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.vat_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'vat_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''venue'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.venue') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'venue'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''vessel_dist'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.vessel_dist') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'vessel_dist'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''vessel_dist_mtm'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.vessel_dist_mtm') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'vessel_dist_mtm'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voucher'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voucher') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voucher'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voucher_alias'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voucher_alias') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voucher_alias'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voucher_approval'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voucher_approval') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voucher_approval'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voucher_category'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voucher_category') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voucher_category'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voucher_cost'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voucher_cost') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voucher_cost'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voucher_duedate'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voucher_duedate') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voucher_duedate'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voucher_ext_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voucher_ext_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voucher_ext_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voucher_pay_approval'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voucher_pay_approval') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voucher_pay_approval'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voucher_payment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voucher_payment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voucher_payment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voucher_relation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voucher_relation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voucher_relation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voucher_type'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voucher_type') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voucher_type'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voucher_vat'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voucher_vat') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voucher_vat'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''voyage'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.voyage') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'voyage'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the table ''wakeup'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.wakeup') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'TABLE',
              @level1name = N'wakeup'
go
 
