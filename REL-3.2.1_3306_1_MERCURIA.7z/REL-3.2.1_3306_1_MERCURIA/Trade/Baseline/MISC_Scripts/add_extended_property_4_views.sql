set nocount on
go
print '=> Adding extended property ''SymphonyProduct'' for the view ''account_and_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_and_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'account_and_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''account_for_broker'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_for_broker') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'account_for_broker'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''account_for_tax_authority'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_for_tax_authority') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'account_for_tax_authority'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''account_with_tax_license'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.account_with_tax_license') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'account_with_tax_license'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''actual_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.actual_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'actual_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''alloc_item_transport_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.alloc_item_transport_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'alloc_item_transport_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''allocation_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.allocation_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'allocation_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''commodity_and_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commodity_and_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'commodity_and_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''commoditys_attached'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.commoditys_attached') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'commoditys_attached'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''concluded_physical_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.concluded_physical_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'concluded_physical_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''cost_bol_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_bol_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'cost_bol_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''cost_book_comp_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_book_comp_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'cost_book_comp_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''cost_code_search_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_code_search_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'cost_code_search_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''cost_counterparty_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_counterparty_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'cost_counterparty_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''cost_cur_code_search_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_cur_code_search_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'cost_cur_code_search_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''cost_owner_search_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_owner_search_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'cost_owner_search_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''cost_pay_rec_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_pay_rec_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'cost_pay_rec_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''cost_price_est_actual_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_price_est_actual_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'cost_price_est_actual_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''cost_qty_est_actual_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_qty_est_actual_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'cost_qty_est_actual_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''cost_search_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_search_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'cost_search_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''cost_transporter_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_transporter_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'cost_transporter_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''cost_type_search_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.cost_type_search_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'cost_type_search_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''currency_commodity'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.currency_commodity') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'currency_commodity'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''jms_classification'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.jms_classification') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'jms_classification'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''jms_department'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.jms_department') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'jms_department'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''jms_desk'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.jms_desk') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'jms_desk'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''jms_division'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.jms_division') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'jms_division'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''jms_groups'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.jms_groups') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'jms_groups'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''jms_legal_entity'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.jms_legal_entity') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'jms_legal_entity'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''jms_location'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.jms_location') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'jms_location'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''jms_profit_center'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.jms_profit_center') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'jms_profit_center'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''jms_reports'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.jms_reports') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'jms_reports'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''jms_strategy'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.jms_strategy') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'jms_strategy'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''jms_trader'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.jms_trader') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'jms_trader'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''lc_headline_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.lc_headline_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'lc_headline_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''location_name_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.location_name_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'location_name_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''markets_attached'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.markets_attached') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'markets_attached'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''non_exch_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.non_exch_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'non_exch_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''nonscheduler_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.nonscheduler_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'nonscheduler_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''portfolio_tag'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_tag') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'portfolio_tag'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''portfolio_tag_definition'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_tag_definition') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'portfolio_tag_definition'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''portfolio_tag_insp_attr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_tag_insp_attr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'portfolio_tag_insp_attr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''portfolio_tag_option'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.portfolio_tag_option') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'portfolio_tag_option'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''posted_price_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.posted_price_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'posted_price_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''scheduler_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.scheduler_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'scheduler_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''tax_authority'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tax_authority') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'tax_authority'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''tax_code_commodity'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tax_code_commodity') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'tax_code_commodity'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''tax_license_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.tax_license_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'tax_license_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''temp_value_adjust_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.temp_value_adjust_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'temp_value_adjust_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''trade_book_comp_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_book_comp_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'trade_book_comp_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''trade_headline_comment'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_headline_comment') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'trade_headline_comment'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''trade_port_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trade_port_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'trade_port_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''trades_for_brent'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trades_for_brent') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'trades_for_brent'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''trades_for_sch'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.trades_for_sch') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'trades_for_sch'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''user_permission'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.user_permission') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'user_permission'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_account_contact_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_account_contact_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_account_contact_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_account_group_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_account_group_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_account_group_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_account_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_account_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_account_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_acct_bookcomp_crinfo_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_acct_bookcomp_crinfo_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_acct_bookcomp_crinfo_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_accum_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_accum_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_accum_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_accum_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_accum_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_accum_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_accumulation_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_accumulation_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_accumulation_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ai_est_actual_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ai_est_actual_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ai_est_actual_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ai_est_actual_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ai_est_actual_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ai_est_actual_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ai_est_actual_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ai_est_actual_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ai_est_actual_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ai_est_actual_spec_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ai_est_actual_spec_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ai_est_actual_spec_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ai_transport_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ai_transport_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ai_transport_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ai_transport_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ai_transport_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ai_transport_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_alloc_item_transport_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_alloc_item_transport_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_alloc_item_transport_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_allocation_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_allocation_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_allocation_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_allocation_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_allocation_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_allocation_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_allocation_item_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_allocation_item_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_allocation_item_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_allocation_item_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_allocation_item_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_allocation_item_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_allocation_item_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_allocation_item_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_allocation_item_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_allocation_item_vat_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_allocation_item_vat_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_allocation_item_vat_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_allocation_reach_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_allocation_reach_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_allocation_reach_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_allocation_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_allocation_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_allocation_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_allocation_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_allocation_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_allocation_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_assign_trade_lc'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_assign_trade_lc') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_assign_trade_lc'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_assign_trade_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_assign_trade_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_assign_trade_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_aud_accum_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_aud_accum_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_aud_accum_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_aud_ai_est_actual_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_aud_ai_est_actual_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_aud_ai_est_actual_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_aud_ai_transport_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_aud_ai_transport_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_aud_ai_transport_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_aud_allocation_item_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_aud_allocation_item_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_aud_allocation_item_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_aud_allocation_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_aud_allocation_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_aud_allocation_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_aud_cost_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_aud_cost_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_aud_cost_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_aud_invbd_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_aud_invbd_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_aud_invbd_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_aud_inventory_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_aud_inventory_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_aud_inventory_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_aud_position_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_aud_position_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_aud_position_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_aud_qpp_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_aud_qpp_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_aud_qpp_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_aud_ti_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_aud_ti_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_aud_ti_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_aud_tid_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_aud_tid_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_aud_tid_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_avg_buy_sell_price_term_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_avg_buy_sell_price_term_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_avg_buy_sell_price_term_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_BI_cmdty_mkt_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_BI_cmdty_mkt_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_BI_cmdty_mkt_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_BI_cob_date'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_BI_cob_date') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_BI_cob_date'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_BI_commkt_formula'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_BI_commkt_formula') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_BI_commkt_formula'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_BI_portfolio'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_BI_portfolio') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_BI_portfolio'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_BI_position'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_BI_position') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_BI_position'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_BI_profit_loss'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_BI_profit_loss') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_BI_profit_loss'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_BI_trade_search'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_BI_trade_search') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_BI_trade_search'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_calendar_detail_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_calendar_detail_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_calendar_detail_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_cash_settle_date_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_cash_settle_date_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_cash_settle_date_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_CHGHISTORY_aud_cost_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_CHGHISTORY_aud_cost_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_CHGHISTORY_aud_cost_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_CHGHISTORY_aud_trade_item_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_CHGHISTORY_aud_trade_item_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_CHGHISTORY_aud_trade_item_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_CHGHISTORY_cost_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_CHGHISTORY_cost_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_CHGHISTORY_cost_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_CHGHISTORY_portfolio_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_CHGHISTORY_portfolio_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_CHGHISTORY_portfolio_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_CHGHISTORY_profit_center_tags'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_CHGHISTORY_profit_center_tags') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_CHGHISTORY_profit_center_tags'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_CHGHISTORY_trade_item_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_CHGHISTORY_trade_item_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_CHGHISTORY_trade_item_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_CHGHISTORY_uic_deletes'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_CHGHISTORY_uic_deletes') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_CHGHISTORY_uic_deletes'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_CHGHISTORY_uic_updates'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_CHGHISTORY_uic_updates') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_CHGHISTORY_uic_updates'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_cmdty_mkt_source_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_cmdty_mkt_source_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_cmdty_mkt_source_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_collateral'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_collateral') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_collateral'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_commodity_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_commodity_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_commodity_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_cost_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_cost_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_cost_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_cost_equalization_rate_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_cost_equalization_rate_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_cost_equalization_rate_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_cost_ext_info_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_cost_ext_info_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_cost_ext_info_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_cost_interface_info_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_cost_interface_info_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_cost_interface_info_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_cost_rate_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_cost_rate_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_cost_rate_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_cost_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_cost_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_cost_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_cost_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_cost_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_cost_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_cost_search'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_cost_search') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_cost_search'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_credit_limit_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_credit_limit_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_credit_limit_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_credit_term_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_credit_term_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_credit_term_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_curve_source'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_curve_source') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_curve_source'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_custom_voucher_range_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_custom_voucher_range_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_custom_voucher_range_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_edpl_event_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_edpl_event_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_edpl_event_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_eipp_task_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_eipp_task_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_eipp_task_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_entity_tag_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_entity_tag_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_entity_tag_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_event_price_term_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_event_price_term_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_event_price_term_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_event_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_event_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_event_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_exposure_detail_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_exposure_detail_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_exposure_detail_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_external_trade_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_external_trade_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_external_trade_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_fb_modular_info_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_fb_modular_info_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_fb_modular_info_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_forecast_value_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_forecast_value_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_forecast_value_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_formula_body_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_formula_body_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_formula_body_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_formula_body_trigger_actual_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_formula_body_trigger_actual_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_formula_body_trigger_actual_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_formula_body_trigger_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_formula_body_trigger_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_formula_body_trigger_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_formula_component_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_formula_component_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_formula_component_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_formula_condition_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_formula_condition_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_formula_condition_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_formula_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_formula_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_formula_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_fx_cost_draw_down_hist_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_fx_cost_draw_down_hist_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_fx_cost_draw_down_hist_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_fx_exposure_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_fx_exposure_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_fx_exposure_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_fx_exposure_currency_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_fx_exposure_currency_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_fx_exposure_currency_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_fx_exposure_dist_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_fx_exposure_dist_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_fx_exposure_dist_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_fx_exposure_dist_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_fx_exposure_dist_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_fx_exposure_dist_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_fx_exposure_pl_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_fx_exposure_pl_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_fx_exposure_pl_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_fx_exposure_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_fx_exposure_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_fx_exposure_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_fx_hedge_rate_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_fx_hedge_rate_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_fx_hedge_rate_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_fx_linked_costs_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_fx_linked_costs_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_fx_linked_costs_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_fx_linking_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_fx_linking_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_fx_linking_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_fx_rate_history_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_fx_rate_history_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_fx_rate_history_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_get_ags_trade_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_get_ags_trade_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_get_ags_trade_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_get_conc_trade_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_get_conc_trade_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_get_conc_trade_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_icts_message_detail_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_icts_message_detail_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_icts_message_detail_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_icts_message_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_icts_message_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_icts_message_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_icts_user_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_icts_user_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_icts_user_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_internal_trade_phys'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_internal_trade_phys') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_internal_trade_phys'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_invbd_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_invbd_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_invbd_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_invbd_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_invbd_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_invbd_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_inventory_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_inventory_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_inventory_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_inventory_build_draw_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_inventory_build_draw_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_inventory_build_draw_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_inventory_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_inventory_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_inventory_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_inventory_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_inventory_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_inventory_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_job_schedule_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_job_schedule_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_job_schedule_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_lc_allocation_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_lc_allocation_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_lc_allocation_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_lc_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_lc_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_lc_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_location_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_location_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_location_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_market_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_market_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_market_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_mkt_price_quo_dates_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_mkt_price_quo_dates_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_mkt_price_quo_dates_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_mkt_pricing_cond_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_mkt_pricing_cond_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_mkt_pricing_cond_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_mot_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_mot_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_mot_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_option_strike_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_option_strike_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_option_strike_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_parcel_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_parcel_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_parcel_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_parcel_quality_slate_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_parcel_quality_slate_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_parcel_quality_slate_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_parcel_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_parcel_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_parcel_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_payment_term_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_payment_term_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_payment_term_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_pipeline_year_cycle'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_pipeline_year_cycle') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_pipeline_year_cycle'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_pl_history_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_pl_history_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_pl_history_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_PLCOMP_cost_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_PLCOMP_cost_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_PLCOMP_cost_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_PLCOMP_portfolio_pl_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_PLCOMP_portfolio_pl_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_PLCOMP_portfolio_pl_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_PLCOMP_position_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_PLCOMP_position_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_PLCOMP_position_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_PLCOMP_TI_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_PLCOMP_TI_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_PLCOMP_TI_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_PLCOMP_trade_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_PLCOMP_trade_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_PLCOMP_trade_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_PLCOMP_trade_item_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_PLCOMP_trade_item_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_PLCOMP_trade_item_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_portfolio_division_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_portfolio_division_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_portfolio_division_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_portfolio_edpl_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_portfolio_edpl_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_portfolio_edpl_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_portfolio_group_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_portfolio_group_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_portfolio_group_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_portfolio_pl'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_portfolio_pl') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_portfolio_pl'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_portfolio_profit_loss'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_portfolio_profit_loss') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_portfolio_profit_loss'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_portfolio_profit_loss_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_portfolio_profit_loss_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_portfolio_profit_loss_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_portfolio_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_portfolio_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_portfolio_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_POSGRID_base_corr'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_POSGRID_base_corr') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_POSGRID_base_corr'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_POSGRID_commkt_formula'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_POSGRID_commkt_formula') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_POSGRID_commkt_formula'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_POSGRID_commkt_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_POSGRID_commkt_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_POSGRID_commkt_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_POSGRID_inv_position_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_POSGRID_inv_position_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_POSGRID_inv_position_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_POSGRID_pl_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_POSGRID_pl_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_POSGRID_pl_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_POSGRID_pl_history'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_POSGRID_pl_history') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_POSGRID_pl_history'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_POSGRID_position_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_POSGRID_position_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_POSGRID_position_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_POSGRID_price_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_POSGRID_price_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_POSGRID_price_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_POSGRID_risk_position'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_POSGRID_risk_position') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_POSGRID_risk_position'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_POSGRID_simple_formula_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_POSGRID_simple_formula_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_POSGRID_simple_formula_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_POSGRID_trade_item_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_POSGRID_trade_item_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_POSGRID_trade_item_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_position_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_position_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_position_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_position_mark_to_market_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_position_mark_to_market_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_position_mark_to_market_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_position_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_position_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_position_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_position_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_position_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_position_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_price_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_price_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_price_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_price_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_price_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_price_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_qpp_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_qpp_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_qpp_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_qpp_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_qpp_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_qpp_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_quote_pricing_period_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_quote_pricing_period_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_quote_pricing_period_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_rc_assign_trade_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_rc_assign_trade_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_rc_assign_trade_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_reprice_event_detail_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_reprice_event_detail_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_reprice_event_detail_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_risk_commodity_group'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_risk_commodity_group') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_risk_commodity_group'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_risk_cover_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_risk_cover_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_risk_cover_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_SAP_cashforcast_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_SAP_cashforcast_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_SAP_cashforcast_view'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_SAP_voucher_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_SAP_voucher_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_SAP_voucher_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_shipment_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_shipment_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_shipment_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_shipment_mot_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_shipment_mot_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_shipment_mot_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_shipment_path_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_shipment_path_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_shipment_path_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_shipment_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_shipment_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_shipment_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ti_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ti_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ti_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ti_dry_phy_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ti_dry_phy_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ti_dry_phy_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ti_exch_opt_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ti_exch_opt_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ti_exch_opt_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ti_mtm_pl_asof_date'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ti_mtm_pl_asof_date') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ti_mtm_pl_asof_date'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ti_otc_opt_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ti_otc_opt_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ti_otc_opt_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ti_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ti_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ti_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_ti_wet_phy_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_ti_wet_phy_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_ti_wet_phy_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_tid_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_tid_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_tid_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_tid_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_tid_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_tid_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_detail'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_detail') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_detail'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_formula_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_formula_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_formula_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_bunker_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_bunker_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_bunker_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_cash_phy_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_cash_phy_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_cash_phy_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_curr_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_curr_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_curr_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_dist_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_dist_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_dist_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_dry_phy_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_dry_phy_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_dry_phy_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_edpl_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_edpl_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_edpl_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_exch_opt_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_exch_opt_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_exch_opt_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_ext_info_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_ext_info_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_ext_info_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_fill_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_fill_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_fill_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_fut_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_fut_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_fut_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_otc_opt_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_otc_opt_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_otc_opt_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_rin_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_rin_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_rin_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_spec_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_spec_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_spec_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_storage_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_storage_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_storage_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_transport_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_transport_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_transport_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_item_wet_phy_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_item_wet_phy_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_item_wet_phy_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_order_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_order_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_order_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_order_bunker_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_order_bunker_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_order_bunker_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_order_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_order_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_order_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trade_term_info_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trade_term_info_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trade_term_info_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_trading_period_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_trading_period_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_trading_period_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_accumulation_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_accumulation_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_accumulation_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_assign_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_assign_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_assign_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_assign_trade1'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_assign_trade1') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_assign_trade1'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_commkt_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_commkt_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_commkt_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_fix_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_fix_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_fix_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_float_price'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_float_price') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_float_price'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_lc_allocation'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_lc_allocation') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_lc_allocation'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_portfolio_booking_company'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_portfolio_booking_company') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_portfolio_booking_company'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_Q_formula_body'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_Q_formula_body') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_Q_formula_body'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_rc_assign_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_rc_assign_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_rc_assign_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_risk_cover'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_risk_cover') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_risk_cover'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_roll_indicator'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_roll_indicator') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_roll_indicator'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_swap_trade_formulas'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_swap_trade_formulas') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_swap_trade_formulas'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_swapflt_trade_formulas'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_swapflt_trade_formulas') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_swapflt_trade_formulas'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_trade'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_trade') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_trade'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_trade_cost_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_trade_cost_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_trade_cost_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_trade_item'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_trade_item') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_trade_item'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_trade_item_dist'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_trade_item_dist') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_trade_item_dist'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_trade_item_dry_phy'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_trade_item_dry_phy') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_trade_item_dry_phy'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_trade_item_exch_opt'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_trade_item_exch_opt') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_trade_item_exch_opt'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_trade_item_fut'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_trade_item_fut') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_trade_item_fut'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_TS_trade_item_wet_phy'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_TS_trade_item_wet_phy') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_TS_trade_item_wet_phy'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_uic_report'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_uic_report') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_uic_report'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_uom_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_uom_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_uom_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_user_trading_entity_map'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_user_trading_entity_map') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_user_trading_entity_map'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_booking_company_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_booking_company_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_booking_company_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_commkt_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_commkt_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_commkt_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_distribution'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_distribution') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_distribution'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_exchange_options'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_exchange_options') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_exchange_options'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_exchange_options_v24'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_exchange_options_v24') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_exchange_options_v24'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_financial_position'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_financial_position') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_financial_position'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_future_trades'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_future_trades') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_future_trades'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_future_trades_v24'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_future_trades_v24') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_future_trades_v24'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_inventory_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_inventory_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_inventory_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_physical_float_trades'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_physical_float_trades') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_physical_float_trades'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_physical_trades'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_physical_trades') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_physical_trades'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_position_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_position_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_position_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_swap_trades'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_swap_trades') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_swap_trades'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_swap_trades_v24'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_swap_trades_v24') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_swap_trades_v24'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_VAR_trade_item_info'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_VAR_trade_item_info') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_VAR_trade_item_info'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_vessel_dist_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_vessel_dist_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_vessel_dist_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_voucher_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_voucher_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_voucher_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_voucher_cost_all_rs'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_voucher_cost_all_rs') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_voucher_cost_all_rs'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_voucher_cost_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_voucher_cost_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_voucher_cost_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_voucher_payment_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_voucher_payment_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_voucher_payment_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''v_voucher_rev'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.v_voucher_rev') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'v_voucher_rev'
go
 
print '=> Adding extended property ''SymphonyProduct'' for the view ''WPTI_cost_view'' ...'
go
IF NOT EXISTS (SELECT 1
               FROM sys.extended_properties
               WHERE [major_id] = OBJECT_ID('dbo.WPTI_cost_view') AND
                     [name] = N'SymphonyProduct' AND
                     [value] = N'OIL')
   exec sys.sp_addextendedproperty
              @name = N'SymphonyProduct',
              @value = N'OIL',
              @level0type = N'SCHEMA',
              @level0name = N'dbo',
              @level1type = N'VIEW',
              @level1name = N'WPTI_cost_view'
go
 
