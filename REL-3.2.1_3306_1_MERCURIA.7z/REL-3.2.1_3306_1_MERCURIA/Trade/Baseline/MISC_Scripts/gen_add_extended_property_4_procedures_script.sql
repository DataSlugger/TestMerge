set nocount on

create table #procedures
(
   procedure_name         sysname primary key
)
go

insert into #procedures
  select name
  from sys.procedures
  where schema_id = SCHEMA_ID('dbo')
go

RAISERROR('set nocount on', 0, 1) WITH NOWAIT
RAISERROR('go', 0, 1) WITH NOWAIT

declare @procedure_name    sysname

select @procedure_name = min(procedure_name)
from #procedures

while @procedure_name is not null
begin
   RAISERROR('print ''=> Adding extended property ''''SymphonyProduct'''' for the procedure ''''%s'''' ...''', 0, 1, @procedure_name) WITH NOWAIT
   RAISERROR('go', 0, 1) WITH NOWAIT
   RAISERROR('IF NOT EXISTS (SELECT 1', 0, 1) WITH NOWAIT 
   RAISERROR('               FROM sys.extended_properties', 0, 1) WITH NOWAIT 
   RAISERROR('               WHERE [major_id] = OBJECT_ID(''dbo.%s'') AND', 0, 1, @procedure_name) WITH NOWAIT
   RAISERROR('                     [name] = N''SymphonyProduct'' AND',  0, 1) WITH NOWAIT
   RAISERROR('                     [value] = N''OIL'')',  0, 1) WITH NOWAIT
   RAISERROR('   exec sys.sp_addextendedproperty',  0, 1) WITH NOWAIT
   RAISERROR('              @name = N''SymphonyProduct'',', 0, 1) WITH NOWAIT
   RAISERROR('              @value = N''OIL'',', 0, 1) WITH NOWAIT
   RAISERROR('              @level0type = N''SCHEMA'',', 0, 1) WITH NOWAIT
   RAISERROR('              @level0name = N''dbo'',', 0, 1) WITH NOWAIT
   RAISERROR('              @level1type = N''PROCEDURE'',', 0, 1) WITH NOWAIT
   RAISERROR('              @level1name = N''%s''', 0, 1, @procedure_name) WITH NOWAIT
   RAISERROR('go', 0, 1) WITH NOWAIT
   RAISERROR(' ', 0, 1) WITH NOWAIT
   
   select @procedure_name = min(procedure_name)
   from #procedures
   where procedure_name > @procedure_name
end
go   