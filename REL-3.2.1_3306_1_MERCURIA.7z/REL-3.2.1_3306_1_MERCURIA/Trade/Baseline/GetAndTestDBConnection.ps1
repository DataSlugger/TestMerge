# GetAndTestDBConnection.ps1
#    This script is used to collect user's inputs for
#        SQL Server instance name or its alias name
#        administrative login
#        password
#        database name
#
#      and build and test db connection string to see if you can successfully connect
#      to the selected database.
#
#      Dependency:
#        It uses the functions stored in
#           PS_gui_funcs.ps1 and
#           DBUpgradeSupportToolSet module
#
#     Created By         : Peter Lo   01/12/2016
#     Last Edited By     : Peter Lo   04/13/2016
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
# *****************************************************************************************

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 

GetDBConnInfo_GUI
#write-host "DEBUG: Server is '$Server'" 
if ($Server -eq "@@@") {break}
GetDesiredDatabase_GUI $Server $Authentication $Login $Password
if ($Database -eq "@@@" ) {break}

# *************************************************************
#  At this point, we have the db login information and the
#  database we want to use to hold ICTS TRADE schema. So, 
#  next thing we need to do is to verify
#   1. if database is in RESTRICTED_USER mode
#   2. if database uses SIMPLE recovery model
#   3. if login has administrative prvilege
#         login must be a member of sysadmin role
#         OR
#         login must be a member of securityadmin role and
#            member of db_owner role of the selected database
# *************************************************************

# We want to make sure if we can open a db connection
if ($Authentication -eq "Windows Authentication")
{
   $ConnStr="Server=$Server;Database=$Database;Integrated Security=True"
}
else
{
   $ConnStr="Server=$Server;Database=$Database;User=$Login;Password=$Password;Integrated Security=False"
}
$conn = New-Object System.Data.SqlClient.SqlConnection
$conn.ConnectionString = $ConnStr
try
{
  $conn.Open()
}
catch
{
    $ErrorMessage = $_.Exception.Message
    write-host "Unable to open a db connection due to the error: $ErrorMessage"
    return
}
$conn.Close()
Write-Host "Database Connection is OK"

# YES, we can open a db connection successfully
$UserAccessMode = GetDBAccessMode -ConnString $ConnStr -Database $Database
if ($UserAccessMode) {write-host "The current user access mode of the '$Database' database is $UserAccessMode"}
else
{
   write-host "Unable to find the current user access mode for the '$Database' database!"
   $conn.Close()
   return
}

$DBRecoveryModel = GetDBRecoveryModel -ConnString $ConnStr -Database $Database
if ($DBRecoveryModel) {write-host "The current recovery mode of the '$Database' database is $DBRecoveryModel"}
else
{
   write-host "Unable to find the current recovery mode for the '$Database' database!"
   $conn.Close()
   return
}

[boolean]$DBInMirroringState = DBInMirroringState -ConnString $ConnStr -Database $Database
if ($DBInMirroringState) {write-host "The '$Database' database is a mirrored database"}
else {write-host "The '$Database' database is NOT a mirrored database!"}

# We need to set DB Recovery model to SIMPLE. However, we can not change the FULL db 
# receovery mode if database is involved with mirroring 

if (!($DBInMirroringState))
{
   if ($DBRecoveryModel -ne "SIMPLE")
   {
      AlterDBRecoveryModel -ConnString $ConnStr -Database $Database -NewRecoveryModel "SIMPLE"
   }
}

[boolean]$PermissionOK = HasAdminPermission -ConnString $ConnStr -Database $Database
if ($PermissionOK)
{
   write-host "The '$Login' has the required administrative permissions"
}
else
{
   write-host "The '$Login' does not have the required administrative permissions"
   $conn.Close()
   return
}
