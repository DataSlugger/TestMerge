# POST_PASS_SCHEMA_UPGRADE_PS.ps1
#
#     Created By         : Peter Lo   04/27/2016
#     Last Edited By     : Peter Lo   04/27/2016
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
#     Company            : Amphora, Inc
# ==============================================================
Param (
  [Parameter(Mandatory=$true,HelpMessage="You must provide a server instance name")]
     [string]$S,
  [string]$U,
  [string]$P,
  [Parameter(Mandatory=$true,HelpMessage="You must provide the name of a pass database")]
     [string]$D
)

# get PS version
$ver = $PsVersionTable.psversion.major
# Check to see if it's V3
If ($ver -lt 3) 
{ 
   write-host "You need PS version v3.0 or later in order to run this script - exiting" 
   return
}

#if ($ver -eq 2)
#{
#   $scriptPath = split-path -parent $MyInvocation.MyCommand.Definition
#}
#else
#{
#   $ScriptRootPath = $PSScriptRoot
#}

$ScriptRootPath = $pwd.Path
[bool]$DebugOn=$false

$Server=$S
$Login=$U
$Password=$P
$Database=$D

if ($DebugOn)
{
   Write-Host "DEBUG: Server is '$Server'"
   Write-Host "DEBUG: Login is '$Login'"
   Write-Host "DEBUG: Password is '$Password'"
   Write-Host "DEBUG: Database is '$Database'"
   Write-Host " "
}

if ($Database -eq "master" -or $Database -eq "msdb" -or $Database -eq "tempdb" -or $Database -eq "model")
{ 
   write-host "You must provide the name of an ICTS pass database for the argument '-D'" 
   exit
}

Import-Module CommonDBUpgradeSupportToolSet
Import-Module PassDBUpgradeSupportToolSet

if ($Login.Length -eq 0 -and $Password.Length -gt 0)
{
   Write-Host "You need to provide a DB login if password was given" 
   exit
}

if ($Login.Length -gt 0 -and $Password.Length -eq 0)
{
   Write-Host "You need to provide a password if DB login was given" 
   exit
}

if ($Login.Length -eq 0 -and $Password.Length -eq 0)
{
   $Authentication = "Windows Authentication"
   if (!(TestDBConnection -S $Server -AUTH $Authentication -D $Database)) {exit}
   $ConnStr="Server=$Server;Database=$Database;Integrated Security=True"
}
else
{
   $Authentication = "SQL Server Authentication"
   if (!(TestDBConnection -S $Server -AUTH $Authentication -U $Login -P $Password -D $Database)) {exit}
   $ConnStr="Server=$Server;Database=$Database;Integrated Security=True"
}

# Yes, at this point, DB connection to database is OK
$UserAccessMode = GetDBAccessMode -ConnString $ConnStr -Database $Database
if ($UserAccessMode) {Write-Host "The current user access mode of the '$Database' database is $UserAccessMode"}
else
{
   Write-Host "Unable to find the current user access mode for the '$Database' database!"
   exit
}

$DBRecoveryModel = GetDBRecoveryModel -ConnString $ConnStr -Database $Database
if ($DBRecoveryModel) {write-host "The current recovery mode of the '$Database' database is $DBRecoveryModel"}
else
{
   Write-Host "Unable to find the current recovery mode for the '$Database' database!"
   exit
}

[boolean]$DBInMirroringState = DBInMirroringState -ConnString $ConnStr -Database $Database
if ($DBInMirroringState) {Write-Host "The '$Database' database is a mirrored database"}
else {Write-Host "The '$Database' database is NOT a mirrored database!"}

# We need to set DB Recovery model to SIMPLE. However, we can not change the FULL db 
# receovery mode if database is involved with mirroring 
if (!($DBInMirroringState))
{
   if ($DBRecoveryModel -ne "SIMPLE")
   {
      AlterDBRecoveryModel -ConnString $ConnStr -Database $Database -NewRecoveryModel "SIMPLE"
   }
}

[boolean]$PermissionOK = HasAdminPermission -ConnString $ConnStr -Database $Database
if ($PermissionOK)
{
   Write-Host "The '$Login' has the required administrative permissions"
}
else
{
   Write-Host "The '$Login' does not have the required administrative permissions"
   exit
}

. ./UpdateSchema.ps1 $Server $Authentication $Login $Password $Database

# Remind DBA to backup the database which has newly updated ICTS pass schema and then set database to be MULTI_USER mode
# set database back to its original recovery model
# cleanup temp files

# We need to reset DB Recovery model back to its original model. 
if (!($DBInMirroringState))
{
   if ($DBRecoveryModel -ne "SIMPLE") {AlterDBRecoveryModel -ConnString $ConnStr -Database $Database -NewRecoveryModel $DBRecoveryModel}
}

# Scan logs in the Logs subfolder
# *************************************************************************
# Scanning logs in the Logs subfolder
if (ErrorsExistedInLogs $ScriptRootPath) 
{
   Write-Host " "
   Write-Host -ForegroundColor DarkRed "The ICTS pass schema was failed to be updated in the '$Database' database!" 
   Write-Host -ForegroundColor DarkRed "You may examine the log files listed above and investigate what caused errors." 
   Write-Host -ForegroundColor DarkRed "After you have fixed the errors, you can try to upgrade schema again" 
}
else
{
   Write-Host " "
   Write-Host -ForegroundColor DarkBlue "The ICTS pass schema was updated successfully in the '$Database' database!"
   Write-Host -ForegroundColor DarkBlue "Before you allow users to access this database, if this database is a production"
   Write-Host -ForegroundColor DarkBlue "database, it is recommended that you make a database backup immediately. "
   Write-Host -ForegroundColor DarkBlue "After that, you execute the 'ALTER DATABASE .. SET MULTI_USER' statement "
   Write-Host -ForegroundColor DarkBlue "so that your users can access the database"
}
Write-Host " "
Write-Host "This was done by using PowerShell version $ver"
Write-Host " "
