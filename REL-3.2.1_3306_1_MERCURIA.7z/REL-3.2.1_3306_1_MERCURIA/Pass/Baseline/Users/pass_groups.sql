if exists (select 1
           from sys.sysusers 
		       where name = 'pass_admin_group' and
		             gid > 0 and
				 issqlrole = 1)
BEGIN
    drop role pass_admin_group;
    if exists (select 1
               from sys.sysusers 
		           where name = 'pass_admin_group' and
		                 gid > 0 and
				             issqlrole = 1)
       print '<<< FAILED DROPPING ROLE pass_admin_group >>>'
    else
       print '<<< DROPPED ROLE pass_admin_group >>>'
END
go

create role pass_admin_group
go


if exists (select 1
           from sys.sysusers 
		   where name = 'pass_user_group' and
		         gid > 0 and
				     issqlrole = 1)
BEGIN
    drop role pass_user_group;
    if exists (select 1
               from sys.sysusers 
		           where name = 'pass_user_group' and
		                 gid > 0 and
				             issqlrole = 1)
       print '<<< FAILED DROPPING ROLE pass_user_group >>>'
    else
       print '<<< DROPPED ROLE pass_user_group >>>'
END
go

create role pass_user_group
go
