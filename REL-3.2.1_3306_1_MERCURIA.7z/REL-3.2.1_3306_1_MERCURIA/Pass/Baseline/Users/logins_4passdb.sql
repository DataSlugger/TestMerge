-- FOR PASS DB
use master
go

if NOT exists (select * from dbo.syslogins where name = 'ictsviewer')
   create login ictsviewer with PASSWORD = 'ictsviewer',  
                                DEFAULT_DATABASE = master, 
                                CHECK_EXPIRATION = OFF, 
                                CHECK_POLICY = OFF
go
