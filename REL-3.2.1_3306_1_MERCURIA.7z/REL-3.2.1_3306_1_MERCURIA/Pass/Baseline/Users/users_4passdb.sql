-- FOR PASS DB

/* ********************************************************* */
IF USER_ID('ictspass') IS NOT NULL
BEGIN
   drop user ictspass;
   IF USER_ID('ictspass') IS NOT NULL
      PRINT '<<< FAILED DROPPING USER ictspass >>>'
   ELSE
      PRINT '<<< DROPPED USER ictspass >>>'
END
go

IF SUSER_SID('ictspass') IS NOT NULL
BEGIN
   IF USER_ID('ictspass') IS NULL
   BEGIN
      create user ictspass for login ictspass;
      exec dbo.sp_addrolemember pass_admin_group, ictspass;
      IF USER_ID('ictspass') IS NOT NULL
         PRINT '<<< CREATED USER ictspass >>>'
      ELSE
         PRINT '<<< FAILED CREATING USER ictspass >>>'
   END
END
go

/* ********************************************************* */
IF USER_ID('ictsviewer') IS NOT NULL
BEGIN
   drop user ictsviewer;
   IF USER_ID('ictsviewer') IS NOT NULL
      PRINT '<<< FAILED DROPPING USER ictsviewer >>>'
   ELSE
      PRINT '<<< DROPPED USER ictsviewer >>>'
END
go

IF SUSER_SID('ictsviewer') IS NOT NULL
BEGIN
   IF USER_ID('ictsviewer') IS NULL
   BEGIN
      create user ictsviewer for login ictsviewer;
      exec dbo.sp_addrolemember pass_user_group, ictsviewer; 
      IF USER_ID('ictsviewer') IS NOT NULL
         PRINT '<<< CREATED USER ictsviewer >>>'
      ELSE
         PRINT '<<< FAILED CREATING USER ictsviewer >>>'
   END
END
go



