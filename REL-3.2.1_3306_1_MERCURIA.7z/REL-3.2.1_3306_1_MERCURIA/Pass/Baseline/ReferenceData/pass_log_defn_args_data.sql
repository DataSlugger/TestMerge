set nocount on

print ' '
print 'Loading reference data into the pass_log_defn_args table ..'
go

/* *** */
insert pass_log_defn_args values (1, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (1, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (2, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (2, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (3, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (4, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (4, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (4, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (4, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (4, 5, 'I', '%d', 'N')
go
insert pass_log_defn_args values (4, 6, 'I', '%d', 'N')
go
insert pass_log_defn_args values (4, 7, 'I', '%d', 'N')
go
insert pass_log_defn_args values (4, 8, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (5, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (5, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (5, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (5, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (5, 5, 'I', '%d', 'N')
go
insert pass_log_defn_args values (5, 6, 'I', '%d', 'N')
go
insert pass_log_defn_args values (5, 7, 'I', '%d', 'N')
go
insert pass_log_defn_args values (5, 8, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (6, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (6, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (6, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (6, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (6, 5, 'I', '%d', 'N')
go
insert pass_log_defn_args values (6, 6, 'I', '%d', 'N')
go
insert pass_log_defn_args values (6, 7, 'I', '%d', 'N')
go
insert pass_log_defn_args values (6, 8, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (7, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (7, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (7, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (7, 4, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (7, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (7, 6, 'S', '%s', 'N')
go
insert pass_log_defn_args values (7, 7, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (7, 8, 'D', '%.3f', 'N')
go

/* *** */
insert pass_log_defn_args values (8, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (8, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (8, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (8, 4, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (8, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (8, 6, 'S', '%s', 'N')
go
insert pass_log_defn_args values (8, 7, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (8, 8, 'D', '%.3f', 'N')
go

/* *** */
insert pass_log_defn_args values (9, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (9, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (9, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (9, 4, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (9, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (9, 6, 'S', '%s', 'N')
go
insert pass_log_defn_args values (9, 7, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (9, 8, 'D', '%.3f', 'N')
go

/* *** */
insert pass_log_defn_args values (10, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (10, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (10, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (10, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (10, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (10, 6, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (11, 1, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (11, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (11, 3, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (11, 4, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (11, 5, 'D', '%.3f', 'N')
go

/* *** */
insert pass_log_defn_args values (12, 1, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (12, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (12, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (13, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (14, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (14, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (15, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (15, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (15, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (15, 4, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (15, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (15, 6, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (15, 7, 'S', '%s', 'N')
go
insert pass_log_defn_args values (15, 8, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (16, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (17, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (18, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (19, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (19, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (19, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (20, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (20, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (20, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (21, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (22, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (22, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (22, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (22, 4, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (22, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (22, 6, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (22, 7, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (23, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (23, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (24, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (24, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (24, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (24, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (24, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (25, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (26, 1, 'S', '%s', 'Y')
go

/* *** */
insert pass_log_defn_args values (28, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (28, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (28, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (28, 4, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (29, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (30, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (30, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (30, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (30, 4, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (31, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (31, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (31, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (31, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (31, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (31, 6, 'S', '%s', 'N')
go
insert pass_log_defn_args values (31, 7, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (31, 8, 'S', '%s', 'N')
go
insert pass_log_defn_args values (31, 9, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (32, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (32, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (33, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (34, 1, 'S', '%s', 'Y')
go

/* *** */
insert pass_log_defn_args values (35, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (35, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (35, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (36, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (36, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (36, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (37, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (37, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (37, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (37, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (38, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (38, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (39, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (39, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (39, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (39, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (40, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (41, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (41, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (41, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (42, 1, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (42, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (42, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (43, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (43, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (43, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (44, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (45, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (45, 2, 'S', '%s', 'N')   /* changed by issue #1361074 */
go

/* *** */
insert pass_log_defn_args values (46, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (46, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (46, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (46, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (46, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (47, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (48, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (48, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (48, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (49, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (50, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (51, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (51, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (51, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (52, 1, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (52, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (53, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (53, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (53, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (57, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (59, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (62, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (64, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (65, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (66, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (67, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (68, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (69, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (69, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (70, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (70, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (70, 3, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (71, 1, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (71, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (71, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (72, 1, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (72, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (72, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (73, 1, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (73, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (73, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (77, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (77, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (77, 3, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (78, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (78, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (78, 3, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (79, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (79, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (79, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (79, 4, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (80, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (80, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (80, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (80, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (80, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (80, 6, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (81, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (81, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (81, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (81, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (81, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (81, 6, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (84, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (84, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (85, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (85, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (86, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (87, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (88, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (89, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (89, 2, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (90, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (91, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (91, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (92, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (96, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (97, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (98, 1, 'S', '%s', 'Y')
go

/* *** */
insert pass_log_defn_args values (99, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (99, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (99, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (99, 4, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (99, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (99, 6, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (100, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (100, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (101, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (101, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (102, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (103, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (103, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (103, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (104, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (104, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (104, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (105, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (105, 2, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (107, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (108, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (109, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (109, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (109, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (109, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (110, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (110, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (110, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (111, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (111, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (112, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (112, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (112, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (113, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (113, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (113, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (114, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (114, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (114, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (116, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (116, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (116, 3, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (117, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (117, 2, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (121, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (121, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (121, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (121, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (122, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (123, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (123, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (124, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (124, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (124, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (125, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (126, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (126, 2, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (127, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (128, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (129, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (130, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (131, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (132, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (132, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (132, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (132, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (133, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (133, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (133, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (133, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (134, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (134, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (134, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (134, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (135, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (135, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (135, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (135, 4, 'I', '%d', 'N')
go
insert pass_log_defn_args values (135, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (135, 6, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (136, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (136, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (136, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (136, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (137, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (138, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (139, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (139, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (139, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (140, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (140, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (140, 3, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (141, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (142, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (143, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (144, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (144, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (144, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (147, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (147, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (147, 3, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (148, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (148, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (148, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (148, 4, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (148, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (148, 6, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (149, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (150, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (150, 2, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (150, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (150, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (151, 1, 'D', '%.3f', 'N')
go

/* *** */
insert pass_log_defn_args values (152, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (152, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (153, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (153, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (154, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (154, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (155, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (155, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (156, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (156, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (157, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (157, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (158, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (158, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (158, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (158, 4, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (158, 5, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (159, 1, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (159, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (159, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (159, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (159, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (161, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (162, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (163, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (164, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (165, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (166, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (167, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (168, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (169, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (170, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (171, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (172, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (173, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (174, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (175, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (176, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (176, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (176, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (176, 4, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (183, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (183, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (184, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (184, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (184, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (184, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (184, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (185, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (185, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (185, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (185, 4, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (186, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (187, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (187, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (187, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (187, 4, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (188, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (188, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (188, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (189, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (189, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (189, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (190, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (190, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (190, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (191, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (192, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (192, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (192, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (192, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (193, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (194, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (195, 1, 'I', '%d', 'Y')
go

/* *** */

/* *** */
insert pass_log_defn_args values (197, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (198, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (199, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (200, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (201, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (201, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (202, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (208, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (208, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (208, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (209, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (209, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (210, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (210, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (211, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (211, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (211, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (211, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (212, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (213, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (213, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (213, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (213, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (214, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (215, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (216, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (216, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (216, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (216, 4, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (216, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (216, 6, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (216, 7, 'S', '%s', 'N')
go
insert pass_log_defn_args values (216, 8, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (216, 9, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (216, 10, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (216, 11, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (216, 12, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (216, 13, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (216, 14, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (216, 15, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (216, 16, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (217, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (217, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (217, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (217, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (217, 5, 'I', '%d', 'N')
go
insert pass_log_defn_args values (217, 6, 'S', '%s', 'N')
go
insert pass_log_defn_args values (217, 7, 'S', '%s', 'N')
go
insert pass_log_defn_args values (217, 8, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (218, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (218, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (218, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (219, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (220, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (220, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (220, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (220, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (220, 5, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (221, 1, 'D', '%.3f', 'N')
go

/* *** */
insert pass_log_defn_args values (222, 1, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (222, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (222, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (222, 4, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (223, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (223, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (223, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (223, 4, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (223, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (223, 6, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (223, 7, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (224, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (224, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (224, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (224, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (224, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (224, 6, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (224, 7, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (224, 8, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (225, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (225, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (225, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (225, 4, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (226, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (226, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (226, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (226, 4, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (227, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (227, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (227, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (230, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (231, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (231, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (231, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (232, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (233, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (233, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (233, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (233, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (233, 5, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (233, 6, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (233, 7, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (234, 1, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (234, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (234, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (234, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (235, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (236, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (236, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (236, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (236, 4, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (237, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (238, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (238, 2, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (239, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (239, 2, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (240, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (240, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (240, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (240, 4, 'I', '%d', 'N')
go
insert pass_log_defn_args values (240, 5, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (241, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (242, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (243, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (251, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (252, 1, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (252, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (252, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (253, 1, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (253, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (253, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (254, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (254, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (255, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (255, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (255, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (255, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (255, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (257, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (262, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (263, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (264, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (265, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (267, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (270, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (271, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (275, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (276, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (277, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (279, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (279, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (279, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (279, 4, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (280, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (280, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (280, 3, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (280, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (280, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (281, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (281, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (281, 3, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (281, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (282, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (282, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (282, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (282, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (282, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (282, 6, 'S', '%s', 'N')
go
insert pass_log_defn_args values (282, 7, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (283, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (283, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (283, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (283, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (284, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (284, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (284, 3, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (285, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (285, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (285, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (285, 4, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (286, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (286, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (286, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (286, 4, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (287, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (287, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (288, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (289, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (290, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (291, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (292, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (292, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (292, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (293, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (294, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (295, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (295, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (296, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (296, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (297, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (298, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (298, 2, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (299, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (299, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (300, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (301, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (302, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (303, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (304, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (305, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (306, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (307, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (308, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (309, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (312, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (313, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (313, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (313, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (314, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (314, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (314, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (315, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (315, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (315, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (315, 4, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (315, 5, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (316, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (316, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (316, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (317, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (318, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (319, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (319, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (319, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (320, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (320, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (320, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (321, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (321, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (321, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (322, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (323, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (323, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (323, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (324, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (325, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (325, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (327, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (328, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (329, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (329, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (329, 3, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (329, 4, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (329, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (329, 6, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (329, 7, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (329, 8, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (330, 1, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (330, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (331, 1, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (331, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (331, 3, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (331, 4, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (331, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (331, 6, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (331, 7, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (331, 8, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (332, 1, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (332, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (334, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (336, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (336, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (336, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (337, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (338, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (338, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (338, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (339, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (339, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (339, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (340, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (340, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (340, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (341, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (341, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (341, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (341, 4, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (342, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (342, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (342, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (342, 4, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (343, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (343, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (343, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (344, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (344, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (344, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (345, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (345, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (345, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (345, 4, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (346, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (346, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (346, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (346, 4, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (347, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (347, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (347, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (347, 4, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (348, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (348, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (348, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (348, 4, 'I', '%d', 'N')
go
insert pass_log_defn_args values (348, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (348, 6, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (349, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (349, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (349, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (349, 4, 'I', '%d', 'N')
go
insert pass_log_defn_args values (349, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (349, 6, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (350, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (350, 2, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (350, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (350, 4, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (350, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (351, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (351, 2, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (351, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (351, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (352, 1, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (352, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (352, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (352, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (352, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (352, 6, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (353, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (353, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (353, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (353, 4, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (353, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (353, 6, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (353, 7, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (354, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (354, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (354, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (354, 4, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (354, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (354, 6, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (354, 7, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (355, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (355, 2, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (355, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (355, 4, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (355, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (356, 1, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (356, 2, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (356, 3, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (357, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (357, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (357, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (357, 4, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (357, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (357, 6, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (358, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (358, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (358, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (358, 4, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (358, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (358, 6, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (358, 7, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (359, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (360, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (361, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (366, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (367, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (367, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (368, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (369, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (370, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (371, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (372, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (373, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (374, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (374, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (375, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (376, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (377, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (378, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (378, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (379, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (379, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (380, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (383, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (383, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (383, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (384, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (384, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (384, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (385, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (385, 2, 'S', '%s', 'N')
go


/* *** */
insert pass_log_defn_args values (388, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (389, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (389, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (389, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (390, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (390, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (390, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (390, 4, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (391, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (391, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (391, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (391, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (391, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (392, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (392, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (392, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (392, 4, 'I', '%d', 'N')
go
insert pass_log_defn_args values (392, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (392, 6, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (393, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (393, 2, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (393, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (393, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (394, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (394, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (394, 3, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (395, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (395, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (396, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (396, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (396, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (396, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (396, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (396, 6, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (397, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (397, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (397, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (397, 4, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (398, 1, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (399, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (400, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (400, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (400, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (400, 4, 'I', '%d', 'N')
go
insert pass_log_defn_args values (400, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (400, 6, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (400, 7, 'S', '%s', 'N')
go
insert pass_log_defn_args values (400, 8, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (400, 9, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (400, 10, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (400, 11, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (401, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (401, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (401, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (401, 4, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (401, 5, 'S', '%s', 'N')
go
insert pass_log_defn_args values (401, 6, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (401, 7, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (402, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (402, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (402, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (402, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (402, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (402, 6, 'S', '%s', 'N')
go
insert pass_log_defn_args values (402, 7, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (402, 8, 'S', '%s', 'N')
go
insert pass_log_defn_args values (402, 9, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (403, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (403, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (403, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (403, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (403, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (403, 6, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (422, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (422, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (422, 3, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (423, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (423, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (423, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (423, 4, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (423, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (423, 6, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (423, 7, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (424, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (424, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (424, 3, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (424, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (424, 5, 'I', '%d', 'N')
go
insert pass_log_defn_args values (424, 6, 'S', '%s', 'N')
go
insert pass_log_defn_args values (424, 7, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (425, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (426, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (426, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (426, 3, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (426, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (426, 5, 'I', '%d', 'N')
go
insert pass_log_defn_args values (426, 6, 'S', '%s', 'N')
go
insert pass_log_defn_args values (426, 7, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (427, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (427, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (427, 3, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (427, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (427, 5, 'I', '%d', 'N')
go
insert pass_log_defn_args values (427, 6, 'S', '%s', 'N')
go
insert pass_log_defn_args values (427, 7, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (428, 1, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (428, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (428, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (428, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (429, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (429, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (429, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (429, 4, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (430, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (431, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (432, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (433, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (434, 1, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (435, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (436, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (437, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (438, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (439, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (440, 1, 'I', '%d', 'Y')
go


/* *** */
insert pass_log_defn_args values (442, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (443, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (445, 1, 'I', '%d', 'Y')
go


/* *** */
insert pass_log_defn_args values (448, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (453, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (453, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (453, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (454, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (454, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (454, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (455, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (455, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (455, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (455, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (455, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (456, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (457, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (457, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (457, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (457, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (458, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (459, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (459, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (461, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (461, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (462, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (462, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (462, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (463, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (464, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (464, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (465, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (465, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (466, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (467, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (467, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (468, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (469, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (470, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (470, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (470, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (471, 1, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (472, 1, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (473, 1, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (474, 1, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (477, 1, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (478, 1, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (479, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (479, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (479, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (479, 4, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (479, 5, 'I', '%d', 'N')
go
insert pass_log_defn_args values (479, 6, 'I', '%d', 'N')
go
insert pass_log_defn_args values (479, 7, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (480, 1, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (480, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (480, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (481, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (481, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (481, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (481, 4, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (481, 5, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (481, 6, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (481, 7, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (481, 8, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (482, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (483, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (484, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (484, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (485, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (485, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (485, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (485, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (485, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (486, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (486, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (486, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (486, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (486, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (487, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (487, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (487, 3, 'I', '%d', 'N')
go
insert pass_log_defn_args values (487, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (487, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (488, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (488, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (489, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (489, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (490, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (490, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (490, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (491, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (492, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (493, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (494, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (494, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (494, 3, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (495, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (495, 2, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (497, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (497, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (497, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (497, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (497, 5, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (497, 6, 'D', '%.3f', 'N')
go

/* *** */
insert pass_log_defn_args values (498, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (498, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (498, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (499, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (499, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (499, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (500, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (500, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (500, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (501, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (502, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (503, 1, 'D', '%.6f', 'N')
go
insert pass_log_defn_args values (503, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (503, 3, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (503, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (504, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (505, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (507, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (507, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (507, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (507, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (508, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (508, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (508, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (508, 4, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (509, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (509, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (509, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (509, 4, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (510, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (510, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (510, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (510, 4, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (511, 1, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (511, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (513, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (513, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (513, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (513, 4, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (514, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (514, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (514, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (516, 1, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (516, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (516, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (516, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (516, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (517, 1, 'D', '%.3f', 'N')
go
insert pass_log_defn_args values (517, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (517, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (517, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (518, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (518, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (519, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (519, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (519, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (519, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (520, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (520, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (520, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (521, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (521, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (521, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (522, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (522, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (523, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (523, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (523, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (523, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (524, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (524, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (524, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (525, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (526, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (526, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (526, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (527, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (527, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (529, 1, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (531, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (531, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (532, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (532, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (533, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (534, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (534, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (534, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (536, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (536, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (538, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (538, 2, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (539, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (540, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (541, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (541, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (542, 1, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (542, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (543, 1, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (543, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (544, 1, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (544, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (545, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (546, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (549, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (550, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (551, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (552, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (553, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (554, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (555, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (555, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (555, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (556, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (557, 1, 'D', '%.6f', 'N')
go

/* *** */
insert pass_log_defn_args values (558, 1, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (559, 1, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (560, 1, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (561, 1, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (561, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (561, 3, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (562, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (563, 1, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (564, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (564, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (564, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (564, 4, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (565, 1, 'D', '%.3f', 'N')
go

/* *** */
insert pass_log_defn_args values (566, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (566, 2, 'D', '%.2f', 'N')
go
insert pass_log_defn_args values (566, 3, 'D', '%.2f', 'N')
go

/* *** */
insert pass_log_defn_args values (567, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (567, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (567, 3, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (568, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (568, 2, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (568, 3, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (568, 4, 'I', '%d', 'N')
go

/* *** */
insert pass_log_defn_args values (573, 1, 'I', '%d', 'Y')
go

/* *** */
insert pass_log_defn_args values (574, 1, 'I', '%d', 'N')
go
insert pass_log_defn_args values (574, 2, 'S', '%s', 'N')
go
insert pass_log_defn_args values (574, 3, 'S', '%s', 'N')
go
insert pass_log_defn_args values (574, 4, 'S', '%s', 'N')
go
insert pass_log_defn_args values (574, 5, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (575, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (575, 2, 'I', '%d', 'N')
go
insert pass_log_defn_args values (575, 3, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (576, 1, 'S', '%s', 'N')
go
insert pass_log_defn_args values (576, 2, 'S', '%s', 'N')
go

/* *** */
insert pass_log_defn_args values (577, 1, 'I', '%d', 'Y')
go
insert pass_log_defn_args values (577, 2, 'D', '%.4f', 'N')
go
insert pass_log_defn_args values (577, 3, 'D', '%.4f', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1000 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1000,1,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1001 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1001,1,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1002 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1002,1,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1003 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1003,1,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1003 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1003,2,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1003 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1003,3,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1004 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1004,1,'D','%.3f','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1004 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1004,2,'D','%.3f','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1004 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1004,3,'D','%.3f','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1004 and
                     argument_num = 4)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1004,4,'D','%.3f','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1004 and
                     argument_num = 5)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1004,5,'D','%.3f','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1004 and
                     argument_num = 6)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1004,6,'D','%.3f','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1004 and
                     argument_num = 7)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1004,7,'D','%.3f','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1004 and
                     argument_num = 8)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1004,8,'D','%.3f','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 1005 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (1005,1,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5000 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5000, 1, 'S', '%s', 'N')
go
  
if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5001 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5001, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5001 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5001, 2, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5002 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5002, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5002 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5002, 2, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5003 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5003, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5004 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5004, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5005 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5005, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5005 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5005, 2, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5005 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5005, 3, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5006 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5006, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5006 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5006, 2, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5006 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5006, 3, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5006 and
                     argument_num = 4)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5006, 4, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5006 and
                     argument_num = 5)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5006, 5, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5006 and
                     argument_num = 6)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5006, 6, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5007 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5007, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5007 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5007, 2, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5007 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5007, 3, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5008 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5008, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5008 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5008, 2, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5008 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5008, 3, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5013 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5013, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5013 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5013, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5013 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5013, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5014 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5014, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5014 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5014, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5014 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5014, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5015 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5015, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5015 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5015, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5015 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5015, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5016 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5016, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5016 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values(5016, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5016 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5016, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5017 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5017, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5017 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5017, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5017 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5017, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5018 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5018, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5018 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5018, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5018 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5018, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5019 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5019, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5019 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5019, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5019 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5019, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5020 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5020, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5020 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5020, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5020 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5020, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5021 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5021, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5021 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5021, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5021 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5021, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5022 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5022, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5022 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5022, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5022 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5022, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5023 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5023, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5023 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5023, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5023 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5023, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5024 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5024, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5024 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5024, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5024 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5024, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5025 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5025, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5025 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5025, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5025 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5025, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5026 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5026, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5026 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5026, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5026 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5026, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5027 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5027, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5027 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5027, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5027 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5027, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5028 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5028, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5028 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5028, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5028 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5028, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5029 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5029, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5029 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5029, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5029 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5029, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5030 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5030, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5030 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5030, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5030 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5030, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5031 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5031, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5031 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5031, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5031 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5031, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5032 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5032, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5032 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5032, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5032 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5032, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5033 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5033, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5033 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5033, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5033 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5033, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5034 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5034, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5034 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5034, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5034 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5034, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5035 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5035, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5035 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5035, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5035 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5035, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5036 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5036, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5036 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5036, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5036 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5036, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5037 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5037, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5037 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5037, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5037 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5037, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5038 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5038, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5038 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5038, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5038 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5038, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5039 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5039, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5039 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5039, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5039 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5039, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5040 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5040, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5040 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5040, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5040 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5040, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5041 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5041, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5041 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5041, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5041 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5041, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5042 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5042, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5042 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5042, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5042 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5042, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5043 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5043, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5043 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5043, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5043 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5043, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5044 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5044, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5044 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5044, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5044 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5044, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5045 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5045, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5045 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5045, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5045 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5045, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5046 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5046, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5046 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5046, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5046 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5046, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5047 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5047, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5047 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5047, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5047 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5047, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5048 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5048, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5048 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5048, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5048 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5048, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5049 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5049, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5049 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5049, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5049 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5049, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5050 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5050, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5050 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5050, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5050 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5050, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5050 and
                     argument_num = 4)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5050, 4, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5050 and
                     argument_num = 5)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5050, 5, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5050 and
                     argument_num = 6)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5050, 6, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5050 and
                     argument_num = 7)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5050, 7, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5050 and
                     argument_num = 8)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5050, 8, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5051 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5051, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5051 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5051, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5051 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5051, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5052 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5052, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5052 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5052, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5052 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5052, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5052 and
                     argument_num = 4)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5052, 4, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5052 and
                     argument_num = 5)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5052, 5, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5052 and
                     argument_num = 6)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5052, 6, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5052 and
                     argument_num = 7)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5052, 7, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5052 and
                     argument_num = 8)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5052, 8, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5053 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5053, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5053 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5053, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5053 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5053, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5053 and
                     argument_num = 4)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5053, 4, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5053 and
                     argument_num = 5)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5053, 5, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5053 and
                     argument_num = 6)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5053, 6, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5053 and
                     argument_num = 7)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5053, 7, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5053 and
                     argument_num = 8)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5053, 8, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5053 and
                     argument_num = 9)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5053, 9, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5054 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5054, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5054 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5054, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5054 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5054, 3, 'I', '%d', 'Y')
go


if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5055 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5055, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5055 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5055, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5055 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5055, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5056 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5056, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5056 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5056, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5056 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5056, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5057 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5057, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5057 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5057, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5057 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5057, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5058 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5058, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5058 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5058, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5058 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5058, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5059 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5059, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5059 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5059, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5059 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5059, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5060 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5060, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5060 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5060, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5060 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5060, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5061 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5061, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5061 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5061, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5061 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5061, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5062 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5062, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5062 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5062, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5062 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5062, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5063 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5063, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5063 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5063, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5063 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5063, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5064 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5064, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5064 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5064, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5064 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5064, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5065 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5065, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5065 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5065, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5065 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5065, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5066 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5066, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5066 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5066, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5066 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5066, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5067 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5067, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5067 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5067, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5067 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5067, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5068 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5068, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5068 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5068, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5068 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5068, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5069 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5069, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5069 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5069, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5069 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5069, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5071 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5071, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5072 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5072, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5073 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5073, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5074 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5074, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5075 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5075, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5076 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5076, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5076 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5076, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5077 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5077, 1, 'D', '%0.2f', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5077 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5077, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5078 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5078, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5079 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5079, 1, 'D', '%0.2f', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5079 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5079, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5080 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5080, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5081 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5081, 1, 'D', '%0.2f', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5081 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5081, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5082 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5082, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5082 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5082, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5083 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5083, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5084 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5084, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5085 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5085, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5087 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5087, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5088 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5088, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5089 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5089, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5090 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5090, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5091 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5091, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5091 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5091, 2, 'S', '%s', 'N')

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5092 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5092, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5093 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5093, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5094 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5094, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5094 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5094, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5095 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5095, 1, 'D', '%0.2f', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5095 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5095, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5096 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5096, 1, 'D', '%0.4f', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5096 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5096, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5097 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5097, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5098 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5098, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5099 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5099, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5100 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5100, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5101 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5101, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5102 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5102, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5104 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5104, 1, 'D', '%0.4f', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5104 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5104, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5105 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5105, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5107 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5107, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5108 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5108, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5110 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5110, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5111 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5111, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5112 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5112, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5113 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5113, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5113 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5113, 2, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5113 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5113, 3, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5113 and
                     argument_num = 4)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5113, 4, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5113 and
                     argument_num = 5)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5113, 5, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5113 and
                     argument_num = 6)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5113, 6, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5114 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5114, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5115 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5115, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5115 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5115, 2, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5115 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5115, 3, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5115 and
                     argument_num = 4)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5115, 4, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5115 and
                     argument_num = 5)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5115, 5, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5115 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5115, 6, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5116 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5116, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5117 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5117, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5118 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5118, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5118 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5118, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5118 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5118, 3, 'S', '%s', 'N')
go

/* added 2/12/2004 */
if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5119 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5119, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5119 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5119, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5119 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5119, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5120 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5120, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5120 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5120, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5120 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5120, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5121 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5121, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5121 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5121, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5121 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5121, 3, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5122 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
     values(5122, 1, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5122 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
     values(5122, 2, 'I', '%d', 'Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5122 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5122, 3, 'I', '%d', 'Y')
go

/* BROKER FIFO */
if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5125 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
     values(5125, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5125 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
     values(5125, 2, 'I', '%d', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5125 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5125, 3, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5126 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
     values(5126, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5126 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
     values(5126, 2, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5126 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5126, 3, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5127 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5127, 1, 'I', '%d', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5128 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5128, 1, 'S', '%s', 'N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5129 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values(5129, 1, 'D', '%.2f', 'N')
go

/* FIFO

   8/2/2004  Peter Lo
*/
if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5131 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5131,1,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5132 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5132,1,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5133 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5133,1,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5134 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5134,1,'D','%.2f','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5135 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5135,1,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5136 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5136,1,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5136 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5136,2,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5137 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5137,1,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5137 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5137,2,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5138 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5138,1,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5138 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5138,2,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5138 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5138,3,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5139 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5139,1,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5140 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5140,1,'I','%d','Y')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5140 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5140,2,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5140 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5140,3,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5141 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5141,1,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5141 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5141,2,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5141 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5141,3,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5142 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5142,1,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5142 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5142,2,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5142 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5142,3,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5143 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5143,1,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5143 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5143,2,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5143 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5143,3,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5144 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5144,1,'D','%.6f','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5144 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5144,2,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5144 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5144,3,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5144 and
                     argument_num = 4)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5144,4,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5145 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5145,1,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5145 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5145,2,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5145 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5145,3,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5145 and
                     argument_num = 4)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5145,4,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5145 and
                     argument_num = 5)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5145,5,'D','%.2f','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5145 and
                     argument_num = 6)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5145,6,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5145 and
                     argument_num = 7)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5145,7,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5145 and
                     argument_num = 8)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5145,8,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5145 and
                     argument_num = 9)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5145,9,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5145 and
                     argument_num = 10)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5145,10,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5145 and
                     argument_num = 11)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5145,11,'D','%.2f','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5145 and
                     argument_num = 12)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5145,12,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5147 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5147,1,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5147 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5147,2,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5147 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5147,3,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5148 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5148,1,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5149 and
                     argument_num = 1)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5149,1,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5149 and
                     argument_num = 2)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5149,2,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5149 and
                     argument_num = 3)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5149,3,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5149 and
                     argument_num = 4)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5149,4,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5149 and
                     argument_num = 5)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
   values (5149,5,'S','%s','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5149 and
                     argument_num = 6)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5149,6,'I','%d','N')
go

if not exists (select 1 
               from pass_log_defn_args
               where pass_log_defn_id = 5149 and
                     argument_num = 7)
   insert into pass_log_defn_args (
      pass_log_defn_id,argument_num,argument_datatype,argument_format,is_primary_key_ind)
    values (5149,7,'S','%s','N')
go
