print ' '
print 'Loading startup reference data into the pass_task table ..'
go

set nocount on

create table #pass_task
(
   oid                 int IDENTITY primary key,
   pass_task_code	     char(20) not null,
   pass_task_desc	     varchar(255) null,
   pass_exec_order	   smallint null,
   task_split_ind	     char(1) not null,
   pass_task_status	   char(1) not null,
   pass_executor_id	   tinyint not null,
   exec_port_type      char(2) null   
)
go

-- Here, I use UNION ALL to avoid unnecessary sorting
insert into #pass_task
   (pass_task_code, pass_task_desc, pass_exec_order, task_split_ind,
    pass_task_status, pass_executor_id, exec_port_type)
select 'SAPVOUCHERSINBOUND', 'Receive Invoices from SAP', null, 'N', 'I', 0, null
union all
select 'SAPCASHINBOUND', 'Receive Cash Payments From SAP', null, 'N', 'I', 0, null
union all
select 'SAPACTUALSINBOUND', 'Receive Refinery Sales Actuals from SAP', null, 'N', 'I', 0, null
union all
select 'SAPACTUALSINGOODSREC', 'Receive Refinery Goods Receipts from SAP', null, 'N', 'I', 0, null
union all
select 'SAPACTUALSINTRUCKS', 'Receive Aggregated Truck Actuals from SAP', null, 'N', 'I', 0, null
union all
select 'PRICEMKTS', 'Price Formula Based Markets', null, 'N', 'A', 0, null
union all
select 'SIMPLTRADE', 'Price Simple Formula Trades', 1001, 'Y', 'I', 1, null
union all
select 'FORMULATRADE', 'Price Formula Trades', null, 'Y', 'A', 0, null
union all
select 'CALCOPTION', 'Calculate Options', null, 'Y', 'A', 1, null
union all
select 'CMPLXTRADE', 'Complex Trade Formulas', 1003, 'Y', 'I', 0, null
union all
select 'PRICEADDLCOSTS', 'Price Formula Based Additional Costs', null, 'Y', 'A', 0, null
union all
select 'CASHALLOC', 'Price Netout/Bookout/ComprClaim Allocations', null, 'Y', 'A', 0, null
union all
select 'PRICEFMLCOSTS', 'Price Formula Cost Rates', null, 'Y', 'A', 0, null
union all
select 'PRICEINV', 'Price Inventories', null, 'Y', 'A', 0, null
union all
select 'PRICEVESSEL', 'Price Fleet time vessel & Cargo', null, 'Y', 'I', 5, null
union all
select 'INVMAC_PRICE', 'Moving Average Inventory Pricing', null, 'Y', 'A', 0, null
union all
select 'XOPTBRKRFIFO', 'Broker FIFO Listed Options', null, 'N', 'I', 0, 'IW'
union all
select 'XOPTPORTMATCH', 'Portfolio Transaction Matching Listed Options', null, 'Y', 'I', 0, null
union all
select 'FIFOLOPT', 'FIFO Listed Options', null, 'Y', 'I', 0, null
union all
select 'PROCESSOPT', 'Exercise/Expire OTC - Expire Listed Options', null, 'Y', 'A', 0, null
union all
select 'EXERLISTEDOPT', 'Exercise Listed Options', null, 'Y', 'A', 0, null
union all
select 'EXPIREFUTURES', 'Expire Future Trades', null, 'Y', 'A', 0, null
union all
select 'FUTBRKRFIFO', 'Broker FIFO Futures', null, 'N', 'I', 0, 'IW'
union all
select 'FUTPORTMATCH', 'Portfolio Transaction Matching Futures', null, 'Y', 'I', 0, null
union all
select 'FIFOFUT', 'FIFO Futures', null, 'Y', 'A', 0, null
union all
select 'PASSPLSETUP', 'Misc setup tasks to be run before running passpl', null, 'Y', 'I', 0, null
union all
select 'PL', 'Compute Profit/Loss', null, 'Y', 'A', 0, null
union all
select 'FXPL', 'Calculate PL for FX costs', null, 'Y', 'A', 0, null
union all
select 'FXUPDATEEXP', 'Update FX Exposure', null, 'Y', 'I', 0, null
union all
select 'ROLLPL', 'Rollup PL', null, 'N', 'A', 0, null
union all
select 'FXROLLPL', 'Rollup FX PL', null, 'N', 'A', 0, null
union all
select 'OPL', 'Mark as Official PL', null, 'N', 'A', 0, null
union all
select 'ENDWEEK', 'Save P/L as End of Week', null, 'N', 'A', 0, null
union all
select 'ENDMONTH', 'Save P/L as End of Month', null, 'N', 'A', 0, null
union all
select 'ENDYEAR', 'Save P/L as End of Year', null, 'N', 'A', 0, null
union all
select 'ENDCOMPYR', 'Save P/L as End of Compensation Year', null, 'N', 'A', 0, null
union all
select 'EQUIVQTY', 'Update Equiv Qty', null, 'Y', 'A', 0, null
union all
select 'DISCOUNT', 'Update Discount Quantity', null, 'Y', 'I', 0, null
union all
select 'UPDATEPOS', 'Update position quantities', null, 'Y', 'I', 0, null
union all
select 'VERIFY_POS_LIMIT', 'Verify Position Limits', null, 'N', 'I', 0, null
union all
select 'SNAPEH', 'Snapshot Entire Hierarchy', null, 'N', 'A', 0, null
union all
select 'SNAPSH', 'Snapshot Selected Hierarchy', null, 'Y', 'A', 0, null
union all
select 'EXPGEN', 'Generate Exposure', null, 'N', 'A', 0, null
union all
select 'CASHFLOW', 'Cash Flow Report', null, 'N', 'A', 2, null
union all
select 'VARMARRPT', 'Variation Margin Report', null, 'N', 'I', 2, null
union all
select 'NOISEBANDDATA', 'Maintain Noise Bands Data', null, 'N', 'A', 0, null
union all
select 'SAPVOUCHERSOUTBOUND', 'Send Vouchers to SAP', null, 'N', 'A', 0, null
union all
select 'SAPDEALSUSERUPOUT', 'Send Physical Trades including updates to SAP', null, 'N', 'A', 0, null
union all
select 'SAPACTUALSOUTBOUND', 'Send B/L actuals to SAP', null, 'N', 'A', 0, null
union all
select 'COSTUPLOAD', 'Upload Costs', null, 'N', 'I', 0, null
union all
select 'SAPDEALPRICEUPDATOUT', 'Send Costs with EOD Price to SAP', null, 'N', 'A', 0, null
union all
select 'SAPDAILYRECONSIL', 'Send SAP reconciliation files to Control Panel', null, 'N', 'A', 0, null
/* union all
      <you can append new tasks nere>
*/
union all
select 'POSTPASSPL', 'Post passpl processing for real time P/L', 500, 'N', 'I', 0, null
go




/* ************************************************************************* */
/* Code block to add pass tasks into pass_task table starts here             */
/*                                                                           */
/* The code below consists of 2 INSERT statements. The ast statement adds    */
/* the tasks with hard-coded pass_exec_order (i.e. 1001, 1003, and 500).     */
/* The 2nd statement adds the tasks with NULL pass_exec_order. In this case, */
/* a seq # (stored in OID column) will be used to fill the pass_exec_order   */
/* columns for these tasks. By using this method, we can avoid hardcoding    */
/* the pass_exec_order for tasks, thus avoid changing pass_exec_order every  */
/* when new tasks have to be inserted into the task list                     */

declare @rows_affected       int,
        @total_tasks_added   int
       
set @total_tasks_added = 0
set @rows_affected = 0
        
begin try
  insert into dbo.pass_task
     (pass_task_code, pass_task_desc, pass_exec_order, task_split_ind,
      pass_task_status, pass_executor_id, exec_port_type)
  select pass_task_code,
         pass_task_desc,
         pass_exec_order,
         task_split_ind,
         pass_task_status,
         pass_executor_id,
         exec_port_type
  from #pass_task
  where pass_exec_order is not null
  set @rows_affected = @@rowcount
end try
begin catch
  print '=> Failed to move task records (1) from temp table to the pass_task table due to the erro:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch
set @total_tasks_added = @total_tasks_added + @rows_affected

begin try
  insert into dbo.pass_task
     (pass_task_code, pass_task_desc, pass_exec_order, task_split_ind,
      pass_task_status, pass_executor_id, exec_port_type)
  select pass_task_code,
         pass_task_desc,
         oid,
         task_split_ind,
         pass_task_status,
         pass_executor_id,
         exec_port_type
  from #pass_task
  where pass_exec_order is null
  set @rows_affected = @@rowcount
end try
begin catch
  print '=> Failed to move task records (2) from temp table to the pass_task table due to the erro:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch
set @total_tasks_added = @total_tasks_added + @rows_affected

print ' '
print '=> There are ' + cast(@total_tasks_added as varchar) + ' records added into the pass_task table!'
endofscript:
go


/* ADSO-7366 */
set nocount on

print ''
print 'Adding new pass task code ''CKIACCRUALSOUTBOUND'' into pass_task table IF NOT EXISTS ...'
print ''

declare @pass_exec_order_SAPAIT  	smallint,
	@rows_affected			int

if exists ( select 1 from dbo.pass_task where pass_task_code = 'CKIACCRUALSOUTBOUND' )
begin
     print '=> The new pass task code ''CKIACCRUALSOUTBOUND'' is already exists in pass_task table '
     goto endofscript
end
select @rows_affected = 0
select @pass_exec_order_SAPAIT = (select max(pass_exec_order) from dbo.pass_task );
begin tran
	begin try
		insert into dbo.pass_task(pass_task_code,pass_task_desc,pass_exec_order,task_split_ind,
		pass_task_status,pass_executor_id,exec_port_type)
		values('CKIACCRUALSOUTBOUND','Send Accrual Costs to CK JDE', @pass_exec_order_SAPAIT+1,'N','A',0,null)
	select @rows_affected = @@rowcount
	end try
	begin catch
		 if @@trancount > 0
			 rollback tran
		 print '=> Failed to insert new pass task code into pass_task table due to below error '
		 print ERROR_MESSAGE()
		 goto endofscript
	end catch
commit tran
if @rows_affected > 0
     print '=> Added a new pass task code into pass_task table successfully !'

endofscript:
go

/* ADSO-7377 */
set nocount on

print ''
print 'Adding new pass task code ''CKIDEALSOUTBOUND'' into pass_task table IF NOT EXISTS ...'
print ''

declare @pass_exec_order_SAPAIT  	smallint,
	@rows_affected			int

if exists ( select 1 from dbo.pass_task where pass_task_code = 'CKIDEALSOUTBOUND' )
begin
     print '=> The new pass task code ''CKIDEALSOUTBOUND'' is already exists in pass_task table '
     goto endofscript
end
select @rows_affected = 0
select @pass_exec_order_SAPAIT = (select max(pass_exec_order) from dbo.pass_task );
begin tran
	begin try
		insert into dbo.pass_task(pass_task_code,pass_task_desc,pass_exec_order,task_split_ind,
		pass_task_status,pass_executor_id,exec_port_type)
		values('CKIDEALSOUTBOUND','Send Shipment parcel details of deals to CK JDE', @pass_exec_order_SAPAIT+1,'N','A',0,null)
	select @rows_affected = @@rowcount
	end try
	begin catch
		 if @@trancount > 0
			 rollback tran
		 print '=> Failed to insert new pass task code into pass_task table due to below error '
		 print ERROR_MESSAGE()
		 goto endofscript
	end catch
commit tran
if @rows_affected > 0
     print '=> Added a new pass task code into pass_task table successfully !'

endofscript:
go

/* ******************************************************************************** */
/* ADSO-7412 */
set nocount on

print ''
print 'Updating pass task code name ''SAPCASHINBOUND'' to ''COSTUPLOAD'' IF NOT EXISTS'
print ''

if exists (select 1 
           from dbo.pass_task 
           where pass_task_code = 'COSTUPLOAD')
begin
   print '=> pass task code ''COSTUPLOAD'' is already exists in pass_task table '
   goto endofscript
end

declare @rows_affected	int

select @rows_affected = 0

begin tran
begin try
  update dbo.pass_task
  set pass_task_code = 'COSTUPLOAD',
      pass_task_desc = 'Upload Costs',
      pass_task_status = 'A'
  where pass_task_code = 'SAPCASHINBOUND'
  set @rows_affected = @@rowcount
end try
begin catch
  if @@trancount > 0
     rollback tran
  print 'Failed to update pass_task_code due to below error '
  print ERROR_MESSAGE()
  goto endofscript
end catch
commit tran
if @rows_affected > 0
   print '=> ' + convert(varchar, @rows_affected) + ' Rows updated in pass_task table successfully !'
endofscript:
go

if not exists (select 1
               from dbo.pass_task
               where pass_task_code = 'CKISETLEMNTSOUTBOUND')
begin
   declare @pass_exec_order_SAPAIT  	smallint

   set @pass_exec_order_SAPAIT = (select max(pass_exec_order) from dbo.pass_task);

   insert into dbo.pass_task
        (pass_task_code,pass_task_desc,pass_exec_order,task_split_ind,
		     pass_task_status,pass_executor_id,exec_port_type)
     values('CKISETLEMNTSOUTBOUND', 'Send vouchers to CK JDE', @pass_exec_order_SAPAIT+1, 'N', 'A', 0, null)
end
go

