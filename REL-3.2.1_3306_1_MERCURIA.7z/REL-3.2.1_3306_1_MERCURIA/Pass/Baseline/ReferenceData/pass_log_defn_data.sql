set nocount on

print ' '
print 'Loading reference data into the pass_log_defn table ..'
go

insert pass_log_defn values (1, 'inventory', 'PDT', 'Inventory num %s is in same loop as inventory num %s... skipping.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (2, NULL, 'PDT', 'Date: (required <=> found) %s<=>%s do not match so creationInd becomes T.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (3, 'portfolio', 'PER', 'ACCESS DENIED FOR PORTFOLIO %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (4, 'cost', 'PDT', 'From cost %s (%s) adding %s %s as additional cost for trade/order/item/dist %s/%s/%s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (5, 'cost', 'PDT', 'From cost %s (%s) adding %s %s as closed P/L for trade/order/item/dist %s/%s/%s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (6, 'cost', 'PDT', 'From cost %s (%s) adding %s %s as open P/L cost amount for trade/order/item/dist %s/%s/%s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (7, 'tradeItemDist', 'PDT', 'From trade/order/item/dist %s/%s/%s/%s adding %s %s as realized closed P/L with alloc qty %s, price %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (8, 'tradeItemDist', 'PDT', 'From trade/order/item/dist %s/%s/%s/%s adding %s %s as realized open P/L with alloc qty %s, price %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (9, 'tradeItemDist', 'PDT', 'From trade/order/item/dist %s/%s/%s/%s adding %s %s as unrealized open P/L with open qty %s, market price %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (10, NULL, 'PDT', 'Adding the quote value for product: %s, quoteValue: %s %s/%s for market: %s. The percentage picked for this quote is: %s in netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (11, NULL, 'PDT', 'Adjusted price: (%s + (%s * %s))/(%s) = %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (12, NULL, 'PDT', 'Adjusting trade price to %s %s/%s for density.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (13, 'allocation', 'PDT', 'Allocation %s is not closed, skipping.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (14, 'allocation', 'PDT', 'Allocation %s, pricing inventory %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (15, 'allocation', 'PDT', 'Allocation %s: Total value=%s %s, total qty=%s %s, weighted average=%s %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (16, 'allocation', 'PDT', 'Allocation P/L %s has no currency code, skipping ...', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (17, 'cost', 'PDT', 'Cost %s has NULL amount, skipping...', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (18, 'formula', 'PDT', 'Avg closed price could not be evaluated for complex formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (19, 'tradeItem', 'PDT', 'AvgFillPrice/uom/currency not found for future trade (trade/order/item) %s/%s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (20, 'tradeItem', 'PDT', 'AvgPrice/uom/currency not found for option trade (trade/order/item) %s/%s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (21, 'positionGroup', 'PDT', 'Begin closed P/L computation for position group: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (22, 'tradeItemDist', 'PDT', 'Begin mark-to-market for trade/order/item/dist %s/%s/%s/%s (%s %s %s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (23, 'position', 'PDT', 'Begin open P/L computation for position: %s (%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (24, 'position', 'PDT', 'Begin open P/L computation for position: %s (%s,%s,%s,%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (25, 'portfolio', 'PDT', 'Begin PassPriceInventories for portfolio num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (26, 'task', 'PDT', 'Begin PassPriceInventories task code %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (27, NULL, 'PDT', 'Begin PassPriceTrades.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (28, 'tradeItemDist', 'PDT', 'Begin P/L calculations for trade/order/item/dist %s/%s/%s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (29, 'position', 'PDT', 'Begin position num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (30, 'tradeItemDist', 'PDT', 'Begin trade/order/item/dist  %s/%s/%s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (31, 'inventory', 'PDT', 'Build values for inventory num %s: Amt (R/U): (%s / %s) %s Qty: %s %s. (@ %s %s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (32, NULL, 'PER', 'Cannot allocate memory for %s in %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (33, NULL, 'PER', 'Cannot allocate resize memory in %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (34, 'task', 'PER', 'Cannot begin PassPriceInventories: invalid task code %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (35, NULL, 'PER', 'Cannot calculate price for %s, %s, %s due to a cyclic reference.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (36, 'tradeItem', 'PDT', 'Cannot compute MTM P/L for trade item (trade/order/item) %s/%s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (37, 'inventoryBuildDraw', 'PDT', 'Skipping inventory B/D record (%s,%s)... cannot convert currency %s to %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (38, NULL, 'PER', 'Could not find factor for converting UOM %s to %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (39, 'tradeItem', 'PER', 'Failure in create/update costs for tradeItem (%s/%s/%s): %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (40, 'portfolio', 'PER', 'Cannot delete inventory_history records for portfolio num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (41, NULL, 'PER', 'Cannot do uom/currency conversion due to missing currency or uom code for %s, %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (42, NULL, 'PDT', 'Cannot find any deliveries so using market value = %s %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (43, NULL, 'PER', 'Cannot find commodity_market_formula cmf_num: %s for market_price_quote_dates (quoteDate/calendarDate): (%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (44, 'position', 'PER', 'Cannot find market price for position: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (45, 'cost', 'PER', 'Cannot find parent cost for %s cost %s, skipping...', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (46, NULL, 'PER', 'Cannot find price for cmdtyCode/mkt/tPrd/priceSource/date (%s/%s/%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (47, NULL, 'PER', 'Cannot load currency for %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (48, 'cost', 'PER', 'For cost %s, cannot obtain currency factor between %s and %s, skipping...', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (49, 'position', 'PDT', 'Cash OTC option exercised for position num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (50, NULL, 'PDT', 'Cleaning up positions which may have expired before %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (51, 'portfolio', 'PDT', 'Closed hedge P/L for position group: %s = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (52, NULL, 'PDT', 'Closed physical P/L = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (53, 'portfolio', 'PDT', 'Closed physical P/L for position group: %s = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (54, NULL, 'PDT', 'Completed closed P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (55, NULL, 'PDT', 'Completed creating PassSnapShots.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (56, NULL, 'PDT', 'Completed PassEndPeriod.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (57, 'portfolio', 'PDT', 'Completed passPriceTrades for portfolio num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (58, NULL, 'PDT', 'Completed pass update underlying equivalents.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (59, 'portfolio', 'PDT', 'Completed processing non position portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (60, NULL, 'PDT', 'Completed processing PassPL.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (61, NULL, 'PDT', 'Completed processing portfolio joint venture.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (62, 'portfolio', 'PDT', 'Completed processing Position Portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (63, NULL, 'PDT', 'Completed PassPriceInventories.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (64, 'position', 'PDT', 'Computed NULL longQty for position num %s. Not updating position.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (65, 'position', 'PDT', 'Computed NULL posPricedQty for position num %s. Not updating position.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (66, 'position', 'PDT', 'Computed NULL purchPrice for position num %s. Not updating position.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (67, 'position', 'PDT', 'Computed NULL salePrice for position num %s. Not updating position.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (68, 'position', 'PDT', 'Computed NULL shortQty for position num %s. Not updating position.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (69, 'inventory', 'PDT', 'Computing previous inventory num %s before inventory num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (70, NULL, 'PDT', 'UOM conversion factor (%s to %s) = %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (71, NULL, 'PDT', 'Converted inventory price is %s %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (72, NULL, 'PDT', 'Converted market price for position is %s %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (73, NULL, 'PDT', 'Converted trade price is %s %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (74, NULL, 'PDT', 'Converting currency between market price and portfolio.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (75, NULL, 'PDT', 'Converting currency between plReconciliation and portfolio.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (76, NULL, 'PDT', 'Converting currency between position and portfolio.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (77, NULL, 'PDT', 'Converting currency between position and price. Conversion factor (%s to %s) = %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (78, NULL, 'PDT', 'Currency conversion factor (%s to %s) = %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (79, 'inventory', 'PDT', 'Converting inventory (%s) price from %s to %s using hedge rate %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (80, 'tradeItem', 'PDT', 'Converting inventory (%s/%s/%s) price from %s to %s using hedge rate %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (81, 'tradeItem', 'PDT', 'Converting trade (%s/%s/%s) price from %s to %s using hedge rate %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (82, NULL, 'PDT', 'Converting UOM between market price and trade price.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (83, NULL, 'PDT', 'Converting UOM between trade quantity and price unit.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (84, 'cost', 'PDT', 'Cost num %s due date is NULL, resetting it to %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (85, 'cost', 'PDT', 'Cost num %s effective date is NULL, resetting it to %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (86, 'cost', 'PDT', 'Cost num %s is a receivable, should reduce inventory price.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (87, 'cost', 'PDT', 'Cost num %s is price actualized, not updating.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (88, 'cost', 'PDT', 'Cost %s is not brokerage cost, is marked as closed P/L but does not have an allocation P/L associated.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (89, 'cost', 'PDT', 'Cost %s is part of a partial allocation, with a ratio %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (90, 'cost', 'PDT', 'Cost %s has NULL amount, skipping...', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (91, 'cost', 'PDT', 'Cost %s is not in real portfolio %s, skipping ...', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (92, 'position', 'PDT', 'Costs updated for position %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (93, NULL, 'PDT', 'Could create key for getting TradeItemExchOpt.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (94, NULL, 'PDT', 'Could create key for getting TradeItemFut.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (95, NULL, 'PDT', 'Could create key for getting TradeItemOtcOpt.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (96, NULL, 'PER', 'Could not add %s to hash.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (97, NULL, 'PER', 'Could not allocate memory for %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (98, 'market', 'PER', 'Could not compute contributions for mktCode: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (99, 'tradeItemDist', 'PER', 'For accumulation TID (%s/%s/%s/%s) could not convert %s to %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (100, NULL, 'PER', 'Could not convert inventory qty uom %s to cost uom %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (101, NULL, 'PER', 'Could not convert inventory qty uom %s to position uom %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (102, NULL, 'PER', 'Could not create a hash key for %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (103, 'cost', 'PER', 'Could not create inventoryHistory record for cost num %s (amt: %s %s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (104, 'cost', 'PER', 'Could not create inventoryHistory record for PR/PO cost num %s (amt: %s %s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (105, 'inventoryBuildDraw', 'PER', 'Could not create inventoryHistory record for rcptBuildDraw num (%s,%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (106, NULL, 'PER', 'Could not create key for getting Related distributions.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (107, 'cost', 'PER', 'Could not delete plHistory records for cost: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (108, 'portfolio', 'PER', 'Could not delete plHistory records for portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (109, 'formula', 'PER', 'Could not evaluate simple formula num %s. Cannot calculate price for %s, %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (110, NULL, 'PER', 'Could not find commodity market formula for %s, %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (111, NULL, 'PER', 'Could not find factor for converting UOM %s to %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (112, NULL, 'PER', 'Could not find quotePrice for commktKey:tradingPrd:priceSourceCode (%s:%s:%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (113, NULL, 'PER', 'Could not find trading period for commktKey:tradingPrd (%s:%s). So previous prices not found -- FISCAL PRICE FAILS -- only pricing for date %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (114, NULL, 'PER', 'Could not find trading period for commktKey:tradingPrd (%s:%s). So previous prices not found -- marketPriceQuoteDates -- only pricing for date %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (115, NULL, 'PER', 'Could not get a transaction id in getICTSTransaction.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (116, 'formulaBody', 'PER', 'Could not get formulaBody for formula num %s, body num %s, component num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (117, 'formulaBody', 'PER', 'Could not get formulaBody for formula num %s, body num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (118, NULL, 'PER', 'Could not get number of portfolioProfitLoss records in getNumRecords.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (119, NULL, 'PER', 'Could not get number of portfolios in getNumPortfolios.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (120, NULL, 'PER', 'Could not get number of positions in getNumPositions.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (121, NULL, 'PER', 'Could not get quoteValue for product: %s, in mkt: %s in currCode/uomCode: %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (122, NULL, 'PER', 'Could not load %s from the database.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (123, NULL, 'PER', 'Could not load %s in %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (124, NULL, 'PER', 'Could not load commktKey:tradingPrd;priceSourceCode -- %s:%s:%s in loadCommktFormulaByKey.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (125, 'formula', 'PER', 'Could not load formula body for formula number %s in loadAllFormulaBodyForFormulaNum.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (126, 'formulaBody', 'PER', 'Could not load formula components for formula number %s and formula_body_num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (127, 'formula', 'PER', 'Could not load formula number %s in loadCommktFormulaNum.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (128, 'formula', 'PER', 'Could not load formula number %s in loadFormulaNum.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (129, 'formula', 'PER', 'Could not load formula number %s in loadSimpleFormulaNum.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (130, 'formula', 'PER', 'Could not load formula number %s in loadCommktFormulaForCmfNumList.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (131, NULL, 'PER', 'Could not load interest Rate for cmdtyCode: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (132, NULL, 'PER', 'Could not locate commktFutureAttr %s. Unable to fetch UOM and currency for price for %s, %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (133, NULL, 'PER', 'Could not locate commktPhysicalAttr %s. Unable to fetch uom and currency for price for %s, %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (134, NULL, 'PER', 'Could not locate commodityMarket %s. Unable to fetch uom and currency for price for %s, %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (135, NULL, 'PER', 'Could not locate price for %s, %s, %s. Cannot calculate price for %s, %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (136, 'formula', 'PER', 'Could not locate simple formula num %s. Cannot calculate price for %s, %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (137, 'position', 'PER', 'Could not mark inventory position %s to market.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (138, NULL, 'PER', 'Could not re-allocate memory for %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (139, 'tradeItem', 'PDT', 'Create settlement cost for tradeItem (%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (140, 'portfolio', 'PDT', 'For Portfolio: %s, created new JV offset cost: %s and JV cost: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (141, 'position', 'PDT', 'Created query for updating position num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (142, NULL, 'PDT', 'Creating settlement costs for options expriring on %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (143, 'cost', 'PER', 'Currency code not defined for cost num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (144, 'tradeItem', 'PER', 'Currency code not defined for inventory for TOI - (%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (145, NULL, 'PER', 'Currency code not defined for position.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (146, NULL, 'PER', 'Currency code not defined for price.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (147, NULL, 'PDT', 'Currency conversion factor (%s to %s) = %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (148, 'inventory', 'PDT', 'Current month price for inventory num %s. It has transactions of %s %s at %s %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (149, 'position', 'PER', 'Current price not available for inventory position num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (150, 'position', 'PDT', 'Current price not available for inventory position %s, purchase or sale price of the position %s %s/%s has been used instead.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (151, NULL, 'PDT', 'Current price not found so market price is %s (inventory average cost).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (152, 'formula', 'PDT', 'Cyclic reference to avgClosed quote evaluation for formula: %s cmfNum: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (153, 'formula', 'PDT', 'Cyclic reference to avgClosed quote evaluation for simple formula: %s cmfNum: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (154, 'formula', 'PDT', 'Cyclic reference to highAsked quote evaluation for formula: %s cmfNum: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (155, 'formula', 'PDT', 'Cyclic reference to highAsked quote evaluation for simple formula: %s cmfNum: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (156, 'formula', 'PDT', 'Cyclic reference to lowBid quote evaluation for formula: %s cmfNum: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (157, 'formula', 'PDT', 'Cyclic reference to lowBid quote evaluation for simple formula: %s cmfNum: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (158, 'tradeItemDist', 'PDT', 'Delta for trade item distribution (%s/%s/%s/%s) = %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (159, NULL, 'PDT', 'Dist qty = %s * %s = %s %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (160, NULL, 'PDT', 'Distribution is a swaption, skipping...', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (161, 'position', 'PDT', 'Doing P/L for any inhouse otc option position: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (162, 'position', 'PDT', 'Doing P/L for exchange option position: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (163, 'position', 'PDT', 'Doing P/L for swap position: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (164, NULL, 'PDT', 'Done loading all costs at: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (165, 'portfolio', 'PDT', 'Done PassPriceInventories for portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (166, 'inventory', 'PDT', 'Done pricing inventory num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (167, 'portfolio', 'PDT', 'End closed P/L computation for position group: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (168, NULL, 'PDT', 'End creating/updating settlement costs for options expiring on %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (169, 'formula', 'PDT', 'End evaluation for avgClosed complex formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (170, 'formula', 'PDT', 'End evaluation for avgClosed simple formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (171, NULL, 'PDT', 'End evaluation for cmfNum: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (172, 'formula', 'PDT', 'End evaluation for high_asked complex formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (173, 'formula', 'PDT', 'End evaluation for high_asked simple formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (174, 'formula', 'PDT', 'End evaluation for low_bid complex formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (175, 'formula', 'PDT', 'End evaluation for low_bid simple formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (176, 'tradeItemDist', 'PDT', 'End mark-to-market for trade/order/item/dist (%s/%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (177, NULL, 'PDT', 'End of period, but some prices are temporary so not updating previous avgClosedFiscal prices.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (178, NULL, 'PDT', 'End of period, but some prices are temporary so not updating previous highAskedFiscal prices.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (179, NULL, 'PDT', 'End of period, but some prices are temporary so not updating previous lowBidFiscal prices.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (180, NULL, 'PDT', 'End of period, updating previous avgClosedprices.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (181, NULL, 'PDT', 'End of period, updating previous highAskeddprices.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (182, NULL, 'PDT', 'End of period, updating previous lowBidprices.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (183, 'position', 'PDT', 'End open P/L computation for position: %s (%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (184, 'position', 'PDT', 'End open P/L computation for position: %s (%s,%s,%s,%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (185, 'tradeItemDist', 'PDT', 'End P/L computation for trade/order/item/dist (%s/%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (186, 'position', 'PDT', 'End position num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (187, 'tradeItemDist', 'PDT', 'End trade/order/item/dist (%s/%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (188, NULL, 'PDT', 'Ending avgClosed fiscal pricing for date: %s for commktFormulaNum|tradingPrd -- %s:%s; could not evaluate.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (189, NULL, 'PDT', 'Ending highAsked fiscal pricing for date: %s for commktFormulaNum|tradingPrd -- %s:%s; could not evaluate.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (190, NULL, 'PDT', 'Ending lowBid fiscal pricing for date: %s for commktFormulaNum|tradingPrd -- %s:%s; could not evaluate.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (191, NULL, 'PDT', 'For asOfDate: %s, could not figure out trading period so no fiscal pricing.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (192, NULL, 'PDT', 'Evaluating simpleFormula (num|commkt|tradingPrd|priceSource) (%s|%s|%s|%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (193, NULL, 'PER', 'Failed to add %s to hash.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (194, 'portfolio', 'PER', 'Failed to create new JV cost for portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (195, 'portfolio', 'PER', 'Failed to create new JV offset and JV costs for Portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (196, 'portfolio', 'PER', 'Failed to create SnapShot for selected hierarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (197, 'position', 'PER', 'Failed to exercise cash OTC option for position %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (198, 'position', 'PER', 'Failed to expire option in position num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (199, 'position', 'PER', 'Failed to find parent portfolioNode for posNum:%s in getParentRealPortfolioForPosition.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (200, 'portfolio', 'PER', 'Failed to find portfolioNode for portNum:%s in createheirarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (201, 'portfolio', 'PER', 'Failed to find portfolioNode for portNum:%s in getParentRealPortfolioForPosition; getting real portfolio for posNum: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (202, 'portfolio', 'PER', 'Failed to get portfolio node for portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (203, NULL, 'PER', 'Failed to load portfolioGroup nodes in createheirarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (204, NULL, 'PER', 'Failed to load portfolioGroup nodes in getParentRealPortfolioForPosition.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (205, NULL, 'PER', 'Failed to load portfolios in createheirarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (206, NULL, 'PER', 'Failed to load portfolios in getParentRealPortfolioForPosition.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (207, NULL, 'PER', 'Failed to update inventories.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (208, 'tradeItem', 'PER', 'Failed to Update P/L for trade item (trade/order/item) (%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (209, 'portfolio', 'PER', 'Failed to update/insert P/L for portfolio: %s and market info for position: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (210, 'portfolio', 'PER', 'Failed to update/insert P/L for portfolio: %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (211, 'tradeItem', 'PER', 'Failure in saving exercising for option item (%s/%s/%s): %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (212, 'position', 'PER', 'Position %s. Failure in updating position quantities.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (213, NULL, 'PER', 'Failure to load all data from %s table for cmfNum|startDate|endDate -- %s|%s|%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (214, NULL, 'PER', 'Failure to load data from %s table.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (215, NULL, 'PDT', 'Finalizing settlement costs for options expiring on %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (216, 'inventory', 'PDT', 'For build (I-A/AI) (%s-%s/%s), setting total/realized/unrealized amounts %s/%s/%s %s, obtained by (%s * %s * %s), (%s * %s * %s), and (%s * %s * %s).', NULL, NULL, NULL, 'I')
go
insert pass_log_defn values (217, NULL, 'PDT', 'For commktKey:pricesourceCode:tradingPrd:date (%s:%s:%s:%s) picked price: %s:%s:%s:%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (218, NULL, 'PDT', 'For asOfDate: %s, fiscal price -- period start:end are: %s:%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (219, 'portfolio', 'PDT', 'For portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (220, NULL, 'PDT', 'Found hedge rate for cost (%s, %s %s %s) of %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (221, NULL, 'PDT', 'Found NBVI value: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (222, NULL, 'PDT', 'Found RP_Differential value: %s %s/%s for commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (223, NULL, 'PDT', 'Freight calculation: flatRateCode: %s, worldScaleCode: %s freightValue = (convToCrudeMkt * convFactorToFormula * flatRateValue * WorldScalePercentage)/100.0: %s = (%s * %s * %s * %s)/100 in netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (224, NULL, 'PDT', 'Generic table conversion factor from commktKey/currCode/uomCode %s/%s/%s to currCode/uomCode: %s/%s is: %s (currFactor * uomFactor: %s * %s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (225, NULL, 'PDT', 'Generic table currency conversion factor is being inverted from commktKey/currCode %s/%s to currCode: %s is: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (226, NULL, 'PDT', 'Generic table uom conversion factor is being inverted from commktKey/uomCode %s/%s to uomCode: %s is: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (227, NULL, 'PDT', 'Getting marketQuoteDates for previously priced for asOfDate: %s, period start:end are %s:%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (228, NULL, 'PER', 'Getting transaction ID failed in updateInventoryPositions.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (229, NULL, 'PER', 'GLOBAL TASK ACCESS DENIED.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (230, 'formula', 'PER', 'High_asked price could not be evaluated for complex formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (231, NULL, 'PDT', 'Ignoring costName: %s, costAmt: %s, for market:%s in netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (232, NULL, 'PDT', 'Ignoring FreightCost for market:%s in netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (233, NULL, 'PDT', 'Including costName: %s, value: %s %s/%s conversion factor (toCrudeMkt * toFormulaUnits): %s * %s for market:%s in netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (234, NULL, 'PDT', 'Including freight cost, value: %s %s/%s for market:%s in netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (235, NULL, 'PER', 'Invalid Position type %s. So not saving P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (236, NULL, 'PER', 'Invalid value of delta found for distribution %s/%s/%s/%s, skipping (position may have expired or had missing data while marking to market.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (237, NULL, 'PDT', 'Inventories in a loop: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (238, 'inventoryBuildDraw', 'PER', 'Inventory B/D record (%s,%s) has NULL amount skipping ...', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (239, 'inventoryBuildDraw', 'PER', 'Inventory B/D record (%s,%s) has NULL currency, defaulting to USD', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (240, 'inventoryBuildDraw', 'PER', 'Inventory B/D record (%s,%s) has wrong portfolio (%s). Picking up in allocation: %s portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (241, 'inventory', 'PDT', 'Inventory build records not found for inventory num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (242, 'position', 'PER', 'Inventory position %s does not have a long quantity.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (243, 'inventory', 'PER', 'Inventory num %s has no deliveries.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (244, NULL, 'PER', 'Load AASpecs from the database using loadAllAASpecs before asking for one.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (245, NULL, 'PER', 'Load All cost scheduled price records.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (246, NULL, 'PER', 'Load commodityMarket from the database using loadAllCommodityMarket before asking for one.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (247, NULL, 'PER', 'Load constants using loadAllConstants before asking for a value.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (248, NULL, 'PER', 'Load Currency from the database using loadAllCurrencies before asking for one.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (249, NULL, 'PER', 'Load related distributions.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (250, NULL, 'PER', 'Load TISpecs from the database using loadAllTISpecs before asking for one.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (251, 'formula', 'PER', 'Low_bid price could not be evaluated for complex formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (252, NULL, 'PDT', 'Market price for inventory position is %s %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (253, NULL, 'PDT', 'Market price for position is %s %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (254, 'position', 'PER', 'Market price not found for position: %s (%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (255, 'position', 'PER', 'Market price not found for position: %s (%s,%s,%s,%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (256, NULL, 'PER', 'Missing commodityCode in generic_data_values table for productQuoteFactor.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (257, NULL, 'PER', 'Missing conversionTypeInd in generic_data_values table for NbviConversionFactor for commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (258, NULL, 'PER', 'Missing costCurrCode in generic_data_values table for marketCostsNbvi.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (259, NULL, 'PER', 'Missing costName in generic_data_values table for marketCostsNbvi.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (260, NULL, 'PER', 'Missing costUomCode in generic_data_values table for marketCostsNbvi.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (261, NULL, 'PER', 'Missing flatRateCode in generic_data_values table for flatRate.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (262, NULL, 'PER', 'Missing flatRateCode in generic_data_values table for freightCode for commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (263, NULL, 'PER', 'Missing flatRateCurrCode in generic_data_values table for flatRate for flatRateCode: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (264, NULL, 'PER', 'Missing flatRateUomCode in generic_data_values table for flatRate for flatRateCode: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (265, NULL, 'PER', 'Missing fromCode in generic_data_values table for NbviConversionFactor for commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (266, NULL, 'PER', 'Missing marketCode in generic_data_values table for crudePriceComposition.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (267, NULL, 'PER', 'Missing marketCode in generic_data_values table for freightCode for commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (268, NULL, 'PER', 'Missing marketCode in generic_data_values table for marketCost.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (269, NULL, 'PER', 'Missing marketCode in generic_data_values table for productQuoteFactor.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (270, NULL, 'PER', 'Missing marketCode in generic_data_values table for productYield, commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (271, NULL, 'PER', 'Missing productCommodityCode in generic_data_values table for productYield, commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (272, NULL, 'PER', 'Missing quotePriceSourceCode in generic_data_values table for productQuoteFactor.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (273, NULL, 'PER', 'Missing quotePriceType in generic_data_values table for productQuoteFactor.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (274, NULL, 'PER', 'Missing quoteTradingPeriod in generic_data_values table for productQuoteFactor.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (275, NULL, 'PER', 'Missing rp_differential uomCode in generic_data_values table for commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (276, NULL, 'PER', 'Missing toCode in generic_data_values table for NbviConversionFactor for commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (277, NULL, 'PER', 'Missing worldScaleCode in generic_data_values table for freightCode for commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (278, NULL, 'PER', 'Missing WorldScaleCode in generic_data_values table for WorldScale.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (279, NULL, 'PDT', 'Multiple conversion factors for commktKey: %s and fromCode: %s toCode: %s in setNetBackValueInitial. We picked: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (280, NULL, 'PDT', 'Multiple flat rate values for flatrateCode: %s and forDate: %s in setNetBackValueInitial. We picked: value amt curr/uom: %s %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (281, NULL, 'PDT', 'Multiple freightCodes for mktCode: %s and commktKey: %s in setNetBackValueInitial. We picked: worldScaleCode %s; flatRateCode: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (282, NULL, 'PDT', 'Multiple quotes for productCmdtyCode: %s and mktCode: %s in setNetBackValueInitial. We picked: quote commktKey/priceSource/tradingPrd/priceType/percentage: %s/%s/%s/%s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (283, NULL, 'PDT', 'Multiple rp_differential values for commktKey: %s in getRPDifferential. We picked: value: %s %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (284, NULL, 'PDT', 'Multiple worldScale values for worldScaleCode: %s and forDate: %s in setNetBackValueInitial. We picked: percentage: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (285, 'accumulation', 'PER', 'No accumulation for trade:order:item:accum; %s:%s:%s:%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (286, 'tradeItemDist', 'PER', 'No accumulations found for tradeItemDist (%s/%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (287, NULL, 'PER', 'No commodityMarket record for cmdtyCode: %s (realizable commodity), and marketCode: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (288, NULL, 'PER', 'No commodityMarket record for commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (289, NULL, 'PER', 'No constant in hash for name %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (290, 'cost', 'PER', 'No cost relative price list for cost num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (291, 'cost', 'PER', 'No cost scheduled rate list for cost num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (292, 'cost', 'PER', 'No currency or uomcode for mktCode: %s, currCode: %s, uomCode: %s for netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (293, NULL, 'PER', 'No data definition for %s for netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (294, NULL, 'PER', 'No data for %s for netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (295, NULL, 'PER', 'No database connection for retrieving formula components for formula num: %s, formulaBody num: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (296, NULL, 'PER', 'No flatRate entry for flatRateCode: %s, date: %s in netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (297, 'formula', 'PER', 'No formula bodies for formula num: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (298, 'formulaBody', 'PER', 'No formula components for formula num: %s, formulaBody num: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (299, NULL, 'PER', 'No freightRate entry for commktKey: %s mktCode: %s in netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (300, 'position', 'PER', 'No interestRate in hash for posNum: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (301, 'position', 'PER', 'No inventories found for position num %s. Setting position qty to zero.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (302, 'position', 'PDT', 'No inventories in hash for position num: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (303, 'position', 'PDT', 'No joint ventures found for portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (304, 'portfolio', 'PDT', 'No JV cost found for the portfolio %s. So creating a JV cost.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (305, 'position', 'PDT', 'No options to be exercised in position num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (306, 'portfolio', 'PER', 'No portfolio in hash for portfolio num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (307, 'portfolio', 'PER', 'No portfolioProfitLoss in hash for portfolio num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (308, 'position', 'PER', 'No position in hash for position num: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (309, 'position', 'PER', 'No position MTMs in hash for position num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (310, NULL, 'PER', 'No positions found.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (311, NULL, 'PER', 'No positions in database.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (312, NULL, 'PER', 'No priceComposition found for commktKey: %s for netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (313, NULL, 'PER', 'No product yield for mktCode: %s, commktKey: %s, date: %s for netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (314, NULL, 'PER', 'No quote information found for mktCode: %s, product: %s, date: %s. setting quoteValue to zero for netBackValueInitial calculation', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (315, 'quotePricingPeriod', 'PER', 'No quote prices for (trade/order/item/accum/qpp) (%s/%s/%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (316, 'tradeItem', 'PER', 'No related distributions for (trade/order/item) (%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (317, NULL, 'PER', 'No RP_Differential found for commktKey:%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (318, 'formula', 'PER', 'No simple formula for formula num: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (319, 'tradeItem', 'PER', 'No TI Exch Opt in hash for (trade/order/item) (%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (320, 'tradeItem', 'PER', 'No TI Fut in hash for (trade/order/item) (%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (321, 'tradeItem', 'PER', 'No TI Otc Opt in hash for (trade/order/item) (%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (322, 'position', 'PER', 'No trade item distributions found for position: %s', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (323, 'tradeItem', 'PER', 'No tradeItem for (trade/order/item) (%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (324, NULL, 'PER', 'No trading periods for commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (325, NULL, 'PER', 'No world scale percentage value for worldScaleCode: %s and date: %s in netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (326, NULL, 'PER', 'NON-EXISTANT PORTFOLIO.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (327, 'inventory', 'PDT', 'Not computing, inventory num %s already priced.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (328, 'inventory', 'PDT', 'Not computing, previous inventory num %s already priced.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (329, NULL, 'PDT', 'Open %s P/L = %s * (%s - %s ) %s %s = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (330, NULL, 'PDT', 'Open hedge P/L = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (331, NULL, 'PDT', 'Open P/L: (%s * %s) - (%s * %s - %s * %s) = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (332, NULL, 'PDT', 'Open physical P/L = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (333, NULL, 'PDT', 'Option is exchange traded.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (334, 'position', 'PDT', 'Position %s. Option is not manually exercised. Attempt to expire.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (335, NULL, 'PDT', 'Option is physically settled.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (336, 'tradeItem', 'PDT', 'Option item (%s/%s/%s) exercised.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (337, 'portfolio', 'PDT', 'P/L has already been computed for portfolio %s, so rolling up without computing P/L for children.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (338, 'portfolio', 'PDT', 'P/L has not been calculated for portfolio %s, %s and asOfDate %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (339, 'cost', 'PDT', 'From cost %s, picking up %s %s in closed hedge P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (340, 'cost', 'PDT', 'From cost %s, picking up %s %s in closed primary P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (341, 'cost', 'PDT', 'From cost %s, picking up %s %s in hedge closed P/L, total=%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (342, 'cost', 'PDT', 'From cost %s, picking up %s %s in hedge liquidated P/L, total=%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (343, 'cost', 'PDT', 'From cost %s, picking up %s %s in liquidated hedge P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (344, 'cost', 'PDT', 'From cost %s, picking up %s %s in liquidated primary P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (345, 'cost', 'PDT', 'From cost %s, picking up %s %s in phys closed P/L, total=%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (346, 'cost', 'PDT', 'From cost %s, picking up %s %s in phys liq P/L, total=%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (347, 'cost', 'PDT', 'From cost %s, picking up %s %s in phys liq P/L, total=%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (348, 'inventory', 'PDT', 'From inventory %s (%s) for alloc/item %s/%s, picking up %s %s in closed primary P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (349, 'inventory', 'PDT', 'From inventory %s (%s) for alloc/item %s/%s, picking up %s %s in liquidated primary P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (350, 'cost', 'PDT', 'Picking up amount from cost num %s (%s * %s = %s %s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (351, 'cost', 'PDT', 'Picking up amount for TI cost num %s, value = %s * %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (352, NULL, 'PDT', 'Picking up conversion factor: %s for commktKey %s: from %s/%s to %s/%s. in netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (353, 'inventory', 'PDT', 'Picking up looped draw qty for build (%s-%s/%s) (I-A/AI) (%s * %s = %s %s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (354, 'inventory', 'PDT', 'Picking up qty for build (I-A/AI) (%s-%s/%s) (%s * %s = %s %s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (355, 'cost', 'PDT', 'Picking up qty from PP cost %s (%s * %s = %s %s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (356, NULL, 'PDT', 'Picking up quoteValue: %s, conversionFactor %s and quotePercentage %s. in netBackValueInitial calculation.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (357, 'inventory', 'PDT', 'Picking up realized/unrealized amount for draw (%s-%s/%s) (I-A/AI) (%s / %s %s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (358, 'portfolio', 'PDT', 'Picking up reconciliation amount from sourcePortNum %s, amt (=offsetAmt * convFactor)= %s(=%s * %s) %s; cumulative amt = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (359, 'portfolio', 'PDT', 'Portfolio %s has no children.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (360, 'portfolio', 'PDT', 'Portfolio %s is locked. No prior P/L found. Not computing P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (361, 'portfolio', 'PDT', 'Portfolio %s is locked. Prior P/L found (unfortunately the P/L calc date is not available in my structure).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (362, NULL, 'PDT', 'Portfolio group Snapshot completed for entire hierarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (363, NULL, 'PDT', 'Portfolio group Snapshot failed for entire hierarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (364, NULL, 'PDT', 'Portfolio Snapshot completed for entire hierarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (365, NULL, 'PDT', 'Portfolio Snapshot failed for entire hierarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (366, 'position', 'PDT', 'Position %s is not of Cash OTC or Exchange Option type. No processing is needed.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (367, 'position', 'PDT', 'Position %s. Currency/Uom for market price not found in commktFutureAttr for commkt_key: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (368, 'position', 'PER', 'Position %s. Failed to expire Option.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (369, 'position', 'PDT', 'Position %s. Option already exercised. No need to expire.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (370, 'position', 'PDT', 'Position %s. Option already exercised/expired. No need to expire.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (371, 'position', 'PDT', 'Position %s. Option expired.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (372, 'position', 'PDT', 'Position %s. Option is in the money. Attempt to auto exercise.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (373, 'position', 'PDT', 'Position %s. Option is not in the money. Attempt to expire.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (374, 'position', 'PDT', 'Position %s does not need to be processed on %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (375, 'position', 'PDT', 'Position %s is an Exchange Option position, closed P/L is picked up from the TradeItem directly, so skipping', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (376, 'position', 'PDT', 'Position %s is an equivalent position, skipping ...', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (377, 'position', 'PDT', 'Position %s is an equivalent. Not computing P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (378, 'position', 'PDT', 'Position %s is of type %s. Not computing open P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (379, 'position', 'PDT', 'Position %s is of type %s. Not computing P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (380, 'portfolio', 'PDT', 'Position group %s has no currency code, skipping ...', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (381, NULL, 'PDT', 'Position group SnapShot completed for entire hierarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (382, NULL, 'PER', 'Position group SnapShot failed for entire hierarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (383, 'portfolio', 'PDT', 'Position Portfolio %s, open hedge P/L = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (384, 'portfolio', 'PDT', 'Position portfolio %s, open physical P/L = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (385, 'portfolio', 'PER', 'Position record not found for portfolio: %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (386, NULL, 'PDT', 'Position SnapShot completed for entire hierarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (387, NULL, 'PER', 'Position Snapshot failed for entire hierarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (388, 'position', 'PDT', 'Position %s is an option, updating positionMarkToMarket record only, will not insert.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (389, 'tradeItem', 'PER', 'Premium/uom/currency not found for option trade (trade/order/item) (%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (390, 'cost', 'PDT', 'Price actualizing cost %s for (trade/order/item) (%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (391, NULL, 'PER', 'Price for (cmfNum: %s) %s %s, %s will not be evaluated on asOfDate (%s) - a weekend/holiday for fiscal market. It will get evaluated if some marketPricingConditions were set and marketPriceQuoteDates entries exist.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (392, NULL, 'PER', 'Price for (commkt|tradingPrd|prcieSource) (%s|%s|%s) cannot be evaluated. Cannot calculate price for %s|%s|%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (393, 'inventory', 'PDT', 'Price for inventory num %s is %s %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (394, 'inventory', 'PDT', 'Processing cost num %s (%s)... obtaining children of parent cost %s for processing info.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (395, 'portfolio', 'PDT', 'Processing children of portfolio: %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (396, 'cost', 'PDT', 'Processing cost %s which is a %s cost with %s %s, %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (397, 'tradeItem', 'PDT', 'Processing PR/PO costs for (trade/order/item) (%s/%s/%s) and found %s costs.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (398, NULL, 'PDT', 'P/L amount of the joint venture will be %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (399, 'inventory', 'PER', 'Qty uom code not defined for inventory num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (400, 'inventoryBuildDraw', 'PDT', 'For draw %s (I-A/AI) (%s-%s/%s) realized/unrealized amounts (%s / %s) %s obtained by prorating (%s / %s) over %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (401, 'portfolio', 'PDT', 'Reducing reconciliation amount sent to destination portfolio num %s, amt (=offsetAmt * convFactor)= %s(=%s * %s) %s; cumulative amt= %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (402, 'inventory', 'PDT', 'Rolled values for inventory num %s: Amt (R/U): (%s / %s) %s Qty: %s %s. (@ %s %s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (403, 'inventory', 'PDT', 'Running total for inventory num %s: Amt (R/U): (%s / %s) %s Qty: %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (404, NULL, 'PER', 'Set the accumQpp hash using loadAllAccumQpps before asking for a accumQpp.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (405, NULL, 'PER', 'Set the accumQpp hash using loadAllQuotePrices before asking for a accumQpp.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (406, NULL, 'PER', 'Set the cost relative price hash using loadAllcosts.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (407, NULL, 'PER', 'Set the cost scheduled hash using loadAllCost ScheduledRates.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (408, NULL, 'PER', 'Set the dist hash using loadAllInvs before asking for inventories for a position.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (409, NULL, 'PER', 'Set the dist hash using loadAllTIDs before asking for dists for a position.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (410, NULL, 'PER', 'Set the formulaBody hash by passing a db connection handle before asking for it.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (411, NULL, 'PER', 'Set the generic data access hash using loadAllgeneric data.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (412, NULL, 'PER', 'Set the interestRate hash using loadAllInterestRates before asking for an interestRate.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (413, NULL, 'PER', 'Set the invAllocAI before asking for them for a invList.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (414, NULL, 'PER', 'Set the portfolio group hash using loadAllPortGroupNode before asking for a portGroupNode.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (415, NULL, 'PER', 'Set the position hash using loadAllPositions before asking for a position.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (416, NULL, 'PER', 'Set the TIExchOpt hash using loadAllTIExchOpts before asking for a TI exch Opt.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (417, NULL, 'PER', 'Set the TIFut hash using loadAllTIFuts before asking for a TI Fut.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (418, NULL, 'PER', 'Set the TIFut hash using loadAllTIFuts before asking for a TI Fut.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (419, NULL, 'PER', 'Set the TIOtcOpt hash using loadAllTIOtcOpts before asking for a TI OTC Opt.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (420, NULL, 'PER', 'Set the tradeItem using loadTradeItem before asking for a tradeItem.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (421, NULL, 'PER', 'Set the tradingPeriod hash using loadAllTradingPeriods before asking for a tradingPeriod.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (422, 'inventoryBuildDraw', 'PDT', 'Setting amount for draw (%s,%s) = %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (423, 'inventoryBuildDraw', 'PDT', 'Setting amount for looped build num (%s,%s) (%s * %s * %s) = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (424, NULL, 'PDT', 'Setting avgClosed fiscal price for date %s number of previous prices %s, previous fiscal price: %s. Date for previous fiscal price %s fiscal price commktKey|PriceSource|tradingPrd: %s|%s|%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (425, 'cost', 'PDT', 'Setting costPlCode to CLOSED for cost num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (426, NULL, 'PDT', 'Setting highAsked fiscal price for date %s number of previous prices %s, previous fiscal price: %s. Date for previous fiscal price %s fiscal price commktKey|PriceSource|tradingPrd: %s|%s|%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (427, NULL, 'PDT', 'Setting lowBid fiscal price for date %s number of previous prices %s, previous fiscal price: %s. Date for previous fiscal price %s fiscal price commktKey|PriceSource|tradingPrd: %s|%s|%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (428, NULL, 'PDT', 'Setting total/realized/unrealized amounts %s/%s/%s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (429, 'tradeItem', 'PDT', 'Settlement costs found for tradeItem (%s/%s/%s), not creating... updating cost amt to %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (430, 'position', 'PDT', 'Skipping uom conversion for market price for position %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (431, NULL, 'PDT', 'Snapshot taken with as of date: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (432, 'formula', 'PDT', 'Start evaluation for avg_closed complex formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (433, 'formula', 'PDT', 'Start evaluation for avg_closed simple formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (434, NULL, 'PDT', 'Start evaluation for cmfNum: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (435, 'formula', 'PDT', 'Start evaluation for high_asked complex formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (436, 'formula', 'PDT', 'Start evaluation for high_asked simple formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (437, 'formula', 'PDT', 'Start evaluation for low_bid complex formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (438, 'formula', 'PDT', 'Start evaluation for low_bid simple formula: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (439, 'inventory', 'PDT', 'Start pricing inventory num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (440, 'portfolio', 'PDT', 'Started closed P/L for portfolio group: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (441, NULL, 'PDT', 'Started creating PassSnapShot for Entire Hierarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (442, 'portfolio', 'PDT', 'Started creating PassSnapShot for selected portfolio num: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (443, 'portfolio', 'PDT', 'Started PassPriceTrades for portfolio num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (444, NULL, 'PDT', 'Started pass update underlying equivalents.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (445, 'portfolio', 'PDT', 'Started processing non position portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (446, NULL, 'PDT', 'Started processing PassPL.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (447, NULL, 'PDT', 'Started processing portfolio joint venture.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (448, 'portfolio', 'PDT', 'Started processing position portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (449, NULL, 'PDT', 'Started saving P/L as End of Compensation Year.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (450, NULL, 'PDT', 'Started saving P/L as End of Month.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (451, NULL, 'PDT', 'Started saving P/L as End of Week.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (452, NULL, 'PDT', 'Started saving P/L as End of Year.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (453, NULL, 'PDT', 'Starting avgClosed fiscal pricing for date: %s for commktFormulaNum:tradingPrd -- %s:%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (454, NULL, 'PDT', 'Starting highAsked fiscal pricing for date: %s for commktFormulaNum:tradingPrd -- %s:%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (455, 'formula', 'PDT', 'Starting NBVI calculation for formulaNum: %s commktKey: %s out currCode/uomCode: %s/%s for Date: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (456, 'inventory', 'PDT', 'Starting pricing of inventory num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (457, 'formula', 'PDT', 'Starting Realizable Price Differential calculation for formulaNum: %s commktKey: %s out currCode/uomCode: %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (458, NULL, 'PDT', 'Starting to load all costs at %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (459, 'cost', 'PDT', 'Succesfully created new JV cost: %s portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (460, NULL, 'PDT', 'Succesfully created SnapShot for selected hierarchy.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (461, 'cost', 'PDT', 'Succesfully updated JV cost: %s for portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (462, 'tradeItem', 'PDT', 'Succesfully Updated P/L trade item (trade/order/item) (%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (463, 'portfolio', 'PDT', 'Succesfully updated/inserted market info for portfolio: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (464, 'portfolio', 'PDT', 'Succesfully updated/inserted P/L for portfolio: %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (465, 'inventory', 'PDT', 'Summary of roll from previous inventory num %s to inventory num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (466, 'position', 'PDT', 'Swap position %s does not contribute to open P/L.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (467, 'position', 'PDT', 'The position %s does not need to be processed on %s.', NULL, NULL, NULL, 'I')
go
insert pass_log_defn values (468, 'position', 'PDT', 'Position %s. There are no underlying distributions.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (469, 'cost', 'PDT', 'TI cost num %s is a receivable, should reduce inventory price.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (470, NULL, 'PDT', 'TID has %s P/L = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (471, NULL, 'PDT', 'Time taken for PassPriceInventories: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (472, NULL, 'PDT', 'Time to do entire PassOptionEquiv: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (473, NULL, 'PDT', 'Time to do entire PassPL: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (474, NULL, 'PDT', 'Time to do entire PassPriceTrades: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (475, NULL, 'PER', 'Too many portfolioProfitLoss records in findPortfolioProfitLoss.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (476, NULL, 'PER', 'Too many positions in loadAllPositions.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (477, NULL, 'PDT', 'Total time taken for creating PassSnapShots is: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (478, NULL, 'PDT', 'Total time taken for PassEndPeriod is: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (479, 'tradeItemDist', 'PDT', 'Trade item distribution (%s/%s/%s/%s) has position:%s in realPortfolio %s, but has realPortNum=%s, skipping ...', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (480, NULL, 'PDT', 'Trade price is %s %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (481, 'tradeItemDist', 'PDT', 'Trade item distribution (%s/%s/%s/%s) has open P/L = %s, closed P/L = %s, and additional costs = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (482, 'ictsTransaction', 'PDT', 'Transaction id is: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (483, 'position', 'PDT', 'Unable to decide if option should be auto exercised for position %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (484, NULL, 'PER', 'Unable to perform currency conversion between %s and %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (485, NULL, 'PER', 'Unable to perform currency conversion between %s and %s. Cannot make uom/currency conversion for price for %s, %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (486, NULL, 'PER', 'Unable to perform uom conversion between %s and %s -- No UOM FACTOR. Cannot make uom/currency conversion for price for %s, %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (487, NULL, 'PER', 'Unable to perform uom conversion between %s and %s due to missing commodityMarket. Cannot make uom/currency conversion for price for %s, %s, %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (488, NULL, 'PER', 'Could not find factor for converting UOM %s -> %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (489, NULL, 'PER', 'Could not find factor for converting currency %s -> %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (490, NULL, 'PER', 'Unable to do uom/currency conversion: missing commodityMarket for commktKey:%s between %s and %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (491, 'position', 'PER', 'Underlying value not found for position num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (492, 'cost', 'PER', 'Uom code not defined for cost num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (493, 'inventory', 'PER', 'Uom code not defined for inventory num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (494, NULL, 'PDT', 'UOM conversion factor (%s to %s) = %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (495, 'cost', 'PDT', 'Updated JV cost %s amount = %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (496, NULL, 'PDT', 'Updated inventories.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (497, NULL, 'PDT', 'Updated price commktKey|PriceSource|tradingPrd|quoteDate|oldVal|newVal %s|%s|%s|%s|%s|%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (498, NULL, 'PDT', 'Updating previous contribution to avgClosed fiscal pricing for date: %s for (commktFormulaNum|tradingPrd) -- (%s|%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (499, NULL, 'PDT', 'Updating previous contribution to highAsked fiscal pricing for date: %s for (commktFormulaNum|tradingPrd) -- (%s:%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (500, NULL, 'PDT', 'Updating previous contribution to lowBid fiscal pricing for date: %s for (commktFormulaNum|tradingPrd) -- (%s:%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (501, 'position', 'PDT', 'Updating price for position num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (502, NULL, 'PDT', 'Updating settlement costs for options expiring on %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (503, NULL, 'PDT', 'Used currency factor of %s for converting from %s/%s %s.', NULL, NULL, NULL, 'I')
go
insert pass_log_defn values (504, 'inventory', 'PDT', 'Using beginning balance value from inventory %s to set initial value.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (505, 'position', 'PER', 'Position %s. No long open quantity, no need to exercise.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (506, NULL, 'PDT', 'Will Compute P/L only if neccessary.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (507, NULL, 'PDT', 'You have a yield with zero percentage. Skipping product: %s, in market: %s in currCode/uomCode: %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (508, 'accumulation', 'PDT', 'Begin accumulation (%s/%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (509, 'accumulation', 'PDT', 'Accumulation (%s/%s/%s/%s) is fully priced, not pricing.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (510, 'accumulation', 'PDT', 'Accumulation (%s/%s/%s/%s) has 0 qty. It has no effect on trade price.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (511, NULL, 'PDT', 'Total price for accumulation = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (512, NULL, 'PER', 'Unable to compute total price for accumulation. Possible missing prices.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (513, 'accumulation', 'PDT', 'End accumulation (%s/%s/%s/%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (514, 'tradeItem', 'PER', 'Unable to compute price for trade/order/item %s/%s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (515, NULL, 'PER', 'Open price is null... defaulting to known market price.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (516, NULL, 'PDT', 'Found price %s for (%s/%s/%s) on %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (517, NULL, 'PDT', 'Found price %s for (%s/%s/SPOT) on %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (518, NULL, 'PDT', 'Trading period %s is the SPOT month for %s, so should pick up SPOT price.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (519, NULL, 'PER', 'Could not find price for (%s/%s/%s) on %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (520, NULL, 'PER', 'Could not find price for (%s/%s/%s) on ANY date.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (521, NULL, 'PER', 'Could not find price for (%s/%s/SPOT) on %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (522, NULL, 'PER', 'Could not find price for (%s/%s/SPOT) on ANY date.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (523, NULL, 'PDT', 'Using price (%s/%s/%s) quoted on %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (524, NULL, 'PDT', 'Using price (%s/%s/SPOT) quoted on %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (525, NULL, 'PDT', 'Trying with secondary price source code %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (526, NULL, 'PER', 'Giving up trying to find price (%s/%s/SPOT) for %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (527, NULL, 'PER', 'No default price source code found for commktKey %s. Defaulting to %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (528, NULL, 'PDT', 'Mark-to-market source not defined. Attempting to use default source.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (529, NULL, 'PDT', 'Use default mark-to-market source %s to retrieve market price.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (530, NULL, 'PER', 'No default mark-to-market source available to retrieve market price.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (531, 'position', 'PER', 'Position %s. Currency/Uom for market price not found in commktOptionAttr for commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (532, 'position', 'PER', 'Position %s. Currency/Uom for market price not found in commktPhysicalAttr for commktKey: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (533, 'position', 'PER', 'CommodityMarket/tradingPrd not found for position num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (534, NULL, 'PDT', 'Using price from source %s, trading period %s, quoted on %s as market price.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (535, NULL, 'PER', 'No market price available.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (536, NULL, 'PDT', 'Price source %s is a POSTING source, using trading period SPOT instead of %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (537, NULL, 'PER', 'Cannot update position, as setting NPVFactor failed.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (538, 'position', 'PER', 'There are no TIDs for position num %s, real portfolio num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (539, 'position', 'PER', 'Cannot update inventory position with position num %s due to unchanged or NULL discount quantity.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (540, 'position', 'PER', 'Cannot update TID with distribution num %s due to unchanged or NULL discount quantity.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (541, NULL, 'PER', 'Could not find trading period for commktKey:tradingPrd (%s:%s).', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (542, NULL, 'PDT', 'Closed hedge P/L = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (543, NULL, 'PDT', 'Liquidated physical P/L = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (544, NULL, 'PDT', 'Liquidated hedge P/L = %s %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (545, 'portfolio', 'PER', 'No position in hash for portfolio num: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (546, 'portfolio', 'PER', 'Position record not found for portfolio num: %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (547, NULL, 'PDT', 'Started processing PassPriceCosts.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (548, NULL, 'PDT', 'Completed processing PassPriceCosts.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (549, 'portfolio', 'PDT', 'No costs found for portfolio num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (550, 'cost', 'PDT', 'Started pricing cost for cost num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (551, 'cost', 'PDT', 'Calculating cost amount for cost num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (552, 'cost', 'PER', 'Failed to update cost amount for cost num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (553, 'cost', 'PDT', 'Succesfully updated cost amount for cost num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (554, 'cost', 'PDT', 'Completed pricing cost for cost num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (555, NULL, 'PDT', 'Calculating cost scheduled price as %s volume, with minimum quantity %s from volume scale, and %s minimum USG testing.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (556, 'cost', 'PDT', 'No cost scheduled price records for cost num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (557, NULL, 'PDT', 'Cost conversion factor is %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (558, NULL, 'PDT', 'Cost amount for cost scheduled price is %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (559, NULL, 'PDT', 'Sum of all wpp cost amounts to %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (560, NULL, 'PDT', 'Percentage rate value is %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (561, NULL, 'PDT', 'Cost amount for cost relative price is calculated as (%s * %s) / 100  = %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (562, 'cost', 'PDT', 'No cost relative price records for cost num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (563, NULL, 'PDT', 'Cost amount for cost relative price is %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (564, NULL, 'PDT', 'Total number of flights are %s for given commodity code %s, trading period %s, location code %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (565, NULL, 'PDT', 'Cost Unit Price is %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (566, NULL, 'PDT', 'Cost amount for cost reference price is calculated as (%s * %s) = %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (567, 'tradeItem', 'PDT', 'No principle primary cost records found for trade (trade/order/item) %s/%s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (568, 'tradeItem', 'PDT', 'No principle primary cost records found for tradeNum/orderNum/itemNum %s/%s/%s and cost code %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (569, NULL, 'PER', 'Failed to create Generic Data List.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (570, NULL, 'PER', 'No generic Data Definition entries found for Data Name COST_REFERENCE_PRICE.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (571, NULL, 'PDT', 'Started Pass Price Cash Allocations.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (572, NULL, 'PDT', 'Completed Pass Price Cash Allocations', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (573, 'portfolio', 'PER', 'No netout cost records for portfolio num %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (574, NULL, 'PER', 'Cannot make uom/currency conversion from (commktKey/currCode/uomCode) = %s/%s/%s to (currCode/uomCode) = %s/%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (575, NULL, 'PDT', 'Starting low bid fiscal pricing for date: %s for (commktFormulaNum:tradingPrd) %s:%s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (576, NULL, 'PDT', '%s is a POSTING source, using trading period SPOT instead of %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (577, 'inventory', 'PDT', 'Picking up inv #%s realized value %s, unrealized value %s.', NULL, NULL, NULL, 'A')
go
insert pass_log_defn values (600, NULL, 'PDT', 'Mark as Official Run', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 1000 and
                     msg_type = 'PDT' and
                     log_entity_name = 'position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (1000,'PDT','position','No distributions found for position: %s, setting quantities to zero.','','','','A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 1001 and
                     msg_type = 'PDT' and
                     log_entity_name = 'position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (1001,'PDT','position','Position %s updated.','','','','A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 1002 and
                     msg_type = 'PDT' and
                     log_entity_name = 'position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (1002,'PDT','position','Position %s not updated.','','','','A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 1003 and
                     msg_type = 'PER' and
                     log_entity_name = 'tradeItemDist')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (1003,'PER','tradeItemDist','Failed to get conversion factor from %s to %s for distribution %s.','','','','A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 1004 and
                     msg_type = 'PDT' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (1004,'PDT',NULL,'Position calculated values long_qty = %s, short_qty = %s, priced_qty = %s, sec_long_qty = %s, sec_short_qty = %s, sec_price_qty = %s, avg_purch_price = %s, avg_sale_price = %s.','','','','A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 1005 and
                     msg_type = 'PDT' and
                     log_entity_name = 'portfolio')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (1005,'PDT','portfolio','Started processing portfolio: %s.','','','','A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5000 and
                     msg_type = 'PDT' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5000, 'PDT',	'General', 'Stopping NTPassServer  Time: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5001 and
                     msg_type = 'SER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5001, 'SER',	'General', 'Unable To Log Onto Master Database  Time: %s  Connection String: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5002 and
                     msg_type = 'PDT' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5002, 'PDT',	'General', 'Starting NTPassServer  Version: %s  Time: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5003 and
                     msg_type = 'SER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5003, 'SER',	'General', 'Unable To Set Console Control Handler  Time: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5004 and
                     msg_type = 'SER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5004, 'SER',	'General', 'Unable To Get Computer Name  Time: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5005 and
                     msg_type = 'SER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5005, 'SER',	'General', 'Error Requesting Simple Formula Task  PassServer: %s  PassDatabase: %s  Time: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5006 and
                     msg_type = 'SER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5006, 'SER',	'General', 'Unable To Log Onto Main Database  ICTSServer: %s ICTSDatabase: %s  ICTSUserID: %s  ICTSPassword: %s  Time: %s  Connection String: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5007 and
                     msg_type = 'SER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5007, 'SER',	'General', 'Unable To Reset Hash Tables  ICTSServer: %s  ICTSDatabase: %s  Time: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5008 and
                     msg_type = 'SER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5008, 'SER',	'General', 'Error Requesting Option Task  PassServer: %s  PassDatabase: %s  Time: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5009 and
                     msg_type = 'PER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5009, 'PER',	'General', 'Unable To Find Constants In Database', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5010 and
                     msg_type = 'PER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5010, 'PER',	'General', 'Error Reading Simple Formula Trades', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5011 and
                     msg_type = 'PER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5011, 'PER',	'General', 'Unable To Find Start/End Records For Processing', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5012 and
                     msg_type = 'PER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5012, 'PER',	'General', 'Run Aborted', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5013 and
                     msg_type = 'PDT' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5013, 'PDT',	'TradeItem', 'Processed Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5014 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5014, 'PER',	'TradeItem', 'Unable To Load Transaction ID For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5015 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5015, 'PER',	'TradeItem', 'Error - Inputs For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5016 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5016, 'PER',	'TradeItem', 'Missing Info For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5017 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5017, 'PER',	'TradeItem', 'Unable To Find Alloc Item Alt For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5018 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5018, 'PER',	'TradeItem', 'Unable To Find Event Formula Actual Date Type For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5019 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5019, 'PER',	'TradeItem', 'Unable To Find Formula Information For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5020 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5020, 'PER',	'TradeItem', 'Unable To Find Swap Fixed Price For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5021 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5021, 'PER',	'TradeItem', 'Unable To Check For Gravity Adjustment For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5022 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5022, 'PER',	'TradeItem', 'Unable To Find Accumulation Info For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5023 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5023, 'PER',	'TradeItem', 'Unable To Find Precision For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5024 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5024, 'PER',	'TradeItem', 'Unable To Find Priced Quantity For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5025 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5025, 'PER',	'TradeItem', 'Unable To Find Price Status For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5026 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5026, 'PER',	'TradeItem', 'Unable To Fill QP Price List For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5027 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5027, 'PER',	'TradeItem', 'Unable To Fill Swap Fixed Price For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5028 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5028, 'PER',	'TradeItem', 'Unable To Round Accumulation Value For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5029 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5029, 'PER',	'TradeItem', 'Unable To Update AA Costs For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5030 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5030, 'PER',	'TradeItem', 'Unable To Update AC Costs For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5031 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5031, 'PER',	'TradeItem', 'Unable To Sum AvgPrice Numerator/Denominator For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5032 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5032, 'PER',	'TradeItem', 'Unable To Sum Total Priced Quantity For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5033 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5033, 'PER',	'TradeItem', 'Unable To Find Total Priced Quantity For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5034 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5034, 'PER',	'TradeItem', 'Unable To Set Global Price Status Flags For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5035 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5035, 'PER',	'TradeItem', 'Unable To Update Accumulation Table For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5036 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5036, 'PER',	'TradeItem', 'Unable To Update TID Table For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5037 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5037, 'PER',	'TradeItem', 'Unable To Compute Average Price For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5038 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5038, 'PER',	'TradeItem', 'Unable To Find Global Price Status For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5039 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5039, 'PER',	'TradeItem', 'Unable To Update AI Costs For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5040 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5040, 'PER',	'TradeItem', 'Unable To Update TI Costs For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5041 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5041, 'PER',	'TradeItem', 'Unable To Find Mark-To-Market Profit/Loss For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5042 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5042, 'PER',	'TradeItem', 'Unable To Find Additional Cost For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5043 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5043, 'PER',	'TradeItem', 'Unable To Update TradeItem Table For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go
	
if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5044 and
                     msg_type = 'PER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5044, 'PER',	'General', 'UOM Convert Error - %s/%s->%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5045 and
                     msg_type = 'PER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5045, 'PER',	'General', 'CURR Convert Error - %s->%s on %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5046 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5046, 'PER',	'TradeItem', 'Unable To Find Formula Component Info For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5047 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5047, 'PER',	'TradeItem', 'Unable To Find CURR/UOM Info For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5048 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5048, 'PER',	'TradeItem', 'Unable To Find QPP Info For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5049 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5049, 'PER',	'TradeItem', 'Unable To Find Historical Price For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5050 and
                     msg_type = 'PDT' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5050, 'PDT',	'TradeItem', 'Missing Historical Price For Simple Formula Trade %s/%s/%s Quote: %s/%s/%s/%s - %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5051 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5051, 'PER',	'TradeItem', 'Unable To Find Open Price For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5052 and
                     msg_type = 'PDT' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5052, 'PDT',	'TradeItem', 'Substituted SPOT For Open Price For Simple Formula Trade %s/%s/%s Quote: %s/%s/%s/%s - %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5053 and
                     msg_type = 'PDT' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5053, 'PDT',	'TradeItem', 'Substituted %s For Open Price For Simple Formula Trade %s/%s/%s Quote: %s/%s/%s/%s - %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5054 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5054, 'PER',	'TradeItem', 'Unable To Find Formula Differential For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5055 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5055, 'PER',	'TradeItem', 'Unable To Find Prices For Position For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5056 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5056, 'PER',	'TradeItem', 'Unable To Find QPP Price For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5057 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5057, 'PER',	'TradeItem', 'Unable To Fill QPP Info For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5058 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5058, 'PER',	'TradeItem', 'Unable To Sum Accumulation Priced Qty For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5059 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5059, 'PER',	'TradeItem', 'Unable To Update QPP Table For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5060 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5060, 'PER',	'TradeItem', 'Unable To Find Accumulation Total Price For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5061 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5061, 'PER',	'TradeItem', 'Unable To Find NonQPP Accumulation Total Price For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5062 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5062, 'PER',	'TradeItem', 'Unable To Find Formula Premium For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5063 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5063, 'PER',	'TradeItem', 'Unable To Evaluate Formula For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5064 and
                     msg_type = 'PDT' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5064, 'PDT',	'TradeItem', 'Unable To UpdateCostPLCode - General Error For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5065 and
                     msg_type = 'PDT' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5065, 'PDT',	'TradeItem', 'Unable To Update CostPLCode - Missing Booking Period For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5066 and
                     msg_type = 'PDT' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5066, 'PDT',	'TradeItem', 'Unable To Update CostPLCode - Missing AccumEndDate For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5067 and
                     msg_type = 'PDT' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5067, 'PDT',	'TradeItem', 'Unable To Update CostPLCode - Missing CostBookCompNum For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5068 and
                     msg_type = 'PDT' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5068, 'PDT',	'TradeItem', 'Unable To Update CostPLCode - Missing CostBookPrdDate For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5069 and
                     msg_type = 'PDT' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5069, 'PDT',	'TradeItem', 'Unable To Update CostPLCode - Missing BookingPrdStatus For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5070 and
                     msg_type = 'PER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5070, 'PER',	'General', 'Error Reading Exchange Options', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5071 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5071, 'PER',	'Position', 'Unable To Load Transaction ID For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5072 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5072, 'PER',	'Position', 'Error--Inputs For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5073 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5073, 'PER',	'Position', 'Error--Creating Trade Number String For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5074 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5074, 'PER',	'Position', 'Missing Info For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5075 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5075, 'PER',	'Position', 'Missing Underlying Price For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5076 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5076, 'PDT',	'Position', 'Substituted %s For Underlying Price For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5077 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5077, 'PDT',	'Position', 'Missing Interest Rate - Defaulting To %s Percent For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5078 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5078, 'PER',	'Position', 'Unable To Compute Implied Vol For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5079 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5079, 'PDT',	'Position', 'Beyond Iter Max For Computing Vol - Defaulting To %s Percent For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5080 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5080, 'PDT',	'Position', 'Missing Opt Value - DEFAULTING TO USING VOL CALCULATION For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5081 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5081, 'PDT',	'Position', 'Missing Volatility - Defaulting To %s Percent For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5082 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5082, 'PDT',	'Position', 'Substituted %s For Volatility For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5083 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5083, 'PER',	'Position', 'Unable To Compute Greeks For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5084 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5084, 'PER',	'Position', 'Unable To Update For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5085 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5085, 'PDT',	'Position', 'Processed Exchange Option Position For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5086 and
                     msg_type = 'PER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5086, 'PER',	'General', 'Error Reading OTC Cash Options', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5087 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5087, 'PER',	'Position', 'Missing Start/End Dates For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5088 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5088, 'PER',	'Position', 'Missing Spread Component Information For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5089 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5089, 'PER',	'Position', 'Unable To Find Quantity UOM Convert Rate For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5090 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5090, 'PER',	'Position', 'Missing Relative Quantities For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5091 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5091, 'PDT',	'Position', 'Missing Historical Price For Position %s Quote: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5092 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5092, 'PDT',	'Position', 'Substituted SPOT Price For Underlying Price For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5093 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5093, 'PER',	'Position', 'Missing Lookup Value For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5094 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5094, 'PDT',	'Position', 'Substituted %s For LookupValue For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5095 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5095, 'PDT',	'Position', 'Missing Volatilities - Defaulting To %s Percent For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5096 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5096, 'PDT',	'Position', 'Missing Correlations - Defaulting To %s For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5097 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5097, 'PER',	'Position', 'Unable To Find Blended Volatility For Position %s', NULL, NULL, NULL, 'A')
go	

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5098 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5098, 'PER',	'Position', 'Unable To Compute Value/Greeks For Position %s', NULL, NULL, NULL, 'A')
go
	
if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5099 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5099, 'PER',	'Position', 'Unable To Fill Output For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5100 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5100, 'PER',	'Position', 'Unable To Find Credit Exposure For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5101 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5101, 'PER',	'Position', 'Unable To Update Credit Exposure For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5102 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5102, 'PDT',	'Position', 'Processed OTC Cash Option Position For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5103 and
                     msg_type = 'PER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5103, 'PER',	'General', 'Error Reading OTC Physical Options', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5104 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5104, 'PDT',	'Position', 'Missing Discounting Factor - Defaulting To %s For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5105 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5105, 'PDT',	'Position', 'Processed OTC Physical Option Position For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5106 and
                     msg_type = 'PER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5106, 'PER',	'General', 'Error Reading OTC Swap Options', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5107 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5107, 'PER',	'Position', 'Missing Option Correction Volatility For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5108 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5108, 'PDT',	'Position', 'Processed OTC Swap Option Position For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5109 and
                     msg_type = 'PER' and
                     log_entity_name = 'General')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5109, 'PER',	'General', 'Error Reading Exchange Spread Options', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5110 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5110, 'PER',	'Position', 'Unable To Find Underlying Commodity Info For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5111 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5111, 'PER',	'Position', 'Unable To Find Option Type For Position %s', NULL, NULL, NULL, 'A')
go
	
if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5112 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5112, 'PER',	'Position', 'Missing Underlying Prices For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5113 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5113, 'PDT',	'Position', 'Substituted %s For Underlying Price For %s/%s/%s/%s For Position %s', NULL, NULL, NULL, 'A')
go	

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5114 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5114, 'PER',	'Position', 'Unable To Compute Implied Vols For Position %s', NULL, NULL, NULL, 'A')
go	

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5115 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5115, 'PDT',	'Position', 'Substituted %s For Volatility For %s/%s/%s/%s For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5116 and
                     msg_type = 'PER' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5116, 'PER',	'Position', 'Unable To Compute Value For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5117 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5117, 'PDT',	'Position', 'Processed Exchange Spread Option Position For Position %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5118 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5118, 'PDT',	'Position', 'Substituted %s For Underlying Price For Position %s Quote: %s', NULL, NULL, NULL, 'A')
go

/* added 2/12/2004 */
if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5119 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5119, 'PER', 'TradeItem', 'Unable To Check For Complex Formula For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5120 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
     values(5120, 'PER', 'TradeItem', 'Unable To Update TID Mark To Market For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5121 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
     values(5121, 'PER', 'TradeItem', 'Unable To Find TIDMTM Quantity For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5122 and
                     msg_type = 'PER' and
                     log_entity_name = 'TradeItem')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5122, 'PER', 'TradeItem', 'Unable To Update TID Mark To Market For QPP For Simple Formula Trade %s/%s/%s', NULL, NULL, NULL, 'A')
go

/* For BROKER FIFO */
if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5123 and
                     msg_type = 'PER' and
                     log_entity_name is null)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5123, 'PER', null, 'No brokers setup in pass_control_info for Future FIFO', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5124 and
                     msg_type = 'PER' and
                     log_entity_name is null)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5124, 'PER', null, 'No brokers setup in pass_control_info for Listed Option FIFO', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5125 and
                     msg_type = 'PER' and
                     log_entity_name is null)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5125, 'PER', null, 'Last FIFO Date %s for broker %s is earlier than FIFO date %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5126 and
                     msg_type = 'PER' and
                     log_entity_name is null)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5126, 'PER', null, 'Failure broker FIFO for broker %s on fifo date %s: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5127 and
                     msg_type = 'PER' and
                     log_entity_name is null)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5127, 'PER', null, 'Non existent portfolio for portNum: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5128 and
                     msg_type = 'PER' and
                     log_entity_name = 'task')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5128, 'PER', 'task', 'Cannot begin broker FIFO: invalid task code %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5129 and
                     msg_type = 'PDT' and
                     log_entity_name is null)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5129, 'PDT', null, 'Time taken for BROKER FIFO: %s', NULL, NULL, NULL, 'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5130 and
                     msg_type = 'PDT' and
                     log_entity_name is null)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
    values(5130, 'PDT', null, 'Completed Broker FIFO', NULL, NULL, NULL, 'A')
go


/* FIFO

   8/2/2004  Peter Lo
*/
if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5131 and
                     msg_type = 'PDT' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5131,'PDT',NULL,'Start FIFO %s',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5132 and
                     msg_type = 'PER' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5132,'PER',NULL,'Non-existant portfolio %s',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5133 and
                     msg_type = 'PDT' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5133,'PDT',NULL,'Compeleted FIFO for %s',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5134 and
                     msg_type = 'PDT' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5134,'PDT',NULL,'Total time taken for FIFO is: %s.',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5135 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5135,'PDT','Position','Position %s is an equivalent. Not computing FIFO.',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5136 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5136, 'PDT','Position','Position %s is of type %s. Not creating exchange FIFO allocations.',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5137 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5137, 'PDT','Position','Position %s expires on %s. Not creating exchange FIFO allocations.',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5138 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5138, 'PDT','Position','Position %s last trade date on %s. Fifo delay is %s. Not creating exchange FIFO allocations.',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5139 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5139, 'PDT','Position','Position %s does not have any fills requiring FIFO. Not creating exchange FIFO allocations.',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5140 and
                     msg_type = 'PDT' and
                     log_entity_name = 'Position')
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5140, 'PDT','Position','Position %s has buys %s and sales %s. Not creating exchange FIFO allocations.',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5141 and
                     msg_type = 'PDT' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5141, 'PDT',NULL,'EFP future trade item (%s/%s/%s) not posted. Not using for FIFO',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5142 and
                     msg_type = 'PDT' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5142, 'PDT',NULL,'Future trade item (%s/%s/%s) not past FIFO delay period. Not using for FIFO',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5143 and
                     msg_type = 'PER' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5143, 'PER',NULL,'Failed to get conversion factor from %s to %s for postion %s',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5144 and
                     msg_type = 'PDT' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5144, 'PDT',NULL,'Using conversion factor %s to convert from %s to %s for postion %s',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5145 and
                     msg_type = 'PDT' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5145, 'PDT',NULL,'FIFO qty for buy (Trade/order/item/fill: %s/%s/%s/%s) is %s %s; for sale (%s/%s/%s/%s) is %s %s.',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5146 and
                     msg_type = 'PER' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5146, 'PER',NULL,'Could not get new num for exch_fifo_alloc_num',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5147 and
                     msg_type = 'PER' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5147, 'PER',NULL,'Failed to get conversion factor from %s to %s for postion %s. Using factor=1 to proceed anyway',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5148 and
                     msg_type = 'PDT' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5148, 'PDT',NULL,'Created SQL for exch_fifo_alloc_num %s and its two alloc_items',NULL,NULL,NULL,'A')
go

if not exists (select 1 
               from pass_log_defn
               where pass_log_defn_id = 5149 and
                     msg_type = 'PDT' and
                     log_entity_name IS NULL)
   insert into pass_log_defn (
      pass_log_defn_id, msg_type, log_entity_name, pass_log_msg_text1,
      pass_log_msg_text2, pass_log_msg_text3, pass_log_msg_text4, defn_record_status)
   values (5149, 'PDT',NULL,'For Trade/order/item/fill (%s/%s/%s/%s) last trade date is %s, FIFO delay is %s. So FIFO will first occur on %s.',NULL,NULL,NULL,'A')
go
