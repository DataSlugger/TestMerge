print ' '
print 'Loading reference data into the pass_context_defn table ..'
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 654 and
                     pass_task_code = 'UPDATEPOS' and
                     context_entity_name = 'Task')
   insert into pass_context_defn values (654,'Task','UPDATEPOS')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 655 and
                     pass_task_code = 'UPDATEPOS' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn values (655,'Portfolio','UPDATEPOS')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 656 and
                     pass_task_code = 'UPDATEPOS' and
                     context_entity_name = 'Position')
   insert into pass_context_defn values (656,'Position','UPDATEPOS')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 1000 and
                     pass_task_code = 'CMPLXTRADE' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (1000, 'CMPLXTRADE', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 1001 and
                     pass_task_code = 'CMPLXTRADE' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (1001, 'CMPLXTRADE', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 1002 and
                     pass_task_code = 'CMPLXTRADE' and
                     context_entity_name = 'TradeItem')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (1002, 'CMPLXTRADE', 'TradeItem')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 1003 and
                     pass_task_code = 'CMPLXTRADE' and
                     context_entity_name = 'Accumulation')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (1003, 'CMPLXTRADE', 'Accumulation')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 1004 and
                     pass_task_code = 'CMPLXTRADE' and
                     context_entity_name = 'QuotePricingPeriod')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (1004, 'CMPLXTRADE', 'QuotePricingPeriod')
go
  
if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 1005 and
                     pass_task_code = 'CMPLXTRADE' and
                     context_entity_name = 'FormulaComponent')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (1005, 'CMPLXTRADE', 'FormulaComponent')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 1006 and
                     pass_task_code = 'CMPLXTRADE' and
                     context_entity_name = 'Cost')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (1006, 'CMPLXTRADE', 'Cost')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 2000 and
                     pass_task_code = 'PRICEINV' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (2000, 'PRICEINV', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 2001 and
                     pass_task_code = 'PRICEINV' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (2001, 'PRICEINV', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 2002 and
                     pass_task_code = 'PRICEINV' and
                     context_entity_name = 'Inventory')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (2002, 'PRICEINV', 'Inventory')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 2003 and
                     pass_task_code = 'PRICEINV' and
                     context_entity_name = 'Allocation')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (2003, 'PRICEINV', 'Allocation')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 3000 and
                     pass_task_code = 'PROCESSOPT' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (3000, 'PROCESSOPT', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 3001 and
                     pass_task_code = 'PROCESSOPT' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (3001, 'PROCESSOPT', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 3002 and
                     pass_task_code = 'PROCESSOPT' and
                     context_entity_name = 'Position')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (3002, 'PROCESSOPT', 'Position')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 3100 and
                     pass_task_code = 'EXERLISTEDOPT' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (3100, 'EXERLISTEDOPT', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 3101 and
                     pass_task_code = 'EXERLISTEDOPT' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (3101, 'EXERLISTEDOPT', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 3102 and
                     pass_task_code = 'EXERLISTEDOPT' and
                     context_entity_name = 'Position')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (3102, 'EXERLISTEDOPT', 'Position')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 5001 and
                     pass_task_code = 'SIMPLTRADE' and
                     context_entity_name = 'General')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (5001, 'SIMPLTRADE', 'General')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 5002 and
                     pass_task_code = 'SIMPLTRADE' and
                     context_entity_name = 'TradeItem')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (5002, 'SIMPLTRADE', 'TradeItem')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 5003 and
                     pass_task_code = 'CALCOPTION' and
                     context_entity_name = 'General')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (5003, 'CALCOPTION', 'General')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 5004 and
                     pass_task_code = 'CALCOPTION' and
                     context_entity_name = 'Position')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (5004, 'CALCOPTION', 'Position')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6000 and
                     pass_task_code = 'SNAPSH' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6000, 'SNAPSH', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6001 and
                     pass_task_code = 'SNAPEH' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6001, 'SNAPEH', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6002 and
                     pass_task_code = 'SNAPSH' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6002, 'SNAPSH', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6003 and
                     pass_task_code = 'ENDCOMPYR' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6003, 'ENDCOMPYR', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6004 and
                     pass_task_code = 'ENDCOMPYR' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6004, 'ENDCOMPYR', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6005 and
                     pass_task_code = 'ENDMONTH' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6005, 'ENDMONTH', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6006 and
                     pass_task_code = 'ENDMONTH' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6006, 'ENDMONTH', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6007 and
                     pass_task_code = 'ENDWEEK' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6007, 'ENDWEEK', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6008 and
                     pass_task_code = 'ENDWEEK' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6008, 'ENDWEEK', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6009 and
                     pass_task_code = 'ENDYEAR' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6009, 'ENDYEAR', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6010 and
                     pass_task_code = 'ENDYEAR' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6010, 'ENDYEAR', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6011 and
                     pass_task_code = 'DISCOUNT' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6011, 'DISCOUNT', 'Task')
go 

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6012 and
                     pass_task_code = 'DISCOUNT' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6012, 'DISCOUNT', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6013 and
                     pass_task_code = 'DISCOUNT' and
                     context_entity_name = 'Position')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6013, 'DISCOUNT', 'Position')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6014 and
                     pass_task_code = 'PL' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6014, 'PL', 'Task')
go 

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6015 and
                     pass_task_code = 'PL' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6015, 'PL', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6016 and
                     pass_task_code = 'PL' and
                     context_entity_name = 'Position')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6016, 'PL', 'Position')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6017 and
                     pass_task_code = 'PL' and
                     context_entity_name = 'Cost')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6017, 'PL', 'Cost')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6018 and
                     pass_task_code = 'PL' and
                     context_entity_name = 'Allocation')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6018, 'PL', 'Allocation')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6019 and
                     pass_task_code = 'PL' and
                     context_entity_name = 'InventoryBuildDraw')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6019, 'PL', 'InventoryBuildDraw')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6020 and
                     pass_task_code = 'PL' and
                     context_entity_name = 'TradeItemDist')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6020, 'PL', 'TradeItemDist')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6021 and
                     pass_task_code = 'ROLLPL' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6021, 'ROLLPL', 'Task')
go 

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6022 and
                     pass_task_code = 'ROLLPL' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6022, 'ROLLPL', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6023 and
                     pass_task_code = 'ROLLPL' and
                     context_entity_name = 'Position')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6023, 'ROLLPL', 'Position')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6024 and
                     pass_task_code = 'ROLLPL' and
                     context_entity_name = 'Cost')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6024, 'ROLLPL', 'Cost')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6025 and
                     pass_task_code = 'ROLLPL' and
                     context_entity_name = 'Allocation')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6025, 'ROLLPL', 'Allocation')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6026 and
                     pass_task_code = 'ROLLPL' and
                     context_entity_name = 'InventoryBuildDraw')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6026, 'ROLLPL', 'InventoryBuildDraw')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6027 and
                     pass_task_code = 'ROLLPL' and
                     context_entity_name = 'TradeItemDist')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6027, 'ROLLPL', 'TradeItemDist')
go
  
if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6028 and
                     pass_task_code = 'PRICEADDLCOSTS' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6028, 'PRICEADDLCOSTS', 'Task')
go               

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6029 and
                     pass_task_code = 'PRICEADDLCOSTS' and
                     context_entity_name = 'Cost')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6029, 'PRICEADDLCOSTS', 'Cost')
go 

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6030 and
                     pass_task_code = 'EQUIVQTY' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6030, 'EQUIVQTY', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6031 and
                     pass_task_code = 'EQUIVQTY' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6031, 'EQUIVQTY', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6032 and
                     pass_task_code = 'EQUIVQTY' and
                     context_entity_name = 'Position')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6032, 'EQUIVQTY', 'Position')
go 
 
if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6033 and
                     pass_task_code = 'PRICEMKTS' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6033, 'PRICEMKTS', 'Task')
go 

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6034 and
                     pass_task_code = 'PRICEMKTS' and
                     context_entity_name = 'Formula')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6034, 'PRICEMKTS', 'Formula')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6035 and
                     pass_task_code = 'CASHALLOC' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6035, 'CASHALLOC', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6036 and
                     pass_task_code = 'PASSPLSETUP' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6036, 'PASSPLSETUP', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6037 and
                     pass_task_code = 'PASSPLSETUP' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6037, 'PASSPLSETUP', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6050 and
                     pass_task_code = 'OPL' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6050, 'OPL', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6051 and
                     pass_task_code = 'OPL' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6051, 'OPL', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6060 and
                     pass_task_code = 'XOPTBRKRFIFO' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values(6060, 'XOPTBRKRFIFO', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6061 and
                     pass_task_code = 'XOPTBRKRFIFO' and
                     context_entity_name = 'Account')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6061, 'XOPTBRKRFIFO', 'Account')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6062 and
                     pass_task_code = 'XOPTPORTMATCH' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values(6062, 'XOPTPORTMATCH', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6063 and
                     pass_task_code = 'XOPTPORTMATCH' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6063, 'XOPTPORTMATCH', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6064 and
                     pass_task_code = 'FUTBRKRFIFO' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values(6064, 'FUTBRKRFIFO', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6065 and
                     pass_task_code = 'FUTBRKRFIFO' and
                     context_entity_name = 'Account')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6065, 'FUTBRKRFIFO', 'Account')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6066 and
                     pass_task_code = 'FUTPORTMATCH' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values(6066, 'FUTPORTMATCH', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6067 and
                     pass_task_code = 'FUTPORTMATCH' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6067, 'FUTPORTMATCH', 'Portfolio')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6068 and
                     pass_task_code = 'FIFOLOPT' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6068, 'FIFOLOPT', 'Task')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6069 and
                     pass_task_code = 'FIFOFUT' and
                     context_entity_name = 'Task')
   insert into pass_context_defn (
      pass_context_defn_id, pass_task_code, context_entity_name)
     values (6069, 'FIFOFUT', 'Task')
go

/* FIFO

   8/2/2004   Peter Lo
*/

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6070 and
                     pass_task_code = 'FIFOLOPT' and
                     context_entity_name = 'Position')
   insert into pass_context_defn values (6070, 'Position', 'FIFOLOPT')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6071 and
                     pass_task_code = 'FIFOLOPT' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn values (6071, 'Portfolio', 'FIFOLOPT')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6072 and
                     pass_task_code = 'FIFOFUT' and
                     context_entity_name = 'Position')
   insert into pass_context_defn values (6072, 'Position', 'FIFOFUT')
go

if not exists (select 1 
               from pass_context_defn
               where pass_context_defn_id = 6073 and
                     pass_task_code = 'FIFOFUT' and
                     context_entity_name = 'Portfolio')
   insert into pass_context_defn values (6073, 'Portfolio', 'FIFOFUT')
go

