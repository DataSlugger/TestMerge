print 'Loading system seed data into the new_num table ...'
go


IF NOT EXISTS (select * 
               from new_num
               where num_col_name = 'pass_log_id')
   INSERT INTO dbo.new_num(num_col_name,last_num,owner_table,owner_column)
   VALUES('pass_log_id',0,'pass_log','pass_log_id')
go

IF NOT EXISTS (select * 
               from new_num
               where num_col_name = 'pass_run_id')
   INSERT INTO dbo.new_num(num_col_name,last_num,owner_table,owner_column)
   VALUES('pass_run_id',0,'pass_run','pass_run_id')
go

IF NOT EXISTS (select * 
               from new_num
               where num_col_name = 'pass_run_detail_id')
   INSERT INTO dbo.new_num(num_col_name,last_num,owner_table,owner_column)
   VALUES('pass_run_detail_id',0,'pass_run_detail','pass_run_detail_id')
go

IF NOT EXISTS (select * 
               from new_num
               where num_col_name = 'pass_log_context_id')
   INSERT INTO dbo.new_num(num_col_name,last_num,owner_table,owner_column)
   VALUES('pass_log_context_id',0,'pass_log_context','pass_log_context_id')
go

IF NOT EXISTS (select * 
               from new_num
               where num_col_name = 'pass_context_defn_id')
   INSERT INTO dbo.new_num(num_col_name,last_num,owner_table,owner_column)
   VALUES('pass_context_defn_id',0,'pass_context_defn','pass_context_defn_id')
go

IF NOT EXISTS (select * 
               from new_num
               where num_col_name = 'pass_log_defn_id')
   INSERT INTO dbo.new_num(num_col_name,last_num,owner_table,owner_column)
   VALUES('pass_log_defn_id',0,'pass_log_defn','pass_log_defn_id')
go

IF NOT EXISTS (select * 
               from new_num
               where num_col_name = 'edpl_ntpass_run_detail_oid')
   INSERT INTO dbo.new_num(num_col_name, last_num, owner_table, owner_column)
   VALUES('edpl_ntpass_run_detail_oid', 0, 'edpl_ntpass_run_detail', 'oid')
go
