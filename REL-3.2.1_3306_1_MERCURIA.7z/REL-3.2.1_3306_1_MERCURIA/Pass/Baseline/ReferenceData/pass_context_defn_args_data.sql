set nocount on

print ' '
print 'Loading reference data into the pass_context_defn_args table ..'
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 654 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values (654,1,'task_code','%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 655 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values (655,1,'port_num','%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 656 and
                     entity_key_num = 1 and
                     entity_key_name = 'pos_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values (656,1,'pos_num','%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1000 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1000, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1001 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1001, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1002 and
                     entity_key_num = 1 and
                     entity_key_name = 'trade_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1002, 1, 'trade_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1002 and
                     entity_key_num = 2 and
                     entity_key_name = 'order_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1002, 2, 'order_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1002 and
                     entity_key_num = 3 and
                     entity_key_name = 'item_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1002, 3, 'item_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1003 and
                     entity_key_num = 1 and
                     entity_key_name = 'trade_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1003, 1, 'trade_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1003 and
                     entity_key_num = 2 and
                     entity_key_name = 'order_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1003, 2, 'order_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1003 and
                     entity_key_num = 3 and
                     entity_key_name = 'item_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1003, 3, 'item_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1003 and
                     entity_key_num = 4 and
                     entity_key_name = 'accum_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1003, 4, 'accum_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1004 and
                     entity_key_num = 1 and
                     entity_key_name = 'trade_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1004, 1, 'trade_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1004 and
                     entity_key_num = 2 and
                     entity_key_name = 'order_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1004, 2, 'order_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1004 and
                     entity_key_num = 3 and
                     entity_key_name = 'item_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1004, 3, 'item_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1004 and
                     entity_key_num = 4 and
                     entity_key_name = 'accum_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1004, 4, 'accum_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1004 and
                     entity_key_num = 5 and
                     entity_key_name = 'qpp_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1004, 5, 'qpp_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1005 and
                     entity_key_num = 1 and
                     entity_key_name = 'formula_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1005, 1, 'formula_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1005 and
                     entity_key_num = 2 and
                     entity_key_name = 'formula_body_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1005, 2, 'formula_body_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1005 and
                     entity_key_num = 3 and
                     entity_key_name = 'formula_comp_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1005, 3, 'formula_comp_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 1006 and
                     entity_key_num = 1 and
                     entity_key_name = 'cost_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(1006, 1, 'cost_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 2000 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(2000, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 2001 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(2001, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 2002 and
                     entity_key_num = 1 and
                     entity_key_name = 'inv_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(2002, 1, 'inv_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 2003 and
                     entity_key_num = 1 and
                     entity_key_name = 'alloc_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(2003, 1, 'alloc_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 3000 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(3000, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 3001 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(3001, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 3002 and
                     entity_key_num = 1 and
                     entity_key_name = 'pos_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(3002, 1, 'pos_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 3100 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(3100, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 3101 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(3101, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 3102 and
                     entity_key_num = 1 and
                     entity_key_name = 'pos_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(3102, 1, 'pos_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 5002 and
                     entity_key_num = 1 and
                     entity_key_name = 'trade_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(5002, 1, 'trade_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 5002 and
                     entity_key_num = 2 and
                     entity_key_name = 'order_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(5002, 2, 'order_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 5002 and
                     entity_key_num = 3 and
                     entity_key_name = 'item_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(5002, 3, 'item_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 5004 and
                     entity_key_num = 1 and
                     entity_key_name = 'pos_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(5004, 1, 'pos_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6000 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6000, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6001 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6001, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6002 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6002, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6003 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6003, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6004 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6004, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6005 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6005, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6006 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6006, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6007 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6007, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6008 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6008, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6009 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6009, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6010 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6010, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6011 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6011, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6012 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6012, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6013 and
                     entity_key_num = 1 and
                     entity_key_name = 'pos_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6013, 1, 'pos_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6014 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6014, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6015 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6015, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6016 and
                     entity_key_num = 1 and
                     entity_key_name = 'pos_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6016, 1, 'pos_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6017 and
                     entity_key_num = 1 and
                     entity_key_name = 'cost_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6017, 1, 'cost_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6018 and
                     entity_key_num = 1 and
                     entity_key_name = 'alloc_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6018, 1, 'alloc_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6019 and
                     entity_key_num = 1 and
                     entity_key_name = 'inv_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6019, 1, 'inv_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6019 and
                     entity_key_num = 2 and
                     entity_key_name = 'inv_b_d_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6019, 2, 'inv_b_d_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6020 and
                     entity_key_num = 1 and
                     entity_key_name = 'dist_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6020, 1, 'dist_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6021 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6021, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6022 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6022, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6023 and
                     entity_key_num = 1 and
                     entity_key_name = 'pos_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6023, 1, 'pos_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6024 and
                     entity_key_num = 1 and
                     entity_key_name = 'cost_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6024, 1, 'cost_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6025 and
                     entity_key_num = 1 and
                     entity_key_name = 'alloc_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6025, 1, 'alloc_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6026 and
                     entity_key_num = 1 and
                     entity_key_name = 'inv_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6026, 1, 'inv_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6026 and
                     entity_key_num = 2 and
                     entity_key_name = 'inv_b_d_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6026, 2, 'inv_b_d_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6027 and
                     entity_key_num = 1 and
                     entity_key_name = 'dist_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6027, 1, 'dist_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6028 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6028, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6029 and
                     entity_key_num = 1 and
                     entity_key_name = 'cost_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6029, 1, 'cost_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6030 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6030, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6031 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6031, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6032 and
                     entity_key_num = 1 and
                     entity_key_name = 'pos_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6032, 1, 'pos_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6033 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6033, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6034 and
                     entity_key_num = 1 and
                     entity_key_name = 'formula_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6034, 1, 'formula_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6035 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6035, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6036 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6036, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6037 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6037, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6050 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6050, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6051 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6051, 1, 'port_num', '%d')
go


/* BROKER FIFO */
if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6060 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6060, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6061 and
                     entity_key_num = 1 and
                     entity_key_name = 'acct_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6061, 1, 'acct_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6062 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6062, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6063 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6063, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6064 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6064, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6065 and
                     entity_key_num = 1 and
                     entity_key_name = 'acct_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6065, 1, 'acct_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6066 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6066, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6067 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6067, 1, 'port_num', '%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6068 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6068, 1, 'task_code', '%s')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6069 and
                     entity_key_num = 1 and
                     entity_key_name = 'task_code')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values(6069, 1, 'task_code', '%s')
go



/* FIFO

   8/2/2004   Peter Lo
*/
if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6070 and
                     entity_key_num = 1 and
                     entity_key_name = 'pos_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values (6070,1,'pos_num','%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6071 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values (6071,1,'port_num','%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6072 and
                     entity_key_num = 1 and
                     entity_key_name = 'pos_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values (6072,1,'pos_num','%d')
go

if not exists (select 1 
               from pass_context_defn_args
               where pass_context_defn_id = 6073 and
                     entity_key_num = 1 and
                     entity_key_name = 'port_num')
   insert into pass_context_defn_args (
      pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
    values (6073,1,'port_num','%d')
go
