print 'Granting permissions on Table database_info to pass_admin_group...'
grant select on database_info to pass_admin_group
go
print 'Granting permissions on Table pass_run to pass_admin_group...'
grant select, insert, update, delete on pass_run to pass_admin_group
go                                 
print 'Granting permissions on Table new_num to pass_admin_group...'
grant select, insert, update on new_num to pass_admin_group
go 
print 'Granting permissions on Table pass_context_defn to pass_admin_group...'
grant select, insert, update, delete on pass_context_defn to pass_admin_group
go
print 'Granting permissions on Table pass_context_defn_args to pass_admin_group...'
grant select, insert, update, delete on pass_context_defn_args to pass_admin_group
go
print 'Granting permissions on Table pass_log to pass_admin_group...'
grant select, insert, update, delete on pass_log to pass_admin_group
go
print 'Granting permissions on Table pass_log_arg_values to pass_admin_group...'
grant select, insert, update, delete on pass_log_arg_values to pass_admin_group
go
print 'Granting permissions on Table pass_log_context to pass_admin_group...'
grant select, insert, update, delete on pass_log_context to pass_admin_group
go
print 'Granting permissions on Table pass_log_context_values to pass_admin_group...'
grant select, insert, update, delete on pass_log_context_values to pass_admin_group
go
print 'Granting permissions on Table pass_log_defn to pass_admin_group...'
grant select, insert, update, delete on pass_log_defn to pass_admin_group
go
print 'Granting permissions on Table pass_log_defn_args to pass_admin_group...'
grant select, insert, update, delete on pass_log_defn_args to pass_admin_group
go
print 'Granting permissions on Table pass_task to pass_admin_group...'
grant select, insert, update, delete on pass_task to pass_admin_group
go
print 'Granting permissions on Table pass_run_detail to pass_admin_group...'
grant select, insert, update, delete on pass_run_detail to pass_admin_group
go                                    
print 'Granting permissions on Table pass_priority to pass_admin_group...'
grant select, insert, update, delete on pass_priority to pass_admin_group
go     
print 'Granting permissions on Table edpl_ntpass_run_detail to pass_admin_group...'
grant select, insert, update, delete on edpl_ntpass_run_detail to pass_admin_group
go  

/* -------------------------------------------------------------------- */
print 'Granting permissions on Table database_info to pass_user_group...'
grant select on database_info to pass_user_group
go
print 'Granting permissions on Table pass_run to pass_user_group...'
grant select on pass_run to pass_user_group
go                                 
print 'Granting permissions on Table new_num to pass_user_group...'
grant select on new_num to pass_user_group
go 
print 'Granting permissions on Table pass_context_defn to pass_user_group...'
grant select on pass_context_defn to pass_user_group
go
print 'Granting permissions on Table pass_context_defn_args to pass_user_group...'
grant select on pass_context_defn_args to pass_user_group
go
print 'Granting permissions on Table pass_log to pass_user_group...'
grant select on pass_log to pass_user_group
go
print 'Granting permissions on Table pass_log_arg_values to pass_user_group...'
grant select on pass_log_arg_values to pass_user_group
go
print 'Granting permissions on Table pass_log_context to pass_user_group...'
grant select on pass_log_context to pass_user_group
go
print 'Granting permissions on Table pass_log_context_values to pass_user_group...'
grant select on pass_log_context_values to pass_user_group
go
print 'Granting permissions on Table pass_log_defn to pass_user_group...'
grant select on pass_log_defn to pass_user_group
go
print 'Granting permissions on Table pass_log_defn_args to pass_user_group...'
grant select on pass_log_defn_args to pass_user_group
go
print 'Granting permissions on Table pass_task to pass_user_group...'
grant select on pass_task to pass_user_group
go
print 'Granting permissions on Table pass_run_detail to pass_user_group...'
grant select on pass_run_detail to pass_user_group
go                                    
print 'Granting permissions on Table pass_priority to pass_user_group...'
grant select on pass_priority to pass_user_group
go     
print 'Granting permissions on Table edpl_ntpass_run_detail to pass_user_group...'
grant select on edpl_ntpass_run_detail to pass_user_group
go 

print 'Granting permissions on Table dbupgrade_log to pass_admin_group and pass_user_group...'
grant select on dbupgrade_log to pass_admin_group, pass_user_group
go  
