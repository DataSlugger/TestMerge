print 'Granting permission on procedure get_next_seqnum to pass_admin_group...'
grant execute on get_next_seqnum to pass_admin_group
go
print 'Granting permission on procedure set_last_seqnums to pass_admin_group...'
grant execute on set_last_seqnums to pass_admin_group
go
print 'Granting permission on procedure checkPASS to pass_admin_group...'
grant execute on checkPASS to pass_admin_group
go
print 'Granting permission on procedure find_todo_task to pass_admin_group...'
grant execute on find_todo_task to pass_admin_group
go
print 'Granting permission on procedure get_current_working_strs to pass_admin_group...'
grant execute on get_current_working_strs to pass_admin_group
go
print 'Granting permission on procedure find_todo_task_for_edpl to pass_admin_group...'
grant execute on find_todo_task_for_edpl to pass_admin_group
go

/*
print 'Granting permission on procedure monitor_ICTSPass to pass_admin_group...'
grant execute on monitor_ICTSPass to pass_admin_group
*/
go
print 'Granting permission on procedure usp_ICTSPASS_purge to pass_admin_group...'
grant execute on usp_ICTSPASS_purge to pass_admin_group
go
print 'Granting permission on procedure populate_pass_priority to pass_admin_group...'
grant execute on populate_pass_priority to pass_admin_group
go
print 'Granting permission on procedure usp_activate_pass_task to pass_admin_group...'
grant execute on usp_activate_pass_task to pass_admin_group
go
print 'Granting permission on procedure usp_deactivate_pass_task to pass_admin_group...'
grant execute on usp_deactivate_pass_task to pass_admin_group
go
print 'Granting permission on procedure locate_getime to pass_admin_group...'
grant execute on locate_getime to pass_admin_group
go





