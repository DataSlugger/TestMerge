exec set_last_seqnums
go
