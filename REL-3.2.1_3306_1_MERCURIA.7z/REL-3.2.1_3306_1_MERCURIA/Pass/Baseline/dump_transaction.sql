use master
go

backup log CSTEST_met_pass with truncate_only
go
