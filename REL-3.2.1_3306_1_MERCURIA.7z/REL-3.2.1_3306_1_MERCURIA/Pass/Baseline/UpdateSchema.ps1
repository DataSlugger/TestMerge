# UpdateSchema.ps1
#    This script can be called from POST_PASS_SCHEMA_UPGRADE_PS.ps1 (in Baseline folder) or
#    called from my_upgrade_PS.ps1 (in UpgradeScripts folder)
#
#      Usage:
#         . .\UpdateSchema.ps1 -S <server> 
#                              -AUTH <an authentication mode>
#                              -U <login> 
#                              -P <pwd> 
#                              -D <name of pass database>
#
#      Dependency:
#        It uses the functions stored in
#           CommonDBUpgradeSupportToolSet module
#           PassDBUpgradeSupportToolSet module
#
#     Created By         : Peter Lo   04/28/2016
#     Last Edited By     : Peter Lo   11/14/2016
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
# *****************************************************************************************

Param (
   [string]$S,
   [string]$AUTH,
   [string]$U,
   [string]$P,
   [string]$D
)

$Server=$S
$Authentication=$AUTH
$Login=$U
$Password=$P
$Database=$D

[bool]$DebugOn=$true
[bool]$PauseOn=$false
[bool]$ExitNow=$true

$ScriptRootPath = $pwd.Path   

if ($DebugOn)
{
   Write-Host "DEBUG: Server is '$Server'"
   Write-Host "DEBUG: Login is '$Login'"
   Write-Host "DEBUG: Password is '$Password'"
   Write-Host "DEBUG: Database is '$Database'"
   Write-Host "DEBUG: Script Root Path is '$ScriptRootPath'"
   Write-Host " "
}

CreateLogsSubFolderIfNotExist $ScriptRootPath

# *************************************************************************

#if (ExitOnError) {$ExitNow=$true}

if (!(CreatePassIndexes $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreatePassConstraints $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreatePassProcedures $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreatePassInsTriggers $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreatePassUpdTriggers $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(GrantPassObjectPermissions $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(AddMissingPassSystemRefData $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(RefreshPassLastNums $Server $Authentication $Login $Password $Database $ScriptRootPath "U")) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}


