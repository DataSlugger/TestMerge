# CreateSchema.ps1
#    This script is used by a number of PowerSell scripts to create an ICTS PASS schema
#
#      Usage:
#         . .\CreateSchema.ps1 -S <server> 
#                              -AUTH <an authentication mode>
#                              -U <login> 
#                              -P <pwd> 
#                              -D <name of pass database>
#
#      Dependency:
#        It uses the functions stored in
#           DBUpgradeSupportToolSet module
#
#     Created By         : Peter Lo   04/27/2016
#     Last Edited By     : Peter Lo   04/27/2016
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
# *****************************************************************************************

Param (
   [string]$S,
   [string]$AUTH,
   [string]$U,
   [string]$P,
   [string]$D
)

$Server=$S
$Authentication=$AUTH
$Login=$U
$Password=$P
$Database=$D

[bool]$DebugOn=$false
[bool]$PauseOn=$false
[bool]$ExitNow=$false

$ScriptRootPath = $pwd.Path

if ($Authentication -eq "Windows Authentication")
{
   $ConnStr="Server=$Server;Database=$Database;Integrated Security=True"
}
else
{
   $ConnStr="Server=$Server;Database=$Database;User=$Login;Password=$Password;Integrated Security=False"
}

if ($DebugOn) {Write-Host "DEBUG: Script Root Path = '$ScriptRootPath'"}

CreateLogsSubFolderIfNotExist $ScriptRootPath

# *************************************************************************

$ScriptRootPath = $pwd.Path   

if (ExitOnError) {$ExitNow=$true}

if (!(CreatePassDbUsers $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreatePassTables $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreatePassIndexes $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreatePassProcedures $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(LoadPassSystemRefData $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreatePassConstraints $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreatePassInsTriggers $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(CreatePassUpdTriggers $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}
if (!(GrantPassObjectPermissions $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}

if (!(RefreshPassLastNums $Server $Authentication $Login $Password $Database $ScriptRootPath)) {if ($ExitNow) {exit}}
if ($PauseOn) {Pause}


