use master
go

backup log pass_newdb with truncate_only
go
