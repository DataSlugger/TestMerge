
' This script splits the PassPLSetup task into subtasks on the real portfolio level, to take
' advantage of multi-tasking.


update pass_task
set task_split_ind = 'Y' 
where pass_task_code = 'PASSPLSETUP'
go

