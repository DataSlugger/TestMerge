use master
go

backup database UNITTESTFR9_tc_pass to mydbdump
go
