use master
go

backup database pass_newdb to DISK='e:\temp'
go

