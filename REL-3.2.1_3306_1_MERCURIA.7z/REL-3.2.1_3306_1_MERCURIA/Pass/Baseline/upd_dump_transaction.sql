use master
go

dump transaction NY_01_pass with truncate_only
go
