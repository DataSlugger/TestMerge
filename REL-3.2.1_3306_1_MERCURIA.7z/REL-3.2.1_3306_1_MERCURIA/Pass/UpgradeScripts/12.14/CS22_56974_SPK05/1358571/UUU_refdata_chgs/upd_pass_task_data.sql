set nocount on

print ''
print 'Updating pass task code name ''SAPCASHINBOUND'' to ''COSTUPLOAD'' IF NOT EXISTS'
print ''

if exists ( select 1 from dbo.pass_task where pass_task_code = 'COSTUPLOAD' )
begin
     print '=> pass task code ''COSTUPLOAD'' is already exists in pass_task table '
     goto endofscript
end

declare @rows_affected	int

select @rows_affected = 0

begin tran
begin try
    update dbo.pass_task
    set pass_task_code = 'COSTUPLOAD',
        pass_task_desc = 'Upload Costs',
	pass_task_status = 'A'
    where pass_task_code = 'SAPCASHINBOUND'
    select @rows_affected = @@rowcount
end try
begin catch
    if @@trancount > 0
        rollback tran
    print 'Failed to update pass_task_code due to below error '
    print ERROR_MESSAGE()
    goto endofscript
end catch
commit tran
if @rows_affected > 0
    print '=> ' + convert(varchar, @rows_affected) + ' Rows updated in pass_task table successfully !'
endofscript:
go