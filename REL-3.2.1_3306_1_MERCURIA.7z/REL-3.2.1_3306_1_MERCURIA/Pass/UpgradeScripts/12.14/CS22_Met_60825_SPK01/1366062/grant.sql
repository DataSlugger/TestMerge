print ' '
print 'Granting object permissions ...'
go

/* main tables */
grant select, insert, update, delete on dbo.edpl_ntpass_run_detail to pass_user_group
go
grant select, insert, update, delete on dbo.edpl_ntpass_run_detail to pass_admin_group
go
