print ' '
print 'Adding a new_num entry to support the edpl_ntpass_run_detail table ...'
go

if NOT EXISTS (select 1
               from dbo.new_num
               where num_col_name = 'edpl_ntpass_run_detail_oid')
   insert into dbo.new_num (num_col_name,  last_num, owner_table, owner_column) 
      values ('edpl_ntpass_run_detail_oid',  0, 'edpl_ntpass_run_detail', 'oid')
go
