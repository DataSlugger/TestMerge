# dbupgrade_56974_PS.ps1
#    This script is used to perform changes to the ICTS pass schema in the selected database for
#    the build #56974
#
#      Usage:
#         PowerShell .\dbupgrade_56974_PS.ps1 -S <server> 
#                                             -AUTH <"SQL Server Authentication" or "Windows Authentication">
#                                             -U <login> 
#                                             -P <pwd> 
#                                             -D <name of pass database>
#                                             -Log <name of log file including its full path>
#
#      Dependency:
#        It uses the functions stored in
#           CommonDBUpgradeSupportToolSet module
#           PassDBUpgradeSupportToolSet module
#
#     Created By         : Peter Lo   05/24/2016
#     Last Edited By     : Peter Lo   05/24/2016
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
# *****************************************************************************************

Param (
  [Parameter(Mandatory=$true,HelpMessage="You must provide a server instance name")]
     [string]$S,
  [string]$AUTH,
  [string]$U,
  [string]$P,
  [Parameter(Mandatory=$true,HelpMessage="You must provide the name of a pass database")]
     [string]$D,
  [Parameter(Mandatory=$true)]
     [string]$Log
)


$Server=$S
$Authentication=$AUTH
$Login=$U
$Password=$P
$Database=$D
$LogFileName56974=$Log

$DebugOn=$false
$ScriptRootPath56974 = $pwd.Path

if ($DebugOn)
{
   Write-Host "DEBUG (v12.14 - 56974): Server is '$Server'"
   Write-Host "DEBUG (v12.14 - 56974): Login is '$Login'"
   Write-Host "DEBUG (v12.14 - 56974): Password is '$Password'"
   Write-Host "DEBUG (v12.14 - 56974): Database is '$Database'"
   Write-Host "DEBUG (v12.14 - 56974): ScriptRootPath is '$ScriptRootPath56974'"
   Write-Host " "
}

# ********************************************************************************
# ********************************************************************************
ShowAndSaveProgress -LogFileName $LogFileName56974 -Message "=> Upgrading ICTS pass database with 56974_SPK05"
Set-Location "$ScriptRootPath56974\CS22_56974_SPK05\1358571"
. .\dbupgrade_PASS_PS $Server $Authentication $Login $Password $Database $LogFileName56974 
# ********************************************************************************
ShowAndSaveProgress -LogFileName $LogFileName56974 -Message "=> DB Changes for build #56974 were applied"
#
Set-Location $ScriptRootPath56974

