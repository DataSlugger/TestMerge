# dbupgrade_60825_PS.ps1
#    This script is used to perform changes to the ICTS pass schema in the selected database for
#    the build #60825
#
#      Usage:
#         PowerShell .\dbupgrade_60825_PS.ps1 -S <server> 
#                                             -AUTH <"SQL Server Authentication" or "Windows Authentication">
#                                             -U <login> 
#                                             -P <pwd> 
#                                             -D <name of pass database>
#                                             -Log <name of log file including its full path>
#
#      Dependency:
#        It uses the functions stored in
#           CommonDBUpgradeSupportToolSet module
#           PassDBUpgradeSupportToolSet module
#
#     Created By         : Peter Lo   05/24/2016
#     Last Edited By     : Peter Lo   05/24/2016
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
# *****************************************************************************************

Param (
  [Parameter(Mandatory=$true,HelpMessage="You must provide a server instance name")]
     [string]$S,
  [string]$AUTH,
  [string]$U,
  [string]$P,
  [Parameter(Mandatory=$true,HelpMessage="You must provide the name of a pass database")]
     [string]$D,
  [Parameter(Mandatory=$true)]
     [string]$Log
)


$Server=$S
$Authentication=$AUTH
$Login=$U
$Password=$P
$Database=$D
$LogFileName60825=$Log

$DebugOn=$false
$ScriptRootPath60825 = $pwd.Path

if ($DebugOn)
{
   Write-Host "DEBUG (v12.14 - 60825): Server is '$Server'"
   Write-Host "DEBUG (v12.14 - 60825): Login is '$Login'"
   Write-Host "DEBUG (v12.14 - 60825): Password is '$Password'"
   Write-Host "DEBUG (v12.14 - 60825): Database is '$Database'"
   Write-Host "DEBUG (v12.14 - 60825): ScriptRootPath is '$ScriptRootPath60825'"
   Write-Host " "
}

# ********************************************************************************
# ********************************************************************************
ShowAndSaveProgress -LogFileName $LogFileName60825 -Message "=> Upgrading ICTS pass database with 60825_SPK01"
Set-Location "$ScriptRootPath60825\CS22_Met_60825_SPK01\1366062"
. .\dbupgrade_PASS_PS $Server $Authentication $Login $Password $Database $LogFileName60825 
# ********************************************************************************
ShowAndSaveProgress -LogFileName $LogFileName60825 -Message "=> DB Changes for build #60825 were applied"
#
Set-Location $ScriptRootPath60825

