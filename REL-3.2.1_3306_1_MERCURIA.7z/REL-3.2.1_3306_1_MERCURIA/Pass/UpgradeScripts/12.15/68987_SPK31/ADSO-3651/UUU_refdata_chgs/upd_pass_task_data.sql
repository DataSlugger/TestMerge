set nocount on

print ''
print 'Enabling task split indicator of ''SNAPSH'' pass task in pass_task table ...'
print ''

if exists (select 1 
           from dbo.pass_task 
           where pass_task_code = 'SNAPSH' and 
                 task_split_ind = 'Y')
begin
   print '=> pass task split indicator of ''SNAPSH'' is already enabled in pass_task table '
   goto endofscript
end

declare @rows_affected	int

select @rows_affected = 0

begin tran
begin try
    update dbo.pass_task
    set task_split_ind='Y'
    where pass_task_code = 'SNAPSH'
    select @rows_affected = @@rowcount
end try
begin catch
    if @@trancount > 0
        rollback tran
    print 'Failed to update pass_task entries due to below error '
    print ERROR_MESSAGE()
    goto endofscript
end catch
commit tran
if @rows_affected > 0
    print '=> ' + convert(varchar, @rows_affected) + ' rows were updated in pass_task table successfully !'
endofscript:
go