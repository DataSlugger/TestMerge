# dbupgrade_68987_PS.ps1
#    This script is used to perform changes to the ICTS pass schema in the selected database for
#    the build #68987
#
#      Usage:
#         PowerShell .\dbupgrade_68987_PS.ps1 -S <server> 
#                                             -AUTH <"SQL Server Authentication" or "Windows Authentication">
#                                             -U <login> 
#                                             -P <pwd> 
#                                             -D <name of pass database>
#                                             -Log <name of log file including its full path>
#
#      Dependency:
#        It uses the functions stored in
#           CommonDBUpgradeSupportToolSet module
#           PassDBUpgradeSupportToolSet module
#
#     Created By         : Peter Lo   04/28/2016
#     Last Edited By     : Peter Lo   04/28/2016
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
# *****************************************************************************************

Param (
  [Parameter(Mandatory=$true,HelpMessage="You must provide a server instance name")]
     [string]$S,
  [string]$AUTH,
  [string]$U,
  [string]$P,
  [Parameter(Mandatory=$true,HelpMessage="You must provide the name of a pass database")]
     [string]$D,
  [Parameter(Mandatory=$true)]
     [string]$Log
)


$Server=$S
$Authentication=$AUTH
$Login=$U
$Password=$P
$Database=$D
$LogFileName68987=$Log

$DebugOn=$false
$ScriptRootPath68987 = $pwd.Path

if ($DebugOn)
{
   Write-Host "DEBUG (v12.15 - 68987): Server is '$Server'"
   Write-Host "DEBUG (v12.15 - 68987): Login is '$Login'"
   Write-Host "DEBUG (v12.15 - 68987): Password is '$Password'"
   Write-Host "DEBUG (v12.15 - 68987): Database is '$Database'"
   Write-Host "DEBUG (v12.15 - 68987): ScriptRootPath is '$ScriptRootPath68987'"
   Write-Host " "
}

# ********************************************************************************
# ********************************************************************************
ShowAndSaveProgress -LogFileName $LogFileName68987 -Message "=> Upgrading ICTS pass database with 68987_SPK31"
Set-Location "$ScriptRootPath68987\68987_SPK31\ADSO-3651"
. .\dbupgrade_PASS_PS $Server $Authentication $Login $Password $Database $LogFileName68987 
# ********************************************************************************
ShowAndSaveProgress -LogFileName $LogFileName68987 -Message "=> DB Changes for build #68987 were applied"
#
Set-Location $ScriptRootPath68987

