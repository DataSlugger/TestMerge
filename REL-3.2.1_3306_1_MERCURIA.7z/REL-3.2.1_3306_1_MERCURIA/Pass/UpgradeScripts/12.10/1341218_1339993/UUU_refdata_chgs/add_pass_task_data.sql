set nocount on

print ''
print 'Adding the followig pass tasks codes before the ''PRICEMKTS'' task if NOT EXIST ...'
print '  SAPCASHINBOUND, SAPACTUALSINBOUND,SAPACTUALSINGOODSREC, SAPACTUALSINTRUCKS, SAPVOUCHERSINBOUND'
go


if exists (select 1
           from dbo.pass_task
           where pass_task_code in ('SAPCASHINBOUND', 
                                    'SAPACTUALSINBOUND',
                                    'SAPACTUALSINGOODSREC', 
                                    'SAPACTUALSINTRUCKS', 
                                    'SAPVOUCHERSINBOUND'))
   goto endofscript
   
 
declare @PRICEMKTS_pass_exec_order      smallint,
        @rows_affected                  int
        
set @rows_affected = 0

select @PRICEMKTS_pass_exec_order = pass_exec_order
from dbo.pass_task
where pass_task_code = 'PRICEMKTS'

if @PRICEMKTS_pass_exec_order is null
begin
   print '=> Could not find the pass task ''PRICEMKTS''!'
   goto endofscript
end

begin try
  update dbo.pass_task
  set pass_exec_order = pass_exec_order + 5
  where pass_exec_order >= @PRICEMKTS_pass_exec_order and
        pass_exec_order < 500
end try
begin catch
  print '=> Failed to change the pass_exec_order value for the pass task ''PRICEMKTS'' and tasks after due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch

begin try
  insert into dbo.pass_task
       (pass_task_code, pass_task_desc, pass_exec_order, task_split_ind,
        pass_task_status, pass_executor_id, exec_port_type)
   select 'SAPVOUCHERSINBOUND', 'Receive Invoices from SAP', @PRICEMKTS_pass_exec_order, 'N', 'I', 0, null  
   union all
   select 'SAPCASHINBOUND', 'Receive Cash Payments From SAP', @PRICEMKTS_pass_exec_order + 1, 'N', 'I', 0, null
   union all
   select 'SAPACTUALSINBOUND', 'Receive Refinery Sales Actuals from SAP', @PRICEMKTS_pass_exec_order + 2, 'N', 'I', 0, null
   union all
   select 'SAPACTUALSINGOODSREC', 'Receive Refinery Goods Receipts from SAP', @PRICEMKTS_pass_exec_order + 3, 'N', 'I', 0, null
   union all
   select 'SAPACTUALSINTRUCKS', 'Receive Aggregated Truck Actuals from SAP', @PRICEMKTS_pass_exec_order + 4, 'N', 'I', 0, null
  set @rows_affected = @@rowcount
end try
begin catch
  print '=> Failed to add new tasks before the ''PRICEMKTS'' task due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch
print ' '
if @rows_affected > 0
   print '=> There are ' + cast(@rows_affected as varchar) + ' pass_task records added before the ''PRICEMKTS'' task!'
else
   print '=> No pass_task records were added before the ''PRICEMKTS'' task!'

endofscript:
go



/* ******************************************************************************* */
print ''
print 'Adding the followig pass tasks codes after the ''NOISEBANDDATA'' task if NOT EXIST ...'
print '  SAPVOUCHERSOUTBOUND, SAPDEALSUSERUPOUT, SAPACTUALSOUTBOUND, SAPDEALPRICEUPDATOUT, SAPDAILYRECONSIL'
print ''
go

if exists (select 1
           from dbo.pass_task
           where pass_task_code in ('SAPVOUCHERSOUTBOUND', 
                                    'SAPDEALSUSERUPOUT', 
                                    'SAPACTUALSOUTBOUND', 
                                    'SAPDEALPRICEUPDATOUT', 
                                    'SAPDAILYRECONSIL'))
   goto endofscript
   
declare @NOISEBANDDATA_pass_exec_order  smallint,
        @rows_affected                  int
        
set @rows_affected = 0

select @NOISEBANDDATA_pass_exec_order = pass_exec_order
from dbo.pass_task
where pass_task_code = 'NOISEBANDDATA'

if @NOISEBANDDATA_pass_exec_order is null
begin
   print '=> Could not find the pass task ''NOISEBANDDATA''!'
   goto endofscript
end

begin try
  update dbo.pass_task
  set pass_exec_order = pass_exec_order + 5
  where pass_exec_order > @NOISEBANDDATA_pass_exec_order and
        pass_exec_order < 500
end try
begin catch
  print '=> Failed to change the pass_exec_order value for the tasks after the ''NOISEBANDDATA'' task due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch

begin try
  insert into dbo.pass_task
      (pass_task_code, pass_task_desc, pass_exec_order, task_split_ind,
       pass_task_status, pass_executor_id, exec_port_type)
   select 'SAPVOUCHERSOUTBOUND', 'Send Vouchers to SAP', @NOISEBANDDATA_pass_exec_order + 1, 'N', 'A', 0, null
   union all
   select 'SAPDEALSUSERUPOUT', 'Send Physical Trades including updates to SAP', @NOISEBANDDATA_pass_exec_order + 2, 'N', 'A', 0, null
   union all
   select 'SAPACTUALSOUTBOUND', 'Send B/L actuals to SAP', @NOISEBANDDATA_pass_exec_order + 3, 'N', 'A', 0, null
   union all
   select 'SAPDEALPRICEUPDATOUT', 'Send Costs with EOD Price to SAP', @NOISEBANDDATA_pass_exec_order + 4, 'N', 'A', 0, null
   union all
   select 'SAPDAILYRECONSIL', 'Send SAP reconciliation files to Control Panel', @NOISEBANDDATA_pass_exec_order + 5, 'N', 'A', 0, null
   set @rows_affected = @@rowcount
end try
begin catch
  print '=> Failed to add new tasks after the ''NOISEBANDDATA'' task due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch
print ' '
if @rows_affected > 0
   print '=> There are ' + cast(@rows_affected as varchar) + ' pass_task records added after the ''NOISEBANDDATA'' task!'
else
   print '=> No pass_task records were added after the ''NOISEBANDDATA'' task!'

endofscript:
go


