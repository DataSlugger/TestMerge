# dbupgrade_PS.ps1
#    This script is used to perform changes to the ICTS pass schema in the selected database for
#    the version 12.10
#
#      Usage:
#         PowerShell .\dbupgrade_PS.ps1 -S <server> 
#                                       -U <login> 
#                                       -P <pwd> 
#                                       -D <name of pass database>
#                                       -Log <name of log file including its full path>
#
#      Dependency:
#        It uses the functions stored in
#           CommonDBUpgradeSupportToolSet module
#           PassDBUpgradeSupportToolSet module
#
#     Created By         : Peter Lo   05/25/2016
#     Last Edited By     : Peter Lo   05/25/2016
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
# *****************************************************************************************

Param (
  [Parameter(Mandatory=$true,HelpMessage="You must provide a server instance name")]
     [string]$S,
  [string]$AUTH,
  [string]$U,
  [string]$P,
  [Parameter(Mandatory=$true,HelpMessage="You must provide the name of a pass database")]
     [string]$D,
  [Parameter(Mandatory=$true)]
     [string]$Log
)

$ScriptRootPath1210 = $pwd.Path

$Server=$S
$Authentication=$AUTH
$Login=$U
$Password=$P
$Database=$D
$LogFileName1210=$Log

$DebugOn=$false

if ($DebugOn)
{
   Write-Host "DEBUG (v12.10): Server is '$Server'"
   Write-Host "DEBUG (v12.10): Login is '$Login'"
   Write-Host "DEBUG (v12.10): Password is '$Password'"
   Write-Host "DEBUG (v12.10): Database is '$Database'"
   Write-Host " "
}

ShowAndSaveProgress -LogFileName $LogFileName1210 -Message " "
ShowAndSaveProgress -LogFileName $LogFileName1210 -Message "Applying db changes for version 12.10 to the ICTS pass database ..."
ShowAndSaveProgress -LogFileName $LogFileName1210 -Message "*******************************************************************************************"
ShowAndSaveProgress -LogFileName $LogFileName1210 -Message "=> Upgrading (1341218_1339993) ..."
Set-Location "$ScriptRootPath1210\1341218_1339993"
. .\dbupgrade_PASS_PS $Server $Authentication $Login $Password $Database $LogFileName1210 
#
ShowAndSaveProgress -LogFileName $LogFileName1210 -Message "=> Upgrading (1345128) ..."
Set-Location "$ScriptRootPath1210\1345128"
. .\dbupgrade_PASS_PS $Server $Authentication $Login $Password $Database $LogFileName1210 
Set-Location $ScriptRootPath1210
#
ShowAndSaveProgress -LogFileName $LogFileName1210 -Message "*******************************************************************************************"
ShowAndSaveProgress -LogFileName $LogFileName1210 -Message "=> Updating db version ..."
if (!(ExecDBScript $Server $Authentication $Login $Password $Database "$ScriptRootPath1210" "dbversion.sql" "@@@")) 
{
   ShowAndSaveProgress -LogFileName $LogFileName1210 -Message "=> Failed to update version info stored in the database_info table"
   ShowAndSaveProgress -LogFileName $LogFileName1210 -Message " "
   exit
}

ShowAndSaveProgress -LogFileName $LogFileName1210 -Message "DB changes covered in v12.10 were applied"
ShowAndSaveProgress -LogFileName $LogFileName1210 -Message " "

