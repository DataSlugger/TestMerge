# Usage:
# PowerShell .\dbupgrade_PASS_PS.ps1 -Server <Server Instance> 
#                                    -Auth {"SQL Server Authentication" or "Windows Authentication"}
#                                    -Login <login>
#                                    -Password <pwd>
#                                    -Database <name of pass db> 
#                                    -LogFileName <name of log file including its full path>
#
#   NOTE: You need to enclose space-embedded argument value with a {}
#
#   Created By        : Peter Lo  05/25/2016
#   Last Edited By    : Peter Lo  05/25/2016
#   Database          : SQL Server 2008R2 or later
#   PowerShell Version: 3.0 or later
#   Company           : Amphora, Inc
# *******************************************************************************
param(
   [parameter(Mandatory=$true)]  [string]$Server, 
   [parameter(Mandatory=$true)]  [string]$Auth,
   [parameter(Mandatory=$false)] [string]$Login, 
   [parameter(Mandatory=$false)] [string]$Password, 
   [parameter(Mandatory=$true)]  [string]$Database,
   [parameter(Mandatory=$false)] [string]$LogFileName = "@@@" 
)

Import-Module CommonDBUpgradeSupportToolSet
Import-Module PassDBUpgradeSupportToolSet

   $Issue="1345128"   
   $ScriptSet = @()
   #                Folder(0)                    Script/BCP file(1)                          TableName(2)                ColumnName(3)           Option(4)       Instruction(5)
   #                ---------------------------  ------------------------------------------  --------------------------  ----------------------  --------------  -----------------------------------
   $ScriptSet +=(, ("UUU_refdata_chgs",          "add_pass_context_defn_and_args_data.sql",  "@@@",                      "@@@",                  "@@@",          "NOCHECK"))

   write-host "=> Applying db changes for issue #$Issue ..."
   $ScriptRootPath = $pwd.Path
   Set-Location $ScriptRootPath

   $dt = ShowCurrentTime -heading "STARTED "
   if ($LogFileName -eq "@@@")
   {
      CreateLogsSubFolderIfNotExist
      $MyLogFileName = "$ScriptRootPath\Logs\$Issue.log"
      Write-Output "STARTED : $dt" | out-file $MyLogFileName
   }
   else
   {  
      $MyLogFileName = $LogFileName
      Write-Output "STARTED : $dt" | out-file $MyLogFileName -append
   }
   
   if ($Auth -eq "Windows Authentication") {$ConnStr="Server=$Server;Database=$Database;Integrated Security=True"}
   else {$ConnStr="Server=$Server;Database=$Database;User=$Login;Password=$Password;Integrated Security=False"}
   
   foreach ($Script in $ScriptSet)
   {
      $ScriptFilePath = $Script[0]
      $ScriptFileName = $Script[1]
      $TableName = $Script[2]
      $ColumnName = $Script[3]
      $BcpSwitches = $Script[3]   
      $ConstraintOption = $Script[4]         
      $DesiredDataType = $Script[4]
      $CheckInstruction = $Script[5]

      if ($ScriptFilePath -eq "@@@") {break}

      if ($ScriptFilePath -eq ".") {$ScriptFullFilePath="$ScriptRootPath"}
      else {$ScriptFullFilePath="$ScriptRootPath\$ScriptFilePath"}
      
      if ($CheckInstruction -ne "BCPIN") 
      {
         $temp = ""
         if ($CheckInstruction -ne "NOCHECK") {$temp = "if needed"}
         Write-Output "=> Executing the script '$ScriptFileName' $temp ..." | out-file $MyLogFileName -append
      }
      
      # *********************************************************************************************************
      if ($CheckInstruction -eq "NOCHECK")
      {     
         if (!(ExecDBScript $Server $Auth $Login $Password $Database $ScriptFullFilePath $ScriptFileName $MyLogFileName)) {break}
      }      
   } #foreach
   
   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED : $dt" | out-file $MyLogFileName -append

