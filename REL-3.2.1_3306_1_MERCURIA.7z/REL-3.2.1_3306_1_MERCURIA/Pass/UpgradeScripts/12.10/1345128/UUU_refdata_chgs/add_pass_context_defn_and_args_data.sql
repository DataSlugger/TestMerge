set nocount on

print ''
print 'Adding pass_context_defn records and associated args for the ''FORMULATRADE'' task if NOT EXIST ... '
print ''
go

declare @rows_affected               int,
        @last_pass_context_defn_id   int

create table #pcd_1345128_CMPLXTRADE
(
   oid                    int IDENTITY PRIMARY KEY,
   pass_context_defn_id	  int	NOT NULL,
   context_entity_name	  varchar(60) NOT NULL
)

if not exists (select 1
               from dbo.pass_task
               where pass_task_code = 'FORMULATRADE')
begin
   print '=> the ''FORMULATRADE'' task does not exist in the pass_task table!'
   goto endofscript
end
              
if exists (select 1
           from dbo.pass_context_defn
           where pass_task_code = 'FORMULATRADE')
begin
   print '=> There are pass_context_defn records setup for the ''FORMULATRADE'' task already!'
   goto endofscript
end

begin try
  insert into #pcd_1345128_CMPLXTRADE
       (pass_context_defn_id, context_entity_name)
  select pass_context_defn_id, context_entity_name
  from dbo.pass_context_defn
  where pass_task_code = 'CMPLXTRADE' 
  set @rows_affected = @@rowcount
end try
begin catch
  print '=> Failed to copy pass_context_defn records owned by the ''CMPLXTRADE'' task to temp table due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch
if @rows_affected = 0
begin
   print '=> No pass_context_defn records found for the ''CMPLXTRADE'' task.  Therefore,'
   print '=> no pass_context_defn records were added for the ''FORMULATRADE'' task!'
   goto endofscript
end
  
select @last_pass_context_defn_id = max(pass_context_defn_id)
from dbo.pass_context_defn

if @last_pass_context_defn_id is null
   set @last_pass_context_defn_id = 0

begin tran
begin try
  insert into dbo.pass_context_defn
      (pass_context_defn_id, context_entity_name, pass_task_code)
  select @last_pass_context_defn_id + oid,
         context_entity_name,
         'FORMULATRADE'
  from #pcd_1345128_CMPLXTRADE
  set @rows_affected = @@rowcount
end try
begin catch
  if @@trancount > 0
     rollback tran
  print '=> Failed to add pass_context_defn records for the ''FORMULATRADE'' task due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch
if @rows_affected > 0
   print '=> ' + cast(@rows_affected as varchar) + ' pass_context_defn records were added for the ''FORMULATRADE'' task.'
else
   print '=> No pass_context_defn records were added for the ''FORMULATRADE'' task.'
   
begin try
  insert into dbo.pass_context_defn_args
      (pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
  select @last_pass_context_defn_id + pcd.oid,
         pcda.entity_key_num,
         pcda.entity_key_name,
         pcda.entity_key_format
  from #pcd_1345128_CMPLXTRADE pcd
          inner join dbo.pass_context_defn_args pcda
             on pcd.pass_context_defn_id = pcda.pass_context_defn_id 
  set @rows_affected = @@rowcount
end try
begin catch
  if @@trancount > 0
     rollback tran
  print '=> Failed to add pass_context_defn_args records for the ''FORMULATRADE'' task due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch
commit tran
if @rows_affected > 0
   print '=> ' + cast(@rows_affected as varchar) + ' pass_context_defn_args records were added for the ''FORMULATRADE'' task.'
else
   print '=> No pass_context_defn_args records were added for the ''FORMULATRADE'' task.'

endofscript:
if object_id('tempdb..#pcd_1345128_CMPLXTRADE', 'U') is not null
   exec('drop table #pcd_1345128_CMPLXTRADE')
exec dbo.set_last_seqnums
go
    
/* ******************************************************************************* */

print ''
print 'Adding pass_context_defn records and associated args for the ''PRICETRANSFERWACOG'' task if NOT EXIST ... '
print ''
go

declare @rows_affected               int,
        @last_pass_context_defn_id   int

create table #pcd_1345128_PRICEINV
(
   oid                    int IDENTITY PRIMARY KEY,
   pass_context_defn_id	  int	NOT NULL,
   context_entity_name	  varchar(60) NOT NULL
)

if not exists (select 1
               from dbo.pass_task
               where pass_task_code = 'PRICETRANSFERWACOG')
begin
   print '=> the ''PRICETRANSFERWACOG'' task does not exist in the pass_task table!'
   goto endofscript
end

if exists (select 1
           from dbo.pass_context_defn
           where pass_task_code = 'PRICETRANSFERWACOG')
begin
   print '=> There are pass_context_defn records setup for the ''PRICETRANSFERWACOG'' task already!'
   goto endofscript
end

begin try
  insert into #pcd_1345128_PRICEINV
       (pass_context_defn_id, context_entity_name)
  select pass_context_defn_id, context_entity_name
  from dbo.pass_context_defn
  where pass_task_code = 'PRICEINV' 
  set @rows_affected = @@rowcount
end try
begin catch
  print '=> Failed to copy pass_context_defn records owned by the ''PRICEINV'' task to temp table due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch
if @rows_affected = 0
begin
   print '=> No pass_context_defn records found for the ''PRICEINV'' task.  Therefore,'
   print '=> no pass_context_defn records were added for the ''PRICETRANSFERWACOG'' task!'
   goto endofscript
end
  
select @last_pass_context_defn_id = max(pass_context_defn_id)
from dbo.pass_context_defn

if @last_pass_context_defn_id is null
   set @last_pass_context_defn_id = 0

begin tran
begin try
  insert into dbo.pass_context_defn
      (pass_context_defn_id, context_entity_name, pass_task_code)
  select @last_pass_context_defn_id + oid,
         context_entity_name,
         'PRICETRANSFERWACOG'
  from #pcd_1345128_PRICEINV
  set @rows_affected = @@rowcount
end try
begin catch
  if @@trancount > 0
     rollback tran
  print '=> Failed to add pass_context_defn records for the ''PRICETRANSFERWACOG'' task due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch
if @rows_affected > 0
   print '=> ' + cast(@rows_affected as varchar) + ' pass_context_defn records were added for the ''PRICETRANSFERWACOG'' task.'
else
   print '=> No pass_context_defn records were added for the ''PRICETRANSFERWACOG'' task.'
   
begin try
  insert into dbo.pass_context_defn_args
      (pass_context_defn_id, entity_key_num, entity_key_name, entity_key_format)
  select @last_pass_context_defn_id + pcd.oid,
         pcda.entity_key_num,
         pcda.entity_key_name,
         pcda.entity_key_format
  from #pcd_1345128_PRICEINV pcd
          inner join dbo.pass_context_defn_args pcda
             on pcd.pass_context_defn_id = pcda.pass_context_defn_id 
  set @rows_affected = @@rowcount
end try
begin catch
  if @@trancount > 0
     rollback tran
  print '=> Failed to add pass_context_defn_args records for the ''PRICETRANSFERWACOG'' task due to the error:'
  print '==> ERROR: ' + ERROR_MESSAGE()
  goto endofscript
end catch
commit tran
if @rows_affected > 0
   print '=> ' + cast(@rows_affected as varchar) + ' pass_context_defn_args records were added for the ''PRICETRANSFERWACOG'' task.'
else
   print '=> No pass_context_defn_args records were added for the ''PRICETRANSFERWACOG'' task.'

endofscript:
if object_id('tempdb..#pcd_1345128_PRICEINV', 'U') is not null
   exec('drop table #pcd_1345128_PRICEINV')
exec dbo.set_last_seqnums
go
    
