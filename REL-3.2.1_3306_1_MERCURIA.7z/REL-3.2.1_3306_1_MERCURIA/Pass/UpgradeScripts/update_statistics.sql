EXEC sp_updatestats
go
