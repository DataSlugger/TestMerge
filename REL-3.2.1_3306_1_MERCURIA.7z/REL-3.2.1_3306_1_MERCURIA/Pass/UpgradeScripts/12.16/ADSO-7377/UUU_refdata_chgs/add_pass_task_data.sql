set nocount on

print ''
print 'Adding new pass task code ''CKIDEALSOUTBOUND'' into pass_task table IF NOT EXISTS ...'
print ''

declare @pass_exec_order_SAPAIT  	smallint,
	@rows_affected			int

if exists ( select 1 from dbo.pass_task where pass_task_code = 'CKIDEALSOUTBOUND' )
begin
     print '=> The new pass task code ''CKIDEALSOUTBOUND'' is already exists in pass_task table '
     goto endofscript
end
select @rows_affected = 0
select @pass_exec_order_SAPAIT = (select max(pass_exec_order) from dbo.pass_task );
begin tran
	begin try
		insert into dbo.pass_task(pass_task_code,pass_task_desc,pass_exec_order,task_split_ind,
		pass_task_status,pass_executor_id,exec_port_type)
		values('CKIDEALSOUTBOUND','Send Shipment parcel details of deals to CK JDE', @pass_exec_order_SAPAIT+1,'N','A',0,null)
	select @rows_affected = @@rowcount
	end try
	begin catch
		 if @@trancount > 0
			 rollback tran
		 print '=> Failed to insert new pass task code into pass_task table due to below error '
		 print ERROR_MESSAGE()
		 goto endofscript
	end catch
commit tran
if @rows_affected > 0
     print '=> Added a new pass task code into pass_task table successfully !'

endofscript:
go