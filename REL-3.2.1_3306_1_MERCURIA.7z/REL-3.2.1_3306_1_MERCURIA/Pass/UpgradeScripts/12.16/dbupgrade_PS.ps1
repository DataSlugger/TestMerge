# dbupgrade_PS.ps1
#    This script is used to perform changes to the ICTS pass schema in the selected database for
#    the version 12.16
#
#      Usage:
#         PowerShell .\dbupgrade_PS.ps1 -S <server> 
#                                       -U <login> 
#                                       -P <pwd> 
#                                       -D <name of pass database>
#                                       -Log <name of log file including its full path>
#
#      Dependency:
#        It uses the functions stored in
#           CommonDBUpgradeSupportToolSet module
#           PassDBUpgradeSupportToolSet module
#
#     Created By         : Peter Lo   04/28/2016
#     Last Edited By     : Peter Lo   10/14/2016
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
# *****************************************************************************************

Param (
  [Parameter(Mandatory=$true,HelpMessage="You must provide a server instance name")]
     [string]$S,
  [string]$AUTH,
  [string]$U,
  [string]$P,
  [Parameter(Mandatory=$true,HelpMessage="You must provide the name of a pass database")]
     [string]$D,
  [Parameter(Mandatory=$true)]
     [string]$Log
)

$ScriptRootPath1216 = $pwd.Path

$Server=$S
$Authentication=$AUTH
$Login=$U
$Password=$P
$Database=$D
$LogFileName1216=$Log

$DebugOn=$false

if ($DebugOn)
{
   Write-Host "DEBUG (v12.16): Server is '$Server'"
   Write-Host "DEBUG (v12.16): Login is '$Login'"
   Write-Host "DEBUG (v12.16): Password is '$Password'"
   Write-Host "DEBUG (v12.16): Database is '$Database'"
   Write-Host " "
}

ShowAndSaveProgress -LogFileName $LogFileName1216 -Message " "
ShowAndSaveProgress -LogFileName $LogFileName1216 -Message "Applying db changes for version 12.16 to the ICTS pass database ..."
ShowAndSaveProgress -LogFileName $LogFileName1216 -Message "*******************************************************************************************"
ShowAndSaveProgress -LogFileName $LogFileName1216 -Message "=> Upgrading (ADSO-7366) ..."
Set-Location "$ScriptRootPath1216\ADSO-7366"
. .\dbupgrade_PASS_PS $Server $Authentication $Login $Password $Database $LogFileName1216
#
ShowAndSaveProgress -LogFileName $LogFileName1216 -Message "=> Upgrading (ADSO-7377) ..."
Set-Location "$ScriptRootPath1216\ADSO-7377"
. .\dbupgrade_PASS_PS $Server $Authentication $Login $Password $Database $LogFileName1216
#
ShowAndSaveProgress -LogFileName $LogFileName1216 -Message "=> Upgrading (ADSO-7412) ..."
Set-Location "$ScriptRootPath1216\ADSO-7412"
. .\dbupgrade_PASS_PS $Server $Authentication $Login $Password $Database $LogFileName1216
Set-Location $ScriptRootPath1216
#
ShowAndSaveProgress -LogFileName $LogFileName1216 -Message "*******************************************************************************************"
ShowAndSaveProgress -LogFileName $LogFileName1216 -Message "=> Updating db version ..."
if (!(ExecDBScript $Server $Authentication $Login $Password $Database "$ScriptRootPath1216" "dbversion.sql" "@@@")) 
{
   ShowAndSaveProgress -LogFileName $LogFileName1216 -Message "=> Failed to update version info stored in the database_info table"
   ShowAndSaveProgress -LogFileName $LogFileName1216 -Message " "
   exit
}
ShowAndSaveProgress -LogFileName $LogFileName1216 -Message "DB changes covered in v12.16 were applied"
ShowAndSaveProgress -LogFileName $LogFileName1216 -Message " "

