set nocount on

print ' '
print 'Updating db version info ...'
go

if exists (select 1
           from dbo.database_info
           where owner_code = 'TCPASS')
begin
   update dbo.database_info 
   set major_revnum = '12', 
       minor_revnum = '12', 
       last_touch_date = getdate(), 
       data_source = 'StarterDB', 
       usage = NULL, 
       script_reference = '20120925-PASS-CS21', 
       note = '2.2.2045.2', 
       icts_dbversion = NULL
   where owner_code = 'TCPASS'
end
else
begin
   insert into dbo.database_info (
         owner_code, major_revnum, minor_revnum, last_touch_date, 
         data_source, usage, script_reference, note, icts_dbversion) 
      values('TCPASS', '12', '12', getdate(), 'StarterDB', NULL, '20120925-PASS-CS21', null, '2.2.2045.2')
end
go

