# dbupgrade_PS.ps1
#    This script is used to perform changes to the ICTS pass schema in the selected database for
#    the version 12.12
#
#      Usage:
#         PowerShell .\dbupgrade_PS.ps1 -S <server> 
#                                       -U <login> 
#                                       -P <pwd> 
#                                       -D <name of pass database>
#                                       -Log <name of log file including its full path>
#
#      Dependency:
#        It uses the functions stored in
#           CommonDBUpgradeSupportToolSet module
#           PassDBUpgradeSupportToolSet module
#
#     Created By         : Peter Lo   05/25/2016
#     Last Edited By     : Peter Lo   05/25/2016
#     Database           : MS SQL Server 2008R2 or later
#     PowerShell         : V3.0 or later
# *****************************************************************************************

Param (
  [Parameter(Mandatory=$true,HelpMessage="You must provide a server instance name")]
     [string]$S,
  [string]$AUTH,
  [string]$U,
  [string]$P,
  [Parameter(Mandatory=$true,HelpMessage="You must provide the name of a pass database")]
     [string]$D,
  [Parameter(Mandatory=$true)]
     [string]$Log
)

$ScriptRootPath1212 = $pwd.Path

$Server=$S
$Authentication=$AUTH
$Login=$U
$Password=$P
$Database=$D
$LogFileName1212=$Log

$DebugOn=$false

if ($DebugOn)
{
   Write-Host "DEBUG (v12.12): Server is '$Server'"
   Write-Host "DEBUG (v12.12): Login is '$Login'"
   Write-Host "DEBUG (v12.12): Password is '$Password'"
   Write-Host "DEBUG (v12.12): Database is '$Database'"
   Write-Host " "
}

ShowAndSaveProgress -LogFileName $LogFileName1212 -Message " "
ShowAndSaveProgress -LogFileName $LogFileName1212 -Message "Applying db changes for version 12.12 to the ICTS pass database ..."
ShowAndSaveProgress -LogFileName $LogFileName1212 -Message "*******************************************************************************************"
ShowAndSaveProgress -LogFileName $LogFileName1212 -Message "=> Upgrading (1326219) ..."
Set-Location "$ScriptRootPath1212\1326219"
. .\dbupgrade_PASS_PS $Server $Authentication $Login $Password $Database $LogFileName1212 
#
ShowAndSaveProgress -LogFileName $LogFileName1212 -Message "=> Upgrading (1332978) ..."
Set-Location "$ScriptRootPath1212\1332978"
. .\dbupgrade_PASS_PS $Server $Authentication $Login $Password $Database $LogFileName1212 
Set-Location $ScriptRootPath1212
#
ShowAndSaveProgress -LogFileName $LogFileName1212 -Message "*******************************************************************************************"
ShowAndSaveProgress -LogFileName $LogFileName1212 -Message "=> Updating db version ..."
if (!(ExecDBScript $Server $Authentication $Login $Password $Database "$ScriptRootPath1212" "dbversion.sql" "@@@")) 
{
   ShowAndSaveProgress -LogFileName $LogFileName1212 -Message "=> Failed to update version info stored in the database_info table"
   ShowAndSaveProgress -LogFileName $LogFileName1212 -Message " "
   exit
}
ShowAndSaveProgress -LogFileName $LogFileName1212 -Message "DB changes covered in v12.12 were applied"
ShowAndSaveProgress -LogFileName $LogFileName1212 -Message " "

