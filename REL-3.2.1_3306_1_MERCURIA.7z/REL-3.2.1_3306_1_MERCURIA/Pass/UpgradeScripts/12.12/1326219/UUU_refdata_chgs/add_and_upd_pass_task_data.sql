/* MS SQL Server 2005 or later */

set nocount on

print ' '
print 'Adding a new pass_task_code ''PRICETRANSFERWACOG'' IF NOT EXISTS ...'
go

if not exists (select 1
           from dbo.pass_task
           where pass_task_code = 'PRICETRANSFERWACOG')
begin

    print ' '
    print 'Update the exec order for tasks AFTER the XOPTBRKRFIFO task ...'

    declare @XOPTBRKRFIFO_pass_exec_order  smallint,
             @PRICEINV_pass_exec_order smallint,
             @rows_affected             int

    select @XOPTBRKRFIFO_pass_exec_order = pass_exec_order
    from dbo.pass_task 
    where pass_task_code = 'XOPTBRKRFIFO'
    if @XOPTBRKRFIFO_pass_exec_order is null
    begin
	   print '=> Could not find the task ''XOPTBRKRFIFO'' in the pass_task table!'
	   goto endofscript
    end

     select @PRICEINV_pass_exec_order = pass_exec_order
     from dbo.pass_task 
     where pass_task_code = 'PRICEINV'

     if @PRICEINV_pass_exec_order is null
     begin
	   print '=> Could not find the task ''PRICEINV'' in the pass_task table!'
	   goto endofscript
     end

     begin tran
	begin try
	   update dbo.pass_task
	   set pass_exec_order = pass_exec_order + 2 
	   where pass_exec_order >= @XOPTBRKRFIFO_pass_exec_order and
             pass_exec_order < 500
        end try
     begin catch
         if @@trancount > 0
              rollback tran
         print '=> Failed to update the pass_exec_order column values for tasks AFTER the XOPTBRKRFIFO task:'
         print '==> ERROR: ' + ERROR_MESSAGE()
         goto endofscript   
     end catch
     commit tran

-- *******************************************************************************************
    print ' '
    print 'Updating pass_exec_order values of pass_task_codes ''INVMAC_PRICE'' and ''PRICEVESSEL'' ...'

-- *******************************************************************************************

    if exists ( select 1 from dbo.pass_task where pass_task_code = 'INVMAC_PRICE' )
    begin
          update dbo.pass_task
	  set pass_exec_order = @PRICEINV_pass_exec_order + 2, pass_task_status = 'A'
	  where pass_task_code = 'INVMAC_PRICE'
    end
    else
    begin
	 INSERT INTO dbo.pass_task
	 (pass_task_code, pass_task_desc, pass_exec_order, task_split_ind,
	  pass_task_status, pass_executor_id, exec_port_type)
	 VALUES ('INVMAC_PRICE', 'Moving Average Inventory Pricing', @PRICEINV_pass_exec_order + 2, 'Y', 'A', 0, null)
    end
    if exists ( select 1 from dbo.pass_task where pass_task_code = 'PRICEVESSEL' )
    begin
          update dbo.pass_task
	  set pass_exec_order = @PRICEINV_pass_exec_order + 3, pass_task_status = 'I'
	  where pass_task_code = 'PRICEVESSEL'    
    end
    else
    begin
         INSERT INTO dbo.pass_task
         (pass_task_code, pass_task_desc, pass_exec_order, task_split_ind,
          pass_task_status, pass_executor_id, exec_port_type)
         VALUES ('PRICEVESSEL', 'Price Fleet time vessel & Cargo', @PRICEINV_pass_exec_order + 3, 'Y', 'I', 0, null)
    end 

-- *******************************************************************************************
    print ' '
    print 'Adding a new pass_task_code ''PRICETRANSFERWACOG'' IF NOT EXISTS ...'

-- *******************************************************************************************

    begin tran
    begin try
      INSERT INTO dbo.pass_task
           (pass_task_code, pass_task_desc, pass_exec_order, task_split_ind,
            pass_task_status, pass_executor_id, exec_port_type)
      VALUES ('PRICETRANSFERWACOG', 'WACOG', @PRICEINV_pass_exec_order + 1, 'Y', 'A', 0, null)
      select @rows_affected = @@rowcount
    end try
    begin catch
        if @@trancount > 0
          rollback tran
        print '=> Failed to add task ''PRICETRANSFERWACOG''!'
        print '==> ERROR: ' + ERROR_MESSAGE()
        goto endofscript   
    end catch
    commit tran
    if @rows_affected > 0
        print '=> The new pass task code ''PRICETRANSFERWACOG'' was added successfully !'
end
else
begin
     print ' '
     print 'The new pass_task_code ''PRICETRANSFERWACOG'' is already exists in the pass_task table !'
end
endofscript:
go
