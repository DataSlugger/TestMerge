print ' '
print 'Updating pass_task_status of pass_task_code ''PRICEINV'' from ''InActive'' to ''Active'' ...'
print ' '


if exists ( select 1 from dbo.pass_task 
                     where pass_task_code = 'PRICEINV' and
		           pass_task_status = 'I')
begin
      update dbo.pass_task
	  set pass_task_status = 'A'
	  where pass_task_code = 'PRICEINV'
end
go


print 'Updating pass_task_status of pass_task_code ''PRICETRANSFERWACOG'' from ''Active'' to ''InActive'' ...'
print ' '
   
if exists ( select 1 from dbo.pass_task 
                     where pass_task_code = 'PRICETRANSFERWACOG' and
		           pass_task_status = 'A')
begin
       update dbo.pass_task
	  set pass_task_status = 'I'
	  where pass_task_code = 'PRICETRANSFERWACOG'
end
go
