set nocount on

print ''
print 'Adding a new pass task code ''CP2'' into pass_task table IF NOT EXISTS ...'
print ''

declare @pass_exec_order_PL  	smallint,
      	@pass_exec_order_CP2	smallint,
	      @rows_affected		    int

if exists (select 1 from dbo.pass_task where pass_task_code = 'CP2')
begin 
   print 'Pass task code ''CP2'' is already exists in pass_task table '
   goto endofscript
end

select @pass_exec_order_PL = null

select @pass_exec_order_PL = pass_exec_order
from dbo.pass_task
where pass_task_code = 'PL'

if @pass_exec_order_PL is null
begin
   print 'Could not find pass_exec_order of pass task code ''PL'''
   goto endofscript
end

select @rows_affected = 0

print 'Updating pass exec orders which are after PL task with pass_exec_order + 1'

begin tran
begin try
   update dbo.pass_task
   set pass_exec_order = pass_exec_order + 1
   where pass_exec_order > @pass_exec_order_PL and 
         pass_exec_order < 500
   select @rows_affected = @@rowcount
end try
begin catch
   if @@trancount > 0
      rollback tran
   print '=> Failed to update pass_exec_order due to below error '
   print '==> ERROR: ' + ERROR_MESSAGE()
   goto endofscript
end catch
commit tran
if @rows_affected > 0
   print '=> ' + convert(varchar, @rows_affected) + ' Rows updated in pass_task table successfully !'
print ' '

if exists (select 1 from dbo.pass_task where pass_exec_order = @pass_exec_order_PL + 1)
begin 
   print '=> pass exec orders not updated properly ??? '
   goto endofscript
end

select @pass_exec_order_CP2 = @pass_exec_order_PL + 1

select @rows_affected = 0

begin tran
begin try
   INSERT into dbo.pass_task
       (pass_task_code, pass_task_desc, pass_exec_order, task_split_ind,
        pass_task_status, pass_executor_id, exec_port_type)
   values('CP2', 'Generate CP2 records', @pass_exec_order_CP2, 'N', 'A', 0, null)
   select @rows_affected = @@rowcount
end try
begin catch
   if @@trancount > 0
	    rollback tran
   print '=> Failed to add new task code CP2 due to below error '
   print '==> ERROR: ' + ERROR_MESSAGE()
   goto endofscript
end catch
commit tran
if @rows_affected > 0
   print 'Added new pass task code CP2 into pass_task table successfully !'
endofscript:
go