set nocount on

print ' '
print 'Updating pass_log_defn_args table where pass_log_defn_id is 45 '
print ' and argument_num is 2 and  argument_datatype <> ''S'' and argument_format <> ''%s'' if EXISTS ...'
print ' '

if exists ( select 1 from pass_log_defn_args where pass_log_defn_id = 
	    (select pass_log_defn_id from pass_log_defn WHERE log_entity_name='cost' and msg_type='PER' 
		and pass_log_msg_text1 = 'Cannot find parent cost for %s cost %s, skipping...' ) 
	    and argument_num = 2 and argument_datatype <> 'S' and argument_format <> '%s' )
begin
   declare @rows_affected int

   begin tran
   begin try
      update pass_log_defn_args
      set argument_datatype = 'S', argument_format = '%s'
      where pass_log_defn_id = (select pass_log_defn_id from pass_log_defn 
		WHERE log_entity_name='cost' and msg_type='PER' 
		and pass_log_msg_text1 = 'Cannot find parent cost for %s cost %s, skipping...' ) 
	and argument_num = 2
      select @rows_affected = @@rowcount
    end try
    begin catch
        if @@trancount > 0
           rollback tran
        print '==> Failed to Update pass_log_defn_args table due to the error:'
        print '===> ERROR: ' + ERROR_MESSAGE()
        goto endofscript
    end catch 
    commit tran      
      if @rows_affected > 0
         print '==> Updated pass_log_defn_args table successfuly!'
end
else
begin
    print '==> Already pass_log_defn_args table is updated'
end

endofscript:
go
