# **********************************************************************************************************
#  CreatePassConstraints.ps1
#     It calls Invoke-Sqlcmd to execute db scripts scripts (*.con) found in ..\Structure\Constraints folder
#     to create foreign key constraints as part of ICTS pass schema
#     
#     Usage:
#        [bool]$status=CreatePassConstraints -Server <?>
#                                            -Auth <?>
#                                            -Login <?> 
#                                            -Password <?> 
#                                            -Database <?>
#                                            -ScriptRootPath <?>
#                                            -Amode <?>      N - Create new ICTS PASS schema, 
#                                                            U - Upgrade ICTS PASS schema
#
#            Example: [bool]$status=CreatePassConstraints -Server "MYSQL10" 
#                                                         -Auth {"SQL Server Authentication"} 
#                                                         -Login "dba" 
#                                                         -Password "XXX"
#                                                         -Database "TEST_amphora_pass"
#                                                         -ScriptRootPath "<path>"
#                                                         -Amode "N"
#
#
#     Output: 
#        It returns either $true or $false:
#           $true    - Foreign key constraints were created without errors
#           $false   - Foreign key constraints were created with errors
#
#        LOG file: ..\Structure\Logs\u_create_constraints.log (produced by schema upgrade)
#                  OR
#                  ..\Structure\Logs\create_constraints.log (produced by schema creation)
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/28/2016
#   Last Edited By       : Peter Lo  04/28/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************

function CreatePassConstraints
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath,
      [parameter(Mandatory=$false)] [string]$Amode = "N"     # N - Create new ICTS schema, U - Upgrade ICTS schema   
   )
   
   if ($Amode -eq "N") {$LogFileName = "$ScriptRootPath\Logs\create_constraints.log"}
   else {$LogFileName = "$ScriptRootPath\Logs\u_create_constraints.log"}   

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating foreign key constraints ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName
   Set-Location -Path $ScriptRootPath
   $ScriptFileSet=Get-ChildItem .\Constraints -filter *.con | Select-Object Name

   foreach ($ScriptFileObj in $ScriptFileSet) 
   {
      $ScriptFileName = $ScriptFileObj.Name
      Write-Output "=> Executing the script '$ScriptRootPath\Constraints\$ScriptFileName'" | out-file $LogFileName -append
      if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Constraints" $ScriptFileName $LogFileName))
      {
         $dt = ShowCurrentTime -heading "FINISHED"
         Write-Output "FINISHED : $dt" | out-file $LogFileName -append
         return $false
      }
   }
   
   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # CreatePassConstraints
