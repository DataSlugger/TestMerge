# **********************************************************************************************************
#  LoadPassSystemRefData.ps1
#     It executes the scripts (*.sql) found in 
#         ..\Structure\ReferenceData folder
#
#
#     To avoid the foreign key violation error, we use the following file in 
#         ..\Structure\MISC_Scripts to control the script execution order:
#            RefData_list.txt
# 
#     
#     Usage:
#        [bool]$status=LoadPassSystemRefData -Server <?>
#                                            -Auth <?>
#                                            -Login <?> 
#                                            -Password <?> 
#                                            -Database <?>
#                                            -ScriptRootPath <?>
#
#            Example: [bool]$status=LoadPassSystemRefData MYSQL10 
#                                                         {"SQL Server Authentication"} 
#                                                         dba 
#                                                         XXX
#                                                         TEST_amphora_pass
#                                                         "<path>"
#
#
#     Output: 
#        It returns either $true or $false:
#           $true    - Scripts were created without errors
#           $false   - Scripts were created with errors
#
#        LOG file: ..\Structure\Logs\load_refdata.log (produced by schema creation)
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/28/2016
#   Last Edited By       : Peter Lo  04/28/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function LoadPassSystemRefData
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath
   )
   
   $LogFileName = "$ScriptRootPath\Logs\load_refdata.log"

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Loading startup system reference data ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName

   $ListingFileName="$ScriptRootPath\MISC_Scripts\RefData_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sql") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\ReferenceData\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\ReferenceData" $ScriptFileName $LogFileName))
         {
            $dt = ShowCurrentTime -heading "FINISHED"
            Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            return $false
         }
      }
   }

   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # LoadPassSystemRefData
