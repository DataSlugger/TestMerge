# **********************************************************************************************************
#  CreatePassDbUsers.ps1
#     It calls Invoke-Sqlcmd to execute the following scripts in ..\Structure\Users folder
#        logins_4passdb.sql
#        pass_groups.sql
#        users_4passdb.sql
#     
#     Usage:
#        [bool]$status=CreatePassDbUsers.ps1 -Server <?>
#                                            -Auth <?>
#                                            -Login <?> 
#                                            -Password <?> 
#                                            -Database <?>
#                                            -ScriptRootPath <?>
#
#            Example: [bool]$status=CreatePassDbUsers.ps1 MYSQL10 
#                                                         {"SQL Server Authentication"} 
#                                                         dba 
#                                                         XXX
#                                                         TEST_amphora_pass
#                                                         "<path>"
#
#
#     Output: 
#        It returns either $true or $false:
#           $true    - The scripts were executed without errors
#           $false   - The scripts were executed with errors
#
#        LOG file: ..\Structure\Logs\create_pass_users.log  (produced by schema creation)
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/28/2016
#   Last Edited By       : Peter Lo  04/28/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************

function CreatePassDbUsers
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath
   )

   $LogFileName = "$ScriptRootPath\Logs\create_pass_users.log"

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating ICTS PASS database users ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName

   $ScriptFileName = "logins_4passdb.sql"
   Write-Output "=> Executing the script '$ScriptRootPath\Users\$ScriptFileName'" | out-file $LogFileName -append
   if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Users" $ScriptFileName $LogFileName))
   {
      $dt = ShowCurrentTime -heading "FINISHED"
      Write-Output "FINISHED : $dt" | out-file $LogFileName -append
      return $false
   }

   $ScriptFileName = "pass_groups.sql"
   Write-Output "=> Executing the script '$ScriptRootPath\Users\$ScriptFileName'" | out-file $LogFileName -append
   if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Users" $ScriptFileName $LogFileName))
   {
      $dt = ShowCurrentTime -heading "FINISHED"
      Write-Output "FINISHED : $dt" | out-file $LogFileName -append
      return $false
   }

   $ScriptFileName = "users_4passdb.sql"
   Write-Output "=> Executing the script '$ScriptRootPath\Users\$ScriptFileName'" | out-file $LogFileName -append
   if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Users" $ScriptFileName $LogFileName))
   {
      $dt = ShowCurrentTime -heading "FINISHED"
      Write-Output "FINISHED : $dt" | out-file $LogFileName -append
      return $false
   }

   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # CreatePassDbUsers.ps1
