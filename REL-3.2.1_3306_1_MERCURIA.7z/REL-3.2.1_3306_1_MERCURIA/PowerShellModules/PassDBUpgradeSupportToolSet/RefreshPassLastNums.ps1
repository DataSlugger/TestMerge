# **********************************************************************************************************
#  RefreshPassLastNums.ps1
#     It executes the script "sync_last_seqnums.sql" found in 
#       ..\Structure folder
#     
#     Usage:
#       [bool]$status=RefreshPassLastNums -Server <?>
#                                         -Auth <?>
#                                         -Login <?> 
#                                         -Password <?> 
#                                         -Database <?>
#                                         -ScriptRootPath <?>
#                                         -Amode <?>      N - Create new ICTS PASS schema, 
#                                                         U - Upgrade ICTS PASS schema
#
#            Example: [bool]$status=RefreshPassLastNums MYSQL10 
#                                                       {"SQL Server Authentication"} 
#                                                       dba 
#                                                       XXX
#                                                       TEST_amphora_pass
#                                                       "<path>"
#                                                       "N"
#
#     Output: 
#        It returns either $true or $false:
#           $true    - Triggers were created without errors
#           $false   - Triggers were created with errors
#
#        LOG file: ..\Structure\Logs\u_upd_last_nums.log (produced by schema upgrade)
#                  OR
#                  ..\Structure\Logs\upd_last_nums.log (produced by schema creation)
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/28/2016
#   Last Edited By       : Peter Lo  04/28/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function RefreshPassLastNums
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath,
      [parameter(Mandatory=$false)] [string]$Amode = "N"     # N - Create new ICTS schema, U - Upgrade ICTS schema
   )
   
   if ($Amode -eq "N") {$LogFileName = "$ScriptRootPath\Logs\upd_last_nums.log"}
   else {$LogFileName = "$ScriptRootPath\Logs\u_upd_last_nums.log"}

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Refreshing the counters stored in the last_num column of the new_num table ..."   
   
   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName

   Write-Output "=> Executing the script '$ScriptRootPath\sync_last_seqnums.sql'" | out-file $LogFileName -append
   if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath" "sync_last_seqnums.sql" $LogFileName))
   {
      $dt = ShowCurrentTime -heading "FINISHED"
      Write-Output "FINISHED : $dt" | out-file $LogFileName -append
      return $false
   }
   
   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # RefreshPassLastNums
