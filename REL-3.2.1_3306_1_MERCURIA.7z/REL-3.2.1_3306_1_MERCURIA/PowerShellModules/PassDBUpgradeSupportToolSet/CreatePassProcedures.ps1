# **********************************************************************************************************
#  CreatePassProcedures.ps1
#     It calls Invoke-Sqlcmd to execute db scripts scripts (*.sp) found in ..\Structure\StoredProcedures 
#     folder to create procedures as part of ICTS pass schema
#     
#     Usage:
#        [bool]$status=CreatePassProcedures -Server <?>
#                                           -Auth <?>
#                                           -Login <?> 
#                                           -Password <?> 
#                                           -Database <?>
#                                           -ScriptRootPath <?>
#                                           -Amode <?>       N - Create new ICTS PASS schema, 
#                                                            U - Upgrade ICTS PASS schema
#
#            Example: [bool]$status=CreatePassProcedures MYSQL10 
#                                                        {"SQL Server Authentication"} 
#                                                        dba 
#                                                        XXX
#                                                        TEST_amphora_pass
#                                                        "<path>"
#                                                        "N"
#
#      To avoid the forward references, we use the following file in ..\Structure\MISC_Scripts
#      to control the script execution order:
#         sp_list.txt
# -----------------------------------------------------------------------------------------
#
#     Output: 
#        It returns either $true or $false:
#           $true    - Procedures were created without errors
#           $false   - Procedures were created with errors
#
#        LOG file: ..\Structure\Logs\u_create_sps.log (produced by schema upgrade)
#                  OR
#                  ..\Structure\Logs\create_sps.log (produced by schema creation)
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/28/2016
#   Last Edited By       : Peter Lo  04/28/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************

function CreatePassProcedures
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath,
      [parameter(Mandatory=$false)] [string]$Amode = "N"     # N - Create new ICTS schema, U - Upgrade ICTS schema
   )
   
   if ($Amode -eq "N") {$LogFileName = "$ScriptRootPath\Logs\create_sps.log"}
   else {$LogFileName = "$ScriptRootPath\Logs\u_create_sps.log"}   

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating stored procedures ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures" $ScriptFileName $LogFileName))
         {
            $dt = ShowCurrentTime -heading "FINISHED"
            Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            return $false
         }
      }
   }

   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # CreatePassProcedures
