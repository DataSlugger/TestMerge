# **********************************************************************************************************
#  CreateMainTables.ps1
#     It calls Invoke-Sqlcmd to execute db scripts scripts (*.tbl) found in ..\Structure\Tables folder
#     to create tables as part of ICTS trade schema
#     
#     Usage:
#        [bool]$status=CreateMainTables -Server <?>
#                                       -Auth <?>
#                                       -Login <?> 
#                                       -Password <?> 
#                                       -Database <?>
#                                       -ScriptRootPath <?>
#
#            Example: [bool]$status=CreateMainTables MYSQL10 
#                                                    {"SQL Server Authentication"} 
#                                                    dba 
#                                                    XXX
#                                                    TEST_amphora_trade
#                                                    "<path>"
#
#
#     Output: 
#        It returns either $true or $false:
#           $true    - tables were created without errors
#           $false   - tables were created with errors
#
#        LOG file: ..\Structure\Logs\create_main_tables.log (produced by schema creation)
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************

function CreateMainTables
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath   
   )
   
   $LogFileName = "$ScriptRootPath\Logs\create_main_tables.log"

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating tables ..."  

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName
   Set-Location -Path $ScriptRootPath
   $ScriptFileSet=Get-ChildItem .\Tables -filter *.tbl | Select-Object Name

   foreach ($ScriptFileObj in $ScriptFileSet) 
   {
      $ScriptFileName = $ScriptFileObj.Name
      Write-Output "=> Executing the script '$ScriptRootPath\Tables\$ScriptFileName'" | out-file $LogFileName -append
      if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Tables" $ScriptFileName $LogFileName)) 
      {
         #$dt = ShowCurrentTime -heading "FINISHED"
         #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
         #return $false
      }
   }

   $ScriptFileSet=Get-ChildItem .\Tables\ForAppLauncher -filter *.tbl | Select-Object Name

   foreach ($ScriptFileObj in $ScriptFileSet) 
   {
      if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Tables\ForAppLauncher" $ScriptFileObj.Name $LogFileName))
      {
         #$dt = ShowCurrentTime -heading "FINISHED"
         #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
         #return $false
      }
   }
   
   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED : $dt" | out-file $LogFileName -append
   return $true
} # CreateMainTables
