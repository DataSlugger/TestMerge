# **********************************************************************************************************
#  AddOrUpdateSeedRefData.ps1
#     It executes the scripts (*.sql) found in 
#         ..\Structure\ReferenceData\SystemSeed folder
#
#     To avoid the foreign key violation error, we use the following files in 
#     ..\Structure\MISC_Scripts to control the script execution order:
#         U_SystemSeedData_list.txt,
#         QuickFillSeedData_list.txt,
#         SystemSeedData_ETD_list.txt,
#         SystemSeedData_ETIA_list.txt,
#         SystemSeedData_ETO_list.txt,
#         SystemSeedData_ET_list.txt,
#         SystemSeedData_GDN_GDD_GDV_list.txt
#     
#     Usage:
#        [bool]$status=AddOrUpdateSeedRefData -Server <?>
#                                             -Auth <?>
#                                             -Login <?> 
#                                             -Password <?> 
#                                             -Database <?>
#                                             -ScriptRootPath <?>
#
#            Example: [bool]$status=AddOrUpdateSeedRefData MYSQL10 
#                                                          {"SQL Server Authentication"} 
#                                                          dba 
#                                                          XXX
#                                                          TEST_amphora_trade
#                                                          "<path>"
#
#
#     Output: 
#        It returns either $true or $false:
#           $true    - Scripts were created without errors
#           $false   - Scripts were created with errors
#
#        LOG file: ..\Structure\Logs\u_add_or_upd_seed_refdata.log (produced by schema upgrade)
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function AddOrUpdateSeedRefData
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath
   )
   
   $LogFileName = "$ScriptRootPath\Logs\u_add_or_upd_seed_refdata.log"

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Adding or updating seed reference data ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName

   $ListingFileName="$ScriptRootPath\MISC_Scripts\U_SystemSeedData_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sql") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\ReferenceData\SystemSeed\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\ReferenceData\SystemSeed" $ScriptFileName $LogFileName)) 
		 {
		    #return $false
		 }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\QuickFillSeedData_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sql") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\ReferenceData\QuickFillSeed\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\ReferenceData\QuickFillSeed" $ScriptFileName $LogFileName)) 
		 {
		    #return $false
		 }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\SystemSeedData_ETD_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sql") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\ReferenceData\SystemSeed\entity_tag_definition\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\ReferenceData\SystemSeed\entity_tag_definition" $ScriptFileName $LogFileName)) 
		 {
		    #return $false
		 }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\SystemSeedData_ETIA_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sql") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\ReferenceData\SystemSeed\entity_tag_insp_attr\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\ReferenceData\SystemSeed\entity_tag_insp_attr" $ScriptFileName $LogFileName)) 
		 {
		    #return $false
		 }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\SystemSeedData_ETO_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sql") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\ReferenceData\SystemSeed\entity_tag_option\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\ReferenceData\SystemSeed\entity_tag_option" $ScriptFileName $LogFileName)) 
		 {
		    #return $false
		 }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\SystemSeedData_ET_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sql") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\ReferenceData\SystemSeed\entity_tag\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\ReferenceData\SystemSeed\entity_tag" $ScriptFileName $LogFileName)) 
		 {
		    #return $false
		 }
      }
   }
   
   $ListingFileName="$ScriptRootPath\MISC_Scripts\SystemSeedData_GDN_GDD_GDV_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sql") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\ReferenceData\SystemSeed\GDN_GDD_GDV\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\ReferenceData\SystemSeed\GDN_GDD_GDV" $ScriptFileName $LogFileName)) 
		 {
		    #return $false
		 }
      }
   }

   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # AddOrUpdateSeedRefData
