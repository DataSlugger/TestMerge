# **********************************************************************************************************
#  CreateAuditIndexes.ps1
#     It calls Invoke-Sqlcmd to execute db scripts scripts (*.idx) found in ..\Structure\AuditIndexes folder
#     to create audit indexes as part of ICTS trade schema
#     
#     Usage:
#        [bool]$status=CreateAuditIndexes -Server <?>
#                                         -Auth <?>
#                                         -Login <?> 
#                                         -Password <?> 
#                                         -Database <?>
#                                         -ScriptRootPath <?>
#                                         -Amode <?>      N - Create new ICTS TRADE schema, 
#                                                         U - Upgrade ICTS TRADE schema
#
#            Example: [bool]$status=CreateAuditIndexes MYSQL10 
#                                                      {"SQL Server Authentication"} 
#                                                      dba 
#                                                      XXX
#                                                      TEST_amphora_trade
#                                                      "<path>"
#                                                      "N"
#
#     Output: 
#        It returns either $true or $false:
#           $true    - Indexes were created without errors
#           $false   - Indexes were created with errors
#
#        LOG file: ..\Structure\Logs\u_create_indexs_4_audit_tables.log (produced by schema upgrade)
#                  OR
#                  ..\Structure\Logs\create_indexs_4_audit_tables.log (produced by schema creation)
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function CreateAuditIndexes
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath,
      [parameter(Mandatory=$false)] [string]$Amode = "N"     # N - Create new ICTS schema, U - Upgrade ICTS schema   
   )
   
   if ($Amode -eq "N") {$LogFileName = "$ScriptRootPath\Logs\create_indexs_4_audit_tables.log"}
   else {$LogFileName = "$ScriptRootPath\Logs\u_create_indexs_4_audit_tables.log"}   

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating indexes for audit tables ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName
   Set-Location -Path $ScriptRootPath
   $ScriptFileSet=Get-ChildItem .\AuditIndexes -filter *.idx | Select-Object Name

   foreach ($ScriptFileObj in $ScriptFileSet) 
   {
      if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\AuditIndexes" $ScriptFileObj.Name $LogFileName))
      {
         #$dt = ShowCurrentTime -heading "FINISHED"
         #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
         #return $false
      }
   }
   
   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # CreateAuditIndexes
