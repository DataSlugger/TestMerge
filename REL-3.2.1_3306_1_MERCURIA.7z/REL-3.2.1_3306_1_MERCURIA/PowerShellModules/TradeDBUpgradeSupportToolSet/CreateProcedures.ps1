# **********************************************************************************************************
#  CreateProcedures.ps1
#     It calls Invoke-Sqlcmd to execute db scripts scripts (*.sp) found in ..\Structure\StoredProcedures 
#     folder to create procedures as part of ICTS trade schema
#     
#     Usage:
#        [bool]$status=CreateProcedures -Server <?>
#                                       -Auth <?>
#                                       -Login <?> 
#                                       -Password <?> 
#                                       -Database <?>
#                                       -ScriptRootPath <?>
#                                       -Amode <?>       N - Create new ICTS TRADE schema, 
#                                                        U - Upgrade ICTS TRADE schema
#
#            Example: [bool]$status=CreateProcedures MYSQL10 
#                                                    {"SQL Server Authentication"} 
#                                                    dba 
#                                                    XXX
#                                                    TEST_amphora_trade
#                                                    "<path>"
#                                                    "N"
#
#      To avoid the forward references, we use the following files in ..\Structure\MISC_Scripts
#      to control the script execution order:
#         sp_list_ADMIN.txt,
#         sp_list_SPECIAL.txt,
#         sp_list_REVOBJ.txt,
#         sp_list_QUICKFILL.txt,  
#         sp_list_PRICE.txt,  
#         sp_list_PURGE.txt,  
#         sp_list_ADD.txt,  
#         sp_list_DEL.txt,  
#         sp_list_FIND.txt,  
#         sp_list_LOCATE.txt,  
#         sp_list_UPD.txt,  
#         sp_list_PASS.txt,  
#         sp_list_POSITION.txt,  
#         sp_list_RVFILE.txt,  
#         sp_list_REPORT.txt,  
#         sp_list_VAR.txt,  
#         sp_list_CQ.txt,
#         sp_list_APPLAUNCHER.txt
# -----------------------------------------------------------------------------------------
#
#     Output: 
#        It returns either $true or $false:
#           $true    - Procedures were created without errors
#           $false   - Procedures were created with errors
#
#        LOG file: ..\Structure\Logs\u_create_sps.log (produced by schema upgrade)
#                  OR
#                  ..\Structure\Logs\create_sps.log (produced by schema creation)
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************

function CreateProcedures
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath,
      [parameter(Mandatory=$false)] [string]$Amode = "N"     # N - Create new ICTS schema, U - Upgrade ICTS schema
   )
   
   if ($Amode -eq "N") {$LogFileName = "$ScriptRootPath\Logs\create_sps.log"}
   else {$LogFileName = "$ScriptRootPath\Logs\u_create_sps.log"}   

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating stored procedures ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_ADMIN.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\Admin\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\Admin" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_SPECIAL.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\Special\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\Special" $ScriptFileName $LogFileName))
         {
            $dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_REVOBJ.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\RevObjects\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\RevObjects" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_QUICKFILL.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\QuickFill\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\QuickFill" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_PRICE.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\PriceManager\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\PriceManager" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_PURGE.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\Purge\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\Purge" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_ADD.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\Add\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\Add" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_DEL.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\Delete\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\Delete" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_FIND.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\Find\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\Find" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_LOCATE.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\Locate\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\Locate" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_UPD.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\Update\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\Update" $ScriptFileName $LogFileName)) 
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_PASS.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\Pass\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\Pass" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_POSITION.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\PositionSystem\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\PositionSystem" $ScriptFileName $LogFileName))
         {
            $dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_RVFILE.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\RVFile\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\RVFile" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_REPORT.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\Reporting\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\Reporting" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_VAR.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\VAR\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\VAR" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_CQ.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\CQ\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\CQ" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\sp_list_APPLAUNCHER.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sp") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\StoredProcedures\AppLauncher\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\StoredProcedures\AppLauncher" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }
   
   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # CreateProcedures
