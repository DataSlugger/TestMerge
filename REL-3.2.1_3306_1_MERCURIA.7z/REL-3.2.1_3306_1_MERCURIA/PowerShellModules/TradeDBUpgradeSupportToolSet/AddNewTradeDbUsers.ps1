# **********************************************************************************************************
#  AddNewTradeDbUsers.ps1
#     It executes the following scripts in ..\Structure\Security folder
#        add_tradedb_users_if_not_exist.sql
#
#     Usage:
#        [bool]$status=AddNewTradeDbUsers -Server <?>
#                                         -Auth <?>
#                                         -Login <?> 
#                                         -Password <?> 
#                                         -Database <?>
#                                         -ScriptRootPath <?>
#
#            Example: [bool]$status=AddNewTradeDbUsers MYSQL10 
#                                                      {"SQL Server Authentication"} 
#                                                      dba 
#                                                      XXX
#                                                      TEST_amphora_trade
#                                                      "<path>"
#
#
#     Output: 
#        It returns either $true or $false:
#           $true    - The scripts were executed without errors
#           $false   - The scripts were executed with errors
#
#        LOG file: ..\Structure\Logs\u_add_standard_users.log  (produced by schema upgrade)
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function AddNewTradeDbUsers
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath
   )

   $LogFileName = "$ScriptRootPath\Logs\u_add_standard_users.log"

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Adding new ICTS TRADE standard database users if NOT EXISTS ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName

   Write-Output "=> Executing the script '$ScriptRootPath\Security\add_tradedb_users_if_not_exist.sql'" | out-file $LogFileName -append
   if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Security" "add_tradedb_users_if_not_exist.sql" $LogFileName)) 
   {
      #return $false
   }
   
   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # AddNewTradeDbUsers
