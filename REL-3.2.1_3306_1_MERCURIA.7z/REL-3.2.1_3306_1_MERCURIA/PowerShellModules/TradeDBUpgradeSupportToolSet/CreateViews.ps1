# **********************************************************************************************************
#  CreateViews.ps1
#     It calls Invoke-Sqlcmd to execute db scripts scripts (*.vu) found in ..\Structure\Views folder
#     to create views as part of ICTS trade schema
#     
#     Usage:
#        [bool]$status=CreateViews -Server <?>
#                                  -Auth <?>
#                                  -Login <?> 
#                                  -Password <?> 
#                                  -Database <?>
#                                  -ScriptRootPath <?>
#                                  -Amode <?>      N - Create new ICTS TRADE schema, 
#                                                  U - Upgrade ICTS TRADE schema
#
#            Example: [bool]$status=CreateViews MYSQL10 
#                                               {"SQL Server Authentication"} 
#                                               dba 
#                                               XXX
#                                               TEST_amphora_trade
#                                               "<path>"
#                                               "N"
#
#     To avoid the forward references, we use the following files in ..\Structure\MISC_Scripts
#     to control the script execution order:
#         view_list.txt,
#         view_list_UPDATEABLE.txt,
#         view_list_JMS.txt,
#         view_list_REVOBJ.txt,
#         view_list_RS.txt,
#         view_list_RSALL.txt,
#         view_list_TS.txt,
#         view_list_VAR.txt,
# -----------------------------------------------------------------------------------------
#
#     Output: 
#        It returns either $true or $false:
#           $true    - Views were created without errors
#           $false   - Views were created with errors
#
#        LOG file: ..\Structure\Logs\u_create_views.log (produced by schema upgrade)
#                  OR
#                  ..\Structure\Logs\create_views.log (produced by schema creation)
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function CreateViews
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath,
      [parameter(Mandatory=$false)] [string]$Amode = "N"     # N - Create new ICTS schema, U - Upgrade ICTS schema
   )
   
   if ($Amode -eq "N") {$LogFileName = "$ScriptRootPath\Logs\create_views.log"}
   else {$LogFileName = "$ScriptRootPath\Logs\u_create_views.log"}   

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating views ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName
   $ListingFileName="$ScriptRootPath\MISC_Scripts\view_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".vu") -gt 0)
      {
         $ScriptFileName.TrimEnd() | out-null
         Write-Output "=> Executing the script '$ScriptRootPath\Views\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Views" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\view_list_UPDATEABLE.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".vu") -gt 0)
      {
         $ScriptFileName.TrimEnd() | out-null
         Write-Output "=> Executing the script '$ScriptRootPath\Views\UPDATEABLE\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Views\UPDATEABLE" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\view_list_JMS.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".vu") -gt 0)
      {
         $ScriptFileName.TrimEnd() | out-null
         Write-Output "=> Executing the script '$ScriptRootPath\Views\JMSRPT\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Views\JMSRPT" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\view_list_REVOBJ.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".vu") -gt 0)
      {
         $ScriptFileName.TrimEnd() | out-null
         Write-Output "=> Executing the script '$ScriptRootPath\Views\REVOBJ\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Views\REVOBJ" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\view_list_RS.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".vu") -gt 0)
      {
         $ScriptFileName.TrimEnd() | out-null
         Write-Output "=> Executing the script '$ScriptRootPath\Views\RS\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Views\RS" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\view_list_REPORT.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".vu") -gt 0)
      {
         $ScriptFileName.TrimEnd() | out-null
         Write-Output "=> Executing the script '$ScriptRootPath\Views\Reporting\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Views\Reporting" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }
   
   $ListingFileName="$ScriptRootPath\MISC_Scripts\view_list_RSALL.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".vu") -gt 0)
      {
         $ScriptFileName.TrimEnd() | out-null
         Write-Output "=> Executing the script '$ScriptRootPath\Views\RS_ALL\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Views\RS_ALL" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\view_list_TS.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".vu") -gt 0)
      {
         $ScriptFileName.TrimEnd() | out-null
         Write-Output "=> Executing the script '$ScriptRootPath\Views\ForTradeSearch\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Views\ForTradeSearch" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\view_list_VAR.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".vu") -gt 0)
      {
         $ScriptFileName.TrimEnd() | out-null
         Write-Output "=> Executing the script '$ScriptRootPath\Views\VAR\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Views\VAR" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }
   
   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # CreateViews
