# **********************************************************************************************************
#  CreateTradeDbRoles.ps1
#     It calls Invoke-Sqmcmd to execute the following scripts in ..\Structure\Security folder
#        add_admin_group_role.sql
#        add_next_usr_role.sql
#     
#     Usage:
#        [bool]$status=CreateTradeDbRoles -Server <?>
#                                         -Auth <?>
#                                         -Login <?> 
#                                         -Password <?> 
#                                         -Database <?>
#                                         -ScriptRootPath <?>
#
#            Example: [bool]$status=CreateTradeDbRoles -Server "MYSQL10" 
#                                                      -Auth {"SQL Server Authentication"}
#                                                      -Login "dba" 
#                                                      -Password "XXX" 
#                                                      -Database "TEST_amphora_trade"
#                                                      -ScriptRootPath "<path>"
#
#     Output: 
#        It returns either $true or $false:
#           $true    - tables were created without errors
#           $false   - tables were created with errors
#
#        LOG file: ..\Structure\Logs\create_ICTS_roles.log  (produced by schema creation)
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function CreateTradeDbRoles
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath
   )

   $LogFileName = "$ScriptRootPath\Logs\create_ICTS_roles.log"

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating ICTS TRADE database roles ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName

   Write-Output "=> Executing the script '$ScriptRootPath\Security\add_admin_group_role.sql'" | out-file $LogFileName -append
   if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Security" "add_admin_group_role.sql" $LogFileName))
   {
      #$dt = ShowCurrentTime -heading "FINISHED"
      #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
      #return $false
   }

   # ----------------------------------------------------------------------   
   Write-Output "=> Executing the script '$ScriptRootPath\Security\add_next_usr_role.sql'" | out-file $LogFileName -append
   if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Security" "add_next_usr_role.sql" $LogFileName))
   {
      #$dt = ShowCurrentTime -heading "FINISHED"
      #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
      #return $false
   }

   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   
   return $true
} #CreateTradeDbRoles
