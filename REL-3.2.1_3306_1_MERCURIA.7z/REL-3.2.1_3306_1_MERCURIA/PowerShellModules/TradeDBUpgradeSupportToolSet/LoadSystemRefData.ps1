# **********************************************************************************************************
#  LoadSystemRefData.ps1
#     It executes the scripts (*.sql) found in 
#         ..\Structure\ReferenceData\SystemRef folder
#
#       and runs bcp.exe to load data from 
#          ..\ReferenceData\SystemRef\sys_resources_data\sys_resources.bcp
#          ..\ReferenceData\SystemRef\feed_definition_data\feed_definition_xsd_xml.bcp
#          ..\ReferenceData\SystemRef\feed_definition_data\feed_definition.bcp
#
#     To avoid the foreign key violation error, we use the following files in 
#         ..\Structure\MISC_Scripts to control the script execution order:
#            SystemRefData_list.txt,
#            SystemRefData_FD_list.txt
#            SystemRefData_APPLAUNCHER_list.txt
# 
#     
#     Usage:
#        [bool]$status=LoadSystemRefData -Server <?>
#                                        -Auth <?>
#                                        -Login <?> 
#                                        -Password <?> 
#                                        -Database <?>
#                                        -ScriptRootPath <?>
#
#            Example: [bool]$status=LoadSystemRefData MYSQL10 
#                                                     {"SQL Server Authentication"} 
#                                                     dba 
#                                                     XXX
#                                                     TEST_amphora_trade
#                                                     "<path>"
#
#
#     Output: 
#        It returns either $true or $false:
#           $true    - Scripts were created without errors
#           $false   - Scripts were created with errors
#
#        LOG file: ..\Structure\Logs\load_system_refdata.log (produced by schema creation)
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function LoadSystemRefData
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath
   )
   
   $LogFileName = "$ScriptRootPath\Logs\load_system_refdata.log"

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Loading startup system reference data ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName

   $ListingFileName="$ScriptRootPath\MISC_Scripts\SystemRefData_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sql") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\ReferenceData\SystemRef\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\ReferenceData\SystemRef" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\SystemRefData_APPLAUNCHER_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sql") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\ReferenceData\SystemRef\AppLauncher\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\ReferenceData\SystemRef\AppLauncher" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   if ($show_dbscript) {Write-Host "=> Loading startup reference data into the sys_resources table ..."}
   Write-Output "=> Loading startup reference data into the sys_resources table ..." | Out-File $LogFileName -append 
   $BcpFullFileName="$ScriptRootPath\ReferenceData\SystemRef\sys_resources_data\sys_resources.bcp"
   $TableName="sys_resources"
   $BcpSwitches="-n"
   
   if (!(BCPInData $Server $Auth $Login $Password $Database $TableName $BcpFullFileName $BcpSwitches $LogFileName)) {return $false}

   #$bcputil = "C:\Program Files\Microsoft SQL Server\100\Tools\Binn\bcp.exe"
   # $bcputil = "bcp.exe"
   #if ($Auth -eq "Windows Authentication")
   #{
   #   $bcpargs = @("$Database.dbo.sys_resources",
   #                "in",
   #                "$BCPFileName",
   #                "-n", 
   #                "-b",
   #                "100",
   #                "-E",
   #                "-S",
   #                "$Server")
   #}
   #else
   #{
   #   $bcpargs = @("$Database.dbo.sys_resources",
   #                "in",
   #                "$BCPFileName",
   #                "-n", 
   #                "-b",
   #                "100",
   #                "-U",
   #                "$Login",
   #                "-P",
   #                "$Password",
   #                "-S",
   #                "$Server")
   #}
   # & $bcputil $bcpargs | Out-File $LogFileName -append

   if ($show_dbscript) {Write-Host "=> Loading startup reference data into the feed_definition_xsd_xml table ..."}
   Write-Output "=> Loading startup reference data into the feed_definition_xsd_xml table ..." | Out-File $LogFileName -append 
   #$bcpargs[0] = "$Database.dbo.feed_definition_xsd_xml"
   #$bcpargs[2] = "$ScriptRootPath\ReferenceData\SystemRef\feed_definition_data\feed_definition_xsd_xml.bcp"
   #& $bcputil $bcpargs | Out-File $LogFileName -append
   $BcpFullFileName="$ScriptRootPath\ReferenceData\SystemRef\feed_definition_data\feed_definition_xsd_xml.bcp"
   $TableName="feed_definition_xsd_xml"
   $BcpSwitches="-n"
   
   if (!(BCPInData $Server $Auth $Login $Password $Database $TableName $BcpFullFileName $BcpSwitches $LogFileName)) 
   {
      #return $false
   }

   if ($show_dbscript) {Write-Host "=> Loading startup reference data into the feed_definition table ..."}
   Write-Output "=> Loading startup reference data into the feed_definition table ..." | Out-File $LogFileName -append 
   #$bcpargs[0] = "$Database.dbo.feed_definition"
   #$bcpargs[2] = "$ScriptRootPath\ReferenceData\SystemRef\feed_definition_data\feed_definition.bcp"
   #& $bcputil $bcpargs | Out-File $LogFileName -append

   $BcpFullFileName="$ScriptRootPath\ReferenceData\SystemRef\feed_definition_data\feed_definition.bcp"
   $TableName="feed_definition"
   $BcpSwitches="-n"
   
   if (!(BCPInData $Server $Auth $Login $Password $Database $TableName $BcpFullFileName $BcpSwitches $LogFileName)) 
   {
      #return $false
   }

   $ListingFileName="$ScriptRootPath\MISC_Scripts\SystemRefData_FD_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sql") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\ReferenceData\SystemRef\feed_definition_data\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\ReferenceData\SystemRef\feed_definition_data" $ScriptFileName $LogFileName))
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # LoadSystemRefData
