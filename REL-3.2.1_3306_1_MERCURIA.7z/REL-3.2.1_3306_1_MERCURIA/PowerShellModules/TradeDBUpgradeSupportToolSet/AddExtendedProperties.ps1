# **********************************************************************************************************
#  AddExtendedProperties.ps1
#     It executes the scripts listed in the "add_extended_properties_list.txt" file
#     under the ..\Structure\MISC_Scripts
#
#     Usage:
#        [bool]$status=AddExtendedProperties -Server <?>
#                                            -Auth <?>
#                                            -Login <?> 
#                                            -Password <?> 
#                                            -Database <?>
#                                            -ScriptRootPath <?>
#                                            -Amode <?>     N - Create new ICTS schema, 
#                                                           U - Upgrade ICTS schema
#
#            Example: [bool]$status=AddExtendedPropertiess MYSQL10 
#                                                          {"SQL Server Authentication"} 
#                                                          dba 
#                                                          XXX
#                                                          TEST_amphora_trade
#                                                          "<path>"
#                                                          "N"
#
#     Output: 
#        It returns either $true or $false:
#           $true    - Scripts were created without errors
#           $false   - Scripts were created with errors
#
#        LOG file: ..\Structure\Logs\add_extended_properties.log (produced by schema creation)
#                  OR
#                  ..\Structure\Logs\u_add_extended_properties.log (produced by schema upgrade)
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# ************************************************************************************************

function AddExtendedProperties
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath,
      [parameter(Mandatory=$false)] [string]$Amode = "N"
   )
   
   if ($Amode -eq "N") {$LogFileName = "$ScriptRootPath\Logs\add_extended_properties.log"}
   else {$LogFileName = "$ScriptRootPath\Logs\u_add_extend_properties.log"}

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Adding extented properties for db objects ..."   
   
   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName
   
   $ListingFileName="$ScriptRootPath\MISC_Scripts\add_extended_properties_list.txt"
   foreach ($ScriptFileName in get-content $ListingFileName)
   {
      if ($ScriptFileName.IndexOf(".sql") -gt 0)
      {
         Write-Output "=> Executing the script '$ScriptRootPath\MISC_Scripts\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\MISC_Scripts" $ScriptFileName $LogFileName)) 
		 {
		    #return $false
	     }
      }
   }
   
   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # AddExtendedProperties
