# **********************************************************************************************************
#  CreateOrUpdateDashboardDbObjects.ps1
#     It calls Invoke-Sqlcmd to execute db scripts in Structure\MISC_Scripts\DashboardReporting
#     to create db objects supporting dashboard reporting
#     
#     Usage:
#        [bool]$status=CreateOrUpdateDashboardDbObjects -Server <?>
#                                                       -Auth <?>
#                                                       -Login <?> 
#                                                       -Password <?> 
#                                                       -Database <?>
#                                                       -ScriptRootPath <?>
#                                                       -UpdateMode <?>
#
#            Example: [bool]$status=CreateOrUpdateDashboardDbObjects MYSQL10 
#                                                                    {"SQL Server Authentication"} 
#                                                                    dba 
#                                                                    XXX
#                                                                    TEST_amphora_trade
#                                                                    "<path>"
#                                                                    "U"
#
#
#     Output: 
#        It returns either $true or $false:
#           $true    - tables were created without errors
#           $false   - tables were created with errors
#
#        LOG file: ..\Structure\Logs\create_dashboard.log or ..\Structure\Logs\update_dashboard.log
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  09/01/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************

function CreateOrUpdateDashboardDbObjects
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath,
      [parameter(Mandatory=$false)] [string]$UpdateMode = "N"      # "N" - creation, "U" - update 
   )
   
   if ($UpdateMode -eq "U")
   {
      $LogFileName = "$ScriptRootPath\Logs\update_dashboard.log"
   }
   else
   {
      $LogFileName = "$ScriptRootPath\Logs\create_dashboard.log"
   }
   
   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName
   if ($UpdateMode -ne "U")
   {   
      Set-Location -Path "$ScriptRootPath\MISC_Scripts\DashboardReporting"
      $ScriptFileSet=Get-ChildItem .\Tables -filter *.tbl | Select-Object Name

      foreach ($ScriptFileObj in $ScriptFileSet) 
      {
         $ScriptFileName = $ScriptFileObj.Name
         Write-Output "=> Executing the script '$ScriptRootPath\MISC_Scripts\DashboardReporting\Tables\$ScriptFileName'" | out-file $LogFileName -append
         if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\MISC_Scripts\DashboardReporting\Tables" $ScriptFileName $LogFileName)) 
         {
            #$dt = ShowCurrentTime -heading "FINISHED"
            #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
            #return $false
         }
      }
   }

   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating indexes supporting dashboard reporting IF NOT EXIST ..."  
   Set-Location -Path "$ScriptRootPath\MISC_Scripts\DashboardReporting"
   $ScriptFileSet=Get-ChildItem .\Indexes -filter *.idx | Select-Object Name

   foreach ($ScriptFileObj in $ScriptFileSet) 
   {
      $ScriptFileName = $ScriptFileObj.Name
      Write-Output "=> Executing the script '$ScriptRootPath\MISC_Scripts\DashboardReporting\Indexes\$ScriptFileName'" | out-file $LogFileName -append
      if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\MISC_Scripts\DashboardReporting\Indexes" $ScriptFileName $LogFileName)) 
      {
         #$dt = ShowCurrentTime -heading "FINISHED"
         #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
         #return $false
      }
   }  
   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating statistics supporting dashboard reporting IF NOT EXIST ..."  
   Set-Location -Path "$ScriptRootPath\MISC_Scripts\DashboardReporting"
   $ScriptFileSet=Get-ChildItem .\Statistics -filter *.sql | Select-Object Name

   foreach ($ScriptFileObj in $ScriptFileSet) 
   {
      $ScriptFileName = $ScriptFileObj.Name
      Write-Output "=> Executing the script '$ScriptRootPath\MISC_Scripts\DashboardReporting\Statistics\$ScriptFileName'" | out-file $LogFileName -append
      if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\MISC_Scripts\DashboardReporting\Statistics" $ScriptFileName $LogFileName)) 
      {
         #$dt = ShowCurrentTime -heading "FINISHED"
         #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
         #return $false
      }
   }
    
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating user-defined functions supporting dashboard reporting IF NOT EXIST ..."  
   Set-Location -Path "$ScriptRootPath\MISC_Scripts\DashboardReporting"
   $ScriptFileSet=Get-ChildItem .\UserDefinedFunctions -filter *.sql | Select-Object Name

   foreach ($ScriptFileObj in $ScriptFileSet) 
   {
      $ScriptFileName = $ScriptFileObj.Name
      Write-Output "=> Executing the script '$ScriptRootPath\MISC_Scripts\DashboardReporting\UserDefinedFunctions\$ScriptFileName'" | out-file $LogFileName -append
      if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\MISC_Scripts\DashboardReporting\UserDefinedFunctions" $ScriptFileName $LogFileName)) 
      {
         #$dt = ShowCurrentTime -heading "FINISHED"
         #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
         #return $false
      }
   }

   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating views supporting dashboard reporting IF NOT EXIST ..."  
   Set-Location -Path "$ScriptRootPath\MISC_Scripts\DashboardReporting"
   $ScriptFileSet = @()
   $ScriptFileSet += "v_CHGHISTORY_aud_cost_info.vu"
   $ScriptFileSet += "v_CHGHISTORY_aud_trade_item_info.vu"
   $ScriptFileSet += "v_CHGHISTORY_cost_info.vu"
   $ScriptFileSet += "v_CHGHISTORY_portfolio_info.vu"
   $ScriptFileSet += "v_CHGHISTORY_profit_center_tags.vu"
   $ScriptFileSet += "v_CHGHISTORY_trade_item_info.vu"
   $ScriptFileSet += "v_CHGHISTORY_uic_deletes.vu"
   $ScriptFileSet += "v_CHGHISTORY_uic_updates.vu"
   $ScriptFileSet += "v_BI_cmdty_mkt_detail.vu"
   $ScriptFileSet += "v_BI_cob_date.vu"
   $ScriptFileSet += "v_BI_commkt_formula.vu"
   $ScriptFileSet += "v_BI_portfolio.vu"
   $ScriptFileSet += "v_BI_position.vu"
   $ScriptFileSet += "v_BI_profit_loss.vu"
   $ScriptFileSet += "v_curve_source.vu"
   $ScriptFileSet += "v_allocation_detail.vu"
   $ScriptFileSet += "v_allocation_reach_detail.vu"
   $ScriptFileSet += "v_cost_search.vu"
   $ScriptFileSet += "v_get_conc_trade_detail.vu"
   $ScriptFileSet += "v_internal_trade_phys.vu"
   $ScriptFileSet += "v_portfolio_profit_loss.vu"
   $ScriptFileSet += "v_price_detail.vu"
   $ScriptFileSet += "v_uic_report.vu"
   $ScriptFileSet += "v_PLCOMP_cost_info.vu"
   $ScriptFileSet += "v_PLCOMP_portfolio_pl_info.vu"
   $ScriptFileSet += "v_PLCOMP_position_info.vu"
   $ScriptFileSet += "v_PLCOMP_TI_info.vu"
   $ScriptFileSet += "v_PLCOMP_trade_info.vu"
   $ScriptFileSet += "v_PLCOMP_trade_item_info.vu"
   $ScriptFileSet += "v_portfolio_division_info.vu"
   $ScriptFileSet += "v_POSGRID_base_corr.vu"
   $ScriptFileSet += "v_POSGRID_commkt_info.vu"
   $ScriptFileSet += "v_POSGRID_inv_position_info.vu"
   $ScriptFileSet += "v_POSGRID_pl_history.vu"
   $ScriptFileSet += "v_POSGRID_pl_detail.vu"
   $ScriptFileSet += "v_POSGRID_position_info.vu"
   $ScriptFileSet += "v_POSGRID_simple_formula_info.vu"
   $ScriptFileSet += "v_POSGRID_trade_item_info.vu"
   $ScriptFileSet += "v_POSGRID_risk_position.vu"
   $ScriptFileSet += "v_POSGRID_commkt_formula.vu"
   $ScriptFileSet += "v_POSGRID_price_detail.vu"
   $ScriptFileSet += "v_risk_commodity_group.vu"
   $ScriptFileSet += "v_SAP_cashforcast_view.vu"
   $ScriptFileSet += "v_SAP_voucher_detail.vu"
   $ScriptFileSet += "v_trade_detail.vu"
   $ScriptFileSet += "v_user_trading_entity_map.vu"
   $ScriptFileSet += "v_collateral.vu"

   foreach ($ScriptFileName in $ScriptFileSet) 
   {
      Write-Output "=> Executing the script '$ScriptRootPath\MISC_Scripts\DashboardReporting\Views\$ScriptFileName'" | out-file $LogFileName -append
      if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\MISC_Scripts\DashboardReporting\Views" $ScriptFileName $LogFileName)) 
      {
         #$dt = ShowCurrentTime -heading "FINISHED"
         #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
         #return $false
      }
   }

   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating stored procedures supporting dashboard reporting IF NOT EXIST ..."  
   Set-Location -Path "$ScriptRootPath\MISC_Scripts\DashboardReporting"
   $ScriptFileSet = @()
   $ScriptFileSet += "usp_save_dashboard_error.sp"
   $ScriptFileSet += "usp_actual_msds_update.sp"
   $ScriptFileSet += "usp_get_fx_data.sp"
   $ScriptFileSet += "usp_get_option_pl.sp"
   $ScriptFileSet += "usp_inventory_detail.sp"
   $ScriptFileSet += "usp_pl_comp_report.sp"
   $ScriptFileSet += "usp_position_grid.sp"
   $ScriptFileSet += "usp_update_allocation_nomqty.sp"
   $ScriptFileSet += "pl_summary_reports.sp"
   $ScriptFileSet += "usp_add_shipment_4_storage_trade.sp"
   $ScriptFileSet += "usp_add_allocation_4_storage_trade.sp"
   $ScriptFileSet += "usp_add_storage_trade.sp"
   $ScriptFileSet += "usp_add_storage_trade_without_template.sp"
   $ScriptFileSet += "usp_bulk_portfolio_Update_forTOI.sp"
   $ScriptFileSet += "usp_CHGHISTORY_get_search_filters.sp"
   $ScriptFileSet += "usp_CHGHISTORY_allocation_changed_report.sp"
   $ScriptFileSet += "usp_CHGHISTORY_cost_changed_report.sp"
   $ScriptFileSet += "usp_CHGHISTORY_trade_changed_report.sp"
   $ScriptFileSet += "usp_conc_m2m_report.sp"
   $ScriptFileSet += "usp_create_currency_trade.sp"
   $ScriptFileSet += "usp_get_COST_tags.sp"
   $ScriptFileSet += "usp_get_detailed_pl_diff.sp"
   $ScriptFileSet += "usp_get_inv_template_name.sp"
   $ScriptFileSet += "usp_get_pivot_output_for_an_entity.sp"
   $ScriptFileSet += "usp_get_PORTFOLIO_tags.sp"
   $ScriptFileSet += "usp_get_TRADE_ITEM_tags.sp"
   $ScriptFileSet += "usp_get_unpaid_voucher_details_dashboard.sp"
   $ScriptFileSet += "usp_PLCOMP_get_pl_details_for_a_cob_date.sp"
   $ScriptFileSet += "usp_PLCOMP_get_plhist_for_a_cob_date.sp"
   $ScriptFileSet += "usp_PLCOMP_get_tag_columns.sp"
   $ScriptFileSet += "usp_PLCOMP_pl_comparison_report.sp"
   $ScriptFileSet += "usp_PLCOMP_report_pl_delta.sp"
   $ScriptFileSet += "usp_PLCOMP_save_argument_values.sp"
   $ScriptFileSet += "usp_POSGRID_roll_COB_date.sp"
   $ScriptFileSet += "usp_POSGRID_apply_uom_conversion.sp"
   $ScriptFileSet += "usp_POSGRID_ETL_position_snapshot.sp"
   $ScriptFileSet += "usp_POSGRID_get_historical_position.sp"
   $ScriptFileSet += "usp_POSGRID_get_live_position.sp"
   $ScriptFileSet += "usp_POSGRID_show_position.sp"
   $ScriptFileSet += "usp_POSGRID_show_position_delta.sp"
   $ScriptFileSet += "usp_POSGRID_get_risk_position.sp"
   $ScriptFileSet += "usp_update_cost_exch_rate.sp"
   $ScriptFileSet += "usp_update_real_portfolio_forTOI.sp"
   $ScriptFileSet += "usp_realized_pl_by_shipment.sp"

   foreach ($ScriptFileName in $ScriptFileSet) 
   {
      Write-Output "=> Executing the script '$ScriptRootPath\MISC_Scripts\DashboardReporting\StoredProcedures\$ScriptFileName'" | out-file $LogFileName -append
      if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\MISC_Scripts\DashboardReporting\StoredProcedures" $ScriptFileName $LogFileName)) 
      {
         #$dt = ShowCurrentTime -heading "FINISHED"
         #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
         #return $false
      }
   }

   ShowAndSaveProgress -LogFileName $LogFileName -Message "Adding reference data supporting dashboard reporting IF NOT EXIST ..."  
   $ScriptFileSet = @()
   $ScriptFileSet += "dashboard_configuration_data.sql"
   $ScriptFileSet += "add_application_data.sql"
   $ScriptFileSet += "add_icts_function_data.sql"
   $ScriptFileSet += "add_function_detail_LEVEL_data.sql"

   foreach ($ScriptFileName in $ScriptFileSet)
   {
      if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\MISC_Scripts\DashboardReporting\ReferenceData" $ScriptFileName $LogFileName)) 
      {
         #$dt = ShowCurrentTime -heading "FINISHED"
         #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
         #return $false
      }
   }
   
   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED : $dt" | out-file $LogFileName -append
   return $true
} # CreateMainTables
