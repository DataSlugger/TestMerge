# **********************************************************************************************************
#  CreateTradeDbUsers.ps1
#     It calls Invoke-Sqlcmd to execute the following scripts in ..\Structure\Security folder
#        add_logins.sql
#        add_tradedb_users.sql
#     
#     Usage:
#        [bool]$status=CreateTradeDbUsers -Server <?>
#                                        -Auth <?>
#                                        -Login <?> 
#                                        -Password <?> 
#                                        -Database <?>
#                                        -ScriptRootPath <?>
#
#            Example: [bool]$status=CreateTradeDbUsers MYSQL10 
#                                                     {"SQL Server Authentication"} 
#                                                     dba 
#                                                     XXX
#                                                     TEST_amphora_trade
#                                                     "<path>"
#
#
#     Output: 
#        It returns either $true or $false:
#           $true    - The scripts were executed without errors
#           $false   - The scripts were executed with errors
#
#        LOG file: ..\Structure\Logs\create_standard_users.log  (produced by schema creation)
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************

function CreateTradeDbUsers
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath
   )

   $LogFileName = "$ScriptRootPath\Logs\create_standard_users.log"

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating ICTS TRADE database users ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName

   Write-Output "=> Executing the script '$ScriptRootPath\Security\add_logins.sql'" | out-file $LogFileName -append
   if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Security" "add_logins.sql" $LogFileName))
   {
      #$dt = ShowCurrentTime -heading "FINISHED"
      #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
      #return $false
   }

   Write-Output "=> Executing the script '$ScriptRootPath\Security\add_tradedb_users.sql'" | out-file $LogFileName -append
   if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\Security" "add_tradedb_users.sql" $LogFileName))
   {
      #$dt = ShowCurrentTime -heading "FINISHED"
      #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
      #return $false
   }

   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # CreateTradeDbUsers
