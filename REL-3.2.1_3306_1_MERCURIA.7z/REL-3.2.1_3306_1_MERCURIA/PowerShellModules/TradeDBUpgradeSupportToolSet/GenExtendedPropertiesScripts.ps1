# **********************************************************************************************************
#  GenExtendedPropertiesScripts.ps1
#     It executes the following scripts found in ..\Structure\MISC_Scripts folder
#        gen_add_extended_property_4_tables_script.sql
#        add_extended_property_4_tables.sql
#        gen_add_extended_property_4_views_script.sql
#        add_extended_property_4_views.sql
#        gen_add_extended_property_4_udfs_script.sql
#        add_extended_property_4_udfs.sql
#        gen_add_extended_property_4_procedures_script.sql
#        add_extended_property_4_procedures.sql
#     
#     Usage:
#        [bool]$status=GenExtendedPropertiesScripts -Server <?>
#                                                   -Auth <?>
#                                                   -Login <?> 
#                                                   -Password <?> 
#                                                   -Database <?>
#                                                   -ScriptRootPath <?>
#                                                   -Amode <?>     N - Create new ICTS TRADE schema, 
#                                                                  U - Upgrade ICTS TRADE schema
#
#            Example: [bool]$status=GenExtendedPropertiesScripts MYSQL10 
#                                                                {"SQL Server Authentication"} 
#                                                                dba 
#                                                                XXX
#                                                                TEST_amphora_trade
#                                                                "<path>"
#                                                                "N"
#
#
#     Output: 
#        It returns either $true or $false:
#           $true    - Scripts were created without errors
#           $false   - Scripts were created with errors
#
#        LOG file: ..\Structure\Logs\gen_scripts_4_add_extended_properties.log
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function GenExtendedPropertiesScripts
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath,
      [parameter(Mandatory=$false)] [string]$Amode = "N"
   )
   
   if ($Amode -eq "N") {$LogFileName = "$ScriptRootPath\Logs\gen_scripts_4_add_extended_properties.log"}
   else {$LogFileName = "$ScriptRootPath\Logs\u_gen_scripts_4_add_extended_properties.log"}

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Generating scripts to add extented properties for db objects ..."   
   
   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName

   $GenScriptFileName="gen_add_extended_property_4_tables_script.sql"
   $AddScriptFileName="add_extended_property_4_tables.sql"
   $FullGenScriptFileName = "$ScriptRootPath\MISC_Scripts\$GenScriptFileName"
   $FullAddScriptFileName = "$ScriptRootPath\MISC_Scripts\$AddScriptFileName"
   if ($show_dbscript) {Write-Host "=> Executing the '$GenScriptFileName' script ..."}
   Write-Output "=> Executing the '$GenScriptFileName' script script ..." | Out-File $LogFileName -append 
   try
   {
      if ($Auth -eq "Windows Authentication")
      {
         # Invoke-Sqlcmd -ServerInstance $Server -Database $Database -MaxCharLength 200 -InputFile "$FullGenScriptFileName" -ErrorVariable err1 -ErrorAction "SilentlyContinue" -verbose > "$FullAddScriptFileName"
         sqlcmd -S $Server -E -d $Database -w 200 -i $FullGenScriptFileName -o $FullAddScriptFileName
      }
      else
      {
         # The following Invoke-Sqlcmd won't work for PS v2 which does not like the use of a '&'
         #Invoke-Sqlcmd -ServerInstance $Server -Username $Login -Password $Password -Database $Database -MaxCharLength 200 -InputFile "$FullGenScriptFileName" -ErrorVariable err1 -ErrorAction "SilentlyContinue" -verbose 4>&1 > "$FullAddScriptFileName"
      
         # The Start-Process will popup a DOS terminal which I don't like
         #Start-Process -FilePath "SQLCMD.exe" -Wait -RedirectStandardOutput "$FullAddScriptFileName" -Passthru -ArgumentList " -S $Server -U $Login -P $Password -d $Database -w 200 -i $FullGenScriptFileName"

         # sqlcmd works for any version of PS. However, it requires to install sqlcmd.exe
         sqlcmd -S $Server -U $Login -P $Password -d $Database -w 200 -i $FullGenScriptFileName -o $FullAddScriptFileName
      }
      #if ($err1)
      #{
      #   Write-Host "==> Failed to execute the script '$GenScriptFileName'"
      #   Write-Output "==> Failed to execute the script '$GenScriptFileName'" | out-file $LogFileName -append
      #   $err1 | out-file $LogFileName -append
      #}
   }
   catch
   {
      $ErrorMessage = $_.Exception.Message
      Write-Host "==> Failed to execute the script '$GenScriptFileName' due to the ERROR: $ErrorMessage"
      Write-Output "==> Failed to execute the script '$GenScriptFileName' due to the ERROR: $ErrorMessage" | out-file $LogFileName
      $dt = ShowCurrentTime -heading "FINISHED"
      Write-Output "FINISHED: $dt" | out-file $LogFileName
      return $false
   }

   $GenScriptFileName="gen_add_extended_property_4_views_script.sql"
   $AddScriptFileName="add_extended_property_4_views.sql"
   $FullGenScriptFileName = "$ScriptRootPath\MISC_Scripts\$GenScriptFileName"
   $FullAddScriptFileName = "$ScriptRootPath\MISC_Scripts\$AddScriptFileName"
   if ($show_dbscript) {Write-Host "=> Executing the '$GenScriptFileName' script ..."}
   Write-Output "=> Executing the '$GenScriptFileName' script ..." | Out-File $LogFileName -append 
   try
   {
      if ($Auth -eq "Windows Authentication")
      {
         sqlcmd -S $Server -E -d $Database -w 200 -i $FullGenScriptFileName -o $FullAddScriptFileName
      }
      else
      {
         sqlcmd -S $Server -U $Login -P $Password -d $Database -w 200 -i $FullGenScriptFileName -o $FullAddScriptFileName
      }
      #if ($err1)
      #{
      #   Write-Host "==> Failed to execute the script '$GenScriptFileName'"
      #   Write-Output "==> Failed to execute the script '$GenScriptFileName'" | out-file $LogFileName -append
      #   $err1 | out-file $LogFileName -append
      #}
   }
   catch
   {
      $ErrorMessage = $_.Exception.Message
      Write-Host "==> Failed to execute the script '$GenScriptFileName' due to the ERROR: $ErrorMessage"
      Write-Output "==> Failed to execute the script '$GenScriptFileName' due to the ERROR: $ErrorMessage" | out-file $LogFileName -append
      $dt = ShowCurrentTime -heading "FINISHED"
      Write-Output "FINISHED: $dt" | out-file $LogFileName -append
      return $false
   }

   $GenScriptFileName="gen_add_extended_property_4_udfs_script.sql"
   $AddScriptFileName="add_extended_property_4_udfs.sql"
   $FullGenScriptFileName = "$ScriptRootPath\MISC_Scripts\$GenScriptFileName"
   $FullAddScriptFileName = "$ScriptRootPath\MISC_Scripts\$AddScriptFileName"
   if ($show_dbscript) {Write-Host "=> Executing the '$GenScriptFileName' script ..."}
   Write-Output "=> Executing the '$GenScriptFileName' script ..." | Out-File $LogFileName -append 
   try
   {
      if ($Auth -eq "Windows Authentication")
      {
         sqlcmd -S $Server -E -d $Database -w 200 -i $FullGenScriptFileName -o $FullAddScriptFileName
      }
      else
      {
         sqlcmd -S $Server -U $Login -P $Password -d $Database -w 200 -i $FullGenScriptFileName -o $FullAddScriptFileName
      }
      #if ($err1)
      #{
      #   Write-Host "==> Failed to execute the script '$GenScriptFileName'"
      #   Write-Output "==> Failed to execute the script '$GenScriptFileName'" | out-file $LogFileName -append
      #   $err1 | out-file $LogFileName -append
      #}
   }
   catch
   {
      $ErrorMessage = $_.Exception.Message
      Write-Host "==> Failed to execute the script '$GenScriptFileName' due to the ERROR: $ErrorMessage"
      Write-Output "==> Failed to execute the script '$GenScriptFileName' due to the ERROR: $ErrorMessage" | out-file $LogFileName -append
      $dt = ShowCurrentTime -heading "FINISHED"
      Write-Output "FINISHED: $dt" | out-file $LogFileName -append
      return $false
   }

   $GenScriptFileName="gen_add_extended_property_4_procedures_script.sql"
   $AddScriptFileName="add_extended_property_4_procedures.sql"
   $FullGenScriptFileName = "$ScriptRootPath\MISC_Scripts\$GenScriptFileName"
   $FullAddScriptFileName = "$ScriptRootPath\MISC_Scripts\$AddScriptFileName"
   if ($show_dbscript) {Write-Host "=> Executing the '$GenScriptFileName' script ..."}
   Write-Output "=> Executing the '$GenScriptFileName' script ..." | Out-File $LogFileName -append 
   try
   {
      if ($Auth -eq "Windows Authentication")
      {
         sqlcmd -S $Server -E -d $Database -w 200 -i $FullGenScriptFileName -o $FullAddScriptFileName
      }
      else
      {
         sqlcmd -S $Server -U $Login -P $Password -d $Database -w 200 -i $FullGenScriptFileName -o $FullAddScriptFileName
      }
      #if ($err1)
      #{
      #   Write-Host "==> Failed to execute the script '$GenScriptFileName'"
      #   Write-Output "==> Failed to execute the script '$GenScriptFileName'" | out-file $LogFileName -append
      #   $err1 | out-file $LogFileName -append
      #}
   }
   catch
   {
      $ErrorMessage = $_.Exception.Message
      Write-Host "==> Failed to execute the script '$GenScriptFileName' due to the ERROR: $ErrorMessage"
      Write-Output "==> Failed to execute the script '$GenScriptFileName' due to the ERROR: $ErrorMessage" | out-file $LogFileName -append
      $dt = ShowCurrentTime -heading "FINISHED"
      Write-Output "FINISHED: $dt" | out-file $LogFileName -append
      return $false
   }
   
   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED: $dt" | out-file $LogFileName -append
   return $true
} # GenExtendedPropertiesScripts

