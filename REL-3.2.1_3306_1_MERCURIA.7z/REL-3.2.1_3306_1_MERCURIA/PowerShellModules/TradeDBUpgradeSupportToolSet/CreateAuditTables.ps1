# **********************************************************************************************************
#  CreateAuditTables.ps1
#     It calls Invoke-Sqlcmd to execute db scripts scripts (*.tbl) found in ..\Structure\AuditTables folder
#     to create audit tables as part of ICTS trade schema
#     
#     Usage:
#        [bool]$status = CreateAuditTables -Server <?>
#                                          -Auth <?>
#                                          -Login <?> 
#                                          -Password <?> 
#                                          -Database <?>
#                                          -ScriptRootPath <?>
#
#            Example: [bool]$status = CreateAuditTables MYSQL10 
#                                                       {"SQL Server Authentication"} 
#                                                       dba 
#                                                       XXX
#                                                       TEST_amphora_trade
#                                                       "<path>"
#
#
#     Output: 
#        It returns either $true or $false:
#           $true    - Tables were created without errors
#           $false   - Tables were created with errors
#
#        LOG file: ..\Structure\Logs\create_audit_tables.log (produced by schema creation)
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  12/13/2017
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function CreateAuditTables
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath
   )
   
   $LogFileName = "$ScriptRootPath\Logs\create_audit_tables.log"

   ShowAndSaveProgress -LogFileName $LogFileName -Message " "   
   ShowAndSaveProgress -LogFileName $LogFileName -Message "Creating audit tables ..."   

   $dt = ShowCurrentTime -heading "STARTED "
   Write-Output "STARTED : $dt" | out-file $LogFileName
   Set-Location -Path $ScriptRootPath
   $ScriptFileSet=Get-ChildItem .\AuditTables -filter *.tbl | Select-Object Name

   foreach ($ScriptFileObj in $ScriptFileSet) 
   {
      if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\AuditTables" $ScriptFileObj.Name $LogFileName))
      {
         #$dt = ShowCurrentTime -heading "FINISHED"
         #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
         #return $false
      }
   }

   $ScriptFileSet=Get-ChildItem .\AuditTables\ForAppLauncher -filter *.tbl | Select-Object Name

   foreach ($ScriptFileObj in $ScriptFileSet) 
   {
      if (!(ExecDBScript $Server $Auth $Login $Password $Database "$ScriptRootPath\AuditTables\ForAppLauncher" $ScriptFileObj.Name $LogFileName))
      {
         #$dt = ShowCurrentTime -heading "FINISHED"
         #Write-Output "FINISHED : $dt" | out-file $LogFileName -append
         #return $false
      }
   }

   $dt = ShowCurrentTime -heading "FINISHED"
   Write-Output "FINISHED : $dt" | out-file $LogFileName -append
   return $true
} # CreateAuditTables
