# **********************************************************************************************************
#  ColumnIsNullable.ps1
#     It returns the current data type of the given column
#     
#     Usage:
#        [bool]$NullableFlag=ColumnIsNullable -ConnString <?>
#                                             -SchemaName <?>
#                                             -TableName <?>
#                                             -ColumnName <?>
#
#            Example: [bool]$NullableFlag=ColumnIsNullable -ConnString ".." 
#                                                          -SchemaName "dbo"
#                                                          -TableName "acount"
#                                                          -ColumnName "acct_status"
#
#     Output:
#        A string indicates whether the given column is a nullable column or now
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  05/16/2016
#   Last Edited By       : Peter Lo  05/16/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function ColumnIsNullable
{
   Param([string]$ConnString, 
         [string]$SchemaName="dbo",
         [string]$TableName,
         [string]$ColumnName)

   $TableExists = (TableExists -ConnString $ConnString -SchemaName $SchemaName -TableName $TableName)
   if (!($TableExists)) {return "TABLE_DOES_NOT_EXIST"}

   $ColumnStatus = (ColumnExists -ConnString $ConnString -SchemaName $SchemaName -TableName $TableName -ColumnName $ColumnName)
   if ($ColumnStatus -eq "NO") {return "COLUMN_DOES_NOT_EXIST"}
   
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnString
   $conn.Open()
   $sql = "select convert(bit, columnproperty(object_id('$SchemaName.$TableName', 'U'), '$ColumnName', 'AllowsNull'))"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   [bool]$ColNullable=$false
   [bool]$ColNullable=$rdr[0]
   $rdr.Close()
   $conn.Close()
   if ($ColNullable -eq $true)
   {
      return "YES"
   }
   else
   {
      return "NO"
   }
} #ColumnIsNullable
