# **********************************************************************************************************
#  ExitOnError.ps1
#     It prompts a confirmation message asking you if you want to proceed or exit in case of error. 
#     
#     Usage:
#        [bool]$status=ExitOnError
#
#     Output:
#        It returns either $true or $false:
#           $true    - Yes, exit immediately
#           $false   - No, I want to continue
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function ExitOnError
{
   write-host " "
   do {
      $Answer = Read-Host -Prompt 'If errors occurred, do you want to exit immediately (Yes or No)?'
      $Answer = $Answer.ToUpper()
   } until ($Answer.StartsWith("Y") -Or $Answer.StartsWith("N"))
   
   if ($Answer.StartsWith("Y"))
   {
      return $true
   }
   else
   {
      return $false
   }
   
} #ExitOnError
