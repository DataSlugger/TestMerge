# **********************************************************************************************************
#  ColumnsAreInDesiredOrder.ps1
#     It tells if the column2 is right after column1 within the given table
#     
#     Usage:
#        [string]$state=ColumnsAreInDesiredOrder -ConnString <?>
#                                                -SchemaName <?>
#                                                -TableName <?>
#                                                -ColumnName1 <?>
#                                                -ColumnName2 <?>
#
#            Example: [string]$state=ColumnsAreInDesiredOrder -ConnString ".."
#                                                             -SchemaName "dbo"
#                                                             -TableName "account"
#                                                             -ColumnName1 "acct_num"
#                                                             -ColumnName2 "acct_status"
#
#     Output:
#        The resturned status string can be
#           TABLE_DOES_NOT_EXIST indicates that the given table is invalid
#           COLUMN_1_DOES_NOT_EXIST indicates that the given column1 does not exist 
#           COLUMN_2_DOES_NOT_EXIST indicates that the given column2 does not exist 
#           YES indicates that the columns are in correct order
#           NO indicates that the columns are NOT in correct order
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function ColumnsAreInDesiredOrder
{
   Param([string]$ConnString, 
         [string]$SchemaName="dbo",
         [string]$TableName,
         [string]$ColumnName1,
         [string]$ColumnName2)

   $TableExists = (TableExists -ConnString $ConnString -SchemaName $SchemaName -TableName $TableName)
   if (!($TableExists)) {return "TABLE_DOES_NOT_EXIST"}

   $ColumnStatus = (ColumnExists -ConnString $ConnString -SchemaName $SchemaName -TableName $TableName -ColumnName $ColumnName1)
   if ($ColumnStatus -eq "COLUMN_DOES_NOT_EXIST") {return "COLUMN_1_DOES_NOT_EXIST"}

   $ColumnStatus = (ColumnExists -ConnString $ConnString -SchemaName $SchemaName -TableName $TableName -ColumnName $ColumnName2)
   if ($ColumnStatus -eq "COLUMN_DOES_NOT_EXIST") {return "COLUMN_2_DOES_NOT_EXIST"}
   
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnString
   $conn.Open()
   $sql = "select column_id from sys.columns where object_id = OBJECT_ID('$SchemaName.$TableName') and name = '$ColumnName1'"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   [int]$ColumnID1=0
   $ColumnID1=$rdr[0]
   $rdr.Close()

   $sql = "select column_id from sys.columns where object_id = OBJECT_ID('$SchemaName.$TableName') and name = '$ColumnName2'"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   [int]$ColumnID2=0
   $ColumnID2=$rdr[0]      
   $rdr.Close()
   $conn.Close()
   if ($ColumnID2 -gt $ColumnID1)
   {
      return "YES"
   }
   else
   {
      return "NO"
   }
} #ColumnsAreInDesiredOrder
