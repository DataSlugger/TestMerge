﻿function ImportSQLServerPSModule {

<#
.SYNOPSIS
    Imports the SQL Server PowerShell module.
 
.DESCRIPTION
    Import-MrSqlModule is a PowerShell function that imports the SQLPS PowerShell
    module (SQL Server 2012 and higher) or adds the SQL PowerShell snapin (SQL
    Server 2008 & 2008R2).
 
.EXAMPLE
     Import-MrSqlModule
 
.NOTES
    Author:  Mike F Robbins
    Website: http://mikefrobbins.com
    Twitter: @mikefrobbins
    
    Be aware that "Import-Module sqlps" changes the location. 
    You must so get and set back the location when importing 
    the module. Example:
        Push-Location
        Import-Module -Name SQLPS -DisableNameChecking
        Pop-Location
#>

    [CmdletBinding()]
    param ()

    if (-not(Get-Module -Name SQLServer)) {
       Write-Verbose -Message 'SQLServer PowerShell module not currently loaded'

       if (Get-Module -Name SQLServer -ListAvailable) {
          Write-Verbose -Message 'SQLServer PowerShell module found'

          Push-Location
          Write-Verbose -Message "Storing the current location: '$((Get-Location).Path)'"

          if ((Get-ExecutionPolicy) -ne 'Restricted') {
             # use 3>$Null to suppress to the warning message like
             #   WARNING: The local compueter does not have an active instance of Alalysis Services
             Import-Module -Name SQLServer -DisableNameChecking -Verbose:$false  3>$Null
             Write-Host 'SQLServer PowerShell module successfully imported'
             Write-Verbose -Message 'SQLServer PowerShell module successfully imported'
          }
          else {
              Write-Warning -Message 'The SQLServer PowerShell module cannot be loaded with an execution policy of restricted'
          }
            
          Pop-Location
          Write-Verbose -Message "Changing current location to previously stored location: '$((Get-Location).Path)'"
       }
	   else {
          Write-Verbose -Message 'Unable to get SQL Server module info'
       }
    }
    else {
        Write-Host 'SQLServer PowerShell module or snapin already loaded'
        Write-Verbose -Message 'SQLServer PowerShell module or snapin already loaded'
    }

}