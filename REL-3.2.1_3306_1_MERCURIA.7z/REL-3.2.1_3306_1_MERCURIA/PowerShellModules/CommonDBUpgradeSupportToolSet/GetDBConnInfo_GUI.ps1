# *****************************************************************************************
#   GetDBConnInfo_GUI.ps1
#      It displays a GUI screen to collect db connection info which includes
#         server name, Authentication, Login, and password
#
#     Usage:
#        GetDBConnInfo_GUI 
# -----------------------------------------------------------------------------------------
#     Output: 
#        It returns an array containing the following elements:
#            Element #1: <Server instance>
#            Element #2: SQL Server Authentication or Windows Authentication
#            Element #3: Login if SQL Server Authentication was selected
#            Element #4: Password if SQL Server Authentication was selected
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# *****************************************************************************************
function GetDBConnInfo_GUI
{
   $script:Login=$Null 
   $script:Password=$Null 
   $script:Server=$Null 
   $script:Authentication=$Null 
   $script:Action="OK"
   
   $myArray = @()

   $objForm = New-Object System.Windows.Forms.Form 
   $objForm.Text = "Database Access Credential"
   $objForm.Size = New-Object System.Drawing.Size(440,300) 
   $objForm.StartPosition = "CenterScreen"

   $objForm.KeyPreview = $true
   $objForm.Add_KeyDown({if ($_.KeyCode -eq "Enter") 
       {$script:Server=$objTextBoxServerName.Text;$script:Authentication=$objComboBoxAuthentication.Text;$script:Login=$objTextBoxLogin.Text;$script:Password=$objTextBoxPassword.Text;$objForm.Close()}})
$objForm.Add_KeyDown({if ($_.KeyCode -eq "Escape") 
       {$objForm.Close()}})

   #----------------------------------------------
   #Generated Event Script Blocks
   #----------------------------------------------
   #region $handler_objComboBoxAuthentication_SelectedIndexChanged
   $handler_objComboBoxAuthentication_SelectedIndexChanged=
   {
      if ($objComboBoxAuthentication.Text -eq "Windows Authentication")
      {
         # DEBUG: write-host "Disabling login and password data entries"
		     $objTextBoxLogin.ReadOnly = $true
         $objTextBoxPassword.ReadOnly = $true
		     $objTextBoxLogin.Text = ""
         $objTextBoxPassword.Text = ""
      }
      else
      {
         # DEBUG: write-host "Enabling login and password data entries"
		     $objTextBoxLogin.ReadOnly = $false
         $objTextBoxPassword.ReadOnly = $false
      }
   }
   #endregion $handler_objComboBoxAuthentication_SelectedIndexChanged
    
   # Setup OK button
   $OKButton = New-Object System.Windows.Forms.Button
   $OKButton.Location = New-Object System.Drawing.Size(137, 220)
   $OKButton.Size = New-Object System.Drawing.Size(75,30)
   $OKButton.Text = "OK"
   $OKButton.Add_Click(
       {$script:Server=$objTextBoxServerName.Text;$script:Authentication=$objComboBoxAuthentication.Text;$script:Login=$objTextBoxLogin.Text;$script:Password=$objTextBoxPassword.Text;$objForm.Close()})
   $objForm.Controls.Add($OKButton)

   # Setup CANCEL button
   $CancelButton = New-Object System.Windows.Forms.Button
   $CancelButton.Location = New-Object System.Drawing.Size(223,220)
   $CancelButton.Size = New-Object System.Drawing.Size(75,30)
   $CancelButton.Text = "Cancel"
   $CancelButton.Add_Click({$script:Action="CANCEL";$objForm.Close()})
   $objForm.Controls.Add($CancelButton)

   # Setup Label for the ServerName data entry
   $objLabelServerName = New-Object System.Windows.Forms.Label
   $objLabelServerName.Location = New-Object System.Drawing.Size(30,33) 
   $objLabelServerName.Size = New-Object System.Drawing.Size(80,13) 
   $objLabelServerName.Text = "Server Name:"
   $objForm.Controls.Add($objLabelServerName) 

   # Setup ServerName TextBox
   $objTextBoxServerName = New-Object System.Windows.Forms.TextBox 
   $objTextBoxServerName.Location = New-Object System.Drawing.Size(140,33) 
   $objTextBoxServerName.Size = New-Object System.Drawing.Size(260,20)
   $objTextBoxServerName.TabIndex = 0
   $objForm.Controls.Add($objTextBoxServerName)
   $objTextBoxServerName.Select()

   # Setup Label for the Authentication ComboBox
   $objLabelAuthentication = New-Object System.Windows.Forms.Label
   $objLabelAuthentication.Location = New-Object System.Drawing.Size(30,60) 
   $objLabelAuthentication.Size = New-Object System.Drawing.Size(80,13) 
   $objLabelAuthentication.Text = "Authentication:"
   $objForm.Controls.Add($objLabelAuthentication) 

   # Setup Authentication ComboBox
   $objComboBoxAuthentication = New-Object System.Windows.Forms.ComboBox 
   $ComboBoxOptions = "Windows Authentication", "SQL Server Authentication";
   $objComboBoxAuthentication.Items.AddRange($ComboBoxOptions);
   $objComboBoxAuthentication.SelectedIndex = 0;
   $objComboBoxAuthentication.Location = New-Object System.Drawing.Size(140,60) 
   $objComboBoxAuthentication.Size = New-Object System.Drawing.Size(260,20)
   $objComboBoxAuthentication.TabIndex = 1
   $objComboBoxAuthentication.add_SelectedIndexChanged($handler_objComboBoxAuthentication_SelectedIndexChanged)
   $objForm.Controls.Add($objComboBoxAuthentication)

   # Setup Label for the Login data entry
   $objLabelLogin = New-Object System.Windows.Forms.Label
   $objLabelLogin.Location = New-Object System.Drawing.Size(35,87) 
   $objLabelLogin.Size = New-Object System.Drawing.Size(80,13) 
   $objLabelLogin.Text = "Login:"
   $objForm.Controls.Add($objLabelLogin) 

   # Setup Login TextBox
   $objTextBoxLogin = New-Object System.Windows.Forms.TextBox 
   $objTextBoxLogin.Location = New-Object System.Drawing.Size(140,87) 
   $objTextBoxLogin.Size = New-Object System.Drawing.Size(260,20)
   $objTextBoxLogin.TabIndex = 2
   $objTextBoxLogin.ReadOnly = $true
   $objForm.Controls.Add($objTextBoxLogin)

   # Setup Label for the Password data entry
   $objLabelPassword = New-Object System.Windows.Forms.Label
   $objLabelPassword.Location = New-Object System.Drawing.Size(35,114) 
   $objLabelPassword.Size = New-Object System.Drawing.Size(80,13) 
   $objLabelPassword.Text = "Password:"
   $objForm.Controls.Add($objLabelPassword) 

   # Setup Password TextBox
   $objTextBoxPassword = New-Object System.Windows.Forms.TextBox 
   $objTextBoxPassword.Location = New-Object System.Drawing.Size(140,114) 
   $objTextBoxPassword.Size = New-Object System.Drawing.Size(260,20)
   $objTextBoxPassword.UseSystemPasswordChar = $True;
   $objTextBoxPassword.TabIndex = 3
   $objTextBoxPassword.ReadOnly = $true
   $objForm.Controls.Add($objTextBoxPassword)

   $objForm.Topmost = $True
   $objForm.Add_Shown({$objForm.Activate()})
   [void] $objForm.ShowDialog()

   if ($Action -eq "CANCEL")
   {
      $script:Server="@@@"
      $myArray += "@@@"
      $myArray += "@@@"
      $myArray += "@@@"
      $myArray += "@@@"      
      return $myArray
   }

   if ($Authentication -eq "Windows Authentication")
   {
      if ($Server)
      {
         # DEBUG
         # Write-Host "Server Name    :" $Server
         # Write-Host "Authentication :" $Authentication
         try
         {
            $conn = New-Object System.Data.SqlClient.SqlConnection
            $conn.ConnectionString = "Server=$Server;Database=master;Integrated Security=True"
            $conn.open()
            Write-Host "Logon is OK"
            $conn.Close()
            $myArray += $Server
            $myArray += $Authentication
            $myArray += "@@@"
            $myArray += "@@@"
            return $myArray
         }
         catch
         {
            $ErrorMessage = $_.Exception.Message
            Write-Host "Unable to login into the '$Server' db server. Please check your inputs for Server, Login, and Password!"
            #Write-Host "ERROR: $ErrorMessage"
            $script:Server="@@@"
            $myArray += "@@@"
            $myArray += "@@@"
            $myArray += "@@@"
            $myArray += "@@@"
            return $myArray
         }
      }
      else
      {
         Write-Host "Missing input for Server Name!"
         $myArray += "@@@"
         $myArray += "@@@"
         $myArray += "@@@"
         $myArray += "@@@"
         return $myArray
      }
   }
   else
   {
      if ($Login -and $Password -and $Server)
      {
         # DEBUG
         # Write-Host "Server Name    :" $Server
         # Write-Host "Authentication :" $Authentication
         # Write-Host "Login          :" $Login
         # Write-Host "Password       :" $Password
         try
         { 
            $conn = New-Object System.Data.SqlClient.SqlConnection
            $conn.ConnectionString = "Server=$Server;Database=master;User=$Login;Password=$Password;Integrated Security=False"
            $conn.open()
            Write-Host "Logon is OK"
            $conn.Close()
            $myArray += $Server
            $myArray += $Authentication
            $myArray += $Login
            $myArray += $Password
            return $myArray
         }
         catch
         {
            $ErrorMessage = $_.Exception.Message
            Write-Host "Failed to login into the '$Server' db server. Please check your inputs for Server, Login, and Password!"
            #Write-Host "ERROR: $ErrorMessage"
            $script:Server="@@@"
            $myArray += "@@@"
            $myArray += "@@@"
            $myArray += "@@@"
            $myArray += "@@@"
            return $myArray
         }  
      }
      else
      {
         Write-Host "Missing inputs for Server Name/Login/Password!"
         $script:Server="@@@"
         $myArray += "@@@"
         $myArray += "@@@"
         $myArray += "@@@"
         $myArray += "@@@"
         return $myArray
      }
  }
}
