# **********************************************************************************************************
#  BCPInData.ps1
#     
#     Usage:
#        [bool]$status=BCPInData -Server <Server Instance> 
#                                -Auth {"SQL Server Authentication" or "Windows Authentication"}
#                                -Login <login>
#                                -Password <pwd>
#                                -Database <name of trade db> 
#
#      Example: [bool]$status=BCPInData -Server "MYSQL10"
#                                       -Auth {"SQL Server Authentication"}
#                                       -Login "dba"
#                                       -Password "XXX"
#                                       -Database "TEST_amphora_trade" 
#  ---------------------------------------------------------------------------------------------------------
#  This function uses the BCP utility to load data into a table
#   
#     bcp <dbname>.dbo.<table> in <bcp data file> <switches> -S <server> -U <login> -P <pwd>
#     OR
#     bcp <dbname>.dbo.<table> in <bcp data file> <switches> -S <server> -T
#
#   This function supports the following BCP command switches (fOR argument $BcpSwitches):
#      -c -t <field terminator> -b <batch_size> -E      for character type
#      -n -b <batch_size> -E                            for native type
#      -w -b <batch_size> -E                            for unicode type
#
#   Here, -E is an option. It is used for the table which has an IDENTITY column. If you want
#   BCP to keep IDENTITY value, then use this switch.
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function BCPInData
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$TableName,
      [parameter(Mandatory=$true)]  [string]$BcpFullFileName,
      [parameter(Mandatory=$true)]  [string]$BcpSwitches,      
      [parameter(Mandatory=$true)]  [string]$LogFileName
   )
   
   if ($show_dbscript) {Write-Host "=> Loading data from the BCP file '$BCPFullFileName' ..."}
   #Write-Output "=> Loading data from the BCP file '$BCPFullFileName' ..." | Out-File $LogFileName -append 

   # Here, we want to find out the path for the bcp.exe
   $RootDirectory = "@@@"
   $FileExists = Test-Path "C:\Program Files\Microsoft SQL Server"
   if ($FileExists -eq $true) {$RootDirectory = "C:\Program Files\Microsoft SQL Server"}
         
   if ($RootDirectory -eq "@@@")
   {
      $FileExists = Test-Path "C:\Program Files (x86)\Microsoft SQL Server"
      if ($FileExists -eq $true) {$RootDirectory = "C:\Program Files (x86)\Microsoft SQL Server"}
   }
         
   if ($RootDirectory -eq "@@@")
   {
      write-host "Could not find the SQL Server system directory!"
      return $false
   }
                  
   $pathes=Get-ChildItem -path $RootDirectory -Filter bcp.exe -Recurse -EA SilentlyContinue | select Directory
   [string]$apath = $pathes[0]
         
   # At this point, the $apath contains the string like "@{Directory=C:\Program Files\Microsoft SQL Server\100\Tools\Binn}"
   $apath = $apath.Replace('@{Directory=', '')
   $apath = $apath.Replace('}', '')
   $bcputil = "$apath\bcp.exe"

   $bcpargs=@()        
   if ($Auth -eq "Windows Authentication")
   {
      $bcpargs += "$Database.dbo.$TableName"                     # Element #0
      $bcpargs += "in"                                           
      $bcpargs += "$BCPFullFileName"                             # Element #2
      $BcpSwitches.Split(" ") | ForEach {$bcpargs += $_}
      $bcpargs += "$BcpSwitches"                                 
      $bcpargs += "-S"                                           
      $bcpargs += "$Server"                                      
      $bcpargs += "-T"                                           
   }
   else
   {
      $bcpargs += "$Database.dbo.$TableName"                     # Element #0
      $bcpargs += "in"                                           
      $bcpargs += "$BCPFullFileName"                             # Element #2
      $BcpSwitches.Split(" ") | ForEach {$bcpargs += $_}
      $bcpargs += "-S"                                           
      $bcpargs += "$Server"                                      
      $bcpargs += "-U"                                           
      $bcpargs += "$Login"                                       
      $bcpargs += "-P"                                           
      $bcpargs += "$Password"                                    
   }
   
   & $bcputil $bcpargs | Out-File $LogFileName -append
   return $true
} #BCPInData
  
   
