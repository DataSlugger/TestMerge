# **********************************************************************************************************
#  Pause.ps1
#     It executes a TSQL script by using Invoke-Sqlcmd method to implement a pause 
#     
#     Usage:
#        Pause
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************

function Pause
{
   write-host " "
   write-host "Press any key to continue ..."
   cmd /c pause | out-null
   
   # OR, use $x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
} #Pause