# **********************************************************************************************************
#  TestDBConnection.ps1
#     It returns a status indicating if we can use the collected db connection info to access
#     database 
#     
#     Usage:
#        [bool]$ConnOK=TestDBConnection -S <?>
#                                       -AUTH <?>
#                                       -U <?>
#                                       -P <?>
#                                       -D <?>
#
#            Example: [bool]$ConnOK=TestDBConnection -S "MYSQL10" 
#                                                    -AUTH {"SQL Server Authentication"}
#                                                    -U "dba" 
#                                                    -P "XXX" 
#                                                    -D "TEST_amphora_trade"
#
#     Output:
#        The returned $true or $false
#           $true indicating the db onnection is OK
#           $false indicates  the db onnection is NOT OK
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function TestDBConnection
{
   Param(
      [string]$S,
      [string]$AUTH,
      [string]$U,
      [string]$P,
      [string]$D
   )

   $Server=$S
   $Login=$U
   $Password=$P
   $Database=$D
   $DebugOn=$false

   if ($DebugON)
   {
      Write-Host "DEBUG (TestDBConnection): Server is '$Server'"
      Write-Host "DEBUG (TestDBConnection): Authentication is '$AUTH'"
      Write-Host "DEBUG (TestDBConnection): Login is '$Login'"
      Write-Host "DEBUG (TestDBConnection): Password is '$Password'"
      Write-Host "DEBUG (TestDBConnection): Database is '$Database'"
      Write-Host " "
   }
   
   # We want to make sure if we can open a db connection
   if ($AUTH -eq "Windows Authentication")
   {
      $ConnStr="Server=$Server;Database=$Database;Integrated Security=True"
   }
   else
   {
      $ConnStr="Server=$Server;Database=$Database;User=$Login;Password=$Password;Integrated Security=False"
   }
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnStr
   try
   {
      $conn.Open()
   }
   catch
   {
      $ErrorMessage = $_.Exception.Message
      write-host "Unable to open a db connection due to the error: $ErrorMessage"
      return $false
   }
   $conn.Close()
   Write-Host "Database Connection is OK"

   return $true
}