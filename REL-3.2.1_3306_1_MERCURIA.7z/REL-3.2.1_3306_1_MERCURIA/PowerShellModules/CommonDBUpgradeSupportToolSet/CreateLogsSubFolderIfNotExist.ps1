# **********************************************************************************************************
#  CreateLogsSubFolderIfNotExist.ps1
#     It checks whether the subfolder 'Logs' exists. If not, create it. Otherwise,
#     remove all existing log files in this folder
#
#   Usage: CreateLogsSubFolderIfNotExist $ScriptRootPath
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function CreateLogsSubFolderIfNotExist
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath
   )
   
   # Create the subfolder "Logs" if it does not exist
   # Write-host "CreateLogsSubFolderIfNotExist: The script set root path is '$ScriptRootPath'!"
   Set-Location $ScriptRootPath
   $path = "Logs"
   if (!(Test-Path -Path $path))
   {
      Write-host "The subfolder 'Logs' does not exist, create it!"
      New-Item $path -type directory > $null
      if (Test-Path -Path $path)
      {
         Write-host "The subfolder 'Logs' was created successfully!"
      } 
      else
      {
         Write-host "Failed to create the subfolder 'Logs'!"        
      }
   }
   else
   {
      # Removing old log files left from previous session
      Write-host "Removing log files left in the subfolder 'Logs'!"
      Remove-Item $ScriptRootPath\Logs\* -include *.log > $null
   }
} # CreateLogsSubFolderIfNotExist
