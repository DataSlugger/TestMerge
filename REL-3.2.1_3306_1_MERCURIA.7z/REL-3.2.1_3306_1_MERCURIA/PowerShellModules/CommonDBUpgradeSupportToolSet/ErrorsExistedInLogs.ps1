# **********************************************************************************************************
#  ErrorsExistedInLogs.ps1
#     It scans the log files in the Structure\Logs and report the files which contain
#     errors raised by SQL Server
#     
#     Usage:
#        ErrorsExistedInLogs -ScriptRootPath <?>
#
#     Output:
#        It displays a list of log files containing errors
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  07/06/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function ErrorsExistedInLogs
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$ScriptRootPath,
      [parameter(Mandatory=$false)] [string]$mode="N"      
   )
   
   Write-Host " "
   Write-Host "Scanning logs in the $ScriptRootPath\Logs subfolder ..."

   # OR, use this
   #   $TableScripts = Get-ChildItem .\Logs | Where-Object {$_.name -like "*.log"} | Foreach-Object {$_.Name}       

   Set-Location -Path $ScriptRootPath
   if ($mode -eq "N") {$TableScripts=Get-ChildItem .\Logs -filter *.log | Select-Object Name}
   else {$TableScripts=Get-ChildItem .\Logs -filter u_*.log | Select-Object Name}
   
   $LogContainingErrors = @()

   foreach ($LogFileObj in $TableScripts) 
   {
      $LogFileName = $LogFileObj.Name
      if ($show_dbscript) {Write-Host "=> Checking the log file '$LogFileName' ..."}
      $FullLogFileName = "$ScriptRootPath\Logs\$LogFileName"

      # ------------------------------------------------------------
      #    Scans the log file to find if any of the following
      #    substrings existed:
      #        "Unable to open input file"
      #        "SQL Server does not exist"
      #        "Cannot open input file"
      #        "Unable to establish database connection"
      #        "Unable to complete login process"  
      #        "An error occurred while processing the command line"             
      #        "> ERROR"
      #        "> Error" 
      #        "> Failed to"   
      #        "ERROR:"
      #        "Error:"         
      #        MS SQL Server's messages
      # ------------------------------------------------------------
      $matches = $false
      $matches = Select-String "Unable to open input file" $FullLogFileName
      if (!($matches)) {$matches = Select-String "SQL Server does not exist" $FullLogFileName}      
      if (!($matches)) {$matches = Select-String "Cannot open input file" $FullLogFileName}
      if (!($matches)) {$matches = Select-String "Unable to establish database connection" $FullLogFileName}
      if (!($matches)) {$matches = Select-String "Unable to complete login process" $FullLogFileName}                     
      if (!($matches)) {$matches = Select-String "An error occurred while processing the command line" $FullLogFileName}               
      if (!($matches)) {$matches = Select-String "> ERROR" $FullLogFileName}
      if (!($matches)) {$matches = Select-String "> Error" $FullLogFileName}
      if (!($matches)) {$matches = Select-String "ERROR:" $FullLogFileName}  
      if (!($matches)) {$matches = Select-String "Error:" $FullLogFileName}  
      if (!($matches)) {$matches = Select-String "> Failed to" $FullLogFileName}  
      if (!($matches)) {$matches = ((Select-String "Msg" $FullLogFileName) -and
                                    (Select-String ", Level" $FullLogFileName) -and
                                    (Select-String ", State" $FullLogFileName))} 
      if ($matches)
      {
         $LogContainingErrors += "$LogFileName"
      }    
   }

   Write-Host " "
   Write-Host " "
   if ($LogContainingErrors.count -gt 0)
   {
      Write-Host -ForegroundColor Red "The following log files contain errors:"
      for ($i = 0; $i -le $LogContainingErrors.count - 1; $i++) 
      {
         $LogFileName = $LogContainingErrors[$i]
         Write-Host "$LogFileName"
      }
      Write-Host " "
      return $true
   }
   else
   {
      Write-Host -ForegroundColor Blue "No erros found in the log files!" 
      Write-Host " "
      return $false
   }
} # ErrorsExistedInLogs
