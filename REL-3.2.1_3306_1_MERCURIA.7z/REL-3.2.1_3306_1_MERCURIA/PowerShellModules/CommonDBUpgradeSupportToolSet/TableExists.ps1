# **********************************************************************************************************
#  TableExists.ps1
#     It returns a status indicating whether the given table exists or not
#     
#     Usage:
#        [bool]$State=TableExists -ConnString <?>
#                                   -SchemaName <?>
#                                   -TableName <?>
#
#            Example: [bool]$State=TableExists -ConnString ".." 
#                                              -SchemaName "dbo" 
#                                              -TableName "acount" 
#
#     Output:
#        It returns either $true or $false:
#           $true    - Table exists
#           $false   - Table does not exist
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function TableExists
{
   Param([string]$ConnString, 
         [string]$SchemaName="dbo",
         [string]$TableName)
   
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnString
   $conn.Open()
   $sql = "select isnull(OBJECT_ID('$SchemaName.$TableName', 'U'), 0)"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   [int]$TableID=$rdr[0]
   $rdr.Close()
   $conn.Close()
   if ($TableID -gt 0)
   {
      return $true
   }
   else
   {
      return $false
   }
} #TableExists
