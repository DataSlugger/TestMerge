# **********************************************************************************************************
#  ColumnDataType.ps1
#     It returns the current data type of the given column
#     
#     Usage:
#        [string]$CurrentDataType=ColumnDataType -ConnString <?>
#                                                -SchemaName <?>
#                                                -TableName <?>
#                                                -ColumnName <?>
#
#            Example: [string]$CurrentDataType=ColumnDataType -ConnString ".." 
#                                                             -SchemaName "dbo"
#                                                             -TableName "acount"
#                                                             -ColumnName "acct_num"
#
#     Output:
#        A SQL Server data type
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function ColumnDataType
{
   Param([string]$ConnString, 
         [string]$SchemaName="dbo",
         [string]$TableName,
         [string]$ColumnName)

   $TableExists = (TableExists -ConnString $ConnString -SchemaName $SchemaName -TableName $TableName)
   if (!($TableExists)) {return "TABLE_DOES_NOT_EXIST"}

   $ColumnStatus = (ColumnExists -ConnString $ConnString -SchemaName $SchemaName -TableName $TableName -ColumnName $ColumnName)
   if ($ColumnStatus -eq "NO") {return "COLUMN_DOES_NOT_EXIST"}
   
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnString
   $conn.Open()
   $sql = "select dbo.udf_table_column_data_type('$SchemaName', '$TableName', '$ColumnName')"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   $ColDataType=$rdr[0]
   $rdr.Close()
   $conn.Close()
   if ($ColDataType.Length -gt 0)
   {
      return $ColDataType
   }
   else
   {
      return "DATA_TYPE_NOT_FOUND"
   }
} #ColumnDataType
