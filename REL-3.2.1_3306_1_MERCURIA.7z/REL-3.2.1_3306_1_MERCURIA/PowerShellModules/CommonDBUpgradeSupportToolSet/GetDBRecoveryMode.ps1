# *****************************************************************************************
#   GetDBRecoveryModel.ps1
#      It returns the current database recovery mode of the given database
#
#     Usage:
#        [string]$DBRecoveryModel=GetDBRecoveryModel -DBInMirroringState <?> -Database <?>
#
#     Output: 
#        It returns one of following modes:
#           Simple, 
#           Full,  
#           Bulk-logged
# -----------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# *****************************************************************************************

function GetDBRecoveryModel
{
   Param([string]$ConnString, 
         [string]$Database)
   
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnString
   $conn.Open()
   $sql = "select recovery_model_desc from sys.databases where name = '$Database'"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   $DBRecoveryModel = $rdr[0]
   $rdr.Close()
   $conn.Close()
   return $DBRecoveryModel
} #GetDBRecoveryModel
 