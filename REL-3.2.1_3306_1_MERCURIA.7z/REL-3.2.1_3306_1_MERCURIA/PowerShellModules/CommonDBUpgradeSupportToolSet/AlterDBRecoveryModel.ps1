# *****************************************************************************************
#   AlterDBRecoveryModel.ps1
#      It changes the database recovery mode from its current mode to the recovery
#      passed to the argument $NewRecoveryModel
#
#     Usage:
#        AlterDBRecoveryModel -ConnString <?> -Database <?> -NewRecoveryModel <?>
# -----------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# *****************************************************************************************

function AlterDBRecoveryModel
{
   Param([string]$ConnString, 
         [string]$Database, 
         [string]$NewRecoveryModel)
   
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnString
   $conn.Open()

   $sql = "ALTER DATABASE $Database SET RECOVERY $NewRecoveryModel"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $cmd.ExecuteNonQuery() | out-null

   $sql = "select recovery_model_desc from sys.databases where name = '$Database'"
   $cmd.CommandText = $sql
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   $RecoveryModel = $rdr[0]
   if ($RecoveryModel)
   {
      write-host "The new recovery model of the '$Database' database is $RecoveryModel"
   }
   else
   {
      write-host "Unable to find the new recovery model for the '$Database' database!"
   }
   $rdr.Close()
   $conn.Close()
} #AlterDBRecoveryModel

