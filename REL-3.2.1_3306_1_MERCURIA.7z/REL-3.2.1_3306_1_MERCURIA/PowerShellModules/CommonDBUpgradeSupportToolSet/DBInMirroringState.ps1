# *****************************************************************************************
#   DBInMirroringState.ps1
#      It checks to see if the trade database has mirroring setup. If it does, then
#      we can not change database recovery mode
#
#     Usage:
#        [bool]$MirroringSetup=DBInMirroringState.ps1 -ConnString <?> -Database <?>
# -----------------------------------------------------------------------------------------
#     Output: 
#        It returns either $true or $false:
#           $true    - Yes, database has mirroring setup
#           $false   - Database does not have mirroring setup
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# *****************************************************************************************
function DBInMirroringState
{
   Param([string]$ConnString, 
         [string]$Database)
   
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnString
   $conn.Open()
   $sql = "select case when b.mirroring_state is null then 'NO' else 'YES' end as mirroring_state from sys.databases a INNER JOIN sys.database_mirroring b ON a.database_id = b.database_id WHERE a.name = '$Database'"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   if ($rdr[0] -eq "YES")
   {
      $status = $true
   }
   else
   {
      $status = $false
   }
   $rdr.Close()
   $conn.Close()
   return $status
} #DBInMirroringState
