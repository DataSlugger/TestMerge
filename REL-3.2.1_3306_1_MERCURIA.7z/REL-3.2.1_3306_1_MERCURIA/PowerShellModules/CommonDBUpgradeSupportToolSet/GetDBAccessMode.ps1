# *****************************************************************************************
#   GetDBAccessMode.ps1
#      It gets the current database access mode
#
#     Usage:
#        [string]$DBAccessMode=GetDBAccessMode -DBInMirroringState <?> -Database <?>
# -----------------------------------------------------------------------------------------
#     Output: 
#        It returns one of following modes:
#           SINGLE_USER,
#           RESTRICTED_USER,
#           MULTI_USER
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# *****************************************************************************************
function GetDBAccessMode
{
   Param([string]$ConnString, [string]$Database)
   
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnString
   $conn.Open()
   $sql = "select user_access_desc from sys.databases where name = '$Database'"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   $UserAccessMode = $rdr[0]
   $rdr.Close()
   $conn.Close()
   return $UserAccessMode
} #GetDBAccessMode
