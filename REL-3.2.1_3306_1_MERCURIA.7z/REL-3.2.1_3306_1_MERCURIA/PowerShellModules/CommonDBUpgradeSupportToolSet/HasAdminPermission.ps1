# *****************************************************************************************
#   HasAdminPermission.ps1
#      It returns a status indicating if the login has administrative permissions 
#
#     Usage:
#        [bool]$PermissionOK = HasAdminPermission -DBInMirroringState <?> -Database <?>
# 
#     Output: 
#        It returns either $true or $false:
#           $true    - Yes, <login> has the desired administrative permissions
#           $false   - <login> does not have the desired administrative permissions
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# *****************************************************************************************
function HasAdminPermission
{
   Param([string]$ConnString, 
         [string]$Database)
   
   if ($Login -eq "sa")
   {
      return $true
   }
 
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnString
   $conn.Open()

   $sql = "select convert(bit, IS_SRVROLEMEMBER('sysadmin', '$Login'))"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   if ($rdr[0])
   {
      $conn.Close()
      return $true
   }
   else
   {
      #write-host "$Login is not a member of sysadmin"
    }
   $rdr.Close()

   $cmd.CommandText = "select convert(bit, IS_SRVROLEMEMBER('securityadmin', '$Login'))"
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   if ($rdr[0])
   {
      #write-host "$Login is a member of securityadmin"
   }
   else
   {
      $conn.Close()
      return $false
   }
   $rdr.Close()
   
   $cmd.CommandText = "select convert(bit, IS_ROLEMEMBER('db_owner', '$Login'))"
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null

   if ($rdr[0])
   {
      $conn.Close()
      return $true
   }
   else
   {
      $conn.Close()
      return $false
   }
} #HasAdminPermission
