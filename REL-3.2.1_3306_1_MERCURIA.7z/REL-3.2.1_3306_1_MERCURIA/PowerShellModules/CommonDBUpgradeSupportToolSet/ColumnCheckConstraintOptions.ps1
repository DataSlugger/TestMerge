# **********************************************************************************************************
#  ColumnCheckConstraintOptions.ps1
#     It returns the current check constraint options of the given column
#     
#     Usage:
#        [string]$CheckOptions=ColumnCheckConstraintOptions -ConnString <?>
#                                                           -SchemaName <?>
#                                                           -TableName <?>
#                                                           -ColumnName <?>
#
#            Example: [string]$CheckOptions=ColumnCheckConstraintOptions -ConnString ".." 
#                                                                        -SchemaName "dbo"
#                                                                        -TableName "acount"
#                                                                        -ColumnName "acct_num"
#
#     Output:
#        The returned status string can be
#           TABLE_DOES_NOT_EXIST indicates that the given table is invalid
#           COLUMN_DOES_NOT_EXIST indicates that the given column1 does not exist 
#           CHECK_OPTIONS_NOT_FOUND indicates that the given column does not have check constraint options
#           Otherwise, a check constraint expression           
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function ColumnCheckConstraintOptions
{
   Param([string]$ConnString, 
         [string]$SchemaName="dbo",
         [string]$TableName,
         [string]$ColumnName)

   $TableExists = (TableExists -ConnString $ConnString -SchemaName $SchemaName -TableName $TableName)
   if (!($TableExists)) {return "TABLE_DOES_NOT_EXIST"}

   $ColumnStatus = (ColumnExists -ConnString $ConnString -SchemaName $SchemaName -TableName $TableName -ColumnName $ColumnName)
   if ($ColumnStatus -eq "NO") {return "COLUMN_DOES_NOT_EXIST"}
   
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnString
   $conn.Open()
   $sql = "select dbo.udf_column_check_constraint_options('$SchemaName', '$TableName', '$ColumnName')"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   $ColCheckOptions=$rdr[0]
   $rdr.Close()
   $conn.Close()
   if ($ColCheckOptions.Length -gt 0)
   {
      return $ColCheckOptions
   }
   else
   {
      return "CHECK_OPTIONS_NOT_FOUND"
   }
} #ColumnCheckConstraintOptions
