# **********************************************************************************************************
#  ShowCurrentTime.ps1
#     It executes a TSQL script by using Invoke-Sqlcmd method to return current time
#     
#     Usage:
#        [string]$current_time = ShowCurrentTime
#
#     Output:
#        It returns a string containing current datetime
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function ShowCurrentTime
{
   Param([string]$heading)

   $dt=[System.DateTime]::Now
   $dt.ToString("M/dd/yyyy hh:mm") | out-null
   if ($heading -like 'STARTED*') {Write-Host " "}
   Write-Host "$heading : $dt"
   if ($heading -like 'FINISHED*') {Write-Host " "}
   return $dt
} #ShowCurrentTime
