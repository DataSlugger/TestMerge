# **********************************************************************************************************
#  ColumnDefaultValue.ps1
#     It returns the current default value of the given column
#     
#     Usage:
#        [string]$DefaultValue=ColumnDefaultValue -ConnString <?>
#                                                 -SchemaName <?>
#                                                 -TableName <?>
#                                                 -ColumnName <?>
#
#            Example: [string]$DefaultValue=ColumnDefaultValue -ConnString ".."
#                                                              -SchemaName "dbo"
#                                                              -TableName "acount"
#                                                              -ColumnName "man_input_sec_qty_required"
#
#     Output:
#        It returns one of following strings:
#           TABLE_DOES_NOT_EXIST indicates that the given table is invalid
#           COLUMN_DOES_NOT_EXIST indicates that the given column1 does not exist 
#           DEFAULT_VALUE_NOT_FOUND indicates that the given column does not have check constraint options
#           Otherwise, a default value           
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function ColumnDefaultValue
{
   Param([string]$ConnString, 
         [string]$SchemaName="dbo",
         [string]$TableName,
         [string]$ColumnName)

   $TableExists = (TableExists -ConnString $ConnString -SchemaName $SchemaName -TableName $TableName)
   if (!($TableExists)) {return "TABLE_DOES_NOT_EXIST"}

   $ColumnStatus = (ColumnExists -ConnString $ConnString -SchemaName $SchemaName -TableName $TableName -ColumnName $ColumnName)
   if ($ColumnStatus -eq "NO") {return "COLUMN_DOES_NOT_EXIST"}
   
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnString
   $conn.Open()
   $sql = "select dbo.udf_column_default_value($SchemaName, $TableName, @ColumnName)"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   $ColDefaultValue=$rdr[0]
   $rdr.Close()
   $conn.Close()
   if ($ColDefaultValue.Length -gt 0)
   {
      return $ColDefaultValue
   }
   else
   {
      return "DEFAULT_VALUE_NOT_FOUND"
   }
} #ColumnDefaultValue
