# **********************************************************************************************************
#  ShowAndSaveProgress.ps1
#     It displays a message on terminal screen and write message to a given log file 
#     
#     Usage:
#        ShowAndSaveProgress -LogFileName <?> -Message <?>
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function ShowAndSaveProgress
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$LogFileName,
      [parameter(Mandatory=$true)]  [string]$Message
   )
   
   write-host $Message
   write-output $Message | out-file $LogFileName -append
} #ShowAndSaveProgress
