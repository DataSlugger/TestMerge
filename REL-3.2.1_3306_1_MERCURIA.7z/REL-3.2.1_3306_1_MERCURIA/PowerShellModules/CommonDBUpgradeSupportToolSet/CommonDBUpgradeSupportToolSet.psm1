#Dot source all functions in all ps1 files located in the module folder 
Get-ChildItem -Path $env:USERPROFILE\Documents\WindowsPowerShell\Modules\CommonDBUpgradeSupportToolSet\*.ps1 -Exclude *tests.ps1, *profile.ps1, Import-MrSqlModule |
ForEach-Object {
    . $_.FullName
}
