# **********************************************************************************************************
#  ColumnExists.ps1
#     It returns a status string indicating if the given column exists in table 
#     
#     Usage:
#        [string]$State=ColumnExists -ConnString <?>
#                                    -SchemaName <?>
#                                    -TableName <?>
#                                    -ColumnName <?>
#
#            Example: [string]$State=ColumnExists -ConnString ".." 
#                                                 -SchemaName dbo 
#                                                 -TableName acount 
#                                                 -ColumnName acct_num
#
#     Output:
#        The returned status string can be
#           TABLE_DOES_NOT_EXIST indicates that the given table is invalid
#           YES indicates that the column exists
#           NO indicates that the column does not exist
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************
function ColumnExists
{
   Param([string]$ConnString, 
         [string]$SchemaName="dbo",
         [string]$TableName,
         [string]$ColumnName)

   $TableExists = (TableExists -ConnString $ConnString -SchemaName $SchemaName -TableName $TableName)
   if (!($TableExists)) {return "TABLE_DOES_NOT_EXIST"}
   
   $conn = New-Object System.Data.SqlClient.SqlConnection
   $conn.ConnectionString = $ConnString
   $conn.Open()
   $sql = "select isnull(name, '@@@') from sys.columns where object_id = OBJECT_ID('$SchemaName.$TableName', 'U') and name = '$ColumnName'"   #write-host "DEBUG: Executing the query '$sql'"
   $cmd = New-Object System.Data.SqlClient.SqlCommand($sql, $conn)
   $rdr = $cmd.ExecuteReader()
   $rdr.Read() | out-null
   $Returned_ColName=$rdr[0]
   $rdr.Close()
   $conn.Close()
   if ($Returned_ColName -eq $ColumnName)
   {
      return "YES"
   }
   else
   {
      return "NO"
   }
} #ColumnExists
