# *****************************************************************************************
#   GetDesiredDatabase_GUI.ps1
#      It displays a GUI screen to pick a desired database
#
#     Usage:
#        GetDesiredDatabase_GUI 
# -----------------------------------------------------------------------------------------
#     Output: 
#        It returns an array containing the following elements:
#            Element #1: <Server instance>
#            Element #2: SQL Server Authentication or Windows Authentication
#            Element #3: Login if SQL Server Authentication was selected
#            Element #4: Password if SQL Server Authentication was selected
# ----------------------------------------------------------------------------------------------------------
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# *****************************************************************************************
function GetDesiredDatabase_GUI
{
   Param
   (
      [parameter(Mandatory=$true)] [string]$Server, 
      [parameter(Mandatory=$true)] [string]$Authentication,       
      [parameter(Mandatory=$true)] [string]$Login, 
      [parameter(Mandatory=$true)] [string]$Password
   )

   $script:Database=$Null
   $script:Action="OK"
   $objForm = New-Object System.Windows.Forms.Form 
   $objForm.Text = "Database Selection"
   $objForm.Size = New-Object System.Drawing.Size(300,280) 
   $objForm.StartPosition = "CenterScreen"

   $objForm.KeyPreview = $true
   $objForm.Add_KeyDown({if ($_.KeyCode -eq "Enter") 
    {$script:Database=$objListBoxDatabase.SelectedItem;$objForm.Close()}})
   $objForm.Add_KeyDown({if ($_.KeyCode -eq "Escape") 
    {$objForm.Close()}})

   # Setup OK button
   $OKButton = New-Object System.Windows.Forms.Button
   $OKButton.Location = New-Object System.Drawing.Size(75, 200)
   $OKButton.Size = New-Object System.Drawing.Size(70,30)
   $OKButton.Text = "OK"
   $OKButton.Add_Click({$script:Database=$objListBoxDatabase.SelectedItem;$objForm.Close()})
   $objForm.Controls.Add($OKButton)

   # Setup CANCEL button
   $CancelButton = New-Object System.Windows.Forms.Button
   $CancelButton.Location = New-Object System.Drawing.Size(155,200)
   $CancelButton.Size = New-Object System.Drawing.Size(75,30)
   $CancelButton.Text = "Cancel"
   $CancelButton.Add_Click({$script:Action="CANCEL";$objForm.Close()})
   $objForm.Controls.Add($CancelButton)

   # Setup Label for the Database ListBox
   $objLabelDatabase = New-Object System.Windows.Forms.Label
   $objLabelDatabase.Location = New-Object System.Drawing.Size(24,33) 
   $objLabelDatabase.Size = New-Object System.Drawing.Size(65,60) 
   $objLabelDatabase.Text = "Database:"
   $objForm.Controls.Add($objLabelDatabase) 

   # Setup Database ListBox
   $objListBoxDatabase = New-Object System.Windows.Forms.ListBox 
   $objListBoxDatabase.Location = New-Object System.Drawing.Size(94,33) 
   #$objListBoxDatabase.Size = New-Object System.Drawing.Size(160,160) 
   $objListBoxDatabase.Height = 140
   $objListBoxDatabase.Width = 170

   # Load items into the Database ListBox
   [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
   $srv = new-object ('Microsoft.SqlServer.Management.Smo.Server') "$Server"
   if ($Authentication -eq "Windows Authentication")
   {
      $srv.ConnectionContext.LoginSecure=$true;
   }
   else
   {
      $srv.ConnectionContext.LoginSecure=$false;
      $srv.ConnectionContext.set_Login($Login);
      $srv.ConnectionContext.set_Password($Password)
   }
   $dbs=$srv.Databases | Select name

   # DEBUG: Show a list of databases    $dbs

   foreach ($db in $dbs) 
   {
      if (($db.Name -ne "tempdb") -and ($db.Name -ne "master") -and ($db.Name -ne "msdb") -and ($db.Name -ne "model")  -and ($db.Name -ne "distribution"))
      {
         [void] $objListBoxDatabase.Items.Add($db.Name)
      }
   }
   $objForm.Controls.Add($objListBoxDatabase) 

   $objForm.Topmost = $True

   $objForm.Add_Shown({$objForm.Activate()})
   [void] $objForm.ShowDialog()

   if ($Action -eq "CANCEL")
   {
      return "@@@"
   }

   if ($Database)
   {
      Write-Host "Database Picked:" $Database 
      return $Database
   }   
   else
   {
      Write-Host "You must select a database!"
      return "@@@"
   }
}
