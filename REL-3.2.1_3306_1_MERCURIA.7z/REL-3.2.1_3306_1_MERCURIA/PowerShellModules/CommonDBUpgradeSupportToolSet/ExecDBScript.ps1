# **********************************************************************************************************
#  ExecDBScript.ps1
#     It executes a TSQL script by using Invoke-Sqlcmd method. 
#     
#     Usage:
#        [bool]$status = ExecDBScript -Server <?>
#                                     -Auth <?>
#                                     -Login <?> 
#                                     -Password <?> 
#                                     -Database <?>
#                                     -ScriptPath <?>
#                                     -ScriptFileName <?>
#                                     -LogFileName <?>
#
#
#     Output:
#        It returns either $true or $false:
#           $true    - The script was executed without errors
#           $false   - The script was executed with errors
#  ---------------------------------------------------------------------------------------------------------
#
#   Created By           : Peter Lo  04/18/2016
#   Last Edited By       : Peter Lo  04/18/2016
#   Database             : SQL Server 2008R2 or later
#   PowerShell version   : 3.0 or later
#   Company              : Amphora, Inc
# **********************************************************************************************************

function ExecDBScript
{
   Param
   (
      [parameter(Mandatory=$true)]  [string]$Server, 
      [parameter(Mandatory=$true)]  [string]$Auth,
      [parameter(Mandatory=$false)] [string]$Login, 
      [parameter(Mandatory=$false)] [string]$Password, 
      [parameter(Mandatory=$true)]  [string]$Database,
      [parameter(Mandatory=$true)]  [string]$ScriptPath,
      [parameter(Mandatory=$true)]  [string]$ScriptFileName,
      [parameter(Mandatory=$true)]  [string]$LogFileName="@@@"
   )
   
   $FullScriptFileName = "$ScriptPath\$ScriptFileName"
   #Write-Host "=> Executing the '$ScriptFileName' script ..."
   #Write-Output "=> Executing the '$ScriptFileName' script ..." | Out-File $LogFileName -append 
   if (Test-Path $FullScriptFileName)
   {
      try
      {
         if ($Auth -eq "Windows Authentication")
         {
            Invoke-Sqlcmd -ServerInstance $Server -Database $Database -MaxCharLength 200 -QueryTimeout 65334 -InputFile "$FullScriptFileName" -ErrorVariable err1 -ErrorAction "SilentlyContinue"
         }
         else # "SQL Server Authentication"
         {
            Invoke-Sqlcmd -ServerInstance $Server -Username $Login -Password $Password -Database $Database -MaxCharLength 200 -QueryTimeout 65334 -InputFile "$FullScriptFileName" -ErrorVariable err1 -ErrorAction "SilentlyContinue"
         }
         if ($err1)
         {
            Write-Host "==> Failed to execute the db script '$FullScriptFileName'"
            if ($LogFileName -ne "@@@") 
            {
               Write-Output "==> Failed to execute the db script '$FullScriptFileName'" | out-file $LogFileName -append
               $err1 | out-file $LogFileName -append
            }
            return $false
         }
      }
      catch
      {
         $ErrorMessage = $_.Exception.Message
         Write-Host "==> Failed to execute the db script '$FullScriptFileName' due to the ERROR: $ErrorMessage"
         if ($LogFileName -ne "@@@") 
         {
            Write-Output "Error: Failed to execute the db script '$FullScriptFileName' due to the ERROR: $ErrorMessage" | out-file $LogFileName -append
            $dt = ShowCurrentTime -heading "FINISHED"
            Write-Output "FINISHED: $dt" | out-file $LogFileName -append
         }
         return $false
      }
   }
   else
   {
      Write-Host -ForegroundColor Red "Can't find db script file --> $FullScriptFileName"
      Write-Output "Error: Can't find db script file '$FullScriptFileName'" | out-file $LogFileName -append
      return $false
   }
   return $true
} #ExecDBScript
